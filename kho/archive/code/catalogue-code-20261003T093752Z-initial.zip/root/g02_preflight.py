from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.otext import OutlineText
from g02_halobank import make_halobank,plot_halos,insert_halo
from pathlib import Path
import pickle,json
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';E=Editor(S.result(NAME));T=OutlineText(E)
T.__dict__.update(pickle.loads(Path(S.report('G02/nhan-dung-cho-ve.pkl')).read_bytes()));T.E=E
plans=json.loads(Path(S.report('G02/ke-hoach-ve.json')).read_text(encoding='utf-8'));out=[];bank=make_halobank(T)
for ps,plan in plans.items():
    p=int(ps)-1;gs=T.page_glyphs(p);n=0;old=plot_halos(E,p,plan['plot']);target=min(oi for oi,gg in old)
    for row in plan['curves']:
        for oi in row['label_ois']:
            g=next(g for g in gs if g.oi==oi);proof=insert_halo(E,p,target,g,[0,0],bank)
            out.append(dict(page=p+1,model=row['model'],blue=oi,**proof));n+=1
    print('ĐẠT VIỀN',ps,n,'chữ, chép đúng hình viền theo biến đổi chữ xanh',flush=True)
Path(fresh(S.report('G02/ban-do-vien-trang-tu-nguyen-mau.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=1),encoding='utf-8')
E.close()
