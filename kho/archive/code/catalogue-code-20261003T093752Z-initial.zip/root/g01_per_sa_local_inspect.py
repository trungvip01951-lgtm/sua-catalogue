from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,collections
from catfix.vector import Editor
from catfix.raster import Raster
import numpy as np

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
src=S.src(name);dst=S.result(name)
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
RDIR=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
d=json.loads((RDIR/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'))
E=Editor(src);R=Raster(E)
for g in d['graphs']:
 if g['page']==8:continue
 if len(sys.argv)>1 and g['family'] not in sys.argv[1:]:continue
 print('FAMILY',g['family'],'PAGE',g['page'])
 a=g['axis'];print('FRAME',a['frame_native'],'FLOW',a['flow_ticks'],'H',a.get('H_grid_calibration'))
 for c in g['curves']:
  targets=[p for p in c['points'] if p['status']!='KHỚP MỐC']
  if not targets:continue
  print('MODEL',c['model'],'LABEL',c.get('label_native_box'),'SEED',c.get('seed'),'IDENTITY',c.get('identity_confirmed'))
  for p in targets:
   keys=['Q_m3_h','H_table_m','target_u_native','v_native','H_curve_m','delta_H_m','uncertainty_H_m','status','reason','observed_u_domain','variant4_5_difference_H_m']
   print('P',json.dumps({k:p[k] for k in keys if k in p},ensure_ascii=False))
E.close()
