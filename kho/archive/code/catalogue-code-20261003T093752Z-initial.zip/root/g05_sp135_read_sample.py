"""Đọc PDF mẫu2nétSP135: actualpath,132mốc ảnh, nguyênmốc khác trong2218.
KhôngsửaPDF; giữmọiUNKNOWN vàsai sốảnh150dpi.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from catfix.vector import Editor
from catfix import verify,charts
from PIL import Image,ImageDraw
from pathlib import Path
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter
import numpy as np,json,hashlib,csv,copy,pymupdf as fitz

O='G05/10SP135 HAI MOC CUOI/'+('MAU 2/' if '--mau2' in sys.argv else 'MAU 1/')
I='G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO/'
rec=json.loads(Path(S.report(O+'TOA DO VA BANG NGUON.json')).read_text(encoding='utf8'));saved=json.loads(Path(S.report(O+'GHI PDF VA NGOAI VUNG.json')).read_text(encoding='utf8'))
old=json.loads(Path(S.report(I+'NGHIEM THU QH PDF MAU.json')).read_text(encoding='utf8'))
current=rec['current_path'];trial=saved['trial'];name='Perotac bơm giếng SP_compressed (bản mới).pdf';source=S.src(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)==rec['current_sha256'] and sha(trial)==saved['trial_sha256'] and sha(source)==rec['source_sha256']
b=rec['axis'];t=TABLES['10SP135'];r=b['rect'];s=72/b['dpi'];xt=np.array(b['xticks']);yt=np.array(b['yticks']);E=Editor(trial);P=E.page(10)
def y_at(path,x):
 cur=None
 for op,p in path:
  if op=='m':cur=np.array(p[0]);continue
  if op=='c':
   ctrl=np.vstack([cur,np.array(p)]);end=ctrl[-1]
   if cur[0]-1e-5<=x<=end[0]+1e-5:
    lo=0.;hi=1.
    for _ in range(70):
     z=(lo+hi)/2;v=(1-z)**3*ctrl[0]+3*(1-z)**2*z*ctrl[1]+3*(1-z)*z*z*ctrl[2]+z**3*ctrl[3]
     if v[0]<x:lo=z
     else:hi=z
    return float(v[1])
   cur=end
 raise ValueError((x,'notinpath'))
actual=[];styles=[];joins=[]
for c in rec['curves']:
 wanted=np.array(c['color_rgb'])/255;cand=[]
 for oi,o in enumerate(P.objs):
  col=P.color_of(oi,'stroke')
  if o['op']=='S' and col is not None and max(abs(np.array(col)-wanted))<1e-8:cand.append((oi,o))
 assert len(cand)==1,(c['model'],cand)
 oi,o=cand[0];path=P.object_pagepath(oi);arr=charts.sample_path(path,n=200);assert np.max(abs(arr[0]-c['start_page']))<1e-5 and np.max(abs(arr[-1]-c['end_page']))<1e-5
 assert abs(o['lw']-c['width_pt'])<1e-7 and len(o['dash'][0])==0 and np.max(abs(o['ctm']-np.eye(3)))<1e-7
 x=float(np.interp(180,xt[:,0],xt[:,1]));y=y_at(path,x);hc=float(np.interp(y,yt[:,1],yt[:,0]));dev=abs(hc-c['target_H']);assert dev<1e-4
 seg=np.array(path[1][1]);deriv=float((seg[-1,1]-seg[-2,1])/(seg[-1,0]-seg[-2,0]));unpt=.24+.24*abs(deriv);un=max(abs(float(np.interp(y+unpt,yt[:,1],yt[:,0]))-hc),abs(float(np.interp(y-unpt,yt[:,1],yt[:,0]))-hc));lim=max(1,.02*c['target_H']);assert dev+un<=lim
 actual.append(dict(page=11,model=c['model'],rank=c['rank'],object_index=oi,Q=180,H_table=c['target_H'],H_actual_PDF=hc,deviation_m=dev,axis_uncertainty_m=un,axis_uncertainty_pt=unpt,limit_m=lim,status='ĐẠT'))
 styles.append(dict(model=c['model'],object_index=oi,stroke_rgb=list(P.color_of(oi,'stroke')),width_pt=o['lw'],dash=str(o['dash']),matrix=o['ctm'].tolist(),start_page=arr[0].tolist(),end_page=arr[-1].tolist(),start_error_pt=float(np.max(abs(arr[0]-c['start_page']))),end_error_pt=float(np.max(abs(arr[-1]-c['end_page'])))))
 # Real source tangent from actualpath control and intended smoothjoin.
 start_derivative=float((seg[0,1]-arr[0,1])/(seg[0,0]-arr[0,0]));target_derivative=float((c['segments'][0][1][1]-c['segments'][0][0][1])/(c['segments'][0][1][0]-c['segments'][0][0][0]));assert abs(start_derivative-target_derivative)<1e-5
 joins.append(dict(model=c['model'],Q=c['Q_join'],actual_start=arr[0].tolist(),source_tangent=target_derivative,actual_tangent=start_derivative,tangent_error=abs(start_derivative-target_derivative)))

im=verify.crop(trial,10,r,600).convert('RGB');g=np.array(im.convert('L'),float);xp=lambda q:(float(np.interp(q,xt[:,0],xt[:,1]))-r[0])/s;yp=lambda h:(r[3]-float(np.interp(h,yt[:,0],yt[:,1])))/s;hd=lambda y:float(np.interp(r[3]-y*s,yt[:,1],yt[:,0]))
n=len(t['rows']);l=round(xp(0));right=round(xp(b['Qmax']));top=round(yp(b['Hmax']));bot=round(yp(0));ink=255-g;full=np.zeros_like(g);full[top+8:bot-8]=ink[top+8:bot-8];titlex=int(l+.78*(right-l));titley=int(yp(b['Hmax']*.85));full[top:titley,titlex:right+3]=0;full=gaussian_filter(full,(.5,.5));out=[];dr=ImageDraw.Draw(im)
for iq,q in enumerate(t['Q']):
 x=xp(q);sets=[];counts=[];offsets=list(range(-32,33,4))
 if q==0:offsets=list(range(8,33,3))
 if iq==len(t['Q'])-1:offsets=list(range(-32,1,3))
 for dx in offsets:
  xx=round(x+dx);v=np.mean(full[:,xx-1:xx+2],axis=1);pk,_=find_peaks(v,prominence=20,height=70,distance=7);pk=pk[(pk>top+10)&(pk<bot-8)];counts.append((dx,len(pk)))
  if len(pk)==n:
   cy=[]
   for p in pk[::-1]:
    ids=np.arange(p-2,p+3);w=np.maximum(0,v[ids]-min(v[ids]));cy.append(float(np.sum(ids*w)/sum(w)) if sum(w)>0 else float(p))
   sets.append((float(xx),np.array(cy)))
 for k,row in enumerate(t['rows']):
  h=row['H'][iq];p=dict(page=11,family='10SP135',row=k+1,source_label=row['curve_model'],curve_model=row['curve_model'],table_models=' | '.join(row['table_models']),Q_m3h=q,H_table_m=h,identity_uncertain=False,slices=len(sets),actual_vector=False,H_curve_m=None,nominal_status='CHƯA THỂ',confidence_status='CHƯA THỂ',reason='Không đủ3látcắt đủ12nét nguồn',measurement_method='Lát sắcđộPDFmẫu thật; thứtựnhãn nguồn, khônglấyH bảng tìm nét.')
  if len(sets)>=3:
   xx=np.array([z[0] for z in sets]);yy=np.array([z[1][k] for z in sets]);cf=np.polyfit(xx,yy,1);cy=float(np.polyval(cf,x));spread=float(max(abs(yy-np.polyval(cf,xx))));extrap=max(min(xx)-x,x-max(xx),0)*s;p.update(local_spread_px=spread,slope=float(cf[0]),extrap_pt=extrap)
   if spread<=3.5 and abs(cf[0])<=1.9 and extrap<=1.8:
    hc=hd(cy);err=.24+max(.24,s*spread)+.06+abs(cf[0])*.30
    if extrap>0:err+=extrap*max(abs(cf[0]),.02)*.15
    un=max(abs(hd(cy+err/s)-hc),abs(hd(cy-err/s)-hc));dev=abs(hc-h);lim=max(1,.02*h);st='ĐẠT' if dev+un<=lim else ('CHƯA ĐẠT' if dev-un>lim else 'CHƯA THỂ')
    p.update(H_curve_m=hc,deviation_m=dev,limit_m=lim,uncertainty_m=un,uncertainty_position_pt=err,nominal_status='ĐẠT' if dev<=lim else 'CHƯA ĐẠT',confidence_status=st,x_px=x,y_px=cy,sample_locations=[dict(x_px=z[0],y_px=float(z[1][k])) for z in sets],reason='Biênsai số150dpi chạmngưỡng' if st=='CHƯA THỂ' else '')
   else:p['reason']='Látcắt khônggiữcùngnét hoặc ngoại suyquáxa'
  if q==180 and row['curve_model'] in ['10SP135-5','10SP135-7']:
   z=next(z for z in actual if z['model']==row['curve_model']);p['raster_measurement']={a:p.get(a) for a in ['H_curve_m','deviation_m','confidence_status','uncertainty_m','slope']}
   p.update(actual_vector=True,actual_object_index=z['object_index'],H_curve_m=z['H_actual_PDF'],deviation_m=z['deviation_m'],limit_m=z['limit_m'],uncertainty_m=z['axis_uncertainty_m'],uncertainty_position_pt=z['axis_uncertainty_pt'],nominal_status='ĐẠT',confidence_status='ĐẠT',x_px=x,y_px=yp(z['H_actual_PDF']),reason='',measurement_method='ActualpathPDF quaQ180; sai sốtrục ảnh150dpi .24pt/Y+.24pt/X tínhđộdốc.')
  p['verification_status']=p['confidence_status'];out.append(p)
  y=yp(h);dr.line((x-5,y,x+5,y),fill=(170,0,240),width=2);dr.line((x,y-5,x,y+5),fill=(170,0,240),width=2)
  if p['H_curve_m'] is not None:
   cy=yp(p['H_curve_m']);co=(0,130,20) if p['confidence_status']=='ĐẠT' else ((235,10,10) if p['confidence_status']=='CHƯA ĐẠT' else (230,150,0));dr.ellipse((x-4,cy-4,x+4,cy+4),outline=co,width=2)
assert len(out)==132
im.save(fresh(S.report(O+'NGHIEM THU 132 MOC.png')))

# Exactpixelsguard forsourcepeer curves. Build600dpi sourcecenterlines fromranklocations;
# compare strips within3.5nativepixels around alltenunchangedcurves, plusalltextleft.
from scipy.interpolate import UnivariateSpline
before=np.asarray(verify.crop(current,10,r,600));after=np.asarray(verify.crop(trial,10,r,600));H,W=before.shape[:2];xx=np.arange(W)+.5;yy=np.arange(H)+.5;peer=[]
for k,row in enumerate(t['rows']):
 if row['curve_model'] in ['10SP135-5','10SP135-7']:continue
 bins={}
 for p in old['points']:
  if p['family']!='10SP135' or p['row']!=k+1 or p.get('H_curve_m') is None:continue
  for z in p['sample_locations']:bins.setdefault(round(z['x_px'],4),[]).append(z['y_px'])
 sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx]);spl=UnivariateSpline(sx,sy,s=len(sx)*.96,k=3)
 mask=np.zeros((H,W),bool)
 xmin=int((rec['curves'][0]['start_page'][0]-.5-r[0])/s);xmax=int((rec['curves'][0]['end_page'][0]+4.8-r[0])/s)
 for x in range(xmin,min(W,xmax+1)):
  centre=float(spl(min(x,xp(180))));mask[:,x]=abs(yy-centre)<14
 count=int(np.any(before[mask]!=after[mask],axis=1).sum());assert count==0,(row['curve_model'],count)
 peer.append(dict(model=row['curve_model'],curve_strip_halfwidth_nativepx=3.5,compared_pixels=int(mask.sum()),changed_pixels=count))
leftrect=(r[0],r[1],min(c['start_page'][0] for c in rec['curves'])-.5,r[3]);left=np.array_equal(np.asarray(verify.crop(current,10,leftrect,600)),np.asarray(verify.crop(trial,10,leftrect,600)));assert left
labels=[]
for model,rr in [('10SP135-5',(536,393,579,406)),('10SP135-7',(536,425,579,439))]:
 same=np.array_equal(np.asarray(verify.crop(current,10,rr,600)),np.asarray(verify.crop(trial,10,rr,600)));assert same;ocr=verify.ocr_check(current,10,rr,model);labels.append(dict(model=model,source_and_sample_label_pixels_identical600dpi=same,source_ocr=ocr,visual_identity_confirmed=True))
tables=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/BANG DAY DU.json')).read_text(encoding='utf8'));tableproof=[]
for tb in tables:
 same=np.array_equal(np.asarray(verify.crop(current,tb['page']-1,tb['rect'],450)),np.asarray(verify.crop(trial,tb['page']-1,tb['rect'],450)));assert same
 tableproof.append(dict(family=tb['family'],page=tb['page'],same_all_table_pixels450dpi=same))
allaxes=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'));panelproof=[]
for ax in allaxes:
 if ax['family']=='10SP135':continue
 same=np.array_equal(np.asarray(verify.crop(current,ax['page']-1,ax['rect'],600)),np.asarray(verify.crop(trial,ax['page']-1,ax['rect'],600)));assert same
 panelproof.append(dict(family=ax['family'],all_pixels600dpi_identical=same))
def resources(path):
 d=fitz.open(path);xr=d.xref_xml_metadata();z=dict(pages=len(d),rect=[list(p.rect) for p in d],fonts=[sorted((f[3],hashlib.sha256(d.extract_font(f[0])[3]).hexdigest()) for f in p.get_fonts(full=True)) for p in d],images=[sorted(hashlib.sha256(d.xref_stream_raw(im[0])).hexdigest() for im in p.get_images(full=True)) for p in d],info=d.metadata,xmp=d.xref_stream(xr) if xr else None,toc=d.get_toc(simple=False),links=[p.get_links() for p in d]);d.close();return z
a=resources(current);z=resources(trial);pres={k:a[k]==z[k] for k in ['pages','rect','fonts','info','xmp','toc','links']};pres['all_current_images_preserved']=all(set(x)<=set(y) for x,y in zip(a['images'],z['images']));assert all(pres.values()),pres
allpoints=copy.deepcopy([p for p in old['points'] if p['family']!='10SP135'])+out;ss=['ĐẠT','CHƯA ĐẠT','CHƯA THỂ'];overall={v:sum(p['verification_status']==v for p in allpoints) for v in ss};numeric={v:sum(p['confidence_status']==v for p in allpoints) for v in ss};assert len(allpoints)==2218
local=dict(trial=trial,trial_sha256=sha(trial),current_sha256=sha(current),source_sha256=sha(source),actual_endpoint_points=actual,actual_styles=styles,joins=joins,peer_curve_pixel_proof=peer,left_text_dashes_same600dpi=left,source_model_labels=labels,table_pixel_guards=tableproof,other14panels_pixel_guards=panelproof,preservation=pres,outside200=saved['outside200'],SP135_counts={v:sum(p['verification_status']==v for p in out) for v in ss},full2218_counts=overall,numeric_full2218_counts=numeric,group_status='CHƯA XONG',remaining_confirmed_failures=[p for p in allpoints if p['verification_status']=='CHƯA ĐẠT'],SP135_points=out,full2218_points=allpoints,prior132_points_remeasured=True,all_other2086_points_pixels_proven_unchanged=True)
Path(fresh(S.report(O+'NGHIEM THU PDF MAU 2END VA TOAN2218.json'))).write_text(json.dumps(local,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(S.report(O+'NGHIEM THU 2218 MOC.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 fields=list(dict.fromkeys(k for p in allpoints for k in p if k not in ['sample_locations','raster_measurement']));w=csv.DictWriter(fp,fields,extrasaction='ignore');w.writeheader();w.writerows(allpoints)
assert sha(current)==rec['current_sha256'] and sha(source)==rec['source_sha256']
E.close();print('SP135_READBACK actual',actual,'SP135counts',local['SP135_counts'],'FULL',overall,'peer unchanged',len(peer),'fonts/images/meta retained',flush=True)
