"""Chỉ phân tích ký tự đen trong 13 nhãn gốc, không dựng font hay mẫu mới."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
measurement=json.loads((root/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'))
E=Editor(src,backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H))
results=[];tiles=[]
bg=np.array([255.,255.,255.],np.float32);ink=np.array([57.,55.,57.],np.float32)
for w in measurement['glyph_word_sources']:
    record=dict(literal=w['literal'],source_box=w['original_native_box'],expected_count=len(w['literal']),source_only=True,analysis=[])
    for thr in [.50,.60,.68,.74]:
        comps=R.components(cv,w['original_native_box'],thr=thr,bg=bg,ink=ink,remove_lines=False,band=True,expect=None)
        record['analysis'].append(dict(alpha_threshold=thr,component_count_without_forced_split_or_merge=len(comps),
                                       component_source_boxes=[list(c['box']) for c in comps],
                                       expected_count_matches=len(comps)==len(w['literal']),
                                       not_a_glyph_shape_acceptance=True))
    x0,y0,x1,y1=w['original_native_box'];raw=Image.fromarray(cv.orig[y0:y1,x0:x1]);big=raw.resize((raw.width*8,raw.height*8),Image.Resampling.NEAREST)
    tile=Image.new('RGB',(600,170),'white');tile.paste(big,(2,25));ImageDraw.Draw(tile).text((2,2),w['literal']+' - ORIGINAL JPEG ONLY, 8x nearest',fill='black');tiles.append(tile)
    results.append(record)
sheet=Image.new('RGB',(1200,170*7),'white')
for k,t in enumerate(tiles):sheet.paste(t,((k%2)*600,(k//2)*170))
sheet.save(fresh(root/'13 NHAN CHU NGUON PHONG8LAN KHONG DUNG MOI.png'))
out=dict(read_only=True,source_original_image='X7 JPEG',not_new_catalogue_sample=True,new_vector_glyph_written=False,new_font_bank_written=False,
         source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),
         labels=results,component_count_matching_does_not_prove_complete_letters=True,
         contour_font_feasibility_not_yet_accepted=True,PDF_written=False,common_progress_written=False)
Path(fresh(root/'DOC THUC 13 NHAN KHONG EP TACH KY TU.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
for r in results:print(r['literal'],'expected',r['expected_count'],'counts',[a['component_count_without_forced_split_or_merge'] for a in r['analysis']],flush=True)
E.close()
