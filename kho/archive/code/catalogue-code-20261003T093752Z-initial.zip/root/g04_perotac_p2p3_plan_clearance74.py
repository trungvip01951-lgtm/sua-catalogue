"""Check proposed legend clearance on original complete pages, read only."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from PIL import Image, ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_whole_pdf_tools46 import read, sha
import json, numpy as np

NAME='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN TOAN BIEU DO TRANG02 VA03 CHI DOC'))
oldpath=base/'TOAN MIEN161 O BANG VA VACH THUC V2 CHI DOC/PHUONG AN7 QH91 O VA7 QH70 O CUC BO NGUON CHI DOC.json'
doc=read(oldpath);root=base/'TOAN MIEN161 O VA KHOANG CHU GIAI V3 CHI DOC'
E=Editor(S.src(NAME),backend='fitz');R=Raster(E)
for record in doc['records']:
    pi=record['page']-1;im=max(R.images(pi),key=lambda z:z.W*z.H);cv=R.canvas(im);raw=cv.orig
    if record['family']=='3SS3':
        oldbox=record['legend_space_proposal_native'];legend=[1368,586,1679,634]
        columns=2;rows=4;baseline=[594,606,618,630]
        protected=[962,640,1695,888]
        roi=[1333,143,1705,636]
        correction='Prior proposed y620..710 overlapped other 3SS2 table. Rejected before any drawing; new 2x4 legend is wholly above that table.'
    else:
        oldbox=record['legend_space_proposal_native'];legend=[124,745,746,801]
        columns=3;rows=3;baseline=[757,773,789]
        protected=[58,916,795,1167]
        roi=[65,132,790,805]
        correction='Use clean own chart lower whitespace; whole own performance heading/table stays below proposed ROI.'
    x0,y0,x1,y1=legend;part=raw[y0:y1,x0:x1]
    contrast=(255-part.mean(2))/255
    record.update(legend_space_proposal_native=legend,legend_columns=columns,legend_rows=rows,
        legend_baseline_native_proposal=baseline,legend_blank_source_RGB_min=int(part.min()),
        legend_source_nonwhite_pixel_count=int(np.any(part!=255,axis=2).sum()),
        legend_source_dark_pixel_count=int((part.min(2)<235).sum()),legend_source_max_contrast=float(contrast.max()),
        nearby_table_or_heading_protected_native_box=protected,
        legend_min_gap_to_protected_table_or_heading_native_px=protected[1]-legend[3],
        whole_chart_ROI_NATIVE_PROPOSAL_ONLY=roi,previous_space_proposal_rejected=oldbox,
        source_complete_page_clearance_note=correction,
        own_source_adjacent_axes_and_caption_halo_final_ROI_review_pending=True,
        legend_and_ROI_are_NOT_drawn_or_accepted=True)
    crop=[max(0,roi[0]-50),max(0,roi[1]-10),min(raw.shape[1],roi[2]+20),min(raw.shape[0],protected[1]+30)]
    c=raw[crop[1]:crop[3],crop[0]:crop[2]].copy();img=Image.fromarray(c).resize((c.shape[1]*2,c.shape[0]*2),Image.Resampling.NEAREST)
    draw=ImageDraw.Draw(img)
    for b,color,text in [(roi,'blue','PROPOSED WHOLE CHART ROI'),(legend,'green','PROPOSED LEGEND WHITESPACE'),(protected,'red','PROTECTED TABLE/HEADING')]:
        bb=[(b[0]-crop[0])*2,(b[1]-crop[1])*2,(b[2]-crop[0])*2,(b[3]-crop[1])*2]
        draw.rectangle(bb,outline=color,width=2);draw.text((bb[0]+4,bb[1]+4),text,fill=color)
    p=Path(fresh(root/(record['family']+' KHOANG TRANG CHU GIAI VA BANG KHONG SUA.png')));img.save(p)
    record['legend_clearance_source_image']=dict(path=str(p),sha256=sha(p))
    print(record['family'],'LEGEND',legend,'SOURCE DARK',record['legend_source_dark_pixel_count'],'MIN_RGB',record['legend_blank_source_RGB_min'],'GAP',record['legend_min_gap_to_protected_table_or_heading_native_px'],flush=True)
doc.update(previous_plan_path=str(oldpath),previous_plan_sha256=sha(oldpath),
    proposed_whole_chart_ROI_not_authorized_or_cut=True,full_source_page_visual_clearance_performed=True,
    source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)))
p=Path(fresh(root/'PHUONG AN161 O VA CHU GIAI KHONG CHAM BANG V3 CHI DOC.json'));p.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
m=Path(fresh(root/'DOC RO GIOI HAN CHU GIAI TRANG02 VA03 V3.md'))
m.write_text('''# Phương án trang 2–3 V3 — chỉ đọc

161 ô H và 14 tên máy giữ nguyên bản đọc V2. Đã xem lại toàn trang nguồn trước khi khóa vị trí chú giải.

Trang 2: vùng chú giải y620–710 của đề xuất V2 đè bảng 3SS2 khác, nên loại trước khi vẽ. Đề xuất mới x1368–1679, y586–634, 2 cột × 4 hàng, đường cơ sở y594/606/618/630. Toàn vùng này không có mực chữ/đường nguồn; mép dưới cách bảng 3SS2 thật ở y640 là 6 pixel nguồn. Vùng biểu đồ dự kiến x1333–1705, y143–636; còn phải kiểm sát trục phải 3SS2 cạnh bên, không dùng hộp ảnh chụp x1300 làm phạm vi xóa.

Trang 3: đề xuất x124–746, y745–801, 3 cột × 3 hàng, dưới trục lưu lượng thật và trên tiêu đề/bảng của chính 3SS4. Vùng biểu đồ dự kiến x65–790, y132–805; cách tiêu đề bảng ở y916 là 111 pixel nguồn.

Chưa dựng RAM/PDF. Độ dày/màu/nhịp đứt, bộ chữ riêng và η của mỗi trang chưa khóa; không chuyển chữ số 4 hoặc η trang 8 sang đây. Phải đối chiếu bộ chữ ít nhất hai ký tự cùng phép biến đổi nếu muốn dùng lại. Chú giải/ROI (phạm vi cắt) vẫn là phương án chờ ROOT kiểm.
''',encoding='utf8')
print('PLANV3',p,'SHA256',sha(p),flush=True)
E.close()
