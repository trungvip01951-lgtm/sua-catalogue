"""Học đường bao ký tự sạch trong chínhtệp; không tạo/chuyển font.
Mặt nạ dùng silhouetteglyphsạch; RGB giữ nguyên từng chữ thật ở đích.
"""
from catwork import start,fresh,HERE
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
import numpy as np,json
O='G05/6SP30 HAI MUOI CHIN MOC/MAT NA CHU TU GLYPH SACH/'
I='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
d=json.loads(Path(S.report(I+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'));E=Editor(d['source_path']);R=Raster(E);cv=R.canvas(R.images(4)[0]);a=cv.orig
specs=[('6SP30-42',(1135,245,1183,253),(246,252)),('6SP30-26',(1135,371,1183,380),(372,378)),('6SP30-17',(1135,442,1183,451),(443,450)),('6SP30-35',(1135,301,1183,309),(302,307)),('6SP30-38',(1135,276,1183,285),(277,283))]
out=[]
for text,box,body in specs:
 cs=R.components(cv,box,expect=len(text),bg=np.array([255,255,255]),ink=np.array([0,0,0]),thr=.22,band=False,remove_lines=False);assert len(cs)==len(text)
 parts=[]
 for ch,c in zip(text,cs):
  x0,y0,x1,y1=c['box'];alpha=c['alpha'];mask=alpha>.10
  # Only the actual source glyphbody is used; the margin may contain a curve.
  ys=np.arange(y0,y1);mask&=(ys[:,None]>=body[0])&(ys[:,None]<=body[1])
  parts.append(dict(char=ch,box=list(c['box']),alpha=alpha.tolist(),body_mask=mask.tolist(),raw_RGB=a[y0:y1,x0:x1].tolist(),source_style='Caption6SP30, originalsource1732×1240'))
  Image.fromarray(a[y0:y1,x0:x1]).resize(((x1-x0)*20,(y1-y0)*20),Image.Resampling.NEAREST).save(fresh(S.report(O+'CHU NGUON/'+text+'-'+str(len(parts))+'-'+ch+'.png')))
 print(text,[(p['char'],p['box']) for p in parts],flush=True);out.append(dict(source_text=text,body=body,box=box,parts=parts))
Path(fresh(S.report(O+'GLYPH THAT DE HOC MAT NA.json'))).write_text(json.dumps(dict(source_sha256=d['source_sha256'],current_sha256=d['current_sha256'],source_only=True,raw_RGB_not_to_be_replaced=True,words=out),ensure_ascii=False,indent=2),encoding='utf8');E.close()
