"""Keep original draft B, correct direct-source transcription and unresolved cell."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'))
final=json.loads(Path(S.report('G04/REDPUMP NGHIEM THU BAN CUOI NET PDF.json')).read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
current=S.result(catalog['name'])
assert sha(catalog['source'])==catalog['source_SHA256'] and sha(current)==final['final_SHA256']
old=root/'BANG SO DA DOC TRUC TIEP B.json'
out=json.loads(old.read_text(encoding='utf8'))
changes=[]
for row in out['rows']:
 for q,new,why in ([(5.4,116,'Ảnh SOI 4SL4 CAC HANG CAO.png đọc116; bản nháp118 là lỗi nhập')] if row['model']=='4SL4/36' else [(3.6,308,'Ảnh SOI 4SL4 CAC HANG CAO.png đọc308; bản nháp306 là lỗi nhập')] if row['model']=='4SL4/56' else [(3.0,None,'Ảnh nén khó phân biệt76/78, chờ đọc độc lập; không dùng78 của bản nháp')] if row['model']=='4SL3/15' else []):
  i=row['Q'].index(q)
  changes.append(dict(model=row['model'],Q=q,old=row['H'][i],new=new,reason=why))
  row['H'][i]=new
 row['table_read']='Đọc số trực tiếp trên ảnh nguồn riêng Redpump; bản nháp B không dùng để đo/vẽ. Hai lỗi nhập đã sửa trong B V2, ô chưa chắc để null.'
 row['ambiguous_cells']=[dict(Q=row['Q'][i],result='CHƯA THỂ',candidates=[76,78],reason='Chữ số nguồn JPEG chưa đọc chắc ở các ảnh cắt') for i,h in enumerate(row['H']) if h is None]
 row['curve_acceptance']='CHƯA ĐO'
out.update(batch='B V2',current_SHA256=sha(current),supersedes_draft=str(old),supersedes_draft_SHA256=sha(old),changes_from_draft=changes,H_cells_read=sum(h is not None for row in out['rows'] for h in row['H']),catalogue_written=False,curve_numeric_acceptance=False)
Path(fresh(root/'BANG SO DA DOC TRUC TIEP B V2.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert sha(catalog['source'])==catalog['source_SHA256'] and sha(current)==final['final_SHA256']
print('Redpump B V2',out['model_rows'],'rows',out['H_cells_read'],'read',out['H_cells']-out['H_cells_read'],'unknown; PDFs unchanged',flush=True)
