"""ROOT giải ba mốc nhiễu màu bằng nét liên thông nguồn; giữ một mốc bị che."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,csv,numpy as np
from scipy.ndimage import label
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G06/KIEM DUONG DOC LAP ROOT V2'));base=json.loads((root/'NGHIEM THU QH ROOT.json').read_text(encoding='utf8'))
name='Aquaris FS_300dpi_75% (bản mới).pdf';source=S.src(name);final=S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source)==base['source_sha'] and sha(final)==base['final_sha']
E=Editor(source,backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(1),key=lambda z:z.W*z.H));a=cv.orig.astype(float)
page=base['pages'][0];xs=page['vertical_rules_native'];ys=page['horizontal_rules_native_top_down'];uu=np.arange(int(round(xs[0]))-2,int(round(xs[-1]))+3);vv=np.arange(int(round(ys[0]))-2,int(round(ys[-1]))+3);yfit=np.array(page['yfit_pixel'])
ar=a[np.ix_(vv,uu)];con=255-ar;resolved=[]
for ident in page['identities']:
    model=ident['model']
    if model not in ('FS-50-7-3.0','FS-50-10-4.0'):continue
    target=255-np.array(ident['legend_actual_RGB']);n=np.linalg.norm(target)
    cosine=(con@target)/(np.maximum(np.linalg.norm(con,axis=2),1)*n);alpha=(con@target)/(n*n)
    mask=(cosine>.982)&(alpha>.15)&(ar.max(2)-ar.min(2)>30)
    labels,count=label(mask,np.ones((3,3)));sizes=np.bincount(labels.ravel());sizes[0]=0;order=np.argsort(sizes)[::-1]
    assert sizes[order[0]]>10000 and sizes[order[1]]<100
    m=labels==order[0]
    for q in ([20] if model=='FS-50-7-3.0' else [0,20]):
        row=next(z for z in base['points'] if z['model']==model and z['Q']==q)
        assert row['result']=='CHƯA THỂ XÁC MINH'
        x=xs[q//20];cols=np.where(abs(uu-int(round(x)))<=2)[0];present=m[:,cols];rr=np.where(present.any(1))[0];assert len(rr)>5
        weight=(alpha[rr][:,cols]*present[rr]).sum(1);y=float(np.average(vv[rr],weights=weight))
        h=float((y-yfit[1])/yfit[0]);interval=sorted([float((vv[rr.min()]-1-yfit[1])/yfit[0]),float((vv[rr.max()]+1-yfit[1])/yfit[0])]);upper=max(abs(t-row['H_table']) for t in interval);assert upper<=row['tolerance']
        updated=dict(row,H_actual=h,error=h-row['H_table'],result='ĐẠT',source_ink_interval_H=interval,max_possible_error=upper,native_x_center=int(round(x)),native_y_ink_center=y,method='Đọc đúng nét liên thông mang màu chú giải, đã ROOT soi ảnh toàn nét; loại các mảnh nhiễu JPEG rời có tối đa35pixel, không chọn cụm theo H bảng',component_pixels=int(sizes[order[0]]),largest_other_component_pixels=int(sizes[order[1]]))
        updated.pop('reason',None);base['points'][base['points'].index(row)]=updated;resolved.append(updated)
E.close();base['counts']={k:sum(z['result']==k for z in base['points']) for k in ('ĐẠT','CHƯA ĐẠT','CHƯA THỂ XÁC MINH')}
assert base['counts']=={'ĐẠT':36,'CHƯA ĐẠT':0,'CHƯA THỂ XÁC MINH':1}
remaining=next(z for z in base['points'] if z['result']=='CHƯA THỂ XÁC MINH')
assert remaining['model']=='FS-50-7-3.0' and remaining['Q']==0
remaining['reason']='Nét hồng ở đầu Q0 bị nét xanh lam nhạt FS-35-7-2.2 che/chồng; nét hồng tách riêng chỉ nhìn được từ gần Q1.9. Không ngoại suy về0 để nhận ĐẠT.'
base['resolved_by_source_component']=resolved;base['component_visual_review']='ROOT đã soi hai ảnh toàn nét liên thông từ đúng điểm ảnh nguồn; nét xanh đậm bắt đầuH20, nét hồng tách khỏi nét xanh lam nhạt; các mảnh JPEG ở mốc20 không phải đường chính.'
base['previous_evidence']=str(root/'NGHIEM THU QH ROOT.json');base['source_and_final_unchanged_after']=sha(source)==base['source_sha'] and sha(final)==base['final_sha']
folder=Path(S.report('G06/KIEM DUONG DOC LAP ROOT V3'))
Path(fresh(folder/'NGHIEM THU QH ROOT.json')).write_text(json.dumps(base,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(folder/'37 MOC DOC LAP ROOT.csv'),'w',encoding='utf-8-sig',newline='') as fp:
    fields=list(dict.fromkeys(k for z in base['points'] for k in z));w=csv.DictWriter(fp,fields);w.writeheader();w.writerows(base['points'])
lines=['# G06 – nghiệm thu bổ sung đường đặc tính độc lập','','Kết luận: 36/37 mốc bảng đọc được ĐẠT; 1 mốc bị chồng nét CHƯA THỂ XÁC MINH. Không phát hiện mốc lệch chắc trong 36 mốc đã đo. Không sửa PDF.','','| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|','| Bổ sung theo toàn quyền | Aquaris FS_300dpi_75% (bản mới).pdf | 2–3 | 7 đường ảnh gốc, chưa đo đủ | Giữ nguyên | Đọc37ô số thật,7tên/chú giải màu, lưới riêng; đo tâm và khoảng mực bằng điểm ảnh nguồn300dpi | 36ĐẠT; 1CHƯA THỂ | NGHIEM THU QH ROOT.json;37 MOC DOC LAP ROOT.csv; ảnh bảng/chú giải V2 |','| Mốc bị chồng | Cùng tệp | 2 | FS-50-7-3.0, Q0, H17m | Giữ nguyên | Không ngoại suy phần hồng từQ≈1.9 về0 qua nét xanh đang che | CHƯA THỂ XÁC MINH | Ảnh toàn nét hồng V2; dữ liệu thành phần mực |','','Bảng/7mã/chú giải được ROOT đọc trực tiếp trong ảnh gốc. Ba điểm nghi ngờ do nhiễu màu đã được tách bằng nét liên thông, 15.552/18.111 điểm ảnh, trong khi các mảnh nhiễu rời chỉ tối đa35 điểm ảnh; ROOT đã soi cả hai nét. Không chọn đường dựa độ gần số bảng hoặc thứ hạng.','','Ảnh toàn trang2/3 bản giao giống mọi điểm ảnh nguồn ở300điểm ảnh/inch. Mã kiểm nội dung nguồn và bản giao giữ nguyên. Các ô H trống, đoạn sau điểm bảng cuối hoặc đầu bị che không nhận đã xác minh.','','G06 còn mục52 thiếu chữ k đúng kiểu. Mục51 sửaĐẠT; mục53 giữnguồn đúng điều kiện “không đẹp thì giữ nguyên”. Không coi toàn nhóm đã xong.','','Q là lưu lượng, m³/h là mét khối/giờ; H là cột áp tính bằng mét. JPEG là định dạng ảnh nén; PDF là định dạng tài liệu.','']
Path(fresh(S.report('BAO CAO G06 BO SUNG DUONG DOC LAP ROOT.md'))).write_text('\n'.join(lines),encoding='utf8')
S.progress('G06','CHƯA XONG','Bổ sung7đường: 36/37mốcQH ĐẠT, 1mốcQ0 củaFS-50-7-3.0 bịnétxanhche CHƯA THỂ, khôngngoạisuy. ROOTđọc37ô/tên/chúgiải vànguồn300dpi, loại3nhiễumàubằngnétliênthông. Không sửaPDF; nguồn/bản giao nguyênSHA. #52vẫnthiếuk, #53giữnguồn theođiềukiện. BAO CAO G06 BO SUNG DUONG DOC LAP ROOT.md.')
print('G06 ROOT final knownanchors',base['counts'],'largestHerror',max(abs(z['error']) for z in base['points'] if z['error'] is not None),flush=True)
