"""Đọc OCR/crop nguồn từng nhãn cao, không vẽ đường sửa."""
from catwork import start, fresh, HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.interpolate import PchipInterpolator
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
O='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
d=json.loads(Path(S.report(O+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'));E=Editor(d['source_path']);R=Raster(E);cv=R.canvas(R.images(4)[0]);a=cv.orig
b=d['axis'];xt=np.array(b['xticks']);yt=np.array(b['yticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]));nx=lambda x:float(cv.to_px(x,b['y0'])[0]);ny=lambda y:float(cv.to_px(b['x0'],y)[1]);out=[]
for z in d['models']:
 if int(z['model'].rsplit('-',1)[1])<10:continue
 bx=z['native_label_box'];hits=R.find(cv,z['model'],box=bx,scale=4,psm=7)
 ws=R.ocr(cv,box=bx,scale=4,psm=7)
 print(z['model'],hits,ws,flush=True)
 rec=dict(model=z['model'],crop_native=bx,hits=hits,words=ws,automatic_bbox_not_final_accepted=True)
 out.append(rec)
Path(fresh(S.report(O+'OCR KHUNG NHAN CAO - CAN SOI.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda v:int(v)),encoding='utf8');E.close()
