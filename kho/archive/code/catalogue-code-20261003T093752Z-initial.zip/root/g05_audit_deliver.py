"""Giao đúng bản mẫu G05 đã đượcROOTnghiệm thu; nguồn bất biến.
prepare chỉ lập hồ sơguard; PowerShellMove-Item lưu phiên cũ; finish ghiPDFbằngcatfix.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
from catfix.recipes import Job
from catfix.cs import Ref
from catfix import verify
import pymupdf as fitz,numpy as np

mode=sys.argv[1]
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
O='G05/GIAO BAN SAU SUA DUONG/'
primary=Path(S.dst(name));source=Path(S.src(name));trial=Path(S.report('G05/MAU PDF SUA DUONG/'+name))
oldsha='10d7d99e2873693fa3913b95185422a038d761903193bd544937b1dce45c8c0c'
sourcesha='e1b94dc6f23c35d18d61cee71d9d88c844b1070d14ff662bbabe2256cdd690c9'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
outdir=Path(S.out_dir).resolve();primary_abs=primary.resolve()
assert primary_abs.is_relative_to(outdir) and primary_abs!=source.resolve()
assert source.resolve().parent.parent!=outdir
audit_path=S.report('G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO/NGHIEM THU QH PDF MAU.json')
audit=json.loads(Path(audit_path).read_text(encoding='utf8'))
actual=json.loads(Path(S.report('G05/MAU PDF SUA DUONG/DOC LAI DUONG THAT VA BAO TOAN.json')).read_text(encoding='utf8'))
assert audit['point_count']==2218 and audit['curve_count']==220 and audit['actual_vector_confidence_counts']['ĐẠT']==52
assert sha(trial)==audit['trial_sha256']==actual['trial_sha256'] and sha(source)==sourcesha
rootproof=S.report('G05/NGHIEM THU MAU DOC LAP ROOT.json');assert Path(rootproof).is_file()
archive=Path(S.report('G05/PHIEN TRUOC/'+oldsha+'/'+str(primary_abs.relative_to(outdir))))
archive_abs=archive.resolve();assert archive_abs.is_relative_to(outdir/'_BAO CAO')
plan_path=S.report(O+'KE HOACH LUU PHIEN CU - SHA GUARD.json')
if mode=='prepare':
 assert sha(primary)==oldsha and not archive.exists()
 archive.parent.mkdir(parents=True,exist_ok=True)
 plan=dict(primary=str(primary_abs),archive=str(archive_abs),old_primary_sha256=oldsha,source=str(source.resolve()),source_sha256=sourcesha,trial=str(trial.resolve()),trial_sha256=sha(trial),output_root=str(outdir),approval='ROOT đã đọc độc lập26paths/52mốc; chấpnhận52đuôimốc vàmodelrow20→28. NgoạilệdàynétSP30-38 ghiđầyđủ, giữCHƯAXONGtoànnhóm.',root_proof=str(Path(rootproof).resolve()))
 Path(fresh(plan_path)).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
 print('ARCHIVE_PLAN',plan_path,flush=True);print('old primary exists; archive path fresh; source unchanged',flush=True)
elif mode=='finish':
 plan=json.loads(Path(plan_path).read_text(encoding='utf8'))
 assert not primary.exists() and archive.exists() and sha(archive)==oldsha
 assert str(primary_abs)==plan['primary'] and str(archive_abs)==plan['archive'] and sha(trial)==plan['trial_sha256']
 j=Job(str(trial),fresh(str(primary)),backend='fitz',log_path=fresh(S.report(O+'NHAT KY GHI PDF FINAL.json')))
 d=fitz.open(source);xr=d.xref_xml_metadata();raw=d.xref_stream(xr) if xr else None;d.close()
 if raw is not None:
  target_xr=j.E.doc.doc.xref_xml_metadata();assert target_xr;j.E.doc.set_stream(Ref(target_xr,0),raw)
 j.save();ck=j.check(raster=True);assert ck['ok'],ck;j.close()
 equality=verify.outside_pixels(str(trial),str(primary),{},dpi=200,thr=0,min_size=0,pad=0);assert not equality,equality
 panels=json.loads(Path(S.report('G05/MAU SUA DUONG/PHAM VI DA BO NET CHUA RO 2/TOA DO VA PHUONG PHAP.json')).read_text(encoding='utf8'))['panels']
 panelproof=[]
 for p in panels:
  a=np.asarray(verify.crop(str(trial),p['page']-1,p['rect'],600));b=np.asarray(verify.crop(str(primary),p['page']-1,p['rect'],600));same=bool(np.array_equal(a,b));assert same
  verify.crop(str(primary),p['page']-1,p['rect'],600).save(fresh(S.report(O+p['family']+'-FINAL-DOC-LAI.png')))
  verify.page_overview(str(archive),str(primary),p['page']-1,fresh(S.report(O+'So sanh trang '+str(p['page'])+'.png')),dpi=120)
  panelproof.append(dict(family=p['family'],page=p['page'],all_final_sample_pixels_identical_600dpi=same))
 assert sha(source)==sourcesha and sha(archive)==oldsha
 tables=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/BANG DAY DU.json')).read_text(encoding='utf8'))
 tableproof=[]
 for t in tables:
  a=np.asarray(verify.crop(str(trial),t['page']-1,t['rect'],450));b=np.asarray(verify.crop(str(primary),t['page']-1,t['rect'],450));same=bool(np.array_equal(a,b));assert same,(t['family'],'table mismatch final/sample')
  tableproof.append(dict(family=t['family'],page=t['page'],all_final_sample_table_pixels_identical450dpi=same))
 finalproof=dict(final=str(primary_abs),final_sha256=sha(primary),source_sha256=sha(source),archived_old_primary=str(archive_abs),archived_sha256=sha(archive),approved_sample=str(trial.resolve()),approved_sample_sha256=sha(trial),catfix_check=ck,whole_pdf_pixels_equal_to_approved_sample200dpi=equality,panels600dpi=panelproof,tables450dpi=tableproof,all2218_QH_audit=audit_path,audit_summary=audit['overall_counts'],new_points52_confidence=audit['actual_vector_confidence_counts'],metadata_raw_xmp_restored=raw is not None,root_independent_approval_proof=rootproof,group_status='CHƯA XONG',notes='6/6việcchữ/số đãđạt;52mốcmới đạt;31mốclệchthật và1074chưathể củaphạmviđo220đườngkhôngđược coiđãđạt.')
 Path(fresh(S.report(O+'NGHIEM THU PDF GIAO.json'))).write_text(json.dumps(finalproof,ensure_ascii=False,indent=2),encoding='utf8')
 S.progress('G05','CHƯA XONG','6/6 CAN SUA chữ/số đãĐẠT; giao bản bổsung26đuôi52mốcĐẠT+modelrow20→28, ROOTkiểmđộclập. Toàn220đường/2218mốc:1113ĐẠT/31CHƯAĐẠT/1074CHƯATHỂ;sourceSHAkhôngđổi;rawXMP/ảnh/font/12trang/ngoàivùnggiữ. XemG05/GIAO BAN SAU SUA DUONG/NGHIEM THU PDF GIAO.json vàkiểmtoánPDFmẫu.')
 print('DELIVERED',str(primary_abs),'SHA',sha(primary),'source unchanged; old SHA archive',oldsha,'counts',audit['overall_counts'],flush=True)
else:raise ValueError(mode)
