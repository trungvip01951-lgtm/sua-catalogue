"""Prepare continuous physical Bezier geometry/dash arc plan; no PDF/sample written."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.integrate import quad
from catfix.charts import Chart
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));p=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17 V2.json').read_text(encoding='utf8'));d=json.loads((root/'104 NEO QH ANH XA VACH THUC CUC BO V1.json').read_text(encoding='utf8'));sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(p['method']['source']),sha(p['method']['input_current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
ch=Chart(1.,0.,1.,0.);records=[];cyc=6.95+3.41
for row in d['records']:
 anchors=[z['page_xy'] for z in row['anchors']];path=ch.smooth_path([tuple(a) for a in anchors],method='pchip');assert len(path)==8 and path[0][0]=='m' and all(a[0]=='c' for a in path[1:]);cur=np.array(anchors[0]);segs=[]
 for i,(op,pts) in enumerate(path[1:]):
  cp=np.vstack([cur,np.array(pts)]);assert np.max(np.abs(cp[-1]-anchors[i+1]))<1e-8
  def velocity(t):return 3*(1-t)**2*(cp[1]-cp[0])+6*t*(1-t)*(cp[2]-cp[1])+3*t*t*(cp[3]-cp[2])
  arc,err=quad(lambda t:float(np.linalg.norm(velocity(t))),0,1,epsabs=1e-9,epsrel=1e-9);segs.append(dict(Bezier_page=cp.tolist(),Q_interval=[row['anchors'][i]['Q'],row['anchors'][i+1]['Q']],arc_pt=arc,arc_numeric_error_pt=err));cur=cp[-1]
 before6=sum(z['arc_pt'] for z in segs[:2]);v1=3*(np.array(segs[1]['Bezier_page'])[3]-np.array(segs[1]['Bezier_page'])[2]);v2=3*(np.array(segs[2]['Bezier_page'])[1]-np.array(segs[2]['Bezier_page'])[0]);angle=abs(float(np.arctan2(v1[1],v1[0])-np.arctan2(v2[1],v2[0])))*180/np.pi
 records.append(dict(model=row['model'],source_anchors=row['anchors'],planned_path=[dict(op=op,points=list(map(list,pts))) for op,pts in path],planned_dashed_path_first_two_cubics=True,planned_solid_path_last_five_cubics=True,source_interpolation_computed_once_for_entire_curve=True,split_at_Q6_anchor_index=2,split_page=anchors[2],split_tangent_angle_deg=angle,split_position_error_pt=0.,segments=segs,dash=[6.95,3.41],phase0=True,arc_Q0_to_Q6_pt=before6,arc_phase_Q6_pt=float(before6%cyc),Q6_inside_dash_ink_by_arc=(before6%cyc)<6.95,phase_not_shifted_to_force_anchor_ink=True,style=dict(RGB=[134,149,152],width_pt=.95,cap=0,join=1,opacity=1),source_input_SHA256=before[1],planned_ink_clip_x_domain=[anchors[0][0],anchors[-1][0]],numeric_plan_only=True,actual_PDF_verified=False))
assert max(z['split_tangent_angle_deg'] for z in records)<1e-6
out=dict(source_SHA256=before[0],current_SHA256=before[1],models=13,H_anchors=104,records=records,PDF_sample_written=False,actual_PDF_verified=False,status='HÌNH HỌC KẾ HOẠCH: chưa phải path đọc từ PDF. Chỉ sau mẫu mới nghiệm thu actual PDF/ảnh.',join_policy='Tính PCHIP cả đường một lần rồi tách tại neoQ6. Không tính lại hai nội suy riêng gây đổi tiếp tuyến; không vẽ nét đứt dưới nét liền làm đậm cạnh kép.',writer_op_count_note='Mỗi model cần2lệnhstroke theo kiểu dash/liền, tổng26lệnhQH nhưng chỉ13đườnghìnhhọc. Khi kiểmPDF phải ghép đúng2miền của model, không gọi26lệnhlà26model.',ink_end_policy='MọiQH dùngclip theo đúng miềnQ0…21 khi vẽ mực, tránh bề rộng bút lấn quáQ cuối. Các điểm/chấm chú giải chỉ ở ảnh báo cáo, không có trong PDF.',catalogue_written=False)
Path(fresh(root/'13 DUONG BEZIER CUC BO VA CHIEU DAI CUNG KE HOACH.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert before==[sha(p['method']['source']),sha(p['method']['input_current'])];print('PLAN only13Bezier/104nodes; noPDF. tangent max',max(z['split_tangent_angle_deg'] for z in records),'Q6 arc phases',[(z['model'],round(z['arc_phase_Q6_pt'],6)) for z in records],flush=True)
