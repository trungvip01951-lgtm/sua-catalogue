from catwork import start
S,D,N=start()
from collections import Counter
from catfix.vector import overlap
j=S.job('KTZ - LH Perotac (bản mới).pdf')
for pi,r in [(2,(77,358,524,522)),(3,(65,560,510,723)),(6,(77,530,270,719))]:
    P=j.E.page(pi);cand=[]
    for oi,o in enumerate(P.objs):
        if overlap(o['bbox'],r)<=0:continue
        c=P.color_of(oi,'stroke') if o['op']=='S' else P.color_of(oi,'fill')
        if not c or not (c[0]>.75 and c[1]<.4 and c[2]<.4):continue
        cand.append((oi,o['op'],c,o['bbox'],o['lw'],len(P.object_pagepath(oi))))
    print(pi+1,Counter((op,c) for oi,op,c,bb,lw,num in cand),flush=True)
    print(cand[:35],flush=True)
j.close()
