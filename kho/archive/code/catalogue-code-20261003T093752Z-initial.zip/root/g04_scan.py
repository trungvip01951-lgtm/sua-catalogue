from catwork import start, fresh
from pathlib import Path
import sys, json
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.verify import crop
descs=json.loads(Path(S.report('G04/duong-dan.json')).read_text(encoding='utf-8'))
which=int(sys.argv[1]) if len(sys.argv)>1 else 0
pages=[int(s)-1 for s in sys.argv[2:]] or list(range(11))
d=descs[which];E=Editor(d['src']);R=Raster(E)
for pi in pages:
    im=R.images(pi)[0]
    if im.has_stencil_mask:
        cv=R.render_canvas(pi,(0,0,d['width'],d['height']),dpi=150)
    else:cv=R.canvas(im)
    words=R.ocr(cv)
    for w in words:w['rect']=cv.rect(w['box'])
    path=Path(S.report(f'G04/OCR/{which}-{pi+1}.json'))
    if not path.exists():path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(words,ensure_ascii=False,indent=2),encoding='utf-8')
    path=Path(S.report(f'G04/NGUON/{which}-page{pi+1}.png'))
    if not path.exists():crop(d['src'],pi,(0,0,d['width'],d['height']),120).save(path)
    print(d['short'],'trang',pi+1,'từ',len(words),flush=True)
E.close()
