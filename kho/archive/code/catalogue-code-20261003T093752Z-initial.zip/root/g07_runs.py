from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from pathlib import Path
import json
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf';root=Path(S.report('G07'))
E=Editor(S.src(NAME));TL=TextLayer(E);P=E.page(0)
out=[]
for r in TL.runs(0):
    if r.glyphs and r.glyphs[0].o[0]<640 and any(abs(r.glyphs[0].o[1]-v)<1 for v in [496.632,487.789,461.263,381.959,372.736,391.181,337.736,303.794,222.551,213.769,79.278,148.608]):
        prevTm=[i for i in range(r.index) if str(P.ops[i].op)=='Tm'][-1]
        cb=[g.cb.hex() for g in r.glyphs if g.ch=='³']
        row=dict(index=r.index,Tmindex=prevTm,text=r.text,x0=r.glyphs[0].o[0],x1=r.glyphs[-1].e[0],y=r.glyphs[0].o[1],
                 font=r.font.basefont,size=r.size_page,tr=r.tr,fill=r.fill,cb3=cb,preceding=[str(x) for x in P.ops[max(0,r.index-3):r.index+1]])
        if cb:
            row['width3']=r.font.width(r.glyphs[0].cb)
            row['glyph_exists_for_raw_code']=r.font.has_glyph(r.glyphs[0].cb)
            fp=r.font._font_program()
            if fp and fp[0]=='tt':
                f=fp[1];row['font_cmaps']=[dict(platform=t.platformID,enc=t.platEncID,subtable=t.cmap.get(179),sup3=t.cmap.get(0xF000+179)) for t in f['cmap'].tables]
        out.append(row);print(row,flush=True)
json.dump(out,open(fresh(root/'runs.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
