"""Read-only source/current design inventory. No PDF change or shared progress write."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
import fitz
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
plan=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
axes=json.loads((root/'17 TRUC DOC NGUON RIENG KHOA V1.json').read_text(encoding='utf8'))
identity=json.loads((root/'DINH DANH NHAN VA SEED DOC TRUC TIEP V1.json').read_text(encoding='utf8'))
cells=json.loads((root/'1931 O NGUON DINH VI VA DOI CHIEU V2.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(d['source']),sha(d['current'])]
assert before==[d['source_SHA256'],d['current_SHA256']]
records=[]
with fitz.open(d['current']) as doc:
 for p in range(len(doc)):
  text=[]
  for b in doc[p].get_text('dict')['blocks']:
   for line in b.get('lines',[]):
    for z in line.get('spans',[]):
     if z['text'].strip():text.append({k:z[k] for k in ['text','font','size','color','bbox','flags']})
  records.append(dict(page=p+1,fonts=doc[p].get_fonts(full=True),native_text=text))
E=Editor(d['current'],backend='fitz');R=Raster(E)
P=E.page(7)
native=[]
for oi,o in enumerate(P.objs):
 if o['op'] in ['S','s']:
  native.append(dict(oi=oi,color=P.color_of(oi,'stroke'),width_user_units=o.get('lw'),ctm=o['ctm'].tolist(),bbox=list(P.object_rect(oi)) if hasattr(P,'object_rect') else None))
for label,rect,dpi in [
 ('TOAN BIEU DO HIEN HANH 300dpi',(37,245,373,521),300),
 ('QH VA NHAN HIEN HANH 600dpi',(57,320,356,510),600),
 ('HIEU SUAT NGUON HIEN HANH 600dpi',(56,268,356,317),600),
 ('NHAN NGUON CHINH TEP 600dpi',(125,348,166,502),600),
 ('TOAN TRANG HIEN HANH 150dpi',(0,0,841.9,598.8),150)]:
 verify.crop(d['current'],7,rect,dpi).save(fresh(plan/(label+'.png')))
E.close()
groups=[]
for a in axes['records']:
 rows=[p for p in d['rows'] if p['family']==a['family'] and p['page']==a['page']]
 ids=[p for p in identity['records'] if p['family']==a['family'] and p['page']==a['page']]
 tab=next(p for p in cells['tables'] if p['family']==a['family'] and p['page']==a['page'])
 groups.append(dict(page=a['page'],family=a['family'],model_count=len(rows),Q=rows[0]['Q'],H_cell_count=sum(len(p['H']) for p in rows),models=[p['model'] for p in rows],identity_locked=sum(p['model_locked'] is not None for p in ids),identity_unknown=[p['table_model_candidate'] for p in ids if p['model_locked'] is None],axis_evidence=a,table_evidence=tab,rows=rows,draw_QH_only_with_printed_H_cells=True,eta_data_status='Không có bảng số hiệu suất; chỉ dựng theo mực nguồn đã quan sát và ghi sai số tái dựng.'))
assert sum(p['model_count'] for p in groups)==196 and sum(p['H_cell_count'] for p in groups)==1931
out=dict(source=d['source'],source_SHA256=d['source_SHA256'],current=d['current'],current_SHA256=d['current_SHA256'],page8_models=[p for p in groups if p['page']==8][0],all_17_groups=groups,native_text_and_fonts=records,page8_native_strokes=native,status='PHƯƠNG ÁN: chưa dựng mẫu hoặc ghi PDF',catalogue_written=False,shared_progress_written=False,total_QH_models=196,total_H_cells=1931,total_source_label_unknown=sum(len(p['identity_unknown']) for p in groups),glyph_rule='Chỉ dùng chữ/nét thật trong CHÍNH Redpump. Font vector dùng khi chứng minh đúng họ/cỡ/nét của nhãn; nếu không thì alpha các cụm chữ nguồn cùng tệp. Không thay phông cho nét ảnh khi chưa chứng minh.',old_tail_sample2_status='Số đo đạt riêng nhưng CHƯA ĐẠT yêu cầu đồ họa đồng bộ mới; giữ riêng, không đưa bản giao.')
Path(fresh(plan/'KIEM KE NGUON RIENG VA FONT 17 BIEU DO.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert before==[sha(d['source']),sha(d['current'])]
print('196 QH models /1931 H; p8 QH',out['page8_models']['model_count'],'font records',[(z['page'],len(z['native_text'])) for z in records],flush=True)
print('p8 native text',records[7]['native_text'],flush=True)
