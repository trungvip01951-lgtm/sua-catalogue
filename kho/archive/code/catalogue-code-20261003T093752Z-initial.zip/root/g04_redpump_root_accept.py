"""ROOT: đọc độc lập mẫu Redpump đã lưu, không ghi PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,csv,numpy as np
import pymupdf as fitz,pikepdf
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify

root=Path(S.report('G04/REDPUMP MAU NET PDF2'))
b=json.loads((root/'TAO VA KIEM MAU.json').read_text(encoding='utf8'))
name='Redpump gieng SL_compressed (bản mới).pdf'
src=S.src(name);cur=S.result(name);trial=b['trial']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==b['source_sha'] and sha(cur)==b['current_sha'] and sha(trial)==b['trial_sha']
manual={'4SL16/23':[136,133,127,115,101,86,69,50], '4SL16/18':[107,104,99,90,79,67,54,39]}
Q=[0,3,6,9,12,15,18,21]
ax,bx,ay,by=b['axis']
E=Editor(trial,backend='fitz');P=E.page(7)
def bez(seg,t):
    if len(seg)==2:return (1-t)*seg[0]+t*seg[1]
    return (1-t)**3*seg[0]+3*t*(1-t)**2*seg[1]+3*t*t*(1-t)*seg[2]+t**3*seg[3]
def segments(path):
    ans=[];pos=None
    for op,pts in path:
        op=op.upper()
        pts=[np.array(p,float) for p in pts]
        if op=='M':pos=pts[0]
        elif op=='L':ans.append([pos,pts[0]]);pos=pts[0]
        elif op=='C':ans.append([pos,*pts]);pos=pts[-1]
        else:raise AssertionError(op)
    return ans
rows=[];style=[];endpoints=[]
for rec in b['records']:
    model=rec['model'];assert rec['Q']==Q and rec['H']==manual[model]
    want=np.array(rec['RGB'])/255
    objs=[]
    for oi,o in enumerate(P.objs):
        rgb=P.color_of(oi,'stroke')
        if o['op']=='S' and rgb is not None and np.max(abs(np.array(rgb)-want))<1e-7:
            objs.append((oi,o,segments(P.object_pagepath(oi))))
    assert len(objs)==len(rec['native_dash_Q_intervals'])==9
    objs.sort(key=lambda z:z[2][0][0][0])
    for (oi,o,segs),(lo,hi) in zip(objs,rec['native_dash_Q_intervals']):
        assert abs(o['lw']-rec['width_pt'])<1e-8
        assert o['dash'] is None or o['dash'][0]==[]
        assert abs((segs[0][0][0]-bx)/ax-lo)<1e-5
        assert abs((segs[-1][-1][0]-bx)/ax-hi)<1e-5
        for seg in segs:
            ts=np.linspace(0,1,201);xy=np.array([bez(seg,t) for t in ts])
            assert np.all(np.diff(xy[:,0])>=-1e-6) and np.all(np.diff(xy[:,1])<=1e-6)
    for q,h in zip(Q,manual[model]):
        x=ax*q+bx;hits=[]
        for oi,o,segs in objs:
            for seg in segs:
                if seg[0][0]-1e-5<=x<=seg[-1][0]+1e-5:
                    lo=0.;hi=1.
                    xx=float(np.clip(x,seg[0][0],seg[-1][0]))
                    for _ in range(65):
                        mid=(lo+hi)/2
                        if bez(seg,mid)[0]<xx:lo=mid
                        else:hi=mid
                    y=bez(seg,(lo+hi)/2)[1];hits.append(float((y-by)/ay))
        assert hits,(model,q,'Không có nét thật ở mốc; không ngoại suy')
        assert max(hits)-min(hits)<1e-4
        actual=float(np.mean(hits));err=actual-h;lim=max(1.,.02*h);assert abs(err)<=lim
        rows.append(dict(model=model,Q=q,H_source_table=h,H_actual_PDF=actual,error_m=err,tolerance_m=lim,result='ĐẠT',method='Giải giao điểm x trên đoạn Bézier thật của PDF bằng chia đôi; không fit lại theo bảng'))
    for which,q,h,xy in [('first',0,manual[model][0],objs[0][2][0][0]),('last',21,manual[model][-1],objs[-1][2][-1][-1])]:
        d=float(np.max(abs(xy-np.array([ax*q+bx,ay*h+by]))));assert d<1e-4
        endpoints.append(dict(model=model,which=which,error_pt=d,xy=xy.tolist()))
    style.append(dict(model=model,objects=[z[0] for z in objs],RGB_actual=objs[0][1]['stroke'],width_actual_pt=objs[0][1]['lw'],source_width_measured_pt=rec['width_pt'],source_dash_intervals=rec['native_dash_Q_intervals']))
E.close()
outside=verify.outside_pixels(cur,trial,{8:[b['allowed_plot']]},dpi=200,thr=0,min_size=0,pad=.4);assert not outside
glyph=[]
for dpi in (150,450,600):
    a=np.asarray(verify.crop(cur,7,(131.5,326,164,499),dpi)).astype(int)
    z=np.asarray(verify.crop(trial,7,(131.5,326,164,499),dpi)).astype(int)
    mask=(a.mean(2)<130)&((a.max(2)-a.min(2))<12)
    changed=int((np.max(abs(a-z),axis=2)[mask]>0).sum());assert changed==0
    glyph.append(dict(dpi=dpi,source_black_glyph_pixels=int(mask.sum()),changed_pixels=changed))
with fitz.open(cur) as a,fitz.open(trial) as z:
    links=lambda d:[[{k:str(v) for k,v in q.items() if k!='xref'} for q in p.get_links()] for p in d]
    protection=dict(info=a.metadata==z.metadata,rawXMP=a.get_xml_metadata()==z.get_xml_metadata(),bookmarks=a.get_toc()==z.get_toc(),links=links(a)==links(z),page_sizes=[tuple(p.rect) for p in a]==[tuple(p.rect) for p in z],fonts=[p.get_fonts(full=True) for p in a]==[p.get_fonts(full=True) for p in z],other_page_content=[a[i].read_contents()==z[i].read_contents() for i in range(11) if i!=7])
assert all(v if not isinstance(v,list) else all(v) for v in protection.values()),protection
imagebytes=[]
with pikepdf.open(cur) as a,pikepdf.open(trial) as z:
    for pi,(pa,pz) in enumerate(zip(a.pages,z.pages)):
        for key,obj in pa.Resources.XObject.items():
            if obj.get('/Subtype')==pikepdf.Name.Image:
                ok=key in pz.Resources.XObject and obj.read_raw_bytes()==pz.Resources.XObject[key].read_raw_bytes()
                assert ok,(pi,str(key));imagebytes.append(dict(page=pi+1,key=str(key),raw_bytes_exact=ok))
Ea=Editor(cur,backend='fitz');Ez=Editor(trial,backend='fitz');Ra=Raster(Ea);Rz=Raster(Ez);matrices=[]
for pi in range(11):
    aa=Ra.images(pi);zz=Rz.images(pi)
    for im in aa:
        candidates=[v for v in zz if str(v.name)==str(im.name)]
        assert len(candidates)==1,(pi,im.name)
        new=candidates[0];same=np.array_equal(im.ctm,new.ctm);assert same
        matrices.append(dict(page=pi+1,name=str(im.name),ctm_exact=same))
Ea.close();Ez.close()
verify.compare_sheet(cur,trial,[(7,b['allowed_plot'],'ROOT: hai đường Redpump theo đúng bảng')],fresh(root/'ROOT SO SANH 150dpi.png'),dpi=150,pad=(.2,.2))
out=dict(source=src,source_sha=sha(src),current=cur,current_sha=sha(cur),trial=trial,trial_sha=sha(trial),points=rows,point_count=len(rows),max_head_error_m=max(abs(r['error_m']) for r in rows),endpoints=endpoints,styles=style,glyphs=glyph,protection=protection,image_raw=imagebytes,image_matrices=matrices,outside=outside,structure=verify.structure_check(cur,trial),source_table_review='ROOT đã soi đúng ảnh nguồn BANG QH.png: 16 số và hai tên model đọc trực tiếp, không chỉ dùng dữ liệu kế hoạch',accepted=False,scope='Hai đường/16 mốc. Nét raster nguồn150dpi có sai số đo độ dày, ảnh/điểm ngoài bảng không tự coi là ĐẠT; còn chờ ROOT soi hình thức ở cỡ toàn trang.')
Path(fresh(root/'NGHIEM THU DOC LAP ROOT.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(root/'16 MOC DOC LAP ROOT.csv'),'w',encoding='utf-8-sig',newline='') as fp:
    w=csv.DictWriter(fp,list(rows[0]));w.writeheader();w.writerows(rows)
print('ROOT Redpump',len(rows),'mốc ĐẠT; maxH',out['max_head_error_m'],'outside',outside,'nguồn và bản giao chưa đổi',flush=True)
