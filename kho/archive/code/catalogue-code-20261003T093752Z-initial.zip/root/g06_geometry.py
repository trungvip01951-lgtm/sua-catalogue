from catwork import start, fresh
S,D,N=start()
from catfix.raster import Raster
from catfix.vector import Editor
from pathlib import Path
import json,numpy as np
NAME='Aquaris FS_300dpi_75% (bản mới).pdf'
root=Path(S.report('G06'));E=Editor(S.src(NAME));R=Raster(E)
cvs=[R.canvas(R.image_at(i,E.mediabox(i))) for i in range(4)]
cv=cvs[3]
grid=[]
for rect in [(287.2,381,420.1,696),(424.5,477,558.0,696)]:
    box=cv.box(rect);a=cv.gray(box);ys=np.where((a<160).mean(axis=1)>.85)[0]
    runs=[]
    for y in ys:
        if runs and y<=runs[-1][-1]+1:runs[-1].append(int(y))
        else:runs.append([int(y)])
    lines=[float(cv.to_page(0,box[1]+np.mean(run))[1]) for run in runs]
    grid.append(dict(rect=rect,lines=lines))
print('Kẻ bảng',grid,flush=True)
standard=[];lines=grid[0]['lines'];right=grid[1]['lines']
for num in range(1,23):
    rect=(311.3,lines[num+1]+.7,419.5,lines[num]-.7)
    words=R.ocr(cv,cv.box(rect),scale=3,psm=7)
    if num not in (5,13,15,18):standard+=words
    print('Hàng',num,rect,' '.join(w['text'] for w in words),flush=True)
for num in range(23,41):
    i=num-22;rect=(447.8,right[i+1]+.7,557.3,right[i]-.7)
    words=R.ocr(cv,cv.box(rect),scale=3,psm=7)
    if num!=28:standard+=words
    print('Hàng',num,rect,' '.join(w['text'] for w in words),flush=True)
bank=R.glyph_bank(cv,words=standard)
print('Chữ chuẩn',sorted(bank['glyphs']),flush=True)
print('Cỡ mẫu chuẩn',[(s['text'],s['size']) for s in bank['samples']],flush=True)
modelsrect=(23,111,102,217)
b2=R.glyph_bank(cvs[1],box=cvs[1].box(modelsrect),psm=6)
print('Số chữ đậm',sorted(b2['glyphs']),[(s['text'],s['size']) for s in b2['samples']],flush=True)
json.dump(dict(grids=grid,standard_words=standard,standard_glyphs=sorted(bank['glyphs']),bold_digit_glyphs=sorted(b2['glyphs'])),
          open(fresh(root/'geometry.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
