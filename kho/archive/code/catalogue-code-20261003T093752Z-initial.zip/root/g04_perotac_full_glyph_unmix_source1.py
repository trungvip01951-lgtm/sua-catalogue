"""Phân tích màu mực chữ/nét bơm trong chính ảnh gốc; không dựng glyph."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from scipy import ndimage
import numpy as np,json,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
measurement=json.loads((root/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'))
E=Editor(src,backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H))
bg=np.array([255.,255.,255.]);font=np.array([57.,55.,57.]);curve=np.array([127.,145.,150.]);basis=np.c_[font-bg,curve-bg];pinv=np.linalg.pinv(basis)
results=[]
for w in measurement['glyph_word_sources']:
    x0,y0,x1,y1=w['original_native_box'];a=cv.orig[y0:y1,x0:x1].astype(float)
    rawcoeff=(a-bg)@pinv.T;alpha=rawcoeff[:,:,0].clip(0,1);beta=rawcoeff[:,:,1].clip(0,1);prediction=bg+rawcoeff@basis.T;resid=np.max(abs(a-prediction),axis=2)
    tries=[]
    for thr in [.40,.50,.60]:
        m=(alpha>=thr);lab,num=ndimage.label(m,structure=np.ones((3,3),int));cc=[]
        for k,sl in enumerate(ndimage.find_objects(lab),1):
            if sl is None:continue
            vv,uu=sl;area=int((lab[sl]==k).sum())
            if area<2:continue
            cc.append(dict(source_box=[x0+uu.start,y0+vv.start,x0+uu.stop,y0+vv.stop],area_px=area,alpha_centroid_confidence=float(np.mean(alpha[sl][lab[sl]==k])),
                           max_RGB_model_residual_median=float(np.median(resid[sl][lab[sl]==k]))))
        cc.sort(key=lambda c:c['source_box'][0]);tries.append(dict(alpha_threshold=thr,components_without_expected_count=len(cc),components=cc,
                                                                  expected_literal_count=len(w['literal']),count_matches=len(cc)==len(w['literal']),
                                                                  matching_count_not_shape_acceptance=True))
    results.append(dict(literal=w['literal'],source_box=w['original_native_box'],analyses=tries,
                        source_curve_and_black_color_unmixing_only=True))
out=dict(source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),
         source_charset_required_for_p8_names='4SA1601235689/',source_caption_7_not_present_and_not_needed=True,
         font_basis_RGB=font.tolist(),curve_basis_RGB=curve.tolist(),color_basis_condition_number=float(np.linalg.cond(basis)),
         read_only=True,source_pixel_color_math_only=True,new_glyph_or_bank_created=False,new_vector_created=False,PDF_created=False,
         coefficients_definition='RGB=white + alphaFont*(font−white) + betaCurve*(curve−white); sourcealphaFont from least squares, no external font.',
         limits='JPEG chỉ150dpi và màu bị biến đổi tại cạnh. Đếm đúngcomponent không chứng minh đúnghình glyph; phải xem nguyên nguồn và đối chứng. Không ép tách/ghép theo8ký tự để báo đạt.',
         words=results,common_progress_written=False)
Path(fresh(root/'DOC MAU CHU DEN TACH NET BOM CHI NGHIEN CUU.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
for w in results:print(w['literal'],'expected',len(w['literal']),'8-connect count',[t['components_without_expected_count'] for t in w['analyses']],flush=True)
print('SOURCE COLOR BASIS CONDITION NUMBER',out['color_basis_condition_number'],flush=True)
E.close()
