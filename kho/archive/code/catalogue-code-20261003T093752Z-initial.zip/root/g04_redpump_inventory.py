"""Read source Redpump only, catalogue never written."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from PIL import Image,ImageDraw
name='Redpump gieng SL_compressed (bản mới).pdf';source=S.src(name);current=S.result(name);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(source),sha(current)]
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));E=Editor(source,backend='fitz');R=Raster(E);records=[];thumbs=[]
for pi in range(E.doc.n_pages):
 rect=(0.,0.,841.9,598.8);im=verify.crop(source,pi,rect,150);im.save(fresh(root/f'NGUON TRANG {pi+1:02}.png'))
 t=im.copy();t.thumbnail((560,400));thumbs.append(t)
 images=[dict(name=str(z.name),W=z.W,H=z.H,ctm=z.ctm.tolist(),bbox=list(z.page_bbox),raw_SHA256=hashlib.sha256(E.doc.stream_raw(z.ref)).hexdigest()) for z in R.images(pi)]
 records.append(dict(page=pi+1,images=images,source_only=True))
sheet=Image.new('RGB',(560*3,420*((len(thumbs)+2)//3)),'white');d=ImageDraw.Draw(sheet)
for i,t in enumerate(thumbs):x=(i%3)*560;y=(i//3)*420;sheet.paste(t,(x,y+20));d.text((x+8,y+3),f'Redpump page {i+1}',fill='black')
sheet.save(fresh(root/'MUC LUC REDPUMP.png'))
assert before==[sha(source),sha(current)];Path(fresh(root/'DINH VI VA NGUON.json')).write_text(json.dumps(dict(name=name,source=source,source_SHA256=before[0],current=current,current_SHA256=before[1],records=records,catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close();print('Redpump inventory 11 source pages; no PDF writes',flush=True)
