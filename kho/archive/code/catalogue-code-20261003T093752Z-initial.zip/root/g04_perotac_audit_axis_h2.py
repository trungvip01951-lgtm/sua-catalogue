from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_axis_h.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
code=code.replace('steps=[5,10,30,20,15,60,50,60,50,50,30,30,25,45,40,50,25]', 'steps=[5,10,30,20,15,60,75,60,50,50,30,30,25,45,40,30,25]')
code=code.replace("fn='TRUC H NGUON '", "fn='TRUC H NGUON LAN2 '")
code=code.replace("' LAN2.png'", "' LAN3.png'")
code=code.replace('TRUC H DOC VA DOI CHIEU.json','TRUC H DOC VA DOI CHIEU LAN2.json')
exec(compile(code,__file__,'exec'))
