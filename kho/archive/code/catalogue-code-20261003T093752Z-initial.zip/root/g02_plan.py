from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor,union
from catfix.otext import OutlineText,Match
from catfix import charts
from g02_glyphs import chart_refs,group_labels
from pathlib import Path
import pickle,json,numpy as np,re,collections
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';E=Editor(S.result(NAME));T=OutlineText(E)
T.__dict__.update(pickle.loads(Path(S.report('G02/glyph-doc-chuan.pkl')).read_bytes()));T.E=E
maps=json.loads(Path(S.report('G02/ban-do-chuan.json')).read_text(encoding='utf-8'))
tables=json.loads(Path(S.report('G01/bang-so-da-nghiem-thu-cho-G02.json')).read_text(encoding='utf-8'))
refs=chart_refs(T);out={};fail=[]
for ps,mp in maps.items():
    p=int(ps)-1;P=E.page(p);coarse=mp['coarse'];b=mp['curve_bbox'];gx,gy=mp['grid']
    hgray=[];vgray=[];alllines=[]
    for oi in P.objects_in(coarse):
        o=P.objs[oi];bb=o['bbox'];col=P.color_of(oi,'stroke')
        if o['op'] not in ['S','s'] or col is None:continue
        horiz=bb[2]-bb[0]>120 and bb[3]-bb[1]<.1
        vert=bb[3]-bb[1]>120 and bb[2]-bb[0]<.1
        if col==(.517578,.525391,.533203):
            if horiz:hgray.append(bb)
            if vert:vgray.append(bb)
        if horiz or vert:alllines.append((oi,bb,horiz,vert))
    assert hgray and vgray,(ps,'no grid')
    def mode_pair(pairs):
        ctr=collections.Counter(tuple(round(float(x),2) for x in z) for z in pairs);key,n=ctr.most_common(1)[0]
        assert n>3,(ps,key,n)
        selected=[z for z in pairs if tuple(round(float(x),2) for x in z)==key]
        return [float(np.median([z[i] for z in selected])) for i in range(2)]
    x0,x1=mode_pair([(r[0],r[2]) for r in hgray]);y0,y1=mode_pair([(r[1],r[3]) for r in vgray]);plot=(x0,y0,x1,y1)
    gx=sorted(set([round(x0,3),round(x1,3)]+[round(float(bb[0]),3) for oi,bb,h,v in alllines if v and x0-.2<=bb[0]<=x1+.2]))
    gy=sorted(set([round(y0,3),round(y1,3)]+[round(float(bb[1]),3) for oi,bb,h,v in alllines if h and y0-.2<=bb[1]<=y1+.2]))
    realglyphs=T.page_glyphs(p)
    T.glyphs[p]=[g for g in realglyphs if P.color_of(g.oi,'fill')==(.216064,.204102,.208008)]
    xt=charts.ticks_from_labels(T,p,(x0-15,y0-36,x1+15,y0-6),'x')
    yt=charts.ticks_from_labels(T,p,(x0-48,y0-8,x0-7,y1+8),'y')
    T.glyphs[p]=realglyphs
    # Trang 18 cần đổi nhãn x theo lưới tuyến tính, giữ đúng vị trí vạch.
    xs=charts.snap_ticks(xt,gx,max_dist=4);ys=charts.snap_ticks(yt,gy,max_dist=4)
    oldxs=xs.copy();oldys=ys.copy()
    if ps=='18':
        xs=[(10*i,c) for i,(v,c) in enumerate(sorted(xs,key=lambda z:z[1]))]
    if ps=='10':ys=[(v*1.2,c) for v,c in ys]
    ch=charts.Chart.from_ticks(xs,ys,max_res=.6)
    # Kiểm tất cả các vạch, không để bộ fit tự bỏ một nhãn không tuyến tính.
    xr=max(abs(ch.to_page(v,0)[0]-c) for v,c in xs);yr=max(abs(ch.to_page(0,v)[1]-c) for v,c in ys)
    assert ch.warning is None and xr<=.6 and yr<=.6,(ps,ch.warning,xr,yr,xs,ys)
    labels,unknown=group_labels(T,p,plot,refs)
    assert not unknown,(ps,[(g.oi,g.char) for g in unknown])
    assert len(labels)==len(mp['curves']),(ps,len(labels),len(mp['curves']),[l['text'] for l in labels])
    # Đọc lại m³/h, mọi model, kW và từng ô H từ hình chữ G01 hiện tại.
    hms=T.find(p,'kW',rect=(30,40,580,610));hms=[m for m in hms if m.bbox[2]-m.bbox[0]<15]
    assert len(hms)==1,(ps,'kW',hms)
    hp=T.find(p,'HP',rect=(30,40,580,610));assert len(hp)==1,(ps,'HP',hp)
    lm=min(T.find(p,'Length',rect=(30,40,580,610)),key=lambda m:m.bbox[0])
    r=(hp[0].bbox[2]+39,hms[0].bbox[1]-1,lm.bbox[0]-5,hms[0].bbox[3]+1)
    qs=T.find(p,r'\d+(?:\.\d+)?',rect=r,regex=True);qs.sort(key=lambda m:m.bbox[0]);q=[float(m.text) for m in qs]
    assert q==tables[ps]['Q'],(ps,q,tables[ps]['Q'])
    kwx=sum(hms[0].bbox[::2])/2
    tab=[]
    for row in tables[ps]['rows']:
        query=row['model'].replace('-','') if ps=='28' and row['model']=='8SP120-5' else row['model']
        # Dấu nối dòng 8SP120-5 là nét stroke rời của bản gốc, đã xác minh trong G01.
        ms=T.find(p,'^'+re.escape(query)+'$',regex=True,ignore_spaces=True,rect=(30,40,300,610));assert len(ms)==1,(ps,row['model'],ms)
        mm=ms[0];cy=sum(mm.bbox[1::2])/2;hs=[]
        for qm in qs:
            cx=sum(qm.bbox[::2])/2
            gl=sorted([g for g in T.page_glyphs(p) if cx-13<sum(g.bbox[::2])/2<cx+13 and cy-5<sum(g.bbox[1::2])/2<cy+5],key=lambda g:g.bbox[0])
            s=''.join(g.char for g in gl);assert re.fullmatch(r'\d+(?:\.\d+)?',s),(ps,row['model'],s)
            hs.append(float(s))
        assert hs==row['H'],(ps,row['model'],hs,row['H'])
        kg=sorted([g for g in T.page_glyphs(p) if kwx-15<sum(g.bbox[::2])/2<kwx+15 and cy-5<sum(g.bbox[1::2])/2<cy+5],key=lambda g:g.bbox[0])
        ks=''.join(g.char for g in kg);assert re.fullmatch(r'\d+(?:\.\d+)?',ks),(ps,row['model'],ks)
        tab.append(dict(**row,kw=float(ks),kw_text=ks))
    curves=sorted(mp['curves'],key=lambda c:-c['start'][1]);pairs=[]
    stage_labels=[int(l['text'].split('-')[0]) for l in labels]
    rankrows=sorted([r for r in tab if r['stages'] in stage_labels],key=lambda r:-r['H'][0])
    assert len(rankrows)==len(curves)
    for curve,lab,rankrow in zip(curves,labels,rankrows):
        m=re.fullmatch(r'(\d+)-(\d+(?:\.\d+)?)',lab['text']);assert m,(ps,lab['text'])
        stages=int(m[1]);kw=float(m[2]);rs=[row for row in tab if row['stages']==stages];assert len(rs)==1,(ps,stages,rs)
        row=rs[0];assert row['kw']==kw,(ps,row['model'],row['kw'],lab['text'])
        oldch=charts.Chart.from_ticks(oldxs,oldys,max_res=.6)
        oldh=float(oldch.to_data(np.array([curve['start']]))[0][1])
        nearest=min(tab,key=lambda r:abs(r['H'][0]-oldh))
        # Một số đường cũ đã sai cột áp: dùng nhãn + thứ tự H0 trong bảng, ghi lại chênh cũ.
        assert rankrow['model']==row['model'],(ps,row['model'],oldh,rankrow['model'])
        pts=list(zip(row['Q'],row['H']));path=ch.smooth_path(pts,method='pchip')
        sampled=ch.to_data(charts.sample_path(path,n=200));deviations=ch.compare(sampled,pts,tol_rel=.02)
        for dev in deviations:dev['ok']=abs(dev['diff'])<=max(1,.02*abs(dev['H_table']))
        assert all(dev['ok'] for dev in deviations)
        start_new=path[0][1][0];delta=[start_new[i]-curve['start'][i] for i in range(2)]
        if max(abs(v) for v in delta)<=2:delta=[0.,0.]
        pairs.append(dict(model=row['model'],stages=stages,kw=kw,oi=curve['oi'],label=lab['text'],newlabel=str(stages)+'-'+m[2],label_ois=[g.oi for g in lab['glyphs']],label_rect=lab['bbox'],label_angle=lab['angle'],label_shift=delta,old_h0=oldh,old_nearest=nearest['model'],H0=row['H'][0],start=path[0][1][0],end=path[-1][1][-1],path=path,method=ch.last_method,last_fit=dict(method='pchip',max_dev=max(abs(d['diff']) for d in deviations)),points=deviations,color=curve['stroke'],lw=curve['lw']))
    assigned={x['model'] for x in pairs};missing=[r for r in tab if r['model'] not in assigned]
    assert missing==[] or (ps=='10' and [r['model'] for r in missing]==['5SP10-30']),(ps,missing)
    if missing:
        row=missing[0];pts=list(zip(row['Q'],row['H']));path=ch.smooth_path(pts,method='pchip')
        pairs.append(dict(model=row['model'],stages=row['stages'],kw=row['kw'],oi=None,label=None,newlabel='30-15',label_ois=[],label_rect=None,label_angle=0.,label_shift=[0.,0.],old_h0=None,H0=row['H'][0],start=path[0][1][0],end=path[-1][1][-1],path=path,method=ch.last_method,last_fit=dict(method='pchip',max_dev=0.),points=ch.compare(ch.to_data(charts.sample_path(path,n=200)),pts),color=curves[0]['stroke'],lw=curves[0]['lw']))
    out[ps]=dict(plot=plot,gridx=gx,gridy=gy,xticks_before=oldxs,yticks_before=oldys,xticks=xs,yticks=ys,axis=dict(ax=ch.ax,bx=ch.bx,ay=ch.ay,by=ch.by,residual=[xr,yr],warning=ch.warning),curves=pairs,table=tab)
    print('ĐẠT KẾ HOẠCH',ps,'trục sai lệch',round(xr,3),round(yr,3),'đường',len(pairs),'nhãn',len(labels),'bảng đọc lại',len(tab),flush=True)
Path(fresh(S.report('G02/ke-hoach-ve.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=1),encoding='utf-8')
T.E=None;Path(fresh(S.report('G02/nhan-dung-cho-ve.pkl'))).write_bytes(pickle.dumps(T.__dict__))
E.close()
