from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.recipes import Job
from g15_masked_patch import commit_masked
from catfix import verify
from PIL import Image
from pathlib import Path
import numpy as np,json,hashlib
name='Perotac bơm giếng SP_compressed (bản mới).pdf';src=S.dst(name)
target=fresh(S.report('G05/BO SUNG MA MODEL/'+name));j=Job(src,target,log_path=fresh(S.report('G05/BO SUNG MA MODEL/NHAT KY.json')))
cv=j.R.render_canvas(5,(93.6,42.3,122.4,49.3),dpi=600);parts=j.R.components(cv,cv.box((95.5,43.6,120.8,48.4)),expect=8)
assert len(parts)==8
for k,p in enumerate(parts):print('old',k,p['box'],cv.rect(p['box']),flush=True)
cv8=j.R.render_canvas(5,(94,79.4,121.8,86.9),dpi=600);bp=j.R.glyph_bank(cv8,words=[dict(text='6SP36-18',box=cv8.box((95.4,80.7,120.8,85.9)))])
assert '8' in bp['glyphs'] and bp['samples']
sam=bp['samples'][0];g8=sam['comps'][-1]
part=parts[-1];rr=cv.rect(part['box']);new=dict(text='8',comps=[g8],base=sam['base'],size=sam['size']);bank=j.R._bank_from_samples([new])
j.R.replace_word(cv,dict(text='6',box=part['box']),'8',bank,align='center',erase_method='median')
j._add(5,rr,'Mã hàng20 6SP36-26 → 6SP36-28: mười mốc Q–H khớp duy nhất nhãn28; giữ QH/kW/dimensions','raster-render')
source_sha=hashlib.sha256(Path(src).read_bytes()).hexdigest()
patch=commit_masked(j);j.R.canvases.clear();j._canvases.clear();j.save();ck=j.check(raster=True)
assert ck['ok'],ck
verify.crop(src,5,(90,35,407,61),450).save(fresh(S.report('G05/BO SUNG MA MODEL/TRUOC.png')))
verify.crop(target,5,(90,35,407,61),450).save(fresh(S.report('G05/BO SUNG MA MODEL/SAU.png')))
ocr=verify.ocr_check(target,5,(95,43,121.5,49),'6SP36-28')
print('model trial',ocr,ck['ok'],flush=True)
assert hashlib.sha256(Path(src).read_bytes()).hexdigest()==source_sha
Path(fresh(S.report('G05/BO SUNG MA MODEL/NGHIEM THU.json'))).write_text(json.dumps(dict(source_current_sha256=source_sha,trial_path=target,rect=rr,source_glyph8_page=6,source_glyph8_model='6SP36-18',source_glyph8_rect=cv8.rect(g8['box']),check=ck,ocr=ocr,patches=patch,not_primary=True),ensure_ascii=False,indent=2,default=lambda v:float(v)),encoding='utf8')
j.close()
