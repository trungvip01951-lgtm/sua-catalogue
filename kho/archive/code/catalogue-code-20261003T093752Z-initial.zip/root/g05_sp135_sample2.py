"""Mẫu2 cuối cùng của cách2đuôiSP135: màu lõi và độ rộng mực đo nguồn.
Tái dùng nền đãnghiệmthu, không sửa nét/bảng khác, chưa ghiPDF ởlượtPNG.
"""
from catwork import start,fresh,HERE
S,D,N=start()
from catfix.raster import RenderCanvas
from catfix.charts import draw_polyline,bezier
from pathlib import Path
from PIL import Image
import json,numpy as np,hashlib,copy

I='G05/10SP135 HAI MOC CUOI/MAU 1/';O='G05/10SP135 HAI MOC CUOI/MAU 2/'
r=copy.deepcopy(json.loads(Path(S.report(I+'TOA DO VA BANG NGUON.json')).read_text(encoding='utf8')))
area=json.loads(Path(S.report('G05/10SP135 HAI MOC CUOI/DO MUC NGUON/DIEN TICH MUC VUONG GOC.json')).read_text(encoding='utf8'))
assert hashlib.sha256(Path(r['current_path']).read_bytes()).hexdigest()==r['current_sha256']==area['current_sha256']
npz=np.load(S.report(I+'NEN VA MASK 600dpi.npz'));orig=npz['orig'];clean=npz['background'];protected=npz['protected']
cv=RenderCanvas(10,r['rect'],600,clean.copy(),None)
for c in r['curves']:
 d=next(z for z in area['curves'] if z['model']==c['model']);c['color_rgb']=d['color_RGB'];c['width_pt']=d['new_width_from_source_opacity_area_pt'];c['source_style_method']=d['method']
 pts=bezier(*map(np.array,c['segments'][0]),n=500).tolist();draw_polyline(cv,pts,color=tuple(round(v) for v in c['color_rgb']),width_px=c['width_pt']*600/72,ss=4)
cv.work[protected]=orig[protected];assert np.array_equal(cv.work[protected],orig[protected])
r['method']='Mẫu2: nguồn màu lõi20%tối nhất, độ rộng bằng diện tíchopacity vuônggóc đo100/95lát nguồn150dpi. Nền/maskgiữchuẩn mẫu1; chỉ2nétnguồn5/7, đúngQ180=66/93.'
r['style']=area['curves'];r['sample_number']=2;r['preview_RGB_rounding_only']=True;r['first_sample_rejection']='ROOT từ chối nétmẫu1 vìmỏng gầngấp2; số/ngoàivùng/bảotoàn đãđạt. Mẫu2 là lầnthửcuối cùng cách này.'
Image.fromarray(orig).save(fresh(S.report(O+'TRUOC.png')));Image.fromarray(cv.work).save(fresh(S.report(O+'SAU.png')));Image.fromarray(clean).save(fresh(S.report(O+'NEN.png')))
np.savez_compressed(fresh(S.report(O+'NEN VA MASK 600dpi.npz')),orig=orig,background=clean,preview=cv.work,protected=protected)
box=(round((715-r['rect'][0])/.12),round((r['rect'][3]-386)/.12),round((763-r['rect'][0])/.12),round((r['rect'][3]-341)/.12))
Image.fromarray(cv.work).crop(box).save(fresh(S.report(O+'SAU - HAI DUOI.png')))
Image.fromarray(orig).crop(box).save(fresh(S.report(O+'TRUOC - HAI DUOI.png')))
Path(fresh(S.report(O+'TOA DO VA BANG NGUON.json'))).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
print('SP135SAMPLE2',[(c['model'],c['color_rgb'],c['width_pt']) for c in r['curves']],flush=True)
