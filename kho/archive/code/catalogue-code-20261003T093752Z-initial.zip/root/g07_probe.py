from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from catfix import verify
from pathlib import Path
import json
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf';root=Path(S.report('G07'))
E=Editor(S.src(NAME));TL=TextLayer(E)
pairs=[('industrian','industriali'),('movimentazionee','movimentazione e'),('utllizzare','utilizzare'),
('peril sollevamentodl','per il sollevamento di'),('inseritidei','inseriti dei'),('spiacevolidanni','spiacevoli danni'),
('50 FHz','50 Hz'),('dean','clean'),('nothigherthan','not higher than'),('anda Schuko','and a Schuko'),
('threephase','three-phase'),('trlphasé','triphasé'),('IPB8','IP68'),('FESI','PESI'),('Imballa','Imballo'),
('CLOSEDIMPELLER','CLOSED IMPELLER'),('PotenZa','Potenza'),('Kg³/m','kg/dm³'),('50HZ','50 Hz')]
out=dict(pairs=[],font_inventory=[],tables=[])
for old,new in pairs:
    found=[]
    for m in TL.find(0,old):
        r=m.glyphs[0].run
        try:r.font.encode(new);missing=''
        except Exception as ex:missing=str(ex)
        found.append(dict(text=m.text,rect=m.bbox,font=r.font.basefont,fontname=str(r.fontname),size=r.size_page,
                          text_run=r.text,run=r.index,missing=missing))
    print(old,'->',new,len(found),[(x['rect'],x['missing']) for x in found],flush=True)
    out['pairs'].append(dict(old=old,new=new,found=found))
for text,gs in TL.text_lines(0):
    if min(g.bbox[0] for g in gs)>640:
        out['tables'].append(dict(text=text,rect=[min(g.bbox[0] for g in gs),min(g.bbox[1] for g in gs),max(g.bbox[2] for g in gs),max(g.bbox[3] for g in gs)],
                                 fonts=sorted(set(g.run.font.basefont for g in gs)),sizes=sorted(set(round(g.run.size_page,3) for g in gs))))
seen=set()
for r in TL.runs(0):
    f=r.font
    if id(f) in seen:continue
    seen.add(id(f));chars={}
    for ch in 'k³-482oPi':
        try:chars[ch]=bytes(f.encode(ch)).hex()
        except Exception as ex:chars[ch]=str(ex)
    out['font_inventory'].append(dict(name=str(r.fontname),font=f.basefont,reference=str(f.ref),char_codes=chars))
json.dump(out,open(fresh(root/'probe.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
verify.crop(S.src(NAME),0,(630,375,1170,825),200).save(fresh(root/'bang-tren.png'))
verify.crop(S.src(NAME),0,(630,240,1170,475),250).save(fresh(root/'bang-duoi.png'))
E.close()
