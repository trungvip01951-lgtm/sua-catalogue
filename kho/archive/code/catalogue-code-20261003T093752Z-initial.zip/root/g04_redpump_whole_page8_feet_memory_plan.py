"""ROOT requested RAM-only clip-hole test. Never save catalogue/M2 PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
import pymupdf as fitz
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Instr,Num
root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
pr=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
b=json.loads((root/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'));keep=json.loads((pr/'VACH PHU FEET VA KHOI TIEU DE GIU NGUON V1.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b['source']),sha(b['input_current']),sha(b['sample'])];assert guards==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
E=Editor(b['sample'],backend='fitz');page=E.page(7);marker=next(i for i,z in enumerate(page.ops) if z.op=='BMC' and list(map(str,z.operands))==['CfxRedpumpWholePage8M1'])
curE=Editor(b['input_current'],backend='fitz');curR=Raster(curE);srcE=Editor(b['source'],backend='fitz');srcR=Raster(srcE)
body=b['grids'][0]['allowed'];records=[]
def intersect(a,z):return [max(a[0],z[0]),max(a[1],z[1]),min(a[2],z[2]),min(a[3],z[3])]
def operands(box):return [box[0],box[1],box[2]-box[0],box[3]-box[1]]
for k,t in enumerate(keep['short_feet_ticks']):
 before=t['source_original_ink_restore_page_bbox'];after=(np.array(before)+[-.48,-.48,.48,.48]).tolist()
 old=intersect(before,body);new=intersect(after,body)
 found=[]
 for i,z in enumerate(page.ops):
  if i>marker and z.op=='re' and len(z.operands)==4 and max(abs(np.array(z.operands,dtype=float)-np.array(operands(old))))<1e-8:
   E.modify_instr(7,i,Instr([Num(float(x)) for x in operands(new)],'re'));found.append(i)
 assert len(found)==2,(k,found)
 sourcecv=srcR.render_canvas(7,new,dpi=600);aa=sourcecv.orig.astype(int);g=aa@np.array([.299,.587,.114]);colored=(aa[:,:,1]-aa[:,:,0]>8)&(aa[:,:,2]-aa[:,:,0]>10)&(g<230)
 curcv=curR.render_canvas(7,new,dpi=600);cc=curcv.orig.astype(int);cg=cc@np.array([.299,.587,.114]);curcolored=(cc[:,:,1]-cc[:,:,0]>8)&(cc[:,:,2]-cc[:,:,0]>10)&(cg<230)
 # Exact source pixels and proposed geometry; no source-family data borrowed.
 sourceink=np.argwhere(colored)
 records.append(dict(index=k+1,source_original_restore_bbox=before,M1_effective_hole_before=old,
  proposed_hole_before_intersection=after,proposed_effective_hole_after=new,unchanged_allowed_body=body,
  changed_rect_instruction_indices=found,padding_pt=.48,
  source_actual600_colored_curve_core_pixels_in_new_hole=int(colored.sum()),
  current_actual600_colored_curve_core_pixels_in_new_hole=int(curcolored.sum()),
  source_color_classification='G-R>8,B-R>10,gray<230; positive result must be read, not automatically called QH.',
  source_colored_pixel_uv=sourceink.tolist(),source_hole_actual_render_rect=sourcecv.rect0,
  enlarged_hole_is_inside_existing_allowed_rectangle=True))
# All editing and rendering below stays in RAM via catfix. NO E.save/Job.save.
E.doc.set_page_content(7,E.build(7))
def render_ram(rect,dpi):
 pg=E.doc.doc[7];T=pg.transformation_matrix;p0=fitz.Point(rect[0],rect[1])*T;p1=fitz.Point(rect[2],rect[3])*T
 rr=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y));z=dpi/72
 pix=pg.get_pixmap(matrix=fitz.Matrix(z,z),clip=rr,colorspace=fitz.csRGB,alpha=False)
 return np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[:,:,:3].copy()
tests=[];sheet=Image.new('RGB',(1600,5*290),'white');draw=ImageDraw.Draw(sheet)
for dpi in [150,200,600]:
 for rec in records:
  box=rec['source_original_restore_bbox'];cv=curR.render_canvas(7,box,dpi=dpi);ram=render_ram(cv.rect0,dpi)
  assert ram.shape==cv.orig.shape,(dpi,rec['index'],ram.shape,cv.orig.shape)
  changed=np.any(ram!=cv.orig,axis=2);count=int(changed.sum());assert count==0,(dpi,rec['index'],count)
  tests.append(dict(index=rec['index'],dpi=dpi,rect_original_restore=box,actual_render_rect=cv.rect0,pixels_checked=int(changed.size),
   changed_pixels=0,retained_original_RGB_byte_exact=True,scope='RAM ONLY / phương án chưa có PDF mẫu2'))
  if dpi==600:
   a=Image.fromarray(cv.orig);z=Image.fromarray(ram);scale=7;y=(rec['index']-1)*290
   sheet.paste(a.resize((a.width*scale,a.height*scale),Image.Resampling.NEAREST),(10,y+35));sheet.paste(z.resize((z.width*scale,z.height*scale),Image.Resampling.NEAREST),(810,y+35))
   draw.text((10,y+5),f'Feet{rec["index"]}:actual current600dpi',fill='blue');draw.text((810,y+5),'RAM simulation only; NO M2 PDF; pixel diff0',fill='blue')
assert all(z['source_actual600_colored_curve_core_pixels_in_new_hole']==0 and z['current_actual600_colored_curve_core_pixels_in_new_hole']==0 for z in records)
sheet.save(fresh(root/'THU LO VACH PHU TRONG RAM KHONG PHAI MAU PDF2.png'))
out=dict(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],M1=b['sample'],M1_SHA256=guards[2],
 method='Sửa10lệnhre của2clipbg/frame bằngcatfixEditor chỉRAM, dựngPixmap từdoc RAM; khôngsave',records=records,source_pixels_RAM_tests=tests,
 source_and_current_QH_old_ink_in_proposed_holes=0,physical_model_QH_end_domain_Q21_page_x=318.288,
 source_black_frame_and_horizontal_stems='Toàn hộp nguồn cũ giữ byteRGB sau RAM150/200/600;0pixel đổi. Tâm/đuôi ngang và mực khung đen đã chứng minh trong phạm vi hộp nguồn.',
 limitation='Chỉ kiểm giải pháp lỗ bảo vệ. Chưa là nghiệm thu PDF2; ROOT/đồ họa phải gộp các lỗi thực khác trước mẫu2.',
 PDF_written=False,new_M2_PDF_exists=False,canonical_written=False,shared_progress_written=False,parent_approval_for_M2=False)
Path(fresh(root/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
curE.close();srcE.close();E.close();assert guards==[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
print('RAM clip expanded .48pt:15crop tests pixel0;10rect edits only RAM;no oldcoloredQH pixels in5holes;NO PDF2',flush=True)
