from catwork import start, fresh
S,D,N=start()
from catfix import verify,ocr
from catfix.pdfdoc import render
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from catfix.recipes import Job
from g03_xmp_helper import check_xmp
from pathlib import Path
import numpy as np, cv2, json, hashlib, pikepdf, pymupdf as fitz, sys

root=Path(S.report('G06'))
mode=sys.argv[1] if len(sys.argv)>1 else 'stage'
kind=sys.argv[2] if len(sys.argv)>2 else 'word-copy'
trial=sys.argv[3] if len(sys.argv)>3 else '2'
st=json.loads((root/'review'/f'{kind}-build-{trial}.json').read_text(encoding='utf-8'))
src=S.src('Aquaris FS_300dpi_75% (bản mới).pdf')
dst=st['stage'] if mode=='stage' else S.dst('Aquaris FS_300dpi_75% (bản mới).pdf')
prior=st['prior'] if mode=='stage' else str(root/'review'/'ban-da-dat-51-truoc-sua-53.pdf')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
serial=lambda x:x.item() if hasattr(x,'item') else x.tolist() if hasattr(x,'tolist') else str(x)
assert sha(src)==st['source_sha256'] and sha(prior)==st['prior_sha256']
if mode=='stage':assert sha(dst)==st['stage_sha256']
allowed={4:[[c['rect'][0]-1,c['rect'][1]-1,c['rect'][2]+1,c['rect'][3]+1] for c in st['changes']]}
out=dict(source=src,prior=prior,destination=dst,mode=mode,source_sha256=sha(src),prior_sha256=sha(prior),
         destination_sha256=sha(dst),source_preserved=True,structure=verify.structure_check(prior,dst),
         outside_pixels_200dpi=verify.outside_pixels(prior,dst,allowed,dpi=200,pad=0,thr=0,min_size=0))
out['unchanged_pages_1_3']=[dict(page=p+1,pixels_exactly_equal=bool(np.array_equal(render(prior,p,200),render(dst,p,200)))) for p in range(3)]
out['model_51_ocr']=verify.ocr_check(dst,0,(50,657,286,681),'FS-35-7-2.2')
out['unsolved_52_headers_preserved']=[dict(page=p+1,pixels_exactly_equal=bool(np.array_equal(np.array(verify.crop(src,p,r,600)),np.array(verify.crop(dst,p,r,600)))))
    for p,r in ((1,(164,227,193,242)),(2,(172,255,205,272)))]
print('Cấu trúc',out['structure']['ok'],'ngoài vùng',out['outside_pixels_200dpi'],'giữ trang1–3',out['unchanged_pages_1_3'],flush=True)

def font_inventory(pdf):
    fonts=[]
    for o in pdf.objects:
        if not isinstance(o,pikepdf.Dictionary) or o.get('/Type')!=pikepdf.Name.Font:continue
        entry=dict(font=str(o.get('/BaseFont')),subtype=str(o.get('/Subtype')))
        fd=o.get('/FontDescriptor')
        if fd is not None:
            for k in ('/FontFile','/FontFile2','/FontFile3'):
                if k in fd:entry[k]=hashlib.sha256(fd[k].read_raw_bytes()).hexdigest()
        fonts.append(json.dumps(entry,sort_keys=True))
    return sorted(fonts)

with pikepdf.open(prior) as a,pikepdf.open(dst) as b:
    out['metadata_equal']={str(k):str(v) for k,v in a.docinfo.items()}=={str(k):str(v) for k,v in b.docinfo.items()}
    out['prior_fonts']=font_inventory(a);out['final_fonts']=font_inventory(b)
    out['font_resources_equal']=out['prior_fonts']==out['final_fonts']
    images=[];patches=[]
    for p,(aa,bb) in enumerate(zip(a.pages,b.pages),1):
        ax=aa.Resources.get('/XObject',{});bx=bb.Resources.get('/XObject',{})
        for k,o in ax.items():
            if o.get('/Subtype')!=pikepdf.Name.Image:continue
            raw_equal=k in bx and o.read_raw_bytes()==bx[k].read_raw_bytes()
            shape_equal=k in bx and all(str(o.get(kk))==str(bx[k].get(kk)) for kk in ('/Width','/Height','/BitsPerComponent','/ColorSpace','/Decode','/Mask','/Filter'))
            icc_equal=True;cs=o.get('/ColorSpace')
            if isinstance(cs,pikepdf.Array) and len(cs)>1 and cs[0]==pikepdf.Name.ICCBased:
                icc_equal=cs[1].read_raw_bytes()==bx[k].ColorSpace[1].read_raw_bytes()
            images.append(dict(page=p,name=str(k),raw_stream_equal=raw_equal,geometry_color_filter_equal=shape_equal,icc_stream_equal=icc_equal,ok=raw_equal and shape_equal and icc_equal))
        for k,o in bx.items():
            if k in ax or o.get('/Subtype')!=pikepdf.Name.Image:continue
            sm=o.get('/SMask');mask=np.frombuffer(sm.read_bytes(),dtype=np.uint8) if sm is not None else None
            patches.append(dict(page=p,name=str(k),width=int(o.Width),height=int(o.Height),filter=str(o.get('/Filter')),masked=sm is not None,
                transparent_pixels=int((mask==0).sum()) if mask is not None else None,opaque_pixels=int((mask==255).sum()) if mask is not None else None))
    out['prior_image_streams_preserved']=images;out['new_patches']=patches
out['xmp']=check_xmp(prior,dst)
with fitz.open(prior) as a,fitz.open(dst) as b:
    out['bookmarks_equal']=a.get_toc()==b.get_toc()
    norm=lambda l:{k:str(v) for k,v in l.items() if k!='xref'}
    out['links_equal']=[[norm(l) for l in p.get_links()] for p in a]==[[norm(l) for l in p.get_links()] for p in b]
EA,EB=Editor(prior),Editor(dst)
def native(E):
    T=TextLayer(E)
    return [[dict(ch=g.ch,code=g.cb.hex(),basefont=g.run.font.basefont,size=g.run.size_page,rect=list(g.bbox),origin=list(g.o)) for g in T.glyphs(p)] for p in range(E.n_pages)]
out['native_text_equal']=native(EA)==native(EB)
EA.close();EB.close()

# Tách phép kiểm đường kẻ/số thứ tự khỏi việc nhìn bố cục.
geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
out['grid_checks']=[];out['number_column_checks']=[];out['old_ink_background_checks']=[]
for dpi in (400,500,600):
    for i,g in enumerate(geo['grids']):
        r=g['rect'];aa=np.array(verify.crop(prior,3,r,dpi));bb=np.array(verify.crop(dst,3,r,dpi))
        dark=aa.min(axis=2)<160;mask=np.zeros(dark.shape,bool)
        for x in np.where(dark.mean(axis=0)>.8)[0]:mask[:,max(0,x-1):min(mask.shape[1],x+2)]=True
        for y in np.where(dark.mean(axis=1)>.8)[0]:mask[max(0,y-1):min(mask.shape[0],y+2),:]=True
        out['grid_checks'].append(dict(dpi=dpi,table=i+1,grid_pixels=int(mask.sum()),changed_grid_pixels=int(np.any(aa[mask]!=bb[mask],axis=1).sum()),pixels_exactly_equal=bool(np.array_equal(aa[mask],bb[mask]))))
    for i,r in enumerate(((287.5,381,310.6,696),(424.8,477,447.2,696))):
        aa=np.array(verify.crop(prior,3,r,dpi));bb=np.array(verify.crop(dst,3,r,dpi))
        out['number_column_checks'].append(dict(dpi=dpi,table=i+1,pixels_exactly_equal=bool(np.array_equal(aa,bb))))
    for c in st['changes']:
        r=c['rect'];aa=np.array(verify.crop(prior,3,r,dpi));bb=np.array(verify.crop(dst,3,r,dpi))
        old=aa.min(axis=2)<230;grid=np.zeros(old.shape,np.uint8)
        for x in np.where(old.mean(axis=0)>.8)[0]:grid[:,max(0,x-4):min(grid.shape[1],x+5)]=1
        for y in np.where(old.mean(axis=1)>.85)[0]:grid[max(0,y-4):min(grid.shape[0],y+5),:]=1
        old=cv2.dilate(old.astype(np.uint8),np.ones((5,5),np.uint8)).astype(bool)&~grid.astype(bool)
        # Bỏ cả hộp từ mới cùng 0,6pt biên khử răng cưa; phần còn lại phải là nền sạch.
        for p in st['placements']:
            if p['row']!=c['row']:continue
            nr=p['destination_rect'];pad=.6;s=dpi/72
            x0=max(0,int(np.floor((nr[0]-pad-r[0])*s)));x1=min(old.shape[1],int(np.ceil((nr[2]+pad-r[0])*s)))
            y0=max(0,int(np.floor((r[3]-nr[3]-pad)*s)));y1=min(old.shape[0],int(np.ceil((r[3]-nr[1]+pad)*s)))
            old[y0:y1,x0:x1]=False
        gray=bb.min(axis=2);vals=gray[old]
        out['old_ink_background_checks'].append(dict(dpi=dpi,row=c['row'],checked_pixels=int(old.sum()),
            minimum=int(vals.min()) if len(vals) else None,dark_pixels_below_230=int((vals<230).sum()),
            pixels_below_254=int((vals<254).sum()),clean=bool(len(vals) and np.all(vals>=254))))
    print('Kiểm lưới/nền',dpi,[(z['row'],z['minimum'],z['pixels_below_254']) for z in out['old_ink_background_checks'] if z['dpi']==dpi],flush=True)

out['readback']=[]
normalize=lambda text:''.join(c for c in text.casefold() if c.isalnum())
for c in st['changes']:
    r=c['rect'];im=verify.crop(dst,3,r,600)
    text=' '.join(w['text'] for w in ocr.image_words(im,psm=6));expected=c['new'].replace('\n',' ')
    margins=[min(p['destination_rect'][0]-r[0],p['destination_rect'][1]-r[1],r[2]-p['destination_rect'][2],r[3]-p['destination_rect'][3]) for p in st['placements'] if p['row']==c['row']]
    out['readback'].append(dict(row=c['row'],expected=expected,ocr=text,ocr_ok=normalize(expected)==normalize(text),
        minimum_word_margin_pt=min(margins),all_words_inside_cell=min(margins)>0,target_cap_px_300dpi=c['target_cap_px'],factor=c['factor']))
    print('Đọc lại',c['row'],repr(text),'lề',min(margins),flush=True)
out['common_checks_ok']=all([out['source_preserved'],out['structure']['ok'],not out['outside_pixels_200dpi'],
    all(r['pixels_exactly_equal'] for r in out['unchanged_pages_1_3']),out['model_51_ocr']['ok'],
    all(r['pixels_exactly_equal'] for r in out['unsolved_52_headers_preserved']),out['metadata_equal'],out['font_resources_equal'],
    out['native_text_equal'],out['xmp']['values_equal'],out['bookmarks_equal'],out['links_equal'],
    all(r['ok'] for r in out['prior_image_streams_preserved']),len(out['new_patches'])==5,
    all(r['page']==4 and r['masked'] and r['transparent_pixels']>0 for r in out['new_patches']),
    all(r['pixels_exactly_equal'] for r in out['grid_checks']),all(r['pixels_exactly_equal'] for r in out['number_column_checks']),
    all(r['clean'] for r in out['old_ink_background_checks']),all(r['all_words_inside_cell'] for r in out['readback'])])
tag='' if kind=='word-copy' else '-'+trial
json.dump(out,open(fresh(root/'review'/f'{kind}-acceptance-{mode}{tag}.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=serial)
print('COMMON',out['common_checks_ok'],'OCR',[(r['row'],r['ocr_ok']) for r in out['readback']],'PATCHES',len(out['new_patches']),flush=True)
