"""Read source ink per local character; no modification to any bank."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from pathlib import Path
from PIL import Image,ImageDraw
from g04_perotac_whole_pdf_tools46 import read,sha
import json,numpy as np
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'CHU TRUC FAIL DOC RIENG NGUON V3/ALPHA TUNG NET DUNG NGUON'
path=base/'CHU TRUC NGUON VA RAM CHI DOC/DON VI DAU CHAM DAU GACH CHEO VA i NGUON V2/CHU TRUC DAU NHO DOC RIENG V2 RAM CHUA NGHIEM THU.json'
doc=read(path);name='Perotac bơm giếng SA_compressed (bản mới).pdf';E=Editor(S.src(name),backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda i:i.W*i.H);cv=R.canvas(im)
keys=['Q US 10','Q US 30','H FEET 200','Q LMIN 150','Q LMIN 250','Q LMIN 350','M3 UNIT','ETA UNIT','Q LMIN 50','H FEET 400']
out=[]
for key in keys:
    word=next(row for row in doc['words'] if row['key']==key);x0,y0,x1,y1=word['source_native_box'];raw=cv.orig[y0:y1,x0:x1];alpha=R.alpha_of(raw,255,np.array(word['source_RGB']))
    h,w=alpha.shape;sc=48;tile=Image.new('RGB',(w*sc+80,h*sc+90),'white');dr=ImageDraw.Draw(tile)
    tile.paste(Image.fromarray(raw).resize((w*sc,h*sc),Image.Resampling.NEAREST),(60,50))
    for x in range(w):
        dr.text((60+x*sc+10,15),str(x),fill='red');dr.line([(60+x*sc,50),(60+x*sc,50+h*sc)],fill=(220,220,255),width=1)
    for y in range(h):
        dr.text((20,50+y*sc+18),str(y),fill='red');dr.line([(60,50+y*sc),(60+w*sc,50+y*sc)],fill=(220,220,255),width=1)
    tile.save(fresh(root/(key+' PIXEL CO TOA DO LOCAL.png')))
    item=dict(key=key,source_native_box=word['source_native_box'],alpha=alpha.tolist(),column_ink_mass=alpha.sum(0).tolist(),source_alpha_mass=float(alpha.sum()))
    out.append(item);print(key,'MASS COL',np.round(alpha.sum(0),2).tolist(),flush=True)
Path(fresh(root/'ALPHA CHU TRUC TUNG FIELD NGUON.json')).write_text(json.dumps(dict(source_sha256=sha(S.src(name)),canonical_sha256=sha(S.result(name)),own_source_X7_only=True,records=out,read_only=True,no_bank_PDF_or_progress_changed=True),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
