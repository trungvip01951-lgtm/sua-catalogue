"""Read actual tick stems/labels from original p8, never from edited masks."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image
import numpy as np, json, hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/DOI CHIEU VACH PHU NGUON THAT'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float);L=a@[.299,.587,.114]
boxes={'H TRAI':(56,171,137,580),'Q TREN':(110,120,757,189),'Q GIUA':(112,562,757,587),'Q DUOI':(108,669,757,734),'ETA TRAI':(96,579,135,682)}
for key,(x0,y0,x1,y1) in boxes.items():
    raw=Image.fromarray(cv.orig[y0:y1,x0:x1]);raw.save(fresh(root/(key+' NGUON150dpi.png')))
    raw.resize((raw.width*4,raw.height*4),Image.Resampling.NEAREST).save(fresh(root/(key+' NGUON PHONG4LAN.png')))
profiles={}
for key,y0,y1,x0,x1,axis in [('H',181,572,120,123,0),('Q TOP',174,179,125,746,1),('Q LOWER',677,683,125,746,1),('Q MID',571,578,125,746,1)]:
    reg=L[y0:y1,x0:x1];d=255-reg
    v=np.sum(d,axis=axis)
    profiles[key]=dict(native_first_index=y0 if axis==0 else x0,native_last_index=y1 if axis==0 else x1,
                       native_probe_box=[x0,y0,x1,y1],sum_original_darkness=v.tolist(),raw_original_RGB=cv.orig[y0:y1,x0:x1].tolist())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'VACH PHU VA PROFILE NGUON CHI DOC.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),
 original_Perotac_X7_only=True,source_profiles=profiles,profiles_need_position_shape_review_not_tick_rank_assignment=True,new_PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close();print('SOURCE TICK CROPS/PROFILES SAVED',str(root),flush=True)
