"""Read actual source efficiency ink for full-panel plan only; no numerical eta claim."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import color_runs,follow_observed_ink
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
folder=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
a=json.loads((root/'17 TRUC DOC NGUON RIENG KHOA V1.json').read_text(encoding='utf8'))
ax=next(p for p in a['records'] if p['family']=='4SL16')['axis'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im)
ar=cv.orig.astype(float);g=ar@np.array([.299,.587,.114]);mask=(ar[:,:,1]-ar[:,:,0]>6)&(ar[:,:,2]-ar[:,:,0]>8)&(g<230);weights=255-g;cache={}
def col(u):
 key=(u,580,674)
 if key not in cache:cache[key]=[z for z in color_runs(mask,weights,u,580,674,max_width=12) if z['strength']>60]
 return cache[key]
seed_candidates=col(460);assert len(seed_candidates)==1,seed_candidates
seed=dict(u=460,**seed_candidates[0]);right,ri=follow_observed_ink(col,seed,710,1,radius=4,max_gap=3,history=11);left,li=follow_observed_ink(col,seed,115,-1,radius=4,max_gap=3,history=11)
pts=sorted([*left[1:],*right],key=lambda z:z['u']);assert len(pts)>500 and not ri+li
uv=np.array([[z['u'],z['v']] for z in pts]);xy=np.array([cv.to_page(*z) for z in uv]);q=(xy[:,0]-ax[1])/ax[0]
pic=Image.fromarray(cv.orig);dr=ImageDraw.Draw(pic)
for u,v in uv[::3]:dr.ellipse((u-1,v-1,u+1,v+1),fill=(180,0,180))
photo=fresh(folder/'ETA NET NGUON THEO DOI KHONG DU LIEU SO.png');pic.crop((110,575,747,677)).resize((2548,408),Image.Resampling.NEAREST).save(photo)
out=dict(page=8,source=d['source'],source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],source_native_ctm=im.ctm.tolist(),source_native_image_size=[im.W,im.H],source_seed=seed,source_observed_ink_points=pts,source_observed_page_points=xy.tolist(),source_observed_Q_interval=[float(q.min()),float(q.max())],native_observed_endpoint=uv[[0,-1]].tolist(),page_observed_endpoint=xy[[0,-1]].tolist(),branch_issues=ri+li,source_trace_photo=photo,eta_numeric_data_available=False,eta_numeric_accuracy_status='CHƯA THỂ: không có bảng η. Chỉ được bảo toàn hình dạng/mốc mực quan sát nguồn.',planned_curve_rebuild='Dựng đường PDF trơn theo tâm mực thật, sai lệch hình học so nguồn <= độ bất định native; không thêm mốc H/η ngoài nguồn, không kéo đầu/cuối.',catalogue_written=False)
Path(fresh(folder/'ETA DOC NET NGUON RIENG.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(d['source']),sha(d['current'])]
print('eta observed',len(pts),'points Q',out['source_observed_Q_interval'],'endpoint',out['native_observed_endpoint'],flush=True)
