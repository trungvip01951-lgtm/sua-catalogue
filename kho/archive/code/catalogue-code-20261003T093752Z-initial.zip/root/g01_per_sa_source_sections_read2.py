from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,collections,math
from scipy.signal import find_peaks
from catfix.vector import Editor
from catfix.raster import Raster

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=S.src('Perotac bơm giếng SA_compressed (bản mới).pdf');dst=S.result('Perotac bơm giếng SA_compressed (bản mới).pdf')
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));RDIR=O.parent
base=json.loads((RDIR/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'));d=json.loads((O/'g01_DO TIEU DIEN XAM VA VACH DIA PHUONG - CHO SOI ANH.json').read_text(encoding='utf8'));axes=json.loads((O/'g01_TRUC Q DO TU VACH ETA THUC RIENG VA TRUC H NGUON.json').read_text(encoding='utf8'));byaxis={g['family']:g for g in axes['graphs']}
E=Editor(src);R=Raster(E);E2=Editor(dst);R2=Raster(E2);out=[];pres=[]

def piece(value,pairs,reverse=False):
 pairs=sorted(pairs,key=lambda p:p[1] if reverse else p[0]);xs=np.array([p[1] if reverse else p[0] for p in pairs]);ys=np.array([p[0] if reverse else p[1] for p in pairs]);j=min(max(int(np.searchsorted(xs,value)),1),len(xs)-1)
 if value<xs[0]-1e-7 or value>xs[-1]+1e-7:return None,None
 return float(ys[j-1]+(value-xs[j-1])*(ys[j]-ys[j-1])/(xs[j]-xs[j-1])),[pairs[j-1],pairs[j]]

for g in d['graphs']:
 family=g['family'];a=byaxis[family];im=max(R.images(g['page']-1),key=lambda z:z.W*z.H);im2=max(R2.images(g['page']-1),key=lambda z:z.W*z.H);rgb=R.canvas(im).orig;gray=rgb.astype(float)@np.array([.299,.587,.114]);raw0=E.doc.stream_raw(im.ref);raw1=E2.doc.stream_raw(im2.ref);assert raw0==raw1,(family,'Original source JPEG changed');assert np.array_equal(rgb,R2.canvas(im2).orig)
 pres.append({'page':g['page'],'family':family,'source_xref':list(im.ref),'current_xref':list(im2.ref),'original_image_raw_SHA':hashlib.sha256(raw0).hexdigest(),'original_image_raw_bytes':len(raw0),'source_and_current_original_image_identical':True,'source_pixel_shape':list(rgb.shape),'image_CTM_same':bool(np.array_equal(im.ctm,im2.ctm))})
 xt=[(t['litre_per_minute'],t['actual_eta_vertical_tick']) for t in a['source_flow_ticks']];yt=[(t['value_H_m'],t['position']) for t in g['axis_H_local']];rowsall=[]
 for c in g['curves']:
  if not c['points']:continue
  trace=c.get('observed_trace',[]);uu=np.array([p['u'] for p in trace]);vv=np.array([p['v'] for p in trace]);issues=c.get('trace_ambiguities',[])
  for old in c['points']:
   q=old['Q_m3_h'];h=old['H_table_m'];x,xb=piece(q*1000/60,xt);pt={'page':g['page'],'family':family,'model':c['model'],'Q_m3_h':q,'Q_l_min':q*1000/60,'H_table_m':h,'tolerance_H_m':max(1,.02*h),'prior_status':old['prior_status'],'Q_source_native_u':x,'source_Q_adjacent_actual_ticks':xb,'literal_label_native_bbox':c['literal_label_native_box'],'source_label_previously_locked':c['baseline_identity_confirmed'],'new_visual_confirmation_pending':True}
   if not trace or x is None or x<uu[0]-.8 or x>uu[-1]+.8:
    pt.update({'status_pending_visual':'CHƯA THỂ XÁC MINH','reason':'Không khóa được nhánh qua chữ/miền mực, không bù bằng H bảng hay ngoại suy','observed_reader_u_domain':[float(uu[0]),float(uu[-1])] if len(uu) else None});rowsall.append(pt);continue
   # The search centre comes only from the label-anchored observed source trace.
   pred=float(np.interp(x,uu,vv));y0=max(0,int(math.floor(pred))-6);y1=min(gray.shape[0]-1,int(math.ceil(pred))+6);ys=np.arange(y0,y1+1);ix=int(math.floor(x));t=x-ix;lum=(1-t)*gray[ys,ix]+t*gray[ys,ix+1];dark=255-lum
   peaks,_=find_peaks(dark,height=28,prominence=18,distance=2);cands=[]
   for k in peaks:
    if abs(ys[k]-pred)>3.1:continue
    floor=max(0,float(min(dark[max(0,k-4):k+1].min(),dark[k:min(len(ys),k+5)].min())));threshold=floor+.50*(dark[k]-floor);lo=k;hi=k
    while lo>0 and dark[lo-1]>=threshold:lo-=1
    while hi+1<len(ys) and dark[hi+1]>=threshold:hi+=1
    weights=np.maximum(dark[lo:hi+1]-floor,0);v=float(np.average(ys[lo:hi+1],weights=weights));hm,hb=piece(v,yt,True)
    cands.append({'source_native_v':v,'source_pixel_FWHM_interval':[float(ys[lo]-.5),float(ys[hi]+.5)],'source_FWHM_width_native_px':int(hi-lo+1),'source_peak_darkness':float(dark[k]),'H_m':hm,'actual_H_adjacent_ticks':hb,'observed_ink_only':True})
   pt.update({'predicted_search_v_from_observed_pixels_only':pred,'gray_section_source_y_pixels':ys.tolist(),'gray_section_source_darkness':dark.tolist(),'source_section_candidates':cands,'target_u_vs_observed_trace_end_native_px':max(float(uu[0]-x),float(x-uu[-1]),0.)})
   nearissues=[z for z in issues if abs(z['u']-x)<3]
   # Never resolve more than one plausible physical ink run from table H.
   if len(cands)!=1 or cands[0]['H_m'] is None:
    pt.update({'status_pending_visual':'CHƯA THỂ XÁC MINH','reason':'Không có đúng một tiết diện mực riêng; không chọn ứng viên gần H bảng'});rowsall.append(pt);continue
   cp=cands[0];hm=cp['H_m'];yb=cp['actual_H_adjacent_ticks'];hperpx=abs((yb[1][0]-yb[0][0])/(yb[1][1]-yb[0][1]));j=min(max(int(np.searchsorted(uu,x)),1),len(trace)-1);p0=trace[j-1];p1=trace[j];slope=(p1['v']-p0['v'])/(p1['u']-p0['u']);width=cp['source_FWHM_width_native_px'];unitround=(.5*abs((xb[1][1]-xb[0][1])/(xb[1][0]-xb[0][0]))) if family=='6SA35' else 0.;unc=(.5*width+.5+.5+abs(slope)*(.5+unitround))*hperpx;delta=hm-h
   pt.update({'H_curve_measured_m':hm,'delta_H_m':delta,'uncertainty_bound_m':unc,'H_curve_bound_m':[hm-unc,hm+unc],'source_FWHM_width_native_px':width,'local_H_m_per_pixel':hperpx,'local_observed_tangent_dv_du':slope,'uncertainty_terms_native_px':{'half_FWHM_width':width*.5,'source_pixel_location':.5,'H_tick':.5,'Q_tick_and_6SA35_rounded_lmin':abs(slope)*(.5+unitround)},'axis_local_limits':('H không có vạch ghi số khớp lưới: chỉ dùng hai khung đen0/240, không suy nhãn trung gian' if g['H_grid_inconsistent_labels'] else None)})
   if nearissues or width>4 or g['H_grid_inconsistent_labels']:
    status='CHƯA THỂ XÁC MINH';reason='Nhánh/vùng mực sát chưa rõ hoặc trục H thiếu định vị địa phương chắc'
   elif abs(delta)-unc>pt['tolerance_H_m']:status='ỨNG VIÊN CHƯA ĐẠT';reason='Sai lệch vượt ngưỡng cả khi cộng biên đọc; cần soi nhãn/nối/source thực trước chốt'
   elif abs(delta)+unc<=pt['tolerance_H_m']:status='ỨNG VIÊN ĐẠT';reason='Khoảng đo nằm trong ngưỡng, cần soi nối đúng nhãn thực trước chốt'
   else:status='CHƯA THỂ XÁC MINH';reason='Tâm đo và biên bất định còn giao ngưỡng; không chốt từ tâm riêng'
   pt.update({'status_pending_visual':status,'reason':reason,'nearby_reader_branch_ambiguities':nearissues});rowsall.append(pt)
 # Unretouched source sections at each distinct unresolved Q, for visual QA.
 section_files=[]
 qs=sorted(set(p['Q_m3_h'] for p in rowsall if p['Q_source_native_u'] is not None))
 for q in qs:
  p=next(p for p in rowsall if p['Q_m3_h']==q);x=p['Q_source_native_u'];fa=next(z for z in base['graphs'] if z['family']==family)['axis']['frame_native'];box=[max(0,int(math.floor(x))-7),max(0,int(fa['top'])-3),min(rgb.shape[1],int(math.ceil(x))+8),min(rgb.shape[0],int(fa['bottom'])+4)];f=O/f'g01_{family}_Q{q:g}_TIET DIEN NGUON KHONG CHINH PIXEL.png';Image.fromarray(rgb[box[1]:box[3],box[0]:box[2]]).save(fresh(f));section_files.append({'Q_m3_h':q,'native_bbox':box,'path':str(f),'sha256':sha(f)})
 out.append({'page':g['page'],'family':family,'source_Q_local_ticks':xt,'source_H_local_ticks':yt,'points':rowsall,'raw_source_sections':section_files,'counts_pending_visual':dict(collections.Counter(p['status_pending_visual'] for p in rowsall))});print('SECTIONS2',family,out[-1]['counts_pending_visual'],flush=True)
fp=Path(fresh(O/'g01_DO MOC TU TIET DIEN MUC THUC VA VACH ETA - V2 CHO DOC NHAN.json'));fp.write_text(json.dumps({'source':src,'source_sha256':sha(src),'current':dst,'current_sha256':sha(dst),'read_only':True,'PDF_written':False,'source_pixel_retouched':False,'original_source_JPEG_current_preserved':pres,'raw_ink_profiles':True,'method':'Tiết diện luminance trực tiếp tại đúng Q trên JPEG nguyên, kể cả tâm xám; thước từng khoảng vạch ETA thực, H vạch thực. H bảng chỉ đem so sau khi khóa nét. Biên bảo thủ gồm nửa bề dày FWHM,0.5px nguồn,0.5pxvạchH và Q theo tiếp tuyến, riêng83/167lmin6SA35 thêm làm tròn. Không gán nhiều ứng viên theo H gần nhất.','all_statuses_pending_visual':True,'graphs':out},ensure_ascii=False,indent=2,default=lambda z:z.item() if isinstance(z,np.generic) else z.tolist()),encoding='utf8');E.close();E2.close();print('FILE',str(fp),'SHA',sha(fp),'COUNT',dict(collections.Counter(p['status_pending_visual'] for g in out for p in g['points'])))
