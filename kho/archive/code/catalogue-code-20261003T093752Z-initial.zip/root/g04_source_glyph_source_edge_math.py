"""Pure geometry: one common colour, own-source edges; never mass-tighten."""
import numpy as np
import cv2
from scipy.ndimage import gaussian_filter,maximum_filter,label,binary_fill_holes,binary_closing,distance_transform_edt
from scipy.optimize import linear_sum_assignment
from scipy.interpolate import splprep,splev
from scipy.spatial import cKDTree
from g04_source_glyph_core_math import topology,hole_centres,signed_area,source_linear_stroke
from g04_source_glyph_vector_math import rounded_loop

def sample_path(path,count=32):
    out=[];cur=first=None
    for op,ps in path:
        if op=='m':cur=np.array(ps[0]);first=cur.copy();out.append(cur)
        elif op=='l':
            q=np.array(ps[0]);out.extend(np.linspace(cur,q,8)[1:]);cur=q
        elif op=='c':
            p=np.array(ps);t=np.linspace(0,1,count)[1:,None]
            q=(1-t)**3*cur+3*(1-t)**2*t*p[0]+3*(1-t)*t**2*p[1]+t**3*p[2]
            out.extend(q);cur=p[2]
        elif op=='h':out.extend(np.linspace(cur,first,8)[1:]);cur=first
    return np.array(out,float)

def smooth_loop(c,up=8,pad=8,curvy=True):
    raw=c[:,0,:].astype(float)/up+.5/up
    if len(raw)<5:return None
    # Pixel-boundary-centre displacement is within 1/up of a600pixel. For a
    # clean font edge use a small periodic cubic fit, preserving this contour.
    closed=np.vstack([raw,raw[0]])
    if curvy:
        best=None
        for sigma in [.4,.7,1.,1.3]:
            try:tck,u=splprep(closed.T,s=len(closed)*sigma**2,per=True,k=3)
            except ValueError:continue
            knots=tck[0];inside=sorted(set(float(x) for x in knots if 0<=x<=1))
            path=[]
            for j,(lo,hi) in enumerate(zip(inside[:-1],inside[1:])):
                p0=np.array(splev(lo,tck));p3=np.array(splev(hi,tck));d0=np.array(splev(lo,tck,der=1));d1=np.array(splev(hi,tck,der=1))
                if j==0:path.append(('m',[(p0-pad).tolist()]))
                path.append(('c',[(p0+d0*(hi-lo)/3-pad).tolist(),(p3-d1*(hi-lo)/3-pad).tolist(),(p3-pad).tolist()]))
            path.append(('h',[]));pp=sample_path(path)+pad
            distance=max(float(cKDTree(raw).query(pp)[0].max()),float(cKDTree(pp).query(raw)[0].max()))
            if distance<=1.75:
                best=dict(path=path,spline_sigma_px600=sigma,max_contour_fit_error_px600=distance,cubic_segments=len(inside)-1)
        if best:return best
    p=rounded_loop(c,up=up,epsilon=.7,radius=1.5)
    if not p:return None
    p=[(op,[[x-pad,y-pad] for x,y in ps]) for op,ps in p]
    pp=sample_path(p)+pad
    distance=max(float(cKDTree(raw).query(pp)[0].max()),float(cKDTree(pp).query(raw)[0].max()))
    return dict(path=p,spline_sigma_px600=None,max_contour_fit_error_px600=distance,cubic_segments=sum(op=='c' for op,_ in p))

def source_edge_glyph(alpha,expected_topology,core_gray=63,curvy=True,pad=8,up=8):
    a=np.asarray(alpha,float);A=np.pad(a,pad);parts,n=label(A>=.085);assert n==expected_topology[0]
    colorcoverage=1-core_gray/255;out=[]
    for k in range(1,n+1):
        aa=np.where(parts==k,A,0.);source_mass=float(aa.sum());z=gaussian_filter(aa,.75)
        desired=(1,expected_topology[1] if n==1 else 0)
        sh=hole_centres(aa>=.085,largest=desired[1]) if desired[1] else np.zeros((0,2));assert len(sh)==desired[1]
        support_fine=cv2.resize((aa>=.085).astype('uint8'),(A.shape[1]*up,A.shape[0]*up),interpolation=cv2.INTER_NEAREST).astype(bool)
        source_distance=distance_transform_edt(~support_fine)/up
        sy,sx=np.where(aa>=.085);source_box=np.array([sx.min(),sy.min(),sx.max()+1,sy.max()+1],float)
        candidates=[]
        for kind in ['direct','local']:
            field=z/max(float(z.max()),1e-12) if kind=='direct' else z/np.maximum(maximum_filter(z,size=9),1e-7)
            for t in np.arange(.10,.651,.025):
                for close in [0,3]:
                    mask=(field>=t)&(z>.04)
                    if close:mask=binary_closing(mask,structure=np.ones((close,close),bool))&(A>.03)
                    if topology(mask)!=desired:continue
                    fine=cv2.resize(mask.astype('uint8'),(A.shape[1]*up,A.shape[0]*up),interpolation=cv2.INTER_NEAREST)
                    cs,hi=cv2.findContours(fine,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
                    if hi is None:continue
                    loops=[];area=0.;maxfit=0.
                    for j,c in enumerate(cs):
                        q=smooth_loop(c,up=up,pad=pad,curvy=curvy)
                        if q is None:continue
                        depth=0;pp=hi[0,j,3]
                        while pp>=0:depth+=1;pp=hi[0,pp,3]
                        ar=abs(signed_area(q['path']));area+=ar*(-1 if depth%2 else 1)
                        q.update(tree_depth=depth,foreground=depth%2==0,area_px=ar);loops.append(q);maxfit=max(maxfit,q['max_contour_fit_error_px600'])
                    if not loops:continue
                    # Check the smoothed *actual* geometric fill, not merely the
                    # initial bitmap. Topology and counter position are guards.
                    poly=[np.rint((sample_path(q['path'])+pad)*up).astype('int32') for q in loops]
                    fm=np.zeros_like(fine);cv2.fillPoly(fm,poly,1);fm=fm>0
                    if topology(fm)!=desired:continue
                    nh=hole_centres(fm)/up;ce=0.
                    if len(sh):
                        cost=np.linalg.norm(nh[:,None,:]-sh[None,:,:],axis=2);rr,cc=linear_sum_assignment(cost);ce=float(cost[rr,cc].max())
                        if ce>4.:continue
                    outer=float(source_distance[fm].max());y,x=np.where(fm)
                    nb=np.array([x.min()/up,y.min()/up,(x.max()+1)/up,(y.max()+1)/up]);be=float(abs(nb-source_box).max())
                    if outer>4. or be>4.:continue
                    pred=gaussian_filter(fm.astype(float)*colorcoverage,1.3*up)
                    obs=cv2.resize(aa.astype('float32'),(A.shape[1]*up,A.shape[0]*up),interpolation=cv2.INTER_CUBIC)
                    residual=float(np.mean((pred-obs)**2))
                    # Geometry/counters and near-half local coverage come first.
                    # There is no target for total mass and no erode/dilate step.
                    score=abs(t-.5)*.04+ce*.005+be*.001+residual*12+(kind=='local')*.001+(close>0)*.001
                    candidates.append(dict(kind=kind,coverage_threshold=float(t),close_px600=close,
                        boundary_offset_px600=0.,no_optical_mass_tightening=True,loops=loops,loop_area_px=area,
                        source_mass_px=source_mass,relative_math_ink_error=float(area*colorcoverage/source_mass-1),
                        source_counter_centres=(sh-pad).tolist(),candidate_counter_centres=(nh-pad).tolist(),counter_centroid_error_px600=ce,
                        extra_ink_distance_from_source_support_px600=outer,bbox_error_px600=be,max_contour_fit_error_px600=maxfit,
                        coarse_source_ink_residual=residual,topology=list(desired),score=score))
        if not candidates:raise ValueError('No faithful source-edge contour for part '+str(k))
        best=min(candidates,key=lambda x:x['score']);best.update(source_part=k,other_candidates=len(candidates));out.append(best)
    return dict(core_gray=core_gray,opacity=1.,source_core_coverage=colorcoverage,source_area_px=float(a.sum()),
        vector_optical_area_px=float(sum(p['loop_area_px'] for p in out)*colorcoverage),expected_topology=list(expected_topology),parts=out,
        physical_scale=1.,source_pixel_pt=.12,no_external_font=True,no_gray_band_layers=True,no_image_SMask=True,
        no_mass_tightening=True,source_native_pixel_uncertainty_pt=.4801362852213916)
