"""Different source-glyph extraction: tight manual boxes, grayscale, no PDF sample."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
words=json.loads((root/'CHU NGUON ALPHA THU DO DOC V2.json').read_text(encoding='utf8'))
other=json.loads((root/'GLYPH TRANG4 VA5 TOA DO THUC.json').read_text(encoding='utf8'))
source=plan['method']['source'];current=plan['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(source),sha(current)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(source,backend='fitz');R=Raster(E);cv8=R.render_canvas(7,words['source_rect'],dpi=600);wordmap={p['model']:p for p in words['records']}
cvs={8:cv8}
o3=next(p for p in other['records'] if p['name']=='3 TU NHAN 4SL3_62');o5=next(p for p in other['records'] if p['name']=='5 TU NHAN 4SL3_35')
cv3=R.render_canvas(4,o3['rect'],dpi=600);cv5=R.render_canvas(4,o5['rect'],dpi=600)
raw={'4':('4SL16/23',18,45),'S':('4SL16/20',44,76),'L':('4SL16/23',76,104),'1':('4SL16/20',102,121),'6':('4SL16/16',120,147),'/':('4SL16/12',145,160),'2':('4SL16/20',156,180),'0':('4SL16/20',180,205),'8':('4SL16/18',180,205),'9':('4SL16/9',156,184)}
inputs=[]
for char,(word,x0,x1) in raw.items():
 _,y0,_,y1=wordmap[word]['source_render_rect'];inputs.append((char,word,8,cv8,[x0,y0,x1,y1]))
inputs.extend([('3','4SL3/62 (số3 sau L)',5,cv3,[115,38,143,80]),('5','4SL3/35 (số5 cuối)',5,cv5,[174,40,199,82])])
pic=Image.new('RGB',(920,12*112),'white');dr=ImageDraw.Draw(pic);records=[]
for i,(ch,word,page,cv,b) in enumerate(inputs):
 x0,y0,x1,y1=b;a=cv.orig[y0:y1,x0:x1].astype(float);g=a@np.array([.299,.587,.114]);core=g<125
 # Core never uses expected letter contour. Manual source rectangle ensures one real glyph.
 assert core.any(),ch;ys,xs=np.nonzero(core);loy,hiy=max(0,int(ys.min())-2),min(len(g),int(ys.max())+3);lox,hix=max(0,int(xs.min())-2),min(g.shape[1],int(xs.max())+3)
 a=a[loy:hiy,lox:hix];g=g[loy:hiy,lox:hix];core=g<125
 candidate=g<232;components,n=label(candidate);keep=np.zeros_like(candidate)
 for k in range(1,n+1):
  m=components==k
  if (m&core).any():keep|=m
 alpha=(1-g/255)*keep
 gray=Image.fromarray((255*(1-alpha)).round().clip(0,255).astype('uint8')).convert('RGB');src=Image.fromarray(a.round().astype('uint8'))
 dr.text((5,i*112+8),ch+' from '+word,fill='blue');pic.paste(src.resize((src.width*2,src.height*2),Image.Resampling.NEAREST),(225,i*112+12));pic.paste(gray.resize((gray.width*2,gray.height*2),Image.Resampling.NEAREST),(430,i*112+12));dr.text((650,i*112+20),f'{alpha.shape[1]}x{alpha.shape[0]} px',fill='blue')
 px=[x0+lox,y0+loy,x0+hix,y0+hiy];pg=[*cv.to_page(px[0],px[3]),*cv.to_page(px[2],px[1])]
 records.append(dict(character=ch,source_page=page,source_word=word,source_canvas_rect=list(cv.rect0),source_render_glyph_box=px,source_page_glyph_box=pg,source_true_alpha=alpha.tolist(),source_glyph_height_pt=alpha.shape[0]*72/600,source_glyph_width_pt=alpha.shape[1]*72/600,original_dpi=150,extract_dpi=600,physical_scale_unchanged=True,new_font=False,status='Chữ thật trong chính Redpump; chưa vector hóa hoặc vẽ mẫuPDF.'))
photo=fresh(root/'GLYPH NGUON CHON LAI GRAYSCALE CUNG FILE.png');pic.save(photo)
out=dict(source=source,source_SHA256=before[0],current_SHA256=before[1],records=records,source_glyph_bank_uniform_per_character=True,samefile_pages=[5,8],font_family_not_named='Nhãn nguồn ảnh, không có metadatafont. So kiểu/nét/cỡ nguyênởảnh donor; khônggọiArial khi chưa chứngminh.',source_glyph_proof_photo=photo,prior_neutral_only_bank_rejected=True,PDF_sample_written=False,contour_vectorized=False,planned_sharp_glyph_method='Mỗi glyph trongbank dùngchungcho13tên. Nếu cần nétPDF, lấybiên mực từalpha thật; kiểmholes/bềdày/cỡ ±ngưỡng trước áp dụng, khôngtrơn làm mấtcấu trúchoặc dựng lại theo fontngoài.',status='NGUỒN GLYPH ĐƯỢC CHỌN LẠI; phải soi hình đủ0/6/8/9 và3/5 trước khóa dùng.')
Path(fresh(root/'GLYPH NGUON CHON LAI GRAYSCALE CUNG FILE.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(source),sha(current)]
print('Source clean-box grayscale glyph bank saved; no PDF sample',flush=True)
