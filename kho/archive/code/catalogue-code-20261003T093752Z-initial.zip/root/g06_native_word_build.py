from catwork import start,fresh
S,D,N=start()
from catfix.raster import Raster
from catfix.vector import Editor
from catfix.recipes import Job
from catfix.cs import Name,Num,Instr
from catfix import verify,ocr
from g06_word_tools import grid_mask,word_piece,scaled_piece,LABELS
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,cv2,json,hashlib,zlib,sys

root=Path(S.report('G06'));name='Aquaris FS_300dpi_75% (bản mới).pdf'
src,prior=S.src(name),S.dst(name);trial=sys.argv[1] if len(sys.argv)>1 else '1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
probe=json.loads((root/'review'/'word-copy-source-geometry.json').read_text(encoding='utf-8'))
plan=json.loads((root/'review'/'word-copy-plan.json').read_text(encoding='utf-8'))
geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
old=json.loads((root/'final-state-v2.json').read_text(encoding='utf-8'))
assert sha(src)==probe['source_sha256'] and sha(prior)==probe['prior_sha256']
stage=fresh(root/'review'/f'native-word-mau-{trial}.pdf')
j=Job(src,stage,log_path=fresh(root/'review'/f'native-word-mau-{trial}.log.json'));j.E.close();j.E=Editor(prior);j.edits=old['final_edits'].copy()
base=Editor(src);RS=Raster(base);sourcecv=RS.canvas(RS.image_at(3,base.mediabox(3)))
cv=j.R.canvas(j.R.image_at(3,j.E.mediabox(3)))
assert np.array_equal(sourcecv.orig,cv.orig)
grid,grecs=grid_mask(sourcecv,geo)
protected=cv2.dilate(grid.astype(np.uint8),np.ones((7,7),np.uint8)).astype(bool)
if trial=='2':
    # Theo đúng tọa độ ảnh gốc: đường ngang có vùng mờ rộng hơn đường dọc.
    # Giữ 4px quanh đường ngang, 2px quanh đường dọc; không giữ nhầm nét C/d cạnh lưới.
    protected=np.zeros(grid.shape,bool)
    for g,rec in zip(geo['grids'],grecs):
        x0,y0,x1,y1=map(int,cv.box(g['rect']))
        for x in rec['vertical_pixels']:protected[max(0,y0-6):min(protected.shape[0],y1+6),max(0,x-2):min(protected.shape[1],x+3)]=True
        for y in rec['horizontal_pixels']:protected[max(0,y-4):min(protected.shape[0],y+5),max(0,x0-6):min(protected.shape[1],x1+6)]=True
changes=[];placements=[];patches=[];word_proof=[];tiles=[]
targetcap=23.0
for rp in plan['rows']:
    rr=next(r for r in probe['rows'] if r['row']==rp['row']);labels=LABELS[rr['row']]
    ws=[w for w in rr['words'] if any(c.isalpha() for c in w['text'])]
    pieces=[word_piece(sourcecv,RS,w,rr['box'],grid,label) for w,label in zip(ws,labels)]
    factor=targetcap/rp['cap'];scaled=[scaled_piece(p,factor,rp['baseline']) for p in pieces]
    oldmask=np.zeros(cv.work.shape[:2],np.uint8)
    for p in pieces:
        quang=6 if trial=='2' else 2
        x0,y0,x1,y1=p['box'];x0=max(0,x0-quang);y0=max(0,y0-quang);x1=min(oldmask.shape[1],x1+quang);y1=min(oldmask.shape[0],y1+quang)
        oldmask[y0:y1,x0:x1]|=np.any(sourcecv.orig[y0:y1,x0:x1]<255,axis=2).astype(np.uint8)
    erase=cv2.dilate(oldmask,np.ones((5,5),np.uint8)).astype(bool)&~protected
    j.R.erase(cv,mask=erase,color=(255,255,255),dilate=0)
    groups=[[0,1,2,3],[4,5,6,7]] if rr['row'] in (5,13) else [[0,1,2],[3,4]] if rr['row'] in (15,18) else [[0,1,2]]
    widths=[sum(scaled[i]['alpha'].shape[1] for i in group)+sum(max(2,(pieces[b]['box'][0]-pieces[a]['box'][2])*factor) for a,b in zip(group,group[1:])) for group in groups]
    cell=rr['rect'];cb=cv.box(cell);asc=[max(scaled[i]['alpha'].shape[0]-scaled[i]['boff'] for i in group) for group in groups];desc=[max(scaled[i]['boff'] for i in group) for group in groups]
    leading=targetcap*1.42;height=asc[0]+leading*(len(groups)-1)+desc[-1];base0=(cb[1]+cb[3]-height)/2+asc[0]
    rowboxes=[];lines=[]
    for li,group in enumerate(groups):
        assert widths[li] <= cb[2]-cb[0]-24
        u=min(pieces[0]['box'][0],cb[2]-12-widths[li]) if rr['row']==28 else (cb[0]+cb[2]-widths[li])/2
        baseline=base0+li*leading;boxes=[]
        for pos,i in enumerate(group):
            g=scaled[i];v=baseline+g['boff']-g['alpha'].shape[0]
            b=(round(u),round(v),round(u)+g['alpha'].shape[1],round(v)+g['alpha'].shape[0]);assert b[0]>=cb[0]+3 and b[2]<=cb[2]-3 and b[1]>=cb[1]+3 and b[3]<=cb[3]-3
            assert not protected[b[1]:b[3],b[0]:b[2]].any()
            if trial=='2':
                # Đặt mực nguyên từ trên giấy trắng tại chính mặt nạ mực mới;
                # không thêm lớp tối do nền JPEG cũ dưới nét mới, không phủ ô chữ nhật.
                targetmask=np.zeros(cv.work.shape[:2],bool)
                targetmask[b[1]:b[3],b[0]:b[2]]=g['alpha']>0
                j.R.erase(cv,mask=targetmask,color=(255,255,255),dilate=0)
            j.R.stamp(cv,g,u,v,ink=np.zeros(3,np.float32));boxes.append(b);rowboxes.append(list(cv.rect(b)))
            alpha=g['alpha'];expected=(255*(1-alpha)).round().clip(0,255).astype(np.uint8)
            actual=cv.work[b[1]:b[3],b[0]:b[2]].min(axis=2)
            p=pieces[i];proof=dict(row=rr['row'],word=g['text'],source_box=list(p['box']),source_rect=list(sourcecv.rect(p['box'])),
                source_rgb_sha256=hashlib.sha256(sourcecv.orig[p['box'][1]:p['box'][3],p['box'][0]:p['box'][2]].tobytes()).hexdigest(),
                source_alpha_sha256=hashlib.sha256(p['alpha'].tobytes()).hexdigest(),scaled_alpha_sha256=hashlib.sha256(alpha.tobytes()).hexdigest(),
                whole_word_scaled=True,factor=factor,destination_box=list(b),destination_rect=list(cv.rect(b)),expected_ink_pixels_exact=bool(np.array_equal(actual[alpha>0],expected[alpha>0])),
                actual_destination_rgb_sha256=hashlib.sha256(cv.work[b[1]:b[3],b[0]:b[2]].tobytes()).hexdigest(),
                maximum_gray_delta_from_original_word_scale=int(np.abs(actual.astype(int)-expected.astype(int))[alpha>0].max()))
            word_proof.append(proof);placements.append(proof.copy())
            oldim=Image.fromarray((255*(1-p['alpha'])).round().astype(np.uint8)).convert('RGB');newim=Image.fromarray(actual).convert('RGB')
            # Về cùng cỡ bằng phép phóng nguyên từ; ảnh chứng cứ giữ cả hình nguồn riêng.
            oldim=oldim.resize((max(1,round(oldim.width*factor)),max(1,round(oldim.height*factor))),Image.Resampling.BICUBIC)
            tile=Image.new('RGB',(max(oldim.width,newim.width)*2+30,max(oldim.height,newim.height)+20),'white');dr=ImageDraw.Draw(tile);dr.text((0,0),f'row{rr["row"]} {g["text"]}',fill='black');tile.paste(oldim,(0,20));tile.paste(newim,(max(oldim.width,newim.width)+30,20));tiles.append(tile)
            u+=alpha.shape[1]
            if pos+1<len(group):u+=max(2,(pieces[group[pos+1]]['box'][0]-pieces[i]['box'][2])*factor)
        box=(min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes))
        lines.append(dict(text=' '.join(scaled[i]['text'] for i in group),bbox_page=list(cv.rect(box)),baseline_native_px=baseline))
    cv.work[protected]=cv.orig[protected]
    rownew=[min(b[0] for b in rowboxes),min(b[1] for b in rowboxes),max(b[2] for b in rowboxes),max(b[3] for b in rowboxes)]
    # Chỉ mực từ cũ + quầng của từ và mực từ mới. Không xoá nền ô.
    changed=np.any(cv.work!=cv.orig,axis=2)
    rowregion=np.zeros_like(changed);rowregion[cb[1]:cb[3],cb[0]:cb[2]]=True
    # Quầng hai bên chữ cũ có thể vượt lòng ô; vẫn phải nằm ngoài mọi lưới bảo vệ.
    rrregion=cv2.dilate(rowregion.astype(np.uint8),np.ones((9,9),np.uint8)).astype(bool)
    mask=(changed|erase)&rrregion&~protected
    ys,xs=np.where(mask);bbox=(int(xs.min()),int(ys.min()),int(xs.max())+1,int(ys.max())+1)
    x0,y0,x1,y1=bbox;mm=mask[y0:y1,x0:x1];face=cv.work[y0:y1,x0:x1].copy();face[~mm]=255;h,w=mm.shape;doc=j.E.doc
    sm=doc.new_image_xobject(zlib.compress((mm.astype(np.uint8)*255).tobytes(),9),w,h,Name('DeviceGray'),8,'FlateDecode')
    ref=doc.new_image_xobject(zlib.compress(face.tobytes(),9),w,h,Name('DeviceRGB'),8,'FlateDecode',smask=sm);nm=j.R._register(3,ref)
    xleft,ytop=cv.to_page(x0,y0);xright,ybottom=cv.to_page(x1,y1);mtx=[Num(xright-xleft),Num(0),Num(0),Num(ytop-ybottom),Num(xleft),Num(ybottom)]
    j.E.insert_instrs(3,len(j.E.page(3).ops)-1,[Instr([],'q'),Instr(mtx,'cm'),Instr([Name(nm)],'Do'),Instr([],'Q')],before=False)
    changes.append(dict(task=53,page=4,row=rr['row'],rect=list(cell),new_rect=rownew,old=' '.join(labels),new='\n'.join(z['text'] for z in lines),lines=lines,
        source_cap_px=rp['cap'],target_cap_px=targetcap,factor=factor,grid_pixels_exactly_equal=bool(np.array_equal(cv.work[protected],cv.orig[protected]))))
    patches.append(dict(row=rr['row'],page=4,name=str(nm),native_box=list(bbox),rect=list(cv.rect(bbox)),masked=True,erase_word_pixels=int(erase.sum()),
        ink_pixels_inside_grid_guard=int((oldmask.astype(bool)&protected).sum()),transparent_pixels=int((~mm).sum())))
    j._add(3,list(cell),f'#53 dòng{rr["row"]}: nguyên từ/ảnh gốc, mặt nạ mực từ, giữ lưới','native-word-mask')
    print('ROW',rr['row'],'scale',factor,'old ink inside grid guard',patches[-1]['ink_pixels_inside_grid_guard'],flush=True)
    # Reset only baseline for tiny-patch collection; no JPEG re-encode via R.commit.
    cv.orig=cv.work.copy()
base.close();j.save();ck=j.check(raster=True)
outside=verify.outside_pixels(prior,stage,{4:[[c['rect'][0]-1,c['rect'][1]-1,c['rect'][2]+1,c['rect'][3]+1] for c in changes]},dpi=200,pad=0,thr=0,min_size=0)
for c in changes:c['ocr_after']=' '.join(w['text'] for w in ocr.image_words(verify.crop(stage,3,c['rect'],600),psm=6))
for dpi in (400,500,600):verify.compare_sheet(prior,stage,[(3,c['rect'],f'#53 row{c["row"]}') for c in changes],fresh(root/'review'/f'native-word-mau-{trial}-{dpi}dpi.png'),dpi=dpi,pad=(2,1))
verify.compare_sheet(prior,stage,[(3,(286,382,559,697),'#53 nguyên từ/ảnh gốc; toàn bảng')],fresh(root/'review'/f'native-word-toan-bang-{trial}.png'),dpi=400,pad=(0,0))
atlas=Image.new('RGB',(max(t.width for t in tiles),sum(t.height+6 for t in tiles)),'white');y=0
for t in tiles:atlas.paste(t,(0,y));y+=t.height+6
atlas.resize((atlas.width*2,atlas.height*2),Image.Resampling.NEAREST).save(fresh(root/'review'/f'native-word-nguyen-tu-chung-cu-{trial}.png'))
data=dict(source=src,prior=prior,stage=stage,source_sha256=sha(src),prior_sha256=sha(prior),stage_sha256=sha(stage),changes=changes,placements=placements,
    word_proof=word_proof,patches=patches,check=ck,outside_new_200dpi=outside,edits=j.edits,native_grid_guard=dict(horizontal_px=4,vertical_px=2) if trial=='2' else dict(horizontal_px=4,vertical_px=4),
    method='Phương pháp khác: thao tác tọa độ điểm ảnh gốc; mặt nạ đúng mực/quầng từng từ, bảo vệ toàn lưới gốc, không quét xoá nền ô; chép nguyên 29 từ, co/phóng đồng tỷ lệ.')
json.dump(data,open(fresh(root/'review'/f'native-word-build-{trial}.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=lambda x:x.item() if hasattr(x,'item') else str(x))
j.close();print('CHECK',ck['ok'],'outside',outside,'word proof',all(w['expected_ink_pixels_exact'] for w in word_proof),flush=True)
