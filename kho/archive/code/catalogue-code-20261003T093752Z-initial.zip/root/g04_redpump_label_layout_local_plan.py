"""Plan thirteen source-font ink boxes around locally mapped curves; no PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.interpolate import PchipInterpolator
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));axis=json.loads((root/'104 NEO QH ANH XA VACH THUC CUC BO V1.json').read_text(encoding='utf8'));labels=json.loads((root/'13 NHAN THAT CUNG BO SNAPSHOT V5 DAY DU.json').read_text(encoding='utf8'));fr=json.loads((root/'KHUNG LUOI THAT NGUON TRANG8.json').read_text(encoding='utf8'));gr=json.loads((root/'LUOI MO DOC MEDIAN NGUON TRANG8.json').read_text(encoding='utf8'));src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[axis['source_SHA256'],axis['current_SHA256']]
frame=next(z for z in fr['panels'] if z['name']=='QH')['frame_page_bbox'];grid=next(z for z in gr['records'] if z['name']=='QH');vy=sorted([z['source_page_y'] for z in grid['horizontal_inner_grid'] if z['peak_native_v']!=219]);vx=sorted(grid['vertical_inner_grid_page']);assert len(vy)==5
curves={z['model']:PchipInterpolator([a['page_xy'][0] for a in z['anchors']],[a['page_xy'][1] for a in z['anchors']],extrapolate=False) for z in axis['records']};labelmap={z['model']:z for z in labels['records']};names=[z['model'] for z in reversed(axis['records'])];curve_half=.95/2;grid_half=.65/2;frame_half=.63/2;clear=.5
def ranges(fun,l,r):
 pts=[l,r];rr=fun.derivative().roots(extrapolate=False);pts.extend(float(p) for p in rr if l<p<r);ys=fun(pts);return float(min(ys)),float(max(ys))
def distance_y(box,lo,hi):
 return max(lo-box[3],box[1]-hi,0.)
def check_box(name,b):
 x0,y0,x1,y1=b;errors=[];dist=[]
 if min(x0-frame[0],frame[2]-x1,y0-frame[1],frame[3]-y1)<frame_half+clear:return None
 for x in vx:
  dx=max(x0-x,x-x1,0.)-grid_half
  if dx<clear-1e-9:return None
  dist.append(dict(kind='vertical_grid',at=x,clearance_pt=dx))
 for y in vy:
  dy=max(y0-y,y-y1,0.)-grid_half
  if dy<clear-1e-9:return None
  dist.append(dict(kind='horizontal_grid',at=y,clearance_pt=dy))
 for code,fun in curves.items():
  lo,hi=ranges(fun,x0,x1);dd=distance_y(b,lo,hi)-curve_half
  if dd<clear-1e-9:return None
  dist.append(dict(kind='curve',model=code,physical_y_range=[lo,hi],clearance_pt=dd))
 xm=(x0+x1)/2;ym=(y0+y1)/2;center=sorted([(abs(float(f(xm))-ym),code) for code,f in curves.items()]);own=next(z[0] for z in center if z[1]==name);other=min(z[0] for z in center if z[1]!=name)
 if own+.2>other:return None
 return dict(distances=dist,min_clearance_pt=min(z['clearance_pt'] for z in dist),own_vs_other_center_distance_pt=[own,other],physical_box=b,unique_closest_curve=name)
candidates={}
for name in names:
 w,h=labelmap[name]['physical_ink_box_size_pt'];cc=[]
 for bay,(left,right) in enumerate([(64.,vx[0]-grid_half-clear),(vx[0]+grid_half+clear+1.,vx[1]-grid_half-clear),(vx[1]+grid_half+clear+1.,vx[2]-grid_half-clear)]):
  for x0 in np.arange(left,right-w+.001,.3):
   x1=x0+w;lo,hi=ranges(curves[name],x0,x1)
   for side in ['above','below']:
    y0=hi+curve_half+clear if side=='above' else lo-curve_half-clear-h;b=[float(x0),float(y0),float(x1),float(y0+h)];checked=check_box(name,b)
    if checked:cc.append(dict(model=name,bay=bay+1,relative_to_own_curve=side,**checked))
 candidates[name]=sorted(cc,key=lambda z:(z['bay'],z['relative_to_own_curve']=='below',z['physical_box'][0]))
 print(name,'layout choices',len(cc),flush=True)
assert all(candidates.values()),[(n,len(z)) for n,z in candidates.items()]
def boxes_clear(a,b):
 return max(a[0]-b[2],b[0]-a[2],a[1]-b[3],b[1]-a[3])>=clear
order=sorted(names,key=lambda n:len(candidates[n]));chosen={}
def solve(i):
 if i==len(order):return True
 name=order[i]
 for z in candidates[name]:
  if all(boxes_clear(z['physical_box'],c['physical_box']) for c in chosen.values()):
   chosen[name]=z
   if solve(i+1):return True
   del chosen[name]
 return False
assert solve(0),'No nonoverlapping complete label layout'
records=[]
for n in names:
 z=chosen[n];ib=labelmap[n]['inkbox600'];x0,y0,x1,y1=z['physical_box'];z.update(source_alpha_word_file=str(root/'13 NHAN THAT CUNG BO SNAPSHOT V5 DAY DU.json'),source_alpha_word_inkbox600=ib,source_word_array_page_origin=[x0-ib[0]*.12,y1+ib[1]*.12],physical_scale=1.,font_status='Bộ chữ nguồn đã có đủ tên, chưa nghiệm thu độ sắc trong PDF. Không font ngoài.',render_status='CHỈ BỐ TRÍ, chưa có PDF mẫu.');records.append(z)
E=Editor(src,backend='fitz');R=Raster(E);cv=R.render_canvas(7,(45,318,359,513),dpi=300);image=Image.fromarray(cv.orig);dr=ImageDraw.Draw(image)
for i,z in enumerate(records,1):
 x0,y0,x1,y1=z['physical_box'];a=cv.to_px(x0,y1);b=cv.to_px(x1,y0);dr.rectangle([*a,*b],outline=(180,0,180),width=2);dr.text((a[0],a[1]-12),str(i),fill=(180,0,180))
photo=fresh(root/'13 HOP NHAN SNAPSHOT V2 TREN NGUON KHONG LA MAU.png');image.save(photo)
out=dict(source_SHA256=before[0],current_SHA256=before[1],source_axis_local_file=str(root/'104 NEO QH ANH XA VACH THUC CUC BO V1.json'),names_count=len(records),records=records,source_marked_planned_bbox_photo=photo,font_raw_source_only=True,minimum_curve_grid_clearance_pt=min(z['min_clearance_pt'] for z in records),minimum_font_scale=1.,candidate_count={n:len(z) for n,z in candidates.items()},horizontal_grid_page_y_used=vy,vertical_grid_page_x_used=vx,excluded_title_bottom_native_v=219,planning_rule='Không đặt chữ vào khe đứt: tránh toàn đường toán học, cả những đoạn không có mực vì nét đứt. Tâm nhãn phải gần chính đường mang mã hơn mọi đường khác ít nhất0,2pt. Bbox mực thật và toàn phần xám của bộ chữ nguồn V4 được kiểm với đường/lưới/khung, không chỉ hộp nominal nhỏ.',clearance_pt=.5,curve_width_pt=.95,grid_width_pt=.65,frame_width_pt=.63,PDF_written=False,status='KẾ HOẠCH 13 NHÃN ĐỦ KHOẢNG CÁCH: không thay cho nghiệm thu chữ/ảnh PDF cuối.')
out['source_font_file']=str(root/'13 NHAN THAT CUNG BO SNAPSHOT V5 DAY DU.json')
out['prior_layout_status']='V1 dùng atlasglyphV4 cũ; V2 tính lại toàn khoảng hở với snapshot glyphV4/atlasV5. GiữV1làm lịch sử.'
Path(fresh(root/'13 HOP NHAN CUC BO SNAPSHOT TRANH DUONG LUOI V2.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('13 label placements; min clearance',out['minimum_curve_grid_clearance_pt'],'noPDF',flush=True)
