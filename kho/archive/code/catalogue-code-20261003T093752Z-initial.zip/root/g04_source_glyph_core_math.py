"""Pure single-core-colour source-contour math; no I/O, PDF, font or brand data."""
import numpy as np
import cv2
from scipy.ndimage import (gaussian_filter,maximum_filter,label,binary_fill_holes,
                          binary_closing,distance_transform_edt)
from scipy.optimize import linear_sum_assignment
from g04_source_glyph_vector_math import rounded_loop

def topology(mask):
    _,n=label(mask)
    _,h=label(binary_fill_holes(mask)&~mask)
    return int(n),int(h)

def hole_centres(mask,largest=None):
    hh,hn=label(binary_fill_holes(mask)&~mask)
    out=[]
    for j in range(1,hn+1):
        y,x=np.where(hh==j);out.append((len(x),[float(x.mean()),float(y.mean())]))
    out=sorted(out,reverse=True)
    if largest is not None:out=out[:largest]
    return np.array([z[1] for z in out],float).reshape(-1,2)

def signed_area(path):
    """Exact Green integral for lines and cubic Beziers in a closed path."""
    total=0.;cur=first=None
    for op,p in path:
        if op=='m':cur=np.array(p[0],float);first=cur.copy()
        elif op in ('l','h'):
            q=np.array(p[0] if op=='l' else first,float)
            total+=float(cur[0]*q[1]-q[0]*cur[1]);cur=q
        elif op=='c':
            p1,p2,p3=np.array(p,float)
            coef=np.array([cur,3*(p1-cur),3*(p2-2*p1+cur),p3-3*p2+3*p1-cur])
            x=coef[:,0];y=coef[:,1];dx=np.arange(1,4)*x[1:];dy=np.arange(1,4)*y[1:]
            z=np.polynomial.polynomial.polysub(np.polynomial.polynomial.polymul(x,dy),
                                             np.polynomial.polynomial.polymul(y,dx))
            total+=float(sum(v/(i+1) for i,v in enumerate(z)));cur=p3
    return total/2

def loops_for_mask(mask,up=8,epsilon=.7,radius=1.5,pad=8):
    cs,h=cv2.findContours(mask.astype('uint8'),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    if h is None:return [],0.
    loops=[];area=0.
    for i,c in enumerate(cs):
        path=rounded_loop(c,up=up,epsilon=epsilon,radius=radius)
        if not path:continue
        depth=0;par=h[0,i,3]
        while par>=0:depth+=1;par=h[0,par,3]
        path=[(op,[[x-pad,y-pad] for x,y in ps]) for op,ps in path]
        ar=abs(signed_area(path));area+=ar*(-1 if depth%2 else 1)
        loops.append(dict(path=path,tree_depth=int(depth),foreground=bool(depth%2==0),area_px=ar))
    return loops,float(area)

def glyph_core_contours(alpha,expected_topology,core_gray=63,pad=8,up=8):
    """Infer half-coverage edges only within the supplied source's uncertainty.

    JPEG local density varies across a stroke. Both direct source coverage and
    coverage relative to its local core are examined. No pre-made glyph outlines
    are used. Disconnected genuine source parts are processed independently.
    """
    a=np.asarray(alpha,float);A=np.pad(a,pad);parts,n=label(A>=.085)
    gray=float(core_gray)/255;opacity=1-gray
    out=[]
    # The provided topology comes from reading this source glyph, not a font.
    desired_component_count,desired_holes=expected_topology
    assert desired_component_count==n
    for k in range(1,n+1):
        aa=np.where(parts==k,A,0.);mass=float(aa.sum());target=mass/opacity
        source_holes=hole_centres(aa>=.085,largest=desired_holes) if desired_holes and n==1 else np.zeros((0,2))
        if desired_holes and n==1:
            assert len(source_holes)==desired_holes,'Source counter reference not locked'
        source_support=aa>=.085
        support_fine=cv2.resize(source_support.astype('uint8'),(A.shape[1]*up,A.shape[0]*up),interpolation=cv2.INTER_NEAREST).astype(bool)
        source_distance=distance_transform_edt(~support_fine)/up
        sy,sx=np.where(source_support);source_box=np.array([sx.min(),sy.min(),sx.max()+1,sy.max()+1],float)
        z=gaussian_filter(aa,.75,mode='constant')
        local=np.maximum(maximum_filter(z,size=9),1e-7);relative=z/local
        candidates=[]
        for kind in ['direct','local']:
            field=(z/max(float(z.max()),1e-7)) if kind=='direct' else relative
            for t in np.arange(.10,.651,.025):
                for close in [0,3]:
                    mask=(field>=t)&(z>.04)
                    if close:
                        closed=binary_closing(mask,structure=np.ones((close,close),bool))
                        # Any bridge must have faint ink in this same source.
                        mask=closed&(A>.03)
                    wanted=(1,desired_holes if n==1 else 0)
                    if topology(mask)!=wanted:continue
                    fine=cv2.resize(mask.astype('uint8'),(mask.shape[1]*up,mask.shape[0]*up),interpolation=cv2.INTER_NEAREST)
                    inside=cv2.distanceTransform(fine,cv2.DIST_L2,cv2.DIST_MASK_PRECISE)
                    outside=cv2.distanceTransform(1-fine,cv2.DIST_L2,cv2.DIST_MASK_PRECISE)
                    field_sd=gaussian_filter((inside-outside)/up,.6*up)
                    # Area adjustment is a boundary-position choice, not glyph
                    # scale/advance. Bound by half a native source pixel.
                    lo,hi=-1.9,1.9
                    for _ in range(12):
                        offset=(lo+hi)/2;newmask=field_sd>=-offset
                        ar=float(newmask.sum()/up**2)
                        if ar<target:lo=offset
                        else:hi=offset
                    offset=(lo+hi)/2;newmask=field_sd>=-offset
                    if topology(newmask)!=wanted:continue
                    loops,ar=loops_for_mask(newmask,up=up,pad=pad)
                    # Refine optical area using the actual cubic fill, not a
                    # binary-mask area alone. The first fast search just seeds it.
                    reflo=max(-1.9,offset-.4);refhi=min(1.9,offset+.4)
                    for _ in range(8):
                        ro=(reflo+refhi)/2;rm=field_sd>=-ro
                        rloops,ra=loops_for_mask(rm,up=up,pad=pad)
                        if ra<target:reflo=ro
                        else:refhi=ro
                    offset=(reflo+refhi)/2;newmask=field_sd>=-offset
                    if topology(newmask)!=wanted:continue
                    loops,ar=loops_for_mask(newmask,up=up,pad=pad)
                    if not loops:continue
                    # Keep counter *positions*, not just their number; a 9 must
                    # not acquire a false lower counter and lose its true top.
                    nh=hole_centres(newmask)/up
                    counter_error=0.
                    if len(source_holes):
                        costs=np.linalg.norm(nh[:,None,:]-source_holes[None,:,:],axis=2)
                        rr,cc=linear_sum_assignment(costs);counter_error=float(costs[rr,cc].max())
                        if counter_error>4.:continue
                    outside_support=float(source_distance[newmask].max())
                    if outside_support>4.:continue
                    yy,xx=np.where(newmask);new_box=np.array([xx.min()/up,yy.min()/up,(xx.max()+1)/up,(yy.max()+1)/up])
                    box_error=float(abs(new_box-source_box).max())
                    if box_error>4.:continue
                    pred=gaussian_filter(newmask.astype(float)*opacity,1.3*up)
                    obs=cv2.resize(aa.astype('float32'),(A.shape[1]*up,A.shape[0]*up),interpolation=cv2.INTER_CUBIC)
                    residual=float(np.mean((pred-obs)**2))
                    err=abs(ar/target-1)
                    # Direct 50% and modest offsets win among mass-equivalent
                    # solutions; local density correction is explicitly logged.
                    score=err*50+residual*100+counter_error*.02+box_error*.005+abs(offset)*.005+abs(float(t)-.5)*.015+(kind=='local')*.001+(close>0)*.001
                    candidates.append(dict(kind=kind,coverage_threshold=float(t),close_px600=close,
                        boundary_offset_px600=float(offset),loop_area_px=float(ar),mass_target_px=target,
                        relative_math_ink_error=float(ar*opacity/mass-1),loops=loops,score=score,
                        topology=list(wanted),foreground_pixel_area=float(newmask.sum()/up**2),
                        source_counter_centres=(source_holes-pad).tolist(),candidate_counter_centres=(nh-pad).tolist(),
                        counter_centroid_error_px600=counter_error,extra_ink_distance_from_source_support_px600=outside_support,
                        bbox_error_px600=box_error,coarse_source_ink_residual=residual))
        if not candidates:
            raise ValueError(f'No source contour preserves part {k} topology in uncertainty')
        best=min(candidates,key=lambda x:x['score']);best.update(source_part=k,source_mass_px=mass,other_candidates=len(candidates))
        out.append(best)
    return dict(core_gray=core_gray,opacity=1.,source_core_coverage=opacity,
        source_area_px=float(a.sum()),vector_optical_area_px=float(sum(p['loop_area_px'] for p in out)*opacity),
        expected_topology=list(expected_topology),parts=out,physical_scale=1.,source_pixel_pt=.12,
        boundary_offset_limit_px600=1.9,contour_simplification_px600=.7,
        corner_rounding_radius_px600=1.5,initial_source_smoothing_px600=.75,
        no_external_font=True,no_gray_band_layers=True,no_image_SMask=True)

def source_linear_stroke(alpha,core_gray=63):
    """Least-squares straight stroke from this source's own row ink centroids."""
    a=np.asarray(alpha,float);ys=np.arange(a.shape[0],dtype=float)+.5
    xs=np.arange(a.shape[1],dtype=float)+.5;weights=a.sum(1)
    keep=weights>.085
    centres=(a@xs)/np.maximum(weights,1e-12)
    coef=np.polyfit(ys[keep],centres[keep],1,w=np.sqrt(weights[keep]))
    ymin=float(ys[keep].min());ymax=float(ys[keep].max())
    p0=np.array([np.polyval(coef,ymin),ymin]);p1=np.array([np.polyval(coef,ymax),ymax])
    delta=p1-p0;length=float(np.linalg.norm(delta));n=np.array([-delta[1],delta[0]])/length
    opacity=1-core_gray/255;target=float(a.sum()/opacity);width=target/length
    p=[p0+n*width/2,p1+n*width/2,p1-n*width/2,p0-n*width/2]
    path=[('m',[p[0].tolist()])]+[('l',[q.tolist()]) for q in p[1:]]+[('h',[])]
    error=np.abs(centres[keep]-np.polyval(coef,ys[keep]))
    return dict(core_gray=core_gray,opacity=1.,source_core_coverage=opacity,source_area_px=float(a.sum()),
        vector_optical_area_px=target*opacity,expected_topology=[1,0],physical_scale=1.,source_pixel_pt=.12,
        stroke_fit_source_row_centres=[[float(y),float(x),float(w)] for y,x,w in zip(ys[keep],centres[keep],weights[keep])],
        source_centroid_line_coefficients=coef.tolist(),centroid_fit_max_error_px600=float(error.max()),
        centroid_fit_RMS_px600=float(np.sqrt(np.average(error**2,weights=weights[keep]))),
        source_stroke_endpoints=[p0.tolist(),p1.tolist()],source_optical_width_px600=width,
        parts=[dict(source_part=1,source_mass_px=float(a.sum()),mass_target_px=target,loop_area_px=target,
            relative_math_ink_error=0.,kind='source_row_centroid_straight_stroke',coverage_threshold=.5,close_px600=0,
            boundary_offset_px600=0.,loops=[dict(path=path,tree_depth=0,foreground=True,area_px=target)],topology=[1,0])],
        no_external_font=True,no_gray_band_layers=True,no_image_SMask=True)
