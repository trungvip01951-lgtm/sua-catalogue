"""Đọc glyph lớn tiêu đề cùngfile để kiểm cầu nối kiểu với caption; chưa font/PDF."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from pathlib import Path
from scipy import ndimage
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/CHU LON TIEU DE CUNG FILE CHI DOC'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);box=[568,189,662,217];raw=cv.orig[189:217,568:662];font=np.array([21.,55.,105.]);bg=np.array([255.,255.,255.]);al=R.alpha_of(raw,bg,font)
lab,num=ndimage.label(al>=.5,np.ones((3,3)));cc=[]
for k,sl in enumerate(ndimage.find_objects(lab),1):
    if sl is None:continue
    y,x=sl;area=int((lab[sl]==k).sum())
    if area<5:continue
    cc.append(dict(box=[568+x.start,189+y.start,568+x.stop,189+y.stop],area=area))
cc.sort(key=lambda r:r['box'][0]);assert len(cc)==5,cc
title=[];montage=[];step=[float(np.linalg.norm(im.ctm[:2,0])/im.W),float(np.linalg.norm(im.ctm[:2,1])/im.H)]
for ch,c in zip('4SA16',cc):
    x0,y0,x1,y1=c['box'];b=[x0-1,y0-1,x1+1,y1+1];aa=R.alpha_of(cv.orig[b[1]:b[3],b[0]:b[2]],bg,font);up=cv2.resize(np.pad(aa,1),((aa.shape[1]+2)*24,(aa.shape[0]+2)*24),interpolation=cv2.INTER_LINEAR);mask=up>=.5
    contours,hi=cv2.findContours(mask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);paths=[]
    for j,co in enumerate(contours):paths.append(dict(points_local_native=((co[:,0,:]+.5)/24-1).tolist(),parent=int(hi[0,j,3]),area_native_px=float(cv2.contourArea(co)/24**2)))
    n=int(ndimage.label(mask,np.ones((3,3)))[1]);il,nh=ndimage.label(~np.pad(mask,1),np.ones((3,3)));outside=set(np.r_[il[0],il[-1],il[:,0],il[:,-1]]);holes=[k for k in range(1,nh+1) if k not in outside]
    ys,xs=np.where(mask);bb=[xs.min()/24-1,ys.min()/24-1,(xs.max()+1)/24-1,(ys.max()+1)/24-1]
    item=dict(character=ch,source_literal_word='4SA16',source_page=8,source_image='X7',source_native_box=b,source_alpha_matrix=aa.tolist(),source_RGB=font.tolist(),source_step_pt=step,
      source_iso_native_bbox=list(map(float,bb)),source_width_pt=float((bb[2]-bb[0])*step[0]),source_height_pt=float((bb[3]-bb[1])*step[1]),source_components=n,source_holes=len(holes),source_paths_for_review=paths,
      caption_font_bridge_not_yet_proved=True,new_catalogue_font_or_PDF_written=False);title.append(item)
    srcimg=Image.fromarray(cv.orig[b[1]:b[3],b[0]:b[2]]).resize(((x1-x0+2)*10,(y1-y0+2)*10),Image.Resampling.NEAREST);ink=np.full((*mask.shape,3),255,np.uint8);ink[mask]=[21,55,105];outimg=Image.fromarray(ink).resize((ink.shape[1]*10//24,ink.shape[0]*10//24),Image.Resampling.LANCZOS)
    tile=Image.new('RGB',(800,330),'white');tile.paste(srcimg,(20,20));tile.paste(outimg,(420,10));tile.save(fresh(root/(ch+' TIEU DE NGUON VA BIEN CHI XEM.png')));montage.append(tile)
    print(ch,'TITLE source bbox',b,'WIDTH HEIGHT PT',item['source_width_pt'],item['source_height_pt'],'CC HOLES',n,len(holes),flush=True)
grid=Image.new('RGB',(800,1650),'white')
for j,t in enumerate(montage):grid.paste(t,(0,j*330))
grid.save(fresh(root/'5 CHU TIEU DE NGUON VA BIEN.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'5 CHU LON TIEU DE CUNG FILE CHI DOC.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),original_Perotac_X7_only=True,
    original_title_font_family_unknown_no_program=True,caption_font_bridge_not_accepted=True,title_glyphs=title,new_font_or_PDF_or_common_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close()
