"""Đo lượngmực vuônggóc của2nét SP135 từnative150dpi; chưa tạo mẫu2.
Phương phápalpha chiếu lên màu lõi, tương tự phép đo ROOT dùng cho G04.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from scipy.interpolate import UnivariateSpline
import numpy as np,json,hashlib

O='G05/10SP135 HAI MOC CUOI/DO MUC NGUON/'
d=json.loads(Path(S.report('G05/10SP135 HAI MOC CUOI/MAU 1/TOA DO VA BANG NGUON.json')).read_text(encoding='utf8'))
current=d['current_path'];assert hashlib.sha256(Path(current).read_bytes()).hexdigest()==d['current_sha256']
E=Editor(current);R=Raster(E);b=d['axis'];im=R.image_at(10,(b['x0'],b['y0'],b['x1'],b['y1']));cv=R.canvas(im);a=cv.orig.astype(float);r=b['rect'];s=72/b['dpi'];xt=np.array(b['xticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));nx=lambda x:float(cv.to_px(x,b['y0'])[0]);ny=lambda y:float(cv.to_px(b['x0'],y)[1]);native_width_pt=abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]);body=a[int(ny(b['y1']))+4:int(ny(b['y0']))-4,int(nx(b['x0']))+5:int(nx(b['x1']))-5];base=np.percentile(body.reshape(-1,3),98,axis=0)
gridx=np.array([nx(x) for q,x in b['xticks']]);gridy=np.array([ny(y) for h,y in b['yticks']]);out=[]
for c in d['curves']:
 bins={}
 for p in c['source_points']:
  if p.get('H_curve_m') is None:continue
  for z in p['sample_locations']:
   x=nx(r[0]+z['x_px']*s);y=ny(r[3]-z['y_px']*s);bins.setdefault(round(x,4),[]).append(y)
 sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx]);spl=UnivariateSpline(sx,sy,s=len(sx)*.06,k=3)
 columns=[];cores=[]
 for x in range(int(np.ceil(nx(px(140)))),int(np.floor(nx(px(178))))+1):
  pred=float(spl(x));yc=int(round(pred))
  if min(abs(gridx-x))<=3 or min(abs(gridy-pred))<=3:continue
  ids=np.arange(yc-4,yc+5);rgb=a[ids,x];lum=rgb@np.array([.299,.587,.114]);k=int(np.argmin(lum));peak=rgb[k]
  if base.mean()-peak.mean()<50:continue
  columns.append(dict(native_x=x,native_y=pred,ids=ids,rgb=rgb,slope=float(spl.derivative()(x)),peak_rgb=peak));cores.append(peak)
 cols=np.array(cores);lum=cols@np.array([.299,.587,.114]);p20=float(np.percentile(lum,20));ink=np.median(cols[lum<=p20],axis=0)
 vec=base-ink;norm=float(np.sum(vec*vec));measures=[]
 for z in columns:
  delta=np.maximum(0,base-z['rgb']);alpha=np.clip(delta@vec/norm,0,1)
  # Nativecolumnarea dividedby sqrt(1+slope²) equals perpendicular opacityarea.
  w=float(alpha.sum()*native_width_pt/np.sqrt(1+z['slope']**2))
  fwhm=float((alpha>=.5).sum()*native_width_pt/np.sqrt(1+z['slope']**2))
  measures.append(dict(native_x=z['native_x'],native_y=z['native_y'],source_core_peak_RGB=z['peak_rgb'].tolist(),native_slope=z['slope'],source_equivalent_ink_width_pt=w,source_fwhm_pt=fwhm,source_profile_RGB=z['rgb'].tolist(),source_profile_alpha=alpha.tolist()))
 width=float(np.median([z['source_equivalent_ink_width_pt'] for z in measures]));assert .55<width<1.5,(c['model'],width)
 out.append(dict(model=c['model'],color_RGB=ink.tolist(),background_RGB=base.tolist(),new_width_from_source_opacity_area_pt=width,source_opacity_width_quantiles_pt=np.percentile([z['source_equivalent_ink_width_pt'] for z in measures],[10,25,50,75,90]).tolist(),source_fwhm_quantiles_pt=np.percentile([z['source_fwhm_pt'] for z in measures],[10,25,50,75,90]).tolist(),source_native_pixel_pt=native_width_pt,column_count=len(measures),samples=measures,method='LõiRGB trungvịnhữngmẫu20%tối nhất. Alpha=clip(dot(bg-RGB,bg-ink)/norm(bg-ink)^2,0,1). Độrộngmực=sum(alpha)*nativepixelpt/sqrt(1+slope^2); median toànlátcắt khônglưới.',source_is_image=True,not_exact_original_PDF_pen=True))
Path(fresh(S.report(O+'DIEN TICH MUC VUONG GOC.json'))).write_text(json.dumps(dict(current_sha256=d['current_sha256'],source_sha256=d['source_sha256'],curves=out),ensure_ascii=False,indent=2),encoding='utf8')
E.close();print('SOURCE_INK_AREA',[(z['model'],z['color_RGB'],z['new_width_from_source_opacity_area_pt'],z['column_count'],z['source_fwhm_quantiles_pt']) for z in out],flush=True)
