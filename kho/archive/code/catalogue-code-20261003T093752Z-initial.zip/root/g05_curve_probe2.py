from catwork import start,fresh
from pathlib import Path
import json,numpy as np
from scipy.signal import find_peaks
S,D,N=start()
from catfix import charts,verify
j=S.job('Perotac bơm giếng SP_compressed (bản mới).pdf')
for p,r in [(4,(469,310,768,355)),(6,(275,340,370,400))]:
    cv=j.R.render_canvas(p,r,dpi=600)
    from PIL import Image
    Image.fromarray(cv.work).save(fresh(S.report(f'G05/DO CONG 2/trang {p+1}.png')))
    a=cv.work.astype(float)
    color=np.minimum(a[:,:,1]-a[:,:,0],a[:,:,2]-a[:,:,0])
    print('TRANG',p+1,'colors',np.percentile(color,[10,50,90,95,99,99.5,99.9]).tolist(),flush=True)
    xx=[469.68,506.64,543.60,581.16,617.64,655.08,692.04,729.00,766.44] if p==4 else [71.88,93.24,114.12,135.48,156.72,177.84,198.96,220.08,241.20,262.32,283.68,305.04,326.16,347.28,368.40]
    ys=[313.72,337.24,360.76,383.8,407.32,430.84,453.88,477.4,500.44] if p==4 else [313.24,344.92,376.12,406.84,438.04,469.24,499.96]
    ch=charts.Chart.from_ticks([(i*6,x) for i,x in enumerate(xx)],[(i*(65 if p==4 else 50),y) for i,y in enumerate(ys)])
    Qs=range(0,43,6) if p==4 else [72,78]
    for q in Qs:
        x=cv.to_px(*ch.to_page(q,0))[0]
        if x<0 or x>=a.shape[1]:continue
        v=np.mean(np.maximum(0,color[:,max(0,round(x)-2):min(a.shape[1],round(x)+3)]),axis=1)
        peaks,_=find_peaks(v,prominence=5,distance=6)
        vals=[]
        for y in peaks:
            px,py=cv.to_page(x,int(y));hh=float(ch.to_data(np.array([[px,py]]))[0,1]);rgb=a[y,round(x)].tolist()
            vals.append(dict(H=round(hh,2),score=round(float(v[y]),2),rgb=rgb))
        print('Q',q,vals,flush=True)
j.close()
