from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_trace1.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
code=code.replace("E=Editor(src);R=Raster(E);allcurves=[];graphs=[]", "E=Editor(src);R=Raster(E);allcurves=[];graphs=[];COLUMN_CACHE={}")
code=code.replace(" m=mask[top:bottom+1,x];labels,n=ndimage.label(m);out=[]", " if (x,top,bottom) in COLUMN_CACHE:return COLUMN_CACHE[(x,top,bottom)]\n m=mask[top:bottom+1,x];labels,n=ndimage.label(m);out=[]")
code=code.replace(" return out\ndef trace", " out=[z for z in out if z['width']<=6]\n COLUMN_CACHE[(x,top,bottom)]=out\n return out\ndef trace")
code=code.replace("for rec,a in zip(DATA,axis):\n pi=", "for rec,a in zip(DATA,axis):\n COLUMN_CACHE={}\n pi=")
code=code.replace("mask=(cr>7)&(cb>9)&(lum>75)&(lum<244)","mask=(cr>3)&(cb>3)&(cr+cb>11)&(lum>105)&(lum<225)")
code=code.replace("labelx,labels=MANUAL[rec['family']];lookup={k:(t,b) for k,t,b in labels};curves=[]", """labelx,labels=MANUAL[rec['family']];lookup={k:(t,b) for k,t,b in labels};curves=[]
 # Original compressed letters can have colored anti-aliased edges. Remove
 # only that black letter core + its two-pixel edge from the in-memory
 # measurement mask; the original source image/PDF remains untouched.
 capzone=np.zeros_like(mask);capzone[top:bottom+1,labelx-3:labelx+65]=True
 neutral_core=(lum<125)&((rgb.max(axis=2)-rgb.min(axis=2))<14)&capzone
 letter_edges=ndimage.binary_dilation(neutral_core,iterations=2)
 # Neutral fragments of the same observed curve can be caused by JPEG.
 # Detect real long gray grid rows before permitting neutral ink fragments.
 medrow=np.median(lum[top:bottom+1,left:right+1],axis=1);gridrows=np.zeros(mask.shape[0],bool);gridrows[top:bottom+1]=(medrow<246)&(medrow>170)
 grayink=(lum>105)&(lum<205)&limit&~gridrows[:,None]
 mask=(mask|grayink)&~letter_edges
""")
old="t,b=lookup[suffix];x=int(labelx)-2;cand=peaks_column(mask,wgt,x,max(top,t),min(bottom,b+10));cand=[z for z in cand if z['v']>=b-2 and z['v']<=b+10];cand.sort(key=lambda z:abs(z['v']-(b+2.4)))"
new="""t,b=lookup[suffix];options=[]
  for xx in [labelx-8,labelx-9,labelx-10,labelx-7,labelx-11,labelx-6,labelx-12]:
   cc=peaks_column(mask,wgt,int(xx),max(top,b-12),min(bottom,b+9));cc=[z for z in cc if z['strength']>3];cc.sort(key=lambda z:abs(z['v']-(b+1.5)))
   if cc:options.append((abs(cc[0]['v']-(b+1.5)),int(xx),cc))
  options.sort(key=lambda z:z[0]);x=options[0][1] if options else int(labelx)-8;cand=options[0][2] if options else []"""
assert old in code;code=code.replace(old,new)
code=code.replace(";unc=vertunc*ay;delta=hh-h", ";unc=math.ceil(vertunc*ay*10)/10;delta=hh-h")
code=code.replace("' LAN1.png'", "' LAN4.png'")
code=code.replace('BANG QH DOC TU NGUON V2.json','BANG QH DOC TU NGUON V5.json')
code=code.replace('TRUC DA DOI CHIEU.json','TRUC DA DOI CHIEU LAN4.json')
code=code.replace('DO NET NGUON LAN1.json','DO NET NGUON LAN4.json')
code=code.replace("print('TRACE1'", "print('TRACE4'")
exec(compile(code,__file__,'exec'))
