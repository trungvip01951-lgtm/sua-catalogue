from catwork import start, fresh
S, D, N = start()
from catfix.raster import Raster
from catfix.vector import Editor
from catfix import verify
from pathlib import Path
from PIL import Image, ImageDraw
import json, hashlib, numpy as np, pikepdf

root = Path(S.report('G06'))
name = 'Aquaris FS_300dpi_75% (bản mới).pdf'
src, prior = S.src(name), S.dst(name)
old = json.loads((root/'final-state-v2.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==old['source_sha256']
assert sha(prior)==old['final_sha256']
geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
E=Editor(src);R=Raster(E);cv=R.canvas(R.image_at(3,E.mediabox(3)))
left,right=[x['lines'] for x in geo['grids']]
rows=[];tiles=[]
for num in (4,5,6,12,13,14,15,16,17,18,19,27,28,29):
    if num<=22:r=(311.3,left[num+1]+.7,419.5,left[num]-.7)
    else:
        i=num-22;r=(447.8,right[i+1]+.7,557.3,right[i]-.7)
    box=cv.box(r);words=R.ocr(cv,box,scale=3,psm=6)
    comps=R.components(cv,box,bg=np.full(3,255.,np.float32),ink=np.zeros(3,np.float32),band=False)
    info=dict(row=num,rect=r,box=list(box),words=words,components=[dict(box=c['box'],height=c['alpha'].shape[0]) for c in comps])
    rows.append(info)
    im=verify.crop(src,3,r,600);t=Image.new('RGB',(im.width,max(40,im.height)+23),'white');dr=ImageDraw.Draw(t)
    dr.text((3,2),f'row {num} source',fill='black');t.paste(im,(0,23));tiles.append(t)
    print('ROW',num,'rect',r,'px',box,'ocr',[(w['text'],w['box'],w['line']) for w in words],flush=True)
atlas=Image.new('RGB',(max(t.width for t in tiles),sum(t.height+8 for t in tiles)),'white');yy=0
for t in tiles:atlas.paste(t,(0,yy));yy+=t.height+8
atlas_path=root/'review'/'word-copy-source-atlas.png'
if not atlas_path.exists():atlas.save(fresh(atlas_path))
fonts=[]
with pikepdf.open(src) as p:
    for o in p.objects:
        if isinstance(o,pikepdf.Dictionary) and o.get('/Type')==pikepdf.Name.Font:
            fd=o.get('/FontDescriptor');entry=dict(basefont=str(o.get('/BaseFont')),subtype=str(o.get('/Subtype')))
            if fd:
                entry['embedded']=[k for k in ('/FontFile','/FontFile2','/FontFile3') if k in fd]
            fonts.append(entry)
data=dict(source=src,prior_final=prior,source_sha256=sha(src),prior_sha256=sha(prior),canvas_shape=list(cv.work.shape),native_dpi=float(cv.im.dpi),rows=rows,embedded_font_inventory=fonts)
json.dump(data,open(fresh(root/'review'/'word-copy-source-geometry.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,
          default=lambda x:x.item() if hasattr(x,'item') else str(x))
E.close()
print('FONTS',fonts,'DPI',data['native_dpi'],flush=True)
