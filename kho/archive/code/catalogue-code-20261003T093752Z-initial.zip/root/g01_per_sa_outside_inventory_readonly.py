from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,collections
from g04_perotac_audit_data import DATA
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));O.mkdir(parents=True,exist_ok=True)
R=O.parent;p=R/'KIEM TOAN CUOI DE ROOT DOC.json';d=json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(d['source'])=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(d['destination'])=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
print('ROOT_KEYS',list(d));print('FIRST_GRAPH_KEYS',list(d['graphs'][0]));print('AXIS',json.dumps(d['graphs'][0]['axis'],ensure_ascii=False)[:3800]);print('CURVE_KEYS',list(d['graphs'][0]['curves'][0]));print('FIRST_POINT',json.dumps(d['graphs'][0]['curves'][0]['points'][0],ensure_ascii=False)[:2500])
rec=[];targets=[]
for g in d['graphs']:
 if g['page']==8:continue
 cnt=collections.Counter(p['status'] for c in g['curves'] for p in c.get('points',[]));reasons=collections.Counter(p['reason'] for c in g['curves'] for p in c.get('points',[]) if p['status']=='CHƯA THỂ XÁC MINH')
 rec.append({'page':g['page'],'family':g['family'],'models':len(g['curves']),'moc':sum(cnt.values()),'counts':dict(cnt),'unknown_reasons':dict(reasons)})
 for c in g['curves']:
  for pt in c.get('points',[]):
   if pt['status']!='KHỚP MỐC' or abs(pt.get('delta_H_m',0))>pt.get('tolerance_H_m',1):targets.append({'page':g['page'],'family':g['family'],'model':c['model'],'curve_identity_confirmed':c.get('identity_confirmed',False),**pt})
plan={'read_only':True,'source':d['source'],'source_SHA':sha(d['source']),'current':d['destination'],'current_SHA':sha(d['destination']),'baseline_file':str(p),'baseline_SHA':sha(p),'outside16_graph_inventory':rec,'outside_models':sum(q['models'] for q in rec),'outside_moc':sum(q['moc'] for q in rec),'outside_counts':dict(collections.Counter(pt['status'] for g in d['graphs'] if g['page']!=8 for c in g['curves'] for pt in c.get('points',[]))),'new_measure_targets':targets,'not_rerun_existing_certain_nodes':True,'page8_excluded':True}
fp=Path(fresh(O/'g01_PHAM VI16 BIEU DO VA MOC CAN DOC MOI.json'));fp.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
print('SUMMARY',json.dumps(rec,ensure_ascii=False),flush=True);print('SCOPE',plan['outside_models'],plan['outside_moc'],plan['outside_counts'],'TARGETS',len(targets),'FILE',fp,'SHA',sha(fp),flush=True)
print('UNKNOWN_EXAMPLES',json.dumps(targets[:5],ensure_ascii=False)[:5000])
