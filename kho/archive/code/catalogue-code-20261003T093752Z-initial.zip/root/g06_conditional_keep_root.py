"""Quyet dinh #53 theo dieu kien 'khong dep thi giu nguyen', khong suaPDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,datetime,numpy as np
from catfix import verify
import pymupdf as fitz
name='Aquaris FS_300dpi_75% (bản mới).pdf';source=S.src(name);final=S.result(name);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source)=='a297ed5b1dec97c33b6d2327d25d30bd3f317690548b9d5895c59e1376a63b31' and sha(final)=='97db44101b00605e71ce8996e8d4d08d672a8475cdcfa51ae1b1d5aa9597e033'
with fitz.open(source) as a,fitz.open(final) as b:
 assert a[3].read_contents()==b[3].read_contents()
 assert tuple(a[3].rect)==tuple(b[3].rect)
 r=(0,0,a[3].rect.width,a[3].rect.height)
assert np.array_equal(np.asarray(verify.crop(source,3,r,400)),np.asarray(verify.crop(final,3,r,400)))
receipt=dict(time=datetime.datetime.now().astimezone().isoformat(),group='G06',task=53,prompt_exact='Chỉnh cỡ chữ cho đều nếu ra đẹp; không đẹp thì giữ nguyên',decision='Giữ nguyên trang4 theo điều kiện cụ thể của #53, vì các mẫu điều chỉnh không đạt hình thức; không nhận chỉnh cỡ chữ đã đạt.',source_sha=sha(source),final_sha=sha(final),page4_content_stream_identical_to_source=True,page4_pixels_identical400dpi=True,tried_methods_stay_failed=True,failed_evidence='BAO CAO BO SUNG G06.md; ảnh góc ô1200điểm ảnh/inch và g06_word_native methods',final_pdf_written=False,task51='ĐẠT sửa model',task52='CHƯA THỂ: thiếu k thường đúng nét đậm trong chính file',task53='ĐẠT phương án giữ nguyên được prompt cho phép',group_status='CHƯA XONG:2/3 yêu cầu xử lý, trong đó1 sửaĐẠT và1 giữnguồn theođiềukiện; #52chưa sửa.')
Path(fresh(S.report('G06/QUYET DINH GIU NGUYEN 53 ROOT.json'))).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# BÁO CÁO G06 – quyết định cuối mục53 có điều kiện','','**G06 vẫn CHƯA XONG vì mục52 chưa có chữ k đúng kiểu. Mục51 đã sửa đạt; mục53 chọn giữ nguyên theo đúng điều kiện của hướng dẫn.**','','| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|','| 51 | Aquaris FS_300dpi_75% (bản mới).pdf | 1 | FS 15 15 1.5 | FS-35-7-2.2 | Nét nguồn, theo báo cáo đã nghiệm thu trước | ĐẠT sửa | G06/acceptance-v2.json; final-state-v2.json |','| 52 | Cùng tệp | 2–3 | (KW) | Còn (KW) | Không tạo chữ k bằng phông ngoài | CHƯA THỂ XÁC MINH | BAO CAO BO SUNG G06.md |','| 53 | Cùng tệp | 4 | Cỡ chữ không đều | Giữ nguyên nguồn | Áp dụng nguyên văn: “Chỉnh cỡ chữ cho đều nếu ra đẹp; không đẹp thì giữ nguyên” | ĐẠT phương án giữ nguyên; không nhận đã chỉnh cỡ chữ | G06/QUYET DINH GIU NGUYEN 53 ROOT.json; BAO CAO BO SUNG G06.md |','','Tổng3yêu cầu:1sửaĐẠT +1giữnguồn theođiềukiện +1CHƯA THỂ. Không gộp thành3việc đã sửa. Mục136 giữ cả hai catalogue FS.','','Các mẫu điều chỉnh mục53 trước đó vẫn CHƯA ĐẠT, có mực chữ cũ/viền chưa sạch và đều không dùng làm bản giao. Quyết định giữ nguồn đáp ứng phương án dự phòng được ghi cụ thể trong PROMPT G06; không biến các mẫu thử lỗi thành đạt.','','ROOT kiểm lại: trang4 bản giao có luồng nội dung giống hệt nguồn và mọi điểm ảnh trùng ở400điểm ảnh/inch. Mã kiểm nội dung nguồn/bản giao giữ đúng; không ghiPDF trong lượt quyết định này.','','Cần anh quyết: chưa có yêu cầu mới. Phát hiện thêm: không có.','','Giải thích: PDF là định dạng tài liệu; SHA-256 là mã kiểm nội dung; PROMPT là bộ hướng dẫn được giao.','']
Path(fresh(S.report('BAO CAO G06 QUYET DINH GIU NGUON.md'))).write_text('\n'.join(lines),encoding='utf8')
S.progress('G06','CHƯA XONG','ROOT chốt#53 GIỮ NGUYÊN theo nguyênvăn điều kiện khôngđẹp thìgiữ, p4content/pixel400dpi giốngnguồn; cácmẫuchỉnh vẫnFAIL khôngdùng. #51sửaĐẠT; #52thiếuk đúngkiểu CHƯATHỂ. Tổng1sửaĐẠT+1giữnguồn theođiềukiện+1CHƯATHỂ; báo cáo BAO CAO G06 QUYET DINH GIU NGUON.md.')
print('G06 conditional #53 kept source exactly; #51 pass; #52 missing k',flush=True)
