"""Readable RAM evidence handoff; no PDF or progress write."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAM TRANG08 DONG BO DE ROOT VA DO HOA XEM'))
r=json.loads((root/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==r['source_sha256'] and sha(S.result(name))==r['current_sha256']
md='''# Perotac SA trang 8 — ảnh xem bố cục trước PDF

**Có đủ 13 đường lưu lượng–cột áp, 13 nhãn đuôi và 13 tên đầy đủ. Chưa nghiệm thu, chưa ghi PDF. Bản nguồn, bản giao và tiến độ giữ nguyên.**

Xem toàn trang ở `PEROTAC P08 TOAN TRANG RAM150 CHUA NGHIEM THU.png` trước, rồi `PEROTAC P08 TOAN BIEU DO RAM600 CHUA NGHIEM THU.png`. Đây là ảnh xem đề xuất dựng trong bộ nhớ; ảnh 600 dpi chưa phải kết quả đọc một PDF mới đã lưu.

## Số liệu và các vạch

104 ô H thật của 13 model lấy riêng từ Perotac p8. Mỗi tọa độ quy qua hai vạch Q/H thực lân cận; dùng tâm lưới x357,564/x435,457 vừa đo lại, không dùng trục lý tưởng làm đầu vào. Toàn bộ nút trong kế hoạch khớp dưới 10⁻⁸ m. Cả104 có mực theo nhịp kế hoạch, chưa phải nghiệm thu nét/mực của PDF thật.

Điểm đầu là Q0 theo ô thật; điểm cuối là Q21 theo ô thật. /20 dừng H43 và /25 dừng H54. Không kéo đường dữ liệu theo các ô trống. Hai đường /23 và /18 tích hợp toàn biểu đồ theo đúng16 ô đã nghiệm thu, sẽ đọc lại cùng104 ô khi lưu mẫu.

Giữ34 vạch phụ có số đọc cạnh chính vạch nguồn; lít/phút không có thêm vạch dưới khungη nên không tạo vạch mới. Vạch m³/giờ dưới cùng độc lập với cột lít/phút, không ghép vì số gần nhau.

## Nét và bố cục

13 Q–H vàη cùng RGB127/145/150, bút0,90pt, không trộn thân JPEG và đuôi sắc. Lưới RGB225, bút0,75pt theo ROOT; khung RGB93, bút0,55pt. Dấu hiệu suất thuộc miền quan sát của nguồn riêng Perotac.

Nét đứt mực/khe7,00/3,37pt; phaước lượng−0,04pt. Thông số được đo từ169 biên thuộc13 nhánh, không chọn bằng bảngQ–H. Pha vector gốc chính xác CHƯA THỂ XÁC MINH vì chỉ cònJPEG. Đoạn đầu bị chặn tạiQ0, không ngoại suy sangQ âm. Sau dùngvạch thực cập nhật, chuyển đứt–liền lệch nguồn từ0,00072 đến0,43546 pixel, đều trong bất định±1 pixel nguồn; chưa đo trên PDF mới.

Các nhãn /4…/25 giãn riêng ở cuối đường; nét dẫn xám0,30pt phân biệt với đường thông số. Chú giải dưới trục ghi13 tên đầy đủ; không cómodel/7. /11 giữ đủ hai số1. Đường dữ liệu dừng tạiQ21, nét dẫn không mang dữ liệuQ–H mới.

## Chữ và điểm chưa đạt

Nguồn không có phông nhúng hay chữ thật. Tên model dùng hình chữ nhỏ của chính Perotac, tỷ lệ1:1; A/S từ cộtMODEL bảng bị loại vì đậm hơn, không dùng phông hệ thống. Bộ12 hình chữ giữ các khoảng tiến ký tự và cấu trúc lỗ. Chỉnh biên cong so ứng viên nguồn tối đa0,207 pixel; diện tích mực lệch−7,43%…+3,41%. Đây là đo ứng viên từ ảnh150dpi, không tuyên bố có mô tả phông liên tục đã mất.

**Ảnh xem chưa được nhận ĐẠT về chữ.** Một số dấu chấm và gạch chéo của đơn vị trục US/Imp g.p.m, l/min, m³/h còn nhỏ/biến dạng do ảnh nguồn. Các đường bao chữ trục hiện giữ vị trí/cỡ/lượng mực nguồn nhưng lượng mực khớp không tự chứng minh hình chữ đúng. Cần đối chiếu lại từng dấu và tác nhân đồ họa xem ảnh trước khi PDF. Không gọi ảnh600dpi là tăng thông tin của nguồn150dpi.

## Hiệu suấtη riêng

558 quan sát mực nguồn Perotac, tuyệt đối không dùng551 điểm của Redpump. Đề xuất4 đoạn trơn nối liên tục đến đạo hàm bậc hai và một đỉnh. 547/547 tâm mực rõ tạiu≥138 trong±1 pixel nguồn; 530 trong±0,5 pixel. Trung vị sai lệch0,08951, lớn nhất0,77689 pixel.

11 quan sát đầu u127…137 lẫn khung: giữ CHƯA THỂ XÁC MINH tâm thật. Điểm(u127,v674) chỉ là cạnh mực quan sát, không nhận thành tâmη chắc chắn hay tự gánQ0/η0. Không kéo dài ngoàiu127…684. Không có bảngη nên giá trị hiệu suất vẫn CHƯA THỂ XÁC MINH.

## Trước cập nhật bản giao

ROOT và tác nhân đồ họa cần kiểm ảnh xem này; chưa tạo mẫuPDF. Số lượng mẫuPDF của phương pháp toàn biểu đồ hiện0. Sau chốt hình/chữ mới dùngcatfix ghi mẫu riêng và đọc lại104 tâm nét, mực600dpi, màu/độ dày/nhịp; nghiệm thu16 điểm riêng/23,/18,13nhãn/13tên và khoảng cách chữ. Ngoài vùng sửa cả11trang phải0 điểm khác ở200dpi; giữ khổ/thông tin/XMP theo giá trị/ảnh nguồnrawbytes/ma trận/liên kết. Không cập nhật tiến độ chung ở đây.

'''
repl={'Cả104':'Cả 104','đúng16':'đúng 16','cùng104':'cùng 104','Giữ34':'Giữ 34','khungη':'khung η','13 Q–H vàη':'13 Q–H và η','RGB127':'RGB 127','RGB225':'RGB 225','RGB93':'RGB 93','bút0':'bút 0','mực/khe7':'mực/khe 7','phaước':'pha ước','biên thuộc13':'biên thuộc 13','từ169':'từ 169','bảngQ':'bảng Q','cònJPEG':'còn JPEG','tạiQ':'tại Q','sangQ':'sang Q','dùngvạch':'dùng vạch','từ0':'từ 0','xám0':'xám 0','ghi13':'ghi 13','model/7':'model /7','số1':'số 1','dữ liệuQ':'dữ liệu Q','tỷ lệ1':'tỷ lệ 1','cộtMODEL':'cột MODEL','Bộ12':'Bộ 12','tối đa0':'tối đa 0','ảnh150dpi':'ảnh 150dpi','−7,43%…+3,41%':'−7,43%…+3,41%','ảnh600dpi':'ảnh 600dpi','nguồn150dpi':'nguồn 150dpi','551 điểm':'551 điểm','dùng551':'dùng 551','Đề xuất4':'Đề xuất 4','tạiu':'tại u','ngoàiu':'ngoài u','bảngη':'bảng η','mẫuPDF':'mẫu PDF','ghi mẫu':'ghi mẫu','pháp toàn':'pháp toàn','hiện0':'hiện 0','dùngcatfix':'dùng catfix','lại104':'lại 104','mực600dpi':'mực 600dpi','thu16':'thu 16','13nhãn/13tên':'13 nhãn/13 tên','cả11trang':'cả 11 trang','phải0':'phải 0','ở200dpi':'ở 200dpi','nguồnrawbytes':'nguồn đúng byte','XMP':'XMP (thông tin mở rộng)'}
for a,b in repl.items():md=md.replace(a,b)
md+='SHA nguồn: '+r['source_sha256']+'\n\nSHA bản giao: '+r['current_sha256']+'\n'
Path(fresh(root/'BAN GIAO ANH RAM VA GIOI HAN CHUA NGHIEM THU.md')).write_text(md,encoding='utf8')
