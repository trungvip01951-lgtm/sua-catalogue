"""Ghi báo cáo mẫu2endpoint trước ROOT duyệt; không ghiPDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,numpy as np,sys

second='--mau2' in sys.argv
O='G05/10SP135 HAI MOC CUOI/'+('MAU 2/' if second else 'MAU 1/')
r=json.loads(Path(S.report(O+'NGHIEM THU PDF MAU 2END VA TOAN2218.json')).read_text(encoding='utf8'))
d=json.loads(Path(S.report(O+'TOA DO VA BANG NGUON.json')).read_text(encoding='utf8'))
lines=['# BÁO CÁO MẪU G05 – hai điểm cuối 10SP135','',
 'Hai điểm Q180 được sửa trong PDF mẫu; bản giao chưa đổi. Chỉ sửa 10SP135-5 và 10SP135-7 từ gần Q162 đến Q180. Nhóm G05 vẫn CHƯA XONG.','',
 '| Mã máy | Trang | Q (m³/h) | H bảng (m) | H nguồn đo (m) | H PDF mẫu đọc thật (m) | Sai lệch (m) | Biên sai số trục (m) | Giới hạn (m) | Kết quả |',
 '|---|---|---|---|---|---|---|---|---|---|']
for p in r['actual_endpoint_points']:
 c=next(c for c in d['curves'] if c['model']==p['model']);old=next(z for z in c['source_points'] if z['Q_m3h']==180)
 lines.append(f'| {p["model"]} | 11 | 180 | {p["H_table"]:g} | {old["H_curve_m"]:.5f} | {p["H_actual_PDF"]:.8f} | {p["deviation_m"]:.8f} | {p["axis_uncertainty_m"]:.5f} | {p["limit_m"]:g} | ĐẠT phần điểm cuối |')
lines.extend(['',
 'Danh tính: đã đọc trực tiếp nhãn cạnh nét nguồn 10SP135-5 và 10SP135-7; bảng có đúng hai mã này, lần lượt hàng7 và hàng9. Thứ tự và dãy Q/H nguồn tương ứng, không dùng H của bảng để chọn nét gần nhất. Nhãn và phần nét đứt bên trái giữ nguyên từng điểm ảnh.','',
 'Nghiệm thu:','',
 '- Đọc 2 đối tượng nét thật trong PDF; điểm cuối đi đúng Q180/H66 và Q180/H93. Điểm nối gần Q162,138 và tiếp tuyến khớp nét nguồn.',
 '- Đo lại đủ132mốc của biểu đồ10SP135: 74ĐẠT, 0CHƯA ĐẠT, 58CHƯA THỂ. 58mốc giữ trạng thái sai số/không đọc rõ của ảnh nguồn150dpi.',
 '- Đối chiếu điểm ảnh toàn10nét còn lại trong dải±3,5điểm ảnh nguồn quanh mỗi nét: không đổi. Chữ/nét đứt phía trái600dpi không đổi; 15bảng450dpi và14biểu đồ khác600dpi không đổi.',
 '- Ngoài2vùng được sửa200dpi, ngưỡng chênh0: rỗng. Giữ12trang, khổtrang, phông/ảnh gốc, thông tin tệp, liênkết/dấu trang và trạng thái không có XMP (khối siêu dữ liệu).','',
 f'Toàn2.218mốc trong mẫu: {r["full2218_counts"]["ĐẠT"]}ĐẠT / {r["full2218_counts"]["CHƯA ĐẠT"]}CHƯA ĐẠT / {r["full2218_counts"]["CHƯA THỂ"]}CHƯA THỂ. 29mốc trái SP30 giữ nguyên, chưa giải quyết trong việc này.','',
 'Màu/độ dày nét mới lấy mẫu hai nét thật trong ảnh150dpi. Tham số nét PDF mới không được tuyên bố là thông số bút PDF nguồn vì nguồn là ảnh. Mẫu1 nét0,48pt bị AI điều phối từ chối; mẫu2 dùng độ rộng lượng mực đo vuông góc, màu lõi20%tối nhất. RGB là mức màu đỏ/xanh lá/xanh lam.','',
 '| Mã máy | RGB mới | Độ dày mới (pt) | Số mẫu nguồn | Bề dày FWHM nguồn p25/trung vị/p75 (pt) |',
 '|---|---|---|---|---|'])
for z in d['style']:
 if second:
  widths=np.array([v['source_fwhm_pt'] for v in z['samples']]);color=z['color_RGB'];w=z['new_width_from_source_opacity_area_pt']
 else:
  widths=np.array([v['fwhm_normal_pt'] for v in z['source_150dpi_width_samples']]);color=z['source_RGB_percentile35'];w=.48
 p=np.percentile(widths,[25,50,75]);lines.append(f'| {z["model"]} | {color} | {w:.8f} | {len(widths)} | {p[0]:.4f} / {p[1]:.4f} / {p[2]:.4f} |')
if second:
 ink=json.loads(Path(S.report(O+'DO MUC TRONG PDF MAU THAT.json')).read_text(encoding='utf8'))
 lines.extend(['','Đọc lại lượng mực từ chính PDF mẫu:','', '| Mã máy | Số lát cùngQ | Trung vị nguồn (pt) | Trung vị mới (pt) | Tỷ lệ mực trung bình mới/nguồn |','|---|---|---|---|---|'])
 for z in ink['curves']:lines.append(f'| {z["model"]} | {z["sample_count"]} | {z["source_equivalent_width_median_pt"]:.6f} | {z["new_render_equivalent_width_median_pt"]:.6f} | {z["mean_area_ratio_new_over_source"]:.6f} |')
lines.extend(['',
 'FWHM là độ rộng tại nửa mức đậm của nét ảnh. Ảnh150dpi có1điểm ảnh=0,48pt. Chênh nhỏ không cho biết chính xác bút nguồn; cũng không dùng biên±1điểm ảnh để cho qua nét nhìn mỏng hơn nguồn. Mẫu2 đã đo lượng mực thật; đang chờ AI điều phối xem và đọc độc lập.','',
 'Bản giao đang giữ SHA256: '+r['current_sha256'],
 'PDF mẫu: '+r['trial'],
 'SHA256 PDF mẫu: '+r['trial_sha256'],
 'Nguồn SHA256 không đổi: '+r['source_sha256'],'',
 'Ảnh trước/sau: TRUOC - HAI DUOI.png; PDF MAU - HAI DUOI.png; SO SANH TRANG11.png. Hồ sơ NGHIEM THU PDF MAU 2END VA TOAN2218.json và NGHIEM THU 2218 MOC.csv chứa đủ từngmốc và bằng chứng bảo toàn.','',
 'Trạng thái: chờ AI điều phối đọc độc lập PDF mẫu; chưa thay bản giao.',''])
Path(fresh(S.report(O+'BAO CAO MAU HAI DIEM CUOI.md'))).write_text('\n'.join(lines),encoding='utf8')
S.progress('G05','CHƯA XONG – MẪU','Hai điểm cuối10SP135-5/-7 tạiQ180 đã đọc actualpath66/93 đạt, nhưng S.dst vẫnSHA bc015… chờ ROOTkiểm độc lập. Full2218trongmẫu1115ĐẠT/29CHƯA ĐẠT/1074CHƯA THỂ;132mốc SP135đọc mới,10nétkhác/toàn bảng/ảnh/phông/ngoài vùng giữ. '+O+'BAO CAO MAU HAI DIEM CUOI.md')
print('sample report and checkpoint saved',flush=True)
