from catwork import start,fresh
from pathlib import Path
import json,hashlib,numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.charts import Chart
from catfix import verify
from PIL import Image,ImageDraw
root=Path(S.report('G04/REDPUMP DOC NGUON RIENG'));probe=json.loads((root/'DINH VI.json').read_text(encoding='utf8'))
name=probe['name'];source=S.src(name);current=S.result(name);E=Editor(source,backend='fitz');R=Raster(E);base=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(base);a=cv.orig.astype(int);g=a@np.array([.299,.587,.114]);height,width=g.shape
assert list(base.page_bbox)==probe['source_image_bbox'] and [base.W,base.H]==[1739,1237]
grid=probe['vertical_rules'];ticks=[(i*50,z['pageX']) for i,z in enumerate(grid)];cx=np.polyfit([q for q,x in ticks],[x for q,x in ticks],1);res=max(abs(np.polyval(cx,q)-x) for q,x in ticks)
top=probe['horizontal_frames'][1]['v'];bottom=probe['horizontal_frames'][2]['v'];assert top==179.5 and bottom==567
y0=cv.to_page(0,bottom)[1];y150=cv.to_page(0,top)[1];C=Chart(float(cx[0]*1000/60),float(cx[1]),float((y150-y0)/150),float(y0));Q=[0,3,6,9,12,15,18,21]
tables=[dict(model='4SL16/23',Q=Q,H=[136,133,127,115,101,86,69,50],source_read='Đọc trực tiếp BANG QH.png; tên/dòng nguồn Redpump riêng'),dict(model='4SL16/18',Q=Q,H=[107,104,99,90,79,67,54,39],source_read='Đọc trực tiếp BANG QH.png; tên/dòng nguồn Redpump riêng')]
color=(a[:,:,1]-a[:,:,0]>8)&(a[:,:,2]-a[:,:,0]>10)&(a[:,:,0]<235)
q21x=C.to_page(21,0)[0];up=cv.to_px(q21x,400)[0];u=int(round(up));rows=np.arange(int(top)+3,int(bottom)-2);cols=color[rows,u-1:u+2];yes=rows[cols.any(1)];parts=[]
for v in yes:
 if not parts or v-parts[-1][-1]>1:parts.append([])
 parts[-1].append(int(v))
peaks=[]
for vs in parts:
 if len(vs)>16:continue
 pix=a[vs,u-1:u+2];weight=np.maximum(1,((pix[:,:,1]+pix[:,:,2])/2-pix[:,:,0]).max(1));v=float(np.average(vs,weights=weight));h=float((bottom-v)/(bottom-top)*150);peaks.append(dict(v=v,H=h,rows=vs))
print('OWN REDPUMP axes',dict(ticks=ticks,cx=cx.tolist(),res_pt=res,top=top,bottom=bottom,q21_x=q21x,q21_u=up),'allQ21peaks',peaks,flush=True)
detail=cv.orig[410:477,int(up)-9:int(up)+10];Image.fromarray(detail).resize((detail.shape[1]*16,detail.shape[0]*16),resample=Image.Resampling.NEAREST).save(fresh(root/'Q21 PIXEL HAI NET NGUON.png'))
# Matching is from source labels read directly on the plot: top-to-bottom
# 25,23,20,18,16,14,12,11,9,8,6,5,4. Two selected named traces are followed
# from their own source labels to Q21. A selected sample must not be a grey rule.
assert len(peaks)==13,(len(peaks),peaks)
records=[]
for t,index in zip(tables,[1,3]):
 p=peaks[index];expected=t['H'][-1];err=p['H']-expected;limit=max(1.,expected*.02);records.append(dict(model=t['model'],Q=21,H_table=expected,H_source_curve=p['H'],error=err,limit=limit,uncertainty_m=150/(bottom-top),source_pixel_rows=p['rows'],source_pixel_v=p['v'],result='CHƯA ĐẠT' if abs(err)>limit+150/(bottom-top) else 'CHƯA THỂ' if abs(err)>limit else 'ĐẠT',identification='Đọc nhãn cùng nguồn và theo thứ tự 13 đường: /25,/23,/20,/18…; không suy mã từ Perotac'))
im=Image.fromarray(cv.orig);dr=ImageDraw.Draw(im);dr.line([(up,top),(up,bottom)],fill=(255,110,0),width=2)
for p in [peaks[1],peaks[3]]:v=p['v'];dr.ellipse((up-6,v-6,up+6,v+6),outline=(255,0,0),width=2)
im.save(fresh(root/'Q21 DOC RIENG CO DANH DAU.png'))
Hrect=(160,39.5,374,177.5);sourceH=np.asarray(verify.crop(source,7,Hrect,400));currentH=np.asarray(verify.crop(current,7,Hrect,400));assert np.array_equal(sourceH,currentH),'Cột QH bản đã sửa khác nguồn; phải đọc lại số current'
out=dict(name=name,page=8,source=source,source_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),current=current,current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),source_image_shape=[base.W,base.H],source_image_bbox=list(base.page_bbox),source_ticks_lmin=ticks,axis=[C.ax,C.bx,C.ay,C.by],axis_residual_pt=float(res),axis_choice='9 nét lưới dọc đọc từ Redpump, gắn nhãn l/min đã soi; khớp tuyến tính, không mượn Perotac',top_v=top,bottom_v=bottom,tables=tables,source_QH_rect=list(Hrect),source_and_current_QH_pixels_exact=True,Q21_read=records,all_Q21_source_peaks=peaks,scope='Hai nguồn nhãn/từng ô 8mốc được đọc; mới đoQ21/đường, chưa nghiệm thu tất cả các mốc nguồn khác hoặc các đường khác G04')
Path(fresh(root/'BANG VA HAI DUONG NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print('SOURCE RESULTS',records,flush=True);E.close()
