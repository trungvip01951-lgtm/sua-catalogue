"""Few cubic segments follow eta source ink only; no new efficiency table."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.interpolate import BSpline,PPoly
from scipy.optimize import least_squares
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=base/'ETA IT DOAN TRON THEO MUC NGUON'
m=json.loads((base/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'));pts=m['eta_source']['source_native_observed_points'];u=np.array([r['u'] for r in pts],float);v=np.array([r['v'] for r in pts],float)
assert len(u)==558
knots=np.r_[[u[0]]*4,[280.,500.],[u[-1]]*4];nc=len(knots)-4;B=BSpline.design_matrix(u,knots,3).toarray();fixed={0:float(v[0]),nc-1:float(v[-1])};free=[i for i in range(nc) if i not in fixed];off=sum(B[:,i]*value for i,value in fixed.items());A=B[:,free]
first=np.linalg.lstsq(A,v-off,rcond=None)[0];fit=least_squares(lambda cc:(A@cc+off-v),first,loss='soft_l1',f_scale=.25)
c=np.zeros(nc)
for i,value in fixed.items():c[i]=value
c[free]=fit.x;spl=BSpline(knots,c,3,extrapolate=False);vv=spl(u);err=vv-v;pp=PPoly.from_spline(spl);segments=[]
for lo,hi in zip([127.,280.,500.],[280.,500.,684.]):
    p0=[lo,float(spl(lo))];p3=[hi,float(spl(hi))];dx=(hi-lo)/3;p1=[lo+dx,p0[1]+float(spl.derivative()(lo))*dx];p2=[hi-dx,p3[1]-float(spl.derivative()(hi))*dx];segments.append(dict(start=p0,control1=p1,control2=p2,end=p3))
bad=[dict(source_u=float(x),source_v=float(y),fit_v=float(z),delta_native_px=float(d),source_RGB_strength=r['strength'],source_component_width=r['width'],
          observed_source_value_not_replaced=True,uncertainty_reason='Ảnh JPEG/khung dưới lẫn vào tâm mực ở đầu trái' if x<136 else 'Tâm mực ảnh JPEG có dao động nguồn') for x,y,z,d,r in zip(u,v,vv,err,pts) if abs(d)>.5]
checks=dict(point_count=558,within_half_native_px=int((abs(err)<=.5).sum()),within_one_native_px=int((abs(err)<=1).sum()),
            median_abs_source_error_native_px=float(np.median(abs(err))),max_abs_source_error_native_px=float(max(abs(err))),
            excludes_all_magnitude_Q_or_eta_numbers=True,geometry_fit_source_pixel_only=True,endpoints_actual_first_last_observed_source_ink_only=True)
doc=dict(read_only=True,source_sha256=m['source_sha256'],current_sha256=m['current_sha256'],original_Perotac_X7_only=True,eta_table_available=False,
         efficiency_numeric_acceptance='UNKNOWN',QH_table_never_used_to_derive_eta=True,source_count_558_preserved=True,
         method='Ba đoạn Bezier bậc3 liên tục tới đạo hàm2; khớp mềm tâm mực nguồn, không khớp từng nhiễu JPEG; hai đầu quan sát giữ nguyên.',
         original_source_points=pts,source_spline_knots=knots.tolist(),source_spline_coefficients=c.tolist(),cubic_bezier_segments_native=segments,
         source_residual_checks=checks,points_outside_half_pixel=bad,source_end_before_frame_right_not_extended=True,
         original_source_left_contact_under_frame_not_extrapolated=True,PDF_font_or_progress_written=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==m['source_sha256'] and sha(S.result(name))==m['current_sha256']
Path(fresh(root/'ETA3 DOAN BEZIER VA558 TAM NGUON CHI DO.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
raw=Image.open(base/'NGUON TRANG08 NGUYEN150dpi.png');crop=raw.crop((118,577,749,682)).resize((2524,420),Image.Resampling.NEAREST);draw=ImageDraw.Draw(crop);xy=[((x-118)*4,(float(spl(x))-577)*4) for x in np.arange(127,684.0001,.25)];draw.line(xy,fill=(200,40,40),width=1);crop.save(fresh(root/'ETA NGUON VA TAM3 DOAN TRON DOI CHIEU.png'))
print('ETA3 SOURCE CHECKS',checks,'BAD',len(bad),'FIRST',bad[:12],flush=True)
