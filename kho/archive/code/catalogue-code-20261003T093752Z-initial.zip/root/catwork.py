"""Hỗ trợ phiên sửa catalogue; không thay mã catfix hoặc file nguồn."""
import contextlib
import io
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent

def start(verbose=False):
    ns = {'__name__': 'catfix_bootstrap'}
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        exec((HERE / 'batdau.py').read_text(encoding='utf-8'), ns)
    from catfix.env import report
    _, verdict = report(verbose=False)
    if not all(bool(v) for _, v in verdict):
        print(buf.getvalue())
        raise RuntimeError('BƯỚC 0: môi trường chưa đạt')
    if verbose:
        print(buf.getvalue())
    S = ns['S']
    data = json.loads(Path(ns['PKG'], 'tasks', 'tasks.json').read_text(encoding='utf-8'))
    return S, data, ns

def fresh(path):
    p = Path(path)
    if p.exists():
        raise FileExistsError('Không ghi đè tệp đã tồn tại: ' + str(p))
    p.parent.mkdir(parents=True, exist_ok=True)
    return str(p)

def row(task, file, page, item, old='', new='', result='ĐẠT', evidence='', **extra):
    return dict(stt=task, file=file, page=page, item=item, old=old, new=new,
                result=result, evidence=evidence, **extra)
