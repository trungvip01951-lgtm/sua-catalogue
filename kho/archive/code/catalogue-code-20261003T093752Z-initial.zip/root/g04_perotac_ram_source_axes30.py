"""Source-axis crops for RAM drawing, original Perotac only; no PDF."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=base/'CHU TRUC NGUON VA RAM CHI DOC'
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig
assert np.array_equal(a,np.asarray(Image.open(base/'NGUON TRANG08 NGUYEN150dpi.png')))
boxes={'Q TREN NGUON':[102,140,790,183],'H TRAI NGUON':[77,164,128,580],'H PHAI NGUON':[741,174,792,582],
       'Q ETA DUOI NGUON':[79,577,791,733],'TIEU DE NGUON':[474,180,748,225]}
for label,b in boxes.items():
    im=Image.fromarray(a[b[1]:b[3],b[0]:b[2]]);sc=5 if im.width>100 else 7;im=im.resize((im.width*sc,im.height*sc),Image.Resampling.NEAREST)
    im.save(fresh(root/(label+'.png')))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'HO CROP CHU TRUC NGUON.json')).write_text(json.dumps(dict(source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_boxes=boxes,original_X7_only=True,PDF_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
