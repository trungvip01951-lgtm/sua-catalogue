from catwork import start, fresh, row
S, D, N = start()
from catfix import verify
from pathlib import Path
import json, datetime

NAME = 'Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'
root = Path(S.report('G03'))
st = json.loads((root / 'build-state.json').read_text(encoding='utf-8'))
acc = json.loads((root / 'acceptance-final.json').read_text(encoding='utf-8'))
font = json.loads((root / 'font-resources.json').read_text(encoding='utf-8'))
for k in ('source_preserved','numeric_all_ok','contents_all_ok','curves_all_ok',
          'special_all_done_parts_ok','metadata_equal','metadata_values_equal',
          'bookmarks_equal','links_equal'):
    if not acc[k]: raise RuntimeError('Chưa đạt nghiệm thu: ' + k)
if not acc['job_check']['ok'] or acc['outside_pixels_200dpi'] or acc['nonchart_retained_from_prior_ocr_pass']:
    raise RuntimeError('Chưa đạt nghiệm thu cấu trúc/vùng ngoài')
if not all(z['ok'] for z in acc['image_streams']):
    raise RuntimeError('Ảnh nguồn bị thay đổi')

method = 'Chép nét chữ cùng kiểu từ chính file, căn giữa ô; đọc lại và xem ảnh'
ratmethod = 'Trung vị cột áp/tầng; kiểm đa thức; chép số cùng kiểu; đồng bộ đường theo bảng'
tasks = {
21:(3,'4SA2/65: 4,0 kW = 5,0 HP','4,0 kW = 5,5 HP',method),
22:(4,'20 lít/phút ↔ 1,1 m³/giờ','20 lít/phút ↔ 1,2 m³/giờ',method),
23:(5,'90 lít/phút ↔ 5,0 m³/giờ','90 lít/phút ↔ 5,4 m³/giờ',method),
24:(5,'4SA4/22, 50 lít/phút: 103 m','130 m',ratmethod),
25:(6,'4SA6/11: 1,0 kW / 1,5 HP','1,1 kW / 1,5 HP',method),
26:(6,'4SA6/36, 20 lít/phút: 281 m','217 m',ratmethod),
27:(7,'40 lít/phút ↔ 2,2 m³/giờ','40 lít/phút ↔ 2,4 m³/giờ',method),
28:(7,'4SA8/8: 1,0 kW / 1,5 HP','1,1 kW / 1,5 HP',method),
29:(7,'Tên hàng 4SA8/24','4SA8/28; giữ 162–153–137–114–72–14',method),
30:(7,'4SA8/44, 80 lít/phút: 316 m','216 m',ratmethod),
31:(8,'4SA10/28, 30 lít/phút: 116 m','166 m',ratmethod),
32:(10,'230 / 265 / 360 lít/phút','233 / 267 / 367 lít/phút',method),
33:(2,'8 tên dòng sản phẩm trong 6 ô lệch hàng/cột','Căn trái theo hai cột, cùng cao độ từng hàng','Dời nguyên nét chữ; kiểm tọa độ thật của 8 tên'),
34:('3–10','KW/Kw; Hp; S.r.l; diameterϕ95mm','Đã sửa HP, S.r.l., diameter ϕ95 mm ở 8 trang; KW/Kw còn nguyên','Chép P hoa và dấu chấm cùng kiểu; dời nét để thêm khoảng trắng; thiếu mẫu k'),
130:(5,'4SA4/40, 100 lít/phút: 98 m','87 m; ước ban đầu 89 m, kiểm đường chọn 87 m trong ±2',ratmethod),
}
rows = []
for ident,(pg,old,new,how) in tasks.items():
    ev = 'G03/acceptance-final.json; G03/so-lieu.png; So sanh G03.png'
    if ident in (24,26,30,31,130): ev += '; G03/ratio-calculation.json; G03/BAO CAO BIEU DO.md'
    if ident == 33: ev = 'G03/muc-luc.png; G03/acceptance-final.json'
    if ident == 34: ev = 'G03/chu-chung.png; G03/font-resources.json; G03/acceptance-final.json'
    rows.append(row(ident,NAME,pg,how,old,new,'CHƯA ĐẠT' if ident==34 else 'ĐẠT',ev,method=how))

outpath = fresh(S.report('BAO CAO G03.md'))
fresh(Path(outpath).with_suffix('.json'))
verify.write_report(rows,outpath,title='BÁO CÁO NHÓM G03 – Aquaris SA')
lines = ['# BÁO CÁO NHÓM G03 – Aquaris SA', '',
         '**Tổng: 15 việc · ĐẠT 14 · CHƯA ĐẠT 1 · CHƯA THỂ XÁC MINH 0.**', '',
         'Còn #34: chưa sửa KW/Kw thành kW vì trong chính PDF không có nét chữ thường k cùng kiểu, không có phông nhúng hoặc lớp chữ thật/ẩn. Đã sửa 24 phần còn lại của #34 ở 8 trang, có kiểm nét ký tự độc lập.', '',
         '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
         '|---|---|---|---|---|---|---|---|']
for r in rows:
    vals = [r[k] for k in ('stt','file','page','old','new','method','result','evidence')]
    lines.append('| ' + ' | '.join(str(x).replace('|','/') for x in vals) + ' |')
lines += ['', '## Số chốt theo tỉ lệ tầng', '',
          'Q là lưu lượng, H là cột áp tính bằng mét; số tầng là số sau dấu /. Trung vị là giá trị ở giữa dãy đã sắp xếp. Khớp đa thức kiểm cả hàng; nội suy đơn điệu từng đoạn dùng để dựng đường qua đúng các điểm bảng.', '',
          '| # | Dòng sản phẩm | Q (lít/phút) | Trung vị H/tầng | Ước chưa làm tròn | Ước nguyên | Bậc đa thức | H theo đa thức | Lệch của ước nguyên | Chốt |',
          '|---|---|---|---|---|---|---|---|---|---|']
for ident,z in st['ratios'].items():
    lines.append(f"| {ident} | {z['model']} | {z['Q']} | {z['median']:.9f} | {z['raw_estimate']:.6f} | {z['rounded_estimate']} | {z['poly_degree']} | {z['poly_at_target']:.6f} | {100*z['relative_difference']:.6f}% | {z['chosen']} |")
lines += ['', '#130: 89 lệch đường khớp 2,541166%, vượt 2%; số nguyên gần nhất là 87. Số 87 vẫn nằm trong 89 ±2, đúng quy tắc chung và lưu ý riêng G03.', '',
          'Các số này là ước theo quy tắc trong gói hướng dẫn, chưa phải số thử bơm từ nhà sản xuất.', '']
for ident,z in st['ratios'].items():
    tab = st['tables'][str(z['page'])]
    stage = int(z['model'].split('/')[-1]); ii=tab['stages'].index(stage)
    source = '; '.join(f"{v['model']}: {v['H']}/{v['stages']}={v['H_per_stage']:.9f}" for v in z['sources'])
    lines += [f"**#{ident}: các H/tầng dùng:** {source}.", '',
              'Hệ số đa thức, từ bậc cao xuống bậc 0: ' + ', '.join(f'{v:.12g}' for v in z['poly_coeff']) + '.', '',
              f"Cả hàng sau sửa: Q={tab['q']}; H={tab['heads'][ii]}. Sai số lớn nhất của phép khớp đa thức: {z['poly_max_residual']:.6f} m. Đường mới qua đúng mọi điểm bảng.", '']
lines += ['## Biểu đồ phát hiện thêm và đã sửa', '',
          'Đã đo toàn bộ 69 đường trên 8 trang, mỗi đường 6 điểm, tổng 414 điểm. Một số đường nguồn lệch bảng hoặc đầu cuối chưa khớp; đã đồng bộ toàn bộ theo quyền sửa/vẽ lại anh cấp. Không thêm số liệu cột áp ngoài bảng; chỉ đổi 5 ô theo tỉ lệ ở trên.', '',
          'Đường mới dùng nội suy đơn điệu qua đúng từng điểm, hai đầu khớp bảng. Giữ màu, độ dày, kiểu nét, ma trận tọa độ và trạng thái hiển thị của đường gốc. Trang 9–10 dùng trục m³/giờ; trang 3–8 dùng lít/phút. Báo cáo chi tiết: [G03/BAO CAO BIEU DO.md](G03/BAO%20CAO%20BIEU%20DO.md).', '',
          'Nhãn giữ nguyên nét chữ và màu xanh; thêm viền trắng bám theo nét chữ để dễ đọc. Nhãn 4SA8/8 trang 7 dời ngang 45 điểm in, tách khỏi 4SA8/6. Không dùng khối che hình chữ nhật.', '',
          '## Nghiệm thu file ra', '',
          '- Cấu trúc PDF đạt; 10 trang, khổ trang, dấu trang, liên kết, thông tin và ảnh nguồn giữ nguyên.',
          '- Các giá trị thông tin XML giữ nguyên; bộ lưu đổi dấu nháy/khoảng trắng và bỏ chỉ dẫn bộ lọc Adobe, nên byte XML không giống nguồn. Đã kiểm độc lập các phần tử/thuộc tính/giá trị: G03/metadata-values.json.',
          '- Ngoài vùng được phép sửa: không có điểm ảnh thay đổi ở phép so sánh 200 điểm ảnh/inch.',
          '- Đọc lại đủ 15 thành phần số của 14 việc đã đạt; 8 tên mục lục có đúng tọa độ.',
          '- 69/69 đường và 414/414 điểm đạt ngưỡng max(1 m, 2% H); hai đầu sai số dưới 0,001 m.',
          '- 8 chữ P hoa và 8 dấu chấm cuối được kiểm nét trực tiếp với mẫu từ nguồn. Hai dấu chấm trang 5 và 9 máy nhận dạng ảnh đọc chưa rõ; kiểm nét và ảnh cho thấy đủ dấu chấm đúng.',
          '- Đã xem ảnh trước/sau từng ô số, mục lục, chữ chung và cả 8 biểu đồ; không đổi kiểu chữ bằng phông ngoài.', '',
          'HP là mã lực, kW là kilôoát; diameter nghĩa là đường kính. OCR là nhận dạng chữ trong ảnh. SHA256 là mã kiểm tra nội dung file. XML là dữ liệu cấu trúc lưu thông tin trong PDF.', '',
          f"File nguồn: {st['source']}", '', f"File ra: {st['destination']}", '',
          f"SHA256 nguồn trước/sau: {acc['source_sha256']}", '', f"SHA256 file ra: {acc['destination_sha256']}", '',
          'Mọi PDF được ghi bằng catfix. Không cài phần mềm. Bản nguồn không bị ghi đè, đổi tên hoặc xóa. Bản kết quả trước khi làm rõ nhãn và các mẫu thử được giữ trong G03/review.', '',
          'Cần anh quyết: không có câu hỏi duyệt đang chờ; #34 cần xử lý giới hạn thiếu mẫu chữ k mà vẫn giữ quy tắc phông gốc.', '',
          'Phát hiện thêm chưa sửa: không ghi thêm lỗi máy bơm ngoài dữ liệu đã kiểm; phần thiếu k của #34 nêu ở trên.', '',
          'Tiến độ: G03 CHƯA XONG – 14/15 ĐẠT, còn #34.', '',
          'Bằng chứng: So sanh G03.png; G03/acceptance-final.json; G03/ratio-calculation.json; G03/font-resources.json; nhật ký sửa tự lưu trong _BAO CAO.', '',
          'Lập báo cáo: ' + datetime.datetime.now().isoformat()]
Path(outpath).write_text('\n'.join(lines),encoding='utf-8')

# Bảng đo trước/sau lưu đủ mọi điểm, không bỏ điểm thiếu giao miền ở bản nguồn.
graphpath = fresh(root / 'BAO CAO BIEU DO.md')
jsonpath = fresh(root / 'BAO CAO BIEU DO.json')
gtext = ['# G03 – nghiệm thu 69 đường, 414 điểm', '',
         'Ngưỡng: max(1 mét, 2% cột áp bảng). Trang 3–8: Q lít/phút. Trang 9–10: Q m³/giờ. H và độ lệch tính bằng mét. “Không có” nghĩa là đường nguồn không bao phủ điểm lưu lượng đó; không đổi thành 0.', '',
         '| Trang | Dòng sản phẩm | Q | H bảng | H đường trước | Lệch trước | H đường sau | Lệch sau | Ngưỡng | Kết quả sau |',
         '|---|---|---|---|---|---|---|---|---|---|']
grows = []
fmt = lambda v: 'Không có' if v is None else f'{float(v):.6f}'
for z in acc['curves_saved_readback']:
    for a,b in zip(z['before'],z['points']):
        grows.append(dict(page=z['page'],model=z['model'],units=z['units'],before=a,after=b,
                          style_checks=z['style_checks'],endpoint_max_error=z['endpoint_max_error']))
        gtext.append(f"| {z['page']} | {z['model']} | {b['Q']} | {b['H_table']} | {fmt(a['H_curve'])} | {fmt(a['diff'])} | {fmt(b['H_curve'])} | {fmt(b['diff'])} | {b['tolerance']:.3f} | {'ĐẠT' if b['ok'] else 'CHƯA ĐẠT'} |")
gtext += ['', f"Tổng 69 đường; {len(grows)}/414 điểm đạt. Kiểm độc lập trên PDF đã lưu: G03/acceptance-final.json. Ảnh: So sanh G03.png, G03/so-sanh-cuoi-p3.png đến p10.png."]
Path(graphpath).write_text('\n'.join(gtext),encoding='utf-8')
Path(jsonpath).write_text(json.dumps(grows,ensure_ascii=False,indent=1,default=str),encoding='utf-8')
if len(grows)!=414: raise RuntimeError('Chưa đủ 414 điểm')
S.progress('G03','CHƯA XONG','14/15 ĐẠT; #34 còn KW/Kw do thiếu chữ k cùng kiểu trong PDF, không có phông nhúng/lớp chữ; 69 đường/414 điểm đạt; xem BAO CAO G03.md')
print('G03: 15 việc · ĐẠT 14 · CHƯA ĐẠT 1 · CHƯA THỂ XÁC MINH 0',flush=True)
print(outpath,flush=True)
