from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
import json
from pathlib import Path
E=Editor(S.dst('Perotac bơm giếng SP_compressed (bản mới).pdf'));R=Raster(E);cv=R.render_canvas(5,(84,12,137,185),dpi=600)
words=R.ocr(cv,scale=1,psm=6);out=[]
for w in words:
 rr=cv.rect(w['box']);out.append(dict(text=w['text'],rect=rr,box=w['box'],conf=w['conf']));print(w['text'],rr,w['conf'],flush=True)
Path(fresh(S.report('G05/BO SUNG MA MODEL/VI TRI.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
