import numpy as np, cv2
from PIL import Image

LABELS={5:['Cruss','recessed','pan','head','screw','and','washer','assemblie'],
        13:['Cross','recessed','pan','head','screw','and','washer','assemblie'],
        15:['Hexagon','socket','head','cap','screw'],
        18:['Hexagon','socket','head','cap','screw'],
        28:['Mechanical','flat','pad']}

def grid_mask(cv, geometry):
    out=np.zeros(cv.work.shape[:2],np.uint8)
    gray=cv.gray()
    records=[]
    for rec in geometry['grids']:
        r=rec['rect'];b=cv.box(r);x0,y0,x1,y1=map(int,b)
        dark=gray[y0:y1,x0:x1]<160
        vx=np.where(dark.mean(axis=0)>.8)[0]
        hy=np.where(dark.mean(axis=1)>.8)[0]
        for x in vx:out[max(0,y0-2):min(out.shape[0],y1+2),max(0,x0+x-1):min(out.shape[1],x0+x+2)]=1
        for y in hy:out[max(0,y0+y-1):min(out.shape[0],y0+y+2),max(0,x0-2):min(out.shape[1],x1+2)]=1
        records.append(dict(rect=r,vertical_pixels=[int(x+x0) for x in vx],horizontal_pixels=[int(y+y0) for y in hy]))
    return out.astype(bool),records

def word_piece(cv,R,w,cell,grid,label):
    x0=max(cell[0],int(np.floor(w['box'][0]))-2)
    x1=min(cell[2],int(np.ceil(w['box'][2]))+2)
    y0,y1=cell[1],cell[3]
    a=R.alpha_of(cv.work[y0:y1,x0:x1],np.full(3,255.,np.float32),np.zeros(3,np.float32))
    a[grid[y0:y1,x0:x1]]=0
    a[a<.08]=0
    ys,xs=np.where(a>.2)
    if not len(xs):raise RuntimeError('Không có mực từ '+label)
    l,t,r,b=max(0,int(xs.min())-1),max(0,int(ys.min())-1),min(a.shape[1],int(xs.max())+2),min(a.shape[0],int(ys.max())+2)
    alpha=a[t:b,l:r].copy()
    box=(x0+l,y0+t,x0+r,y0+b)
    cc=R.components(cv,tuple(w['box']),bg=np.full(3,255.,np.float32),ink=np.zeros(3,np.float32),expect=len(label))
    metric=None
    if len(cc)==len(label):
        bots=[c['box'][3] for ch,c in zip(label,cc) if ch not in R.DESC and ch not in R.LOWMARK]
        if bots:metric=float(np.median(bots))
    cap=cc[0]['alpha'].shape[0] if cc and label[0].isupper() else None
    return dict(text=label,ocr_text=w['text'],box=box,alpha=alpha,bg=np.full(3,255.,np.float32),ink=np.zeros(3,np.float32),
                baseline_metric=metric,capital_height=cap,component_count=len(cc))

def scaled_piece(piece,factor,baseline):
    a=piece['alpha'];ww=max(1,round(a.shape[1]*factor));hh=max(1,round(a.shape[0]*factor))
    al=np.array(Image.fromarray(a.astype('float32')).resize((ww,hh),Image.Resampling.BICUBIC)).clip(0,1)
    return dict(text=piece['text'],box=(0,0,ww,hh),alpha=al,bg=piece['bg'],ink=piece['ink'],
                boff=(piece['box'][3]-baseline)*factor,source_box=piece['box'])
