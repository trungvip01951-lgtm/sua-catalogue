"""Đo phong cách/η/chữ từ nguyên ảnh Perotac p8; chưa tạo mẫu thay đổi."""
from catwork import start, fresh
S, D, N = start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
from scipy import ndimage
from scipy.interpolate import PchipInterpolator
from graph_image_math import color_runs, follow_observed_ink
from g04_perotac_audit_data import DATA
from g04_perotac_audit_labels_manual import MANUAL
import numpy as np, json, hashlib, math

name = 'Perotac bơm giếng SA_compressed (bản mới).pdf'
src, current = S.src(name), S.result(name)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src) == '3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(current) == '389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
folder = Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
def save_source_once(raw, path):
    p=Path(path)
    if p.exists():
        assert np.array_equal(np.asarray(Image.open(p).convert('RGB')),np.asarray(raw)),p
    else:raw.save(fresh(p))
audit = json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'))
g = next(z for z in audit['graphs'] if z['family'] == '4SA16')
table = next(z for z in DATA if z['family'] == '4SA16')
E = Editor(src, backend='fitz'); R = Raster(E); im = max(R.images(7), key=lambda z: z.W*z.H); cv = R.canvas(im)
a = cv.orig.astype(float); lum = a @ [.299,.587,.114]; chroma = a.max(2)-a.min(2)
step_pt = float(np.linalg.norm(im.ctm[:2,0])/im.W)
curves=[]; allrgb=[]; widths=[]; added_source_style_traces=[]
for c in g['curves']:
    source_path=c.get('native_path')
    if not source_path:
        # Previously accepted /23,/18 were excluded from the old numerical audit.
        # For the new whole-chart style, follow their ORIGINAL colored source ink
        # beside the explicit label, without using table H or the accepted vector.
        assert c['model'] in ['4SA16/23','4SA16/18']
        suffix=int(c['model'].split('/')[-1]);lx,ll=MANUAL['4SA16'];_,t,b=next(z for z in ll if z[0]==suffix)
        source_mask=(chroma>=9)&(lum<225)&(a[:,:,2]>=a[:,:,0]+6)
        source_weights=(255-lum)*source_mask
        getcol=lambda u:color_runs(source_mask,source_weights,u,181,571,max_width=13)
        candidates=[z for z in getcol(lx-6) if t-8<=z['v']<=b+8]
        assert len(candidates)==1,(c['model'],candidates)
        named_seed=dict(u=lx-6,**candidates[0])
        aa,ai=follow_observed_ink(getcol,named_seed,126,-1,6,9)
        bb,bi=follow_observed_ink(getcol,named_seed,684,1,6,9)
        source_path=aa[:0:-1]+bb
        assert not ai and not bi,(c['model'],ai,bi)
        added_source_style_traces.append(dict(model=c['model'],literal_label_native_box=[lx,t,lx+68,b],
                                              source_seed=named_seed,observed_source_path=source_path,
                                              numerical_reacceptance_not_claimed=True,table_H_not_used_for_trace=True))
    xy = np.array([[p['u'],p['v']] for p in source_path]); xs,ys=xy[:,0],xy[:,1]
    rgb=[]; w=[]; dashes=[]
    for u in range(128,630):
        if not xs[0]<=u<=xs[-1]: continue
        v=float(np.interp(u,xs,ys)); vv=int(round(v)); near=xy[abs(xs-u)<6]; sl=float(np.polyfit(near[:,0],near[:,1],1)[0]) if len(near)>3 else 0
        if u<279:
            win=a[max(0,vv-3):vv+4,u]; ll=win@[.299,.587,.114]; cc=win.max(1)-win.min(1)
            visible=np.any((cc>=8)&(ll<220));dashes.append(dict(u=u,visible=bool(visible)))
        if u<360 or any(abs(u-z['u_native'])<5 for z in g['axis']['flow_ticks']):continue
        rr=np.arange(vv-5,vv+6); core=(chroma[rr,u]>=10)&(lum[rr,u]<210)
        if not core.any():continue
        j=rr[core][np.argmin(lum[rr[core],u])];rgb.append(a[j,u].tolist())
        bglevel=float(np.median(np.r_[lum[vv-10:vv-6,u],lum[vv+7:vv+11,u]]))
        darkness=np.maximum(bglevel-lum[rr,u],0); darkness[~((chroma[rr,u]>=5)&(lum[rr,u]<235))]=0
        if darkness.max()>0:
            width=float(darkness.sum()/darkness.max()/math.sqrt(1+sl*sl)*step_pt);w.append(width)
    med=np.median(rgb,axis=0).tolist();allrgb.extend(rgb);widths.extend(w)
    intervals=[]
    for p in dashes:
        if p['visible']:
            if intervals and p['u']==intervals[-1][1]+1:intervals[-1][1]=p['u']
            else:intervals.append([p['u'],p['u']])
    curves.append(dict(model=c['model'],source_median_core_RGB=med,source_sample_count=len(rgb),
                       source_equivalent_width_pt_median=float(np.median(w)),
                       source_equivalent_width_pt_p10_p90=np.percentile(w,[10,90]).tolist(),
                       source_only_observed_dash_native_intervals=intervals,
                       dash_sampling_is_read_only_and_requires_visual_verification=True,
                       literal_table_row_H=next(r['H'] for r in table['rows'] if r['model']==c['model'])))

# Eta panel has a single colored observed curve. Use actual ink; no H/Q table.
eta_mask=(chroma>=9)&(lum<228)&(a[:,:,2]>=a[:,:,0]+6)
eta_weights=(255-lum)*eta_mask
def cols(u):
    # The isolated eta curve can have two colored JPEG fringes separated by
    # a neutral core. Merge nearby fragments of that same observed stroke;
    # retain non-neighboring branches as unresolved issues.
    rr=color_runs(eta_mask,eta_weights,u,585,676,max_width=13);merged=[]
    for z in rr:
        if merged and z['lo']-merged[-1]['hi']<=3:
            old=merged[-1];strength=old['strength']+z['strength']
            old.update(v=(old['v']*old['strength']+z['v']*z['strength'])/strength,
                       strength=strength,hi=z['hi'],width=z['hi']-old['lo']+1)
        else:merged.append(dict(z))
    return merged
seed_candidates=cols(450);assert len(seed_candidates)==1,seed_candidates
seed=dict(u=450,**seed_candidates[0])
left,li=follow_observed_ink(cols,seed,126,-1,5,3)
right,ri=follow_observed_ink(cols,seed,686,1,5,3)
eta=left[:0:-1]+right
print('ETA SOURCE TRACE ISSUES', len(li),len(ri), flush=True)
eta_rgb=[]
for p in eta:
    u=p['u'];v=int(round(p['v']));rr=np.arange(max(585,v-2),min(677,v+3));mm=eta_mask[rr,u]
    if mm.any():j=rr[mm][np.argmin(lum[rr[mm],u])];eta_rgb.append(a[j,u].tolist())
eta_info=dict(source_image='X7 original JPEG only',
              source_native_observed_points=eta, first_observed=eta[0],last_observed=eta[-1],
              ambiguous_branches=li+ri, source_median_core_RGB=np.median(eta_rgb,axis=0).tolist(),
              actual_table_for_eta_present=False, no_numeric_eta_acceptance_claimed=True,
              source_endpoint_not_extrapolated=True,
              allowed_method='Bám mực JPEG nguồn; khớp nét trơn trong sai số định vị nguồn, không dựng từ bảng Q–H và không suy số hiệu suất mới.')
save_source_once(Image.fromarray(cv.orig[578:679,115:751]),folder/'HIEU SUAT ETA NGUON150dpi.png')

# Exact source words: no external font, no replacement glyph has been made.
labelx, labels=MANUAL['4SA16'];glyph_sources=[]
for suffix,t,b in labels:
    box=[labelx-2,t-2,labelx+68,b+3]
    raw=Image.fromarray(cv.orig[box[1]:box[3],box[0]:box[2]])
    path=str(folder/f'CHU NGUON 4SA16-{suffix} NGUYEN150dpi.png');save_source_once(raw,path)
    # Original neutral letter pixels only. Save the source, not a new outline.
    rgb=cv.orig[box[1]:box[3],box[0]:box[2]].astype(int);l=rgb@[.299,.587,.114];croma=rgb.max(2)-rgb.min(2)
    black=(l<90)&(croma<25)
    ys0,xs0=np.where(black)
    bbox=[int(xs0.min()),int(ys0.min()),int(xs0.max()+1),int(ys0.max()+1)]
    glyph_sources.append(dict(literal='4SA16/'+str(suffix), original_native_box=box,original_source_file=path,
                              neutral_ink_bbox_within_crop=bbox,neutral_ink_cap_height_px=bbox[3]-bbox[1],
                              source_same_file=True,original_label_identity_matches_literal_table=True,
                              font_program=None,new_vector_glyph_written=False))

# PCHIP here is numeric planning only: no visible chart or PDF is created.
numeric_plan=[]
q=np.array(table['Q_m3_h'],float)
for idx,row in enumerate(table['rows'],1):
    h=np.array(row['H'],float);p=PchipInterpolator(q,h,extrapolate=False);xx=np.linspace(q[0],q[-1],2101)
    yy=p(xx);err=float(np.max(abs(p(q)-h)));assert err<1e-10 and np.max(np.diff(yy))<1e-9
    numeric_plan.append(dict(legend_key=idx,model=row['model'],source_H_m=row['H'],source_Q_m3_h=table['Q_m3_h'],
                             starts_at_literal_QH=[float(q[0]),float(h[0])],ends_at_literal_QH=[float(q[-1]),float(h[-1])],
                             interpolator='PCHIP, nội suy từng đoạn giữ hình và đi qua đúng ô số',
                             planning_max_literal_cell_error_m=err,monotone_decreasing_in_numeric_plan=True,
                             no_sample_drawn=True,no_extrapolation=True))
out=dict(read_only=True,PDF_sample_created=False,source_sha256=sha(src),current_sha256=sha(current),
         source_pixel_to_page_pt=step_pt, QH_source_styles=curves,
         common_QH_source_color_median_RGB=np.median(allrgb,axis=0).tolist(),
         common_QH_equivalent_width_pt_median=float(np.median(widths)),
         equivalent_width_is_not_literal_original_PDF_pen_width=True,
         eta_source=eta_info,glyph_word_sources=glyph_sources,numeric_plan_104_cells=numeric_plan,
         prior_accepted_models_original_source_style_trace_only=added_source_style_traces,
         plan104_numeric_pass=True,actual_PDF104_acceptance_not_yet_run=True,
         source_fonts_absent=True,no_external_font_used=True,common_progress_written=False)
Path(fresh(folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('QH COLORS',out['common_QH_source_color_median_RGB'],'WIDTH',out['common_QH_equivalent_width_pt_median'],flush=True)
print('ETA',len(eta),eta[0],eta[-1],'RGB',eta_info['source_median_core_RGB'],flush=True)
for c in curves:print(c['model'],c['source_median_core_RGB'],round(c['source_equivalent_width_pt_median'],4),c['source_only_observed_dash_native_intervals'],flush=True)
print('GLYPH CAPS',[(z['literal'],z['neutral_ink_cap_height_px']) for z in glyph_sources],flush=True)
E.close()
