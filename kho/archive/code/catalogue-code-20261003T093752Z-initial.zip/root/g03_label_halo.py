from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.cs import Instr
from catfix import verify
from pathlib import Path
import json,numpy as np,sys
root=Path(S.report('G03'));st=json.loads((root/'build-state.json').read_text(encoding='utf-8'))
pages=[7] if len(sys.argv)==1 else list(range(3,11))
E=Editor(st['destination'])
details=[]
for pg in pages:
    P=E.page(pg-1); curves=[c for c in st['curves'] if c['page']==pg];last=max(c['oi'] for c in curves)
    scale=float(np.sqrt(abs(np.linalg.det(P.objs[last]['ctm'][:2,:2]))))
    halo_width=0.75/scale
    ins=[]
    for z in curves:
        pp=[];fill=None
        for oi in z['label_objects']:
            col=P.objs[oi]['fill']
            if fill is None:fill=col
            elif fill!=col:raise RuntimeError('Màu nhãn không đồng nhất')
            pp+=P.object_pagepath(oi)
        local=E._to_local(pg-1,last,pp)
        ins += [Instr([],'q'),Instr([1],'g'),Instr([1],'G'),Instr([halo_width],'w')]+local+[Instr([],'B')]
        ins += [Instr(list(fill[1]),fill[0])]+local+[Instr([],'f'),Instr([],'Q')]
        details.append(dict(page=pg,model=z['model'],label_objects=z['label_objects'],template=last,width_page=0.75,fill=fill))
    E.insert_instrs(pg-1,P.objs[last]['i1']+1,ins,before=True)
    print('Viền trắng theo nét chữ',pg,len(curves),flush=True)
label='nhan-trang7' if pages==[7] else 'nhan-toan-file'
out=fresh(root/'review'/f'{label}.pdf');E.save(out);E.close()
json.dump(dict(source=st['destination'],destination=out,details=details),open(fresh(root/'review'/f'{label}.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
for pg in pages:
    axis=next(a for a in st['axes'] if a['page']==pg)
    verify.compare_sheet(st['destination'],out,[(pg-1,axis['rect'],f'Nhãn biểu đồ trang {pg}: viền trắng theo nét chữ')],fresh(root/'review'/f'{label}-p{pg}.png'),dpi=260)
print(out,flush=True)
