"""Complete one-color source caption contours; straight1 and few curves2358."""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import cv2
from scipy.interpolate import BSpline
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'TOAN BO CHU NGUON IT DOAN CONG V2'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
old=read(base/'CHU A NET XIEN THANH NGANG NGUON/CHU A NET THANG TU NGUON VA13 TEN RAM CHUA NGHIEM THU.json');raw=read(base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json');by={r['key']:r for r in raw['candidates']};zoom=64
def periodic_fit(pt,n):
    closed=np.vstack([pt,pt[0]]);d=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(closed,axis=0),axis=1))];t=np.linspace(0,1,800,endpoint=False);target=np.column_stack([np.interp(t*d[-1],d,closed[:,k]) for k in [0,1]])
    knots=np.arange(-3,n+4,dtype=float)/n;BB=BSpline.design_matrix(t,knots,3).toarray();B=BB[:,:n].copy();B[:,:3]+=BB[:,n:];DD=np.eye(n)*-2+np.roll(np.eye(n),1,axis=1)+np.roll(np.eye(n),-1,axis=1);c=np.linalg.solve(B.T@B+.1*(DD.T@DD),B.T@target);sp=BSpline(knots,np.vstack([c,c[:3]]),3,extrapolate=False)
    ss=sp(np.linspace(0,1,4096,endpoint=False));bb=np.r_[pt.min(0),pt.max(0)];nb=np.r_[ss.min(0),ss.max(0)];f=(bb[2:]-bb[:2])/(nb[2:]-nb[:2]);off=bb[:2]-nb[:2]*f;c=c*f+off;sp=BSpline(knots,np.vstack([c,c[:3]]),3,extrapolate=False);ss=sp(np.linspace(0,1,4096,endpoint=False));segs=[]
    for j in range(n):
        a=j/n;b=(j+1)/n;delta=(b-a)/3;p=sp(a);q=sp(b);segs.append([p.tolist(),(p+sp.derivative()(a)*delta).tolist(),(q-sp.derivative()(b)*delta).tolist(),q.tolist()])
    hd=max(float(cKDTree(pt).query(ss)[0].max()),float(cKDTree(ss).query(pt)[0].max()));area=abs(float(np.sum(ss[:,0]*np.roll(ss[:,1],-1)-ss[:,1]*np.roll(ss[:,0],-1))/2))
    return dict(local_native_xy=ss.tolist(),cubic_segments_local_native=segs,curve_segments=n,C2_periodic=True,source_boundary_max_symmetric_distance_native_px=hd,area_native_px=area,source_bbox_restored=True)
def L(a,b):a=np.asarray(a,float);b=np.asarray(b,float);return [a.tolist(),(a+(b-a)/3).tolist(),(a+2*(b-a)/3).tolist(),b.tolist()]
def sample(segments):
    out=[]
    for s in segments:
        c=np.asarray(s);t=np.linspace(0,1,200,endpoint=False)[:,None];out.extend(((1-t)**3*c[0]+3*(1-t)**2*t*c[1]+3*(1-t)*t**2*c[2]+t**3*c[3]).tolist())
    return np.asarray(out)
font=[];tries=[];tiles=[]
for src in old['glyphs']:
    ch=src['character']
    if ch not in ['1','2','3','5','8']:font.append(src);continue
    r=by[src['source_key']];al=np.asarray(r['alpha']);h,w=al.shape;up=cv2.resize(np.pad(al,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);m=up>=r['iso_mass_match_threshold'];co,hh=cv2.findContours(m.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);ps=[]
    for i,cc in enumerate(co):
        pt=(cc[:,0,:].astype(float)+.5)/zoom-1;areaold=abs(cv2.contourArea(cc)/zoom**2)
        if ch=='1':
            segments=[[[2.492,.664],[2.21,.86],[1.78,1.30],[1.445,1.773]],L((1.445,1.773),(.242,2.508)),L((.242,2.508),(.493,2.852)),
             [[.493,2.852],[.875,3.01],[1.62,2.93],[1.945,3.492]],L((1.945,3.492),(1.945,7.523)),[[1.945,7.523],[1.98,7.86],[2.35,8.133],[2.508,8.133]],
             [[2.508,8.133],[2.71,8.133],[3.09,7.72],[3.085,7.508]],L((3.085,7.508),(3.13,1.70)),[[3.13,1.70],[3.108,1.246],[2.998,.791],[2.492,.664]]]
            ss=sample(segments);bb=np.r_[pt.min(0),pt.max(0)];nb=np.r_[ss.min(0),ss.max(0)];f=(bb[2:]-bb[:2])/(nb[2:]-nb[:2]);off=bb[:2]-nb[:2]*f;segments=(np.asarray(segments)*f+off).tolist();ss=sample(segments)
            hd=max(float(cKDTree(pt).query(ss)[0].max()),float(cKDTree(ss).query(pt)[0].max()));ar=abs(float(np.sum(ss[:,0]*np.roll(ss[:,1],-1)-ss[:,1]*np.roll(ss[:,0],-1))/2));chosen=dict(local_native_xy=ss.tolist(),cubic_segments_local_native=segments,curve_segments=9,source_true_straight_stem_kept=True,source_bbox_restored=True,source_boundary_max_symmetric_distance_native_px=hd,area_native_px=ar)
        else:
            ns=[12,14,16,18] if hh[0,i,3]<0 else [4,6,8];chosen=None
            for n in ns:
                z=periodic_fit(pt,n);delta=(z['area_native_px']/areaold-1)*100;tries.append(dict(character=ch,parent=int(hh[0,i,3]),segments=n,source_max_symmetric_distance_native_px=z['source_boundary_max_symmetric_distance_native_px'],area_delta_percent=delta))
                if z['source_boundary_max_symmetric_distance_native_px']<=1 and abs(delta)<=10:chosen=z;break
            if chosen is None:chosen=z;chosen['source_shape_not_accepted']=True
        chosen.update(parent=int(hh[0,i,3]),source_original_contour_area_native_px=areaold,area_vs_source_contour_percent=(chosen['area_native_px']/areaold-1)*100);ps.append(chosen)
    img=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);d=ImageDraw.Draw(img)
    for p in ps:d.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p['local_native_xy']],fill=255 if p['parent']<0 else 0)
    mi=np.asarray(img)>0;cc,chh=cv2.findContours(mi.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);area=float(mi.sum()/zoom**2);g=dict(**src);g['cleaned_contour_paths']=ps;g.update(few_curves_from_original_source_iso=True,few_curve_total_segments=sum(p['curve_segments'] for p in ps),few_curve_area_native_px=area,few_curve_vs_original_alpha_area_delta_percent=(area/r['alpha_integral_native_px']-1)*100,
       few_curve_max_source_boundary_distance_native_px=max(p['source_boundary_max_symmetric_distance_native_px'] for p in ps),few_curve_outer_components=int(sum(chh[0,j,3]<0 for j in range(len(cc)))),few_curve_holes=int(sum(chh[0,j,3]>=0 for j in range(len(cc)))),source_counter_contour_bbox_and_area_recorded=True,ROOT_graphic_style_acceptance_pending=True)
    font.append(g);vi=Image.new('RGB',((w+2)*24,(h+2)*24),'white');dd=ImageDraw.Draw(vi)
    for p in ps:dd.polygon([((x+1)*24,(y+1)*24) for x,y in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
    rawim=Image.open(base/'DO BIEN GIU LUONG MUC NGUON'/(src['source_key']+' NGUON150dpi.png'));tile=Image.new('RGB',(800,300),'white');tile.paste(rawim.resize((w*24,h*24),Image.Resampling.NEAREST),(10,10));tile.paste(vi,(400,0));tile.save(fresh(root/(ch+' NGUON VA IT DOAN CONG V2.png')));tiles.append(tile)
    print(ch,'SEG',g['few_curve_total_segments'],'AREA%',g['few_curve_vs_original_alpha_area_delta_percent'],'HD',g['few_curve_max_source_boundary_distance_native_px'],'TOPO',g['few_curve_outer_components'],g['few_curve_holes'],flush=True)
bank={r['character']:r for r in font};sheet=Image.new('RGB',(1750,2600),'white');dr=ImageDraw.Draw(sheet)
for i,word in enumerate(old['words']):
    x=15.;y=i*200+140.;scale=14
    for c in word['literal']:
        g=bank[c]
        for p in g['cleaned_contour_paths']:dr.polygon([(x+xx*scale,y+(yy-9)*scale) for xx,yy in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
        x+=g['native_advance']*scale
sheet.save(fresh(root/'13 TEN CHU NGUON TOAN BO IT DOAN CONG V2 RAM.png'));atlas=Image.new('RGB',(1600,900),'white')
for i,t in enumerate(tiles):atlas.paste(t,((i%2)*800,(i//2)*300))
atlas.save(fresh(root/'1 2 3 5 8 NGUON VA IT DOAN CONG V2.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==old['source_sha256'] and sha(S.result(name))==old['current_sha256']
Path(fresh(root/'TOAN BO12 CHU NGUON IT DOAN CONG V2 RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_small_caption_only=True,one_color_original_source_RGB=[57,55,57],glyphs=font,words=old['words'],all_component_fit_trials=tries,no_font_program_name_invented=True,source_counter_advance_bbox_kept=True,source_ONE_native_pixel_uncertainty_per_ROOT=True,no_PDF_font_or_progress_written=True,ROOT_and_graphic_acceptance_pending=True),ensure_ascii=False,indent=2),encoding='utf8')
