"""New readable report only; keep the previous evidence/report intact."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import hashlib
O=Path(S.report('G04/g01 KIEM DOC LAP CHU NHO REDPUMP RAM V5'))
p=O/'g01_BAO CAO8 COT CHU NHO REDPUMP V5 VA TOA DO5 9.md'
t=p.read_text(encoding='utf8')
replacements={
 'Đã mở13nhãn/biểuđồ150và600 điểmảnh mỗiinch.':'Đã mở 13 nhãn và toàn biểu đồ ở 150 và 600 điểm ảnh mỗi inch.',
 'donor5 hiện lấy4SL3/35p5, đã có3mảnh ở mức mực0,085.':'Chữ 5 mẫu hiện lấy từ 4SL3/35 trang 5, đã có 3 mảnh ở mức mực 0,085.',
 'V5 làm các mảnh đậm/rời thấy rõ hơn ở cỡ150; dáng5 hẹp, đầu tròn so số5 nguyên nhãn sạch4SL16/25p8.':'V5 làm các mảnh đậm và rời thấy rõ hơn ở cỡ 150; dáng 5 hẹp, đầu tròn so số 5 nguyên nhãn sạch 4SL16/25 trang 8.',
 'Chân9 vẫn thuộc1cụm và có1lỗ':'Chân 9 vẫn thuộc 1 cụm và có 1 lỗ',
 'Tíchphân5+57,39%/9+36,03%':'Tích phân mực 5 +57,39% và 9 +36,03%',
 'giới hạn đo mựcJPEG':'giới hạn đo mực JPEG (ảnh nén gốc)',
 'metadata giữtỷlệ1':'dữ liệu tọa độ giữ tỷ lệ 1',
 'ở150. Hộp mực600':'ở 150. Hộp mực 600',
 'Nguồn p8 và M1 đều0phông nhúng; danh tính/cỡ phông danh nghĩa chưa thể truyra từJPEG.':'Nguồn trang 8 và mẫu 1 đều có 0 phông nhúng; danh tính và cỡ phông danh nghĩa chưa thể truy ra từ ảnh JPEG.',
 'Có ứng viên5 sạch ngay4SL16/25p8 cùng hồsơ2ký tự4/S, nhưng chưa tự xácnhận donor hoặc đổi bộ chữ.':'Có ứng viên số 5 sạch ngay nhãn 4SL16/25 trang 8 cùng hồ sơ 2 ký tự 4/S, nhưng chưa tự xác nhận chữ mẫu hoặc đổi bộ chữ.',
 'Tác nhân ghi cần đọc trực tiếp ứng viên và kiểm cùng kiểu/cỡ trước dùng; không thay font ngoài, không chỉnh xám theo từng ký tự, không ép tíchphân.':'Tác nhân ghi cần đọc trực tiếp ứng viên và kiểm cùng kiểu/cỡ trước dùng; không thay phông ngoài, không chỉnh xám theo từng ký tự, không ép tích phân mực.',
 'So nguyên chữ nhỏ của chính Redpump p8':'So nguyên chữ nhỏ của chính Redpump trang 8',
 'đối chứng thêm nguồn donor thật.':'đối chứng thêm chữ mẫu thật trong nguồn.',
 'RGB63 và độ đục1':'RGB 63 (ba kênh màu xám) và độ đục 1 (không trong suốt)',
 'tíchphân':'tích phân',
 'Donor5 p5 đã có3mảnh từJPEG:':'Chữ 5 mẫu trang 5 đã có 3 mảnh từ ảnh JPEG:',
 'V5 tô một màu làm mảnh rời/độ đậm nhìn lộ hơn và hình5 hẹp hơn mẫu sạchp8.':'V5 tô một màu làm mảnh rời và độ đậm nhìn lộ hơn; hình 5 hẹp hơn mẫu sạch trang 8.',
 'Donor9 p3 chỉ1cụm/1lỗ tại ngưỡng0,085, nhưng tail trongRAM phình rõ;':'Chữ 9 mẫu trang 3 chỉ 1 cụm/1 lỗ tại ngưỡng 0,085, nhưng chân trong bộ nhớ phình rõ;',
 'phôngPASS':'phông đạt',
 'số5':'số 5','số9':'số 9','chân9':'chân 9','dáng5':'dáng 5','phôngPASS':'phông đạt',
 'ảnh150/600':'ảnh 150/600','ở150':'ở 150','và600':'và 600','kiểu/cỡ':'kiểu và cỡ',
 'Đã mở13':'Đã mở 13','metadata':'dữ liệu mô tả','retouch (tô sửa ảnh)':'tô sửa ảnh',
}
for old,new in replacements.items():t=t.replace(old,new)
t+='\nPhiếu này chỉ làm rõ cách viết; không thay tọa độ, dữ liệu glyph (hình ký tự), ảnh hay kết luận nghiệm thu.\n'
out=Path(fresh(O/'g01_BAO CAO CHU NHO REDPUMP V5 BAN DOC RO VA TOA DO5 9.md'))
out.write_text(t,encoding='utf8')
print(out,'SHA',hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
