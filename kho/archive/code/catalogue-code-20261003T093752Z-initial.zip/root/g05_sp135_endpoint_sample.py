"""MẫuPNG1: chỉ sửa2đuôi 10SP135-5/-7 từQ≈162 đếnQ180.
Nét nguồn nhận dạng độc lập nhãn/rank; giữ số/chữ/10nét còn lại từngpixel.
Không ghiPDF tronglượt mẫu này.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from catfix.vector import Editor
from catfix.raster import Raster,RenderCanvas
from catfix.charts import draw_polyline,bezier
from scipy.interpolate import UnivariateSpline,PchipInterpolator,CubicHermiteSpline
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib

name='Perotac bơm giếng SP_compressed (bản mới).pdf';current=S.dst(name)
before=hashlib.sha256(Path(current).read_bytes()).hexdigest();assert before=='bc015b9e872b23d17e717f196c5ddc93937a3e69cc2b5e2fea77d3365f07f593'
P='G05/KIEM TOAN TOAN BO/';I='G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO/';O='G05/10SP135 HAI MOC CUOI/MAU 1/'
audit=json.loads(Path(S.report(I+'NGHIEM THU QH PDF MAU.json')).read_text(encoding='utf8'));b=next(z for z in json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8')) if z['family']=='10SP135');t=TABLES['10SP135']
E=Editor(current);R=Raster(E);im=R.image_at(10,(b['x0'],b['y0'],b['x1'],b['y1']));cv=R.canvas(im);a=cv.orig.copy();bg=a.copy();r=b['rect'];s=72/b['dpi']
xt=np.array(b['xticks']);yt=np.array(b['yticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]));qx=lambda x:float(np.interp(x,xt[:,1],xt[:,0]))
nx=lambda x:float(cv.to_px(x,b['y0'])[0]);ny=lambda y:float(cv.to_px(b['x0'],y)[1]);pagey=lambda y:float(cv.to_page(0,y)[1])
splines=[]
for k,row in enumerate(t['rows']):
 bins={}
 for p in audit['points']:
  if p['family']!='10SP135' or p['row']!=k+1 or p.get('H_curve_m') is None:continue
  for z in p['sample_locations']:
   x=nx(r[0]+z['x_px']*s);y=ny(r[3]-z['y_px']*s);bins.setdefault(round(x,4),[]).append(y)
 sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx]);spl=UnivariateSpline(sx,sy,s=len(sx)*.06,k=3);res=float(np.max(abs(spl(sx)-sy)));assert res<1
 splines.append(spl)

xp0=nx(b['x0']);xp1=nx(b['x1']);yp0=ny(b['y1']);yp1=ny(b['y0']);xlo=int(np.ceil(nx(px(162))));xend=nx(px(180));xhi=int(np.ceil(xend+9));ylo=int(np.ceil(yp0+3));yhi=int(np.floor(yp1-3))
body=a[ylo:yhi,int(np.ceil(xp0+5)):int(np.floor(xp1-5))].astype(float);vp=np.median(body,axis=0);hp=np.median(body,axis=1);base=np.percentile(body.reshape(-1,3),98,axis=0);gridys=np.array([ny(y) for h,y in b['yticks']]);gridxs=np.array([nx(x) for q,x in b['xticks']])
def background(x,ys):
 yy=np.clip(np.asarray(ys,dtype=int)-ylo,0,len(hp)-1);xx=int(np.clip(x-int(np.ceil(xp0+5)),0,len(vp)-1));v=np.tile(base,(len(yy),1));use=np.min(abs(np.asarray(ys)[:,None]-gridys),axis=1)<=3.;v[use]=hp[yy[use]];return np.minimum(v,vp[xx])

selected=[6,8];tube=np.zeros(a.shape[:2],bool);native_protected=np.zeros(a.shape[:2],bool)
for x in range(xlo,xhi+1):
 centres=np.array([z(min(x,xend)) for z in splines]);yy=np.arange(ylo,yhi);dist=abs(yy[:,None]-centres);owner=dist.argmin(1)
 for k in selected:
  # Erase source ink+JPEG fringe within its own Voronoi cell, reserve onepixel
  # before neighbourmidpoint. Adjacentcurve originals are never inthismask.
  separation=float(np.min(abs(np.delete(centres,k)-centres[k])));rad=min(13.,max(2.,separation*.5-.8));ids=yy[(owner==k)&(dist[:,k]<=rad)]
  tube[ids,x]=True;bg[ids,x]=np.clip(np.round(background(x,ids)),0,255).astype(np.uint8)
 for k in range(len(splines)):
  if k in selected:continue
  ids=yy[(dist[:,k]<3.5)&(a[yy,x].mean(1)<220)];native_protected[ids,x]=True
assert not np.any(tube&native_protected)

from catfix import verify
orig=np.asarray(verify.crop(current,10,r,600));H,W=orig.shape[:2];xs=r[0]+(np.arange(W)+.5)*s;ys=r[3]-(np.arange(H)+.5)*s
ux=(xs-im.ctm[2,0])/im.ctm[0,0]*im.W;vy=(1-(ys-im.ctm[2,1])/im.ctm[1,1])*im.H;iu=np.clip(np.floor(ux).astype(int),0,a.shape[1]-1);iv=np.clip(np.floor(vy).astype(int),0,a.shape[0]-1)
mask=tube[iv[:,None],iu[None,:]];clean=orig.copy();clean[mask]=bg[iv[:,None],iu[None,:]][mask]
outcv=RenderCanvas(10,r,600,clean.copy(),im);curves=[];style=[]
for k in selected:
 row=t['rows'][k];model=row['curve_model'];source_points=[p for p in audit['points'] if p['family']=='10SP135' and p['row']==k+1];assert all(not p['identity_uncertain'] for p in source_points)
 assert any(p['verification_status']=='CHƯA ĐẠT' and p['Q_m3h']==180 for p in source_points)
 # Match sourceRGBcore in selected realnative rank, Q140..176 avoiding grid.
 samples=[]
 for xf in np.linspace(nx(px(140)),nx(px(176)),100):
  x=int(round(xf));pred=float(splines[k](x));centres=np.array([z(x) for z in splines]);sep=float(np.min(abs(np.delete(centres,k)-pred)))
  if min(abs(gridxs-x))<3 or min(abs(gridys-pred))<3:continue
  ids=np.arange(round(pred)-3,round(pred)+4);back=background(x,ids);profile=a[ids,x].astype(float);amp=np.maximum(0,back-profile).mean(1);peak=int(np.argmax(amp))
  if amp[peak]<45:continue
  half=amp>amp.max()*.5;width=float(half.sum()*.48/np.sqrt(1+splines[k].derivative()(x)**2));samples.append(dict(native_x=x,native_y=int(ids[peak]),rgb=profile[peak].astype(int).tolist(),fwhm_normal_pt=width))
 assert len(samples)>10
 color=np.round(np.percentile(np.array([z['rgb'] for z in samples]),35,axis=0)).astype(int).tolist();width=.48
 xjoin=float(cv.to_page(xlo,0)[0]);qjoin=qx(xjoin);yjoin=pagey(splines[k](xlo));djoin=-float(splines[k].derivative()(xlo));allx=np.array([px(q) for q in t['Q']]);ally=np.array([py(h) for h in row['H']]);target=PchipInterpolator(allx,ally)
 xe=px(180);ye=py(row['H'][-1]);bridge=CubicHermiteSpline([xjoin,xe],[yjoin,ye],[djoin,float(target.derivative()(xe))]);dx=xe-xjoin;segment=[[xjoin,yjoin],[xjoin+dx/3,yjoin+djoin*dx/3],[xe-dx/3,ye-float(target.derivative()(xe))*dx/3],[xe,ye]]
 pts=bezier(*map(np.array,segment),n=500).tolist();draw_polyline(outcv,pts,color=tuple(color),width_px=width*600/72,ss=4)
 curves.append(dict(model=model,rank=k+1,source_label=model,page=11,Q_join=qjoin,start_page=[xjoin,yjoin],end_page=[xe,ye],new_Q=[180],target_H=row['H'][-1],segments=[segment],color_rgb=color,width_pt=width,source_points=source_points,source_font_pixels_kept=True))
 style.append(dict(model=model,source_150dpi_width_samples=samples,source_RGB_percentile35=color,new_vector_width_pt=width,interpretation='Suy nét từ ảnh150dpi, khôngthểxácđịnh byte/thôngsốpen nguồn.'))
# Preserve every corepixel of the ten unmodified curves in the preview.
protect=native_protected[iv[:,None],iu[None,:]];outcv.work[protect]=orig[protect];assert np.array_equal(outcv.work[protect],orig[protect])
assert np.array_equal(outcv.work[:,:int((curves[0]['start_page'][0]-r[0])/s)-4],orig[:,:int((curves[0]['start_page'][0]-r[0])/s)-4])
Image.fromarray(orig).save(fresh(S.report(O+'TRUOC.png')));Image.fromarray(outcv.work).save(fresh(S.report(O+'SAU.png')));Image.fromarray(clean).save(fresh(S.report(O+'NEN.png')))
np.savez_compressed(fresh(S.report(O+'NEN VA MASK 600dpi.npz')),orig=orig,background=clean,preview=outcv.work,protected=protect)
labrect=(535,385,579,439);verify.crop(current,10,labrect,600).save(fresh(S.report(O+'NHAN5-7 GIU NGUYEN.png')))
Path(fresh(S.report(O+'TOA DO VA BANG NGUON.json'))).write_text(json.dumps(dict(current_path=current,current_sha256=before,source_sha256=hashlib.sha256(Path(S.src(name)).read_bytes()).hexdigest(),page=11,family='10SP135',rect=r,dpi=600,axis=b,curves=curves,style=style,method='Tách nét nguồn thuộc riêng2rank đãkhớpnhãn, giữlướivà10nétriêng; Bézier trơn nối nguồnQ162→Q180 thật66/93. Mặt nạ chỉpixelđổi. Mẫu1 chưaghiPDF.',native_image_ctm=im.ctm.tolist(),protected_other_curve_pixels=int(protect.sum()),actual_endpoint_Q=180,all_other_curve_protected_pixels_identical=True),ensure_ascii=False,indent=2),encoding='utf8')
assert hashlib.sha256(Path(current).read_bytes()).hexdigest()==before
E.close();print('SP135_SAMPLE1',[(c['model'],c['Q_join'],c['color_rgb'],c['width_pt'],c['target_H']) for c in curves],'protected',int(protect.sum()),'primary unchanged',flush=True)
