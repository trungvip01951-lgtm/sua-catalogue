from catwork import start,fresh
from pathlib import Path
import contextlib,io,json,re
S,D,N=start()
from catfix import verify
from catfix.vector import union
names=['Catalog cắt rác Aquaris WC (bản mới).pdf','Catalog cắt rác perotac (bản mới).pdf','Catalog cắt rác redpump (bản mới).pdf']
out=[]
for name in names:
    job=S.job(name)
    info={'name':name,'source':job.src,'output':job.dst,'pages':[]}
    buf=io.StringIO()
    for pi in range(job.E.n_pages):
        with contextlib.redirect_stdout(buf): job.TL.dump(pi)
        lines=job.TL.text_lines(pi)
        info['pages'].append([dict(text=t,bbox=union(g.bbox for g in ln)) for t,ln in lines])
    Path(fresh(S.report('G08/'+name+'.txt'))).write_text(buf.getvalue(),encoding='utf-8')
    print(name,'trang',job.E.n_pages)
    for pi in [0,1,2,4,7]:
        print('trang',pi+1)
        for l in info['pages'][pi]:
            if re.search('50WC15-25|50WC15-80|150WC200|Power|head|Speed|DN|80 WC|WARRANTY',l['text'],re.I): print(l)
    if 'Aquaris' in name:
        for pi in [0,2,4]:
            verify.crop(job.src,pi,job.E.mediabox(pi),130).save(fresh(S.report(f'G08/TRANG NGUON {pi+1}.png')))
    job.close()
    out.append(info)
Path(fresh(S.report('G08/NGUON.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
