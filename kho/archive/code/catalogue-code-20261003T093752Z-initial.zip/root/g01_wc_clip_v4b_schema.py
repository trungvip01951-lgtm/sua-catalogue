"""Read only the exact approved V4B source data and identify its schema."""
from catwork import start, HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,importlib.util
fp=HERE/'wc_clip_source_du_lieu_20261003'/'DU LIEU DUONG CAT NGUON V4B BIEN THAN DUNG'/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json'
sha=hashlib.sha256(fp.read_bytes()).hexdigest()
assert sha=='d2356789b101589037eb587a6e75af4ce899e0c5297e6f316969217c162cce7a'
d=json.loads(fp.read_text(encoding='utf8'))
def short(q):
    if isinstance(q,dict):return {'keys':list(q),'count':len(q)}
    if isinstance(q,list):return {'count':len(q),'first':short(q[0]) if q else None}
    return q
print('TOP',json.dumps({k:short(v) for k,v in d.items()},ensure_ascii=False,indent=2),flush=True)
for k,v in d.items():
    if isinstance(v,list) and v and isinstance(v[0],dict):
        print('LIST',k,flush=True)
        for g in v[:3]:print(json.dumps({kk:short(vv) for kk,vv in g.items()},ensure_ascii=False,indent=2),flush=True)
print('TOOLS',{v:bool(importlib.util.find_spec(v)) for v in ['shapely','cv2','PIL','numpy']},flush=True)
name='Catalog cắt rác perotac (bản mới).pdf'
for tag,p in [('SOURCE',S.src(name)),('CANONICAL',S.dst(name))]:print(tag,p,hashlib.sha256(Path(p).read_bytes()).hexdigest(),flush=True)
