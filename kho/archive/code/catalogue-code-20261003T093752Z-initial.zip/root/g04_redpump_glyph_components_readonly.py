"""Read genuine glyph ink components and source context; no catalogue writes."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'GLYPH HOAN CHINH HOP NGUON THU CONG.json').read_text(encoding='utf8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
src=d['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)]
assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cache={};out=[]
pic=Image.new('RGB',(1250,500),'white');dr=ImageDraw.Draw(pic)
for i,ch in enumerate(['5','3','6','9']):
 z=next(z for z in d['records'] if z['character']==ch);key=(z['source_page'],tuple(z['source_canvas_rect']))
 if key not in cache:cache[key]=R.render_canvas(z['source_page']-1,z['source_canvas_rect'],dpi=600)
 cv=cache[key];x0,y0,x1,y1=z['source_render_box'];whole=cv.orig.astype(float);g=whole@np.array([.299,.587,.114]);bg=np.median(g,axis=1);raw=whole[y0:y1,x0:x1]
 a=np.clip((bg[y0:y1,None]-g[y0:y1,x0:x1])/np.maximum(bg[y0:y1,None],1),0,1)
 comp,n=label(a>.085);rr=[]
 for k in range(1,n+1):
  yy,xx=np.nonzero(comp==k);rr.append(dict(component=k,area=len(xx),bbox=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],alpha_min=float(a[comp==k].min()),alpha_max=float(a[comp==k].max())))
 area_pic=np.zeros_like(raw,dtype='uint8')+255;colors=np.array([[220,30,30],[30,180,40],[30,70,220],[200,40,200],[240,130,20]])
 for k in range(1,n+1):area_pic[comp==k]=colors[(k-1)%len(colors)]
 dr.text((5,i*120+5),ch+' source '+z['source_word'],fill='blue');pic.paste(Image.fromarray(raw.round().astype('uint8')).resize(((x1-x0)*3,(y1-y0)*3),Image.Resampling.NEAREST),(160,i*120))
 pic.paste(Image.fromarray(area_pic).resize(((x1-x0)*3,(y1-y0)*3),Image.Resampling.NEAREST),(280,i*120));dr.text((430,i*120+12),str(rr),fill='black')
 out.append(dict(character=ch,source_page=z['source_page'],source_word=z['source_word'],source_page_box=z['source_page_box'],components=rr,unmixed_alpha=a.tolist()))
photo=fresh(root/'THANH PHAN MUC CHU THAT 5 3 6 9.png');pic.save(photo)
Path(fresh(root/'THANH PHAN MUC CHU THAT 5 3 6 9.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=out,photo=photo,catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print(json.dumps(out,ensure_ascii=False)[:6500],flush=True)
