"""Read-only conclusion/coordinate plan: keep #34 UNKNOWN without a real k."""
from catwork import start, fresh, HERE
S, D, N = start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from collections import Counter
from catfix.vector import Editor
from catfix.otext import OutlineText, procrustes
import hashlib, json, numpy as np, pikepdf, pymupdf as fitz, csv
O='G03/PHUC HOI CHU k DUNG NGUON 03-10-2026/'
ip=S.report(O+'01 KIEM KE NGUON FONT ALIAS UNICODE VA TAT CA NET VE.json')
sp=S.report(O+'02 CHUNG MINH STYLE HAI KY TU VA ANH DU164 CLUSTER112 NET VIEN.json')
iv=json.loads(Path(ip).read_text(encoding='utf8'));sh=json.loads(Path(sp).read_text(encoding='utf8'))
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert sha(iv['source'])==iv['source_sha256'] and sha(iv['canonical'])==iv['canonical_sha256']
assert len(iv['targets_KW_Kw'])==16 and not iv['all_lower_k_cluster_candidates']
assert len(sh['all_unknown_outline_clusters'])==164 and len(sh['all_extra_paint_candidates'])==112
assert all(not iv[k] for k in ['font_objects','font_streams','font_alias_dicts','unicode_maps','actual_nonimage_text_stream_operators'])

font_magic=[];formops=[];streamcount=0;errors=[];raw_image_streams=[]
with pikepdf.open(iv['source']) as pdf:
    pagecontents=set()
    for pg in pdf.pages:
        cc=pg.obj.get('/Contents')
        if isinstance(cc,pikepdf.Stream):pagecontents.add(cc.objgen)
        elif isinstance(cc,pikepdf.Array):pagecontents.update(o.objgen for o in cc)
    for i,obj in enumerate(pdf.objects):
        if not isinstance(obj,pikepdf.Stream):continue
        streamcount+=1
        try:
            bb=obj.read_bytes()
        except pikepdf.PdfError:
            assert str(obj.get('/Subtype',''))=='/Image', (i+1,obj.get('/Subtype'))
            bb=obj.read_raw_bytes()
            raw_image_streams.append(dict(xref=i+1,subtype='/Image',filter=str(obj.get('/Filter')),raw_bytes=len(bb),probe='Dữ liệu ảnh mã hóa; không phải chương trình phông theo tài nguyên PDF'))
        if bb[:4] in [b'OTTO',b'\x00\x01\x00\x00',b'true',b'ttcf',b'wOFF',b'wOF2'] or bb.startswith(b'%!PS-AdobeFont'):
            font_magic.append(dict(xref=i+1,header_hex=bb[:8].hex(),decoded_bytes=len(bb)))
        if obj.objgen in pagecontents or str(obj.get('/Subtype',''))=='/Form':
            try:
                ops=Counter(str(x.operator) for x in pikepdf.parse_content_stream(obj))
                formops.append(dict(xref=i+1,kind='PAGE CONTENT' if obj.objgen in pagecontents else 'FORM',total_operators=sum(ops.values()),text_operators={k:v for k,v in ops.items() if k in ['BT','ET','Tf','Tj','TJ',"'",'"','Tr']}))
            except Exception as ex:errors.append(dict(xref=i+1,error=str(ex)))
assert not font_magic and not errors and all(not x['text_operators'] for x in formops)

A=Editor(iv['source'],backend='fitz');B=Editor(iv['canonical'],backend='fitz');af=fitz.open(iv['source'])
T=OutlineText(A);T.learn(range(10),dpi=400,verbose=False)
records=[];images=[]
for i,m in enumerate(sh['targets'],1):
    pi=m['page']-1;P=A.page(pi);PB=B.page(pi);gg=[]
    for g in m['source_glyphs']:
        oi=g['object_index'];source_path=A.glyph_pagepath(pi,oi,{'subs':g['subs']})
        found=[]
        for jo,o in enumerate(PB.objs):
            if o['op'] not in ['f','F','f*','B','B*','b','b*']:continue
            for z in PB.merged_glyphs(jo):
                if np.max(abs(np.asarray(z['bbox'])-np.asarray(g['bbox'])))>.0001:continue
                path=B.glyph_pagepath(pi,jo,z)
                pts=np.array([v for op,pp in path for v in pp]);before=np.array([v for op,pp in source_path for v in pp])
                if [v[0] for v in path]!=[v[0] for v in source_path] or pts.shape!=before.shape:continue
                delta=float(np.max(abs(pts-before)))
                if delta<.0001 and P.color_of(oi,'fill')==PB.color_of(jo,'fill'):
                    found.append(dict(object_index=jo,subs=z['subs'],bbox=z['bbox'],max_source_path_delta_pt=delta))
        assert len(found)==1,(m['page'],m['old'],g,found)
        gg.append(dict(char=g['char'],source_object_index=oi,source_subpaths=g['subs'],source_bbox_bottom_left=g['bbox'],source_paint_op=P.objs[oi]['op'],source_fill_RGB=P.color_of(oi,'fill'),source_linewidth=P.objs[oi].get('lw'),source_CTM=P.objs[oi]['ctm'].tolist(),source_actual_path=source_path,canonical_actual_identical_glyph=found[0],outline_style_id=g['style'],font_program_name=None))
    box=m['bbox_bottom_left'];hh=float(af[pi].rect.height);clip=fitz.Rect(box[0]-3,hh-box[3]-3,box[2]+3,hh-box[1]+3)
    im=fresh(S.report(O+f'16 VI TRI THAT/{i:02d} P{pi+1} {m["old"]} NGUON600.png'));af[pi].get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=clip,alpha=False).save(im);images.append(im)
    compatibles=[]
    for c in m['all_same_shape_font_other_sizes']:
        pp=c['two_or_more_common_character_proofs']
        compatibles.append(dict(source_style=c['source_style'],physical_scale=c['scale'],common_character_count=c['shared_character_count'],at_least_two_independent_characters_confirmed=len(pp)>=2,actual_shared_character_proofs=pp,has_lower_k=c['has_lower_k'],source_chars=c['source_chars']))
    records.append(dict(location_id=i,page=pi+1,source_old=m['old'],proposed_final='kW',status='CHƯA THỂ — chưa có k thường cùng nét/phông trong chính PDF',source_and_canonical_bbox_bottom_left=box,actual_existing_glyphs=gg,source_target_glyph_style_ids=[g['style'] for g in m['source_glyphs']],same_font_family_other_size_search=compatibles,lower_k_source_page=None,lower_k_source_object=None,lower_k_source_font_name=None,current_no_edit_action='Giữ nguyên; không thu nhỏ K hoặc ghép phần chữ để suy ra k',source_crop600dpi=im,source_font_name_unrecoverable_from_resource_dictionary=True))

# Evidence for the existing family equivalences: these are not donors for k.
prototypes=[]
small=next(z for z in records if z['source_old']=='Kw')
for match in small['same_font_family_other_size_search']:
    if match['source_style']==small['source_target_glyph_style_ids'][0] or not match['at_least_two_independent_characters_confirmed']:continue
    prototypes.append(match)
source_total=sum(x['learnt_outline_glyph_count'] for x in iv['pages'])
out=dict(status='CHƯA THỂ #34 kW; không có phương án chép k hợp lệ từ nguồn đã kiểm',read_only=True,source=iv['source'],source_sha256=iv['source_sha256'],canonical=iv['canonical'],canonical_sha256=iv['canonical_sha256'],group_filename_from_tasks=iv['group'],task=34,scope='Chỉ tìm chữ k thường cùng kiểu cho KW/Kw; không sửa phần đã nghiệm thu',font_objects=0,font_program_streams=0,font_alias_dictionaries=0,unicode_maps=0,all_pdf_streams_magic_checked=streamcount,font_program_magic_matches=font_magic,raw_encoded_image_streams=raw_image_streams,all_page_content_and_forms_operator_proofs=formops,operator_parse_errors=errors,outline_glyphs_read=source_total,lower_k_candidates_any_learnt_style=0,uppercase_K_count=16,unknown_clusters164_visual_review_all_done=True,stroke_candidates112_visual_review_all_done=True,unknown_visual_summary='Số/nhãn xoay, ký hiệu/chữ hoa đầu trang và khối mũi tên; không k thường',stroke_visual_summary='Viền chữ hoa bìa/đầu trang, dấu inch và các đường chú giải; không k thường',source_all10_pages_opened=True,required_target_locations16=records,same_family_two_plus_common_characters_actual_proofs=prototypes,source_font_label_limit='Nguồn chỉ có đường nét, không có tên/phông nhúng; không gán Arial/Helvetica hay tên phông đoán',target_white_KW_style_limit='K và W bị bộ gom nét xếp thành hai kiểu chỉ có một ký tự mỗi kiểu; chưa đủ hai chữ chung để nhận tên/họ phông bằng riêng mã kiểu này',valid_recovery_plan=None,plan_if_real_source_k_later_confirmed='Chỉ dùng k nguyên vẹn của chính tệp và có ít nhất hai chữ chung chứng minh cùng kiểu, cùng tỷ lệ cỡ; chép đúng hình/màu/baseline vào 16 vùng đã khóa; giữ W nếu đã đúng, W hoa của Kw cũng phải chứng minh nguồn riêng; tạo một mẫu sau ROOT cho phép',old_G03_14_of15_status_held=True,old_task34_other24_components_held=True,old_69_curves_414_points_exact_current_hash_held=True,no_PDF_written=True,no_canonical_replaced=True,no_shared_progress_written=True,inventory_proof=ip,inventory_sha256=sha(ip),shape_proof=sp,shape_proof_sha256=sha(sp),source_images=images)
fp=fresh(S.report(O+'03 KET LUAN CHUA THE VA PHUONG AN 16 TOA DO GIU NGUYEN.json'));Path(fp).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
rows=[]
for z in records:
    rows.append(dict(location=z['location_id'],page=z['page'],old=z['source_old'],proposed='kW',bbox_bottom_left=json.dumps(z['source_and_canonical_bbox_bottom_left']),source_K_object=z['actual_existing_glyphs'][0]['source_object_index'],source_K_outline_style=z['source_target_glyph_style_ids'][0],source_colour_RGB=json.dumps(z['actual_existing_glyphs'][0]['source_fill_RGB']),lower_k_source='',status=z['status'],source_image=z['source_crop600dpi']))
cp=fresh(S.report(O+'16 VI TRI KW Kw VA TRANG THAI CHUA THE.csv'))
with open(cp,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
lines=['BÁO CÁO NGHIÊN CỨU G03 #34 — CHỮ k ĐÚNG NGUỒN','',
    'CHƯA THỂ sửa 16 chỗ KW/Kw thành kW theo quy tắc giữ phông nguồn. Đã kiểm lại chính PDF gốc, cả chương trình phông, tên tài nguyên, bảng mã Unicode, nét tô và nét viền. Không có nguồn k thường hợp lệ. Đây là kết quả nghiên cứu chỉ đọc; chưa tạo PDF mẫu, không sửa bản giao hoặc tiến độ chung. Các việc đã đạt và 69 đường/414 mốc giữ nguyên mã kiểm.', '',
    f'Tệp: {iv["source"]}', f'SHA256 nguồn: {iv["source_sha256"]}',
    f'Bản giao: {iv["canonical"]}', f'SHA256 bản giao giữ nguyên: {iv["canonical_sha256"]}', '',
    f'Kiểm kê: {source_total} hình chữ nét tô được đọc; 0 phông/0 chương trình phông/0 bảng tên thay thế phông/0 ánh xạ Unicode; {streamcount} luồng dữ liệu kiểm thêm dấu đầu chương trình phông, không tìm thấy. Các luồng trang và biểu mẫu không có toán tử chữ thật. Đã mở đủ 10 trang nguồn, 164 nhóm nét chưa nhận dạng và 112 hình từ lớp nét viền hoặc tô kèm viền.', '',
    'Nét viền gồm chữ hoa bìa/đầu trang, dấu inch và đường chú giải. Nhóm nét chưa nhận dạng gồm số, ký hiệu và nhãn xoay; không có k thường. 16 K hoa hiện hữu không được coi là k thường; không thu nhỏ K hoặc ghép nét từ ký tự khác để tạo k.', '',
    'Có ba nhóm chữ khác cỡ khớp nhóm của nhãn Kw bằng ít nhất ba ký tự chung; phép so hình thật lưu bên dưới, tất cả vẫn thiếu k. Riêng K và W trắng trong bảng được bộ gom nét chia thành hai kiểu chỉ có một chữ mỗi kiểu, nên không suy tên phông chỉ từ mã kiểu. Do PDF chỉ giữ đường vẽ, không có căn cứ đặt tên phông là Arial hoặc Helvetica.', '',
    '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
    '|---|---|---|---|---|---|---|---|']
for z in records:
    pos=', '.join(f'{v:.4f}' for v in z['source_and_canonical_bbox_bottom_left'])
    objs='/'.join(str(g['source_object_index']) for g in z['actual_existing_glyphs'])
    lines.append(f'| 34 / vị trí {z["location_id"]} | Aquaris SA | {z["page"]} | {z["source_old"]}, hộp [{pos}], nét nguồn {objs} | Cần kW; chưa sửa | Chỉ chép k nguyên vẹn cùng phông nếu có nguồn đã chứng minh; hiện chưa có | CHƯA THỂ | 16 VI TRI THAT/{z["location_id"]:02d} P{z["page"]} {z["source_old"]} NGUON600.png; JSON 03 |')
lines+=['','Tổng phạm vi nghiên cứu: 16 vị trí — ĐẠT sửa 0, CHƯA THỂ 16; không có PDF mẫu. Trạng thái nhóm G03 vẫn 14/15 việc đã đạt, phần còn lại của #34 chưa đạt. Không đánh lại 69 đường/414 mốc đã đạt, vì bản giao không thay đổi byte nào.','',
    '| Nhóm cùng hình chữ của Kw | Tỷ lệ đưa về cỡ nhãn | Số ký tự chung | Các ký tự kiểm trực tiếp | Có k thường |',
    '|---|---|---|---|---|']
for z in prototypes:
    chars=', '.join(v['char'] for v in z['actual_shared_character_proofs'])
    lines.append(f'| Mã nét {z["source_style"]} | {z["physical_scale"]:.12f} | {z["common_character_count"]} | {chars} | Không |')
lines+=['','Phương án trong quyền hiện tại: giữ 16 chỗ nguyên trạng, ghi CHƯA THỂ và giao hồ sơ nguồn để ROOT kiểm. Không có tọa độ/phông donor hợp lệ cho chữ k để thực hiện mẫu. Nếu tìm được chữ k thật của chính tệp sau này, phải chứng minh ít nhất hai ký tự chung và tỷ lệ cỡ thống nhất trước khi chép nét; không dùng phông hoặc file khác.', '',
    'Tọa độ dùng điểm in PDF, gốc dưới trái, 72 điểm trên một inch. kW là kilôoát. Unicode là bảng gán mã số cho ký tự; nguồn không có bảng đó để gọi thêm chữ chưa dùng. CSV là bảng có thể mở bằng Excel; JSON là hồ sơ số liệu có cấu trúc. SHA256 là mã kiểm nội dung tệp. 600 điểm ảnh/inch là độ phóng ảnh bằng dữ liệu PDF thật.', '',
    f'Hồ sơ kết luận/từng nét/màu/ma trận/tọa độ: {fp}',
    f'Bảng 16 vị trí: {cp}',
    f'Kiểm kê phông/chữ/lớp: {ip}',
    f'So hình hai chữ trở lên và ảnh nhóm chưa nhận dạng: {sp}',
    '', 'Cần anh quyết: không có yêu cầu duyệt mẫu đang chờ; chưa có nguồn hợp lệ để dựng mẫu trong quy tắc hiện tại. Phát hiện thêm: không sửa thêm phần máy bơm hoặc số liệu.', '']
rp=fresh(S.report(O+'BAO CAO 8 COT NGHIEN CUU CHU k - CHUA THE.md'));Path(rp).write_text('\n'.join(lines),encoding='utf8')
A.close();B.close();af.close();assert sha(iv['source'])==iv['source_sha256'] and sha(iv['canonical'])==iv['canonical_sha256']
print('READONLY CONCLUSION: CHUA THE 16 / 16; SOURCE/CANONICAL HELD; NO PDF OR SHARED PROGRESS WRITE',flush=True)
print('EVIDENCE',fp,'REPORT',rp,'CSV',cp,flush=True)
print('TWO CHAR FAMILY PROOFS',[(z['source_style'],z['physical_scale'],[q['char'] for q in z['actual_shared_character_proofs']]) for z in prototypes],flush=True)
