"""Investigate all shapes skipped by normal OCR, without writing any PDF."""
from catwork import start, fresh, HERE
S, D, N = start()
import sys
sys.path.insert(0, str(HERE))
from pathlib import Path
from collections import Counter
from catfix.vector import Editor
from catfix.otext import OutlineText, procrustes
from PIL import Image
import hashlib, json, numpy as np, pymupdf as fitz
O='G03/PHUC HOI CHU k DUNG NGUON 03-10-2026/'
ip=S.report(O+'01 KIEM KE NGUON FONT ALIAS UNICODE VA TAT CA NET VE.json')
iv=json.loads(Path(ip).read_text(encoding='utf8'));sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert sha(iv['source'])==iv['source_sha256'] and sha(iv['canonical'])==iv['canonical_sha256']
E=Editor(iv['source'],backend='fitz');T=OutlineText(E);T.learn(range(10),dpi=400,verbose=False)
doc=fitz.open(iv['source']);height=lambda pi:float(doc[pi].rect.height)
targets=[]
for rec in iv['targets_KW_Kw']:
    pi=rec['page']-1;m=T.find(pi,rec['old'],rect=rec['bbox_bottom_left'])[0]
    x=dict(rec,target_character='k',uppercase_K_is_not_lowercase_k=True)
    sid=m.glyphs[0].style
    x['source_style_characters']=''.join(sorted(T.styles[sid].get('src',{})))
    same=[]
    for sid2, st in T.styles.items():
        ss=T.style_scale(sid,sid2) if sid2!=sid else 1.
        if ss is None:continue
        common=sorted(set(T.styles[sid].get('src',{})).intersection(st.get('src',{})))
        proofs=[]
        for c in common:
            aa=T.clusters[T.styles[sid]['src'][c]];bb=T.clusters[st['src'][c]]
            a=aa['members'][0];b=bb['members'][0]
            if aa['ops']!=bb['ops'] or aa['pts'].shape!=bb['pts'].shape:continue
            sc,rot,shift,res=procrustes(bb['pts'],aa['pts'],allow_rotation=False)
            proofs.append(dict(char=c,normalized_shape_scale=sc,max_shape_residual=res,target_source=dict(page=a.key+1,object_index=a.oi,subs=a.g['subs'],bbox=a.bbox,cluster=a.cl),donor_style_source=dict(page=b.key+1,object_index=b.oi,subs=b.g['subs'],bbox=b.bbox,cluster=b.cl)))
        same.append(dict(source_style=sid2,scale=ss,shared_character_count=len(common),two_or_more_common_character_proofs=proofs[:4],source_chars=''.join(sorted(st.get('src',{}))),has_lower_k='k' in st.get('src',{})))
    x['all_same_shape_font_other_sizes']=same
    targets.append(x)

unknown=[]
for ci, cl in enumerate(T.clusters):
    if cl['label']!='?':continue
    members=cl['members'];gl=members[0];bb=gl.bbox
    unknown.append(dict(cluster=ci,member_count=len(members),page=gl.key+1,object_index=gl.oi,subs=gl.g['subs'],bbox=bb,style=gl.style,ops=list(cl['ops']),representative_path=E.glyph_pagepath(gl.key,gl.oi,gl.g),all_member_boxes=[dict(page=g.key+1,object_index=g.oi,bbox=g.bbox) for g in members]))
extra=iv['all_merged_stroke_or_fill_stroke_letter_size_candidates']

def crop_record(rec,margin=1.3):
    bb=rec['bbox'];pi=rec['page']-1
    box=fitz.Rect(bb[0]-margin,height(pi)-bb[3]-margin,bb[2]+margin,height(pi)-bb[1]+margin)&doc[pi].rect
    pix=doc[pi].get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=box,alpha=False)
    return Image.frombytes('RGB',[pix.width,pix.height],pix.samples)

def contacts(label,recs,start=0,batch=48):
    out=[]
    for i in range(start,len(recs),batch):
        group=recs[i:i+batch];columns=6;cw,ch=205,125;rows=(len(group)+columns-1)//columns
        sheet=Image.new('RGB',(columns*cw,rows*ch),(230,230,230));manifest=[]
        for j,rec in enumerate(group):
            im=crop_record(rec);im.thumbnail((cw-12,ch-12));x=(j%columns)*cw+(cw-im.width)//2;y=(j//columns)*ch+(ch-im.height)//2;sheet.paste(im,(x,y))
            manifest.append(dict(index=i+j+1,row=j//columns+1,column=j%columns+1,source_record=rec))
        fp=fresh(S.report(O+f'ANH NET CHUA NHAN/{label} {i+1}-{i+len(group)} NGUON600.png'));sheet.save(fp)
        mf=fresh(S.report(O+f'ANH NET CHUA NHAN/{label} {i+1}-{i+len(group)} TOA DO.json'));Path(mf).write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
        out.append(dict(image=fp,index_map=mf,first=i+1,last=i+len(group),columns=columns,source_native_PDF_pixels_only=True,no_font_rendered=True))
    return out

contacts_unknown=contacts('CLUSTER CHUA BIET',unknown)
contacts_stroke=contacts('NET VIEN',extra)
examples=[]
for pi in [2,3,4,5,6,7,8,9]:
    lines=iv['pages'][pi]['outline_lines']
    for kind,bb in [('MO TA TIEU DE',[48,640,560,726]),('KW BANG',[255,572,291,591]),('Kw NHAN MAY',[524,685,539,699])]:
        box=fitz.Rect(bb[0],height(pi)-bb[3],bb[2],height(pi)-bb[1])&doc[pi].rect
        fn=fresh(S.report(O+f'ANH NGUON/P{pi+1} {kind} NGUON600.png'));doc[pi].get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=box,alpha=False).save(fn);examples.append(dict(page=pi+1,kind=kind,bbox_bottom_left=bb,image=fn))

out=dict(read_only=True,source=iv['source'],source_sha256=iv['source_sha256'],canonical=iv['canonical'],canonical_sha256=iv['canonical_sha256'],font_inventory=ip,font_inventory_sha256=sha(ip),targets=targets,all_unknown_outline_clusters=unknown,all_unknown_cluster_images=contacts_unknown,all_extra_paint_candidates=extra,all_extra_paint_images=contacts_stroke,source_crop_images=examples,target_styles=sorted({v['source_glyphs'][0]['style'] for v in targets},key=str),no_native_lower_k_label_any_style=True,unknown_requires_actual_visual_review=True,no_PDF_written=True,no_shared_progress_written=True)
fp=fresh(S.report(O+'02 CHUNG MINH STYLE HAI KY TU VA ANH DU164 CLUSTER112 NET VIEN.json'));Path(fp).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda q:q.tolist() if isinstance(q,np.ndarray) else float(q)),encoding='utf8')
for v in targets:
    print('TARGET',v['page'],v['old'],'STYLE',v['source_glyphs'][0]['style'],'SIZE',v['bbox_bottom_left'],'MATCHEDSTYLES',[(z['source_style'],z['scale'],z['shared_character_count'],z['has_lower_k']) for z in v['all_same_shape_font_other_sizes']],flush=True)
print('UNKNOWN',len(unknown),'STROKE',len(extra),'IMAGE GROUPS',len(contacts_unknown),len(contacts_stroke),'EVIDENCE',fp,flush=True)
E.close();doc.close();assert sha(iv['source'])==iv['source_sha256'] and sha(iv['canonical'])==iv['canonical_sha256']
