from catwork import start,fresh
from pathlib import Path
import json,hashlib,numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify,ocr
from PIL import Image
name='Redpump gieng SL_compressed (bản mới).pdf';source=S.src(name);current=S.result(name)
E=Editor(source,backend='fitz');R=Raster(E);base=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(base);a=cv.orig.astype(int);g=a@np.array([.299,.587,.114]);root=Path(S.report('G04/REDPUMP DOC NGUON RIENG'))
u0,v0,u1,v1=cv.box((57,314,361,518));dark=(a.max(2)-a.min(2)<14)&(g<170)
rr=np.arange(v0,v1);count=dark[rr,u0+12:u1-12].sum(1);sel=rr[count>(u1-u0-24)*.7];groups=[]
for v in sel:
 if not groups or v-groups[-1][-1]>2:groups.append([])
 groups[-1].append(int(v))
lines=[dict(v=float(np.median(vs)),pageY=float(cv.to_page(0,np.median(vs))[1]),span=vs,coverage=[float(count[v-v0]/(u1-u0-24)) for v in vs]) for vs in groups]
print('OWN REDPUMP horizontal frames',lines,flush=True)
for label,rect,dpi in [('TRANG8',(0,0,842,599),150),('BANG QH',(27,39,380,198),600),('TRUC VA NHAN',(36,301,373,526),500),('LUU LUONG',(49,255,361,305),600)]:
 path=root/(label+'.png')
 if not path.exists():verify.crop(source,7,rect,dpi).save(fresh(path))
tab=cv.box((27,39,380,198));piece=Image.fromarray(cv.orig[tab[1]:tab[3],tab[0]:tab[2]]);words=ocr.image_words(piece.resize((piece.width*4,piece.height*4)),psm=6)
axisbox=cv.box((49,250,370,278));axisimage=Image.fromarray(cv.orig[axisbox[1]:axisbox[3],axisbox[0]:axisbox[2]]);axiswords=ocr.image_words(axisimage.resize((axisimage.width*6,axisimage.height*6)),psm=6)
for w in axiswords:
 bx=w['box'];u=axisbox[0]+(bx[0]+bx[2])/12;v=axisbox[1]+(bx[1]+bx[3])/12;w['center_page']=list(cv.to_page(u,v))
print('OWN REDPUMP flow ticks',[(w['text'],w['center_page']) for w in axiswords],flush=True)
# Whole surviving vertical grey rules within H20..115, independently from numbers.
vv0=int(round(179.5+(567-179.5)*(150-115)/150));vv1=int(round(179.5+(567-179.5)*(150-20)/150));xrange=np.arange(u0,u1)
neutral=(a.max(2)-a.min(2)<14)&(g<250);xc=neutral[vv0:vv1,xrange].mean(0);chosen=xrange[xc>.60];xgroups=[]
for u in chosen:
 if not xgroups or u-xgroups[-1][-1]>2:xgroups.append([])
 xgroups[-1].append(int(u))
xlines=[dict(u=float(np.median(us)),pageX=float(cv.to_page(np.median(us),0)[0]),span=us,coverage=float(np.max(xc[np.array(us)-u0]))) for us in xgroups]
print('OWN REDPUMP vertical rule candidates',xlines,flush=True)
rec=dict(name=name,source=source,current=current,source_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),source_image_name=base.name,source_image_shape=[base.W,base.H],source_image_ctm=base.ctm.tolist(),source_image_bbox=list(base.page_bbox),horizontal_frames=lines,table_words=words,flow_tick_words=axiswords,vertical_rules=xlines,source_scope='Redpump source only; no axes/glyph/image copied from Perotac; source curve identification not yet accepted')
Path(fresh(root/'DINH VI.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf8');E.close()
