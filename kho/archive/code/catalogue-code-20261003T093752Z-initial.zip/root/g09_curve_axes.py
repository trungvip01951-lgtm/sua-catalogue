from catwork import start,fresh
from pathlib import Path
import json,sys
S,D,N=start()
from catfix.vector import Editor
from catfix import charts,verify
fi=int(sys.argv[1]) if len(sys.argv)>1 else 0
d=json.loads(Path(S.report('G09/NGUON.json')).read_text(encoding='utf8'))[fi]
curves=json.loads(Path(S.report(f'G09/DO DUONG/LAN3/{d["short"]}/CAC DUONG.json')).read_text(encoding='utf8'))
E=Editor(S.dst(d['name']));out=[]
for c in curves:
    pi=c['page']-1;r=c['rect'];P=E.page(pi);gx,gy=charts.gridlines(P,(r[0]-2,r[1]-3,r[2]+2,r[3]+5))
    print(c['label'],'gx',gx,'gy',gy,flush=True)
    allred=[]
    for oi,o in enumerate(P.objs):
        bb=o['bbox']
        if not (r[0]<=(bb[0]+bb[2])/2<=r[2] and r[1]<=(bb[1]+bb[3])/2<=r[3]):continue
        for kind in ['stroke','fill']:
            col=P.color_of(oi,kind)
            if col and col[0]>.75 and col[1]<.4 and col[2]<.4:
                if o['op']!='S':allred.append(dict(oi=oi,op=o['op'],kind=kind,bbox=bb,path=P.object_pagepath(oi)))
    out.append(dict(label=c['label'],gx=gx,gy=gy,extra_red=allred))
    if allred:print('EXTRA COUNT',len(allred),flush=True)
for pi,rect in [(2,(58,45,559,312)),(3,(44,45,544,314)),(6,(59,43,555,297))]:
    path=S.report(f'G09/DO DUONG/BANG {d["short"]} {pi+1}.png')
    if not Path(path).exists():verify.crop(S.dst(d['name']),pi,rect,300).save(fresh(path))
Path(fresh(S.report(f'G09/DO DUONG/TRUC LAN2 {d["short"]}.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8');E.close()
