"""Đo biên bảo toàn lượng mực từng ứng viên nguồn, không ghép chữ/PDF."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from pathlib import Path
from PIL import Image
from scipy import ndimage
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/DO BIEN GIU LUONG MUC NGUON'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cache={};bg=np.array([255.,255.,255.]);ink=np.array([57.,55.,57.]);zoom=64
cases=[('SLASH25',7,[314,204,318,213]),('SLASH20',7,[314,275,318,284]),('SLASH18',7,[314,304,318,313]),
       ('3_4SA8-37',5,[1191,295,1196,304]),('3_4SA8-33_LAST',5,[1196,325,1202,334]),('3_4SA10-30',6,[318,270,324,279]),('3_4SA3-30_PREFIX',4,[288,386,295,395]),
       ('8_4SA8-37_PREFIX',5,[1182,295,1188,304]),('8_4SA8-33_PREFIX',5,[1182,325,1188,334]),('8_4SA16-18',7,[323,304,329,313]),
       ('0_4SA10-30_LAST',6,[324,270,330,279]),('0_4SA16-20',7,[323,275,329,284]),
       ('9_4SA16-9',7,[318,433,323,442]),('1_4SA16-25',7,[304,204,308,213]),('1_4SA16-20',7,[304,275,308,284]),
       ('S_4SA16-25',7,[289,204,296,213]),('A_4SA16-25',7,[296,204,304,213]),('4_4SA16-25',7,[282,204,289,213]),
       ('6_4SA16-25',7,[308,204,314,213]),('2_4SA16-25',7,[318,204,323,213]),('5_4SA16-25',7,[323,204,329,213]),
       ('S_4SA8-37_BRIDGE',5,[1167,295,1174,304]),('A_4SA8-37_BRIDGE',5,[1174,295,1182,304]),('4_4SA8-37_BRIDGE',5,[1160,295,1167,304]),
       ('S_4SA8-33_BRIDGE',5,[1167,325,1174,334]),('A_4SA8-33_BRIDGE',5,[1174,325,1182,334]),('4_4SA8-33_BRIDGE',5,[1160,325,1167,334])]
out=[];mont=[]
for key,pi,b in cases:
    if pi not in cache:
        im=max(R.images(pi),key=lambda z:z.W*z.H);cache[pi]=(im,R.canvas(im))
    im,cv=cache[pi];x0,y0,x1,y1=b;raw=cv.orig[y0:y1,x0:x1];al=R.alpha_of(raw,bg,ink)
    up=cv2.resize(np.pad(al,1),(al.shape[1]*zoom+2*zoom,al.shape[0]*zoom+2*zoom),interpolation=cv2.INTER_LINEAR)
    lo=.05;hi=.9;integral=float(al.sum())
    for z in range(32):
        mid=(lo+hi)/2;area=float((up>=mid).sum()/zoom**2)
        if area>integral:lo=mid
        else:hi=mid
    thr=(lo+hi)/2;m=up>=thr;lab,num=ndimage.label(m,np.ones((3,3)));inv,nh=ndimage.label(~np.pad(m,1,constant_values=False),np.ones((3,3)))
    exterior=set(np.r_[inv[0],inv[-1],inv[:,0],inv[:,-1]]);holes=[k for k in range(1,nh+1) if k not in exterior]
    ys,xs=np.where(m);bbox=[float(xs.min()/zoom-1),float(ys.min()/zoom-1),float((xs.max()+1)/zoom-1),float((ys.max()+1)/zoom-1)]
    ptx=float(np.linalg.norm(im.ctm[:2,0])/im.W);pty=float(np.linalg.norm(im.ctm[:2,1])/im.H)
    item=dict(key=key,source_page=pi+1,source_image='X'+str(pi),source_native_box=b,raw_pixel_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),alpha=al.tolist(),
              alpha_is_source_projected_on_original_ink=True,alpha_integral_native_px=integral,iso_mass_match_threshold=thr,iso_mass_match_area_native_px=float(m.sum()/zoom**2),
              ink_area_difference_percent=float((m.sum()/zoom**2/integral-1)*100),components=int(num),holes=len(holes),
              source_iso_native_bbox=bbox,source_iso_width_pt=float((bbox[2]-bbox[0])*ptx),source_iso_height_pt=float((bbox[3]-bbox[1])*pty),
              source_iso_top_native_y=y0+bbox[1],source_iso_bottom_native_y=y0+bbox[3],source_native_px_step_pt=[ptx,pty],
              standalone_glyph_no_font_acceptance=True,PDF_written=False)
    out.append(item)
    Image.fromarray(raw).save(fresh(root/(key+' NGUON150dpi.png')))
    srcbig=Image.fromarray(raw).resize((raw.shape[1]*24,raw.shape[0]*24),Image.Resampling.NEAREST);rgb=np.full((*m.shape,3),255,np.uint8);rgb[m]=[57,55,57]
    render=Image.fromarray(rgb).resize((rgb.shape[1]*24//zoom,rgb.shape[0]*24//zoom),Image.Resampling.LANCZOS)
    tile=Image.new('RGB',(480,300),'white');tile.paste(srcbig,(20,20));tile.paste(render,(240,-4));mont.append(tile)
    tile.save(fresh(root/(key+' NGUON VA BIEN GIU MUC.png')))
    print(key,'T',round(thr,4),'CC/HOLES',num,len(holes),'W/H',round(item['source_iso_width_pt'],4),round(item['source_iso_height_pt'],4),flush=True)
grid=Image.new('RGB',(480*3,300*9),'white')
for i,t in enumerate(mont):grid.paste(t,((i%3)*480,(i//3)*300))
grid.save(fresh(root/'27 UNG VIEN NGUON VA BIEN GIU LUONG MUC.png'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),
    source_original_only=True,source_pixel_matrix_unchanged=True,new_FontProgram_or_PDF_written=False,common_progress_written=False,
    method='Ứng viên biên đẳng mực nội suy bilinear; ngưỡng riêng khớp diện tích alpha nguồn, không vẽ bù nét. Lượng mựckhớp không chứng minh topology/hình/cùngphông; phải kiểm tất cả.',
    source_resolution_uncertainty_native_px=.5,candidates=out),ensure_ascii=False,indent=2),encoding='utf8');E.close()
