"""GhiPDFmẫu2endpointSP135 bằngcatfix; giữnguyên bảngiao đãnghiệmthu."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.recipes import Job
from catfix.raster import RenderCanvas
from catfix.cs import Instr,Num,Ref
from g15_masked_patch import commit_masked
from catfix import verify
from pathlib import Path
import numpy as np,json,hashlib,pymupdf as fitz

name='Perotac bơm giếng SP_compressed (bản mới).pdf';current=S.dst(name)
O='G05/10SP135 HAI MOC CUOI/'+('MAU 2/' if '--mau2' in sys.argv else 'MAU 1/')
rec=json.loads(Path(S.report(O+'TOA DO VA BANG NGUON.json')).read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)==rec['current_sha256']
trial=fresh(S.report(O+name));j=Job(current,trial,backend='fitz',log_path=fresh(S.report(O+'NHAT KY PDF MAU.json')))
im=j.R.image_at(10,rec['rect']);arrays=np.load(S.report(O+'NEN VA MASK 600dpi.npz'));orig=arrays['orig'];background=arrays['background']
cv=RenderCanvas(10,rec['rect'],rec['dpi'],orig.copy(),im);cv.work=background.copy();j.R.canvases[('render',10,tuple(rec['rect']))]=cv
X=np.linalg.inv(im.ctm);inv=[Num(X[0,0]),Num(X[0,1]),Num(X[1,0]),Num(X[1,1]),Num(X[2,0]),Num(X[2,1])]
ins=[Instr([],'q'),Instr(inv,'cm'),Instr([Num(0)],'J'),Instr([Num(1)],'j'),Instr([[],Num(0)],'d')]
for c in rec['curves']:
 ins.append(Instr([Num(v/255) for v in c['color_rgb']],'RG'));ins.append(Instr([Num(c['width_pt'])],'w'))
 seg=c['segments'][0];ins.append(Instr([Num(seg[0][0]),Num(seg[0][1])],'m'));ins.append(Instr([Num(v) for pt in seg[1:] for v in pt],'c'));ins.append(Instr([],'S'))
 # Bounds include sourceJPEGfringe tube; source actualcenter recorded separately.
 pts=np.array(seg);allowed=(c['start_page'][0]-.5,float(pts[:,1].min()-4),c['end_page'][0]+5,float(pts[:,1].max()+4))
 j._add(10,allowed,c['model']+' chỉ sửađuôiQ162→180, sốcuối'+str(c['target_H']),'raster-source-background+vector')
ins.append(Instr([],'Q'));j.E.insert_instrs(im.key,im.index,ins,before=False)
patches=commit_masked(j);j.R.canvases.clear();j._canvases.clear()
d=fitz.open(S.src(name));xr=d.xref_xml_metadata();raw=d.xref_stream(xr) if xr else None;d.close()
if raw is not None:
 xr=j.E.doc.doc.xref_xml_metadata();assert xr;j.E.doc.set_stream(Ref(xr,0),raw)
j.save();ck=j.check(raster=False);assert ck['ok'],ck
allowed={11:[e['rect'] for e in j.edits]}
outside=verify.outside_pixels(current,trial,allowed,dpi=200,thr=0,min_size=0,pad=.4);assert not outside,outside
verify.crop(trial,10,rec['rect'],600).save(fresh(S.report(O+'PDF MAU DOC LAI.png')))
verify.crop(trial,10,(715,341,763,386),600).save(fresh(S.report(O+'PDF MAU - HAI DUOI.png')))
verify.page_overview(current,trial,10,fresh(S.report(O+'SO SANH TRANG11.png')),dpi=120)
assert sha(current)==rec['current_sha256'] and sha(S.src(name))==rec['source_sha256']
Path(fresh(S.report(O+'GHI PDF VA NGOAI VUNG.json'))).write_text(json.dumps(dict(current=current,current_sha256=sha(current),source_sha256=sha(S.src(name)),trial=trial,trial_sha256=sha(trial),check=ck,outside200=outside,edits=j.edits,patches=patches,source_has_xmp=raw is not None,raw_xmp_restored=raw is not None),ensure_ascii=False,indent=2),encoding='utf8')
j.close();print('SP135PDF',trial,'outside',outside,'primary unchanged',flush=True)
