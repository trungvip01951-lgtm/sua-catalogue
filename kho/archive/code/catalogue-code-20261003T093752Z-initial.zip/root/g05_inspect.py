from catwork import start, fresh
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
S,D,N=start()
from catfix import verify
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
j=S.job(name)
out=[];ims=[]
for p in range(j.E.n_pages):
    cv=j.canvas(p)
    words=j.R.ocr(cv)
    out.append(dict(page=p+1,mediabox=j.E.mediabox(p),images=[str(im) for im in j.R.images(p)],
          words=[dict(text=w['text'],rect=cv.rect(w['box']),box=w['box']) for w in words]))
    im=verify.crop(j.src,p,j.E.mediabox(p),100)
    im.save(fresh(S.report(f'G05/NGUON/Trang {p+1}.png')))
    im.thumbnail((800,580));ims.append(im)
    print('Trang',p+1,'khổ',j.E.mediabox(p),'chữ',len(words),flush=True)
sheet=Image.new('RGB',(1600,620*6),'white');dr=ImageDraw.Draw(sheet)
for p,im in enumerate(ims):
    x=(p%2)*800;y=(p//2)*620
    dr.text((x+5,y+5),'Trang '+str(p+1),fill='black')
    sheet.paste(im,(x,y+25))
sheet.save(fresh(S.report('G05/NGUON 12 TRANG.png')))
Path(fresh(S.report('G05/NGUON.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
j.close()
