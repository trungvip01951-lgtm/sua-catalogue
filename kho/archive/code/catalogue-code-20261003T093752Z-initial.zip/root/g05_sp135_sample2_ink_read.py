"""Đọc lượngmực của nétPDFmẫu2 đãrender thật; so riêngsource vùngđuôi sạch.
Khôngsửagì; báo độrộngtươngđương/ratio thực, khôngchoquangưỡng tựđặt.
"""
from catwork import start,fresh,HERE
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify,charts
from pathlib import Path
import numpy as np,json

O='G05/10SP135 HAI MOC CUOI/MAU 2/'
d=json.loads(Path(S.report(O+'TOA DO VA BANG NGUON.json')).read_text(encoding='utf8'));p=json.loads(Path(S.report(O+'GHI PDF VA NGOAI VUNG.json')).read_text(encoding='utf8'));E=Editor(p['trial']);P=E.page(10)
sourceE=Editor(d['current_path']);R=Raster(sourceE);b=d['axis'];im=R.image_at(10,(b['x0'],b['y0'],b['x1'],b['y1']));cv=R.canvas(im);r=d['rect'];s=72/600;after=np.asarray(verify.crop(p['trial'],10,r,600)).astype(float);xt=np.array(b['xticks']);yt=np.array(b['yticks']);gridx=xt[:,1];gridy=yt[:,1];out=[]
for c in d['curves']:
 src=next(z for z in d['style'] if z['model']==c['model']);bg=np.array(src['background_RGB']);col=np.array(src['color_RGB']);vec=bg-col;norm=float(np.sum(vec*vec));path=None
 for oi,o in enumerate(P.objs):
  rgb=P.color_of(oi,'stroke')
  if o['op']=='S' and rgb is not None and max(abs(np.array(rgb)-col/255))<1e-8:path=P.object_pagepath(oi);width=o['lw'];break
 assert path is not None
 arr=charts.sample_path(path,n=1200);derivs=np.gradient(arr[:,1],arr[:,0]);samples=[]
 for z in src['samples']:
  xp=cv.to_page(z['native_x']+.5,0)[0];q=float(np.interp(xp,xt[:,1],xt[:,0]))
  if not 164<=q<=178:continue
  y=float(np.interp(xp,arr[:,0],arr[:,1]));slope=float(np.interp(xp,arr[:,0],derivs))
  if min(abs(gridx-xp))<2.0 or min(abs(gridy-y))<2.6:continue
  x=int(round((xp-r[0])/s));yp=int(round((r[3]-y)/s));ids=np.arange(yp-20,yp+21);rgb=after[ids,x];alpha=np.clip(np.maximum(0,bg-rgb)@vec/norm,0,1);w=float(alpha.sum()*s/np.sqrt(1+slope*slope))
  samples.append(dict(Q=q,source_native_x=z['native_x'],source_opacity_width_pt=z['source_equivalent_ink_width_pt'],new_actual_render_opacity_width_pt=w,new_actual_render_fwhm_pt=float((alpha>=.5).sum()*s/np.sqrt(1+slope*slope)),new_actual_slope=slope,new_peak_RGB=rgb[np.argmax(alpha)].tolist()))
 assert len(samples)>=10,(c['model'],len(samples))
 srcw=np.array([z['source_opacity_width_pt'] for z in samples]);neww=np.array([z['new_actual_render_opacity_width_pt'] for z in samples])
 out.append(dict(model=c['model'],new_actual_pdf_width_pt=width,new_RGB=col.tolist(),sample_count=len(samples),same_Q_window=[min(z['Q'] for z in samples),max(z['Q'] for z in samples)],source_equivalent_width_median_pt=float(np.median(srcw)),new_render_equivalent_width_median_pt=float(np.median(neww)),median_area_ratio_new_over_source=float(np.median(neww)/np.median(srcw)),mean_area_ratio_new_over_source=float(np.mean(neww)/np.mean(srcw)),source_width_percentile10_90=np.percentile(srcw,[10,90]).tolist(),new_width_percentile10_90=np.percentile(neww,[10,90]).tolist(),samples=samples,notes='Ảnhnguồn150dpi/JPEG phânphốibềdàytheovịtrílưới. Chỉbáosốthật, khôngcoi ngưỡng±1px làđạtkiểunét.'))
Path(fresh(S.report(O+'DO MUC TRONG PDF MAU THAT.json'))).write_text(json.dumps(dict(trial=p['trial'],source_dpi=150,new_read_dpi=600,curves=out),ensure_ascii=False,indent=2),encoding='utf8')
E.close();sourceE.close();print('ACTUAL_INK',[(z['model'],z['new_actual_pdf_width_pt'],z['source_equivalent_width_median_pt'],z['new_render_equivalent_width_median_pt'],z['median_area_ratio_new_over_source'],z['mean_area_ratio_new_over_source'],z['sample_count']) for z in out],flush=True)
