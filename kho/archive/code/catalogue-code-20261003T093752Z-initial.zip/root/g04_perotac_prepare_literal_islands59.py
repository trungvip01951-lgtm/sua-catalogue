"""Prepare a fresh pure builder with source-literal clipping islands.

Does not change the historical builder or call any PDF writer. The local
ellipse research is explicitly rejected as a recovered original font.
"""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
from g04_perotac_whole_pdf_tools46 import sha
here=Path(__file__).resolve().parent
old=here/'g04_perotac_whole_clip_builder47.py';code=old.read_text(encoding='utf8')
changes=[]
def replace_once(before,after):
    global code
    assert code.count(before)==1,(before,code.count(before))
    code=code.replace(before,after);changes.append(dict(old_SHA256=hashlib.sha256(before.encode()).hexdigest(),new_SHA256=hashlib.sha256(after.encode()).hexdigest()))
replace_once('RAM_REL=\'G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAM TRANG08 DONG BO LONG4 DUNG V3/RAM13 QH104 O VA ETA CHUA NGHIEM THU.json\'\n',
'''RAM_REL='G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAM TRANG08 DONG BO LONG4 DUNG V3/RAM13 QH104 O VA ETA CHUA NGHIEM THU.json'
KEEP_SOURCE_LITERAL_KEYS=['TITLE','Q US 10','Q US 30','H FEET 200','Q LMIN 150','Q LMIN 250','Q LMIN 350','M3 UNIT','ETA UNIT']
''')
replace_once('    island=list(cv.rect(title[\'source_native_box\']))\n',
'''    island=list(cv.rect(title['source_native_box']))
    source_islands=[]
    for key in KEEP_SOURCE_LITERAL_KEYS:
        literal=next(word for word in axisdoc['words'] if word['key']==key)
        source_islands.append(dict(key=key,literal_source_read=literal['literal_source_read'],
            source_native_box=literal['source_native_box'],source_page_box=list(cv.rect(literal['source_native_box'])),
            source_cropped_RGB_SHA256=hashlib.sha256(cv.orig[literal['source_native_box'][1]:literal['source_native_box'][3],literal['source_native_box'][0]:literal['source_native_box'][2]].tobytes()).hexdigest(),
            original_X7_bytes_CTM_native_size_spacing_kept=True,font_program_and_exact_original_vector_outline_UNKNOWN=True))
''')
replace_once('        if keep:newclip+=polygon(transform(corners(island),inverse))\n',
'''        if keep:
            for literal_island in source_islands:
                newclip+=polygon(transform(corners(literal_island['source_page_box']),inverse))
''')
replace_once("    group=[ins('q'),ins('gs',Name(state_name))]+polygon(corners(roi))+polygon(corners(island))+[ins('W*'),ins('n')]\n",
'''    group=[ins('q'),ins('gs',Name(state_name))]+polygon(corners(roi))
    for literal_island in source_islands:group+=polygon(corners(literal_island['source_page_box']))
    group+=[ins('W*'),ins('n')]
''')
replace_once("        if axis['key']=='TITLE':continue\n","        if axis['key'] in KEEP_SOURCE_LITERAL_KEYS:continue\n")
replace_once("        source_title_X7_CTMs_and_bytes_unchanged=True,source_X7_raw_sha256=hashlib.sha256(ed.doc.stream_raw(im.ref)).hexdigest(),\n",
'''        source_literal_islands_all=source_islands,source_literal_island_count=len(source_islands),
        source_literal_keys_not_reconstructed=KEEP_SOURCE_LITERAL_KEYS,
        rejected_research_ring_contours_not_used=True,original_axis_word_bank_unchanged=True,
        no_original_font_program_claim_from_four_ring_cubics=True,
        source_title_X7_CTMs_and_bytes_unchanged=True,source_X7_raw_sha256=hashlib.sha256(ed.doc.stream_raw(im.ref)).hexdigest(),
''')
new=here/'g04_perotac_whole_source_island_builder60.py'
Path(fresh(new)).write_text(code,encoding='utf8')
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
manifest=dict(stage='PREPARATION ONLY; PDF WRITER NOT RUN',historical_builder_path=str(old),historical_builder_SHA256=sha(old),
    prepared_builder_path=str(new),prepared_builder_SHA256=sha(new),unique_replacements=changes,
    method='Geometric even-odd complementary clip; no white/color cover or new image/SMask',
    source_sha256=sha(S.src(name)),canonical_sha256=sha(S.result(name)),
    source_literal_island_keys=['TITLE','Q US 10','Q US 30','H FEET 200','Q LMIN 150','Q LMIN 250','Q LMIN 350','M3 UNIT','ETA UNIT'],
    local_research_4_cubic_rings_status='CHƯA ĐẠT; not an original font; not used in locked RAM/writer',
    graphic_RAM_V3_caption4_13names_QH104_ticks34_eta547_kept=True,
    ROI_not_expanded=True,MediaBox_outer_clip_pad_pt=2,no_PDF_or_progress_written=True)
root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/CHU TRUC NGUON9 DAO CATFIX CHUAN BI'))
Path(fresh(root/'CHUAN BI BUILDER60 DAO NGUON9 CHUA CHAY PDF.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print('PREPARED PURE BUILDER',str(new),manifest['prepared_builder_SHA256'],flush=True)
