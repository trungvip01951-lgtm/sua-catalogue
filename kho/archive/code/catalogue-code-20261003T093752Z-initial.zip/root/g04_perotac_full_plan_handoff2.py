"""Phương án đồng bộ Perotac p8 sau quy chuẩn đồ họa; chỉ kế hoạch."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
import json,hashlib,numpy as np

name='Perotac bơm giếng SA_compressed (bản mới).pdf'
src,current=S.src(name),S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
read=lambda fn:json.loads((folder/fn).read_text(encoding='utf8'))
info=read('104 O NGUON VA PHAM VI DONG BO CHI DOC.json')
measure=read('MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json')
fonts=read('PHONG VA CHU NGUON CHI DOC.json')
lock=read('KHOA DASH LUOI KHUNG VA CO CHU NGUON.json')
type_color=read('MAU LOI CHU VA TIEU DE GOC.json')
assert sha(src)==info['source_sha256'] and sha(current)==info['current_sha256']
assert len(measure['numeric_plan_104_cells'])==13
assert sum(len(z['source_H_m']) for z in measure['numeric_plan_104_cells'])==104
assert fonts['same_file_embedded_font_candidate_count']==0
E=Editor(src,backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H))
axis=info['axis_previously_read'];qfit=axis['calibration'];hfit=axis['H_grid_calibration'];edit=[65,117,790,805]
key_centers_v=[562,550,538,526,514,496,484,472,460,448,435,423,411]
rows=[]
for idx,p in enumerate(measure['numeric_plan_104_cells']):
    q0,h0=p['starts_at_literal_QH'];q1,h1=p['ends_at_literal_QH'];col,rr=idx//5,idx%5
    row=dict(p,curve_suffix_label='/'+p['model'].split('/')[-1],
             proposed_end_suffix_center_native=[710,key_centers_v[idx]],
             legend_column_0based=col,legend_row_0based=rr,
             legend_source_word_native_baseline=[140+col*(621.5/3),744+rr*14],
             native_numeric_start=[qfit['u_Q0']+qfit['u_per_l_min']*q0*1000/60,hfit['v_H0']+hfit['v_per_m']*h0],
             native_numeric_end=[qfit['u_Q0']+qfit['u_per_l_min']*q1*1000/60,hfit['v_H0']+hfit['v_per_m']*h1],
             identity_from_same_literal_table_record=True)
    rows.append(row)

dash=lock['proposed_locked_dash_pt'];period=sum(dash)
styles=dict(
    QH=dict(RGB=[127,145,150],width_pt=0.90,opacity=1.0,cap=0,join=1,
            same_for_all_13_models=True,color_from_Perotac_original_only=True,
            source_equivalent_width_median_pt=measure['common_QH_equivalent_width_pt_median']),
    eta=dict(RGB=[127,145,150],width_pt=0.90,opacity=1.0,cap=0,join=1,
             source_median_RGB=measure['eta_source']['source_median_core_RGB'],numeric_acceptance='CHƯA THỂ XÁC MINH — không có bảng η'),
    dash=dict(length_pt=dash[0],gap_pt=dash[1],phase_pt=0.0,period_pt=period,
              source_full_dashes=lock['source_dash_count'],source_gaps=lock['source_gap_count'],
              source_arc_length_median_pt=lock['source_dash_arc_median_pt'],source_gap_arc_median_pt=lock['source_gap_arc_median_pt'],
              source_edge_uncertainty_pt=lock['source_dash_edge_uncertainty_pt'],
              same_physical_arc_length_pattern_for_all_models=True,
              planned_7_dashes_before_solid=True,solid_arc_start_pt=7*period,
              source_solid_start_is_occluded_near_old_labels=True,
              method='Một compound path: 7 subpath nét đứt theo chiều dài cung, subpath thứ 8 nối liền đến Q21. Chỉ một lần tô nét; không ghép thân ảnh/đuôi vector và không chồng hai path che nối.',
              explicit_subpaths_require_actual_arc_length_readback=True,
              source_18_head_trace_limit='Dò màu /18 chỉ bám được từ u253; nhịp chung cần đối chiếu ảnh nguyên 13 đầu nét, không gọi thiếu mực là nét đứt.'),
    grid=dict(RGB=[225,225,225],width_pt=0.25,opacity=1.0,
              vertical_native_u=[124.5,202,280,358,435,513,591,668,746],
              horizontal_native_v=[180.55520504731862,246,311,376,441,506,571.5443037974684],
              source_position_limit_native_px=0.5,source_core_median_RGB=lock['source_grid_median_core_RGB'],
              new_width_is_design_choice_not_claimed_original_PDF_pen=True),
    frame=dict(RGB=[93,93,93],width_pt=0.55,opacity=1.0,
               source_median_RGB=lock['source_frame_median_core_RGB'],new_width_is_design_choice=True),
    caption_font=dict(source='Nhãn 4SA16 trong chính X7 Perotac',source_caption_core_RGB=type_color['source_caption_core_RGB_median'],
                      RGB=[57,55,57],opacity=1.0,scale=1.0,
                      physical_source_cap_height_px=[7,8],physical_source_cap_height_pt=[7*measure['source_pixel_to_page_pt'],8*measure['source_pixel_to_page_pt']],
                      outside_font=False,source_font_program=False,
                      method='Đường đẳng alpha0,5 của mực glyph gốc, theo alpha=(255−L)/(255−L_core). Ghi đường bao bằng catfix; giữ tỷ lệ1:1, lỗ chữ, cấu trúc, đường cơ sở. Chỉ làm mượt biên nếu sai khác≤0,10pixel nguồn và đạt đối chứng hình/đậm/cỡ.',
                      safe_glyph_selection='Chọn glyph sạch từ các caption cùng kiểu; loại lưới/mực đường bơm bằng màu và vị trí. Dạng chữ thiếu nét hoặc lẫn đường không được suy ra, phải tìm glyph khác trong chính file hoặc ghi chưa thể.',
                      clear_glyph_bank_covers='4,S,A,0–9,/ cho tên và suffix, đủ /11 với cả hai số1',
                      letter_bank_not_yet_created=True,new_glyph_sample_not_yet_drawn=True),
    title=dict(source_literal='4SA16',source_native_bbox=type_color['source_title_ink_native_bbox'],
               source_RGB=type_color['source_title_RGB_median'],RGB=[21,55,105],scale=1.0,opacity=1.0,
               method='Chép hình chữ xanh đậm trong chính X7; không học từ caption thường'),
    axis_font=dict(scale=1.0,opacity=1.0,source='Từng cụm chữ/số đúng vị trí trục trong X7; cùng kiểu học riêng',
                   new_font_name_not_claimed=True,source_words_traced_individually=True),
    annotation_leader=dict(RGB=[180,180,180],width_pt=0.30,opacity=1.0,cap=0,
                           not_extra_pump_performance=True,no_QH_beyond21=True,
                           minimum_glyph_to_grid_or_line_clearance_pt=0.5))

plan=dict(
    stage='CHỈ KẾ HOẠCH — CHỜ ROOT KHÓA, CHƯA TẠO MẪU',owner='g03_aquaris_sa — duy nhất Perotac SA',
    source=src,current=current,source_sha256=sha(src),current_sha256=sha(current),
    page=8,QH_model_count=13,literal_H_cell_count=104,separate_eta_curve_count=1,
    source_no_model_7=True,read_104_source_cells_at_PDF600dpi=True,
    edit_native_box=edit,edit_pdf_rect=list(cv.rect(edit)),
    planned_layout=dict(QH_frame=axis['frame_native'],eta_panel_native_box=[124.5,583,746,677],
                        full_model_legend_native_box=[124.5,733,746,805],legend_columns=3,legend_rows_max=5,
                        legend_native_baseline_step=14,
                        suffix_centers_avoid_H_grid_v441_and506=True,
                        literal_model_identity_from_table_not_rank_or_power=True,
                        outside_kept=['Toàn trang1–7,9–11','Toàn nửa phải trang8','Bảng thông số trang8 và các ô kW/HP đã sửa']),
    rows=rows,prior_accepted_16_points=[r for r in rows if r['model'] in ['4SA16/23','4SA16/18']],
    styles=styles,source_axis=axis,
    axes_literal=dict(H_m=[0,25,50,75,100,125,150],flow_l_min=[0,50,100,150,200,250,300,350],
                      flow_m3_h=[0,2.5,5,7.5,10,12.5,15,17.5,20,22.5],
                      US_gpm=[0,10,20,30,40,50,60,70,80,90],Imp_gpm=[0,10,20,30,40,50,60,70,80],feet=[0,100,200,300,400],
                      no_extra_unprinted_end_label=True,eta_percent_labels=[0,20,40,60]),
    eta_source=measure['eta_source'],eta_shape_tolerance_native_px=0.75,
    eta_method='Cubic trơn theo558tâm mực X7, giữ endpoints quan sát, không ngoại suy; độ lệch vuông góc tối đa0,75pixel nguồn. Đường/khung bị che tại gốc chỉ ghi giới hạn, không tự thêm Q0/η0.',
    background_and_layer_method='Chỉ lấy nguồn giấy/số/chữ từ X7 nguyên Perotac. Xóa toàn mực biểu đồ cũ trong hộp, gồm2đường vector và mọi mask đang có. Dùng miếng nền không mất dữ liệu với SMask ở pixel thật cần đổi; giữ11JPEGrawbytes/CTM. Sau đó toàn khung/lưới,13Q–H/η và chữ là vector, đặt sau mọi mask. Không raster hóa trang và không lấy patch/Redpump làm nguồn.',
    literal_source_anomalies_all17=[r for r in info['all_17_graph_counts'] if r['literal_increases']],
    all17_source_manifest=info['all_17_graph_counts'],
    old_whole_audit_unknown_235_not_reclassified=True,
    first_page8_only_then_root_review=True,max_failed_trials_each_method=2,new_method_trial_count=0,
    glyph_critical_limit='Nguồn150dpi không có mô tả phông liên tục. Chuyển biên glyph chưa được thử nên chưa khẳng định chữ sẽ sắc/đạt. Sai hình hoặc không sạch thì CHƯA ĐẠT, không dùng phông hệ thống.',
    numerical_planning_only=True,numerical_PDF_readback_not_yet_run=True,
    acceptance=dict(numeric_path='104ô từ nét thực PDF; đi đúng8nút/model, endpointQ0..21; sai số≤max(1m,2%H).16mốc/23,/18 đọc lại từ cùng nguồn.',
                    visible_ink='104mốc bằng mực600dpi, nguồn/vạch/uncertainty ghi riêng; mốc nằm trong gap đứt phải ghi thiếu đọc mực, không nhận pixelPASS từ mảng.',
                    graphic='Đủ13tên/13suffix, không thiếu số1; nét/chữ/lưới/khung đồng bộ, không halo/nét đôi/mảnh cũ. Toàn trang150dpi100%, nghi ngờ600dpi.',
                    w_color_sharpness='wkhai báo cùng0,90pt±0,01; widthmặt cắt≥5đoạn sạch/đường, trungvị lệch≤5%, phân tán≤5%; RGB≤1/255; opacity1; mép10–90%≤2pixel600dpi.',
                    glyph='Cỡ so nguồn±2%, đậm±10%, đủglyph và topology; ít nhất2ký tự chung/toàn từ đối chứng150/600dpi. Không phóngảnh mờ thành chữ sắc.',
                    dash='Nét/khe theo actualarclength trongPDF, cùng7,26/2,94±0,01pt và pha0; điểm nối khônggap/đôi, khoảng tâm≤0,01pt/tangent≤1°.',
                    preserve='Ngoài hộp:11trang200dpi/ngưỡng0=0pixel khác.11JPEGrawSHA/CTM,Info,XMPgiá trị chuẩn XML,links/bookmarks/11khổtrang/fontgiữ.',
                    ROOT='ROOT kiểm số và tác nhân đồhọa kiểm ảnh thật trước canonical; numeric đúng/graphicfail vẫn CHƯA ĐẠT.'),
    trial_PDF_written=False,trial_image_written=False,new_vector_glyph_written=False,canonical_written=False,common_progress_written=False)

Path(fresh(folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V2.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Phương án đồng bộ Perotac trang 8 — chỉ kế hoạch

**13 đường Q–H, 104 ô H và một đường η riêng. Chưa tạo mẫu. Nguồn và bản giao giữ nguyên.** Q là lưu lượng; H là cột áp; η là hiệu suất. Không có model /7.

Hai đường /23, /18 đã nghiệm thu được tích hợp vào biểu đồ mới theo chỉ đạo anh Trung; giữ đúng 16 ô riêng Perotac và kiểm lại cùng 104 ô. Mẫu vá năm đuôi giữ bằng chứng kỹ thuật, CHƯA ĐẠT hình thức theo yêu cầu mới.

## Bảng nguồn đã đọc lại

Q chung: **0, 3, 6, 9, 12, 15, 18, 21 m³/giờ**. Mỗi hàng dưới là tám ô H thật, theo đúng thứ tự Q. Ảnh toàn bảng nguồn PDF600dpi có trong hồ sơ.

| Model | 8 ô H(m) | Điểm đầu Q/H | Điểm cuối Q/H |
|---|---|---|---|
'''
for r in rows:
    md+='| '+r['model']+' | '+', '.join(map(str,r['source_H_m']))+' | 0 / '+str(r['source_H_m'][0])+' | 21 / '+str(r['source_H_m'][-1])+' |\n'
md+='''
Nội suy PCHIP là phép nối từng đoạn qua đúng các ô số và giữ chiều giảm. Cả 13 hàng giảm, sai số nút kế hoạch dưới 10⁻¹⁰ m; chưa phải nghiệm thu PDF. Không ngoại suy sau Q21: /20 kết thúc H43, /25 H54; đuôi cũ kéo dài chỉ giữ trong bằng chứng nguồn.

## Khóa nét, chữ, lưới và bố cục

| Hạng mục | Thông số đề nghị, đo riêng từ Perotac |
|---|---|
| Q–H và η | RGB 127/145/150; bút 0,90pt; opacity 1; cap0 (đầu phẳng), join1 (nối bo). 13 đường Q–H cùng một bộ nét. |
| Cơ sở độ dày | Trung vị tương đương nguồn 0,90056pt; từng đường 0,8220–0,9252pt. Đây là đo ảnh JPEG, không gọi là bút PDF gốc. |
| Nét đứt | Nét 7,26pt, khe 2,94pt, pha0 tính theo chiều dài cung. Đo 71 đoạn/59 khe từ mực nguồn; bất định biên khoảng±0,36pt. Một đối tượng nét gồm 7 đoạn đứt và đoạn thứ8 liền đến Q21; không chồng thân/đuôi để che nối. |
| Lưới | RGB225/225/225, bút0,25pt. Giữ đúng vạch nguồn, sai khác tâm không quá±0,5pixel gốc. Bút mới là lựa chọn thiết kế sau khi đối chiếu nguồn. |
| Khung | RGB93/93/93, bút0,55pt; cùng bộ cho cả miền Q–H và η. Màu từ lõi khung nguồn; độ dày đề nghị cần xem mẫu. |
| Chữ tên model | Mực nguồn RGB57/55/57; tỷ lệ1:1, cap chữ gốc7–8pixel≈3,36–3,84pt. Không tăng cỡ trái ngưỡng±2%. |
| Tiêu đề | Chép chữ4SA16 xanh từ chính X7; RGB21/55/105, tỷ lệ1:1. Chữ trục/đơn vị học riêng đúng kiểu/cỡ/vị trí nguồn. |
| Chú giải | 13 tên đầy đủ, 3cột×5hàng; bước dòng14pixel gốc≈6,72pt. Suffix thật tại cuối đường, kèm đường dẫn xám0,30pt để phân biệt khỏi dữ liệu bơm. |

Toàn biểu đồ và khoảng chú giải nằm trong hộp ảnh gốc **[65,117,790,805]**. Q–H giữ khung x124,5..746/y180,5..571,5; η ở x124,5..746/y583..677. Chú giải dùng khoảng trắng dưới trục Q: x124,5..746/y733..805. Bảng thông số và toàn nửa phải trang8 giữ nguyên.

Các suffix /4…/25 ở x≈710 được giãn tại y562/550/538/526/514/496/484/472/460/448/435/423/411, tránh hẳn lưới y441/y506. Mỗi suffix và tên đầy đủ lấy **cùng bản ghi model trong bảng**, không suy tên từ thứ hạng hay công suất. Đường dẫn giữ thứ tự, không giao nhau; không được gây hiểu nhầm là kéo thêm đường Q–H sauQ21. Khoảng chữ với nét/lưới ít nhất0,5pt; cần kiểm hình thực trước nhận.

Giữ số/đơn vị nguồn: H0/25/50/75/100/125/150m; lít/phút0…350; m³/giờ0…22,5; gallon Mỹ0…90, gallon Anh0…80; feet0/100/200/300/400 (feet là đơn vị chiều dài). Giữ tên gốc trong catalogue, không thêm nhãn cuối chưa in. Trục phụ dùng đúng vạch/chữ nguồn, không ghép số gần nhau thành cặp quy đổi.

## Chữ nguồn và phần chưa thể cam kết

**11 trang nguồn có 0 phông nhúng và 0 chữ thật.** Chữ là ảnh JPEG150dpi. Caption4SA16 có đủ4/S/A/0–9/slash cho 13 tên và suffix; phải giữ cả hai số1 trong /11. Không lấy phông hệ thống, tệp khác hoặc Redpump.

Đề nghị chọn glyph sạch cùng kiểu trong chính Perotac; dựng đường bao từ mực nguồn bằng catfix. Biên lấy đường đẳng alpha0,5; alpha là tỷ lệ mực so với nền và màu lõi. Giữ tỷ lệ1:1, đường cơ sở, lỗ chữ và cấu trúc. Một ngân hàng glyph chung cho các chữ lặp để không có chữ đậm/chữ mờ. Nếu làm mượt biên, giới hạn sai khác0,10pixel nguồn và chỉ nhận khi độ cao±2%, độ đậm±10%, topology (cấu trúc/lỗ chữ) cùng nguồn. Đơn vị và tiêu đề học riêng, không gán tên một phông không có trong PDF.

**Chưa tạo ngân hàng glyph vector hay mẫu chữ mới.** Không khẳng định nguồn150dpi sẽ tự chuyển thành chữ đẹp. Cần so ít nhất2ký tự chung và toàn từ ở độ phân giải nguồn, rồi ảnh PDF600dpi. Thiếu nét, dính lưới/đường bơm, khác hình hoặc cạnh bể cạnh nét mới thì CHƯA ĐẠT; không dùng phông ngoài để vượt giới hạn.

Đầu nét nguồn /18 trong phép dò màu chỉ theo được từu253; 12đường còn lại khóa được chu kỳ. Cần soi nguyên cả13đầu nét ở600dpi trước nhận nhịp chung. Không biến hụt mực JPEG1–2pixel thành khe mới. Chu kỳ đề nghị là lựa chọn đồng bộ có cơ sở đo; chưa nghiệm thu nét đứt PDF.

## η riêng

Có558tâm mực quan sát từu127đến684, không có nhánh khác sau gộp hai quầng của cùng nét. Đầu quan sát(u127,v674), cuối(u684,v630,6808). Dựng cubic (nét trơn bậc ba) trong miền quan sát, độ lệch vuông góc đề nghị≤0,75pixel nguồn; không ngoại suy. Không tự gán Q0/η0 cho chỗ bị khung che. Giữ nhãn0/20/40/60%, không thêm70%. Không có bảngη nên **CHƯA THỂ XÁC MINH hiệu suất số liệu**, chỉ nghiệm thu hình bám nguồn.

## Nền và kiểm sau mẫu

Nguồn giấy/số/chữ/màu đều từ X7 nguyên Perotac. Xóa toàn mực biểu đồ cũ trong hộp, gồm JPEG, hai nét vector /23,/18 và phần che đang có; không để nét cũ lẫn nét mới. Giữ 11 JPEG đúng byte/ma trận. Miếng nền không mất dữ liệu dùng SMask (mặt nạ độ trong suốt) chỉ ở pixel thật cần đổi. Toàn khung/lưới/13Q–H/η/chữ mới là vector, đặt sau mọi mặt nạ; không nén ảnh nguyên trang hay chuyển trang thành ảnh.

Sau ROOT khóa kế hoạch mới tạo MẪU1 riêng. Đọc lại **104 ô từ nét và mực PDF thực**, endpointQ0..21, đủ13tên/suffix,16mốc/23,/18; sai số≤max(1m,2%H), ghi độ bất định trục riêng. Mốc nằm trong khe đứt phải ghi thiếu đọc mực; không gọi mảng tọa độ là nghiệm thu nhìn thấy.

Kiểm đồ họa theo quy chuẩn độc lập: ít nhất5mặt cắt sạch/đường; bút sai khác≤0,01pt; độ dày trung vị/phân tán≤5%; opacity1; màu cùng nhóm≤1/255; mép10–90%≤2pixel600dpi. Chu kỳ nét đứt đọc từ đường thật±0,01pt, tâm nối≤0,01pt và tiếp tuyến≤1°. Xem toàn trang150dpi100% trước, vùng nghi ngờ600dpi sau: không mờ/đậm xen, không quầng/vết vá/nét đôi/mảnh cũ, không mất ký tự.

Vùng ngoài hộp trên11trang:200dpi/ngưỡng0=0pixel khác. Giữ11JPEGrawSHA/CTM,Info,XMPgiá trị sau chuẩn XML,link/bookmark/khổ/phông. ROOT kiểm số độc lập và tác nhân đồ họa kiểm ảnh thật trước cập nhật bản giao. Nhiều nhất2mẫu thất bại/phương pháp; số đúng nhưng hình thức chưa đạt vẫn CHƯA ĐẠT.

## Khung cho17biểuđồ

Đã đọc196dòng/1931ô riêng Perotac. Chỉ mở rộng sau mẫu p8 đạt số/chữ/đồ họa. Từng biểu đồ dùng bảng/ảnh/vạch/glyph của chính Perotac; η giữ giới hạn riêng vì không bảng. 235mốc cũ chưa rõ và7danh tính nét cũ chưa khóa không tự thành đạt. Bảng có tăng nhẹ (6SA25...) phải giữ đúng ô thật, không ép giảm hay sửa bảng để thuận hình. Danh sách đủ17biểuđồ và các ô tăng có trong JSON.

Không ghi TIEN DO.md, chưa ghi PDF hay hình mẫu mới.
'''
# Keep human-facing wording spaced even around quantities and symbols.
fixes={
 'sauQ21':'sau Q21','13đầu':'13 đầu','12đường':'12 đường','13tên':'13 tên','16mốc':'16 mốc','11trang':'11 trang','11JPEG':'11 JPEG','17biểuđồ':'17 biểu đồ','196dòng':'196 dòng','1931ô':'1931 ô','235mốc':'235 mốc','7danh':'7 danh','558tâm':'558 tâm','5mặt':'5 mặt','2mẫu':'2 mẫu','2ký':'2 ký',
 'RGB225':'RGB 225','RGB93':'RGB 93','RGB57':'RGB 57','RGB21':'RGB 21','bút0':'bút 0','chữ4SA16':'chữ 4SA16','Caption4SA16':'Caption 4SA16','tỷ lệ1':'tỷ lệ 1','cap0':'cap 0','join1':'join 1','pha0':'pha 0','phiên0':'phiên 0',
 '0,01pt':'0,01 pt','0,5pt':'0,5 pt','6,72pt':'6,72 pt','0,75pixel':'0,75 pixel','0,10pixel':'0,10 pixel','7–8pixel':'7–8 pixel','14pixel':'14 pixel','1–2pixel':'1–2 pixel','2pixel':'2 pixel','0pixel':'0 pixel','1m':'1 m',
 'Nguồn150dpi':'Nguồn 150dpi','JPEG150dpi':'JPEG 150dpi','nguồn150dpi':'nguồn 150dpi','opacity1':'opacity 1','0,5;':'0,5;',
 '13Q–H':'13 Q–H','13 tên':'13 tên','bảngη':'bảng η','thêm70%':'thêm 70%','từu253':'từ u253','từu127đến684':'từ u127 đến684',
 'RGB 127/145/150':'RGB 127/145/150', '3cột×5hàng':'3 cột×5 hàng',
 'ngân hàng glyph':'ngân hàng glyph (mẫu hình ký tự)', 'slash':'dấu gạch chéo', 'vector':'vector (nét PDF thật)',
 'compound path':'đường ghép các phần nét', 'endpointQ0':'điểm đầu/cuối Q0','topology':'topology',
 '104 ô từ nét':'104 ô từ nét'
}
for old,new in fixes.items():md=md.replace(old,new)
md+='\nSHA nguồn: '+sha(src)+'\n\nSHA bản giao: '+sha(current)+'\n'
Path(fresh(folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V2.md')).write_text(md,encoding='utf8')
E.close()
print('PLAN ONLY 13QH/104CELLS + ETA; styles',styles['QH'],styles['dash']['length_pt'],styles['dash']['gap_pt'],flush=True)
print('NO PDF/NEW GLYPH/PROGRESS; SHA',sha(src),sha(current),flush=True)
