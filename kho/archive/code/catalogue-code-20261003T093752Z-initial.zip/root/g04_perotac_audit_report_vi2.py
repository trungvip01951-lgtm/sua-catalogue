from catwork import start,fresh
S,D,N=start()
from pathlib import Path
root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
txt=(root/'KIEM TOAN CUOI TIENG VIET.md').read_text(encoding='utf8')
txt=txt.replace('KIEM TOAN CUOI DE tác nhân chính DOC.json','KIEM TOAN CUOI DE ROOT DOC.json')
Path(fresh(root/'KIEM TOAN CUOI TIENG VIET V2.md')).write_text(txt,encoding='utf8')
assert 'KIEM TOAN CUOI DE ROOT DOC.json' in txt
assert 'nominal' not in txt
print('Vietnamese report V2 saved; evidence filenames preserved.',flush=True)
