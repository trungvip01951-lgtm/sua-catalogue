"""Callable RAM reconstruction; import does no file work or mutation."""
def build_three_fix_RAM(b,a,atlas,layout,v,holes,eta):
    from catfix.vector import Editor
    from catfix.cs import Instr,Num,Name
    import json
    def I(op,*xs):return Instr([Num(float(x)) for x in xs],op)
    def re(bb):return I('re',bb[0],bb[1],bb[2]-bb[0],bb[3]-bb[1])
    V={z['character']:z for z in v['records']};AA={z['model']:z for z in atlas['records']};LB={z['model']:z for z in layout['records']}
    E=Editor(b['sample'],backend='fitz');P=E.page(7)
    tag=next(i for i,z in enumerate(P.ops) if z.op=='BMC' and list(map(str,z.operands))==['CfxRedpumpWholePage8M1'])
    for r in b['labels']:
        matches=[z['i'] for z in P.images if z['i']>tag and z['name']==r['image_name']];assert len(matches)==1
        E.delete_instrs(7,matches)
    for r in holes['records']:
        for idx in r['changed_rect_instruction_indices']:E.modify_instr(7,idx,re(r['proposed_effective_hole_after']))
    ec=next(z for z in eta['RAM_rendered_candidates'] if z['pieces']==2);eo=P.objs[a['eta_actual']['actual_object']]
    E.delete_instrs(7,range(eo['i0'],eo['i1']))
    E.insert_instrs(7,eo['i1'],[Instr([Num(float(val)) for xy in ps for val in xy],op) for op,ps in ec['actual_RAM_path']],before=True)
    ins=[Instr([Name('CfxRedpumpSmallSourceGlyphSingleCoreRAM2')],'BMC'),Instr([],'q')];records=[];expected=[]
    for r in b['labels']:
        name=r['model'];lb=LB[name];word=AA[name];origin=lb['source_word_array_page_origin'];bb=lb['physical_box']
        ins += [Instr([],'q'),re(bb),Instr([],'W'),Instr([],'n'),I('g',v['core_gray']/255)]
        chars=[]
        for g in word['glyphs']:
            ch=g['character'];vv=V[ch];dx,dy=g['assembled_offset600'];ox=origin[0]+dx*.12;oy=origin[1]-dy*.12
            for part in vv['parts']:
                path=[]
                for loop in part['loops']:
                    for op,ps in loop['path']:
                        pts=[[ox+x*.12,oy-y*.12] for x,y in ps];path.append((op,pts))
                        ins.append(Instr([Num(float(val)) for xy in pts for val in xy],op))
                ins.append(Instr([],'f*'));expected.append(dict(model=name,character=ch,source_part=part['source_part'],path=path))
            chars.append(dict(character=ch,word_offset600=[dx,dy],page_origin=[ox,oy]))
        ins.append(Instr([],'Q'));records.append(dict(model=name,physical_box=bb,chars=chars))
    ins += [Instr([],'Q'),Instr([],'EMC')]
    E.insert_instrs(7,len(P.ops),ins,before=True);E.doc.set_page_content(7,E.build(7));E.pages.clear();PR=E.page(7)
    qh=[]
    for m in a['actual_QH_paths']:
        for part in m['parts']:
            oi=part['object_index'];path=PR.object_pagepath(oi)
            assert json.dumps(path,separators=(',',':'))==json.dumps(part['path'],separators=(',',':'))
            qh.append(dict(model=m['model'],actual_object=oi,path_unchanged=True))
    assert len(qh)==26
    return E,records,expected,qh
