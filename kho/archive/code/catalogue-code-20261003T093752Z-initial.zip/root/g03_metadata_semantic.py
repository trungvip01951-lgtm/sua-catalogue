from catwork import start, fresh
S,D,N=start()
from pathlib import Path
import json, xml.etree.ElementTree as ET
root=Path(S.report('G03'))
probe=json.loads((root/'metadata-probe.json').read_text(encoding='utf-8'))
def canonical(element):
    return (element.tag,sorted(element.attrib.items()),(element.text or '').strip(),
            tuple(canonical(child) for child in element))
a=canonical(ET.fromstring(probe[0]['xml']))
b=canonical(ET.fromstring(probe[1]['xml']))
result=dict(values_equal=a==b,stream_bytes_equal=probe[0]['xml']==probe[1]['xml'],
            source_values=a,final_values=b,
            note='Bộ lưu pikepdf đổi cách ghi dấu nháy/khoảng trắng XML và bỏ chỉ dẫn bộ lọc Adobe; mọi phần tử, thuộc tính và giá trị thông tin đều giữ nguyên.')
json.dump(result,open(fresh(root/'metadata-values.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
accpath=root/'acceptance-final.json'
acc=json.loads(accpath.read_text(encoding='utf-8'))
acc['metadata_values_equal']=result['values_equal']
acc['metadata_format_note']=result['note']
accpath.write_text(json.dumps(acc,ensure_ascii=False,indent=1,default=str),encoding='utf-8')
print('Giá trị thông tin XML giữ nguyên:',result['values_equal'])
