"""All thirteen literal model names from one genuine Redpump glyph bank. No PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));d=json.loads((root/'GLYPH NGUON NGUYEN CAC NET ROI SNAPSHOT V4.json').read_text(encoding='utf8'));bank={z['character']:z for z in d['records']};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(plan['method']['source']),sha(plan['method']['input_current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
advance={ch:24 for ch in '0123456789'};advance.update({'S':32,'L':24,'/':12});bearing={'4':0,'S':2,'L':0,'6':2,'3':1,'/':0,'2':1,'5':2,'0':1,'8':1,'9':1,'1':4};baseline={'4':33,'S':33,'L':33,'6':33,'3':33,'/':33,'2':33,'5':34,'0':36,'8':32,'9':37,'1':36}
names=[z['model'] for z in reversed(plan['page8_QH_models'])];picture=Image.new('RGB',(1200,len(names)*135),'white');dr=ImageDraw.Draw(picture);records=[]
for i,name in enumerate(names):
 width=sum(advance[ch] for ch in name)+18;alpha=np.zeros((56,width),float);x=6;glyphs=[]
 for ch in name:
  a=np.array(bank[ch]['source_alpha']);h,w=a.shape;y=43-baseline[ch];u=x+bearing[ch];alpha[y:y+h,u:u+w]=np.maximum(alpha[y:y+h,u:u+w],a);glyphs.append(dict(character=ch,source_page=bank[ch]['source_page'],source_word=bank[ch]['source_word'],source_page_box=bank[ch]['source_page_box'],source_alpha_file=str(root/'GLYPH NGUON NGUYEN CAC NET ROI SNAPSHOT V4.json'),assembled_offset600=[u,y],physical_scale=1.));x+=advance[ch]
 yy,xx=np.nonzero(alpha>.085);ib=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)];word=Image.fromarray((255*(1-alpha)).round().clip(0,255).astype('uint8')).convert('RGB');dr.text((5,i*135+7),name,fill='blue');picture.paste(word,(170,i*135+12));picture.paste(word.resize((word.width*2,word.height*2),Image.Resampling.NEAREST),(475,i*135+3));dr.text((950,i*135+20),str(ib),fill='blue')
 metrics=[]
 for t in [.085,.15,.2,.25,.3]:
  yv,xv=np.nonzero(alpha>=t);metrics.append(dict(source_alpha_level=t,inkbox600=[int(xv.min()),int(yv.min()),int(xv.max()+1),int(yv.max()+1)],physical_height_pt=float((yv.max()-yv.min()+1)*.12)))
 records.append(dict(model=name,assembled_alpha_source_only=alpha.tolist(),glyphs=glyphs,inkbox600=ib,physical_ink_box_size_pt=[(ib[2]-ib[0])*.12,(ib[3]-ib[1])*.12],alpha_level_metrics=metrics,source_scale=1.,same_bank=True,catalogue_written=False))
photo=fresh(root/'13 NHAN THAT CUNG BO SNAPSHOT V5 DAY DU.png');picture.save(photo)
out=dict(source_SHA256=before[0],current_SHA256=before[1],source_bank=str(root/'GLYPH NGUON NGUYEN CAC NET ROI SNAPSHOT V4.json'),records=records,proof_photo=photo,physical_scale=1.,advance600=advance,bearing600=bearing,baseline600=baseline,nominal_black_core_capheight_pt=3.84,source_render_pixel_pt=.12,source_native_pixel_pt=.480136,font_no_embedded_metrics=True,source_glyph_edge_uncertainty_pt=.24,font_size_statement='Giữ đúng kích thước vật lý mỗi mẫu chữ nguồn, không co/giãn. Cỡ phông danh nghĩa không truy ra được vì tệp chỉ có ảnh; chiều cao hộp mực thay đổi theo ngưỡng do JPEG/pha điểm ảnh, không lấy một ngưỡng làm cỡ phông chính xác.',placement_statement='Dịch vị trí/baseline (đường chân chữ) và dùng cùng bộ khoảng tiến đo từ nhãn nguồn; không đổi hình mực, không tạo chữ phông ngoài.',status='HỒ SƠ CHỮ NGUỒN SNAPSHOT: đủ 13 tên để ROOT/đồ họa đọc, chưa ghi PDF và chưa kết luận đạt độ sắc cuối.',PDF_sample_written=False)
out['correction']='V5 dùng glyph nguồn snapshotV4 có rawRGB + requestrect độc lập: giữ mọi nét roi của0/1/3/5/9 và bỏ đúng cột số2 cạnh6. Không dùng metadataIDcomponent khi replayCVrect0 vì làm tròn có thể dịch một hàng.'
Path(fresh(root/'13 NHAN THAT CUNG BO SNAPSHOT V5 DAY DU.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert before==[sha(plan['method']['source']),sha(plan['method']['input_current'])];print('13 literal model names, source bank V3, physical scale 1, noPDF',flush=True)
