from catwork import start,fresh,row
from pathlib import Path
import json,hashlib
S,D,N=start()
from catfix.vector import Editor
from catfix import verify
from g03_xmp_helper import check_xmp
import pymupdf as fitz
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
trial=S.report('G05/HOAN THIEN/'+name)
ck=json.loads(Path(S.report('G05/HOAN THIEN/KIEM TRA.json')).read_text(encoding='utf-8'))
ind=json.loads(Path(S.report('G05/NGHIEM THU DOC LAP CUOI.json')).read_text(encoding='utf-8'))
assert ck['check']['ok'] and not ck['check']['unexpected'] and not ck['check']['missing']
assert ind['keep_50_134_pixels_identical'] and ind['native_original_images_preserved']
assert len(ind['ocr'])==17
# Mười hai vùng đã được OCR xác nhận; năm vùng vật liệu phải đọc bằng ảnh.
# Đã xem SO SANH, O9 và bảy ảnh toàn trang, không coi kết quả OCR lỗi là đạt.
assert sum(r['ocr_result']['ok'] for r in ind['ocr'])==12
base=json.loads(Path(S.report('BAO CAO BUOC0.json')).read_text(encoding='utf-8'))
hashes=next(r['hashes_before'] for r in base if 'hashes_before' in r)
for p,h in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
dst=fresh(S.dst(name));E=Editor(trial);E.save(dst);E.close()
assert not verify.outside_pixels(trial,dst,{},dpi=150)
allowed={}
for ed in ck['edits']:
    r=ed['rect'];allowed.setdefault(ed['page']+1,[]).append([r[0]-3,r[1]-3,r[2]+12,r[3]+3])
outside=verify.outside_pixels(S.src(name),dst,allowed,dpi=150,thr=48,min_size=2)
assert not outside
structure=verify.structure_check(S.src(name),dst);assert structure['ok']
a=fitz.open(S.src(name));b=fitz.open(dst)
assert a.metadata==b.metadata and a.get_toc(simple=False)==b.get_toc(simple=False)
assert all(a[p].get_links()==b[p].get_links() and a[p].rect==b[p].rect for p in range(12))
xmp=check_xmp(S.src(name),dst);assert xmp['values_equal']
a.close();b.close()
log=dict(source=S.src(name),destination=dst,edits=ck['edits'],accepted_trial=trial,
         final_pixel_identical=True,source_sha256=hashlib.sha256(Path(S.src(name)).read_bytes()).hexdigest(),
         final_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest())
Path(fresh(S.report(name+'.log.json'))).write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
verify.compare_sheet(S.src(name),dst,[(e['page'],e['rect'],e['label']) for e in ck['edits']],fresh(S.report('So sanh G05.png')),dpi=300)
verification=dict(source=log['source'],destination=dst,structure=structure,outside_pixels=outside,
                  xmp=xmp,source_images_preserved=True,source_all_27_hashes_preserved=True,
                  metadata_links_bookmarks_preserved=True,keep_50_134_pixels_identical=True,
                  edited_spots=17,ocr_pass=12,visual_pass=17,ocr_ambiguous_material=5,
                  reviewed_pages=[1,4,5,7,8,9,11],source_sha256=log['source_sha256'],final_sha256=log['final_sha256'],
                  curves_pending=['6SP30-6 trang 5','6SP60-20 trang 7'])
Path(fresh(S.report('G05/NGHIEM THU BAN CUOI SO VA CHU.json'))).write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
chosen={47:'67 m; trung vị H/tầng 11,1183473389; ước tính 66,7100840336, làm tròn 67; đa thức tại Q6 ≈66,11m, lệch 1,33%.',
        48:'1827 = 1063 + 764',49:'175',132:'Warranty: 1 year (bảo hành 1 năm), đủ 4 trang',
        133:'103 / 72, đúng số được chỉ định',135:'AISI 316 SS cho trục và khớp nối, đủ 8 dòng tại 4 trang'}
rows=[]
for t in D['tasks']:
    if 'G05' not in t['groups']:continue
    status='ĐẠT' if t['status']=='CAN_SUA' else 'GIỮ NGUYÊN'
    rows.append(row(t['id'],name,t['page'],t['where'],t['current'],chosen.get(t['id'],t['new']),status,
          evidence='So sanh G05.png; G05/NGHIEM THU BAN CUOI SO VA CHU.json',
          method='catfix chép số/cụm chữ từ chính file, đúng cỡ/màu và căn giữa; giữ nguyên chữ year đã có.' if status=='ĐẠT' else 'Đối chiếu vùng tiêu đề và bảng khối lượng: điểm ảnh giống nguồn.'))
assert sum(r['result']=='ĐẠT' for r in rows)==6
rep=fresh(S.report('BAO CAO G05.md'));verify.write_report(rows,rep,title='BÁO CÁO NHÓM G05 – Perotac SP')
lines=['# BÁO CÁO NHÓM G05 – Perotac SP','',
       'Đã sửa đủ 6 việc chữ/số. Nhóm CHƯA XONG vì hai đường đặc tính phát hiện thêm còn chờ đồng bộ theo bảng mới.','',
       '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|']
for r in rows:lines.append('| '+' | '.join(str(r[k]).replace('|','/').replace('\n',' ') for k in ['stt','file','page','old','new','method','result','evidence'])+' |')
lines+=['','Tổng phạm vi chữ/số: 6 việc · ĐẠT 6 · CHƯA ĐẠT 0 · CHƯA THỂ XÁC MINH 0.',
        '','Phần bổ sung: hai đường đặc tính CHƯA ĐẠT mục tiêu đồng bộ; chưa sửa đường, không tính là nghiệm thu biểu đồ.',
        '','6SP60-20 trang7 tại Q72m³/h: đường nguồn khoảng110m so bảng mới103m. 6SP30-6 trang5 tại Q36m³/h: đường nguồn khoảng37m so bảng34m. Các số đo ảnh chỉ dùng để phát hiện cần kiểm lại, không coi là số đo đủ cho cả biểu đồ.',
        '','Đã kiểm nguồn27 tệp còn nguyên, 12trang/khổ/thông tin/liên kết/dấu trang/byte ảnh gốc giữ nguyên. #50 tiêu đề và #134 vùng khối lượng giống điểm ảnh tuyệt đối.',
        '','17 vị trí đã đọc lại bằng ảnh; OCR (nhận dạng chữ từ ảnh) xác nhận12/17. Năm vùng vật liệu OCR không ổn định được xem riêng, không báo OCR đạt. Chữ316 chép cả cụm từ mẫu AISI316SS trong chính file, không dùng phông ngoài.',
        '','Chi tiết tính #47: G05/DINH VI/TOA DO VA TI LE.json. Hai số #133 giữ đúng103/72 đã chốt trong hướng dẫn, không thay bằng ước tính phụ.',
        '','Cần anh quyết: không; tiếp tục xử lý hai đường theo quyền sửa/vẽ đã cấp. AISI316SS là ký hiệu thép không gỉ316. Warranty nghĩa là bảo hành.']
Path(rep).write_text('\n'.join(lines),encoding='utf-8')
S.progress('G05','CHƯA XONG','6/6 việc chữ/số ĐẠT, 17 vị trí đã xem; còn đồng bộ2 đường đặc tính 6SP30-6/6SP60-20 phát hiện thêm.')
print('G05 lưu đúng6/6 chữ/số, nguồn nguyên, 2đường cần đồng bộ: CHƯA XONG.',flush=True)
