"""Đo kiểu chữ từ chính các nét Arial thường của bảng nguồn; ghi vẫn qua catfix."""
from catfix.otext import OutlineText,Match,procrustes
import numpy as np,copy,collections

BLACK=('rg',(0.216064,0.204102,0.208008))
BLUE=('rg',(0.133057,0.36499,0.634766))

def make_regular(T):
    E=T.E;pool=[];samples=[]
    # Cùng kiểu Arial thường, cùng cỡ: các câu và tên linh kiện trên trang 15.
    selected=[g for g in T.page_glyphs(14) if 80<g.bbox[1]<711 and 150<g.bbox[0]<470 and E.page(14).objs[g.oi]['fill'] in [BLACK,BLUE]]
    selected=[g for g in selected if g.char!='?' and not(g.char.isdigit() and g.bbox[3]-g.bbox[1]<5.5)]
    # Chỉ các dòng chữ bình thường; không lấy ký hiệu vòng tròn, chữ mũ hoặc ký hiệu nhiệt độ.
    for text,ln in T.text_lines(14):
        gl=[g for g in ln if g in selected]
        if len(gl)!=len(ln) or not gl:continue
        if not all(32<=ord(g.char)<127 for g in gl):continue
        txt=T.line_text(gl)
        if '?' in txt or any(c in txt for c in ['"','%','+']):continue
        x0=min(g.bbox[0] for g in gl);y0=min(g.bbox[1] for g in gl)
        if 332<y0<450:continue
        key='components' if y0<332 and x0<270 else len(samples)
        samples.append((txt,gl,key));pool.extend(gl)
    # P/K là ký tự có sẵn trong lớp chữ thường cùng cỡ; thêm các câu có đủ số đo.
    for p,q in [(15,'SP20'),(14,'Motor power (Kw)'),(14,'Direct start (1 cable)'),(2,'Highest')]:
        for m in T.find(p,q):
            if q=='SP20' and m.bbox[1]>300:continue
            samples.append((m.text,m.glyphs,len(samples)));pool.extend(m.glyphs)
    for m in T.find(14,'0.25'):
        samples.append((m.text,m.glyphs,len(samples)));pool.extend(m.glyphs)
    # Đo các số trong bảng 6SP20 cùng cỡ, cùng kiểu, không lấy chữ của biểu đồ.
    for m in T.find(15,r'^\d+$',regex=True,rect=(254,45,431,278)):
        if all(6.1<g.bbox[3]-g.bbox[1]<6.7 for g in m.glyphs):
            samples.append((m.text,m.glyphs,len(samples)));pool.extend(m.glyphs)
    chars=sorted(set(c for text,_,_ in samples for c in text if c!=' '))
    keys=list(dict.fromkeys(k for _,_,k in samples))
    names=[('origin',k) for k in keys]+[('adv',c) for c in chars+[' ']]+[('lsb',c) for c in chars if c!='S']
    idx={k:i for i,k in enumerate(names)};A=[];bx=[];where=[]
    for text,gl,key in samples:
        bi=0
        for k,c in enumerate(text):
            if c==' ':continue
            v=np.zeros(len(names));v[idx[('origin',key)]]=1
            for pc in text[:k]:v[idx[('adv',pc)]]+=1
            if c!='S':v[idx[('lsb',c)]]=1
            A.append(v);bx.append(gl[bi].bbox[0]);where.append((text,c,key,gl[bi].bbox));bi+=1
    # Cùng nét thẳng đứng của B/D/P/K: cố định sự nhập nhằng của chữ chỉ đứng đầu/cuối từ.
    for c in 'DPKH':
        if c in chars and 'B' in chars:
            v=np.zeros(len(names));v[idx[('lsb',c)]]=1000;v[idx[('lsb','B')]]=-1000
            A.append(v);bx.append(0)
    # Các số là kiểu bảng: độ tiến chữ giống nhau, xác minh từ các cặp 11/22/33 có sẵn.
    for c in '123456789':
        if c in chars and '0' in chars:
            v=np.zeros(len(names));v[idx[('adv',c)]]=1000;v[idx[('adv','0')]]=-1000
            A.append(v);bx.append(0)
    A=np.asarray(A);bx=np.asarray(bx);sol=np.linalg.lstsq(A,bx,rcond=None)[0]
    resid=A@sol-bx
    diag=sorted([(abs(float(r)),float(r),loc) for r,loc in zip(resid,where)],reverse=True)[:12]
    lsb={'S':0.};lsb.update({c:float(sol[idx[('lsb',c)]]) for c in chars if c!='S'})
    adv={c:float(sol[idx[('adv',c)]]) for c in chars+[' ']}
    if ')' in adv and '(' in adv:adv[')']=adv['(']
    # Đo đường chân chữ từ cùng một dòng, không dùng toạ độ suy đoán của phông hệ thống.
    namesy=[('base',i) for i in range(len(samples))]+[('bot',c) for c in chars if c!='S']
    iy={k:i for i,k in enumerate(namesy)};Ay=[];by=[]
    for n,(text,gl,key) in enumerate(samples):
        bi=0
        for c in text:
            if c==' ':continue
            v=np.zeros(len(namesy));v[iy[('base',n)]]=1
            if c!='S':v[iy[('bot',c)]]=1
            Ay.append(v);by.append(gl[bi].bbox[1]);bi+=1
    Ay=np.asarray(Ay);by=np.asarray(by);sy=np.linalg.lstsq(Ay,by,rcond=None)[0]
    bot={'S':0.};bot.update({c:float(sy[iy[('bot',c)]]) for c in chars if c!='S'})
    U=OutlineText(E)
    for g in pool:
        z=copy.copy(g);U._assign_cluster(z)
    # Gán nhãn từ nét nguồn đã đọc; mỗi ký tự vẫn lấy đúng hình nguồn cùng kiểu/cỡ.
    for cl in U.clusters:
        cl['label']=cl['members'][0].char
        cl['style']=0
        for g in cl['members']:g.char=cl['label'];g.style=0
    src={}
    for ci,cl in enumerate(U.clusters):
        c=cl['label']
        if c not in src or len(cl['members'])>len(U.clusters[src[c]]['members']):src[c]=ci
    F=dict(lsb=lsb,adv=adv,bot=bot,ref='S',rms_x=float(np.sqrt((resid**2).mean())),max_x=float(abs(resid).max()),rms_y=float(np.sqrt(((Ay@sy-by)**2).mean())),max_y=float(abs(Ay@sy-by).max()),n=len(samples),diagnostics=diag)
    lsb[' ']=0.;bot[' ']=0.
    U.styles[0]=dict(clusters=list(range(len(U.clusters))),metrics=F,src=src,space=adv[' '])
    return U,F

def at_scale(U,match):
    """Xác minh cùng hình chữ trong PDF, rồi đo tỉ lệ cỡ chữ."""
    estimates=[]
    for g in match.glyphs:
        c=g.char
        if c not in U.styles[0]['src']:continue
        src=U.clusters[U.styles[0]['src'][c]]['members'][0]
        if src.ops==g.ops and src.pts.shape==g.pts.shape:
            s,R,t,res=procrustes(src.pts,g.pts,allow_rotation=False)
            if res<.025:estimates.append((s,res,c))
    assert estimates,('Không chứng minh được cùng kiểu chữ',match.text)
    scale=float(np.median([s for s,r,c in estimates]));assert .4<scale<2
    assert max(abs(s-scale) for s,r,c in estimates)<.02,(match.text,estimates)
    V=OutlineText(U.E);V.clusters=U.clusters;V.styles=copy.deepcopy(U.styles)
    F=V.styles[0]['metrics']
    for k in ['lsb','adv','bot']:
        F[k]={c:v*scale for c,v in F[k].items()}
    gl=[copy.copy(g) for g in match.glyphs]
    for g in gl:g.style=0
    M=Match(match.key,gl,match.text,gl)
    return V,M,dict(scale=scale,proof=estimates)
