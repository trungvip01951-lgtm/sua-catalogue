from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_axis2.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
code=code.replace("sc=255-np.median(g[int(top)+45:int(bottom)-12,int(left)+4:int(right)-3],axis=0)","sc=255-np.median(g[int(bottom)+20:int(bottom)+(64 if dual else 89),int(left)+4:int(right)-3],axis=0)")
code=code.replace('height=9,distance=9,prominence=6','height=8,distance=9,prominence=5')
code=code.replace('TRUC Q NGUON ','TRUC Q NGUON LAN3 ')
code=code.replace('TRUC NGUON DO LAN2.json','TRUC NGUON DO LAN3.json')
code=code.replace('NHAN 17 DA SUA DOI CHIEU.png','NHAN 17 DA SUA DOI CHIEU LAN3.png')
exec(compile(code,__file__,'exec'))
