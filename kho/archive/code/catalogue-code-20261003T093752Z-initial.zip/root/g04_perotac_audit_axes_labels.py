from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from pathlib import Path
from PIL import Image
import numpy as np,json,re

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));E=Editor(src);R=Raster(E);allitems=[]
for rec in DATA:
 pi=rec['page']-1;im=max(R.images(pi),key=lambda x:x.W*x.H);cv=R.canvas(im);box=rec['plot_native_box'];x0,y0,x1,y1=box;dual=x1-x0<400
 # Work only in memory for character reading; original source image is never
 # replaced. Colored curve pixels are suppressed in this OCR hint copy.
 cv.work=cv.orig.copy();a=cv.work[y0:y1,x0:x1,:3];ai=a.astype(int);g=a.astype(float)@np.array([.299,.587,.114]);cyan=(ai[:,:,1]-ai[:,:,0]>5)&(ai[:,:,2]-ai[:,:,0]>7)&(g>110)
 a[cyan]=255
 labels=R.ocr(cv,(x0+20,y0+3,x1-12,y1-3),scale=4,psm=11)
 for w in labels:w['rect']=cv.rect(w['box'])
 cv.work=cv.orig.copy()
 hb=(max(0,x0-31),max(0,y0-7),x0-1,y1+8);qb=(max(0,x0-8),y1+(72 if dual else 104),min(im.W,x1+8),y1+(93 if dual else 126))
 hwords=R.ocr(cv,hb,scale=5,psm=11);qwords=R.ocr(cv,qb,scale=5,psm=6)
 for arr in (hwords,qwords):
  for w in arr:w['rect']=cv.rect(w['box'])
 names=[]
 for w in labels:
  text=w['text'].upper().replace(' ','').replace('|','').strip(',;:')
  if '/' in text:names.append(dict(raw_text=w['text'],normalized_observed=text,rect=w['rect'],box=w['box'],confidence=w['conf']))
 hs=[dict(value=float(w['text']),coord=float((w['rect'][1]+w['rect'][3])/2),word=w) for w in hwords if re.fullmatch(r'\d+(?:\.\d+)?',w['text'])]
 qs=[dict(value=float(w['text']),coord=float((w['rect'][0]+w['rect'][2])/2),word=w) for w in qwords if re.fullmatch(r'\d+(?:\.\d+)?',w['text'])]
 # Only record fits as hints. Numeric sources and rejected words remain in the
 # dossier; no fitted curve/table H value is used for model identity.
 def fit_ticks(ticks):
  if len(ticks)<3:return None
  vals=np.array([z['value'] for z in ticks]);coords=np.array([z['coord'] for z in ticks]);best=None
  for i in range(len(vals)):
   for k in range(i+1,len(vals)):
    if vals[i]==vals[k]:continue
    aa=(coords[k]-coords[i])/(vals[k]-vals[i]);bb=coords[i]-aa*vals[i];err=abs(aa*vals+bb-coords);keep=err<.7
    if keep.sum()<3:continue
    fit=np.polyfit(vals[keep],coords[keep],1);res=abs(np.polyval(fit,vals[keep])-coords[keep]);candidate=dict(slope=float(fit[0]),intercept=float(fit[1]),max_tick_residual_pt=float(res.max()),accepted_ticks=[z for z,t in zip(ticks,keep) if t],rejected_ticks=[z for z,t in zip(ticks,keep) if not t])
    key=(keep.sum(),-float(res.mean()))
    if best is None or key>best[0]:best=(key,candidate)
  return best[1] if best else None
 qfit=fit_ticks(qs);hfit=fit_ticks(hs)
 item=dict(page=pi+1,family=rec['family'],source_image=str(im.name),plot_native_box=box,label_OCR_hints=names,all_label_words=labels,head_tick_words=hwords,flow_tick_words=qwords,head_ticks=hs,flow_ticks=qs,head_axis_hint=hfit,flow_axis_hint=qfit,hint_only=True,model_identity_by_table_rank_or_H_forbidden=True)
 allitems.append(item)
 print('AXES LABELS',rec['family'],'names',[z['normalized_observed'] for z in names],'H',None if hfit is None else (hfit['slope'],hfit['intercept'],len(hfit['accepted_ticks']),hfit['max_tick_residual_pt']),'Q',None if qfit is None else (qfit['slope'],qfit['intercept'],len(qfit['accepted_ticks']),qfit['max_tick_residual_pt']),flush=True)
Path(fresh(root/'GOI Y TRUC VA NHAN LAN1.json')).write_text(json.dumps(dict(source=src,read_only=True,pdf_written=False,graphs=allitems),ensure_ascii=False,indent=2),encoding='utf8');E.close()
