"""Đối chiếu 13 nhịp đầu đường từ mực gốc, không dùng H bảng chọn nhánh."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import color_runs,follow_observed_ink
from pathlib import Path
from PIL import Image
from scipy.ndimage import median_filter
import numpy as np,json,hashlib,math
name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=folder/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON'
m=json.loads((folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'));plan=json.loads((folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V4.json').read_text(encoding='utf8'))
audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));g=next(z for z in audit['graphs'] if z['family']=='4SA16')
paths={c['model']:c.get('native_path') for c in g['curves']};paths.update({c['model']:c['observed_source_path'] for c in m['prior_accepted_models_original_source_style_trace_only']})
E=Editor(src,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float);lum=a@[.299,.587,.114]
mask=(a[:,:,2]-a[:,:,0]>=4)&(a[:,:,1]-a[:,:,0]>=2)&(lum<240);weights=(255-lum)*mask
def col(u):
    parts=color_runs(mask,weights,u,181,570,max_width=13);merged=[]
    for z in parts:
        if merged and z['lo']-merged[-1]['hi']<=3:
            p=merged[-1];tot=p['strength']+z['strength'];p.update(v=(p['v']*p['strength']+z['v']*z['strength'])/tot,strength=tot,hi=z['hi'],width=z['hi']-p['lo']+1)
        else:merged.append(dict(z))
    return merged
color=np.array([127.,145.,150.]);tone=color-color.mean();tone2=float(tone@tone);cc=(a-255)@tone/tone2
step=float(np.linalg.norm(im.ctm[:2,0])/im.W);ticks=sorted(g['axis']['flow_ticks'],key=lambda x:x['u_native']);ux=np.array([z['u_native'] for z in ticks]);qx=np.array([z['litre_per_minute']*.06 for z in ticks])
def qlocal(u):return float(np.interp(u,ux,qx))
def intervals(uv):
    out=[]
    for u,present in uv:
        if present:
            if out and u==out[-1][1]+1:out[-1][1]=u
            else:out.append([u,u])
    return out
results=[];montage=[]
for style in m['QH_source_styles']:
    model=style['model'];old=np.array([[p['u'],p['v']] for p in paths[model]])
    # Seed position is the named source ink in the earlier explicit identity audit.
    seed_u=277;pred=float(np.interp(seed_u,old[:,0],old[:,1]));cand=[z for z in col(seed_u) if abs(z['v']-pred)<4]
    assert len(cand)==1,(model,cand,pred);seed=dict(u=seed_u,**cand[0]);left,li=follow_observed_ink(col,seed,126,-1,4.5,12,history=13);right,ri=follow_observed_ink(col,seed,370,1,4.5,12,history=13)
    xy=np.array([[p['u'],p['v']] for p in left[:0:-1]+right]);issues=li+ri;us=np.arange(max(128,int(xy[0,0])),min(370,int(xy[-1,0]))+1)
    profile=[]
    for u in us:
        v=float(np.interp(u,xy[:,0],xy[:,1]));iv=int(round(v));lo=max(181,iv-4);hi=min(570,iv+5)
        bgv=np.r_[cc[max(181,iv-8):max(181,iv-5),u],cc[min(570,iv+6):min(570,iv+9),u]]
        body=float(cc[lo:hi,u].sum()-np.median(bgv)*(hi-lo))
        profile.append(dict(u=int(u),observed_source_center_v=v,chromatic_ink_integral=body))
    xx=np.array([z['u'] for z in profile]);signal=np.array([z['chromatic_ink_integral'] for z in profile]);head=signal[(xx>=128)&(xx<=269)];norm=float(np.percentile(head,65));assert norm>0
    strength=signal/norm;filtered=median_filter(strength,size=3,mode='nearest');raw_intervals=intervals(zip(xx,filtered>=.45));merged=[];weak=[]
    for lo,hi in raw_intervals:
        if merged and lo-merged[-1][1]-1<=2:
            weak.append([merged[-1][1]+1,lo-1]);merged[-1][1]=hi
        else:merged.append([lo,hi])
    full=[r for r in merged if r[0]<273 and r[1]<=273 and r[1]-r[0]+1>=8]
    tail=[r for r in merged if r[1]>=345]
    solid=None
    if tail:
        rr=tail[-1]
        if rr[0]<=300:solid=dict(source_long_ink_interval_native=rr,first_observed_after_last_resolved_gap_native_u=rr[0],source_first_ink_Q_by_local_axis=qlocal(rr[0]),source_edge_uncertainty_native_px=.75,
            source_interval_with_glyph_occlusion_weak_columns_merged=[r for r in weak if r[0]>=rr[0]],observed_ink_not_invented_data=True)
    planned=next(r for r in plan['rows'] if r['model']==model)
    for p,s in zip(profile,filtered):p['source_normalized_filtered_chromatic_coverage']=float(s)
    y0=max(175,int(xy[:,1].min())-8);y1=min(576,int(xy[:,1].max())+9);box=[120,y0,375,y1]
    raw=Image.fromarray(cv.orig[y0:y1,120:375]);p=root/(model.replace('/','-')+' DAU VA NOI NGUON150dpi.png')
    if p.exists():assert np.array_equal(np.asarray(Image.open(p)),np.asarray(raw)),p
    else:raw.save(fresh(p))
    p=root/(model.replace('/','-')+' DAU VA NOI NGUON PHONG3LAN.png');big=raw.resize((raw.width*3,raw.height*3),Image.Resampling.NEAREST)
    if p.exists():assert np.array_equal(np.asarray(Image.open(p)),np.asarray(big)),p
    else:big.save(fresh(p))
    montage.append(raw)
    result=dict(model=model,source_seed=seed,source_actual_trace_xy=xy.tolist(),source_trace_issue_count=len(issues),source_trace_issues=issues,old_trace_u_minmax=[float(old[0,0]),float(old[-1,0])],new_source_trace_u_minmax=[float(xy[0,0]),float(xy[-1,0])],
        source_profile=profile,source_original_word_and_head_image_native_box=box,source_full_ink_intervals_after_median3=raw_intervals,source_joined_intervals_only_gaps_max2_native_px=merged,
        source_short_weak_columns_intervals=weak,source_complete_dash_intervals=full,source_dash_physical_lengths_pt=[(hi-lo+1)*step for lo,hi in full],source_long_ink_transition_candidate=solid,
        V3_planned_solid_start_Q=planned['planned_solid_Q_start_m3_h'],V3_planned_solid_start_u=planned['planned_solid_native_u'],
        V3_dash_not_assumed_confirmed_by_this_probe=True,source_Q_ticks_used_for_transition=ticks,table_H_not_used_for_source_trace=True,
        method_limits='Đọc tích phân màu loại xám của lưới/chữ; JPEG gây nhiễu nên lưu profile nguyên và cột yếu. Khoảng chập nét chữ không đủ chứng minh vị trí chuyển chính xác; ảnh thật phải đọc chéo trước khóa. Mốc bảng không dùng chỉnh pha.')
    results.append(result);print(model,'trace',xy[0,0],xy[-1,0],'issues',len(issues),'INTERVAL',merged,'SOLID',solid['source_first_ink_Q_by_local_axis'] if solid else None,'PLAN',planned['planned_solid_native_u'],flush=True)
height=sum(im.height+6 for im in montage);sheet=Image.new('RGB',(255,height),'white');off=0
for raw in montage:sheet.paste(raw,(0,off));off+=raw.height+6
p=root/'13 DAU NET VA NOI NGUON150dpi KHONG VE MOI.png'
if p.exists():assert np.array_equal(np.asarray(Image.open(p)),np.asarray(sheet)),p
else:sheet.save(fresh(p))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(src)==plan['source_sha256'] and sha(current)==plan['current_sha256']
Path(fresh(root/'13 NHIP DUT LIEN DOC NGUON CHI KIEM.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(src),current_sha256=sha(current),every_image_from_original_X7=True,source_pixel_step_pt=step,
    automatic_integral_profile_method_rejected=True,rejection_reason='Một số profile tích phân nhiễu JPEG đã ghép qua nhiều khe đứt thật nhìn rõ trong nguồn (như /4 từu208). Không dùng trường transition_candidate để khóa nét hoặc vẽ. Giữ ảnh nguyên và trace để đọc chéo bằng mask vị trí.',
    source_exact_transition_not_accepted_before_visual_review=True,source_color_profile_math_only_not_new_paths=True,curves=results,new_PDF_font_or_chart_sample_written=False,common_progress_written=False),ensure_ascii=False,indent=2,default=lambda z:int(z) if isinstance(z,np.integer) else float(z) if isinstance(z,np.floating) else z.tolist()),encoding='utf8');E.close()
