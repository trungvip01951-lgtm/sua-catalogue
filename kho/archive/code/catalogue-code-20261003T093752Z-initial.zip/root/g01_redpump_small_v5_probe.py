"""Read Redpump RAM labels/source positions only; no images/PDF/g18 mutations."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.ndimage import label,binary_fill_holes
from g04_source_glyph_source_edge_math import sample_path
M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/'CHU NHO BIEN NGUON KHONG EP MUC RAM V5'
J=lambda p:json.loads(p.read_text(encoding='utf8'))
A=J(F/'RENDER ACTUAL RAM/13 NHAN MOT MAU VA3LOI ACTUAL RAM.json')
G=J(F/'12 GLYPH NHO BIEN MOT MAU RAM V2.json')
B=J(P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json')
source5=J(M/'CHU5 NGUON P8 DOI CHIEU LAN1/NGUON5 DOI CHIEU TU CHINH FILE.json')
words=J(P/'CHU NGUON ALPHA THU DO DOC V2.json')
source_clean=J(M/'CHU5 SACH NGUON P8 VA2 KY TU CUNG KIEU LAN1/5 CUNG KIEU2 KY TU NGUON VA CO.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for key,hashkey in [('source','source_SHA256'),('current','current_SHA256'),('M1','M1_SHA256')]:assert sha(A[key])==A[hashkey]
print('GUARDS',[(key,A[key],sha(A[key])) for key in ['source','current','M1']],flush=True)
print('GEOMETRY_SHA',sha(F/'12 GLYPH NHO BIEN MOT MAU RAM V2.json'),'ACTUAL_SHA',sha(F/'RENDER ACTUAL RAM/13 NHAN MOT MAU VA3LOI ACTUAL RAM.json'),flush=True)
print('SOURCE5',[(r['model'],r['source_page_box']) for r in source5['records']],flush=True)
print('SOURCEWORDKEYS',list(words['records'][0]),'SOURCERECT',words['source_rect'],flush=True)
print('SOURCEWORDS',[(r['model'],r.get('source_render_rect')) for r in words['records']],flush=True)
print('CLEAN_SOURCE5',[(r['character'],r['source_page_box'],r['candidate_ink_size_pt'],r['ink_size_difference_pt'],r['topology']) for r in source_clean['records']],flush=True)
vv={r['character']:r for r in G['records']}
for ch in ['5','9','4','S','8']:
 r=vv[ch];a=np.array(r['source_alpha']);dd=[]
 for t in [.085,.15,.25,.5]:
  z=a>=t;_,n=label(z);_,h=label(binary_fill_holes(z)&~z);ys,xs=np.nonzero(z)
  dd.append({'threshold':t,'components':int(n),'holes':int(h),'bbox600':[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]})
 print('GLYPH',ch,'source',r['source_page'],r['source_word'],r['source_page_box'],'alphaShape',a.shape,'sourceTopo',dd,'partRecipe',[(p['kind'],p['coverage_threshold'],p.get('close_px600'),p['topology'],p.get('bbox_error_px600'),p.get('counter_centroid_error_px600')) for p in r['parts']],'mass_delta',r['vector_optical_area_px']/r['source_area_px']-1,flush=True)
for r in A['placements']:
 chars=[]
 for g in r['chars']:
  if g['character'] not in '59':continue
  v=vv[g['character']];p=np.concatenate([sample_path(q['path'],count=96) for part in v['parts'] for q in part['loops']]);x,y=g['page_origin'];pts=np.column_stack([x+p[:,0]*.12,y-p[:,1]*.12])
  chars.append({'ch':g['character'],'native_page_bbox':[float(pts[:,0].min()),float(pts[:,1].min()),float(pts[:,0].max()),float(pts[:,1].max())],'donor_page':g['source_page'],'donor_word':g['source_word'],'donor_page_box':g['source_page_box']})
 metrics=[]
 for mm in A['actual_RAM_metrics']:
  if mm['model']!=r['model'] or mm['dpi'] not in [150,600,2400]:continue
  d={k:v for k,v in mm.items() if k not in ['old_RGB','new_RGB']}
  if mm['dpi']==600:
   for tag in ['old','new']:
    rgb=np.array(mm[tag+'_RGB']);gray=rgb.mean(2);ink=gray<224;yy,xx=np.nonzero(ink)
    d[tag+'_actual_bbox_graylt224']=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)];d[tag+'_RGB_min']=rgb.min((0,1)).tolist()
  metrics.append(d)
 print('MODEL',r['model'],'clip',r['physical_box'],'chars59',json.dumps(chars,ensure_ascii=False),'metrics',json.dumps(metrics,ensure_ascii=False),flush=True)
for p in A['images']:print('IMAGE',p,'SHA',sha(p),flush=True)
