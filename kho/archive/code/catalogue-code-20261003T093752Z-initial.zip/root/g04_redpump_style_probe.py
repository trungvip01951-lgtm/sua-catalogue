from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np
from scipy.ndimage import binary_dilation,binary_closing,binary_opening
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.charts import Chart
from PIL import Image,ImageDraw
root=Path(S.report('G04/REDPUMP DOC NGUON RIENG'));proof=json.loads((root/'BANG VA HAI DUONG NGUON.json').read_text(encoding='utf8'))
E=Editor(proof['source'],backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));ar=cv.orig;g=ar.astype(float)@np.array([.299,.587,.114]);height,width=g.shape;C=Chart(*proof['axis']);Q=np.array(proof['tables'][0]['Q'],float)
u0=int(round(cv.to_px(*C.to_page(0,0))[0]));ue=int(round(cv.to_px(*C.to_page(21.6,0))[0]));us=np.arange(u0,ue+1);qq=np.array([(cv.to_page(int(u),0)[0]-C.bx)/C.ax for u in us])
a=ar.astype(int);coloured=(a[:,:,1]-a[:,:,0]>8)&(a[:,:,2]-a[:,:,0]>10)&(a[:,:,0]<235);black=(g<140)&((a.max(2)-a.min(2))<10);protect=binary_dilation(black,iterations=2)
rowsout=[];images=[]
for table in proof['tables']:
 heads=np.array(table['H'],float);guide=np.polyval(np.polyfit(Q,heads,3),qq)+2;vp=np.array([cv.to_px(*C.to_page(float(q),float(h)))[1] for q,h in zip(qq,guide)]);raw=[]
 for u,v in zip(us,vp):
  rows=np.arange(max(0,int(v)-9),min(height,int(v)+10));good=rows[coloured[rows,u]&~protect[rows,u]]
  if not len(good):raw.append(np.nan);continue
  groups=np.split(good,np.where(np.diff(good)>1)[0]+1);centers=[float(np.average(z,weights=255-g[z,u])) for z in groups];raw.append(min(centers,key=lambda z:abs(z-v)))
 raw=np.array(raw);ok=np.isfinite(raw);keep=ok.copy()
 for _ in range(4):fit=np.polyval(np.polyfit(qq[keep],raw[keep],4),qq);keep=ok&(abs(raw-fit)<1.5)
 tube=np.zeros((height,width),bool)
 for u,v in zip(us,fit):tube[max(0,int(round(v))-4):min(height,int(round(v))+5),u]=True
 eligible=tube&coloured&~protect;xg=np.zeros(width,bool)
 for u,q in zip(us,qq):
  if 8<q<17:xg[u]=True
 pix=ar[eligible&xg[None,:]].astype(float);lum=pix@np.array([.299,.587,.114]);ink=np.median(pix[lum<=np.percentile(lum,20)],axis=0)
 alpha=np.clip((255-ar.astype(float))@(255-ink)/np.sum((255-ink)**2),0,1);nwidth=[];profiles=[]
 for idx,(u,q) in enumerate(zip(us,qq)):
  if not 8<q<17:continue
  v=int(round(fit[idx]));rows=np.arange(v-4,v+5);slope=float(np.gradient(fit)[idx]);nwidth.append(float((alpha[rows,u]*coloured[rows,u]).sum()/np.sqrt(1+slope*slope)))
  profiles.append(dict(Q=float(q),v=float(fit[idx]),RGB=ar[rows,u].tolist(),alpha=alpha[rows,u].tolist(),lum=g[rows,u].tolist()))
 variants=[]
 for threshold in [180,195,205,215]:
  # The curve is grey/cyan in JPEG, so some true dark cores have no chroma.
  # Neutral thin grid is lighter than205; labels start past the dashed region.
  on=np.array([bool((tube[:,u]&(g[:,u]<threshold)).any()) for u in us]);on=binary_opening(binary_closing(on,structure=np.ones(3)),structure=np.ones(3));on[:3]=True
  intervals=[];run=None
  for idx,(q,present) in enumerate(zip(qq,on)):
   if q>6:break
   if present and run is None:run=0. if idx==0 else max(0.,float(q))
   if not present and run is not None:
    end=float(qq[idx-1]);
    if end>run:intervals.append([run,end])
    run=None
  if run is not None:intervals.append([run,6.])
  variants.append(dict(lum_threshold=threshold,dash_Q_intervals=intervals))
 native=np.stack([ar[int(round(v))-6:int(round(v))+7,u] for u,v in zip(us,fit)],axis=1);im=Image.fromarray(native).resize((native.shape[1]*4,native.shape[0]*12),resample=Image.Resampling.NEAREST);images.append(im)
 rowsout.append(dict(model=table['model'],coreRGB=ink.tolist(),native_width_px=float(np.median(nwidth)),native_width_pt=float(np.median(nwidth))*.4801362852214,dashes=variants,profiles=profiles))
canvas=Image.new('RGB',(max(im.width for im in images),sum(im.height for im in images)+20),'white');y=0
for im in images:canvas.paste(im,(0,y));y+=im.height+20
canvas.save(fresh(root/'MU CUA HAI NET THANG XAM.png'))
Path(fresh(root/'PHAN TICH NET THANG XAM.json')).write_text(json.dumps(rowsout,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps([{k:v for k,v in z.items() if k!='profiles'} for z in rowsout]),flush=True);E.close()
