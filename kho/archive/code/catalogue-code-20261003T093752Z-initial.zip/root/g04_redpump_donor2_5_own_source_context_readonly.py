"""Own-source alternate small donors2/5 plus four common characters, no bank change."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
F=M/'DONOR2 5 NGUYEN CUNG TU P8 P4 LAN4';assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
E=Editor(b['source'],backend='fitz');R=Raster(E)
defs=[dict(page=4,word='4SL2/52',request=[537,456,565,474],
           glyphs={'4':[29,62,53,98],'S':[53,62,81,98],'L':[85,62,109,98],'/':[133,62,145,98],'5':[145,62,169,98]}),
      dict(page=8,word='4SL16/20',request=[132,457.64,164.04,463.40],
           glyphs={'4':[20,7,44,43],'S':[44,7,76,43],'L':[76,7,104,43],'/':[144,7,160,43],'2':[156,7,180,43]}),
      dict(page=8,word='4SL16/25',request=[132,491.72,164.04,497.00],
           glyphs={'4':[20,3,44,39],'S':[44,3,76,39],'L':[76,3,104,39],'/':[144,3,156,39],'2':[152,3,178,39],'5':[178,4,204,41]})]
records=[];source_cells={}
for d in defs:
    cv=R.render_canvas(d['page']-1,d['request'],dpi=600);whole=Image.fromarray(cv.orig)
    full=Path(fresh(F/(d['word'].replace('/','_')+' NGUYEN CUM NGUON600.png')));whole.save(full)
    for ch,bb in d['glyphs'].items():
        raw=cv.orig[bb[1]:bb[3],bb[0]:bb[2]].copy();assert raw.shape[:2]==(bb[3]-bb[1],bb[2]-bb[0])
        page_box=[*cv.to_page(bb[0],bb[3]),*cv.to_page(bb[2],bb[1])]
        p=Path(fresh(F/(d['word'].replace('/','_')+f' CHU{ord(ch):03d} NGUYEN NGUON.png')));Image.fromarray(raw).save(p)
        gray=raw.astype(float)@np.array([.299,.587,.114]);alpha=(255-gray)/255
        yy,xx=np.where(alpha>=.085)
        bbox=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]
        records.append(dict(character=ch,source_page=d['page'],source_word=d['word'],source_page_box=page_box,
            source_canvas_request=d['request'],source_canvas_actual_rect=list(cv.rect0),source_render_box=bb,
            actual_source_RGB_cell=raw.tolist(),source_gray_by_luminance=gray.tolist(),source_alpha=alpha.tolist(),
            source_image_file=str(p),source_image_SHA256=sha(p),full_word_original_image=str(full),
            source_full_box_pt=[(bb[2]-bb[0])*.12,(bb[3]-bb[1])*.12],source_weak_bbox600=bbox,
            source_weak_ink_size_pt=[(bbox[2]-bbox[0])*.12,(bbox[3]-bbox[1])*.12],
            measured_optical_integral_px=float(alpha.sum()),
            source_neutrality_RGB_difference_max=int((raw.max(2).astype(int)-raw.min(2).astype(int)).max()),
            original_RGB_used_only_as_evidence=True,geometry_input_is_gray_luminance_not_one_channel=True,
            no_scale_no_advance_edit=True,status='NGUỒN ỨNG VIÊN; cần nhìn đúng ký tự và3–4chữ chung trước đổi bank/phông.'))
        source_cells[(d['word'],ch)]=raw
for ch in ['4','S','L','/','2','5']:
    selected=[r for r in records if r['character']==ch]
    sheet=Image.new('RGB',(1500,700),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(16)
    dr.text((5,5),f'{ch} – nguyên nguồn nhỏ cùng Redpump, không co/đổi màu/pixel; chưa bank/PDF',fill='blue',font=ft)
    for i,r in enumerate(selected):
        im=Image.fromarray(source_cells[(r['source_word'],ch)]);x=20+i*480
        dr.text((x,35),r['source_word']+' p'+str(r['source_page']),fill='blue',font=ft)
        sheet.paste(im.resize((im.width*10,im.height*10),Image.Resampling.NEAREST),(x,65))
        dr.text((x,470),'Hộp thật '+str(r['source_full_box_pt'])+'pt\nMực yếu '+str(r['source_weak_ink_size_pt'])+'pt\nKhông suy fontPASS từ bbox',fill='blue',font=ft)
    sheet.save(fresh(F/(f'CHU{ord(ch):03d} NGUYEN NGUON CUNG TU DOI CHIEU.png')))
E.close();assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
fp=Path(fresh(F/'NGUON2 5 VA4 KY TU CHUNG P4 P8 NGUYEN CUM KHONG DOI BANK.json'))
fp.write_text(json.dumps(dict(source=b['source'],source_SHA256=guards[0],current_SHA256=guards[1],M1_SHA256=guards[2],records=records,
    common_characters_observed=['4','S','L','/'],source_native_pixel_pt=.4801362852213916,
    other_font_source_used=False,bank_changed=False,PDF_written=False,M2_written=False,shared_progress_written=False,
    status='Chỉ đọc nguyên mực nguồn khác cùngfile; cần soi dáng/cỡ/đậm và chữ cạnh trước dùng. Không cấpPASS tự động từ dữ liệu mực.'),ensure_ascii=False,indent=2),encoding='utf8')
print('SOURCE BOXES',[(r['source_word'],r['character'],r['source_weak_ink_size_pt']) for r in records],flush=True)
print(str(fp),'SHA256',sha(fp),flush=True)
