"""Đo độc lập toàn bộ PDF mẫu G05; chỉ đọc PDF và ghi hồ sơ mới.
Giữ độ phân giải nguồn150dpi cho sai số, không biến UNKNOWN thành PASS.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES as ORIGINAL_TABLES
from catfix import verify
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,csv,hashlib,copy
from scipy.ndimage import gaussian_filter
from scipy.signal import find_peaks

P='G05/KIEM TOAN TOAN BO/'
O='G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO/'
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
trial=S.report('G05/MAU PDF SUA DUONG/'+name)
source=S.src(name);primary=S.dst(name)
expected_primary='10d7d99e2873693fa3913b95185422a038d761903193bd544937b1dce45c8c0c'
expected_source='e1b94dc6f23c35d18d61cee71d9d88c844b1070d14ff662bbabe2256cdd690c9'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(primary)==expected_primary and sha(source)==expected_source
bs=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
actual=json.loads(Path(S.report('G05/MAU PDF SUA DUONG/DOC LAI DUONG THAT VA BAO TOAN.json')).read_text(encoding='utf8'))
assert actual['trial_sha256']==sha(trial)
newpoints={(p['model'],p['Q']):p for p in actual['points']}
TABLES=copy.deepcopy(ORIGINAL_TABLES)
TABLES['6SP36']['rows'][19].update(suffix='28',curve_model='6SP36-28',table_models=['6SP36-28'],identity_uncertain=False,identity_reason='Đã sửa chỉ chữ26→28, nhận dạng duy nhất10/10mốc nguồn và nhãn28; toàn bộ số giữ nguyên.')
TABLES['6SP30']['rows'][6].update(identity_uncertain=True,actual_source_label='6SP30-9',identity_reason='Nét nguồn ghi6SP30-9; bảng ghi6SP30-8; không đủ8/8mốc để chốt cùngmodel. Giữ nét/nhãn nguồn.')
data_corrections=[dict(family='6SP30',model='6SP30-38',Q=0,old_manual_H=432,correct_H=433,action='Chỉ sửa dữ liệu kiểm toán đọc bằng mắt; bảngPDFgốc không đổi.',evidence='BANG DAY DU/6SP30.png hàngápchót, cộtQ0 đọc433; ROOTđọcđộclập cũng433.')]
source_table_rect=next(b['rect'] for b in json.loads(Path(S.report(P+'BANG DAY DU.json')).read_text(encoding='utf8')) if b['family']=='6SP30')
proof=verify.crop(source,4,source_table_rect,600)
proof.save(fresh(S.report(O+'BANG NGUON 6SP30 - H0 433.png')))
Path(fresh(S.report(O+'DINH CHINH DU LIEU KIEM TOAN.json'))).write_text(json.dumps(data_corrections,ensure_ascii=False,indent=2),encoding='utf8')

def intr(a,b,v):return float(np.interp(v,a,b))
def status(dev,un,lim):return 'ĐẠT' if dev+un<=lim else ('CHƯA ĐẠT' if dev-un>lim else 'CHƯA THỂ')
points=[];summary=[];curve_records=[]
for b in bs:
 f=b['family'];t=TABLES[f];n=len(t['rows']);r=b['rect'];s=72/b['dpi']
 im=verify.crop(trial,b['page']-1,r,b['dpi']).convert('RGB')
 im.save(fresh(S.report(O+'ANH PDF THAT/'+f+'.png')))
 g=np.array(im.convert('L'),float);xt=np.array(b['xticks']);yt=np.array(b['yticks'])
 xp=lambda q:(intr(xt[:,0],xt[:,1],q)-r[0])/s
 yp=lambda h:(r[3]-intr(yt[:,0],yt[:,1],h))/s
 hd=lambda y:intr(yt[:,1],yt[:,0],r[3]-y*s)
 l=round(xp(0));right=round(xp(b['Qmax']));top=round(yp(b['Hmax']));bot=round(yp(0));ink=255-g
 full=np.zeros_like(g);full[top+8:bot-8,:]=ink[top+8:bot-8,:]
 title_x=int(l+.78*(right-l));title_y=int(yp(b['Hmax']*.85));full[top:title_y,title_x:right+3]=0
 full=gaussian_filter(full,(.5,.5));draw=ImageDraw.Draw(im);profiles=[];family_points=[]
 for iq,q in enumerate(t['Q']):
  x=xp(q);sets=[];counts=[]
  offsets=list(range(-32,33,4))
  if q==0:offsets=list(range(8,33,3))
  if iq==len(t['Q'])-1:offsets=list(range(-32,1,3))
  for dx in offsets:
   xx=round(x+dx);v=np.mean(full[:,xx-1:xx+2],axis=1)
   pk,_=find_peaks(v,prominence=20,height=70,distance=7);pk=pk[(pk>top+10)&(pk<bot-8)]
   counts.append((dx,len(pk)))
   if len(pk)==n:
    cy=[]
    for p in pk[::-1]:
     ids=np.arange(p-2,p+3);w=np.maximum(0,v[ids]-np.min(v[ids]));cy.append(float(np.sum(ids*w)/sum(w)) if sum(w)>0 else float(p))
    sets.append((float(xx),np.array(cy)))
  profiles.append(dict(Q=q,candidates=counts,exact_slices=len(sets)))
  for k,row in enumerate(t['rows']):
   h=row['H'][iq];assert h is not None
   p=dict(page=b['page'],family=f,row=k+1,source_label=row.get('actual_source_label',row['curve_model']),curve_model=row['curve_model'],table_models=' | '.join(row['table_models']),Q_m3h=q,H_table_m=h,identity_uncertain=row.get('identity_uncertain',False) or t['plot_family']!=f,slices=len(sets),actual_vector=False)
   p.update(H_curve_m=None,nominal_status='CHƯA THỂ',confidence_status='CHƯA THỂ',reason='Không đủ ba lát cắt nhận đủ đường độc lập',measurement_method='Lát sắc độ từ ảnh của chínhPDFmẫu, thứ tự nét nguồn độc lập vớiH bảng.')
   if len(sets)>=3:
    xx=np.array([v[0] for v in sets]);yy=np.array([v[1][k] for v in sets]);cf=np.polyfit(xx,yy,1);res=np.abs(yy-np.polyval(cf,xx));cy=float(np.polyval(cf,x));hc=hd(cy);spread=float(max(res));extrap=max(min(xx)-x,x-max(xx),0)*s
    p.update(local_spread_px=round(spread,5),slope=float(cf[0]),extrap_pt=round(extrap,5))
    if spread>3.5 or abs(cf[0])>1.9 or extrap>1.8:
     p['reason']='Lát cắt không giữ cùng nét ổn định hoặc cách biên quá xa'
    else:
     yerr_pt=.24+max(.24,s*spread)+.06+abs(cf[0])*.30
     if extrap>0:yerr_pt+=extrap*max(abs(cf[0]),.02)*.15
     un=max(abs(hd(cy+yerr_pt/s)-hc),abs(hd(cy-yerr_pt/s)-hc));dev=abs(hc-h);lim=max(1,.02*h)
     p.update(H_curve_m=round(hc,5),deviation_m=round(dev,5),limit_m=lim,uncertainty_m=round(un,5),uncertainty_position_pt=round(yerr_pt,5),nominal_status='ĐẠT' if dev<=lim else 'CHƯA ĐẠT',confidence_status=status(dev,un,lim),x_px=round(x,4),y_px=round(cy,4),sample_locations=[dict(x_px=v[0],y_px=float(v[1][k])) for v in sets],reason='')
     if p['confidence_status']=='CHƯA THỂ':p['reason']='Biên sai số ảnh150dpi chạm ngưỡng cho phép.'
   vp=newpoints.get((row['curve_model'],q))
   if vp is not None:
    assert not p['identity_uncertain']
    # Lưu phép đọc ảnh thô độc lập trước khi dùngpath thật. Mốc trênpath mới là chínhxác
    # so với trục đãhiệuchuẩn; vẫn tính sai số vị trí trục ảnhgốc .24pt/Y+.24pt/X.
    p['raster_measurement']={z:p.get(z) for z in ['H_curve_m','deviation_m','confidence_status','reason','local_spread_px','slope','extrap_pt','x_px','y_px']}
    hc=vp['H_actual_PDF'];dev=abs(hc-h);cy=yp(hc);sl=abs(p.get('slope',0.))
    yerr_pt=.24+.24*sl
    un=max(abs(hd(cy+yerr_pt/s)-hc),abs(hd(cy-yerr_pt/s)-hc));lim=max(1,.02*h)
    p.update(actual_vector=True,actual_object_index=vp['object_index'],H_curve_m=hc,deviation_m=dev,limit_m=lim,uncertainty_m=un,uncertainty_position_pt=yerr_pt,nominal_status='ĐẠT' if dev<=lim else 'CHƯA ĐẠT',confidence_status=status(dev,un,lim),x_px=x,y_px=cy,reason='',measurement_method='ĐọcpathBézier thật củaPDFmẫu, toạđộtrục ảnhgốc; sai số trục.24pt theo150dpi. Phépđọc ảnhthô giữ riêng.')
    if p['confidence_status']=='CHƯA THỂ':p['reason']='Path mới chínhxác theo trụchiệuchuẩn, nhưng biên sai sốtrụcảnh150dpi chạmngưỡng.'
   p['verification_status']=p['confidence_status'] if not p['identity_uncertain'] else 'CHƯA THỂ'
   if p['identity_uncertain']:p['identity_reason']=row.get('identity_reason','Tên họtrongbảng vàđồthị khác nhau4SP14/4SP15.')
   x=xp(q);y=yp(h);draw.line((x-5,y,x+5,y),fill=(170,0,240),width=2);draw.line((x,y-5,x,y+5),fill=(170,0,240),width=2)
   if p['H_curve_m'] is not None:
    cy=yp(p['H_curve_m']);color=(0,130,20) if p['verification_status']=='ĐẠT' else ((235,10,10) if p['verification_status']=='CHƯA ĐẠT' else (230,150,0));draw.ellipse((x-4,cy-4,x+4,cy+4),outline=color,width=2)
   points.append(p);family_points.append(p)
 ss=['ĐẠT','CHƯA ĐẠT','CHƯA THỂ'];cc=[]
 for k,row in enumerate(t['rows']):
  rr=[p for p in family_points if p['row']==k+1];cs={v:sum(p['verification_status']==v for p in rr) for v in ss};ns={v:sum(p['confidence_status']==v for p in rr) for v in ss};st='CHƯA ĐẠT' if cs['CHƯA ĐẠT'] else ('CHƯA THỂ' if cs['CHƯA THỂ'] else 'ĐẠT')
  c=dict(family=f,page=b['page'],row=k+1,source_label=row.get('actual_source_label',row['curve_model']),curve_model=row['curve_model'],table_models=row['table_models'],points=len(rr),counts=cs,numeric_counts=ns,status=st,confirmed_failed_Q=[p['Q_m3h'] for p in rr if p['confidence_status']=='CHƯA ĐẠT'],identity_uncertain=row.get('identity_uncertain',False) or t['plot_family']!=f,Q=t['Q'],H_table=row['H'],H_curve=[p['H_curve_m'] for p in rr],actual_vector_points=sum(p['actual_vector'] for p in rr),max_deviation_m=max(p.get('deviation_m',0) for p in rr))
  cc.append(c);curve_records.append(c)
 z=dict(family=f,page=b['page'],curves=len(cc),points=len(family_points),numeric_counts={v:sum(p['confidence_status']==v for p in family_points) for v in ss},overall_counts={v:sum(p['verification_status']==v for p in family_points) for v in ss},curve_counts={v:sum(c['status']==v for c in cc) for v in ss},unmeasured=sum(p['H_curve_m'] is None for p in family_points),profiles=profiles)
 summary.append(z)
 draw.rectangle((0,0,min(1850,im.width),24),fill='white');draw.text((5,6),'Tim: moc bang. Xanh: dat. Do: sai da ro. Cam: chua the. '+f,fill='black')
 im.save(fresh(S.report(O+'NGHIEM THU/'+f+'.png')))
 print('PDF_FULL',f,z['overall_counts'],'unmeasured',z['unmeasured'],flush=True)

ss=['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']
assert len(points)==2218 and len(curve_records)==220 and sum(p['actual_vector'] for p in points)==52
out=dict(trial_path=trial,trial_sha256=sha(trial),source_path=source,source_sha256=sha(source),primary_path=primary,primary_unchanged_sha256=sha(primary),panel_count=len(summary),curve_count=len(curve_records),point_count=len(points),actual_vector_point_count=52,numeric_counts={v:sum(p['confidence_status']==v for p in points) for v in ss},overall_counts={v:sum(p['verification_status']==v for p in points) for v in ss},actual_vector_nominal_counts={v:sum(p['actual_vector'] and p['nominal_status']==v for p in points) for v in ss},actual_vector_confidence_counts={v:sum(p['actual_vector'] and p['confidence_status']==v for p in points) for v in ss},unmeasured=sum(p['H_curve_m'] is None for p in points),method='Đo từ15ảnh củaPDFmẫu thật, ranknhãnnguồn; giữsai số150dpi;52mốcvector đọcpaththật. Không dựng điểmtrống hoặc tìmnéttheoH bảng.',summary=summary,curves=curve_records,points=points,group_status='CHƯA XONG',identity_unknown=['4SP14 /4SP15 toàn110mốc','Bảng6SP30-8 /nguồnnét6SP30-9 toàn8mốc'],unchanged_native_low_confidence=True,data_corrections=data_corrections)
Path(fresh(S.report(O+'NGHIEM THU QH PDF MAU.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(S.report(O+'NGHIEM THU QH PDF MAU.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 fields=list(dict.fromkeys(k for p in points for k in p if k not in ['sample_locations','raster_measurement']));w=csv.DictWriter(fp,fields,extrasaction='ignore');w.writeheader();w.writerows(points)
with open(fresh(S.report(O+'NGHIEM THU 220 DUONG.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,list(curve_records[0]));w.writeheader();w.writerows(curve_records)
with open(fresh(S.report(O+'MOC LECH DA RO.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 fields=['page','family','curve_model','source_label','row','Q_m3h','H_table_m','H_curve_m','deviation_m','limit_m','uncertainty_m','verification_status','identity_uncertain'];w=csv.DictWriter(fp,fields,extrasaction='ignore');w.writeheader();w.writerows(p for p in points if p['confidence_status']=='CHƯA ĐẠT')
assert sha(primary)==expected_primary and sha(source)==expected_source
print('FULL_TOTAL',len(curve_records),len(points),'NUMERIC',out['numeric_counts'],'OVERALL',out['overall_counts'],'NEW_NOMINAL',out['actual_vector_nominal_counts'],'NEW_CONFIDENCE',out['actual_vector_confidence_counts'],flush=True)
print('FAILED',[(c['curve_model'],c['confirmed_failed_Q']) for c in curve_records if c['confirmed_failed_Q']],flush=True)
