from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib
import fitz
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_PDF M1 V5 DOC LAP DU8 TRANG'))
PDF=Path(S.dst('Catalog cắt rác redpump (bản mới).pdf'));h=sha(PDF);out=[]
for page in [1,4,6]:
 with fitz.open(str(PDF)) as doc:
  infos=doc[page-1].get_image_info(xrefs=True)
  candidates=[i for i in infos if (i['bbox'][2]-i['bbox'][0])*(i['bbox'][3]-i['bbox'][1])>10000]
  assert candidates
  info=max(candidates,key=lambda i:(i['bbox'][2]-i['bbox'][0])*(i['bbox'][3]-i['bbox'][1]))
  for kind,rect in [('whole',None),('photo',fitz.Rect(info['bbox']))]:
   pix=doc[page-1].get_pixmap(dpi=150,clip=rect,colorspace=fitz.csRGB,alpha=False)
   fp=Path(fresh(O/f'g01_RED WC HIEN HANH p{page:02d} {kind} 150dpi SO ANH.png'));pix.save(str(fp))
   out.append({'page':page,'kind':kind,'PNG':str(fp),'PNG_SHA':sha(fp),'rect':list(rect) if rect else None,'image_xref':info['xref'],'width':info['width'],'height':info['height']})
assert sha(PDF)==h
data={'comparison_current_Redpump_WC_PDF':str(PDF),'SHA':h,'opened_pages':[1,4,6],'images':out,'only_plain_direct_PDF_render_no_retouch':True,'judgment':'PENDING actual image views; do not infer a different physical model merely from brand/header.'}
jp=Path(fresh(O/'g01_DOC RIENG ANH REDPUMP WC HIEN HANH DE DOI CHIEU.json'));jp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'PDF':str(PDF),'SHA':h,'JSON':str(jp),'JSON_SHA':sha(jp),'images':out},ensure_ascii=False))
