"""Single-colour own-source small-glyph paths; all three fixes only in RAM."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib,sys,numpy as np
import pymupdf as fitz
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.cs import Instr,Num,Name
from catfix import verify

root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
pr=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
fontroot=root/'CHU NHO BIEN NGUON KHONG EP MUC RAM V5';folder=fontroot/'RENDER ACTUAL RAM';assert not folder.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(root/'TAO MAU1 VA BAO VE NGUON.json');a=J(root/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')
atlas=J(pr/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json');layout=J(pr/'13 HOP NHAN CUC BO TRANH DUONG LUOI V1.json')
v=J(fontroot/'12 GLYPH NHO BIEN MOT MAU RAM V2.json');holes=J(root/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json');eta=J(root/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
assert guards==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
V={z['character']:z for z in v['records']};AA={z['model']:z for z in atlas['records']};LB={z['model']:z for z in layout['records']}
E=Editor(b['sample'],backend='fitz');P=E.page(7)
tag=next(i for i,z in enumerate(P.ops) if z.op=='BMC' and list(map(str,z.operands))==['CfxRedpumpWholePage8M1'])
def I(op,*vs):return Instr([Num(float(x)) for x in vs],op)
def re(bb):return I('re',bb[0],bb[1],bb[2]-bb[0],bb[3]-bb[1])
removed=[]
for r in b['labels']:
    matches=[z['i'] for z in P.images if z['i']>tag and z['name']==r['image_name']];assert len(matches)==1
    E.delete_instrs(7,matches);removed.append(dict(model=r['model'],image=r['image_name'],Do_index=matches[0]))
for r in holes['records']:
    bb=r['proposed_effective_hole_after']
    for idx in r['changed_rect_instruction_indices']:E.modify_instr(7,idx,re(bb))
ec=next(z for z in eta['RAM_rendered_candidates'] if z['pieces']==2);eo=P.objs[a['eta_actual']['actual_object']]
E.delete_instrs(7,range(eo['i0'],eo['i1']))
E.insert_instrs(7,eo['i1'],[Instr([Num(float(val)) for xy in pts for val in xy],op) for op,pts in ec['actual_RAM_path']],before=True)

ins=[Instr([Name('CfxRedpumpSmallSourceGlyphSingleCoreRAM2')],'BMC'),Instr([],'q')];placements=[]
for r in b['labels']:
    name=r['model'];lb=LB[name];word=AA[name];origin=lb['source_word_array_page_origin'];bb=lb['physical_box']
    ins += [Instr([],'q'),re(bb),Instr([],'W'),Instr([],'n'),I('g',v['core_gray']/255)]
    chars=[]
    for g in word['glyphs']:
        ch=g['character'];vv=V[ch];dx,dy=g['assembled_offset600'];ox=origin[0]+dx*.12;oy=origin[1]-dy*.12
        for part in vv['parts']:
            for loop in part['loops']:
                for op,ps in loop['path']:
                    ins.append(Instr([Num(float(val)) for x,y in ps for val in [ox+x*.12,oy-y*.12]],op))
            ins.append(Instr([],'f*'))
        chars.append(dict(character=ch,source_page=g['source_page'],source_word=g['source_word'],source_page_box=g['source_page_box'],
            word_offset600=[dx,dy],page_origin=[ox,oy],physical_scale=1.,topology=vv['expected_topology']))
    ins += [Instr([],'Q')]
    placements.append(dict(model=name,source_array_origin=origin,physical_box=bb,chars=chars,
        original_nominal_box_clearance_pt=lb['min_clearance_pt'],clip_to_original_word_box=True))
ins += [Instr([],'Q'),Instr([],'EMC')]
E.insert_instrs(7,len(P.ops),ins,before=True);E.doc.set_page_content(7,E.build(7));E.pages.clear();PR=E.page(7)
qh=[]
for m in a['actual_QH_paths']:
    for part in m['parts']:
        oi=part['object_index'];path=PR.object_pagepath(oi)
        assert json.dumps(path,separators=(',',':'))==json.dumps(part['path'],separators=(',',':'))
        qh.append(dict(model=m['model'],actual_object=oi,path_unchanged=True,not_remeasured_104anchors=True))
assert len(qh)==26;assert not E.doc.doc[7].get_fonts(full=True)

def ramrender(bb,dpi):
    pg=E.doc.doc[7];T=pg.transformation_matrix;p0=fitz.Point(bb[0],bb[1])*T;p1=fitz.Point(bb[2],bb[3])*T
    clip=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y))
    pix=pg.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=clip,colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[:,:,:3].copy()

metrics=[];imgs=[]
for dpi in [150,600,2400]:
    if dpi in [150,600]:
        p=fresh(folder/f'TOAN3LOI RAM MOT MAU {dpi}dpi KHONG PDF2.png')
        Image.fromarray(ramrender([53,267,364,511],dpi)).save(p);imgs.append(p)
    rowh=180 if dpi==600 else 90
    sheet=Image.new('RGB',(2200,13*rowh+80),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(16)
    for k,r in enumerate(placements):
        bb=r['physical_box'];rect=[bb[0]-.24,bb[1]-.24,bb[2]+.24,bb[3]+.24]
        old=np.asarray(verify.crop(b['sample'],7,rect,dpi));new=ramrender(rect,dpi);assert old.shape==new.shape
        oa=(255-old.astype(float).mean(2))/255;na=(255-new.astype(float).mean(2))/255
        metrics.append(dict(model=r['model'],dpi=dpi,rect=rect,source_area_pt2=float(oa.sum()*(72/dpi)**2),
            new_area_pt2=float(na.sum()*(72/dpi)**2),relative_actual_ink_error=float(na.sum()/oa.sum()-1),
            old_RGB=old.tolist() if dpi==600 else None,new_RGB=new.tolist() if dpi==600 else None))
        if dpi in [150,600]:
            p0=Image.fromarray(old);p1=Image.fromarray(new);y=k*rowh+70
            sheet.paste(p0,(210,y));sheet.paste(p1,(480,y))
            if dpi==600:
                sheet.paste(p0.resize((p0.width*3,p0.height*3),Image.Resampling.NEAREST),(770,y))
                sheet.paste(p1.resize((p1.width*3,p1.height*3),Image.Resampling.NEAREST),(1490,y))
            dr.text((5,y),r['model'],fill='blue',font=ft)
    if dpi in [150,600]:
        dr.text((5,3),'CHỈ RAM, KHÔNG PDF2: trước M1 / sau biên nguồn một màu',fill='blue',font=ft)
        dr.text((210,32),'Trước',fill='blue',font=ft);dr.text((480,32),'Sau',fill='blue',font=ft)
        if dpi==600:
            dr.text((770,32),'Trước 3x điểm ảnh',fill='blue',font=ft);dr.text((1490,32),'Sau 3x điểm ảnh',fill='blue',font=ft)
        p=fresh(folder/f'13 NHAN TRUOC SAU RAM MOT MAU {dpi}dpi KHONG PDF2.png');sheet.save(p);imgs.append(p)

out=dict(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],M1=b['sample'],M1_SHA256=guards[2],
    geometry_data=str(fontroot/'12 GLYPH NHO BIEN MOT MAU RAM V2.json'),placements=placements,actual_RAM_metrics=metrics,images=imgs,
    QH_26_actual_paths_unchanged=qh,removed_only_M1_label_Do=removed,uniform_glyph_fill_RGB=[v['core_gray']]*3,
    uniform_glyph_opacity=1.,new_external_font=False,new_SMask_used=False,new_gray_layers_used=False,
    eta_2_Bezier_C2=True,eta_numeric_status='CHƯA THỂ XÁC MINH: không bảng η',five_feet_recipe='Lỗ +0,48pt đúng hộp giao, đã RAM15crop0pixel',
    status='ỨNG VIÊN RAM: cần đọc hình thức, nét/diện tích/cỡ/biên/khoảng hở. Chưa ghi PDF2.',PDF_written=False,
    M2_written=False,canonical_written=False,shared_progress_written=False)
Path(fresh(folder/'13 NHAN MOT MAU VA3LOI ACTUAL RAM.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert guards==[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
print('RAM only; 26QH path fingerprints retained; actual2400 areaErrors',[(r['model'],round(r['relative_actual_ink_error'],4)) for r in metrics if r['dpi']==2400],flush=True)
