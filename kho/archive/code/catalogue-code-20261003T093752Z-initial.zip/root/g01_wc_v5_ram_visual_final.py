"""Independent read-only V5 RAM acceptance: existing images, source rows, new QA files only."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,math,csv,io
import numpy as np
from PIL import Image
from g01_wc_clip_math import parse,windall

O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 KIEM ANH RAM DOC LAP'))
G=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 DU LIEU HINH HOC'))
V5=G/'g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json'
RAM=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs\per_wc_continue_photo_union_v5_RAM_a1')
V4=RAM.parent/'per_wc_continue_photo_union_v4B_RAM_a1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(V5)=='8fabfa4986246865c6e0931cb4e63881326e58358aa099bfcb6ffb47a108c4fa'
d=json.loads(V5.read_text(encoding='utf8'))
actual_file=O/'g01_02_DOC PNG RAM V5 THAT VA TOA DO8 DOAN.json'
actual=json.loads(actual_file.read_text(encoding='utf8'))
holes_file=G/'g01_DOC LAI TEP V5 DA LUU - TAP CON LIEN TUC VA 12 KHE.json'
holes=json.loads(holes_file.read_text(encoding='utf8'))
count_file=G/'g01_SO DEM CHINH THUC V5 LAY TU TUNG TOA DO.json'
counts=json.loads(count_file.read_text(encoding='utf8'))
unknown_file=O/'g01_01_MEP MO NGUON DOC TRUOC KHI CO RAM V5.json'
unknown=json.loads(unknown_file.read_text(encoding='utf8'))
guards={Path(S.src('Catalog cắt rác perotac (bản mới).pdf')):d['source_PDF_sha256'],Path(S.dst('Catalog cắt rác perotac (bản mới).pdf')):d['canonical_untouched_sha256'],V5:sha(V5)}
for g in d['groups']:guards[Path(g['source_JPEG'])]=g['source_JPEG_sha256']
for p,h in guards.items():assert sha(p)==h
manifest=json.loads(Path(actual['RAM_manifest']).read_text(encoding='utf8'))
manifest_now=[]
for f in manifest['files']:
    p=RAM/f['file'];h=sha(p);sz=p.stat().st_size
    assert h==f['sha256'] and sz==f['bytes']
    manifest_now.append({'file':str(p),'SHA256':h,'bytes':sz})
assert not list(RAM.glob('*.pdf'))
assert all(q['outside8_source_change_envelopes_with2_render_pixel_pad']==0 for g in actual['actual_photos'] for q in g['V4B_vs_V5_pixels'])
assert all(q['before_photo_exact_pixels_equal'] for g in actual['actual_photos'] for q in g['V4B_vs_V5_pixels'])
water=[x for x in actual['actual_PNG_point_probes'] if x['kind']=='added_exclude_water' and x['dpi']==600 and x['winding_old']!=0]
metal=[x for x in actual['actual_PNG_point_probes'] if x['kind']=='added_keep_metal' and x['dpi']==600]
assert len(water)==counts['water_newly_excluded'] and all(not q['equal_V4B_V5'] for q in water)
assert len(metal)==counts['metal_kept_checks'] and all(q['equal_V4B_V5'] for q in metal)

def locate(folder,num,page,kind,dpi):
    p=list(folder.glob(f'*group{num}_p{page:02d}_{kind}_{dpi}dpi.png'));assert len(p)==1,p
    return p[0]
images={};transforms={};rects={};whole=[];all_images_seen=[]
for g in actual['actual_photos']:
    n=g['group'];page=g['representative_page'];transforms[n]=g['source_transform_top'];rects[n]=g['photo_crop_rect_top']
    w,h=d['groups'][n-1]['source_canvas_pixel']
    a,b,c,e,tx,ty=transforms[n]
    def wholepoint(x,y,dpi):return np.array([a*x/w+c*y/h+tx,b*x/w+e*y/h+ty])*dpi/72
    for dpi in (150,600):
        p4=locate(V4,n,page,'RAM_photo',dpi);p5=locate(RAM,n,page,'RAM_photo',dpi)
        images[n,dpi]=(np.array(Image.open(p4).convert('RGB')),np.array(Image.open(p5).convert('RGB')))
        all_images_seen.append({'group':n,'kind':'RAM_photo','dpi':dpi,'file':str(p5),'SHA256':sha(p5),'opened_directly_in_view_image':True})
    p4=locate(V4,n,page,'RAM_whole_page',150);p5=locate(RAM,n,page,'RAM_whole_page',150)
    aa=np.array(Image.open(p4).convert('RGB'));bb=np.array(Image.open(p5).convert('RGB'));assert aa.shape==bb.shape
    change=np.any(aa!=bb,axis=2);allow=np.zeros(change.shape,dtype=bool)
    for edit in d['groups'][n-1]['V5_edits']:
        x0,y0,x1,y1=edit['changed_bbox_source_pixel'];cs=[wholepoint(x,y,150) for x,y in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]]
        lo=np.floor(np.min(cs,axis=0)-2).astype(int);hi=np.ceil(np.max(cs,axis=0)+2).astype(int)
        allow[max(0,lo[1]):min(change.shape[0],hi[1]),max(0,lo[0]):min(change.shape[1],hi[0])]=True
    outside=int(np.sum(change&~allow));assert outside==0,(n,outside)
    whole.append({'group':n,'page':page,'dpi':150,'V4B_SHA256':sha(p4),'V5_SHA256':sha(p5),'size':[bb.shape[1],bb.shape[0]],'changed_pixels_threshold0':int(change.sum()),'outside8_changed_bbox_envelopes_with2_render_pixel_pad':outside,'charts_text_tables_elsewhere_identical_at150dpi':True})
    all_images_seen.append({'group':n,'kind':'RAM_whole_page','dpi':150,'file':str(p5),'SHA256':sha(p5),'opened_directly_in_view_image':True})

def pixel_read(num,point,dpi):
    w,h=d['groups'][num-1]['source_canvas_pixel'];a,b,c,e,tx,ty=transforms[num];x,y=point
    sx=dpi/72;px=(a*x/w+c*y/h+tx)*sx-math.floor(rects[num][0]*sx);py=(b*x/w+e*y/h+ty)*sx-math.floor(rects[num][1]*sx)
    xx=int(round(px-.5));yy=int(round(py-.5));aa,bb=images[num,dpi]
    assert 0<=xx<bb.shape[1] and 0<=yy<bb.shape[0]
    return {'dpi':dpi,'PNG_pixel':[xx,yy],'V4B_RGB':aa[yy,xx].tolist(),'V5_RGB':bb[yy,xx].tolist(),'pixels_exactly_equal':bool(np.array_equal(aa[yy,xx],bb[yy,xx]))}

actual_holes=[]
for q in holes['hole_interior_probes']:
    n=q['group'];point=q['verified_interior_point_source_pixel'];probes=[pixel_read(n,point,dpi) for dpi in (150,600)]
    assert all(z['pixels_exactly_equal'] for z in probes)
    actual_holes.append({'group':n,'ring':q['ring'],'source_point':point,'boundary_exactly_unchanged':q['boundary_exactly_unchanged'],'source_RGB':q['source_RGB'],'actual_RAM_samples':probes,'result':'ĐẠT: giữ vòng cắt và điểm trong ảnh; không suy số lỗ cơ khí từ số vòng.'})
assert len(actual_holes)==12
gap=d['actual_source_gap_proof_V5'];assert gap['source_row']==798 and gap['V5_visible_count']==0
pol=[parse(q) for q in d['groups'][2]['combined_clip_subpaths']]
pts=[[x+.5,gap['source_row']+.5] for x in range(*gap['x_range'])]
assert len(pts)==gap['pixel_centers_checked'] and np.all(windall(pol,pts)==0)
gap_samples=[]
for p in pts[::25]+[pts[-1]]:
    q=[pixel_read(3,p,dpi) for dpi in (150,600)];assert all(z['pixels_exactly_equal'] for z in q)
    gap_samples.append({'source_point':p,'actual_RAM_samples':q})

visual_edits={
 'G1_01':'Cục/gai nước nhô bên phải ống đôi ở V4B đã hết; biên ống giữ thẳng. Mực xanh pha ngay mép nguồn vẫn giữ.',
 'G1_02':'Các chồi nước bên trái thanh đơn đã thu; thanh kim loại vẫn liên tục, không thiếu phần thân nhìn rõ.',
 'G1_03':'Các gai nước bên phải thanh đơn đã thu; không thấy khối nước rời ở cạnh. Viền pha màu mỏng nguồn còn.',
 'G1_04':'Khối xanh bên trái quai nhỏ đã bỏ; phần quai thật x149 trở vào và khoảng sáng nguồn được giữ. Không dựng thêm lỗ.',
 'G1_05':'Khối/gai xanh ngoài ống đôi phía trái đã bỏ; bóng và cột kim loại nhìn rõ giữ đúng nguồn.',
 'G2_01':'Đốm xanh nhô vách trái được thu; đường thân nhìn liền ở 150 dpi. Mép pha màu sát vách không bị tự khoét.',
 'G3_01':'Gai nước bên trái bơm trái đã thu; mép thân không có khối xanh rời. Phần sắc xanh đã pha vào rìa nguồn vẫn giữ.',
 'G3_02':'Cụm xanh rõ bên trái/đáy động cơ phải đã thu; mối cạnh giữ đúng vị trí nguồn, không làm mất trục bên dưới.'}
edit_rows=[]
for g in d['groups']:
    for e in g['V5_edits']:
        assert e['id'] in visual_edits
        edit_rows.append({'id':e['id'],'group':g['group'],'pages':g['pages'],'source_ROI':e['source_roi'],'observation_from_actual150_600':visual_edits[e['id']],'source_conservative_limit':e['why'],'conclusion':'ĐẠT đúng phạm vi 8 đoạn; phần mờ nguồn giữ giới hạn riêng.'})
assert len(edit_rows)==8
mechanical=[
 {'group':1,'seen':'Cặp ống, thanh đơn, khuỷu/coupling (khớp nối), hai quai nhỏ, thân bơm, miệng ống và hai khe chân nhìn rõ đều còn. Khe tối/phản quang nhỏ và quai ít pixel chưa đủ để xác định mọi cấu tạo.','catalogue_150':'Bố cục gọn, khối xanh thừa V4B đã hết. JPEG 246×357 điểm ảnh vẫn mềm và có răng cưa nguồn; không yêu cầu dựng chi tiết mới.','limit':'Viền xanh/cyan/đỏ tím mỏng ở đúng mép ống, quai và chân là pha màu trong JPEG gốc; chưa thể tách mọi pixel khỏi vật liệu.'},
 {'group':2,'seen':'Quai kim loại lớn và khoảng trong, đầu cáp, thân, cụm bu-lông, miệng bơm, chân, hai chi tiết rời giữ đúng hình nhìn thấy. Bề mặt sáng/tâm xám của chi tiết rời trắng giữ nguyên.','catalogue_150':'Thân liền, hình sạch hơn V4B, không còn cục xanh vách trái. Bóng mềm phía ngoài chi tiết rời trên vốn có trong nguồn, chưa xác minh hết đó là nền hay phản quang.','limit':'Viền xanh mỏng mép phải thân và viền phía trong chân dính ngay mép ảnh nguồn, không có khoảng nền rõ để cắt chắc. Không tự xóa theo màu.'},
 {'group':3,'seen':'Hai quai dây, hai phần thân/động cơ, đầu trục, chi tiết rời giữa, phần vỏ/đế rời, bích/miệng bơm và bốn khe chân nhìn rõ giữ. Khe y798 giữa hai phần rời có thật và còn mở.','catalogue_150':'Các cụm rõ, không còn khối xanh ở vách trái hay dưới động cơ phải. Không thấy nét nối giả giữa các cụm rời. Chữ H mép phải ảnh cắt thuộc trục biểu đồ của trang, không phải chữ phát sinh trong JPEG.','limit':'Viền xanh trên nắp/miệng vỏ rời, viền chân, rìa hai thân đã nằm sát vật liệu trong JPEG gốc. Quai dây sáng/mờ giữ nguồn, chưa thể xác định mọi pixel là kim loại hay nền.'}]
residual_specs=[
 (1,'Méps ống đôi và thanh đơn, xanh/cyan pha trên rìa',[46,175,113,247],[[54,228],[76,228],[99,188],[107,214]]),
 (1,'Quai nhỏ cạnh phần đã thu; phía trong mờ',[149,162,160,176],[[149,166],[150,168],[155,166]]),
 (2,'Viền xanh sát mép phải thân',[688,440,698,482],[[690,455],[693,455],[695,455]]),
 (2,'Viền phía trong hai chân, xen mép vật liệu',[406,1230,635,1365],[[440,1295],[547,1310],[550,1310]]),
 (3,'Viền nắp/miệng vỏ rời đã pha màu',[616,801,774,830],[[646,806],[675,806],[754,817]]),
 (3,'Rìa thân phải giáp sóng nước nguồn',[778,370,792,490],[[779,400],[783,400],[787,400]])]
residual=[]
for n,title,roi,points in residual_specs:
    im=np.array(Image.open(d['groups'][n-1]['source_JPEG']).convert('RGB'));ps=[]
    pp=[parse(q) for q in d['groups'][n-1]['combined_clip_subpaths']]
    for x,y in points:
        samples=[]
        for yy in range(y-1,y+2):
            for xx in range(x-1,x+2):samples.append({'source_pixel':[xx,yy],'RGB':im[yy,xx].tolist()})
        ps.append({'source_pixel':[x,y],'RGB_source':im[y,x].tolist(),'neighbors3x3':samples,'V5_clip_winding_at_pixel_center':int(windall(pp,[[x+.5,y+.5]])[0]),'actual_RAM150_600':[pixel_read(n,[x+.5,y+.5],dpi) for dpi in (150,600)]})
    residual.append({'group':n,'title':title,'source_ROI_halfopen':roi,'probes':ps,'automatic_color_classification':False,'separation_of_every_pixel':'CHƯA THỂ XÁC MINH: ở sát rìa vật liệu pha màu trong nguồn, không có chứng cứ để cắt thêm. Không có sửa hình học/RGB trong phiếu này.'})

for p,h in guards.items():assert sha(p)==h
result={
 'scope':'Đọc độc lập ảnh RAM V5 đã khóa; 3 nhóm, 8 đoạn; không ghi PDF/ảnh RGB/dữ liệu clip/TIEN DO.',
 'V5_geometry_path':str(V5),'V5_geometry_SHA256':sha(V5),
 'RAM_lock_reported_by_ROOT_SHA256':'0221e7b270bf6d406f600d070ecc1e24dd4ff8b65ef473e1602dd000d20f6b34',
 'RAM_manifest_file':actual['RAM_manifest'],'RAM_manifest_SHA256':sha(actual['RAM_manifest']),
 'all_manifest_files_read_now':manifest_now,'images_directly_opened_for_visual_qa':all_images_seen,
 'actual_photo_pixel_QA_file':str(actual_file),'actual_photo_pixel_QA_SHA256':sha(actual_file),
 'whole_page150_actual_pixel_readback':whole,'all8_edits_visual_actual':edit_rows,
 'actual_new_water600_confirmed':len(water),'actual_retained_metal600_exactly_equal':len(metal),
 'geometry_counts_read_from_file':counts,'actual12_hole_interior_samples':actual_holes,
 'actual_source_gap_y798':{'geometry_source_centers_read':len(pts),'source_x_range':gap['x_range'],'all_geometry_windings_zero':True,'actual_RAM_samples':gap_samples,'visual_gap_seen_at150_and600':True},
 'mechanical_and_catalogue_size_visual_read':mechanical,
 'source_ambiguous_regions_prior':{'file':str(unknown_file),'SHA256':sha(unknown_file),'regions':len(unknown['source_regions_read']),'all_ROI_pixel_centers_geometry_unchanged':all(q['V4B_V5_geometry_differences_in_ROI_at_pixel_centers']==0 for q in unknown['source_regions_read'])},
 'residual_source_edge_pixels_read':residual,
 'native_RAM_PDF_byte_acceptance':'CHƯA CHẠY: PDF còn trong bộ nhớ của tác nhân ghi, chưa có tệp PDF để em đọc byte độc lập. Báo cáo native của tác nhân không được tính là em đã đọc PDF.',
 'overall_scoped_visual_conclusion':'ĐẠT phạm vi 8 đoạn đã chốt và trình bày ảnh V5 ở kích thước catalogue: mảng xanh ngoài cấu tạo nhìn rõ đã thu; không thấy phần kim loại nhìn rõ bị cắt mất hay khối nước rời cần cắt thêm. Viền nguồn pha màu/mép mờ có giới hạn chưa thể tách chắc; không tuyên bố toàn ảnh hết mọi pixel xanh hoặc mọi cấu tạo mờ đạt.',
 'all_guards_read_after':{str(p):sha(p) for p in guards},
 'source_RGB_modified_by_this_task':False,'geometry_modified_by_this_task':False,'PDF_or_PNG_written_by_this_task':False,'TIEN_DO_modified':False}
fp=Path(fresh(O/'g01_03_NGHIEM THU DOC LAP RAM V5 - ANH THAT VA GIOI HAN NGUON.json'))
fp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')

lines=['# Nghiệm thu độc lập ảnh Perotac WC V5 trong bộ nhớ', '',
 '**ĐẠT đúng 8 đoạn đã khóa và cách trình bày ở kích thước catalogue. Chưa nghiệm thu byte PDF ảnh vì chưa có PDF trên đĩa.**', '',
 'Đã trực tiếp mở cả ba nhóm ảnh 150/600 điểm ảnh mỗi inch và ba toàn trang đại diện 1/4/6; so ảnh JPEG gốc, bản cắt V4B và V5. Không sửa clip (đường cắt), RGB (điểm ảnh màu), PDF hoặc TIEN DO.md.',
 f'Dữ liệu hình học: `{sha(V5)}`. Mã kiểm tệp là SHA256; tệp không đổi.', '',
 '| STT | Tệp | Trang | Việc | Trước | Sau | Nghiệm thu | Chứng cứ |',
 '|---|---|---|---|---|---|---|---|']
for q in edit_rows:
    lines.append(f"| {q['id']} | Perotac WC | {','.join(map(str,q['pages']))} | Thu mực ngoài thân ở đoạn đã khóa | V4B giữ mảng/gai xanh | {q['observation_from_actual150_600']} | ĐẠT phạm vi đoạn | ROI nguồn {q['source_ROI']}; ảnh 150/600 thật; JSON đi kèm |")
lines.extend(['',f"Đọc lại các ảnh thật: {len(water)}/{len(water)} mốc nước mới loại đổi pixel ở 600 dpi; {len(metal)}/{len(metal)} mốc kim loại sát cạnh giữ đúng pixel V4B→V5. Có {counts['water_already_excluded_in_V4B']} mốc nước đã nằm ngoài V4B, tách khỏi số mới thu. {len(actual_holes)}/{len(actual_holes)} vòng lỗ giữ nguyên tọa độ và mẫu điểm trong ảnh; không suy số vòng thành số lỗ cơ khí.",
 'Ảnh trước V4B/V5 giống đúng điểm ảnh ở 150/600. Toàn trang đại diện 1/4/6 so V4B→V5 ở 150 dpi/ngưỡng 0: không có thay đổi ngoài bao 8 vùng (đệm 2 điểm ảnh để chứa chống răng cưa). Ảnh cắt 150/600 cũng không đổi ngoài bao này. Đây là nghiệm thu ảnh đã có, không thay phép đọc cấu trúc PDF sau khi ghi mẫu.',
 f"Khe thật nhóm 3 ở hàng y798: đọc {len(pts)} tâm điểm ảnh x{gap['x_range'][0]}…{gap['x_range'][1]-1} đều ngoài miền ảnh; xem 150/600 còn khoảng rõ giữa hai chi tiết rời. Không nối giả hoặc thêm chi tiết.",
 '', '| Nhóm | Cấu tạo nhìn rõ đã kiểm | Quan sát kích thước catalogue | Giới hạn nguồn |',
 '|---|---|---|---|'])
for q in mechanical:lines.append(f"| {q['group']} | {q['seen']} | {q['catalogue_150']} | {q['limit']} |")
lines.extend(['', 'Viền xanh còn lại dính vào rìa vật liệu trong JPEG gốc được giữ. Không tự dùng ngưỡng màu để khoét kim loại, quai hay khe. Những phần mờ nhỏ và bóng phản quang ghi **CHƯA THỂ XÁC MINH** về tách từng điểm ảnh; không gọi toàn bộ cấu tạo đạt chỉ từ 82 mốc hoặc 12 vòng.',
 f"Phiếu chi tiết: [{fp.name}]({fp.name}), SHA256 `{sha(fp)}`. Phiếu này có đủ đường dẫn/mã kiểm ảnh thật, số đo, mẫu điểm các viền mờ và bảo vệ nguồn.",
 'Nguồn catalogue 622bcc…31d4; bản giao 5418b7…f3d và ba JPEG nguyên mã kiểm. Không có tệp PDF mới trong thư mục RAM. ROOT có thể cho tác nhân dựng một mẫu PDF theo đúng clip đã khóa; sau đó cần đọc trực tiếp PDF mẫu trước giao.'])
report=Path(fresh(O/'g01_04_BAO CAO8 COT DOC ANH RAM V5 VA VIEN NGUON.md'));report.write_text('\n'.join(lines)+'\n',encoding='utf8')
print('RESULT_JSON',fp,'SHA',sha(fp),flush=True)
print('RESULT_REPORT',report,'SHA',sha(report),flush=True)
print('WHOLE150',[(x['page'],x['changed_pixels_threshold0'],x['outside8_changed_bbox_envelopes_with2_render_pixel_pad']) for x in whole],flush=True)
print('ACTUAL_CHECKS','water_new',len(water),'metal_equal',len(metal),'holes',len(actual_holes),'gap_source',len(pts),flush=True)
