from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,csv
import numpy as np
from PIL import Image
from catfix.vector import Editor
from catfix.raster import Raster
from g01_wc_clip_math import windall,area,bbox,parse,intersections,dist
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads(Path(S.report('G08/ROOT PHAT HANH MOT PDF ANH V5 CA8 TRANG/ROOT KHOA MOT PDF ANH M1 V5.json')).read_text(encoding='utf8'))
d=json.loads(Path(lock['clip_file']).read_text(encoding='utf8'));assert sha(lock['clip_file'])==lock['clip_sha256']
pdf=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs\per_wc_continue_photo_union_v5_PDF_mau1_a1\Catalog cắt rác perotac (bản mới).pdf')
assert sha(pdf)=='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee'
witnesses=d['original27_witnesses_read_again']+d['additional_water_and_metal_witnesses'];assert len(witnesses)==82
e=Editor(str(pdf),backend='fitz');points=[];geoms=[];zones=[];gaps=[]
for job in lock['jobs8']:
 pi=job['page']-1;g=next(q for q in d['groups'] if q['group']==job['group']);im=next(q for q in Raster(e).images(pi) if q.name==job['original_source_JPEG_name']);ops=e.page(pi).ops;di=im.index
 assert ops[di-2].op=='W' and ops[di-1].op=='n'
 qi=max(i for i in range(di-2) if ops[i].op=='q');polys=[];current=[];unitpaths=[]
 for op in ops[qi+1:di-2]:
  if op.op=='m':assert not current;current=[[float(op.operands[0])*im.W,(1-float(op.operands[1]))*im.H]]
  elif op.op=='l':current.append([float(op.operands[0])*im.W,(1-float(op.operands[1]))*im.H])
  elif op.op=='h':
   a=np.asarray(current);a=a[:-1] if np.array_equal(a[0],a[-1]) else a;polys.append(a);current=[]
  else:raise AssertionError(('UNEXPECTED',op.op))
 assert not current and len(polys)==len(g['combined_clip_subpaths'])
 original=[parse(sub) for sub in g['combined_clip_subpaths']]
 rings=[]
 for i,(p,o) in enumerate(zip(polys,original)):
  assert p.shape==o.shape
  delta=float(np.max(np.abs(p-o)));allowed=max(im.W,im.H)*5.1e-11
  assert delta<=allowed
  rings.append({'ring':i,'actual_vertices':len(p),'actual_area_source_pixel2':area(p),'expected_area_source_pixel2':area(o),'actual_bbox':bbox(p),'max_coordinate_delta_source_pixel':delta,'orientation_source_coordinates':'outer-positive' if area(p)>0 else 'hole-negative','actual_coordinates_match_source_round10':True})
 src=Image.open(g['source_JPEG']).convert('RGB');assert sha(g['source_JPEG'])==g['source_JPEG_sha256']
 wg=[q for q in witnesses if q['group']==job['group']]
 ws=windall(polys,[q['point_source_pixel'] for q in wg])
 for q,w in zip(wg,ws.tolist()):
  x,y=q['point_source_pixel'];rgb=list(src.getpixel((int(x),int(y))));isvisible=w!=0
  uv=np.array([x/im.W,1-y/im.H,1.]);pagebottom=(uv@im.ctm).tolist()[:2]
  result={'page':job['page'],'group':job['group'],'label':q['label'],'kind':q['kind'],'point_source_pixel':[x,y],'expected_visible':q['expected_visible'],'actual_saved_PDF_clip_winding':w,'actual_saved_PDF_clip_visible':isvisible,'visibility_match':isvisible==q['expected_visible'],'source_RGB_read':rgb,'source_RGB_expected':q['source_RGB'],'source_RGB_match':rgb==q['source_RGB'],'minimum_native_boundary_distance_in_source_pixel':min(dist(p,[x,y]) for p in polys),'actual_page_point_bottom_pt':pagebottom,'result':'ĐẠT' if isvisible==q['expected_visible'] and rgb==q['source_RGB'] else 'CHƯA ĐẠT'}
  points.append(result)
 for z in [z for z in d['excluded_regions5'] if z['group']==job['group']]:
  x0,y0,x1,y1=z['source_rectangle'];rect=np.array([[x0,y0],[x1,y0],[x1,y1],[x0,y1]],float)
  hits=sum(len(intersections(p,rect)) for p in polys)
  vertices_inside=sum(int(np.sum((p[:,0]>x0)&(p[:,0]<x1)&(p[:,1]>y0)&(p[:,1]<y1))) for p in polys)
  centerw=int(windall(polys,[[(x0+x1)/2,(y0+y1)/2]])[0]);excluded=hits==vertices_inside==centerw==0
  zones.append({'page':job['page'],'group':job['group'],'name':z['name'],'source_rectangle':z['source_rectangle'],'actual_boundary_intersections':hits,'actual_clip_vertices_inside_rectangle':vertices_inside,'actual_center_winding':centerw,'whole_continuous_rectangle_excluded':excluded,'result':'ĐẠT' if excluded else 'CHƯA ĐẠT'})
 if job['group']==3:
  pts=[[x+.5,798.5] for x in range(515,822)];ww=windall(polys,pts)
  gaps.append({'page':job['page'],'source_y_center':798.5,'source_x_centers':[515.5,821.5],'centers_tested':len(pts),'actual_saved_PDF_clip_visible_count':int((ww!=0).sum()),'result':'ĐẠT' if np.all(ww==0) else 'CHƯA ĐẠT'})
 geoms.append({'page':job['page'],'group':job['group'],'actual_clipper':'W n','rings':rings,'outer_components':sum(area(p)>0 for p in polys),'hole_loops':sum(area(p)<0 for p in polys),'actual_witness_instances':len(wg)})
assert not e.touched();e.close()
unique=[q for q in points if q['page'] in [1,4,6]];assert len(unique)==82
assert all(q['result']=='ĐẠT' for q in points+zones+gaps)
assert sha(pdf)=='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee' and sha(lock['canonical_file'])==lock['canonical_sha256'] and sha(lock['source_file'])==lock['source_sha256']
data={'PDF':str(pdf),'PDF_SHA':sha(pdf),'clip_source':lock['clip_file'],'clip_SHA':sha(lock['clip_file']),'unique_source_witnesses':len(unique),'native_point_instances_in8placements':len(points),'native_point_instances_PASS':sum(q['result']=='ĐẠT' for q in points),'native_witness_points':points,'groups_pages_actual_clip_geometry':geoms,'excluded5regions_read_all_pages':zones,'source_gap_read_all3pages':gaps,'unique_outer_components':sum(q['outer_components'] for q in geoms if q['page'] in [1,4,6]),'unique_hole_loops':sum(q['hole_loops'] for q in geoms if q['page'] in [1,4,6]),'limitations':'82 điểm đã đọc trực tiếp là kiểm mẫu hình học/điểm nguồn, không suy toàn bộ cấu tạo/viền mờ của ảnh ĐẠT; kết luận hình thức từ24ảnh thật đã mở riêng. Số vòng lỗ không phải số lỗ cơ khí.','source_or_PDF_or_RGB_or_TIENDO_modified':False}
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_PDF M1 V5 DOC LAP DU8 TRANG'))
fp=Path(fresh(O/'g01_82 MOC DOC TRUC TIEP CLIP PDF THAT - TUNG DIEM VA5 VUNG12 KHE.json'));fp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
cp=Path(fresh(O/'g01_TUNG MOC CLIP PDF THAT8 TRANG.csv'))
with cp.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['page','group','kind','label','x_source_pixel','y_source_pixel','expected_visible','winding_PDF','visible_PDF','source_RGB_match','result'])
 for q in points:w.writerow([q['page'],q['group'],q['kind'],q['label'],*q['point_source_pixel'],q['expected_visible'],q['actual_saved_PDF_clip_winding'],q['actual_saved_PDF_clip_visible'],q['source_RGB_match'],q['result']])
print('SAVED',fp,'SHA',sha(fp),flush=True)
print('CSV',cp,'SHA',sha(cp),flush=True)
print('UNIQUE',len(unique),'POINT_INSTANCES_PASS',len(points),'EXCLUDED_REGION_INSTANCES',len(zones),'UNIQUE_COMPONENTS_HOLES',data['unique_outer_components'],data['unique_hole_loops'],'GAP',gaps,flush=True)
