"""Read exact alpha/positions of source 3-phase words before any glyph use."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/CHU MODEL TU BANG3 PHA CUNG X7'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));out=[]
for model,box in [('4SA 16/25',[160,1143,225,1159]),('4SA 16/11',[160,1004,225,1019]),('4SA 16/4',[160,904,225,920])]:
    x0,y0,x1,y1=box;raw=cv.orig[y0:y1,x0:x1];al=R.alpha_of(raw,np.array([255.,255.,255.]),np.array([57.,55.,57.]));key=model.replace('/','-').replace(' ','')
    Image.fromarray(raw).save(fresh(root/(key+' TU NGUON150dpi.png')));Image.fromarray(raw).resize((raw.shape[1]*16,raw.shape[0]*16),Image.Resampling.NEAREST).save(fresh(root/(key+' TU NGUON PHONG16LAN.png')))
    print(model,'SOURCE',box,flush=True)
    print('     '+''.join(str((u//10)%10) for u in range(x0,x1)),flush=True);print('     '+''.join(str(u%10) for u in range(x0,x1)),flush=True)
    for y,row in enumerate(al):print(f'{y+y0:4d} '+''.join('#' if v>=.65 else '+' if v>=.4 else ':' if v>=.18 else '.' if v>=.05 else ' ' for v in row),flush=True)
    out.append(dict(model=model,source_column='3 pha,380–415V',source_native_box=box,original_RGB=raw.tolist(),alpha=al.tolist(),column_alpha_sum=al.sum(axis=0).tolist(),row_alpha_sum=al.sum(axis=1).tolist(),same_style_with_caption_not_yet_proved=True))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();Path(fresh(root/'3 TU MODEL NGUON VA PROFILE THEO COT.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_words=out,
     source_table_space_after4SA_kept_as_printed=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close()
