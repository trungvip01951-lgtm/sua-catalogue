from catwork import start, fresh
S,D,N=start()
from catfix import verify
from catfix.inspect_pdf import summary
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
import json, hashlib
NAME='Aquaris FS_300dpi_75% (bản mới).pdf'
root=Path(S.report('G06'));root.mkdir(exist_ok=True)
src=S.src(NAME)
E=Editor(src);R=Raster(E)
out=dict(source=src,destination=S.dst(NAME),sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),summary=summary(src),pages=[])
for pi in range(E.n_pages):
    verify.crop(src,pi,E.mediabox(pi),200).save(fresh(root/f'nguon-p{pi+1}.png'))
    im=R.image_at(pi,E.mediabox(pi))
    cv=R.canvas(im)
    hits=R.find(cv,'',psm=6)
    out['pages'].append(dict(page=pi+1,hits=hits,images=[str(i) for i in R.images(pi)]))
    print('Trang',pi+1,'ảnh đã lưu',len(hits),flush=True)
print(summary(src),flush=True)
json.dump(out,open(fresh(root/'inspection.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
