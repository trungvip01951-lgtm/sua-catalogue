"""Báo cáo bổ sung G05 đúng mẫu, lấy tổng từ từngmốc đãđo; khôngghiPDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib,csv

O='G05/GIAO BAN SAU SUA DUONG/'
P='G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO/'
basic=json.loads(Path(S.report('BAO CAO G05.json')).read_text(encoding='utf8'))
a=json.loads(Path(S.report(P+'NGHIEM THU QH PDF MAU.json')).read_text(encoding='utf8'))
actual=json.loads(Path(S.report(O+'DOC LAI ACTUAL PDF GIAO VA DINH CHINH XMP.json')).read_text(encoding='utf8'))
delivery=json.loads(Path(S.report(O+'NGHIEM THU PDF GIAO.json')).read_text(encoding='utf8'))
style=json.loads(Path(S.report('G05/MAU PDF SUA DUONG/MAU VA DO DAY TUNG DOAN - SUY TU ANH.json')).read_text(encoding='utf8'))
assert hashlib.sha256(Path(actual['final']).read_bytes()).hexdigest()==actual['final_sha256']==delivery['final_sha256']
points=a['points'];curves=a['curves'];statuses=['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']
counts={s:sum(p['verification_status']==s for p in points) for s in statuses};assert counts==a['overall_counts']
failed=[p for p in points if p['verification_status']=='CHƯA ĐẠT']
unknown=[p for p in points if p['verification_status']=='CHƯA THỂ']
new=[p for p in points if p['actual_vector']]
assert len(new)==52 and all(p['verification_status']=='ĐẠT' for p in new)
can=[r for r in basic if r['result']=='ĐẠT'];assert len(can)==6
md=['# BÁO CÁO BỔ SUNG NHÓM G05 – Perotac SP','',
 'Đã giao đúng tên tệp và thư mục Giếng: 6/6 việc chữ/số giữ đạt; bổ sung 26 đuôi đường với 52 mốc đạt và mã hàng 6SP36-28. Nhóm **CHƯA XONG** vì kiểm toàn bộ 220 đường còn 31 mốc lệch đã xác định và 1.074 mốc chưa thể xác minh.','',
 '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
 '|---|---|---|---|---|---|---|---|']
for r in basic:
 p='1,4,9,11' if r['stt']==132 else r['page']
 method='Chép nét chữ/số từ chính tệp bằng catfix; đủ 17 vị trí đã nghiệm thu. Bản giao giữ nguyên điểm ảnh ngoài bổ sung bên dưới.' if r['result']=='ĐẠT' else 'Đối chiếu điểm ảnh nguồn; giữ nguyên.'
 evidence=r['evidence']+'; '+O+'NGHIEM THU PDF GIAO.json'
 vals=[r['stt'],r['file'],p,r['old'],r['new'],method,r['result'],evidence]
 md.append('| '+' | '.join(str(v).replace('|','/').replace('\n',' ') for v in vals)+' |')
md.extend(['',f'Tổng phạm vi chữ/số: {len(can)} việc · ĐẠT {len(can)} · CHƯA ĐẠT 0 · CHƯA THỂ XÁC MINH 0. #50 và #134 giữ nguyên.','',
 '| # bổ sung | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
 '|---|---|---|---|---|---|---|---|',
 '| BS01 | Perotac bơm giếng SP_compressed (bản mới).pdf | 5,7 | Đuôi những đường nhận dạng chắc lệch bảng | 16 đuôi 6SP30 + 10 đuôi 6SP60; 52 mốc cuối theo đúng bảng | Chỉ tách mực đường cần sửa, giữ lưới/chữ; mặt nạ trong suốt chỉ chứa điểm ảnh đổi; đường Bézier trơn đi qua mốc thật. | ĐẠT phần 52 mốc mới | G05/MAU PDF SUA DUONG; G05/GIAO BAN SAU SUA DUONG/52 MOC ACTUAL PDF GIAO.csv; G05/NGHIEM THU MAU DOC LAP ROOT.json |',
 '| BS02 | Perotac bơm giếng SP_compressed (bản mới).pdf | 6 | Hàng 20 lặp mã 6SP36-26 | 6SP36-28; toàn bộ Q/H/kW/kích thước giữ nguyên | Chép ký tự 8 thật từ mã 6SP36-18, cùng kiểu/cỡ 4,08pt trong chính tệp; 10/10 mốc nguồn khớp duy nhất nhãn 28. | ĐẠT | G05/BO SUNG MA MODEL/SAU.png; G05/KIEM TOAN TOAN BO/HAI HANG 6SP36-26 - CAN CU NOI BO.json |','',
 f'Tổng bổ sung đã sửa: 2 việc · ĐẠT 2 trong phạm vi nêu trên. 26 đường chỉ được sửa phần đuôi; chưa gọi cả đường đã đạt. Sai lệch lớn nhất đọc từ nét thật trong PDF giao: {actual["max_actual_deviation_m"]:.11f} m. Cả 52 mốc đều nằm trong giới hạn max(1m,2%H), đã tính biên vị trí trục ảnh nguồn.','',
 f'Kiểm toán toàn bộ: {len(curves)} đường, {len(points):,} mốc số thực có trong bảng, 15 ô biểu đồ trên 10 trang. ĐẠT {counts["ĐẠT"]:,}; CHƯA ĐẠT {counts["CHƯA ĐẠT"]}; CHƯA THỂ XÁC MINH {counts["CHƯA THỂ"]:,}.'.replace(',','.'),'',
 'Phép đo mốc ảnh dùng thứ tự nét và nhãn nguồn, không tìm đường gần số H của bảng. Nguồn là ảnh 150dpi (150 điểm ảnh/inch); chụp 600dpi chỉ giúp nhìn, không được coi là độ phân giải nguồn mới. Biên sai số bảo thủ gồm định vị trục, tâm nét, độ dốc và ngoại suy. Dấu gạch/ô trống không dựng thêm điểm.','',
 'Các mốc lệch còn lại:','',
 '| Mã máy | Trang | Q lệch (m³/h) | Số mốc |',
 '|---|---|---|---|'])
failed_curves=[]
for c in curves:
 rr=[p for p in failed if p['family']==c['family'] and p['row']==c['row']]
 if not rr:continue
 qs=[p['Q_m3h'] for p in rr];failed_curves.append(dict(model=c['curve_model'],page=c['page'],Q=qs,points=rr))
 md.append('| '+' | '.join(map(str,[c['curve_model'],c['page'],', '.join(map(str,qs)),len(rr)]))+' |')
assert sum(len(z['points']) for z in failed_curves)==len(failed)
md.extend(['',
 '29 mốc trái của 13 mã 6SP30 và 2 mốc Q180 của 10SP135-5/-7 vẫn CHƯA ĐẠT. Đây là phần giữ nguyên sau mẫu, chưa được giải quyết bằng sửa đuôi. Hồ sơ từng Q/H, sai lệch, sai số và ảnh đánh dấu đủ 15 ô biểu đồ nằm trong G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO.','',
 'Tên bảng 4SP14 và nhãn đường 4SP15 chưa có căn cứ chọn tên đúng: giữ 110 mốc CHƯA THỂ về danh tính. Bảng 6SP30-8 và nét nguồn 6SP30-9 không đủ 8/8 mốc nhận dạng: giữ toàn nét/nhãn và 8 mốc CHƯA THỂ. Không đổi mã theo thứ tự đường đơn thuần. Hai mốc số trên nét này lệch ngưỡng nhưng vẫn CHƯA THỂ về danh tính, không gộp vào 31 mốc của các mã chắc chắn.','',
 'Đính chính dữ liệu kiểm toán: ô H0 của 6SP30-38 đọc đúng 433m, lần chép trước ghi 432m. Đã sửa riêng dữ liệu đo, lưu ảnh bảng nguồn và lịch sử đính chính; PDF không sửa ô này.','',
 'Nghiệm thu hình dáng và bảo toàn:','',
 '- AI điều phối đã đọc độc lập 26 đối tượng nét thật/52 mốc, đối chiếu bảng nguồn và xem 2 ô biểu đồ của PDF mẫu; chấp nhận phần sửa.',
 '- PDF giao được đọc lại 26 nét/52 mốc; màu, độ dày, nét liền, ma trận vẽ, điểm đầu/cuối giống bản mẫu đã duyệt. 2 ô biểu đồ 600dpi và 15 bảng 450dpi giữ từng điểm ảnh của mẫu. Toàn PDF 200dpi với ngưỡng chênh 0 không có điểm ảnh khác mẫu.',
 '- Đoạn trái chứa chữ/nét đứt giữ điểm ảnh nguồn 300dpi. Nét 6SP30-9, hai nét thấp SP30-2/-3 và ba nét thấp SP60-2/-3/-4 giữ nguyên.',
 '- Tất cả 2.218 ô Q/H vẫn giữ điểm ảnh; chỉ nhãn mã máy có sửa riêng. Bảng số/kW/điện áp/kích thước không đổi. Hàng kích thước 26 trang 8 giữ nguyên, không tự suy kích thước 28.',
 '- Giữ 12 trang, khổ trang, phông nhúng, ảnh JPEG gốc, thông tin tệp, liên kết, dấu trang. Tệp nguồn và tệp giao đều không có XMP (khối thông tin siêu dữ liệu), giữ nguyên trạng thái không có. Cờ restored=True cố định ở hồ sơ giao đã được đính chính bằng hồ sơ đọc thật tệp giao; không có luồng XMP để khôi phục.',
 '- #50 tiêu đề và #134 khối lượng giữ điểm ảnh nguồn. Mã kiểm tra SHA256 nguồn không đổi; bản ra phiên trước đã lưu vào báo cáo sau kiểm đường dẫn và mã kiểm tra.','',
 'Màu/độ dày nguồn là số suy từ ảnh JPEG 150dpi; không tuyên bố bút vector nguồn có đúng tham số mới. Mẫu màu mới cách lõi RGB nguồn gần nhất tối đa 8/255 mức. 51/52 đoạn có bề dày nét mới 0,48pt nằm trong khoảng FWHM đo ảnh ±0,12pt. Ngoại lệ SP30-38 đoạn Q36→42: FWHM ảnh nguồn 0,707–1,169pt, trung vị 0,779pt; chênh 0,299pt với nét mới nhỏ hơn 1 điểm ảnh nguồn 0,48pt nên chưa đủ kết luận bút vẽ sai. FWHM là độ rộng nét tại nửa mức đậm; RGB là ba mức màu đỏ/xanh lá/xanh lam. Vector là nét vẽ bằng tọa độ. AI điều phối đã chấp nhận hình mẫu thật với giới hạn đo ảnh này. Hồ sơ giữ nguyên đầy đủ 52 đoạn, không che ngoại lệ.','',
 'Hai phương pháp đã thử: tách mực/nền + nét vector (2 mẫu kỹ thuật); chuyển tiết diện mực nguồn (1 mẫu không đạt vì mờ). Các mẫu không đạt giữ trong báo cáo, không giao. Bản được chấp nhận là phạm vi 16+10 nét, giữ nét chưa đủ danh tính. Không thử lại máy móc phương pháp không đạt.','',
 'Cần anh quyết: không có yêu cầu duyệt bổ sung; quyền sửa/vẽ đã cấp. Phần còn lại vẫn ghi CHƯA XONG, không nâng các mốc ảnh chưa đủ bằng chứng thành ĐẠT.','',
 'Tệp giao: '+actual['final'],
 'SHA256 bản giao: '+actual['final_sha256'],
 'SHA256 nguồn bất biến: '+actual['source_sha256'],
 'Bản phiên trước: '+delivery['archived_old_primary'],'',
 'Bằng chứng chính:','',
 '- G05/GIAO BAN SAU SUA DUONG/DOC LAI ACTUAL PDF GIAO VA DINH CHINH XMP.json',
 '- G05/GIAO BAN SAU SUA DUONG/NGHIEM THU PDF GIAO.json',
 '- G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO/NGHIEM THU QH PDF MAU.json/.csv',
 '- G05/MAU PDF SUA DUONG/KIEM TOAN TOAN BO/NGHIEM THU 220 DUONG.csv và NGHIEM THU/*.png',
 '- G05/MAU PDF SUA DUONG/MAU VA DO DAY TUNG DOAN - SUY TU ANH.json',
 '- G05/NGHIEM THU MAU DOC LAP ROOT.json',''])
path=fresh(S.report('BAO CAO BO SUNG G05 - DA NGHIEM THU.md'))
Path(path).write_text('\n'.join(md),encoding='utf8')
data=dict(final_sha256=actual['final_sha256'],source_sha256=actual['source_sha256'],basic_task_count=len(can),basic_tasks_passed=len(can),supplemental_corrections=2,new_vector_curves=len(actual['styles']),new_vector_points=len(new),new_points_counts={s:sum(p['verification_status']==s for p in new) for s in statuses},curve_count=len(curves),point_count=len(points),overall_counts=counts,numeric_counts=a['numeric_counts'],confirmed_failed_curves=failed_curves,unknown_point_count=len(unknown),group_status='CHƯA XONG',archived_previous_path=delivery['archived_old_primary'],style_exception='6SP30-38 đoạnQ36→42; ngoại lệ1/52 bềdày từảnh; nguồn150dpi khôngđủkếtluậnpenwidth.',reports=[path,a['trial_path'],actual['final']])
Path(fresh(S.report('BAO CAO BO SUNG G05 - DA NGHIEM THU.json'))).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
print('REPORT',path,'counts',counts,'basic',len(can),'new',len(new),flush=True)
