"""Kiểm độc lập G03: đọc bảng thật và 414 mốc trong PDF đã lưu."""
from catwork import start, fresh
from pathlib import Path
import json, hashlib, pickle, copy, collections, csv
import numpy as np
S, D, N = start()
from catfix.vector import Editor
from catfix.otext import OutlineText, procrustes
from catfix import charts, verify

root = Path(S.report('G03'))
st = json.loads((root/'build-state.json').read_text(encoding='utf8'))
rev = json.loads((root/'final-revision.json').read_text(encoding='utf8'))
src, dst = st['source'], st['destination']
assert hashlib.sha256(Path(src).read_bytes()).hexdigest() == st['source_sha256']
assert hashlib.sha256(Path(dst).read_bytes()).hexdigest() == 'fbc99ed3b402bb373832cd5153e35474a10f2c97c195be4b34f6320f20cf257e'
A, B = Editor(src), Editor(dst)
AT = OutlineText(A)
cache = root/'NGUON CHU DOC LAP ROOT.pkl'
if cache.exists():
    AT.__dict__.update(pickle.loads(cache.read_bytes()))
else:
    AT.learn(range(10), dpi=400, verbose=False)
    state = {k:v for k,v in AT.__dict__.items() if k not in ('E',)}
    Path(fresh(cache)).write_bytes(pickle.dumps(state))
BT = OutlineText(B)
BT.clusters = copy.deepcopy(AT.clusters)
BT._buckets = copy.deepcopy(AT._buckets)
for cl in BT.clusters:
    cl['members'] = []
typed = collections.defaultdict(list)
for cl in AT.clusters:
    if cl['label'] != '?':
        typed[(cl['ops'],len(cl['pts']))].append(cl)

def output_glyphs(pi):
    gs = BT.page_glyphs(pi)
    for g in gs:
        g.char = BT.clusters[g.cl]['label']
        g.style = BT.clusters[g.cl]['style']
        if g.char == '?':
            matches = []
            for cl in typed[(g.ops,len(g.pts))]:
                scale, rotation, shift, err = procrustes(cl['pts'],g.pts,allow_rotation=False)
                if .5 < scale < 2 and err < .003:
                    matches.append((err,cl['label']))
            if matches:
                g.char = min(matches)[1]
    return gs

def cells_in_row(gs, box):
    cy = (box[1]+box[3])/2
    chosen = sorted([g for g in gs if g.bbox[0]>342 and g.bbox[2]<534
                     and abs((g.bbox[1]+g.bbox[3])/2-cy)<3.5], key=lambda g:g.bbox[0])
    groups = []
    for g in chosen:
        if not groups or g.bbox[0] - groups[-1][-1].bbox[2] > 4:
            groups.append([g])
        else:
            groups[-1].append(g)
    return [dict(text=''.join(g.char for g in group),
                 rect=[min(g.bbox[0] for g in group),min(g.bbox[1] for g in group),
                       max(g.bbox[2] for g in group),max(g.bbox[3] for g in group)])
            for group in groups]

tables, points, paint, endpoints = [], [], [], []
for page, tab in st['tables'].items():
    pg, pi = int(page), int(page)-1
    axis = next(z for z in st['axes'] if z['page']==pg)
    P0, P = A.page(pi), B.page(pi)
    border0 = P0.objs[tab['grid_oi']]
    borders = [o for o in P.objs if o['op'] in ('S','s') and o.get('bbox')
               and np.max(abs(np.asarray(o['bbox'])-border0['bbox']))<1e-6]
    assert len(borders)==1 and np.max(abs(np.asarray(axis['rect'])-borders[0]['bbox']))<1e-6
    x0,y0,x1,y1 = borders[0]['bbox']
    C = charts.Chart.from_ticks([(0,x0),(max(tab['q']),x1)],[(0,y0),(tab['maxH'],y1)])
    candidates = []
    for oi in charts.curve_objects(P,(x0-.02,y0-.02,x1+.02,y1+.02),min_span=100):
        col = P.color_of(oi,'stroke')
        if col is None or not(col[0]<.3 and col[1]>.6 and col[2]>.8):
            continue
        arr = charts.sample_path(P.object_pagepath(oi),n=1800)
        if arr[0,0]>arr[-1,0]: arr=arr[::-1]
        candidates.append((oi,arr))
    assert len(candidates)==len(tab['stages']),(pg,len(candidates),len(tab['stages']))
    ag, bg = AT.page_glyphs(pi), output_glyphs(pi)
    used = set()
    for stage, heads in zip(tab['stages'], tab['heads']):
        model = f"{tab['series']}/{stage}"
        old_model = '4SA8/24' if model=='4SA8/28' else model
        row_rect = (180,y1+8,240,610)
        found = AT.find(pi,old_model,rect=row_rect,ignore_spaces=True)
        def whole_model(m):
            cy=(m.bbox[1]+m.bbox[3])/2
            return ''.join(g.char for g in sorted([g for g in ag if 180<g.bbox[0]<240
                       and abs((g.bbox[1]+g.bbox[3])/2-cy)<1.5],key=lambda g:g.bbox[0]))
        found = [m for m in found if whole_model(m)==old_model]
        assert len(found)==1,(pg,old_model,len(found))
        box = found[0].bbox
        old_cells, new_cells = cells_in_row(ag,box), cells_in_row(bg,box)
        assert len(old_cells)==len(new_cells)==6,(pg,model,old_cells,new_cells)
        source_heads = []
        for i,(q,h) in enumerate(zip(tab['q'], heads)):
            before, after = old_cells[i]['text'],new_cells[i]['text']
            assert float(after)==h,(pg,model,q,after,h)
            changed = before != after
            if changed:
                proof = [z for z in st['checks'] if z['page']==pg and z['old']==before
                         and z['new']==after and np.max(abs(np.asarray(z['rect'])-old_cells[i]['rect']))<.05]
                assert len(proof)==1,(pg,model,q,before,after,old_cells[i]['rect'])
            source_heads.append(dict(Q=q,source=before,output=after,H=h,changed=changed))
        tables.append(dict(page=pg,model=model,cells=source_heads))
        intended = np.asarray(C.to_page(np.asarray(tab['q'])[[0,-1]],np.asarray(heads)[[0,-1]])).T
        # Match the fresh output path by both actual endpoints; do not trust its object index.
        matches = [(oi,arr) for oi,arr in candidates if oi not in used
                   and np.max(abs(arr[[0,-1]]-intended))<.001]
        assert len(matches)==1,(pg,model,len(matches))
        oi,arr = matches[0];used.add(oi)
        original = next(z for z in st['curves'] if z['page']==pg and z['model']==model)
        oo, nn = P0.objs[original['oi']],P.objs[oi]
        for field in ('op','fill','stroke','lw','dash','gs','fill_cs','stroke_cs','clip','textclip'):
            assert oo.get(field)==nn.get(field),(pg,model,field)
        assert np.array_equal(oo['ctm'],nn['ctm'])
        assert P0.color_of(original['oi'],'stroke')==P.color_of(oi,'stroke')
        data = C.to_data(arr)
        assert np.min(np.diff(data[:,0]))>=-1e-6
        for q,h in zip(tab['q'],heads):
            assert data[0,0]-.00001<=q<=data[-1,0]+.00001
            got = float(np.interp(q,data[:,0],data[:,1]))
            error, tolerance = got-h,max(1,.02*abs(h))
            assert abs(error)<=tolerance,(pg,model,q,h,got)
            points.append(dict(page=pg,model=model,unit_Q=tab['units'],Q=q,H_table=h,
                               H_read=got,difference_m=error,tolerance_m=tolerance,result='ĐẠT'))
        endpoints.append(dict(page=pg,model=model,output_object=oi,
                              error_pt=float(np.max(abs(arr[[0,-1]]-intended)))))
        paint.append(dict(page=pg,model=model,source_object=original['oi'],output_object=oi,
                          style_exact=True))
    assert len(used)==len(candidates)
    print(f'G03 ROOT trang {pg}: {len(tab["stages"])} đường; bảng nguồn/đầu ra đã đọc trực tiếp',flush=True)

assert len(points)==414 and len(paint)==69
allowed = collections.defaultdict(list)
for e in rev['edits']:
    allowed[e['page']+1].append(e['rect'])
outside = verify.outside_pixels(src,dst,allowed,dpi=150,thr=12,min_size=1,pad=2)
assert not outside, outside
structure = verify.structure_check(src,dst)
assert structure['ok'],structure
out = dict(source=src,destination=dst,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),
           destination_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest(),tables=tables,table_cell_count=414,
           curve_count=69,point_count=414,points=points,endpoints=endpoints,paint=paint,
           max_difference_m=max(abs(z['difference_m']) for z in points),outside=outside,structure=structure,
           limitations='Nghiệm thu bảng và 69 đường. Việc #34 thiếu k cùng phông vẫn chưa đạt; không nhận cả G03 đã xong.')
Path(fresh(root/'NGHIEM THU DOC LAP ROOT.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8')
with open(fresh(root/'414 DIEM DOC LAI ROOT.csv'),'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(points[0]));w.writeheader();w.writerows(points)
print('G03 ROOT: 69/69 đường và 414/414 mốc ĐẠT. MaxΔH=',out['max_difference_m'],flush=True)
A.close();B.close()
