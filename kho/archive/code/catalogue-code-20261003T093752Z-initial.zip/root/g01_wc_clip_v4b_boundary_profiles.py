"""Read-only pixel profiles and contour coordinates; no image or PDF is created."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
ip=HERE/'wc_clip_source_du_lieu_20261003'/'DU LIEU DUONG CAT NGUON V4B BIEN THAN DUNG'/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json'
assert hashlib.sha256(ip.read_bytes()).hexdigest()=='d2356789b101589037eb587a6e75af4ce899e0c5297e6f316969217c162cce7a'
d=json.loads(ip.read_text(encoding='utf8'));rows=[];segments=[]
specs=[(1,'ống đôi: mép trái',[100,180,207,215,231,235,239],range(46,60)),(1,'ống đôi: mép phải',[100,180,207,215,228,234,239],range(71,82)),(1,'thanh đơn: mép trái',[100,170,188,194,217,223],range(93,105)),(1,'thanh đơn: mép phải',[100,170,177,180,213,214,217,223],range(103,114)),(1,'quai trái nhỏ và mực nước',[160,162,166,168,170,173,176],range(143,164)),(2,'vách trái bơm',[780,788,792,802,809,820,823,830],range(390,405)),(3,'vệt ngoài động cơ phải',[500,508,514,523,532,540],range(584,614)),(3,'vách trái bơm trái',[690,710,715,717,735,745],range(171,184))]
for num,title,ys,xs in specs:
    g=d['groups'][num-1];a=np.array(Image.open(g['source_JPEG']).convert('RGB'),dtype=int)
    print('\n',num,title,flush=True)
    for y in ys:
        zz=[]
        for x in xs:
            rgb=a[y,x].tolist();rows.append({'group':num,'ROI':title,'x':x,'y':y,'RGB':rgb})
            zz.append(f'{x}:{rgb[0]},{rgb[1]},{rgb[2]}')
        print('y='+str(y)+' '+' | '.join(zz),flush=True)
    bb=[min(xs),min(ys),max(xs)+1,max(ys)+1]
    rr=[]
    for k,q in enumerate(g['combined_clip_subpaths']):
        p=np.array([c[1:] for c in q['commands_pixel'] if not isinstance(c,str) and c[0] in ('M','L')],dtype=float)
        if np.array_equal(p[0],p[-1]):p=p[:-1]
        for i in range(len(p)):
            t=p[(i+1)%len(p)];s=p[i]
            if max(s[0],t[0])>=bb[0] and min(s[0],t[0])<=bb[2] and max(s[1],t[1])>=bb[1] and min(s[1],t[1])<=bb[3]:rr.append({'ring':k,'edge':i,'from':s.tolist(),'to':t.tolist()})
    print('CLIP_EDGES',json.dumps(rr,ensure_ascii=False),flush=True)
    segments.append({'group':num,'ROI':title,'box':bb,'clipping_edges':rr})
op=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_03_PROFILE NGUON VA CANH CLIP SAI.json'))
Path(fresh(op)).write_text(json.dumps({'input_sha256':hashlib.sha256(ip.read_bytes()).hexdigest(),'pixels':rows,'clipping_edges_in_ROIs':segments,'no_raster_or_PDF_written':True},ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',op,flush=True)
