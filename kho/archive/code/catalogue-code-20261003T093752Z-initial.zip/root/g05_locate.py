from catwork import start,fresh
from pathlib import Path
import json
S,D,N=start()
from catfix import verify
j=S.job('Perotac bơm giếng SP_compressed (bản mới).pdf')
d=json.loads(Path(S.report('G05/NGUON.json')).read_text(encoding='utf-8'))
regions=[(4,(470,18,790,199),'BANG 6SP30'),(6,(28,18,397,193),'BANG 6SP60'),
         (7,(553,365,790,500),'KICH THUOC 6SP46'),(8,(463,20,787,181),'BANG 8SP77')]
for p,r,label in regions:
    verify.crop(j.src,p,r,280).save(fresh(S.report('G05/DINH VI/'+label+'.png')))
    cv=j.canvas(p)
    ws=j.R.ocr(cv,box=cv.box(r),scale=3,psm=6)
    ls={}
    for w in ws:ls.setdefault(str(w['line']),[]).append(w)
    texts=[]
    for line in ls.values():
        texts.append(' '.join(w['text'] for w in sorted(line,key=lambda w:w['box'][0])))
    Path(fresh(S.report('G05/DINH VI/'+label+'.txt'))).write_text('\n'.join(texts),encoding='utf-8')
    print(label,'\n'+'\n'.join(texts),flush=True)
for p in [0,3,8,10]:
    r=(20,35,230,190 if p==0 else 240)
    verify.crop(j.src,p,r,240).save(fresh(S.report(f'G05/DINH VI/VAT LIEU BAO HANH {p+1}.png')))
j.close()
