"""Đối chứng cùng kiểu qua4,S,A của chữ lớn/nhỏ trongchínhfile; chưa PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.ndimage import map_coordinates,gaussian_filter
from scipy.optimize import differential_evolution,minimize
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'DOI CHIEU CHU LON VA CHU NHAN CUNG FILE'
title=json.loads((base/'CHU LON TIEU DE CUNG FILE CHI DOC/5 CHU LON TIEU DE CUNG FILE CHI DOC.json').read_text(encoding='utf8'));tby={r['character']:r for r in title['title_glyphs']}
cap=json.loads((base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json').read_text(encoding='utf8'));by={r['key']:r for r in cap['candidates']};keys={'4':'4_4SA16-25','S':'S_4SA16-25','A':'A_4SA16-25'}
sub=12;refs={};samplecoords={}
for ch in '4SA':
    r=by[keys[ch]];t=tby[ch];al=np.array(r['alpha']);ta=np.array(t['source_alpha_matrix']);refs[ch]=al
    yy,xx=np.mgrid[:al.shape[0]*sub,:al.shape[1]*sub];worldx=r['source_native_box'][0]+(xx+.5)/sub;worldy=r['source_native_box'][1]+(yy+.5)/sub
    py,px=np.mgrid[:al.shape[0],:al.shape[1]];ty,tx=np.mgrid[:ta.shape[0],:ta.shape[1]]
    muR=r['source_native_box'][0]+float(((px+.5)*al).sum()/al.sum());muT=t['source_native_box'][0]+float(((tx+.5)*ta).sum()/ta.sum())
    samplecoords[ch]=(worldx,worldy,muR,muT,r,t)
def predict(ch,z):
    sx,sy,dy,sigma,floor=z;worldx,worldy,muR,muT,r,t=samplecoords[ch];ta=np.array(t['source_alpha_matrix'])
    sourcex=(worldx-muR)/sx+muT;sourcey=(worldy-(212.3+dy))/sy+214.3
    hi=map_coordinates(ta,[sourcey-t['source_native_box'][1]-.5,sourcex-t['source_native_box'][0]-.5],order=1,mode='constant',cval=0,prefilter=False)
    h,w=refs[ch].shape;aa=hi.reshape(h,sub,w,sub).mean((1,3));pred=np.clip(gaussian_filter(aa,sigma,mode='constant')+floor,0,1)
    return pred,aa
def objective(z):return float(np.mean([np.mean((predict(ch,z)[0]-refs[ch])**2) for ch in '4SA']))
bounds=[(.32,.39),(.32,.39),(-.5,.5),(0,.45),(0,.025)]
opt=differential_evolution(objective,bounds,seed=4011,popsize=8,maxiter=38,tol=1e-6,polish=False);fine=minimize(objective,opt.x,bounds=bounds,method='Powell',options={'maxiter':80,'xtol':1e-5,'ftol':1e-8});z=fine.x
results=[];tiles=[]
for ch in '4SA':
    rr=refs[ch];pred,aa=predict(ch,z);r=by[keys[ch]];t=tby[ch];worldx,worldy,muR,muT,_,_=samplecoords[ch];rb=np.array(r['source_iso_native_bbox']);tb=np.array(t['source_iso_native_bbox']);transform_width=(tb[2]-tb[0])*z[0];transform_height=(tb[3]-tb[1])*z[1]
    w=(rr>.2)|(pred>.2);rm=rr>.45;pm=pred>.45
    result=dict(character=ch,source_caption_box=r['source_native_box'],source_title_box=t['source_native_box'],source_caption_page=8,source_title_page=8,same_original_X7_only=True,
       title_to_caption_common_scale_xy=z[:2].tolist(),common_baseline_dy_native_px=float(z[2]),comparison_JPEG_sigma_native_px=float(z[3]),comparison_JPEG_floor_alpha=float(z[4]),
       horizontal_centroid_alignment_for_character_placement_only=True,source_caption_alpha=rr.tolist(),source_title_alpha=t['source_alpha_matrix'],source_title_predicted_caption_alpha=pred.tolist(),
       alpha_RMSE=float(np.sqrt(np.mean((pred-rr)**2))),alpha_MAE=float(np.mean(abs(pred-rr))),signal_correlation=float(np.corrcoef(rr[w],pred[w])[0,1]),IoU_iso45=float((rm&pm).sum()/(rm|pm).sum()),
       title_after_common_transform_bbox_width_px=transform_width,title_after_common_transform_bbox_height_px=transform_height,caption_bbox_width_px=rb[2]-rb[0],caption_bbox_height_px=rb[3]-rb[1],
       transformed_vs_caption_width_delta_native_px=transform_width-(rb[2]-rb[0]),transformed_vs_caption_height_delta_native_px=transform_height-(rb[3]-rb[1]),
       source_caption_components_and_holes=[r['components'],r['holes']],source_title_components_and_holes=[t['source_components'],t['source_holes']],
       common_shape_comparison_not_font_family_metadata=True,font_style_match_not_finally_accepted=True)
    results.append(result)
    src=Image.open(base/'DO BIEN GIU LUONG MUC NGUON'/(keys[ch]+' NGUON150dpi.png'));rawimg=src.resize((src.width*24,src.height*24),Image.Resampling.NEAREST)
    predimg=Image.fromarray((255-pred[:,:,None]*np.array([198,200,198])).clip(0,255).astype(np.uint8)).resize((rr.shape[1]*24,rr.shape[0]*24),Image.Resampling.NEAREST)
    rawT=Image.open(base/'CHU LON TIEU DE CUNG FILE CHI DOC'/(ch+' TIEU DE NGUON VA BIEN CHI XEM.png'))
    tile=Image.new('RGB',(1100,360),'white');tile.paste(rawimg,(20,40));tile.paste(predimg,(340,40));tile.paste(rawT.crop((0,0,360,330)),(700,10));tiles.append(tile);tile.save(fresh(root/(ch+' CHU NHAN VA CHU LON QUA CUNG BIEN DOI.png')))
    print(ch,'RMSE',result['alpha_RMSE'],'CORR/IOU',result['signal_correlation'],result['IoU_iso45'],'DW/DH px',result['transformed_vs_caption_width_delta_native_px'],result['transformed_vs_caption_height_delta_native_px'],flush=True)
sheet=Image.new('RGB',(1100,1080),'white')
for i,t in enumerate(tiles):sheet.paste(t,(0,i*360))
sheet.save(fresh(root/'4SA NGUON CAPTION TIEU DE BIEN DOI CHUNG.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==cap['source_sha256'] and sha(S.result(name))==cap['current_sha256']
Path(fresh(root/'CAU NOI 3 CHU LON VA CAPTION NGUON.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),same_Perotac_X7_source_only=True,characters_examined=['4','S','A'],
       common_transform_and_JPEG_readback_fit=z.tolist(),fit_global_source_MSE=objective(z),source_small_edge_uncertainty_px=.5,each_character_translation_only_placement_centroids_not_shape_fit=True,
       original_font_program_and_family_unavailable=True,font_match_not_proved_by_IoU_alone=True,results=results,source_larger4_not_yet_selected_for_catalogue=True,PDF_or_font_or_common_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
print('COMMON SOURCE TRANSFORM',z.tolist(),flush=True)
