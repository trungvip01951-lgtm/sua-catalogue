from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
r=Path(S.report('G04/REDPUMP 25 MAU SUA DUOI1'));b=json.loads((r/'TAO VA KIEM MAU1.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(b['sample'])==b['sample_sha'] and sha(b['current'])==b['current_sha']
out=dict(sample=b['sample'],sample_sha=b['sample_sha'],source_sha=b['source_sha'],current_sha=b['current_sha'],status='CHƯA ĐẠT HÌNH THỨC',reason='Soi ảnh600dpi: vài khe trắng cuối đuôi mới do mask xóa mực /23 có sẵn vẽ sau nét/25 mẫu1. Đường số có đủneo nhưng mực hiển thị bị che; không tính ĐẠT.',evidence=str(r/'DUOI TRUOC SAU 600dpi.png'),remedy_sample2='Giữ mask hẹp và đúng số, đặt nét/25 sau tất cả lớp mask cũ; chỉ được hai mẫu/phương pháp.',canonical_changed=False)
Path(fresh(r/'MAU1 CHUA DAT HINH THUC.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(out['status'])
