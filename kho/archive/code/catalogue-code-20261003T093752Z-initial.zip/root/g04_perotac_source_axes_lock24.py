"""Lock actual local primary grid and secondary tick stems from printed source."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=base/'DOI CHIEU VACH PHU NGUON THAT'
old=json.loads((root/'TAM VACH NGUON THEO TUNG HANG DON VI V3 CHUA GAN SO.json').read_text(encoding='utf8'));by={r['axis_row']:r for r in old['rows']}
geo=json.loads((base/'KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json').read_text(encoding='utf8'));audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));g=next(z for z in audit['graphs'] if z['family']=='4SA16')
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float);L=a@[.299,.587,.114]
def save_original_verified(image,path):
    if path.exists():
        assert np.array_equal(np.array(Image.open(path)),np.array(image)),str(path)
    else:image.save(fresh(path))
out=[]
for key,vals,yr in [('Q US',list(range(0,100,10)),(148,165)),('Q IMP',list(range(0,90,10)),(164,181))]:
    ticks=by[key]['tick_stem_candidates'];assert len(ticks)==len(vals)
    for tick,val in zip(ticks,vals):
        u=tick['native_weighted_dark_stem_center'];box=[max(112,int(u)-13),yr[0],min(750,int(u)+15),yr[1]]
        # The numeric association is manually read from each individual crop,
        # not asserted solely from being the nth detected stem.
        raw=Image.fromarray(cv.orig[box[1]:box[3],box[0]:box[2]]);save_original_verified(raw.resize((raw.width*12,raw.height*12),Image.Resampling.NEAREST),root/(key.replace(' ','_')+' SO'+str(val)+' VA VACH THUC.png'))
        out.append(dict(axis=key,value_printed=val,source_tick_center_native=u,source_value_and_stem_crop_native_box=box,numeric_label_read_from_its_own_crop=True,source_uncertainty_native_px=.5))
v=(255-L[693:695,124:745]).mean(axis=0);b=float(np.median(v));w=np.maximum(v-b,0);runs=[]
for j in np.flatnonzero(w>25):
    if runs and j==runs[-1][1]+1:runs[-1][1]=int(j)
    else:runs.append([int(j),int(j)])
vals=[0,2.5,5,7.5,10,12.5,15,17.5,20,22.5];assert len(runs)==len(vals)
for (lo,hi),val in zip(runs,vals):
    pp=np.arange(max(0,lo-1),min(len(w),hi+2));ww=w[pp];u=float((pp*ww).sum()/ww.sum()+124);box=[max(112,int(u)-13),690,min(750,int(u)+16),709]
    save_original_verified(Image.fromarray(cv.orig[box[1]:box[3],box[0]:box[2]]).resize(((box[2]-box[0])*12,(box[3]-box[1])*12),Image.Resampling.NEAREST),root/('Q_M3 SO'+str(val).replace('.','-')+' VA VACH THUC.png'))
    out.append(dict(axis='Q M3',value_printed=val,source_tick_center_native=u,source_value_and_stem_crop_native_box=box,numeric_label_read_from_its_own_crop=True,source_uncertainty_native_px=.5))
feet=by['H FEET']['tick_stem_candidates'];assert len(feet)==5
for tick,val in zip(feet,[400,300,200,100,0]):
    y=tick['native_weighted_dark_stem_center'];box=[744,max(175,int(y)-9),786,min(581,int(y)+11)]
    save_original_verified(Image.fromarray(cv.orig[box[1]:box[3],box[0]:box[2]]).resize(((box[2]-box[0])*10,(box[3]-box[1])*10),Image.Resampling.NEAREST),root/('H_FEET SO'+str(val)+' VA VACH THUC.png'))
    out.append(dict(axis='H FEET',value_printed=val,source_tick_center_native=y,source_value_and_stem_crop_native_box=box,numeric_label_read_from_its_own_crop=True,source_uncertainty_native_px=.5))
qx=[r['native_center'] for r in geo['main_observed_vertical_lines']][:8]
qt=[0,3,6,9,12,15,18,21];assert len(qx)==8
hr=g['axis']['H_grid_calibration']['ticks'];primaryq=[dict(Q_m3_h=q,Q_l_min=q*1000/60,native_u=x,source_primary_number_printed=True) for q,x in zip(qt,qx)]
primaryh=[dict(H_m=r['H_m'],native_v=r['v_native'],source_number_printed=True) for r in hr]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==old['source_sha256'] and sha(S.result(name))==old['current_sha256']
doc=dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),primaryQ_actual_local_grid_ticks=primaryq,primaryH_actual_local_grid_ticks=primaryh,
    secondary_units_actual_source_stems=out,source_Q_LMIN_extra_stems_below_eta_frame_none_seen=True,Q_LMIN_numbers_attach_existing_vertical_grid=True,
    source_H_M_extra_unlabelled_stems_none_seen=True,H_M_extra_candidates_from_read18_rejected_digit_tails_not_stems=True,
    source_secondary_stem_count=len(out),source_synthetic_unlabelled_ticks_not_added=True,source_eta_grid_native=geo['source_eta_horizontal_lines'],
    source_axis_fit_global_only_crosscheck_not_node_input=True,source_original_Perotac_X7_only=True,PDF_font_or_progress_written=False)
Path(fresh(root/'VACH PHU34 VA TRUC CUC BO NGUON V4 DE ROOT KIEM.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8');E.close()
print('LOCK 34 SECONDARY STEMS; PRIMARY Q',primaryq,'PRIMARY H',primaryh,flush=True)
