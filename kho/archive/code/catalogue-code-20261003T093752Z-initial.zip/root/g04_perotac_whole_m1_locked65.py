"""One fresh CATFIX M1 save, disabled until ROOT supplies a matching lock.

Default invocation prints CHƯA CHẠY and exits. Never promotes canonical, never
changes source or progress. Saved PDF still needs ROOT independent acceptance.
"""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import argparse,json,hashlib
from g04_perotac_whole_pdf_tools46 import read,sha
from g04_perotac_whole_source_island_builder60 import prepare,NAME,RAM_REL
from g04_perotac_whole_saved_qa63 import post_save

PREP_REL='G04/PHUONG AN DONG BO TOAN BIEU DO P08/M1 WRITER VA QA CHUAN BI CHUA CHAY/KHOA SHA RAM SOURCE9 WRITER QA CHUA CHAY.json'
parser=argparse.ArgumentParser();parser.add_argument('--root-lock');args=parser.parse_args()
if not args.root_lock:
    print('CHƯA CHẠY: writer M1 chờ ROOT khóa nghiệm thu đồ họa đúng SHA; số lần ghi PDF = 0.',flush=True)
    raise SystemExit(0)
prepared_path=Path(S.report(PREP_REL));prepared=read(prepared_path);lock=read(args.root_lock)
assert lock.get('authority')=='ROOT' and lock.get('scope')=='Perotac SA page8 whole chart M1'
assert lock.get('grant_one_fresh_PDF_M1') is True and lock.get('graphic_actual_RAM_approved') is True
assert lock.get('prepared_manifest_sha256')==sha(prepared_path)
assert lock.get('actual_RAM_report_sha256')==prepared['actual_RAM_report_sha256']
for row in prepared['locked_files']:assert sha(row['path'])==row['sha256'],row['path']
assert sha(S.src(NAME))==prepared['source_sha256'] and sha(S.result(NAME))==prepared['canonical_sha256']
ed,R,cv,content,clip_only,report=prepare(S)
assert hashlib.sha256(content).hexdigest()==prepared['prepared_content_sha256']
assert report['source_literal_keys_not_reconstructed']==prepared['source_literal_island_keys']
trial_dir=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/MAU01 TOAN BIEU DO SOURCE9 DAO ROOT CHO PHEP'))
trial_path=Path(fresh(trial_dir/NAME)).resolve()
assert trial_path.parent==trial_dir.resolve() and trial_path.name==NAME
assert trial_path!=Path(S.src(NAME)).resolve() and trial_path!=Path(S.result(NAME)).resolve()
# Exactly one filesystem PDF writer call. CATFIX internally retains all raw
# source image streams and refuses writing over its current input.
ed.save(str(trial_path))
ed.close()
saved=post_save(S,trial_path,report,read(S.report(RAM_REL)),trial_dir)
receipt=dict(ROOT_lock_path=str(Path(args.root_lock).resolve()),ROOT_lock_SHA256=sha(args.root_lock),
    prepared_manifest_sha256=sha(prepared_path),source_sha256=prepared['source_sha256'],canonical_sha256=prepared['canonical_sha256'],
    trial_path=str(trial_path),trial_SHA256=sha(trial_path),filesystem_PDF_save_count=1,
    post_save_technical_checks_pass=saved['technical_checks_pass'],root_graphic_PDF_acceptance_pending=True,
    canonical_not_promoted=True,no_progress_written=True)
Path(fresh(trial_dir/'BIEN NHAN ROOT LOCK VA MOT CATFIX SAVE.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
