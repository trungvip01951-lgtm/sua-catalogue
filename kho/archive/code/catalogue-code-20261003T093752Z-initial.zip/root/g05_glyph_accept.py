from catwork import start,fresh
from pathlib import Path
import json,numpy as np
from PIL import Image
S,D,N=start()
from catfix.recipes import Job
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
old=Job(S.src(name),S.report('G05/NHAP KHONG LUU.pdf'))
new=Job(S.report('G05/HOAN THIEN/'+name),S.report('G05/NHAP KHONG LUU2.pdf'))
ref=old.R.render_canvas(8,(133.9,88.6,143.8,94.3),dpi=600)
parts=old.R.components(ref,ref.box((134.1,88.8,143.6,94.1)),expect=3)
assert len(parts)==3
def normalized(a):
    return np.asarray(Image.fromarray(np.uint8(np.clip(a,0,1)*255)).resize((32,48),Image.Resampling.LANCZOS)).astype(float)/255
answers=[]
for p,r in [(0,(105.5,87.3,116.3,93.5)),(0,(105.5,78.8,116.3,85.0)),
            (3,(99.0,87.0,109.3,93.5)),(3,(99.0,79.1,109.3,86.0)),
            (8,(96.5,88.3,106.7,94.4)),(8,(96.5,80.6,106.7,86.7)),
            (10,(91.0,90.9,101.5,97)),(10,(91.0,83.2,101.5,89.3))]:
    cv=new.R.render_canvas(p,r,dpi=600)
    finalparts=new.R.components(cv,cv.box(r),expect=3)
    cor=[]
    for s,t in zip(parts,finalparts):
        aa=normalized(s['alpha']);bb=normalized(t['alpha'])
        cor.append(float(np.corrcoef(aa.ravel(),bb.ravel())[0,1]))
    rec=dict(page=p+1,rect=r,source_word='316',source_page=9,
             correlations=cor,component_count=len(finalparts),ok=len(finalparts)==3 and min(cor)>.84)
    answers.append(rec);print(rec,flush=True)
Path(fresh(S.report('G05/KIEM CHU 316 DOC LAP.json'))).write_text(json.dumps(answers,ensure_ascii=False,indent=2),encoding='utf-8')
old.close();new.close()
assert all(a['ok'] for a in answers)
