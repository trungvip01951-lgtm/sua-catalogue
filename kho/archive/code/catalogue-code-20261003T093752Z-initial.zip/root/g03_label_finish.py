from catwork import start, fresh
S, D, N = start()
from catfix.vector import Editor
from catfix.cs import Instr
from catfix import verify
from pathlib import Path
import json, numpy as np

root = Path(S.report('G03'))
st = json.loads((root / 'build-state.json').read_text(encoding='utf-8'))
E = Editor(st['destination'])
details = []
for pg in range(3, 11):
    P = E.page(pg - 1)
    curves = [c for c in st['curves'] if c['page'] == pg]
    last = max(c['oi'] for c in curves)
    scale = float(np.sqrt(abs(np.linalg.det(P.objs[last]['ctm'][:2, :2]))))
    ins = []
    for z in curves:
        pp = []
        fill = None
        dx = 45.0 if pg == 7 and z['model'] == '4SA8/8' else 0.0
        for oi in z['label_objects']:
            col = P.objs[oi]['fill']
            if fill is None:
                fill = col
            elif fill != col:
                raise RuntimeError('Màu nhãn không đồng nhất')
            path = P.object_pagepath(oi)
            if dx:
                E.move_object(pg - 1, oi, dx, 0)
                path = E.transform_path(path, dx=dx)
            pp += path
        local = E._to_local(pg - 1, last, pp)
        # Viền chỉ bám theo nét chữ có sẵn; không dùng khối che hình chữ nhật.
        ins += [Instr([], 'q'), Instr([1], 'g'), Instr([1], 'G'),
                Instr([0.75 / scale], 'w')] + local + [Instr([], 'B')]
        ins += [Instr(list(fill[1]), fill[0])] + local + [Instr([], 'f'), Instr([], 'Q')]
        details.append(dict(page=pg, model=z['model'], label_objects=z['label_objects'],
                            template=last, width_page=0.75, fill=fill, dx=dx, dy=0))
    E.insert_instrs(pg - 1, P.objs[last]['i1'] + 1, ins, before=True)
    print('Làm rõ nhãn trang', pg, len(curves), flush=True)
out = fresh(root / 'review' / 'nhan-cuoi.pdf')
E.save(out)
E.close()
json.dump(dict(source=st['destination'], destination=out, details=details),
          open(fresh(root / 'review' / 'nhan-cuoi.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1, default=str)
axis = next(a for a in st['axes'] if a['page'] == 7)
verify.compare_sheet(st['destination'], out,
                     [(6, axis['rect'], 'Trang 7: giãn nhãn 4SA8/8 để không chồng 4SA8/6')],
                     fresh(root / 'review' / 'nhan-cuoi-p7.png'), dpi=300)
print(out, flush=True)
