"""ROOT: đo độc lập5 mốc Perotac từ vạch/mực nguồn riêng, không ghi PDF."""
from catwork import start, fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
import numpy as np
import pymupdf as fitz
from PIL import Image,ImageDraw

base=Path(S.report('G04/ROOT PEROTAC NAM MOC V3'))
assert not base.exists(),base
base.mkdir(parents=True)
source=Path(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf'))
current=Path(S.result(source.name))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(source),sha(current)]
assert before==['3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd','389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c']
# Các giá trị in trên vạch đã ROOT xem trực tiếp ở hình nguồn, không lấy
# H bảng để suy ra trục hay chọn đường. Dò lại tâm mực từng vạch độc lập.
panels=[dict(page=2,family='3SS3',xt=[(v,1368.5+4.78*v) for v in range(0,61,5)],
             yt=[(v,467.4-1.8*v) for v in range(0,161,20)],
             xstrip=(1570,1598),ystrip=(491,531),Q=3.6,
             cases=[('3SS3/37',54,0,2.1)]),
        dict(page=3,family='3SS4',xt=[(v,124.5+6.22*v) for v in range(0,91,10)],
             yt=[(v,571.4-3.2575*v) for v in range(0,121,15)],
             xstrip=(700,738),ystrip=(595,620),Q=5.4,
             cases=[('3SS4/28',36,0,1.0),('3SS4/20',25,2,.9)]),
        dict(page=8,family='4SA16',xt=[(v,124.5+1.553*v) for v in range(0,351,50)],
             yt=[(v,571.5-2.604*v) for v in range(0,151,25)],
             xstrip=(700,738),ystrip=(596,625),Q=21,
             cases=[('4SA16/25',54,0,1.2),('4SA16/20',43,2,1.4)])]

def detect(profile,expected):
    lo=max(0,int(expected)-3);hi=min(len(profile),int(expected)+4)
    a=profile[lo:hi].copy();assert a.max()>3,(expected,a)
    # Trừ nền nén JPEG tại chính dải7pixel, không đổi tâm theo số cần khớp.
    weight=np.maximum(a-float(np.min(a)),0)
    assert weight.sum()>0
    return float(np.average(np.arange(lo,hi),weights=weight))

def mapped(ticks,value):
    for a,b in zip(ticks,ticks[1:]):
        if a[0]-1e-9<=value<=b[0]+1e-9:return a[1]+(value-a[0])*(b[1]-a[1])/(b[0]-a[0])
    raise ValueError(value)

def inverted(ticks,coordinate):
    for a,b in zip(ticks,ticks[1:]):
        if min(a[1],b[1])<=coordinate<=max(a[1],b[1]):return a[0]+(coordinate-a[1])*(b[0]-a[0])/(b[1]-a[1])
    raise ValueError(coordinate)

result=[]
with fitz.open(source) as orig, fitz.open(current) as cur:
    for info in panels:
        page=orig[info['page']-1]
        im=max(page.get_images(full=True),key=lambda z:z[2]*z[3])
        image_pix=fitz.Pixmap(orig,im[0]); assert image_pix.n==3
        raw=np.frombuffer(image_pix.samples,np.uint8).reshape(image_pix.height,image_pix.width,3).copy()
        bbox,matrix=page.get_image_rects(im[0],transform=True)[0]
        def to_page(u,v):return fitz.Point(u/image_pix.width,v/image_pix.height)*matrix
        def to_native(x,y):
            pt=fitz.Point(x,y)/matrix
            return pt.x*image_pix.width,pt.y*image_pix.height
        f=raw.astype(float);gray=f@np.array([.299,.587,.114])
        # Vạch xám trong JPEG có thể lệch kênh màu khi MuPDF giải mã; trung
        # vị dải dài loại mực đường cắt ngang mà không làm mất vạch nhạt.
        darkness=255-gray
        x0,x1=info['xstrip']; y0,y1=info['ystrip']
        hp=np.median(darkness[:,x0:x1],axis=1)
        xp=np.median(darkness[y0:y1,:],axis=0)
        yt=[(v,detect(hp,c)) for v,c in info['yt']]
        xt=[(v,detect(xp,c)) for v,c in info['xt']]
        target_u=mapped(xt,info['Q']*1000/60)
        coordinate=to_page(target_u,0).x
        # Lưu cả trang nguồn và bảng nguyên gốc để ROOT đọc5 ô thật.
        page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(fresh(base/f'NGUON TRANG {info["page"]:02d} 144dpi.png'))
        for label,doc in [('NGUON',orig),('BAN GIAO',cur)]:
            pg=doc[info['page']-1];sc=600/72
            # Ảnh nguồn đã khóa nhãn: tại Q cuối cả5 nét đều nằm dưới H80.
            # Giới hạn này loại khung tên đen ở phần cao, không dùng H bảng
            # để chọn nhánh. Đọc mọi nét thấp còn lại theo độ tương phản.
            lt=to_page(target_u-5,mapped(yt,80));rb=to_page(target_u+7,yt[0][1])
            rect=fitz.Rect(lt,rb)
            p=pg.get_pixmap(matrix=fitz.Matrix(sc,sc),clip=rect,alpha=False)
            rgb=np.frombuffer(p.samples,np.uint8).reshape(p.height,p.width,p.n)[:,:,:3].copy()
            xx=int(round(coordinate*sc))-p.x
            prof=rgb[:,xx].astype(float);chroma=prof[:,1:].mean(1)-prof[:,0]
            gg=prof@np.array([.299,.587,.114])
            # Nét JPEG Perotac có tâm gần xám; lọc màu có thể bỏ nét chính
            # nhưng nhận quầng nén. Tương phản>50 giữ mực chính, loại lưới
            # nhạt và quầng; nối khe tối đa3pixel render (<1pixel ảnh gốc).
            contrast=255-gg
            inds=np.flatnonzero(contrast>50)
            runs=np.split(inds,np.flatnonzero(np.diff(inds)>4)+1) if len(inds) else []
            groups=[]
            for run in runs:
                if len(run)<3:continue
                vc=float(np.average(run,weights=contrast[run]));page_y=(p.y+vc)/sc
                uu,vv=to_native(coordinate,page_y)
                groups.append(dict(render_v=vc,native_v=vv,H_m=inverted(yt,vv),
                                   pixel_interval=[int(run[0]),int(run[-1])],weight=float(contrast[run].sum())))
            picture=Image.fromarray(rgb);draw=ImageDraw.Draw(picture)
            draw.line((xx,0,xx,picture.height-1),fill=(215,15,15),width=1)
            for model,h,rank,unc in info['cases']:
                assert len(groups)>rank,(model,groups)
                g=groups[rank]
                tol=max(1,h*.02);delta=g['H_m']-h
                draw.ellipse((xx-4,g['render_v']-4,xx+4,g['render_v']+4),outline=(215,15,15),width=1)
                result.append(dict(model=model,page=info['page'],file_role=label,Q_m3_h=info['Q'],
                                   H_table=h,H_actual=g['H_m'],delta=delta,tolerance=tol,uncertainty=unc,
                                   result='CHƯA ĐẠT' if abs(delta)-unc>tol else 'CHƯA THỂ XÁC MINH',
                                   curve_rank_from_actual_label=rank+1,
                                   Q_label_grid_native=xt,H_label_grid_native=yt,all_observed_runs=groups,
                                   source_xref=im[0],source_image_bbox=list(bbox),source_image_matrix=list(matrix)))
            picture.save(fresh(base/f'{label} {info["family"]} TIET DIEN Q{info["Q"]} 600dpi.png'))
            print(label,info['family'],'vạchQ',round(target_u,4),'nhómH',[round(g['H_m'],4) for g in groups],flush=True)
assert before==[sha(source),sha(current)]
Path(fresh(base/'ROOT SO DO NAM MOC THUC.json')).write_text(json.dumps(dict(source=str(source),current=str(current),hashes=before,
     records=result,original_and_canonical_not_written=True,
     identity_rule='Thứ tự nét được khóa bằng nhãn trực tiếp trên ảnh; không chọn theo H bảng. Trục từ mực vạch nguồn riêng; không dùng tọa độ Redpump.',
     status='Số đo độc lập; cần ROOT đọc bảng/nhãn/ảnh tiết diện trước chốt'),ensure_ascii=False,indent=2),encoding='utf8')
print([(r['model'],r['file_role'],round(r['H_actual'],4),r['result']) for r in result],flush=True)
