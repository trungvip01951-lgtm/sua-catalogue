from catwork import start, fresh
S,D,N=start()
import pikepdf, json, difflib
from pathlib import Path
root=Path(S.report('G03'))
st=json.loads((root/'build-state.json').read_text(encoding='utf-8'))
paths=[st['source'],st['destination'],str(root/'review'/'Ban truoc lam ro nhan.pdf')]
values=[]
for p in paths:
    with pikepdf.open(p) as pdf:
        m=pdf.Root.get('/Metadata')
        values.append(dict(file=p,xml=m.read_bytes().decode('utf-8','replace') if m is not None else None))
print('\n'.join(difflib.unified_diff(values[0]['xml'].splitlines(),values[1]['xml'].splitlines())))
json.dump(values,open(fresh(root/'metadata-probe.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
