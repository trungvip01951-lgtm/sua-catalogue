"""Read source-caption neighbors and actual fill geometry, RAM only."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from PIL import Image, ImageDraw
from catfix.cs import parse, serialize
from catfix.vector import VPage
from g04_perotac_source9_left_halo_builder70 import prepare, memory_bytes, NAME, ins, polygon, corners
from g04_perotac_whole_pdf_tools46 import read, sha, pixel_at, page_at_pixel
from g04_perotac_whole_actual_read50 import render_document, same_path
import numpy as np, pymupdf as fitz, hashlib, json

base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'RAMV3 CUM CHU VA VACH GAN FULL GLYPH CHI DOC'
ed,R,cv,content,cliponly,report=prepare(S)
blob=memory_bytes(ed,content);axis=read(report['axis_report_path']);words={w['key']:w for w in axis['words']}
P=VPage(parse(content));fill=[]
for expected in report['new_objects']:
    if expected['paint']=='S':continue
    hits=[(oi,obj) for oi,obj in enumerate(P.objs) if obj['op']==expected['paint'] and obj['gs']==report['new_normal_opaque_gs'] and same_path(P.object_pagepath(oi),expected['pagepath'])]
    assert len(hits)==1
    oi,obj=hits[0];path=P.object_pagepath(oi);sample=[];last=None
    for op,points in path:
        if op=='m':last=np.array(cv.to_px(*points[0]));sample.append(last)
        elif op=='l':last=np.array(cv.to_px(*points[0]));sample.append(last)
        elif op=='c':
            c=np.array([last]+[cv.to_px(*p) for p in points]);t=np.linspace(0,1,513)[:,None]
            pp=(1-t)**3*c[0]+3*(1-t)**2*t*c[1]+3*(1-t)*t*t*c[2]+t**3*c[3]
            sample.extend(pp);last=c[-1]
    pp=np.array(sample);bbox=np.r_[pp.min(0),pp.max(0)].tolist()
    intersections=[]
    for island in report['source_literal_islands_all']:
        b=island['source_native_box']
        if min(b[2],bbox[2])>max(b[0],bbox[0]) and min(b[3],bbox[3])>max(b[1],bbox[1]):
            intersections.append(dict(key=island['key'],source_native_box=b,
                min_intersection_native_box=[max(b[0],bbox[0]),max(b[1],bbox[1]),min(b[2],bbox[2]),min(b[3],bbox[3])],
                bbox_intersection_is_conservative_not_full_painted_area=True))
    if intersections:
        fill.append(dict(key=expected['key'],kind=expected['kind'],actual_object_index=oi,actual_sampled_fill_bbox_native=bbox,
            intersected_literal_islands=intersections,actual_path_SHA256=hashlib.sha256(json.dumps(path).encode()).hexdigest(),
            actual_vector_part_inside_literal_islands_excluded_by_new_group_Wstar=True,
            possible_source_vector_join_requires_full_glyph_readback=True))

regions=[('H200 WITH OWN TICK',[745,403,787,424]),('US10 WITH OWN TICK',[169,146,201,168]),
         ('US30 WITH OWN TICK',[287,146,317,168]),('ETA UNIT PLUS60 WITH FRAME',[82,574,132,608])]
photos=[]
with fitz.open(S.src(NAME)) as source,fitz.open(stream=blob,filetype='pdf') as actual:
    for key,b in regions:
        for dpi in [150,600]:
            a,m=render_document(source,7,dpi,list(cv.rect(b)));z,n=render_document(actual,7,dpi,list(cv.rect(b)))
            factor=6 if dpi==150 else 2
            left=Image.fromarray(a).resize((a.shape[1]*factor,a.shape[0]*factor),Image.Resampling.NEAREST);right=Image.fromarray(z).resize(left.size,Image.Resampling.NEAREST)
            tile=Image.new('RGB',(left.width*2+45,left.height+50),'white');dr=ImageDraw.Draw(tile)
            dr.text((7,7),key+f' SOURCE / ACTUAL RAM V3 ({dpi} dpi real render; {factor}x pixel display)',fill='black')
            tile.paste(left,(0,32));tile.paste(right,(left.width+40,32))
            p=Path(fresh(root/(key+f' NGUON ACTUAL THAT{dpi}.png')));tile.save(p)
            photos.append(dict(key=key,dpi=dpi,native_box=b,path=str(p),sha256=sha(p)))
            if key.startswith('ETA') and dpi==600:
                # All pixels in the conservative overlap strip are kept, not
                # ignored as an interior margin or called original font proof.
                changed=np.any(a!=z,axis=2);yy,xx=np.indices(changed.shape)
                pts=np.array([cv.to_px(*page_at_pixel([x+.5,y+.5],m)) for y,x in zip(yy.ravel(),xx.ravel())]).reshape(changed.shape+(2,))
                strip=(pts[:,:,0]>=108)&(pts[:,:,0]<=123)&(pts[:,:,1]>=591)&(pts[:,:,1]<=594)
                eta_seam=dict(source_ETA_UNIT_native_box=words['ETA UNIT']['source_native_box'],
                    source_ETA60_original_word_native_box=words['ETA 60']['source_native_box'],
                    compared_strip_native=[108,591,123,594],all_pixels=int(strip.sum()),changed_pixels=int((changed&strip).sum()),
                    changed_source_dark_pixels=int((changed&strip&(a.min(2)<235)).sum()),
                    source_image_and_vector_join_is_not_full_font_acceptance=True)
doc=dict(stage='READ-ONLY SOURCE + ACTUAL RAM WHOLE CAPTION NEIGHBORS',
    source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)),prepared_content_sha256=hashlib.sha256(content).hexdigest(),
    real_actual_fill_bbox_intersections_with_source_literal_islands=fill,
    sampled_fill_bounds_segments=512,stroke_only_check_does_not_cover_all_filled_glyphs=True,
    ETA_UNIT_ETA60_join=eta_seam,source_actual_images=photos,
    original_font_exact_vector_UNKNOWN=True,source_glyph_or_JPEG_halo_not_inferred_from_alpha_or_area=True,
    no_PDF_source_canonical_font_bank_writer65_or_progress_written=True,saved_PDF_count=0)
p=Path(fresh(root/'CUM CHU VACH VA FILL GLYPH GIAO DAO NGUON RAMV3.json'));p.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
print('FILL INTERSECTIONS',fill,flush=True)
print('ETA SEAM',eta_seam,flush=True)
print('REPORT',p,'SHA256',sha(p),flush=True)
ed.close()
