from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor,union
from catfix.otext import OutlineText,procrustes,Match
from catfix import charts,verify
from g01_fontbank import make_regular
from pathlib import Path
import pickle,copy,collections,json,numpy as np

NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
src=S.result(NAME);E=Editor(src);T=OutlineText(E)
st=pickle.loads(Path(S.report('G02/glyph-doc-dau-vao.pkl')).read_bytes());T.__dict__.update(st);T.E=E
Es=Editor(S.src(NAME));Ts=OutlineText(Es)
Ts.__dict__.update(pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes())['data']);Ts.E=Es
U,F=make_regular(Ts)
refs=[]
for cl in U.clusters:
    if cl['label'] in '0123456789.-':refs.append(cl)

tables=json.loads(Path(S.report('G01/bang-so-da-nghiem-thu-cho-G02.json')).read_text(encoding='utf-8'))
out={}
for ps in tables:
    p=int(ps)-1;P=E.page(p);coarse=(70,70,560,455) if p+1<15 else (55,370,560,755)
    cur=charts.curve_objects(P,coarse,color=(.133,.365,.635))
    # Largest regular lattice gives plot boundaries; blue paths identify the chart's area.
    gx,gy=charts.gridlines(P,coarse)
    gs=T.page_glyphs(p)
    labels=[]
    for g in gs:
        color=P.color_of(g.oi,'fill');cx=(g.bbox[0]+g.bbox[2])/2;cy=(g.bbox[1]+g.bbox[3])/2
        if not(color and max(abs(a-b) for a,b in zip(color,(.133,.365,.635)))<.02 and coarse[0]<=cx<=coarse[2] and coarse[1]<=cy<=coarse[3]):continue
        cand=[]
        for cl in refs:
            if cl['ops']!=g.ops or cl['pts'].shape!=g.pts.shape:continue
            s,R,t,res=procrustes(cl['pts'],g.pts,allow_rotation=True)
            ang=float(np.degrees(np.arctan2(R[1,0],R[0,0])))
            if .25<s<3 and res<.025 and -30<ang<5:cand.append((res,cl['label'],s,ang))
        if cand:
            res,char,sc,ang=min(cand);g.char=char
            labels.append({'char':char,'oi':g.oi,'bbox':g.bbox,'angle':ang,'res':res})
    cb=union(P.objs[oi]['bbox'] for oi in cur)
    # Only labels immediately to the right of the left axis, not the plot title/caption.
    xleft=min(x for x in gx if x>=cb[0]-1)
    lab=[g for g in labels if xleft-3<g['bbox'][0]<xleft+65 and cb[1]-8<g['bbox'][1]<cb[3]+8]
    info={'coarse':coarse,'curve_bbox':cb,'grid':(gx,gy),'curves':[], 'labels':lab,'near_text':[],'table':[]}
    for oi in cur:
        pts=charts.sample_path(P.object_pagepath(oi),n=60)
        info['curves'].append({'oi':oi,'bbox':P.objs[oi]['bbox'],'start':pts[0].tolist(),'end':pts[-1].tolist(),'stroke':P.objs[oi]['stroke'],'lw':P.objs[oi]['lw']})
    for txt,ln in T.text_lines(p):
        b=union(g.bbox for g in ln)
        if coarse[0]-65<b[0]<coarse[2]+25 and coarse[1]-35<b[1]<coarse[3]+15:info['near_text'].append({'text':txt,'bbox':b,'oi':list(set(g.oi for g in ln))})
        if 'SP' in txt and b[1]<(485 if p+1<15 else 370):info['table'].append({'text':txt,'bbox':b})
    out[ps]=info
    print('PAGE',ps,'curves',len(cur),'rows',len(tables[ps]['rows']),'curve_bbox',cb,flush=True)
    print('TICKS',[(t['text'],[round(v,2) for v in t['bbox']]) for t in info['near_text'] if t['text'].replace('.','').isdigit()],flush=True)
    print('LABELS',[(g['char'],round(g['bbox'][0],1),round(g['bbox'][1],1),round(g['angle'],1)) for g in lab],flush=True)
    print('TABLE',info['table'],flush=True)
Path(fresh(S.report('G02/ban-do-chuan.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=1),encoding='utf-8')
T.E=None
Path(fresh(S.report('G02/glyph-doc-chuan.pkl'))).write_bytes(pickle.dumps(T.__dict__))
E.close();Es.close()
