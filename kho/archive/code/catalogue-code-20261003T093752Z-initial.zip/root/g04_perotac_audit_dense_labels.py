from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
E=Editor(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf'));R=Raster(E);root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));out=[]
for family,pi,box in [('4SA6',5,(277,462,341,552)),('4SA8',5,(1152,488,1216,548)),('4SA12',6,(1153,472,1220,539))]:
 im=max(R.images(pi),key=lambda i:i.W*i.H);cv=R.canvas(im);a=cv.orig[box[1]:box[3],box[0]:box[2]];g=a.astype(float)@np.array([.299,.587,.114]);rgb=Image.fromarray(a).resize((a.shape[1]*10,a.shape[0]*10),Image.Resampling.NEAREST);bw=Image.fromarray(np.where(g<135,0,255).astype('uint8')).convert('RGB').resize(rgb.size,Image.Resampling.NEAREST)
 pic=Image.new('RGB',(rgb.width*2+65,rgb.height),'white');pic.paste(rgb,(65,0));pic.paste(bw,(65+rgb.width,0));draw=ImageDraw.Draw(pic)
 for y in range(box[1],box[3]):
  yp=(y-box[1])*10
  if y%5==0:draw.text((3,yp),str(y),fill='red');draw.line((40,yp,64,yp),fill='red')
 pic.save(fresh(root/('NHAN CHONG TOA DO '+family+'.png')))
 cv.work=cv.orig.copy();words=R.ocr(cv,box,scale=8,psm=6);out.append(dict(family=family,box=box,raw=words));print(family,[(w['text'],w['box']) for w in words],flush=True)
Path(fresh(root/'NHAN CHONG OCR NGUYEN.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
