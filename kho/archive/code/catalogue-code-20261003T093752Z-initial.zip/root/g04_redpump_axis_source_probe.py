"""Redpump-only source grids and printed axis bands; raw candidates, no curve acceptance."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import long_vertical_grid_candidates
from PIL import Image
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'));panels=json.loads((root/'DUONG VA NHAN HIEN HANH V2/DINH VI ANH V2.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);records=[]
def runs(ids):
 out=[]
 for i in ids:
  if not out or i-out[-1][-1]>1:out.append([])
  out[-1].append(int(i))
 return out
for p in panels['records']:
 small=p['page'] in [1,2,10,11];a=p['plot_page_rect'];rect=(a[0],310 if small else 240,a[2],a[3]);cv=R.render_canvas(p['page']-1,rect,dpi=300);rgb=cv.orig.astype(float);g=rgb@np.array([.299,.587,.114]);H,W=g.shape
 x0=int(W*.17);x1=int(W*.82);score=(g[:,x0:x1]<130).mean(1);ys=runs(np.flatnonzero(score>.75));hs=[float(np.average(z,weights=score[z])) for z in ys];hys=[cv.to_page(0,y)[1] for y in hs]
 def nearest(want,tol):
  candidates=[(v,y) for v,y in zip(hs,hys) if abs(y-want)<tol]
  assert candidates,(p['family'],want,hys)
  return min(candidates,key=lambda z:abs(z[1]-want))
 top=nearest(508,5);bottom=nearest(371 if small else 322,6);et=nearest(bottom[1]-6,4);eb=nearest(335 if small else 271,8)
 if et[0]>eb[0]:et,eb=eb,et
 yy0=int(et[0]+5);yy1=int(eb[0]-5);assert yy1>yy0
 ids,profile=long_vertical_grid_candidates(g,(0,yy0,W,yy1),height=6,distance=10,prominence=3)
 pix=[float(i) for i in ids];page_x=[cv.to_page(x,0)[0] for x in pix]
 footer=(a[0],310 if small else 240,a[2],eb[1]+5);Image.fromarray(R.render_canvas(p['page']-1,footer,dpi=600).orig).save(fresh(root/'TRUC NGUON RIENG'/f'TRANG {p["page"]:02} {p["family"]} LUU LUONG.png'))
 rec=dict(page=p['page'],family=p['family'],source_SHA256=d['source_SHA256'],render_dpi=300,render_rect=list(cv.rect0),H_frame_top_page=top[1],H_frame_bottom_page=bottom[1],efficiency_top_page=et[1],efficiency_bottom_page=eb[1],vertical_grid_candidates_rendered=pix,vertical_grid_candidates_page=page_x,vertical_grid_strengths=[float(profile[i]) for i in ids],status='CANDIDATE ONLY: match actual printed ticks and distinguish major/minor; no numbers acceptance')
 records.append(rec);print(p['page'],p['family'],'Hframes',round(top[1],3),round(bottom[1],3),'eta',round(et[1],3),round(eb[1],3),'grid',len(ids),flush=True)
E.close();assert before==[sha(d['source']),sha(d['current'])]
Path(fresh(root/'17 TRUC NGUON CANDIDATE.json')).write_text(json.dumps(dict(records=records,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
