from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from pathlib import Path
import json,hashlib
NAME='Aquaris FS_300dpi_75% (bản mới).pdf'
root=Path(S.report('G06'));st=json.loads((root/'build-state-2.json').read_text(encoding='utf-8'))
fresh(S.dst(NAME))
job=S.job(NAME)
originalcontent=job.E.doc.page_content(3)
originalnames=set(job.E.doc.pdf.pages[3].Resources.XObject.keys())
job.E.close()
job.E=Editor(st['stage'])
# Bỏ toàn bộ mẫu sửa chữ chi tiết không đạt; trang 4 dùng lại nguyên nội dung/ảnh gốc.
job.E.doc.set_page_content(3,originalcontent)
xo=job.E.doc.pdf.pages[3].Resources.XObject
for name in list(xo.keys()):
    if name not in originalnames:del xo[name]
job.edits=[e for e in st['edits'] if e['page']==0]
job.E.log=[dict(page=1,kind='raster-native-copy',task=51,old='FS 15 15 1.5',new='FS-35-7-2.2',
                source_page=2,source_model='FS-35-7-2.2',preserve_groups=True,font5_iou=st['font5_iou']),
           dict(task=52,result='CHƯA THỂ XÁC MINH',reason=st['missing52']),
           dict(task=53,result='CHƯA ĐẠT',reason='Hai mẫu ghép nét chưa đẹp, giữ nguyên trang 4 theo điều kiện nhóm'),
           dict(task=136,result='GIỮ NGUYÊN',reason=st['preserve136'])]
job.save()
out=dict(**st,final=job.dst,final_sha256=hashlib.sha256(Path(job.dst).read_bytes()).hexdigest(),
         final_edits=job.edits,final_checks=[c for c in st['checks'] if c['id']==51],log_path=job.log_path,
         kept53='Giữ nguyên trang 4 sau hai mẫu không đạt nét chữ; không đưa mẫu sửa vào file cuối')
json.dump(out,open(fresh(root/'final-state.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
assert hashlib.sha256(Path(job.src).read_bytes()).hexdigest()==st['source_sha256']
job.close()
print('Đã lưu kết quả #51; trang 4 nguyên ảnh/nội dung nguồn',out['final'],flush=True)
