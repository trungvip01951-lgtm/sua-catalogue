"""Read actual source H grid candidates, save printed H axis evidence; no PDF write."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.signal import find_peaks
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'17 TRUC NGUON XY CANDIDATE V4.json').read_text(encoding='utf8'));h=json.loads((root/'17 TRUC NGUON CANDIDATE.json').read_text(encoding='utf8'));v=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(v['source']),sha(v['current'])];assert before==[v['source_SHA256'],v['current_SHA256']]
E=Editor(v['source'],backend='fitz');R=Raster(E);out=[]
for p,z in zip(d['records'],h['records']):
 assert p['family']==z['family'];xl,xr=p['H_frame_x_page'];yb=z['H_frame_bottom_page'];yt=z['H_frame_top_page']
 cv=R.render_canvas(p['page']-1,(xl-16,yb-5,xr+1,yt+5),dpi=600);rgb=cv.orig.astype(float);g=rgb@np.array([.299,.587,.114]);a=cv.to_px(xl+8,0)[0];b=cv.to_px(xr-8,0)[0];prof=255-np.median(g[:,int(a):int(b)],axis=1)
 ids,_=find_peaks(prof,height=4,prominence=3,distance=22);pagey=[float(cv.to_page(0,i)[1]) for i in ids];source=Image.fromarray(cv.orig);xcut=int(cv.to_px(xl+2,0)[0]);photo=source.crop((0,0,xcut,source.height));draw=ImageDraw.Draw(photo)
 for j,y in enumerate(ids):
  draw.line((int(xcut-18),y,int(xcut-2),y),fill=(180,0,180),width=1);draw.text((int(xcut-28),int(y-6)),str(j),fill=(180,0,180))
 file=fresh(root/'TRUC H NGUON DINH VI'/f'TRANG {p["page"]:02} {p["family"]} TRUC H.png');photo.save(file)
 rec=dict(page=p['page'],family=p['family'],H_grid_candidates_page_y=pagey,H_grid_strength=[float(prof[i]) for i in ids],source_photo=str(file),source_dpi=600,source_render_rect=list(cv.rect0),source_SHA256=v['source_SHA256'],status='CANDIDATE: đọc số H thực và loại hàng JPEG/nhãn trước khóa')
 out.append(rec);print(p['family'],len(ids),np.round(pagey,3),flush=True)
E.close();assert before==[sha(v['source']),sha(v['current'])]
Path(fresh(root/'17 TRUC H CANDIDATE.json')).write_text(json.dumps(dict(records=out,source_SHA256=v['source_SHA256'],current_SHA256=v['current_SHA256'],catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
