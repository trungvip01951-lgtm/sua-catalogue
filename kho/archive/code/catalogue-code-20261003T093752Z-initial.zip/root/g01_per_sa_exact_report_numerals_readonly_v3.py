from catwork import start, fresh, HERE
S, D, N = start()
import sys
sys.path.insert(0, str(HERE))
from pathlib import Path
import datetime
import hashlib
import json

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def entry(p, **extra):
    p = Path(p)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=sha(p), **extra)

def num(v):
    return f'{v:.6f}'.replace('.', ',')

O = Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'))
source = Path(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf'))
current = Path(S.result('Perotac bơm giếng SA_compressed (bản mới).pdf'))
assert sha(source) == '3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(current) == '389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
result_file = O / 'g01_KET QUA RA SOAT16 BIEU DO NGOAI TRANG8 - KHONG GHI PDF.json'
assert sha(result_file) == 'dd53f90c937035bac1bb5fb00b8cde840872e3274134022c9f638c281b323076'
result = json.loads(result_file.read_text(encoding='utf-8'))
p31 = next(p for p in result['11_point_final_decisions'] if p['model'] == '3SS3/31')
p23 = next(p for p in result['11_point_final_decisions'] if p['model'] == '4SA12/23')
v2 = O / 'g01_BAO CAO8 COT183 MODEL1827 MOC - BAN DE DOC V2.md'
text = v2.read_text(encoding='utf-8')
old31 = '48,846696 ± 2,259345 m. Biên dưới 46,587351 m'
new31 = f'{num(p31["H_measured_m"])} ± {num(p31["uncertainty_m"])} m. Biên dưới {num(p31["H_measured_m"] - p31["uncertainty_m"])} m'
assert old31 in text
text = text.replace(old31, new31).replace('128,967359 ± 1,509062 m', f'{num(p23["H_measured_m"])} ± {num(p23["uncertainty_m"])} m')
text += '\nBản dễ đọc V3 lấy các số trong đoạn diễn giải trực tiếp từ JSON kết quả, thống nhất với bảng 8 cột. Các số đo, biên bất định và trạng thái trong dữ liệu JSON không thay đổi; V2 được giữ nguyên.\n'
report = Path(fresh(O / 'g01_BAO CAO8 COT183 MODEL1827 MOC - BAN DE DOC V3.md'))
report.write_text(text, encoding='utf-8')
old_manifest_file = O / 'g01_DANH MUC MA KIEM CHINH XAC183 MODEL1827 MOC - V2.json'
assert sha(old_manifest_file) == 'fc352f996fed4d29fcab4d02f42a877b3498d4ccb1138e7d3249c7e449cf50ef'
manifest = json.loads(old_manifest_file.read_text(encoding='utf-8'))
manifest['time_host'] = datetime.datetime.now().astimezone().isoformat()
manifest['authoritative_human_report'] = entry(report)
manifest['previous_manifest'] = entry(old_manifest_file)
manifest['previous_human_report_V2'] = entry(v2)
manifest['own_script_entries'] = [entry(p) for p in sorted(HERE.glob('g01_per_sa_*.py'))]
manifest['output_evidence_files'] = [entry(p, relative_path=str(p.relative_to(O))) for p in sorted(O.rglob('*')) if p.is_file()]
manifest['output_evidence_count'] = len(manifest['output_evidence_files'])
manifest['V3_only_aligns_report_narrative_rounding_with_JSON_without_changing_data'] = True
for e in manifest['output_evidence_files'] + manifest['own_script_entries'] + manifest['inherited_evidence_inputs']:
    assert sha(e['path']) == e['sha256'], e['path']
manifest_file = Path(fresh(O / 'g01_DANH MUC MA KIEM CHINH XAC183 MODEL1827 MOC - V3.json'))
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
back = json.loads(manifest_file.read_text(encoding='utf-8'))
assert sha(source) == back['source']['sha256'] and sha(current) == back['current']['sha256']
print('REPORT', str(report), 'SHA256', sha(report))
print('MANIFEST', str(manifest_file), 'SHA256', sha(manifest_file), 'FILES', back['output_evidence_count'])
print('SOURCE EXACT', json.dumps(dict(model=p31['model'], H=p31['H_measured_m'], uncertainty=p31['uncertainty_m'], H_range=p31['measured_H_range_m'], result=p31['result']), ensure_ascii=False))
