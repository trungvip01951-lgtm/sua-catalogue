from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor,union
from catfix.otext import OutlineText,procrustes
from catfix import charts
from g02_glyphs import chart_refs,group_labels
from pathlib import Path
import pickle,copy,collections,json,numpy as np,hashlib,fitz

NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';src=S.result(NAME);dst=S.dst(NAME,sub='G02 (gồm cả G01)')
E0=Editor(src);T0=OutlineText(E0)
T0.__dict__.update(pickle.loads(Path(S.report('G02/nhan-dung-cho-ve.pkl')).read_bytes()));T0.E=E0
refs=chart_refs(T0)
Es=Editor(S.src(NAME));Ts=OutlineText(Es)
Ts.__dict__.update(pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes())['data']);Ts.E=Es
for p in range(2,32):
    for m in Ts.find(p,'Aquaris S.r.y',rect=(0,0,120,60)):Ts.clusters[m.glyphs[-1].cl]['label']='l'
Ea=Editor(dst);Ta=OutlineText(Ea)
Ta.clusters=copy.deepcopy(Ts.clusters);Ta._buckets=copy.deepcopy(Ts._buckets)
for cl in Ta.clusters:cl['members']=[]
byop=collections.defaultdict(list)
for cl in Ts.clusters:
    if cl['label']!='?':byop[(cl['ops'],len(cl['pts']))].append(cl)
def read_page(p):
    gs=Ta.page_glyphs(p)
    for g in gs:
        g.char=Ta.clusters[g.cl]['label']
        if g.char=='?':
            cand=[]
            for ref in byop.get((g.ops,len(g.pts)),[]):
                s,R,t,res=procrustes(ref['pts'],g.pts,allow_rotation=False)
                if .25<s<3 and res<.03:cand.append((res,ref['label']))
            if cand:g.char=min(cand)[1]
    return gs

plans=json.loads(Path(S.report('G02/ke-hoach-ve.json')).read_text(encoding='utf-8'))
records=json.loads(Path(S.report('G01/nhung-cho-da-sua.json')).read_text(encoding='utf-8'))
g01=[];actual={};all_devs=[]
for p in range(2,32):
    gs=read_page(p);P=Ea.page(p)
    for r in [r for r in records if r['page']==p+1]:
        rect=r['rect'];pad=.6
        gl=sorted([g for g in gs if rect[0]-pad<=sum(g.bbox[::2])/2<=rect[2]+pad and rect[1]-pad<=sum(g.bbox[1::2])/2<=rect[3]+pad],key=lambda g:g.bbox[0])
        txt=''.join(g.char for g in gl);expected=r['new'].replace(' ','')
        ok=txt==expected if r['mode']!='delete' else not gl
        g01.append(dict(**r,readback=txt,ok=ok))
    ps=str(p+1)
    if ps not in plans:continue
    plan=plans[ps];plot=plan['plot'];x0,y0,x1,y1=plot
    # Trục được đọc độc lập từ chữ thật trong PDF ra, rồi ghép với lưới giữ nguyên.
    Ta.glyphs[p]=[g for g in gs if P.color_of(g.oi,'fill')==(.216064,.204102,.208008)]
    xt=charts.ticks_from_labels(Ta,p,(x0-15,y0-36,x1+15,y0-6),'x')
    yt=charts.ticks_from_labels(Ta,p,(x0-48,y0-8,x0-7,y1+8),'y')
    Ta.glyphs[p]=gs
    xt=charts.snap_ticks(xt,plan['gridx'],max_dist=4);yt=charts.snap_ticks(yt,plan['gridy'],max_dist=4)
    assert sorted(v for v,c in xt)==sorted(v for v,c in plan['xticks']),(ps,'x',xt,plan['xticks'])
    assert sorted(v for v,c in yt)==sorted(v for v,c in plan['yticks']),(ps,'y',yt,plan['yticks'])
    ch=charts.Chart.from_ticks(xt,yt,max_res=.6)
    residual=[max(abs(ch.to_page(v,0)[0]-c) for v,c in xt),max(abs(ch.to_page(0,v)[1]-c) for v,c in yt)]
    assert ch.warning is None and max(residual)<=.6,(ps,residual,ch.warning)
    cur=charts.curve_objects(P,(x0-3,y0-3,x1+3,y1+3),color=(.133,.365,.635))
    assert len(cur)==len(plan['table']),(ps,len(cur),len(plan['table']))
    found=[]
    for oi in cur:
        path=P.object_pagepath(oi);pagepts=charts.sample_path(path,n=500);datapts=ch.to_data(pagepts)
        found.append((float(datapts[0,1]),oi,path,datapts))
    found.sort(reverse=True,key=lambda r:r[0]);expected=sorted(plan['table'],key=lambda r:-r['H'][0]);rows=[]
    labels,unknown=group_labels(Ta,p,plot,refs)
    assert not unknown,(ps,'unknown',[(g.oi,g.char) for g in unknown])
    wanted={r['newlabel'] for r in plan['curves']}
    assert len(labels)==len(expected) and {l['text'] for l in labels}==wanted,(ps,'labels',[l['text'] for l in labels],wanted)
    for (h0,oi,path,datapts),row in zip(found,expected):
        original=next(r for r in plan['curves'] if r['model']==row['model'])
        style=P.objs[oi];styleok=style['stroke']==tuple([original['color'][0],tuple(original['color'][1])]) and style['lw']==original['lw']
        # JSON chuyển tuple sang list; phép so màu đọc nguyên trạng từ paint object.
        styleok=list(style['stroke'][1])==original['color'][1] and style['stroke'][0]==original['color'][0] and style['lw']==original['lw']
        src_oi=original['oi'] if original['oi'] is not None else plan['curves'][0]['oi']
        old_style=E0.page(p).objs[src_oi]
        styleok=styleok and style['dash']==old_style['dash'] and style['op']==old_style['op']
        points=[]
        for q,h in zip(row['Q'],row['H']):
            hc=ch.value_at(datapts,q);assert hc is not None,(ps,row['model'],q)
            delta=float(hc-h);tol=max(1,.02*abs(h))
            dev=dict(page=p+1,model=row['model'],Q=q,H_table=h,H_curve=hc,diff=delta,tolerance=tol,ok=abs(delta)<=tol)
            points.append(dev);all_devs.append(dev)
        end=[[float(datapts[0,0]),float(datapts[0,1])],[float(datapts[-1,0]),float(datapts[-1,1])]]
        er=max(abs(end[0][0]-row['Q'][0]),abs(end[0][1]-row['H'][0]),abs(end[1][0]-row['Q'][-1]),abs(end[1][1]-row['H'][-1]))
        monotone=bool(np.all(np.diff(datapts[:,0])>=-1e-6) and np.all(np.diff(datapts[:,1])<=1e-6))
        ok=styleok and er<.002 and monotone and all(d['ok'] for d in points)
        rows.append(dict(model=row['model'],oi=oi,label=original['newlabel'],color=list(style['stroke'][1]),lw=style['lw'],style_ok=styleok,endpoints=end,endpoint_max_error=er,monotone=monotone,max_deviation=max(abs(d['diff']) for d in points),points=points,ok=ok))
    actual[ps]=dict(page=p+1,curves=rows,curve_count=len(rows),labels=[l['text'] for l in labels],axis_warning=ch.warning,axis_residual=residual,xticks=xt,yticks=yt,ok=all(r['ok'] for r in rows))
    print('ĐỌC LẠI ĐẠT',ps,'đường',len(rows),'điểm',sum(len(r['points']) for r in rows),'lệch',round(max(r['max_deviation'] for r in rows),6),'G01',sum(r['ok'] for r in g01 if r['page']==p+1),flush=True)
before=fitz.open(src);after=fitz.open(dst)
meta=dict(metadata=before.metadata==after.metadata,xml=before.get_xml_metadata()==after.get_xml_metadata(),bookmarks=before.get_toc()==after.get_toc(),pages=len(before)==len(after),page_sizes=all(tuple(a.rect)==tuple(b.rect) for a,b in zip(before,after)))
def linkdata(doc):return [[{k:(list(v) if isinstance(v,fitz.Rect) else v) for k,v in lk.items() if k not in ['xref','id']} for lk in p.get_links()] for p in doc]
meta['links']=linkdata(before)==linkdata(after)
before.close();after.close()
bad=[r for r in g01 if not r['ok']];hashes=dict(original=hashlib.sha256(Path(S.src(NAME)).read_bytes()).hexdigest(),g01_input=hashlib.sha256(Path(src).read_bytes()).hexdigest(),g02_output=hashlib.sha256(Path(dst).read_bytes()).hexdigest())
assert hashes['original']=='c56abd03329bbe9469156196e2da7782d07a66f60b685c4c9f4b3d74b45ed785'
assert hashes['g01_input']=='d1ba36df84342b3949f445dee82abc557240bf099ef98002319614a080108dae'
result=dict(ok=not bad and all(meta.values()) and all(p['ok'] for p in actual.values()),charts=actual,points=all_devs,protected_g01=g01,protected_g01_bad=bad,meta=meta,hashes=hashes,max_deviation=max(abs(d['diff']) for d in all_devs),max_endpoint_error=max(r['endpoint_max_error'] for p in actual.values() for r in p['curves']))
Path(fresh(S.report('G02/nghiem-thu-doc-lap.json'))).write_text(json.dumps(result,ensure_ascii=False,indent=1),encoding='utf-8')
print('KẾT QUẢ',result['ok'],'21 biểu đồ',len(actual),'đường',sum(p['curve_count'] for p in actual.values()),'điểm',len(all_devs),'G01',sum(r['ok'] for r in g01),'/',len(g01),'sai',[(r['task'],r['page'],r['readback'],r['new']) for r in bad],'lệch max',result['max_deviation'],'đầu/cuối max',result['max_endpoint_error'],meta,hashes,flush=True)
Ea.close();E0.close();Es.close()
