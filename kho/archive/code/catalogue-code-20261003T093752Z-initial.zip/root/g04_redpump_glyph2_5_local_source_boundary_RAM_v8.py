"""Observed SL small glyph edge correction2/5 only. RAM geometry; no PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import copy,json,hashlib,sys,numpy as np,cv2
from scipy.ndimage import gaussian_filter,distance_transform_edt
from PIL import Image,ImageDraw
sys.path.insert(0,str(HERE))
from g04_source_observed_mask_contour_math import source_mask_contours
from g04_source_glyph_core_math import topology
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
F=M/'CHU2 5 BIEN MUC CUC BO RAM V8B'
assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
prev=J(M/'CHU5 9 BIEN QUAN SAT RAM V7/12 GLYPH RAM V7 BIEN5 9 MOT MAU.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
external=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-kiem-mau-perotac-redpump\outputs\wc_sample_graphics_SL_V7_report.md')
changes=[];pad=8;up=8
def smoothstep(x):
    t=np.clip(x,0,1);return t*t*(3-2*t)
def band(x,left,right,edge=2.):
    return smoothstep((x-left+edge)/edge)*smoothstep((right+edge-x)/edge)
for ch in ['2','5']:
    old=next(r for r in prev['records'] if r['character']==ch)
    alpha=np.asarray(old['source_alpha'],float)
    A=np.pad(alpha,pad);yy,xx=np.indices(A.shape);y=yy-pad;x=xx-pad
    if ch=='5':
        sigma=1.1;field=gaussian_filter(A,sigma)
        levels=np.full_like(A,.30)
        # Source midbar has one dark row with gray edges; the right body has a
        # one-pixel dark center. Raise these local edge cuts without scaling.
        middle=band(y,11,20,edge=2.)*band(x,3,23,edge=2.)
        right=band(y,18,31,edge=2.)*smoothstep((x-10)/4)
        levels+=np.maximum(.095*middle,.105*right)
        # The observed bottom connecting arc is gray, keep its source edge.
        footer=band(y,30,35,edge=1.5)
        levels-=.035*footer
        note='Nguồn5 p8/25. Thu biên giữa/phải tới dải mực tối riêng; giữ cung dưới xám nguồn. Không co glyph, không ép tổng mực, không close.'
    else:
        sigma=1.0;field=gaussian_filter(A,sigma)
        levels=np.full_like(A,.30)
        bulge=band(y,11,18,edge=2.)*smoothstep((x-13)/3)
        levels+=.095*bulge
        # The source shows a weak narrow neck directly below the dark cap.
        # Lower only that observed bridge instead of morphological closing3.
        neck=band(y,9,12.5,edge=1.5)*band(x,11.5,17,edge=1.5)
        levels-=.09*neck
        note='Nguồn2 p5/62. Bỏclose3; đọc lại biên dải chuyển đầu–thân từmực yếu nguồn và giảm khối phồng phải. Không đổi cỡ/advance/màu.'
    mask=field>=levels
    topo=topology(mask)
    diagnostics=dict(character=ch,source_page=old['source_page'],source_word=old['source_word'],source_page_box=old['source_page_box'],
        source_alpha=alpha.tolist(),source_field=field.tolist(),local_levels=levels.tolist(),mask=mask.tolist(),topology=topo,
        method=note,no_morphological_closing=True,no_mass_target=True,no_scale_or_advance_change=True)
    print('MASK',ch,'topology',topo,'pixels',int(mask.sum()),flush=True)
    if topo!=(1,0):
        Path(fresh(F/f'{ch} MASK CHUA THE LIEN NET.json')).write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2),encoding='utf8')
        raise RuntimeError('Source local edge mask does not support one continuous glyph; stop this candidate')
    loops,area,actual=source_mask_contours(mask,pad=pad,up=up,curvy=False,epsilon=1.5,radius=.9,expected=(1,0))
    # This field is a geometry hypothesis within the source JPEG, not a font
    # program reconstruction. Preserve weak-edge uncertainty explicitly.
    weak=cv2.resize((A>=.085).astype('uint8'),(actual.shape[1],actual.shape[0]),interpolation=cv2.INTER_NEAREST).astype(bool)
    missing=float(distance_transform_edt(actual==0)[weak].max()/up*.12)
    extra=float(distance_transform_edt(~weak)[actual>0].max()/up*.12)
    pyy,pxx=np.where(actual)
    bbox=[float(pxx.min()/up-pad),float(pyy.min()/up-pad),float((pxx.max()+1)/up-pad),float((pyy.max()+1)/up-pad)]
    z=copy.deepcopy(old);coverage=1-63/255
    z.update(vector_optical_area_px=area*coverage,parts=[dict(source_part=1,loops=loops,kind='local_observed_source_edge_contour',
        source_smoothing_sigma_px600=sigma,source_smoothing_sigma_pt=sigma*.12,levels=levels.tolist(),
        local_source_regions=dict(middle=[2,11,18,20],right_body=[13,18,18,33]) if ch=='5' else dict(right_transition=[10,9,20.3,19]),
        close_px600=0,source_mass_px=float(alpha.sum()),loop_area_px=area,relative_math_ink_error=float(area*coverage/alpha.sum()-1),
        actual_vector_bbox600=bbox,topology=[1,0],source_weak_alpha_point085_missing_distance_pt=missing,
        source_weak_alpha_point085_extra_distance_pt=extra,max_contour_fit_error_px600=max(lp['max_contour_fit_error_px600'] for lp in loops),
        no_mass_tightening=True,no_geometry_scale=True,method_note=note,status='ỨNG VIÊN RAM; cần soi vùng mực nguồn và13 tên, chưa fontPASS.')])
    changes.append(z)
    H,W=alpha.shape;core=(255-192*actual.astype(float)).clip(0,255).astype('uint8')
    candidate=Image.fromarray(core).crop((pad*up,pad*up,(pad+W)*up,(pad+H)*up)).convert('RGB')
    oldpoly=np.zeros_like(actual)
    from g04_source_glyph_source_edge_math import sample_path
    for part in old['parts']:
        pts=[np.rint((sample_path(q['path'],64)+pad)*up).astype('int32') for q in part['loops']]
        cv2.fillPoly(oldpoly,pts,1)
    oldimage=Image.fromarray((255-192*oldpoly.astype(float)).clip(0,255).astype('uint8')).crop((pad*up,pad*up,(pad+W)*up,(pad+H)*up)).convert('RGB')
    sourceimage=Image.fromarray(np.round(255*(1-alpha)).clip(0,255).astype('uint8')).convert('RGB')
    sheet=Image.new('RGB',(1450,700),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(17)
    dr.text((5,5),f'{ch} nguồn nhỏ thật / V7 / RAM V8 - cùngmàu63, chưa PDF2',fill='blue',font=ft)
    for label,img,position in [('Nguồn',sourceimage,30),('V7',oldimage,430),('V8 ứngviên',candidate,830)]:
        dr.text((position,35),label,fill='blue',font=ft)
        sheet.paste(img.resize((W*10,H*10),Image.Resampling.NEAREST if label=='Nguồn' else Image.Resampling.LANCZOS),(position,65))
    dr.text((5,520),f'Khôngscale/close/ép mực. Δmực{z["vector_optical_area_px"]/z["source_area_px"]-1:+.4f}; contour chọnfit{z["parts"][0]["max_contour_fit_error_px600"]*.12:.4f}pt\nToànmép JPEG yếu thiếu{missing:.4f}pt; không khẳngđịnh mọi biên≤1nativepixel.',fill='blue',font=ft)
    sheet.save(fresh(F/f'{ch} NGUON V7 V8 BIEN CUC BO RAM KHONG PDF.png'))
    Path(fresh(F/f'{ch} NGUON MASK VA BIEN CUC BO RAM V8.json')).write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2),encoding='utf8')
out=copy.deepcopy(prev);changed={z['character']:z for z in changes}
out['records']=[changed.get(z['character'],z) for z in prev['records']]
assert next(z for z in out['records'] if z['character']=='9')==next(z for z in prev['records'] if z['character']=='9')
out.update(RAM_variant='V8_source_local2_5_no_morph_close_other10and9V7unchanged',
    previous_bank=str(M/'CHU5 9 BIEN QUAN SAT RAM V7/12 GLYPH RAM V7 BIEN5 9 MOT MAU.json'),
    previous_graphics_report=str(external),previous_graphics_report_SHA256=sha(external),
    common_gray=63,core_gray=63,opacity=1,no_mass_tightening=True,
    status='ỨNG VIÊN RAM; hình thức còn cần ROOT/đồhọa đọc. Không PDF2/canonical/TIEN DO.',
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False)
fp=Path(fresh(F/'12 GLYPH RAM V8 BIEN2 5 MOT MAU GIU9V7.json'))
fp.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print('RAM BANK',str(fp),'SHA256',sha(fp),flush=True)
