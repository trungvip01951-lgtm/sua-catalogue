"""Source-only axis locks from actual printed labels inspected in 17 photos."""
from catwork import start,fresh
S,D,N=start()
import json,hashlib,numpy as np
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import fit_observed_ticks
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
v=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'));qq=json.loads((root/'17 TRUC Q DOC NGUON RIENG.json').read_text(encoding='utf8'));hh=json.loads((root/'17 TRUC H CANDIDATE.json').read_text(encoding='utf8'))
configs={
 '2SL0.7':(list(range(12)),list(range(55,-1,-5))),
 '2.5SL1.5':(list(range(10)),list(range(90,-1,-10))),
 '3SL2':([0,2,3,4,5,6,8,9],list(range(210,-1,-30))),
 '3SL3':([0,2,3,4,5,6,7,8,9],list(range(160,-1,-20))),
 '3SL4':(list(range(9)),list(range(120,-1,-15))),
 '4SL2':([0,1,2,3,4,5,6,9,11],list(range(480,-1,-60))),
 '4SL3':([0,1,2,3,4,7,11],list(range(450,-1,-75))),
 '4SL4':([0,2,3,4,5,6,7,9,11],list(range(480,-1,-60))),
 '4SL6':([0,1,2,3,4,5,6,8,11],list(range(400,-1,-50))),
 '4SL8':([0,1,2,3,4,5,8],list(range(300,-1,-50))),
 '4SL10':([0,10],[240,0]),
 '4SL12':([0,1,2,3,4,5,6,8],list(range(210,-1,-30))),
 '4SL16':([0,2,3,4,6,8,9],list(range(150,-1,-25))),
 '6SL15':([0,2,3,4,5,7,8,10,11],list(range(360,-1,-45))),
 '6SL25':([0,2,3,4,5,6,7,9,10],list(range(320,-1,-40))),
 '6SL35':([0,1,2,3,4,5,7,10,12,14,15],list(range(300,-1,-30))),
 '6SL45':([0,1,2,3,4,5,6,8,10,11],list(range(225,-1,-25)))}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(v['source']),sha(v['current'])];assert before==[v['source_SHA256'],v['current_SHA256']]
E=Editor(v['source'],backend='fitz');R=Raster(E);out=[]
for qa,ha in zip(qq['records'],hh['records']):
 assert qa['family']==ha['family'];name=qa['family'];ids,heads=configs[name];ys=[ha['H_grid_candidates_page_y'][i] for i in ids];f=fit_observed_ticks(heads,ys);qfit=qa['fit'];C=[qfit['slope'],qfit['intercept'],f['slope'],f['intercept']]
 base=max(R.images(qa['page']-1),key=lambda z:z.W*z.H);dx=abs(base.to_page(1,0)[0]-base.to_page(0,0)[0]);dy=abs(base.to_page(0,1)[1]-base.to_page(0,0)[1])
 qrec=dict(slope_pt_per_m3h=qfit['slope'],intercept_pt=qfit['intercept'],residuals_pt=qfit['residuals'],max_residual_pt=qfit['max_residual_px'])
 hrec=dict(slope_pt_per_m=f['slope'],intercept_pt=f['intercept'],residuals_pt=f['residuals'],max_residual_pt=f['max_residual_px'])
 rec=dict(page=qa['page'],family=name,axis=C,Q=qrec,H=hrec,Q_printed_values=qa['printed_values'],Q_printed_tick_page_x=qa['printed_tick_page_x'],H_printed_values_used=heads,H_printed_grid_page_y=ys,H_selected_candidate_indices=ids,H_printed_intermediate_values_not_assigned_to_grid=[200,160,120,80,40] if name=='4SL10' else [],source_image_shape=[base.W,base.H],source_image_bbox=list(base.page_bbox),source_image_ctm=base.ctm.tolist(),native_pixel_pt=[dx,dy],H_native_resolution_m=dy/abs(C[2]),Q_native_resolution_m3h=dx/abs(C[0]),Q_source_photo=qa['source_photo'],H_source_photo=ha['source_photo'],source_SHA256=v['source_SHA256'],current_SHA256=v['current_SHA256'],two_H_anchors_only=name=='4SL10',uncertainty_rule='Chỉ hai neo H thì residual0 không có nghĩa uncertainty0: giữ tối thiểu nửa pixel khung, nửa bề rộng mực và sai số lấy mẫu; sai sốQ đổi sangH theo dH/dQ đo trên mực. Không ghép nhãn H vào hàng lưới khác bước.',scope='Nguồn Redpump riêng, đủ các số chia thực dùng fit; chưa thay cho đọc từng đường.')
 out.append(rec);print(name,'axis',np.round(C,6),'Q/Hres',round(qrec['max_residual_pt'],5),round(hrec['max_residual_pt'],5),'nativeH/px',round(rec['H_native_resolution_m'],5),flush=True)
E.close();assert before==[sha(v['source']),sha(v['current'])]
Path(fresh(root/'17 TRUC DOC NGUON RIENG KHOA V1.json')).write_text(json.dumps(dict(records=out,source_SHA256=v['source_SHA256'],current_SHA256=v['current_SHA256'],catalogue_written=False,raw_helper_field_units_note='Trong17 TRUC Q DOC NGUON RIENG.json tên max_residual_px của helper nhận dữ liệuPAGEpt; giá trị có đơn vịpt. Hồ sơ khóa này đổi tên rõmax_residual_pt, không đổi số đo.'),ensure_ascii=False,indent=2),encoding='utf8')
