"""Read exact source fields and local contours. No bank/PDF/progress writes."""
from catwork import start
S,D,N=start()
from g04_perotac_whole_pdf_tools46 import read
from pathlib import Path
import numpy as np
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
doc=read(base/'CHU TRUC NGUON VA RAM CHI DOC/DON VI DAU CHAM DAU GACH CHEO VA i NGUON V2/CHU TRUC DAU NHO DOC RIENG V2 RAM CHUA NGHIEM THU.json')
alpha=read(base/'CHU TRUC FAIL DOC RIENG NGUON V3/ALPHA TUNG NET DUNG NGUON/ALPHA CHU TRUC TUNG FIELD NGUON.json')
for r in alpha['records']:
    print(r['key'],r['source_native_box'],flush=True)
    a=np.asarray(r['alpha'])
    for y,row in enumerate(a):
        if r['key'] in ['Q US 10','Q LMIN 150','M3 UNIT','ETA UNIT']:
            print(y,' '.join(f'{v:.2f}' for v in row),flush=True)
    word=next(w for w in doc['words'] if w['key']==r['key'])
    print('CONTOURS',[(p['parent'],np.r_[np.asarray(p['local_native_xy']).min(0),np.asarray(p['local_native_xy']).max(0)].round(3).tolist()) for p in word['contour_paths']],flush=True)
