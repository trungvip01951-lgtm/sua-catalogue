"""Lập kế hoạch đầy đủ, không dựng hình mẫu hay ghi catalogue."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
import json, hashlib, numpy as np

name='Perotac bơm giếng SA_compressed (bản mới).pdf'
src,current=S.src(name),S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
info=json.loads((folder/'104 O NGUON VA PHAM VI DONG BO CHI DOC.json').read_text(encoding='utf8'))
measure=json.loads((folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'))
fonts=json.loads((folder/'PHONG VA CHU NGUON CHI DOC.json').read_text(encoding='utf8'))
assert sha(src)==info['source_sha256'] and sha(current)==info['current_sha256']
assert not measure['eta_source']['ambiguous_branches']
assert len(measure['numeric_plan_104_cells'])==13
assert sum(len(z['source_H_m']) for z in measure['numeric_plan_104_cells'])==104
assert fonts['same_file_embedded_font_candidate_count']==0
E=Editor(src,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im)
axis=info['axis_previously_read']; flow=axis['calibration'];head=axis['H_grid_calibration']; step=measure['source_pixel_to_page_pt']
edit=[65,117,790,805]
rows=[]
for idx,p in enumerate(measure['numeric_plan_104_cells']):
    model=p['model'];suffix=model.split('/')[-1]
    q0,h0=p['starts_at_literal_QH'];q1,h1=p['ends_at_literal_QH']
    ux=lambda q:flow['u_Q0']+flow['u_per_l_min']*q*1000/60
    vy=lambda h:head['v_H0']+head['v_per_m']*h
    col=idx//5;line=idx%5
    legend_pos=[float(140+col*(621.5/3)),float(744+line*14)]
    end_key_center=[710.0,float(562-idx*12)]
    rows.append(dict(p,source_literal_label='4SA16/'+suffix,curve_end_key='/'+suffix,
                     actual_source_table_display_spacing_does_not_change_model=True,
                     numeric_native_start=[ux(q0),vy(h0)],numeric_native_end=[ux(q1),vy(h1)],
                     proposed_end_key_native_center=end_key_center,
                     legend_column_0based=col,legend_row_0based=line,legend_native_baseline=legend_pos,
                     leader_is_annotation_not_extra_pump_performance=True,
                     planned_QH_RGB=[127,145,150],planned_QH_pen_width_pt=0.90))
previously_accepted=[p for p in rows if p['model'] in ['4SA16/23','4SA16/18']]
assert len(previously_accepted)==2
dash_intervals_native=[[124.54166666666664,139.5],[145.5,160.5],[167.5,182.5],[188.5,203.5],[210.5,225.5],[231.5,246.5],[253.5,268.5]]
asq=lambda u:(u-flow['u_Q0'])/flow['u_per_l_min']*60/1000
method=dict(
    name='Dựng đồng bộ toàn biểu đồ: đúng bảng, nguồn glyph chính Perotac, nét PDF thật',
    new_method_not_patch_trial3=True,trial_count_new_method=0,
    source_background='Nền giấy của riêng X7 nguyên JPEG Perotac; được thay đồng bộ trong hộp toàn biểu đồ, không dùng ảnh Redpump/patch cũ làm nguồn.',
    erase_method='Đọc mực hiện hành để xóa toàn bộ phần biểu đồ cũ trong vùng được phép, gồm ảnh/nét/nhãn/lưới cũ và 2 đường vector đã nghiệm thu. Lưu 11 JPEG gốc đúng byte. Miếng nền không mất dữ liệu + SMask chỉ ở pixel cần đổi; không nén lại ảnh nguyên trang.',
    old_accepted_vector_handling='Khóa các đối tượng thật /23,/18 theo hồ sơ đã duyệt rồi bỏ chúng trong PDF mẫu, hoặc đặt mặt nạ đủ phủ mọi mực cũ; không để nét cũ nằm lẫn với 13 đường mới. Bản giao hiện tại giữ nguyên.',
    complete_layer_order='Xóa mực cũ/nền nguồn → toàn lưới/vạch/khung PDF thật → 13 Q–H PDF thật + η bám nguồn → chữ/nhãn/đường dẫn chú giải. Đặt sau mọi mặt nạ sẵn có.',
    line_RGB=[127,145,150],line_width_pt=0.90,
    color_basis='Trung vị lõi mực 13 đường trên chính X7: RGB 127/145/150; η127/146/150. Gộp cùng màu xanh xám nguồn để đồng đều, xin ROOT xét lựa chọn thiết kế này.',
    width_basis='Trung vị độ dày tương đương nguồn 0,90056pt, từng đường0,8220–0,9252pt; chọn một bút0,90pt. Đây là đo JPEG tương đương, không gọi là bút PDF gốc.',
    head_dash='Giữ quy ước đầu đường nét đứt; dùng chu kỳ đồng bộ theo các khoảng mực nguồn được đo trực tiếp. Nét liền bắt đầu sau khe cuối quan sát được, không tự chuyển toàn đường thành nét liền.',
    source_dash_intervals_native=dash_intervals_native,
    source_dash_intervals_Q_m3_h=[[max(0,asq(a)),asq(b)] for a,b in dash_intervals_native],
    proposed_solid_start_native_u=275.5,proposed_solid_start_Q_m3_h=asq(275.5),
    dash_limit='Dữ liệu lõi JPEG có khe giả1–2px. Dùng chu kỳ của12 đường nguồn quan sát đủ; /18 chỉ bám được từu253 trong phép dò màu này, cần xem ảnh đầu nét nguyên ở600dpi trước khi nhận quy ước chung.',
    interpolation='PCHIP giảm từng đoạn từ8 số của từng model; đúng104 số tại nút, không ngoại suy Q<0/Q>21. Không dùng đường nguồn sai làm mục tiêu nội suy.',
    eta='558 cột mực nguồn u127..684; không có nhánh mơ hồ sau gộp hai quầng JPEG thuộc cùng nét. Khớp nét trơn trong sai số mực nguồn; η không được nhận đạt số liệu vì không có bảng.',
    eta_source_endpoints=measure['eta_source']['first_observed'],
    eta_source_last=measure['eta_source']['last_observed'],
    eta_frame='Giữ khung/đơn vị/nhãn0,20,40,60% đúng vị trí nguồn; không tự bổ sung nhãn70% hay mốc η ngoài nguồn.',
    curve_identity='Mỗi đường mới và suffix/chú giải lấy cùng một bản ghi literal của bảng; không ghép model theo thứ hạng, công suất hoặc nét gần H. Có13model; không có/7.',
    note_legacy_unknowns='7 danh tính nét cũ và235mốc cũ chưa rõ không biến thành đạt. Phương pháp mới dựng từ bảng riêng từng model; sẽ nghiệm thu104mốc mới thực tế. Các biểu đồ khác chưa được vẽ/nghiệm thu.',
    same_file_font_strategy='Không có phông nhúng. Dùng glyph chữ/số và cả từ đã có trong chính X7/Perotac. Caption4SA16 có đủ0–9,4,S,A,slash. Dựng đường bao mực nguồn thành vector bằng catfix; không nhận một phông bên ngoài là cùng kiểu.',
    glyph_guard='Lấy dạng chữ gốc ở150dpi, dựng biên có khử răng cưa giữ tỉ lệ rộng/cao/đường cơ sở/lỗ chữ. Một ngân hàng mẫu chung cho tên model/suffix để nét lặp đồng nhất. Đơn vị/nhãn trục/tiêu đề học riêng từ chính chữ nguồn cùng vị trí. Kiểm đối chứng ít nhất2ký tự chung và toàn từ ở độ phân giải nguồn+600dpi; nếu sai hình/đậm/cỡ, mẫu không đạt. Chưa tạo glyph vector mẫu trong hồ sơ kế hoạch này.',
    glyph_sharpness_limit='Ảnh gốc150dpi không có mô tả phông liên tục, nên không thể khẳng định việc vector hóa chữ sẽ tự đẹp. ROOT và tác nhân đồ họa cần xét mẫu trước khi ghi bản giao; không lách bằng phông hệ thống.',
    axes='Giữ hệ trục và vị trí vạch nguồn: H0..150m, các nhãn25m; l/min0..350; m³/h0..22,5; USgpm0..90, Impgpm0..80; feet0/100/200/300/400. Không thêm số tận cùng không in trong nguồn.',
    labels='Giữ chữ đúng nguồn, kể cả Total dynamic head H(m), Flow rate Q, Eta(%), l/min,m³/h,USg.p.m,Imp g.p.m,feet. Bản kế hoạch tiếng Việt giải thích đơn vị; trong catalogue giữ nguyên chữ nguồn.',
    legend='13tên đầy đủ từ bảng nguồn, 3cột×5hàng trong khoảng trắng dưới trục Q, 3hàng cột cuối. Curve-end suffix /4../25 có đường dẫn chú giải mảnh và khác nét Q–H, không kéo dài đường bơm sauQ21.',
    leader_guard='Các suffix x≈710, tâm y562−12×chỉsố0..12; giữ đúng thứ tự bảng. Đường dẫn cùng thứ tự, không giao nhau; tách rõ khỏi bút Q–H, không chạm feet/lưới/η/khung. Nếu gây hiểu nhầm đuôi bơm, mẫu không đạt.',
    text_size='Đề xuất độ cao mực chữ thường/số≈4,0pt, giữ tỉ lệ glyph; bước hàng chú giải6,72pt. Đây là kích thước hình mực vì nguồn không có thông số FontSize.',
    grid='Cùng vị trí vạch nguồn đã đọc; lưới x/y toàn vector. Đề xuất khung đen0,55pt, lưới xám0,20pt, Q–H/η0,90pt, đường dẫn chú giải0,30pt. Không dùng nén JPEG cho một đoạn lưới còn vector cho đoạn khác.',
    planned_graphics_acceptance='ROOT/tác nhân đồ họa đánh giá toàn trang ở100%, biểu đồ ở200–300%, chữ và lưới ở600dpi: không chồng, không mờ/đậm xen, không vết vá; cả khung/chữ/lưới phải đồng đều.',
    max_failed_trials_per_method=2,ROOT_plan_review_before_trial=True,canonical_update_only_after_ROOT_actual_pdf_review=True)
plan=dict(stage='CHỈ KẾ HOẠCH; CHƯA TẠO MẪU',source=src,canonical=current,
          source_sha256=sha(src),canonical_sha256=sha(current),owner='g03_aquaris_sa — chỉ Perotac SA',
          edit_native_box=edit,edit_pdf_rect=list(cv.rect(edit)),scope_page=8,
          outside_boxes=['Trang1–7,9–11 toàn bộ','Nửa phải trang8: bảng kích thước4SA2/3/4 và sơ đồ bơm','Toàn bảng thông sốp8 và các sửa kW/HP đã đạt'],
          model_count=13,QH_numeric_cells=104,separate_eta_curve_count=1,prior_accepted_model_points_to_recheck=16,
          geometry=dict(QH_frame=axis['frame_native'],eta_panel_native_box=[124.5,583,746,677],
                        legend_native_box=[124.5,733,746,805],source_axis_fit=axis,
                        legend_safe_gap_before_source_performance_heading_native_px=10),
          rows=rows,previously_accepted_rows=previously_accepted,method=method,
          all17graph_source_manifest=info['all_17_graph_counts'],
          next_all17_policy='Chỉ mở rộng sau mẫu p8 đạt cả số/chữ/đồ họa. Mỗi biểu đồ dùng đúng bảng+ảnh/phông từ chính Perotac, nguồn trục riêng. Hàng nguồn tăng phải báo, không sửa bảng hay ép giảm trái104/1931ô. η mỗi đồ thị giữ riêng giới hạn không có bảng.',
          planned_actual_readback=['104nút Q–H từ các path trong PDF vừa lưu, sai số≤max(1m,2%H), đồng thời kiểm đi qua đúng nút kế hoạch và endpoints miền0..21',
                                  '104mốc mực nhìn thấy trên PDF600dpi, đủ13suffix/13tên, không chỉ so mảng tọa độ trong bộ nhớ',
                                  '16mốc /23,/18 nguồn riêng giữ đúng8+8số; mẫu đồ họa chưa đạt thì không ghi canonical',
                                  'η so hình mực nguồn/điểm nguồn, không gọi đạt hiệu suất số; đo sai số hình và ghi phạm vi',
                                  'Ngoài hộp p8:200dpi,ngưỡng0,sốpixelkhác0 trên11trang; không đụng bảng/nửa phải',
                                  '11JPEGrawSHA/CTM,Info,XMPXMLgiá trị sauchuẩnhóa,link/bookmark/11khổtrang/phông giữ; chỉ thêm vector/mặt nạ cục bộ',
                                  'Xem toàn tờ và cắt chữ/lưới/suffix; chưa đạt sau2mẫu cùng phương pháp phải dừng'],
          actual_pdf_written=False,new_glyph_written=False,common_progress_written=False,ROOT_plan_approval_received=False)
Path(fresh(folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V1.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
md=[
    '# Phương án đồng bộ toàn biểu đồ Perotac trang 8 — CHỈ ĐỌC',
    '',
    '**13 đường Q–H, 104 ô số, thêm 1 đường η riêng. Chưa tạo mẫu PDF hoặc hình catalogue mới. Bản gốc và bản giao giữ SHA.**',
    '',
    'Q là lưu lượng; H là cột áp; η là hiệu suất. 13 model đúng bảng: /4,/5,/6,/8,/9,/11,/12,/14,/16,/18,/20,/23,/25. Không có model /7. Các đường /23 và /18 đã đạt được tích hợp vào biểu đồ đồng bộ theo chỉ đạo mới; giữ đúng 16 ô nguồn và kiểm lại cùng104ô.',
    '',
    '## Số liệu và miền đường',
    '',
    '| Model | Q (m³/h) | H(m) đúng8ô | Điểm đầu | Điểm cuối |',
    '|---|---|---|---|---|'
]
for r in rows:
    md.append('| '+r['model']+' | 0,3,6,9,12,15,18,21 | '+','.join(map(str,r['source_H_m']))+' | 0/'+str(r['source_H_m'][0])+' | 21/'+str(r['source_H_m'][-1])+' |')
md += [
    '',
    'Đã đọc lại cả bảng nguồn bằng ảnh PDF600dpi. Nội suy PCHIP (từng đoạn đi đúng ô, giữ chiều giảm) chỉ là phép tính kế hoạch: sai số nút<10⁻¹⁰m, cả13hàng giảm và không ngoại suy. Chưa được tính là104mốc PDF thực tế đạt. /20 kết thúcQ21/H43; /25Q21/H54; không giữ đuôi nguồn cũ ngoài ô cuối.',
    '',
    '## Bố cục và nét đồng bộ',
    '',
    'Thay toàn bộ biểu đồ và khoảng chú giải bên trái trong hộp ảnh gốc [65,117,790,805], tương ứng PDF '+str(plan['edit_pdf_rect'])+'pt. Giữ nguyên bảng thông số phía dưới và toàn phần bên phải. Khung Q–H/vạch trục dùng tọa độ nguồn; khungη giữ riêng. Giữ các đơn vị/số đã in: H0–150m; lít/phút0–350; m³/giờ0–22,5; gallon Mỹ0–90; gallon Anh0–80; feet0/100/200/300/400 (feet là đơn vị chiều dài). Không thêm tick cuối hay đổi số trục.',
    '',
    'Đề xuất toàn13nét Q–H cùng xanh xám RGB127/145/150, bút0,90pt. Đây là trung vị lõi nguồn13nét, độ dày tương đương trung vị0,90056pt; cácnétnguồn0,8220–0,9252pt. Không gọi bút JPEG này là thông số PDF gốc. η cùng màu/nét, lưới toàn vector xám0,20pt, khungđen0,55pt. Chờ ROOT xét các kích thước thiết kế này trước mẫu.',
    '',
    'Đầu đường còn nét đứt đúng quy ước nguồn. 12đường có chu kỳ mực nguồn trực tiếp gần15pixel nét/7pixel khe, không lấy nhiễu JPEG1pixel làm khe. Dữ liệu các đoạn và chuẩn hóaQ trongJSON. Phép dò /18 chỉ theo được từu253; cần soi phần đầu thật600dpi trước nhận nhịp chung. Nét liền từ khoảngu275,5 theo khe cuối nguồn; đây là lựa chọn đồ họa theo mực, không sửa số máy bơm.',
    '',
    'Các nhãn thấp cũ bị dồn nay dùng chú giải13tên đầy đủ, 3cột×5hàng trong khoảng trắng [124,5,733,746,805]. Tên/glyph có trong nguồn. Tại đầu cuối mỗi đường chỉ suffix thật (/4…/25), đưa giãn theo thứ tự bản ghi bảng ởx≈710;y562−12×chỉsố, có đường dẫn chú giải0,30pt phân biệt khỏi nét Q–H. Các đường bơm vẫn kết thúcQ21; đường dẫn chỉ nối nhãn, không là dữ liệu sauQ21. Trước nghiệm thu phải kiểm không chồng/cắt khung hoặc gây hiểu nhầm đuôi bơm.',
    '',
    '## Chữ: nguồn thật và giới hạn',
    '',
    '**11trang nguồn không có phông nhúng, không có lớp chữ thật.** Chữ đang có nằm trong JPEG150dpi. Không lấy phông hệ thống hoặc tệp khác. Caption4SA16 cùng kiểu trongX7 có đủ mọi ký tự tên model và số suffix. Các từ đơn vị/tiêu đề/trục lấy đúng từ ở vị trí gốc, học riêng theo kiểu gốc; không tự dịch/đặt tiêu đề mới.',
    '',
    'Phương án đề nghị: tách mực glyph nguồn (giữ đối chứng nguyên150dpi), dùngcatfix dựng đường bao PDF từ đúng hình glyph; một ngân hàng mẫu cùngkiểu cho các ký tự lặp để chữđồng nhất, giữ tỉ lệ rộng/cao và đường cơ sở. Chọn độcao mực≈4,0pt cho số/nhãn/chúgiải; bước dòng6,72pt. Đây là độcao hình mực, không gán một FontSize không có trong nguồn. Tiêu đề4SA16 xanh lấy đúng chữ gốc và cỡ gốc. Kiểm tối thiểu2ký tự chung+toàn từ, lỗ chữ/độđậm/hình/chân/cỡ ở150dpi và600dpi. Đườngbao phải giữ hình nguồn; không thay bằng một phông nhìn gần giống.',
    '',
    '**Chưa tạo glyph vector mẫu; chưa khẳng định chữ sẽ tự đạt sắc nét.** Nguồn150dpi không có mô tả nét liên tục; việc chuyển biên có thể lộ răngcưa/đổi độđậm. ROOT/tác nhân đồhọa cần xem mẫu thật; sai thì CHƯAĐẠT và không dùngfontngoài để lách. Đây là điểm phải giải quyết trong phương pháp mới.',
    '',
    '## η: chỉ bám hình nguồn',
    '',
    'Đo được558cột mực riêng η từu127đến684, đầuquan sát(u127,v674), cuối(u684,v630,6808); khôngcó nhánhkhác saugộpquầngJPEG thuộc cùngnét. Không giả định thêm mốcQ0/η0 từbảng vì không có bảngη. Nét trơn mới cần bám chính558điểmvà giữmiềnmựcquan sát; đoạn bịkhungche/hụttâm vẫnghigiớihạn. Giữnhãnη0/20/40/60%; khôngbổsungsố70%. Không nhận ĐẠT hiệu suất số liệu.',
    '',
    '## Xóa cũ/lưu PDF/kiểm độc lập',
    '',
    'Thaytoàn mực biểu đồ cũ bằngnền chínhX7: ảnh/lưới/nhãn/nétcũ và2đườngPDFđãđạt đềuphảixửlý, để khônglẫn JPEGmờ/vectorsắc. Giữ11JPEGgốc đúngbyte/ma trận; miếngnền+mặt nạđộtrong suốtkhôngmấtdữliệu chỉởpixelcầnđổi. Khôngdùngpatchcũ hoặcRedpump làmnguồnfont/số/ảnh. Sau nền, dựnglưới/khung/vạch,13Q–H/η, rồi toànchữ/chúgiả saumọimặtnạhiệncó. Khôngchuyểnnguyêntrangthànhảnh.',
    '',
    'SauROOTduyệtkếhoạch mới tạo MẪU1 (filefresh). Đọclại actualpath (néttrongPDFthực), mực600dpi đủ104mốc/13tên, endpointQ0..21,16mốc/23,/18; sai số≤max(1m,2%H). Soηvớimựcnguồn vàghigiớihạn. Xemtrang100%,biểuđồ200–300%,chữ/lưới600dpi: khôngchồng,khôngtrộnđậmmờ,khôngvếtvá. Vùngngoàihộptrên11trang200dpi/ngưỡng0=0pixelkhác;11JPEGraw/CTM/Info/XMPgiátrị/link/bookmark/khổ/phônggiữ. ROOTkiểmđộclập trướcghi bản giao. Nhiềunhất2mẫuthấtbại/phươngpháp.',
    '',
    '## Phạmvi17biểuđồ',
    '',
    'NguồnPerotaccó17biểuđồ,196dòng,1931ô. Saup8đạt mới mởrộng cùngkhungkiểm nguồn/literal/fonttheochínhtệp. Các235mốc cũchưa rõvà7mappingcũchưa khóa giữđúngtrạngthái; khôngđổithànhđạtbởicó bảng. Từngđườngmớitừbảngnguồn sẽđượcđọclại độc lập. Nhữngô nguồncóH tăngkhiQ tăng(phần6SA25...)phảibáo đúngô,không sửa bảnghayépgiảm trái nguồn. η17đường khôngcóbảng,giớihạnsốriêng.',
    '',
    'KhôngghiPDFmẫu/khôngghiTIEN DO.md. Mẫuvá5đuôiđãghiCHƯAĐẠTđồhọatheochỉđạomới vàgiữchỉlàchứngcứkỹthuật.',
    '',
    'SHAnguồn: '+sha(src),
    'SHA bản giao: '+sha(current),
    ''
]
# Make Vietnamese prose legible; technical object keys remain unchanged in JSON.
replacements={
 '13nét':'13 nét','cácnétnguồn':'các nét nguồn','104mốc':'104 mốc','13hàng':'13 hàng','13model':'13 model','13tên':'13 tên','12đường':'12 đường','16mốc':'16 mốc','11trang':'11 trang','11JPEG':'11 JPEG','17biểuđồ':'17 biểu đồ','1931ô':'1931 ô','196dòng':'196 dòng',
 'khôngcó':'không có','khôngdùng':'không dùng','khôngghi':'không ghi','khônglẫn':'không lẫn','khôngchuyển':'không chuyển','khôngbổsung':'không bổ sung','khônggiảđịnh':'không giả định','đúngbyte':'đúng byte','sốriêng':'số riêng',
 'nguồn13nét':'nguồn 13 nét','cùngkiểu':'cùng kiểu','chữđồng nhất':'chữ đồng nhất','chúgiải':'chú giải','độcao':'độ cao','độđậm':'độ đậm','đồhọa':'đồ họa','răngcưa':'răng cưa','fontngoài':'phông ngoài','mẫuthật':'mẫu thật','cỡgốc':'cỡ gốc',
 'ĐẠT hiệu suất':'ĐẠT hiệu suất','558cột':'558 cột','đầuquan sát':'đầu quan sát','nhánhkhác':'nhánh khác','saugộpquầngJPEG':'sau gộp quầng JPEG','cùngnét':'cùng nét','phảixửlý':'phải xử lý','phảibáo':'phải báo','giớihạn':'giới hạn','558điểmvà':'558 điểm và','giữmiềnmựcquan sát':'giữ miền mực quan sát','bịkhungche/hụttâm':'bị khung che/hụt tâm','ghigiớihạn':'ghi giới hạn','Giữnhãnη':'Giữ nhãn η','số70%':'số 70%',
 'Thaytoàn':'Thay toàn','bằngnền':'bằng nền','chínhX7':'chính X7','nétcũ':'nét cũ','vectorsắc':'vector sắc','JPEGmờ':'JPEG mờ','miếngnền+mặt nạđộtrong suốtkhôngmấtdữliệu':'miếng nền + mặt nạ độ trong suốt không mất dữ liệu','chỉởpixelcầnđổi':'chỉ ở pixel cần đổi','font/số/ảnh':'phông/số/ảnh','SauROOTduyệtkếhoạch':'Sau ROOT duyệt kế hoạch','filefresh':'tệp mới riêng','Đọclại':'Đọc lại','néttrongPDFthực':'nét trong PDF thực','mực600dpi':'mực 600dpi','vớimựcnguồn':'với mực nguồn','Xemtrang':'Xem trang','biểuđồ200':'biểu đồ 200','khôngchồng':'không chồng','khôngtrộnđậmmờ':'không trộn đậm mờ','khôngvếtvá':'không vết vá','Vùngngoàihộptrên':'Vùng ngoài hộp trên','ngưỡng0':'ngưỡng 0','0pixelkhác':'0 pixel khác','XMPgiátrị':'XMP giá trị','ROOTkiểmđộclập':'ROOT kiểm độc lập','Nhiềunhất':'Nhiều nhất','mẫuthấtbại':'mẫu thất bại','Saup8đạt':'Sau p8 đạt','chínhtệp':'chính tệp','đọclại':'đọc lại','độclập':'độc lập','nguồncóH':'nguồn có H','phần6SA25':'phần 6SA25','đúngô':'đúng ô','épgiảm':'ép giảm','khôngđổithànhđạtbởicó bảng':'không đổi thành đạt bởi có bảng','NguồnPerotaccó':'Nguồn Perotac có','từngđườngmới':'từng đường mới',
 'KhôngghiPDFmẫu/khôngghiTIEN DO.md':'Không ghi PDF mẫu/không ghi TIEN DO.md','Mẫuvá':'Mẫu vá','5đuôi':'5 đuôi','đãghiCHƯAĐẠTđồhọatheochỉđạomới':'đã ghi CHƯA ĐẠT đồ họa theo chỉ đạo mới','vàgiữchỉlàchứngcứkỹthuật':'và giữ chỉ là chứng cứ kỹ thuật','SHAnguồn':'SHA nguồn'
}
text='\n'.join(md)
for old,new in replacements.items():text=text.replace(old,new)
Path(fresh(folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V1.md')).write_text(text,encoding='utf8')
E.close()
print('PLAN ONLY; 13QH/104CELLS+ETA; NO PDF/NEW GLYPH; SOURCE/CURRENT UNCHANGED',sha(src),sha(current),flush=True)
