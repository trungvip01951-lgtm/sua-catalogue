"""Complete source bank with clean 9 from genuine 3SL4/9; study only, no PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'GLYPH THAT DAY DU GIU CA NET ROI NGUON V2.json').read_text(encoding='utf8'));ctx=json.loads((root/'CHU9 UNG VIEN MO NGUYEN CUM VA TOA DO.json').read_text(encoding='utf8'));plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
src=d['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);c=next(z for z in ctx['records'] if z['word']=='3SL4/9');cv=R.render_canvas(2,c['rect'],dpi=600);x0,y0,x1,y1=46,7,74,46;whole=cv.orig.astype(float);g=whole@np.array([.299,.587,.114]);bg=np.median(g,axis=1);p=g[y0:y1,x0:x1];al=np.clip((bg[y0:y1,None]-p)/np.maximum(bg[y0:y1,None],1),0,1)
components,n=label(al>.085);sizes=[int((components==k).sum()) for k in range(1,n+1)];idx=int(np.argmax(sizes))+1;al*=components==idx;yy,xx=np.nonzero(al>.085)
z=next(z for z in d['records'] if z['character']=='9');z.update(source_page=3,source_word='3SL4/9',source_canvas_rect=list(cv.rect0),source_render_box=[x0,y0,x1,y1],source_page_box=[*cv.to_page(x0,y1),*cv.to_page(x1,y0)],source_alpha=al.tolist(),source_background_gray_by_row=bg[y0:y1].tolist(),source_components_kept=[idx],source_components_areas=sizes,source_ink_bbox600=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],source_physical_box_size_pt=[(x1-x0)*.12,(y1-y0)*.12],physical_scale=1.,source_context=str(root/'CHU9 UNG VIEN MO NGUYEN CUM VA TOA DO.png'))
picture=Image.new('RGB',(1200,230),'white');dr=ImageDraw.Draw(picture);raw=Image.fromarray(whole.round().astype('uint8'));clean=Image.fromarray((255*(1-al)).round().clip(0,255).astype('uint8')).convert('RGB');picture.paste(raw.resize((raw.width*3,raw.height*3),Image.Resampling.NEAREST),(5,20));picture.paste(clean.resize((clean.width*3,clean.height*3),Image.Resampling.NEAREST),(500,20));dr.text((630,30),'9: true 3SL4/9 source, no substitute font',fill='blue');dr.text((630,60),str({'components':sizes,'kept':idx,'ink_bbox600':z['source_ink_bbox600']}),fill='blue')
photo=fresh(root/'CHU9 SACH NGUON 3SL4_9 V3.png');picture.save(photo)
d.update(source_proof_photo=photo,status='BỘ CHỮ NGUỒN V3: chữ 9 từ 3SL4/9 trang 3, đọc nguyên cụm nguồn. Chưa ghi PDF; phải soi mỗi ký tự và toàn 13 nhãn.',corrections=[*d['corrections'],'Ứng viên 9 trang 4/8 có mép xám dưới, không dùng. V3 lấy nguyên chữ 9 từ nhãn 3SL4/9, giữ nguyên cỡ vật lý, nét mở chân dưới đúng mực nguồn.'],source_pages=sorted(set(z['source_page'] for z in d['records'])))
Path(fresh(root/'GLYPH THAT DAY DU CUNG BO NGUON V3.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('clean true source9',sizes,z['source_ink_bbox600'],'noPDF',flush=True)
