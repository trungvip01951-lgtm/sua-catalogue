from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,Canvas
from g04_perotac_audit_data import DATA
from pathlib import Path
from PIL import Image
import numpy as np,json

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));E=Editor(src);R=Raster(E)
def groups(v):
 out=[]
 for k in v:
  if not out or k>out[-1][-1]+1:out.append([int(k)])
  else:out[-1].append(int(k))
 return [float(np.mean(z)) for z in out]
allitems=[]
for rec in DATA:
 pi=rec['page']-1;im=max(R.images(pi),key=lambda x:x.W*x.H);cv=R.canvas(im);tb=rec['table_native_box'];u0,v0,u1,v1=tb;ar=cv.orig[v0-5:v1+5,u0-5:u1+5,:3];g=ar.astype(float)@np.array([.299,.587,.114]);black=g<175
 yy=groups(np.where(black.sum(1)>ar.shape[1]*.65)[0]);xx=groups(np.where(black.sum(0)>ar.shape[0]*.55)[0]);ny=len(rec['rows']);nx=len(rec['Q_m3_h'])
 # Header lines precede the final N+1 body borders; final Q-data columns lie
 # at the right of the table. Read positions from actual original grid.
 yb=[z+v0-5 for z in yy[-(ny+1):]];xb=[z+u0-5 for z in xx[-(nx+1):]]
 if len(yb)!=ny+1 or len(xb)!=nx+1:
  print('GRID UNKNOWN',rec['family'],len(yy),len(xx),flush=True);allitems.append(dict(family=rec['family'],grid_unknown=True,row_candidates=yy,column_candidates=xx));continue
 dy=np.diff(yb);dx=np.diff(xb)
 if max(abs(dy-np.median(dy)))>2 or max(abs(dx-np.median(dx)))>2:
  print('GRID SPACING UNKNOWN',rec['family'],'dy',dy,'dx',dx,flush=True);allitems.append(dict(family=rec['family'],grid_unknown=True,row_candidates=yy,column_candidates=xx));continue
 cw,ch=160,90;sheet=Image.new('RGB',(nx*cw,ny*ch),'white');cellboxes=[]
 for row in range(ny):
  for col in range(nx):
   b=[int(np.floor(xb[col]))+3,int(np.floor(yb[row]))+3,int(np.ceil(xb[col+1]))-2,int(np.ceil(yb[row+1]))-2]
   pic=Image.fromarray(cv.orig[b[1]:b[3],b[0]:b[2],:3]).resize(((b[2]-b[0])*4,(b[3]-b[1])*4),Image.Resampling.LANCZOS)
   if pic.width>cw-8 or pic.height>ch-8:pic.thumbnail((cw-8,ch-8))
   sheet.paste(pic,(col*cw+(cw-pic.width)//2,row*ch+(ch-pic.height)//2));cellboxes.append(dict(row=row,col=col,native_box=b))
 mem=Canvas();mem.orig=np.asarray(sheet).copy();mem.work=mem.orig.copy();words=R.ocr(mem,scale=1,psm=6,config='-c tessedit_char_whitelist=0123456789')
 cells=[[[] for _ in range(nx)] for _ in range(ny)]
 for w in words:
  x0,y0,x1,y1=w['box'];col=int((x0+x1)/2//cw);row=int((y0+y1)/2//ch)
  if 0<=row<ny and 0<=col<nx:cells[row][col].append(w)
 diffs=[];parsed=[]
 for ri,row in enumerate(rec['rows']):
  vals=[]
  for ci,h in enumerate(row['H']):
   ws=cells[ri][ci];txt=''.join(w['text'] for w in ws);v=int(txt) if txt.isdigit() else None;vals.append(v)
   if v!=h:diffs.append(dict(model=row['model'],Q_m3_h=rec['Q_m3_h'][ci],expected_manual=h,observed_OCR=v,words=ws,native_box=cellboxes[ri*nx+ci]['native_box'],need_visual_review=True))
  parsed.append(dict(model=row['model'],H_OCR=vals))
 path=fresh(root/f'OCR O SO {rec["family"].replace(".","_")}.png');sheet.save(path)
 allitems.append(dict(page=pi+1,family=rec['family'],grid_unknown=False,row_borders_native=yb,Q_column_borders_native=xb,cell_boxes=cellboxes,OCR_words=words,parsed=parsed,differences=diffs,OCR_is_hint_only_not_accepted=True))
 print('TABLE OCR',rec['family'],'cells',nx*ny,'differences',len(diffs),'FIRST',diffs[:4],flush=True)
out=dict(source=src,read_only=True,pdf_written=False,tables=allitems,discrepancy_count=sum(len(z.get('differences',[])) for z in allitems),grid_unknown_count=sum(z['grid_unknown'] for z in allitems),note='Bảng OCR nối ảnh từng ô nguồn sau bỏ riêng biên kẻ, chỉ để đối chiếu bản chép. Chưa tự thay số, chưa dùng làm nghiệm thu.')
Path(fresh(root/'DOI CHIEU DOC BANG LAN1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
