from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_axis_h.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
code=code.replace('steps=[5,10,30,20,15,60,50,60,50,50,30,30,25,45,40,50,25]', 'steps=[5,10,30,20,15,60,75,60,50,50,240,30,25,45,40,30,25]')
code=code.replace("fn='TRUC H NGUON '", "fn='TRUC H NGUON LAN4 '")
code=code.replace("' LAN2.png'", "' LAN5.png'")
code=code.replace('TRUC H DOC VA DOI CHIEU.json','TRUC H DOC VA DOI CHIEU LAN4.json')
code=code.replace("ax['H_tick_evidence_image']=fn", "ax['H_tick_evidence_image']=fn\n ax['H_grid_calibration']['actual_printed_labels']=[0,40,80,120,160,200,240] if rec['family']=='4SA10' else [t['H_m'] for t in ticks]\n ax['H_grid_calibration']['only_black_frame_endpoints_used']=rec['family']=='4SA10'\n ax['H_grid_calibration']['printed_values_review_pending']=False")
exec(compile(code,__file__,'exec'))
