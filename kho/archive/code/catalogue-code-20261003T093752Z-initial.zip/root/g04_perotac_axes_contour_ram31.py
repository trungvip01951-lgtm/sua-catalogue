"""Axis literal contours from own original Perotac X7, RAM graphics only."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from scipy.ndimage import distance_transform_edt
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=base/'CHU TRUC NGUON VA RAM CHI DOC'
ticks=json.loads((base/'DOI CHIEU VACH PHU NGUON THAT/VACH PHU34 VA TRUC CUC BO NGUON V4 DE ROOT KIEM.json').read_text(encoding='utf8'))
geo=json.loads((base/'KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json').read_text(encoding='utf8'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig;zoom=64;cases=[]
for r in ticks['secondary_units_actual_source_stems']:
    key=r['axis'];v=r['value_printed'];c=r['source_tick_center_native']
    if key=='Q US':b=[int(c)-12,148,int(c)+14,159]
    elif key=='Q IMP':b=[int(c)-12,165,int(c)+14,176]
    elif key=='Q M3':b=[int(c)-14,696,int(c)+16,710]
    else:b=[753,int(c)-6,784,int(c)+8]
    cases.append((key+' '+str(v),str(v),b,[57,55,57]))
for r in ticks['primaryH_actual_local_grid_ticks']:
    h=r['H_m'];v=r['native_v'];cases.append(('H M '+str(h),str(h),[102,int(v)-6,123,int(v)+8],[57,55,57]))
for q,x in zip([0,50,100,150,200,250,300,350],[r['native_center'] for r in geo['main_observed_vertical_lines']][:8]):
    cases.append(('Q LMIN '+str(q),str(q),[int(x)-13,678,int(x)+16,691],[57,55,57]))
for h,v in [(0,676),(20,650),(40,623),(60,597)]:cases.append(('ETA '+str(h),str(h),[108,v-6,123,v+7],[57,55,57]))
cases.extend([('US UNIT','US g.p.m',[704,146,750,160],[57,55,57]),('IMP UNIT','Imp g.p.m',[702,165,750,176],[57,55,57]),
 ('FEET UNIT','feet',[752,177,787,190],[57,55,57]),('LMIN UNIT','l/min',[722,678,750,691],[57,55,57]),('M3 UNIT','m³/h',[725,696,750,710],[57,55,57]),
 ('ETA UNIT','Eta(%)',[85,577,123,593],[57,55,57]),('H VERTICAL WORD','Total dynamic head H(m) and original arrow',[87,296,105,550],[57,55,57]),
 ('FLOW WORD','Flow rate Q and original arrow',[383,710,475,725],[57,55,57]),('TITLE','4SA16',[568,188,663,217],[21,55,105])])
def smooth(points):
    p=np.asarray(points,float);segs=[];sample=[]
    def tan(k):
        vin=p[k]-p[(k-1)%len(p)];vout=p[(k+1)%len(p)]-p[k];angle=np.degrees(np.arccos(np.clip(vin@vout/max(np.linalg.norm(vin)*np.linalg.norm(vout),1e-9),-1,1)))
        return np.zeros(2) if angle>75 else (p[(k+1)%len(p)]-p[(k-1)%len(p)])*.145
    for i,x in enumerate(p):
        j=(i+1)%len(p);q=p[j];c1=x+tan(i);c2=q-tan(j);tt=np.linspace(0,1,24,endpoint=False)[:,None]
        sample.extend(((1-tt)**3*x+3*(1-tt)**2*tt*c1+3*(1-tt)*tt**2*c2+tt**3*q).tolist());segs.append([x.tolist(),c1.tolist(),c2.tolist(),q.tolist()])
    return segs,np.asarray(sample)
out=[];tiles=[]
for key,literal,b,ink in cases:
    x0,y0,x1,y1=b;raw=a[y0:y1,x0:x1];al=R.alpha_of(raw,np.array([255.,255.,255.]),np.asarray(ink,float));h,w=al.shape
    # Dark source-only component seeds; discard isolated faint JPEG paper noise,
    # keeping the actual alpha fringe around connected character ink.
    core=al>=.28;count,labels=cv2.connectedComponents(core.astype(np.uint8),connectivity=8);keep=np.zeros_like(core)
    for k in range(1,count):
        yy,xx=np.where(labels==k)
        if len(yy)>=1 and float(al[yy,xx].max())>=.4:keep[yy,xx]=True
    near=cv2.dilate(keep.astype(np.uint8),np.ones((3,3),np.uint8),iterations=1)>0
    used=al*near;up=cv2.resize(np.pad(used,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);integral=float(used.sum());lo=.1;hi=.9
    for it in range(30):
        mid=(lo+hi)/2
        if (up>=mid).sum()/zoom**2>integral:lo=mid
        else:hi=mid
    thr=(lo+hi)/2;m=up>=thr;co,hh=cv2.findContours(m.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);paths=[];small_removed=0.
    for j,c in enumerate(co):
        area=cv2.contourArea(c)/zoom**2
        if area<.08:small_removed+=area;continue
        pp=(cv2.approxPolyDP(c,.08*zoom,True)[:,0,:].astype(float)+.5)/zoom-1;segs,sp=smooth(pp)
        # Restore each original contour box; no typographic rescaling.
        oldbb=np.r_[pp.min(0),pp.max(0)];newbb=np.r_[sp.min(0),sp.max(0)];fac=(oldbb[2:]-oldbb[:2])/np.maximum(newbb[2:]-newbb[:2],1e-9);off=oldbb[:2]-newbb[:2]*fac
        sp=sp*fac+off;segs=(np.asarray(segs)*fac+off).tolist()
        paths.append(dict(local_native_xy=sp.tolist(),cubic_segments_local_native=segs,parent=int(hh[0,j,3]),original_contour_index=j,source_contour_bbox_native=oldbb.tolist(),source_contour_signed_area_native_px=float(area if hh[0,j,3]<0 else -area)))
    mi=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);dr=ImageDraw.Draw(mi)
    for p in paths:dr.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p['local_native_xy']],fill=255 if p['parent']<0 else 0)
    mm=np.asarray(mi)>0;area=float(mm.sum()/zoom**2);cc,ch=cv2.findContours(mm.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
    oldedge=np.zeros_like(m);newedge=np.zeros_like(m)
    for c in co:oldedge[c[:,0,1],c[:,0,0]]=True
    for c in cc:newedge[c[:,0,1],c[:,0,0]]=True
    # Removed faint isolated paper specks are separately disclosed, not a glyph
    # deformation. Compare surviving source components against new boundaries.
    distances=distance_transform_edt(~oldedge)[newedge]/zoom;maxdist=float(distances.max()) if len(distances) else None
    item=dict(key=key,literal_source_read=literal,source_page=8,source_image='X7',source_native_box=b,source_raw_RGB_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),
       source_alpha_projected_integral=float(al.sum()),source_connected_alpha_integral=integral,source_faint_paper_alpha_not_used=float(al.sum()-integral),source_mass_threshold=thr,
       source_components_before_small_paper_removal=int(sum(hh[0,i,3]<0 for i in range(len(co)))),source_holes_before_small_paper_removal=int(sum(hh[0,i,3]>=0 for i in range(len(co)))),
       discarded_isolated_contour_area_native_px=small_removed,contour_paths=paths,source_RGB=ink,scale_original=1.,
       RAM_area_native_px=area,RAM_vs_connected_alpha_area_delta_percent=float((area/integral-1)*100) if integral else None,
       RAM_outer_components=int(sum(ch[0,i,3]<0 for i in range(len(cc)))),RAM_holes=int(sum(ch[0,i,3]>=0 for i in range(len(cc)))),
       max_RAM_edge_to_source_iso_native_px=maxdist,ROOT_graphic_and_literal_read_pending=True,no_system_or_other_catalogue_font=True)
    out.append(item)
    tile=Image.new('RGB',(1150,360),'white');tile.paste(Image.fromarray(raw).resize((w*8,h*8),Image.Resampling.NEAREST),(10,10))
    vimg=Image.new('RGB',((w+2)*8,(h+2)*8),'white');vd=ImageDraw.Draw(vimg)
    for p in paths:vd.polygon([((x+1)*8,(y+1)*8) for x,y in p['local_native_xy']],fill=tuple(ink) if p['parent']<0 else 'white')
    tile.paste(vimg,(600,2));tile.save(fresh(root/(key.replace(' ','_')+' NGUON VA BIEN CHU TRUC.png')));tiles.append(tile)
    print(key,b,'area%',item['RAM_vs_connected_alpha_area_delta_percent'],'CC/H',item['RAM_outer_components'],item['RAM_holes'],flush=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==ticks['source_sha256'] and sha(S.result(name))==ticks['current_sha256']
Path(fresh(root/'CHU SO TRUC VA TIEU DE DUONG BAO RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_original_Perotac_X7_only=True,words=out,source_boxes_to_review=True,no_PDF_font_or_progress_written=True),ensure_ascii=False,indent=2),encoding='utf8');E.close()
