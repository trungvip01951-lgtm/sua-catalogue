"""Giao mẫu2đuôiSP135 sau ROOTduyệt; dùng catfix, lưuphiêntrước theoSHA.
prepare lậpguardđểPowerShellMove-Item;finish ghi mới vàđọcactualPDF giao.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.recipes import Job
from catfix.cs import Ref
from catfix.vector import Editor
from catfix import verify,charts
from pathlib import Path
import numpy as np,json,hashlib,pymupdf as fitz,csv

mode=sys.argv[1]
I='G05/10SP135 HAI MOC CUOI/MAU 2/'
O='G05/10SP135 HAI MOC CUOI/GIAO BAN/'
r=json.loads(Path(S.report(I+'NGHIEM THU PDF MAU 2END VA TOAN2218.json')).read_text(encoding='utf8'))
source=S.src('Perotac bơm giếng SP_compressed (bản mới).pdf');primary=Path(S.dst('Perotac bơm giếng SP_compressed (bản mới).pdf'));trial=Path(r['trial'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
outdir=Path(S.out_dir).resolve();primary_abs=primary.resolve();assert primary_abs.is_relative_to(outdir) and primary_abs!=Path(source).resolve()
archive=Path(S.report('G05/PHIEN TRUOC/'+r['current_sha256']+'/'+str(primary_abs.relative_to(outdir)))).resolve();assert archive.is_relative_to(outdir/'_BAO CAO')
assert sha(source)==r['source_sha256'] and sha(trial)==r['trial_sha256']
planpath=S.report(O+'KE HOACH LUU PHIEN CU.json')
if mode=='prepare':
 rootproof=S.report(sys.argv[2]);assert Path(rootproof).is_file()
 rootcheck=json.loads(Path(rootproof).read_text(encoding='utf8'))
 # ROOTđãduyệt mẫu2 bằngtin nhắn trực tiếp sau khi soi150/600dpi. Hồsơ số
 # đượcghi trước bước xemảnh vẫnaccepted=False; không sửa hồsơ củaROOT.
 assert rootcheck['trial_sha']==r['trial_sha256'] and rootcheck['current_sha']==r['current_sha256'] and not rootcheck['outside200'] and all(rootcheck['metadata'].values())
 assert len(rootcheck['actual_points'])==2 and all(p['result']=='ĐẠT' for p in rootcheck['actual_points'])
 assert sha(primary)==r['current_sha256'] and not archive.exists()
 archive.parent.mkdir(parents=True,exist_ok=True)
 plan=dict(primary=str(primary_abs),archive=str(archive),old_primary_sha256=r['current_sha256'],source=str(Path(source).resolve()),source_sha256=r['source_sha256'],trial=str(trial.resolve()),trial_sha256=sha(trial),output_root=str(outdir),root_proof=rootproof,root_file_accepted_flag=rootcheck.get('accepted'),approval='ROOT tin nhắn trực tiếp: ROOT duyệt mẫu2 SP135...Đãsoi150+600dpi; chấp nhận độdày tươngđương đo mựcnguồn...HãyguardarchiveSHA bc015 rồi lưucatfixbảncuối. HồsơROOT numericđượcghi trước xemảnh vẫnacceptedFalse, giữnguyên hồsơROOT.')
 Path(fresh(planpath)).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
 print('SP135_ARCHIVE_PLAN',planpath,flush=True)
elif mode=='finish':
 plan=json.loads(Path(planpath).read_text(encoding='utf8'));assert not primary.exists() and sha(archive)==r['current_sha256'] and sha(trial)==plan['trial_sha256'] and Path(plan['root_proof']).is_file()
 assert str(primary_abs)==plan['primary'] and str(archive)==plan['archive']
 j=Job(str(trial),fresh(str(primary)),backend='fitz',log_path=fresh(S.report(O+'NHAT KY GHI FINAL.json')))
 src=fitz.open(source);xr=src.xref_xml_metadata();raw=src.xref_stream(xr) if xr else None;src.close()
 if raw is not None:
  txr=j.E.doc.doc.xref_xml_metadata();assert txr;j.E.doc.set_stream(Ref(txr,0),raw)
 j.save();ck=j.check(raster=True);assert ck['ok'],ck;j.close()
 eq=verify.outside_pixels(str(trial),str(primary),{},dpi=200,thr=0,min_size=0,pad=0);assert not eq
 rec=json.loads(Path(S.report(I+'TOA DO VA BANG NGUON.json')).read_text(encoding='utf8'));b=rec['axis'];xt=np.array(b['xticks']);yt=np.array(b['yticks']);E=Editor(str(primary));P=E.page(10);new=[]
 def y_at(path,x):
  cur=None
  for op,p in path:
   if op=='m':cur=np.array(p[0]);continue
   if op=='c':
    ctrl=np.vstack([cur,np.array(p)]);end=ctrl[-1]
    if cur[0]-1e-5<=x<=end[0]+1e-5:
     lo=0.;hi=1.
     for _ in range(70):
      z=(lo+hi)/2;v=(1-z)**3*ctrl[0]+3*(1-z)**2*z*ctrl[1]+3*(1-z)*z*z*ctrl[2]+z**3*ctrl[3]
      if v[0]<x:lo=z
      else:hi=z
     return float(v[1])
    cur=end
  raise ValueError(x)
 for p in r['actual_endpoint_points']:
  oi=p['object_index'];o=P.objs[oi];assert o['op']=='S';path=P.object_pagepath(oi);x=float(np.interp(180,xt[:,0],xt[:,1]));h=float(np.interp(y_at(path,x),yt[:,1],yt[:,0]));assert abs(h-p['H_actual_PDF'])<1e-8 and abs(h-p['H_table'])<1e-4
  st=next(v for v in r['actual_styles'] if v['model']==p['model']);assert o['lw']==st['width_pt'] and list(P.color_of(oi,'stroke'))==st['stroke_rgb'] and str(o['dash'])==st['dash'] and np.max(abs(o['ctm']-np.array(st['matrix'])))<1e-8
  c=dict(p);c['H_actual_final']=h;c['deviation_final_m']=abs(h-p['H_table']);c['actual_style_preserved']=True;new.append(c)
 E.close()
 a=np.asarray(verify.crop(str(primary),10,b['rect'],600));z=np.asarray(verify.crop(str(trial),10,b['rect'],600));assert np.array_equal(a,z)
 verify.crop(str(primary),10,b['rect'],600).save(fresh(S.report(O+'10SP135-FINAL.png')))
 verify.crop(str(primary),10,(715,341,763,386),600).save(fresh(S.report(O+'HAI DUOI FINAL.png')))
 verify.page_overview(str(archive),str(primary),10,fresh(S.report(O+'So sanh trang11.png')),dpi=120)
 assert sha(archive)==r['current_sha256'] and sha(source)==r['source_sha256']
 points=r['full2218_points'];ss=['ĐẠT','CHƯA ĐẠT','CHƯA THỂ'];counts={v:sum(p['verification_status']==v for p in points) for v in ss};assert counts==r['full2218_counts'] and len(points)==2218
 out=dict(final=str(primary_abs),final_sha256=sha(primary),approved_sample=str(trial),approved_sample_sha256=sha(trial),archive_previous=str(archive),archived_sha256=sha(archive),source_sha256=sha(source),check=ck,entire_pdf_equal_to_approved_sample200dpi=eq,SP135_panel_equal600dpi=True,actual_final_endpoint_points=new,full2218_counts=counts,full2218_points=points,SP135_132_counts=r['SP135_counts'],sample_readback_evidence=S.report(I+'NGHIEM THU PDF MAU 2END VA TOAN2218.json'),root_independent_evidence=plan['root_proof'],source_has_xmp=raw is not None,raw_xmp_restore_applied=raw is not None,group_status='CHƯA XONG',remaining='29mốc trái SP30 giữ nguyên;1.074mốc chưa thể vẫn giữ; 6/6 chữ/số và28đuôi54mốc mới đãđạt.')
 Path(fresh(S.report(O+'NGHIEM THU ACTUAL PDF GIAO.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
 lines=['# BÁO CÁO BỔ SUNG G05 – hai điểm cuối 10SP135 đã giao','',
  'Đã sửa và giao hai điểm cuối Q180 của 10SP135-5 và 10SP135-7. AI điều phối đã kiểm độc lập PDF mẫu trước khi giao. Nguồn giữ nguyên; bản trước được lưu theo mã kiểm tra SHA256.','',
  '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
  '|---|---|---|---|---|---|---|---|']
 for p in new:
  c=next(c for c in rec['curves'] if c['model']==p['model']);old=next(v for v in c['source_points'] if v['Q_m3h']==180)
  lines.append(f'| BS03-{p["model"]} | Perotac bơm giếng SP_compressed (bản mới).pdf | 11 | Q180, đường nguồn≈{old["H_curve_m"]:.5f}m | H bảng{p["H_table"]:g}m; nét PDF giao đọc{p["H_actual_final"]:.8f}m | Chỉ nối trơn đuôi gầnQ162→180; giữ chữ/nét đứt/10nét khác và mọi số bảng | ĐẠT điểm cuối | G05/10SP135 HAI MOC CUOI/GIAO BAN/NGHIEM THU ACTUAL PDF GIAO.json |')
 lines.extend(['',
  'Tổng việc mới: 2 điểm cuối · ĐẠT 2 · CHƯA ĐẠT 0 · CHƯA THỂ 0 trong phạm vi sửa. Không gọi cả đường đã đạt vì các mốc nguồn khác còn giới hạn đo ảnh.','',
  f'Sai lệch lớn nhất đọc từ nét thật của PDF giao: {max(p["deviation_final_m"] for p in new):.11f}m. Hai điểm đều đạt cả sai lệch và biên sai số trục ảnh 150dpi so với giới hạn max(1m,2%H).','',
  'Đã đo lại đủ 132 mốc biểu đồ 10SP135: 74 ĐẠT / 0 CHƯA ĐẠT / 58 CHƯA THỂ. 14 biểu đồ khác giữ từng điểm ảnh 600dpi; 15 bảng giữ từng điểm ảnh 450dpi. Dải ±3,5 điểm ảnh nguồn quanh cả 10 nét còn lại không đổi. Chữ/nét đứt phía trái 600dpi không đổi.','',
  f'Toàn 220 đường/2.218 mốc: {counts["ĐẠT"]} ĐẠT / {counts["CHƯA ĐẠT"]} CHƯA ĐẠT / {counts["CHƯA THỂ"]} CHƯA THỂ. Nhóm vẫn CHƯA XONG. 29 mốc trái SP30 giữ nguyên theo phạm vi giao lần này.','',
  '6/6 việc chữ/số gốc vẫn đạt; phần bổ sung đã có 28 đuôi đường/54 mốc mới đạt và mã hàng 6SP36-28. Danh tính 4SP14/4SP15 và bảng 6SP30-8/nét 6SP30-9 vẫn chưa thể xác minh.','',
  'Bảo toàn: toàn PDF giao giống mẫu đã duyệt từng điểm ảnh 200dpi/ngưỡng 0; biểu đồ SP135 giống mẫu 600dpi. Giữ 12 trang, khổ trang, phông/ảnh gốc, thông tin/liên kết/dấu trang; XMP (khối siêu dữ liệu) nguồn và bản giao đều không có. Màu/độ dày nét mới suy từ ảnh 150dpi, không gọi là tham số bút nguồn chính xác.','',
  'Bằng chứng: hồ sơ nghiệm thu mẫu 132 mốc + toàn 2.218 mốc và 15 bảng/14 biểu đồ; hồ sơ đọc thật bản giao; ảnh So sanh trang11.png; hồ sơ độc lập của AI điều phối. Nét Bézier là đường trơn bằng tọa độ; actual nghĩa là đọc từ chính tệp giao.','',
  'Mẫu1 bị loại vì nét 0,48pt mỏng hơn nguồn. Mẫu2 cuối cùng dùng màu lõi 20% tối nhất và độ rộng lượng mực vuông góc đo từ 100/95 lát cắt nguồn: 0,820389/0,786665pt. Đọc mực từ chính PDF mẫu trên 43/24 lát cùng Q, tránh lưới: tỷ lệ mực trung bình nét mới/nguồn 1,0081 và 1,0254 (chênh 0,8%/2,5%); không chỉ dùng biên ±1 điểm ảnh để cho qua độ dày. Hồ sơ MAU 2/DO MUC TRONG PDF MAU THAT.json.','',
  'AI điều phối đọc độc lập 195/195 tiết diện từ điểm ảnh JPEG gốc khớp hồ sơ. Quy ước opacity theo trung vị kênh của AI điều phối cho độ rộng 0,7758/0,7332pt; chênh kế hoạch 0,0446/0,0535pt do quy ước tách mực và nhiễu JPEG. Opacity nghĩa là độ che phủ mực. Giữ riêng giới hạn đo ảnh này, không tuyên bố biết chính xác bút vector nguyên thủy. AI điều phối đã xem 150dpi và 600dpi rồi chấp nhận nét tương đương. Hồ sơ DO MUC NGUON/ROOT DOC LAI MUC NGUON RAW.json.','',
  'Tệp giao: '+str(primary_abs),
  'SHA256 bản giao: '+sha(primary),
  'SHA256 nguồn bất biến: '+sha(source),
  'Bản trước: '+str(archive),'',
  'Cần anh quyết: không có yêu cầu duyệt mới. Các điểm chưa đạt/chưa thể còn lại được ghi rõ để xử lý riêng.',''])
 Path(fresh(S.report('BAO CAO BO SUNG G05 - HAI DIEM CUOI 10SP135.md'))).write_text('\n'.join(lines),encoding='utf8')
 S.progress('G05','CHƯA XONG','Hai điểmQ180 của10SP135-5/-7 đã ROOTduyệt vàgiao,actual66/93 đạt;10nét khác/bảng/chữ/ảnh/phông/ngoài vùng giữ. Toàn220đường/2218mốc1115ĐẠT/29CHƯA ĐẠT/1074CHƯA THỂ;6/6chữ/số+28đuôi54mốcmớiĐẠT. Báo cáo BAO CAO BO SUNG G05 - HAI DIEM CUOI 10SP135.md; nguồn không đổi;phiênbc015…lưuSHA.')
 print('SP135_DELIVERED',sha(primary),'NEW2',new,'FULL',counts,flush=True)
else:raise ValueError(mode)
