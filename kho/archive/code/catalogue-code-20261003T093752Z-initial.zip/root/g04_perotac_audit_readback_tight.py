from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,math
root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));name='Perotac bơm giếng SA_compressed (bản mới).pdf';E=Editor(S.src(name));R=Raster(E);im=max(R.images(7),key=lambda p:p.W*p.H);cv=R.canvas(im)
j=json.loads((root/'DO NET NGUON LAN4.json').read_text(encoding='utf8'));g=next(x for x in j['graphs'] if x['family']=='4SA16');items=[]
for c in g['curves']:
 if c['model'] not in ['4SA16/20','4SA16/25']:continue
 p=c['points'][-1];u,v=p['target_u_native'],p['v_native'];box=(u-2,v-2,u+2,v+2);rect=cv.rect(box)
 a=verify.crop(S.src(name),7,rect,600);b=verify.crop(S.result(name),7,rect,600);delta=np.asarray(a).astype(int)-np.asarray(b).astype(int)
 fn='MUC RIENG NGUON VA BAN GIAO '+c['model'].replace('/','-')+'.png';pic=Image.new('RGB',(a.width+b.width,max(a.height,b.height)+22),'white');pic.paste(a,(0,22));pic.paste(b,(a.width,22));d=ImageDraw.Draw(pic);d.text((2,2),'S',fill='black');d.text((a.width+2,2),'R',fill='black');pic.resize((pic.width*8,pic.height*8),Image.Resampling.NEAREST).save(fresh(root/fn))
 item=dict(model=c['model'],Q_m3_h=p['Q_m3_h'],source_native_box=box,evidence_file=fn,actual_visible_pixel_difference_count=int(np.any(delta!=0,axis=2).sum()),max_rgb_difference=int(abs(delta).max()));items.append(item);print(item,flush=True)
Path(fresh(root/'DOC LAI MUC RIENG BAN GIAO.json')).write_text(json.dumps(dict(read_only=True,pdf_written=False,points=items,interpretation='Ô cắt rộng trước đó chứa đường bên cạnh đã sửa; chỉ so mực của đúng đường đang xét ở đây.'),ensure_ascii=False,indent=2),encoding='utf8');E.close()
