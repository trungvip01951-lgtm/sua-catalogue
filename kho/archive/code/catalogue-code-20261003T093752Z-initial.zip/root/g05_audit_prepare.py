from catwork import start, fresh, HERE
S,D,N=start(verbose=True)
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster,RenderCanvas
from pathlib import Path
from PIL import Image
import json,hashlib,numpy as np,pymupdf as fitz

name='Perotac bơm giếng SP_compressed (bản mới).pdf'
src=S.src(name);dst=S.dst(name);raw=Path(dst).read_bytes()
doc=fitz.open(stream=raw,filetype='pdf')
E=Editor(dst);R=Raster(E)
prefix='G05/KIEM TOAN TOAN BO/'
plans=[
 (1,'4SP3',(470,307,790,508),(448,22,798,190)),
 (2,'4SP5',(49,398,206,520),(38,180,394,355)),
 (2,'4SP8',(226,398,390,520),(38,31,394,182)),
 (2,'4SP10',(469,397,633,518),(460,171,819,337)),
 (2,'4SP14',(646,397,817,518),(460,30,819,179)),
 (4,'6SP10',(469,330,789,522),(436,19,797,237)),
 (5,'6SP18',(62,308,375,514),(38,16,398,235)),
 (5,'6SP30',(461,306,776,509),(438,13,793,226)),
 (6,'6SP36',(67,307,382,510),(44,13,405,238)),
 (6,'6SP46',(464,299,780,507),(439,13,795,223)),
 (7,'6SP60',(65,309,379,510),(39,12,400,181)),
 (9,'8SP77',(469,298,790,522),(459,14,798,203)),
 (10,'8SP95',(54,290,375,522),(26,15,390,181)),
 (11,'10SP135',(460,298,793,520),(451,13,796,188)),
 (12,'10SP160',(43,280,376,512),(23,13,390,169)),
]
def canvas(p,rect,dpi):
    page=doc[p];s=72/dpi;h=page.rect.height
    x0=np.floor(rect[0]/s)*s;x1=np.ceil(rect[2]/s)*s
    y0=h-np.ceil((h-rect[1])/s)*s;y1=h-np.floor((h-rect[3])/s)*s
    box=(x0,y0,x1,y1)
    pix=page.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=fitz.Rect(x0,h-y1,x1,h-y0),alpha=False)
    arr=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,pix.n).copy()
    return RenderCanvas(p,box,dpi,arr,None)

snap=dict(source=src,output=dst,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),output_sha256=hashlib.sha256(raw).hexdigest(),pages=len(doc),page_sizes=[list(p.rect) for p in doc],charts=[])
for page,family,plotrect,tabrect in plans:
    p=page-1
    plot=canvas(p,plotrect,600);table=canvas(p,tabrect,450)
    plot.save_png(fresh(S.report(prefix+f'{family}-bieu-do.png')))
    table.save_png(fresh(S.report(prefix+f'{family}-bang.png')))
    words=R.ocr(table,scale=1,psm=6)
    ws=[dict(text=w['text'],rect=table.rect(w['box']),conf=w['conf'],line=w['line']) for w in words]
    lines={}
    for w in ws:lines.setdefault(str(w['line']),[]).append(w)
    texts=[' '.join(w['text'] for w in sorted(a,key=lambda w:w['rect'][0])) for a in lines.values()]
    Path(fresh(S.report(prefix+f'{family}-bang.txt'))).write_text('\n'.join(texts),encoding='utf8')
    snap['charts'].append(dict(page=page,table_family=family,plot_rect=plot.rect0,plot_dpi=600,plot_shape=list(plot.work.shape),table_rect=table.rect0,table_dpi=450,table_shape=list(table.work.shape),table_words=ws,table_lines=texts))
    print('ĐÃ CHỤP',page,family,'OCR',len(words),flush=True)
snap['current_output_sha256_after_capture']=hashlib.sha256(Path(dst).read_bytes()).hexdigest()
snap['unchanged_during_capture']=snap['current_output_sha256_after_capture']==snap['output_sha256']
Path(fresh(S.report(prefix+'TRANG THAI VA OCR.json'))).write_text(json.dumps(snap,ensure_ascii=False,indent=2),encoding='utf8')
print('CHỤP',len(plans),'biểu đồ; SHA256',snap['output_sha256'],'không đổi trong lúc chụp',snap['unchanged_during_capture'],flush=True)
E.close();doc.close()
