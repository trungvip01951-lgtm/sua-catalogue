from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np,math
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC'));audit=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
plan=json.loads((root/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM.json').read_text(encoding='utf8'));doc=json.loads((audit/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'));E=Editor(S.src(name));R=Raster(E);items=[]
for it in plan['items']:
 cv=R.canvas(max(R.images(it['page']-1),key=lambda z:z.W*z.H));ar=cv.orig.astype(int);lum=cv.orig.astype(float)@np.array([.299,.587,.114]);neutral=(lum<140)&((ar.max(2)-ar.min(2))<14);box=it['proposed_native_edit_bounding_box'];x0,y0,x1,y1=box;g=next(z for z in doc['graphs'] if z['family']==it['family']);c=next(z for z in g['curves'] if z['model']==it['model']);own=c['native_path'][:-1]+it['source_tail_core_extension_points'];paths={z['model']:z['native_path'] for z in g['curves'] if z.get('native_path')};paths[it['model']]=own
 pix=[]
 ys,xs=np.where(neutral[y0:y1,x0:x1]);
 for yy,xx in zip(ys+y0,xs+x0):
  distances=[]
  for model,path in paths.items():
   us=np.array([p['u'] for p in path]);vs=np.array([p['v'] for p in path]);
   if us[0]<=xx<=us[-1]:distances.append((abs(yy-np.interp(xx,us,vs)),model))
  distances.sort();pix.append(dict(u=int(xx),v=int(yy),RGB=ar[yy,xx].tolist(),nearest_path=distances[0][1] if distances else None,vertical_distance=float(distances[0][0]) if distances else None,is_own_curve=bool(distances and distances[0][1]==it['model'] and distances[0][0]<3)))
 view=(x0-8,y0-8,x1+8,y1+8);raw=Image.fromarray(cv.orig[view[1]:view[3],view[0]:view[2]]).resize(((view[2]-view[0])*8,(view[3]-view[1])*8),Image.Resampling.NEAREST);d=ImageDraw.Draw(raw)
 for p in pix:
  xx=(p['u']-view[0])*8;yy=(p['v']-view[1])*8;d.rectangle((xx,yy,xx+7,yy+7),outline='red' if p['is_own_curve'] else 'orange',width=1)
 item=dict(model=it['model'],neutral_core_threshold_pixels=len(pix),neutral_threshold_own_curve_pixels=sum(p['is_own_curve'] for p in pix),pixels=pix,no_literal_text_box_inside_edit_box=all(z['distance_from_edit_box_native_px']>0 for z in it['nearby_text_boxes']),interpretation='Ngưỡng màu không phải lớp chữ: đối chiếu vị trí từng pixel vào đúng nét nguồn. Các pixel đỏ thuộc nét đang sửa, màu cam thuộc nét khác; chưa chạm PDF. Cần giữ nét khác theo hình/vị trí, không chỉ bảo vệ toàn màu xám đen.')
 raw.save(fresh(root/it['model'].replace('/','-')/'DOI CHIEU LOI XAM THEO VI TRI.png'));items.append(item);print(it['model'],'NEUTRAL',len(pix),'OWN',item['neutral_threshold_own_curve_pixels'],'TYPES',sorted({p['nearest_path'] for p in pix if p['nearest_path']}))
Path(fresh(root/'DOI CHIEU LOI XAM 5 NET.json')).write_text(json.dumps(dict(read_only=True,pdf_written=False,items=items),ensure_ascii=False,indent=2),encoding='utf8');E.close()
