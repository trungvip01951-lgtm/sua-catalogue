from catwork import start,fresh
S,D,N=start()
from catfix.inspect_pdf import summary
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from catfix import verify
from pathlib import Path
import json,hashlib
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf'
root=Path(S.report('G07'));root.mkdir(exist_ok=True)
src=S.src(NAME);E=Editor(src);TL=TextLayer(E)
out=dict(source=src,destination=S.dst(NAME),sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),summary=summary(src),pages=[])
for pi in range(E.n_pages):
    lines=[]
    for text,gs in TL.text_lines(pi):
        bbox=[min(g.bbox[0] for g in gs),min(g.bbox[1] for g in gs),max(g.bbox[2] for g in gs),max(g.bbox[3] for g in gs)]
        lines.append(dict(text=text,bbox=bbox,glyphs=[dict(char=g.ch,bbox=g.bbox,font=g.run.font.basefont,size=g.run.size_page,
                                                       origin=g.o,fontname=str(g.run.fontname),run=g.run.index) for g in gs]))
    out['pages'].append(dict(page=pi+1,lines=lines))
    verify.crop(src,pi,E.mediabox(pi),140).save(fresh(root/f'nguon-p{pi+1}.png'))
print(out['summary'],flush=True)
json.dump(out,open(fresh(root/'inspection.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
