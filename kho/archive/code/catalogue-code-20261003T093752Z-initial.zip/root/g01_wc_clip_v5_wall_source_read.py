"""Only read full source rows to choose conservative geometric boundary manually."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
from PIL import Image
import numpy as np
ip=HERE/'wc_clip_source_du_lieu_20261003'/'DU LIEU DUONG CAT NGUON V4B BIEN THAN DUNG'/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json'
assert hashlib.sha256(ip.read_bytes()).hexdigest()=='d2356789b101589037eb587a6e75af4ce899e0c5297e6f316969217c162cce7a'
d=json.loads(ip.read_text(encoding='utf8'));out=[]
for num,title,x0,x1,y0,y1,seed in [(3,'Vách động cơ phải, chỗ vệt nước',584,622,493,543,620),(3,'Vách trái bơm trái',172,189,707,739,187),(2,'Vách trái bơm',392,406,780,831,404),(1,'Ngoài quai nhỏ',144,160,161,176,157)]:
    a=np.array(Image.open(d['groups'][num-1]['source_JPEG']).convert('RGB'),dtype=int)
    rr=[]
    print('GROUP',num,title,flush=True)
    for y in range(y0,y1):
        rgb=a[y,x0:x1];neutral=(rgb.max(axis=1)-rgb.min(axis=1)<=18)&(rgb.min(axis=1)<190)&(rgb.max(axis=1)>30)
        starts=[x0+k for k in range(len(rgb)-4) if neutral[k:k+4].all()]
        # Only a printed suggestion for reading rows; no cut geometry is computed from colors.
        first=min(starts) if starts else None
        if first is not None:
            band=list(range(max(x0,first-2),min(x1,first+3)))
            print('y',y,'first4_neutral',first,'pixel_RGB',[(x,a[y,x].tolist()) for x in band],flush=True)
        else:print('y',y,'no4neutral',flush=True)
        rr.append({'y':y,'x0':x0,'x1_exclusive':x1,'RGB':rgb.tolist(),'first4_neutral_reading_hint_only':first})
    out.append({'group':num,'region':title,'rows':rr,'note':'Color hint is diagnostic only, not a material mask or geometric cut. Boundary must be checked visually and kept conservative.'})
fp=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_04_HANG PIXEL NGUON CHO BIEN V5 KHONG TU KHOET.json'))
Path(fresh(fp)).write_text(json.dumps({'input_sha256':hashlib.sha256(ip.read_bytes()).hexdigest(),'source_rows':out,'no_new_image_PDF':True},ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',fp,flush=True)
