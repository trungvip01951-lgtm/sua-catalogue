from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,collections
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'))
d=json.loads((O/'g01_DO TIEU DIEN XAM VA VACH DIA PHUONG - CHO SOI ANH.json').read_text(encoding='utf8'))
for g in d['graphs']:
 if sys.argv[1:] and g['family'] not in sys.argv[1:]:continue
 print('FAMILY',g['family'],'Q TICKS',[(p['value_l_min'],round(p['position'],4)) for p in g['axis_Q_local']],'H TICKS',[(p['value_H_m'],round(p['position'],4)) for p in g['axis_H_local']])
 for c in g['curves']:
  if not c['points']:continue
  path=c.get('observed_trace',[]);issues=c.get('trace_ambiguities',[])
  print('MODEL',c['model'],'TRACE',[path[0]['u'],path[-1]['u']] if path else None,'AMB',len(issues))
  for p in c['points']:
   print('Q',p['Q_m3_h'],'H',p['H_table_m'],'x',round(p.get('u_from_actual_local_ticks') or 0,4),'y',round(p.get('v_gray_source') or 0,4),'NEW',round(p.get('H_curve_local_m') or 0,4),'DELTA',round(p.get('delta_H_m') or 0,4),'UNC',round(p.get('uncertainty_H_m') or 0,4),'WIDTH',[z['width'] for z in p.get('source_bracket',[])],'STAT',p['new_status'])
