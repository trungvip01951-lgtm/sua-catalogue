from catwork import start,fresh
from pathlib import Path
import json
S,D,N=start()
from catfix import charts
j=S.job('KTZ - LH Perotac (bản mới).pdf');info=[]
for pi,r,label in [(2,(77,358,524,522),'KTZ67.5 50Hz'),(3,(65,560,510,723),'KTZ32.2 60Hz'),(3,(65,358,510,522),'KTZ67.5 60Hz'),(6,(77,530,270,719),'LH637 50Hz')]:
    P=j.E.page(pi);gx,gy=charts.gridlines(P,r)
    curves=charts.curve_objects(P,r,color=(1,0,0))
    print(label,'gridx',gx,'gridy',gy,'curves',len(curves),flush=True)
    print('native labels',[(t,[(g.bbox) for g in gl]) for t,gl in j.TL.text_lines(pi) if t in ['67.5','32.2']],flush=True)
    for oi in curves:print(oi,tuple(round(float(v),3) for v in P.objs[oi]['bbox']),len(P.object_pagepath(oi)),flush=True)
    info.append(dict(page=pi+1,label=label,rect=r,gridx=gx,gridy=gy,curves=[dict(oi=oi,bbox=P.objs[oi]['bbox'],path=P.object_pagepath(oi),color=P.color_of(oi,'stroke'),width=P.objs[oi]['lw']) for oi in curves]))
Path(fresh(S.report('G09/DO THU DUONG NGUON.json'))).write_text(json.dumps(info,ensure_ascii=False,indent=2,default=str),encoding='utf-8');j.close()
