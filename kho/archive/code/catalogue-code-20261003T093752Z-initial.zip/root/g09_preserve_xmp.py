from catwork import start,fresh
from pathlib import Path
import json,hashlib
S,D,N=start()
from catfix.vector import Editor
from catfix.cs import Ref
import pymupdf as fitz
data=json.loads(Path(S.report('G09/NGUON.json')).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for d in data:
    dst=Path(S.dst(d['name']));sample=S.report('G09/MAU LAN2/'+d['name'])
    point=Path(S.report('G09/DIEM LUU '+d['short']+'.json'))
    if dst.exists():
        assert point.exists()
        rec=json.loads(point.read_text(encoding='utf-8'));assert dst.resolve().is_relative_to(Path(S.out_dir).resolve()) and sha(dst)==rec['sha256']
        archive=Path(fresh(S.report('G09/XMP BAN THU/'+d['name'])))
        assert archive.resolve().is_relative_to(Path(S.out_dir).resolve()) and not archive.exists()
        dst.rename(archive)
    A=Editor(S.src(d['name']))
    ref=Ref(A.doc.pdf.Root.Metadata.objgen)
    raw,left,_=A.doc.stream_decoded(ref);assert not left
    A.close()
    E=Editor(sample,backend='fitz')
    meta_ref=Ref((E.doc.doc.xref_xml_metadata(),0));assert meta_ref[0]>0
    E.doc.set_stream(meta_ref,raw)
    E.save(fresh(str(dst)));E.close()
    a=fitz.open(S.src(d['name']));b=fitz.open(str(dst))
    assert a.get_xml_metadata()==b.get_xml_metadata() and a.metadata==b.metadata
    a.close();b.close()
    Path(fresh(S.report('G09/DIEM LUU '+d['short']+' GIU XMP.json'))).write_text(json.dumps(dict(dst=str(dst),sha256=sha(dst),sample=sample,sample_sha256=sha(sample),xmp_sha256=hashlib.sha256(raw).hexdigest(),xmp_exact=True,backend='catfix fitz'),ensure_ascii=False,indent=2),encoding='utf-8')
    print(d['short'],'XMP nguyên vẹn, lưu:',dst,flush=True)
