"""Read-only whole-chart plan for Perotac 3SS3/3SS4, using their own source.

This reads actual source gray grid ink. It writes evidence/proposals only,
never a PDF, font bank, manufacturer value, or the shared progress file.
"""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from PIL import Image, ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from g04_perotac_whole_pdf_tools46 import sha
import numpy as np, json

NAME='Perotac bơm giếng SA_compressed (bản mới).pdf'
root=Path(S.report('G04/PHUONG AN TOAN BIEU DO TRANG02 VA03 CHI DOC/TOAN MIEN161 O BANG VA VACH THUC V2 CHI DOC'))
specs=[dict(page=2,family='3SS3',image='X1',flow_native_hint=[1368.5,1392,1416,1440,1464,1488,1512,1536,1560,1584,1608,1632,1655],
    flow_l_min=list(range(0,61,5)),flow_gray_column_band_y=[488,531],
    H_values=list(range(0,161,20)),H_native_hint=[467.4,431,395,359,323,287,251,215,179],H_gray_row_band_x=[1375,1505],
    label_boxes={8:[1417,401,1465,409],11:[1417,379,1465,387],16:[1417,345,1465,353],21:[1417,311,1465,319],26:[1417,273,1465,281],31:[1417,238,1465,246],37:[1417,199,1465,207]},
    chart_box=[1300,122,1710,635],table_box=[962,936,1695,1165],
    major_H_frame_labels=[0,160],source_frame_right_has_no_printed_flow_value=True,
    source_endpoint_l_min=60,source_endpoint_m3_h=3.6,
    legend_proposal_native=[1350,620,1700,710],legend_proposal_columns=2,legend_proposal_rows=4),
dict(page=3,family='3SS4',image='X2',flow_native_hint=[124.5,187,249,311,373,435,498,560,622,684],
    flow_l_min=list(range(0,91,10)),flow_gray_column_band_y=[590,668],
    H_values=list(range(0,121,15)),H_native_hint=[571.375,522.545,473.462,424.522,376,327,278,229.417,180.435],H_gray_row_band_x=[132,465],
    label_boxes={6:[254,481,302,489],9:[254,443,302,451],12:[254,403,302,411],16:[254,350,302,358],20:[254,299,302,307],24:[254,245,302,253],28:[254,192,302,201]},
    chart_box=[64,124,791,786],table_box=[60,936,793,1165],
    major_H_frame_labels=[0,120],source_frame_right_has_no_printed_flow_value=True,
    source_endpoint_l_min=90,source_endpoint_m3_h=5.4,
    legend_proposal_native=[124,790,746,855],legend_proposal_columns=3,legend_proposal_rows=3)]

def observed_line_center(gray,axis,hint,band):
    # Source pixel starts are integer; explicitly use center index+0.5.
    indexes=np.arange(int(np.floor(hint))-2,int(np.ceil(hint))+3)
    lo,hi=band
    sample=gray[lo:hi,indexes] if axis=='u' else gray[indexes,lo:hi]
    profile=(255-np.median(sample,axis=(0 if axis=='u' else 1)))/255
    peak=float(profile.max());selected=profile>=.8*peak
    center=float(np.average(indexes[selected]+.5,weights=profile[selected])) if peak>0 else None
    return dict(native_centers=(indexes+.5).tolist(),source_gray_contrast_profile=profile.tolist(),
        source_gray_core_center_native=center,source_gray_peak=peak,
        core_threshold_fraction=.8,source_native_pixel_center_convention='integer pixel starts + 0.5',
        JPEG_position_uncertainty_native_px=1,original_vector_tick_coordinate='CHUA THE XAC MINH')

E=Editor(S.src(NAME),backend='fitz');R=Raster(E);records=[];files=[]
for sp in specs:
    data=next(d for d in DATA if d['page']==sp['page'] and d['family']==sp['family'])
    images=R.images(sp['page']-1);im=max(images,key=lambda z:z.W*z.H)
    assert str(im.name)==sp['image'] and [im.W,im.H]==[1754,1247]
    cv=R.canvas(im);raw=cv.orig;gray=raw.mean(2)
    full_path=Path(fresh(root/(sp['family']+' NGUYEN TRANG NGUON150 KHONG SUA.png')))
    Image.fromarray(raw).save(full_path);files.append(full_path)
    model_labels=[]
    for row in data['rows']:
        b=sp['label_boxes'][row['suffix']];x0,y0,x1,y1=b
        path=Path(fresh(root/(row['model'].replace('/','_')+' NHAN TEN NGUON THAT.png')))
        Image.fromarray(raw[y0-2:y1+2,x0-2:x1+2]).resize(((x1-x0+4)*12,(y1-y0+4)*12),Image.Resampling.NEAREST).save(path)
        files.append(path)
        model_labels.append(dict(model=row['model'],label_literal_read_directly=row['model'],label_source_native_box=b,
            source_same_model_in_table=True,model_identity_from_printed_label_not_rank_H_or_kW=True,
            source_label_RGB_SHA256=__import__('hashlib').sha256(raw[y0:y1,x0:x1].tobytes()).hexdigest(),
            source_label_path=str(path)))
    flow=[]
    for value,hint in zip(sp['flow_l_min'],sp['flow_native_hint']):
        measurement=observed_line_center(gray,'u',hint,sp['flow_gray_column_band_y'])
        flow.append(dict(printed_l_min=value,printed_value_read_in_own_source_axis=True,**measurement))
    head=[]
    for value,hint in zip(sp['H_values'],sp['H_native_hint']):
        measurement=observed_line_center(gray,'v',hint,sp['H_gray_row_band_x'])
        head.append(dict(printed_H_m=value,printed_value_read_in_own_source_axis=True,**measurement))
    u=np.array([t['source_gray_core_center_native'] for t in flow]);q_l=np.array(sp['flow_l_min'])
    hv=np.array([t['source_gray_core_center_native'] for t in head]);h=np.array(sp['H_values'])
    assert np.all(np.diff(u)>0) and np.all(np.diff(hv)<0)
    nodes=[]
    for row in data['rows']:
        for Q,H in zip(data['Q_m3_h'],row['H']):
            # Both Q units are printed in this table; the conversion is also
            # checked against the corresponding printed L/min column.
            q_l_min=Q*1000/60;assert np.isclose(q_l_min,sp['flow_l_min'][data['Q_m3_h'].index(Q)])
            j=int(np.clip(np.searchsorted(h,H,side='right')-1,0,len(h)-2));local_head=[head[j],head[j+1]]
            native_u=float(np.interp(q_l_min,q_l,u));native_v=float(np.interp(H,h,hv))
            local_m_per_px=abs((h[j+1]-h[j])/(hv[j+1]-hv[j]))
            nodes.append(dict(model=row['model'],Q_m3_h=Q,printed_Q_l_min=q_l_min,H_m=H,
                Q_H_both_read_in_same_source_table=True,proposed_native_u=native_u,proposed_native_v=native_v,
                local_bracketing_H_ticks=[dict(H_m=t['printed_H_m'],native_v=t['source_gray_core_center_native']) for t in local_head],
                node_conversion_is_readonly_proposal_not_saved_curve=True,
                local_H_uncertainty_m_per1_native_px=local_m_per_px,
                acceptance_tolerance_H_m=max(1,.02*H)))
    record=dict(page=sp['page'],family=sp['family'],source_image_name=str(im.name),source_image_key=im.key,
        source_image_raw_sha256=__import__('hashlib').sha256(E.doc.stream_raw(im.ref)).hexdigest(),source_image_CTM=im.ctm.tolist(),
        source_table_native_box=sp['table_box'],source_Q_m3_h=data['Q_m3_h'],source_rows_H_m=data['rows'],source_numeric_cells=len(nodes),
        own_source_only=True,all161_table_values_visually_reread_before_plan=True,source_labels=model_labels,
        local_flow_tick_measurements=flow,local_head_tick_measurements=head,source_native_gray_sample_band_Q=sp['flow_gray_column_band_y'],
        source_native_gray_sample_band_H=sp['H_gray_row_band_x'],proposed104_style_NOT_COPIED_from_other_page=True,
        proposed_table_nodes_with_local_H_mapping=nodes,
        source_original_frame_right_native_has_no_printed_Q_value=True,curve_Q_domain=[0,sp['source_endpoint_m3_h']],
        endpoint_from_last_printed_table_column=True,no_extrapolation_to_frame_right=True,
        hydraulic_interpolation_plan='PCHIP monotone through all own-table Q/H nodes; no invented/extrapolated blank cells',
        interpolation_between_table_nodes_not_manufacturer_verified=True,
        eta_plan='Trace only each own original source eta ink; no eta table or p8/SL eta borrowed',
        eta_original_number_acceptance='CHUA THE XAC MINH: source has no numeric eta table',
        eta_source_centers_and_dash_style_have_not_yet_been_locked=True,
        source_typography_plan='Keep own source word geometry/size; build smooth contour only with own glyph evidence; preserve whole source literal island when uncertain',
        source_p8_glyph4_or_bank_reuse_NOT_AUTHORIZED_without_two_whole_char_same_transform_proof=True,
        source_font_program='CHUA THE XAC MINH: source image has no embedded font program',
        uniform_style_plan='Uniform source-backed graph style across entire plot; measure own color/ink width/dash before locking, not source JPEG width as original pen',
        own_RGB_equivalent_width_dash_and_typography_status='CHUA CHAY: only whole-chart proposal, no RAM/PDF for p2/p3',
        legend_space_proposal_native=sp['legend_proposal_native'],legend_columns=sp['legend_proposal_columns'],legend_rows=sp['legend_proposal_rows'],
        legend_layout_final_ROI_and_nearby_content_clearance='ROOT TO REVIEW; proposed area only, no cut executed',
        cleanup_plan='Complementary even-odd geometric clip of old Do/paths, keep own source text islands, no white cover/new mask/recompressed fullpage image',
        saved_PDF_count=0,writer_created=False,shared_progress_written=False)
    records.append(record)

doc=dict(stage='READ-ONLY WHOLE-PLOT PROPOSAL; NOT ACCEPTED OR DRAWN',source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)),
    total_models=14,total_source_H_cells=sum(r['source_numeric_cells'] for r in records),records=records,
    ROOT_confirmed_original_FAIL_points=[dict(page=2,model='3SS3/37',Q_m3_h=3.6,H_table=54,source_visible_H_ROOT=58.634),
        dict(page=3,model='3SS4/20',Q_m3_h=5.4,H_table=25,source_visible_H_ROOT=27.336),
        dict(page=3,model='3SS4/28',Q_m3_h=5.4,H_table=36,source_visible_H_ROOT=38.185)],
    G01_new_point_ROOT_verification_pending=dict(page=2,model='3SS3/31',Q_m3_h=3.6,H_table=45,source_H_measured_by_G01=48.8466958,
        uncertainty_m=2.2593448,lower_bound_H=46.587351,tolerance_m=1,status='FAIL reported by G01; ROOT independent decision pending'),
    G01_borderline_points_kept_UNKNOWN=['3SS3/26 Q3.6 H38','3SS4/24 Q5.4 H31'],
    immutable_source_evidence=[dict(path=str(p),sha256=sha(p)) for p in files],
    no_PDF_no_Font_no_shared_progress_mutated=True)
path=Path(fresh(root/'PHUONG AN7 QH91 O VA7 QH70 O CUC BO NGUON CHI DOC.json'))
path.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Phương án toàn biểu đồ trang 2–3 — CHỈ ĐỌC

Khóa trực tiếp 14 tên máy và 161 ô H của đúng bảng Perotac: trang 2 là 7 đường 3SS3 × 13 cột (91 ô); trang 3 là 7 đường 3SS4 × 10 cột (70 ô). Đã nhìn lại từng hàng trong ảnh bảng nguồn. Tên ở nhãn đồ thị khớp tên bảng, không gán đường theo thứ hạng cột áp hay công suất.

3 lỗi ROOT đã đo độc lập: 3SS3/37 tại Q3,6/H54; 3SS4/20 tại Q5,4/H25; 3SS4/28 tại Q5,4/H36. G01 báo thêm 3SS3/31 tại Q3,6/H45 lệch chắc; giữ trạng thái chờ ROOT xác minh. 3SS3/26 và 3SS4/24 ở điểm cuối vẫn CHƯA THỂ XÁC MINH.

Mỗi đường sẽ dựng toàn miền có số của chính hàng bảng, nội suy trơn giảm đơn điệu qua đủ các ô. Trang 2 kết thúc Q3,6 m³/h = 60 lít/phút; trang 3 kết thúc Q5,4 m³/h = 90 lít/phút. Khung bên phải còn rộng hơn, không lấy mép khung làm giá trị Q mới. Không kéo đường ra phần không có ô bảng.

Đã đọc lại các vạch bằng tâm mực xám nguồn, dùng tâm pixel = chỉ số + 0,5; chuyển từng H bằng hai vạch H thật bao quanh. Bất định tọa độ JPEG giữ ±1 pixel nguồn; không nhận tọa độ bút vẽ gốc là đã biết. Đây là tọa độ đề xuất, chưa có nét PDF để nghiệm thu.

Đường η phải đọc riêng nguồn của mỗi trang; chưa khóa tâm/nét đứt/RGB/độ dày/chữ. Không dùng η trang 8 hoặc catalogue khác. Nguồn không có bảng η, nên không nhận số hiệu suất đạt.

Đề xuất đủ 7 tên ở chú giải trong khoảng trống dưới mỗi biểu đồ, phải kiểm toàn trang và duyệt vị trí trước khi cắt. Chữ giữ dáng/cỡ từ chính nhãn trang tương ứng; không dùng bộ số 4 trang 8 khi chưa có đối chứng hai ký tự và một phép biến đổi. Với chữ không chắc, giữ nguyên cụm nguồn bằng đảo cắt hình học.

Chưa vẽ RAM/PDF trang 2–3, chưa có writer (mã ghi PDF), chưa thay bản giao hoặc tiến độ. Khi ROOT khóa các phép đo nét/chữ/bố cục, kỹ thuật dựng toàn biểu đồ dùng clip (vùng cắt hình học) bù để bỏ mực cũ, không sơn ô trắng, giữ ảnh nguồn và mọi vùng ngoài.
'''
mp=Path(fresh(root/'PHUONG AN TOAN BIEU DO TRANG02 VA03 V2 CHI DOC.md'));mp.write_text(md,encoding='utf8')
print('PROPOSAL',path,'SHA256',sha(path),'MODELS',doc['total_models'],'CELLS',doc['total_source_H_cells'],flush=True)
for row in records:
    print(row['family'],'Q LOCAL',[(t['printed_l_min'],round(t['source_gray_core_center_native'],4)) for t in row['local_flow_tick_measurements']],flush=True)
    print(row['family'],'H LOCAL',[(t['printed_H_m'],round(t['source_gray_core_center_native'],4)) for t in row['local_head_tick_measurements']],flush=True)
E.close()
