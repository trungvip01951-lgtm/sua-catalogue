from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.textlayer import TextLayer
from catfix import verify
from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,collections

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name);root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
progress=S.read_progress();Path(fresh(root/'TIEN DO DA DOC.txt')).write_text(progress,encoding='utf8')
print('PROGRESS G04', '\n'.join(line for line in progress.splitlines() if 'G04' in line),flush=True)
accept=json.loads(Path(S.report('G04/NGHIEM THU BAN CUOI NET PDF THAT.json')).read_text(encoding='utf8'));assert accept['accepted'] and accept['final_sha']==sha(dst)
E=Editor(src);R=Raster(E);TL=TextLayer(E);items=[];pics=[]
for pi in range(11):
 P=E.page(pi);ims=R.images(pi);source=max(ims,key=lambda x:x.W*x.H);assert source.W>1000 and source.H>1000 and 'Cfx' not in str(source.name)
 cv=R.canvas(source);text=[dict(text=r.text,bbox=list(r.bbox)) for r in TL.runs(pi)]
 previous=Path(S.report(f'G04/OCR/0-{pi+1}.json'));words=json.loads(previous.read_text(encoding='utf8')) if previous.exists() else []
 item=dict(page=pi+1,source_image=dict(name=str(source.name),width=source.W,height=source.H,dpi=float(source.dpi),page_bbox=list(source.page_bbox),ctm=source.ctm.tolist(),color_space=str(source.d.get('ColorSpace'))),all_images=[dict(name=str(x.name),width=x.W,height=x.H,page_bbox=list(x.page_bbox)) for x in ims],paint_objects=dict(collections.Counter(o['op'] for o in P.objs)),hidden_text_runs=text,previous_source_OCR_hint=words,explicitly_excluded_models=['4SA16/23','4SA16/18'] if pi==7 else [])
 items.append(item);path=fresh(root/f'NGUON TRANG {pi+1:02d}.png');verify.crop(src,pi,tuple(source.page_bbox),150).save(path)
 pic=Image.open(path);pic.thumbnail((800,570));tile=Image.new('RGB',(800,600),'white');tile.paste(pic,(0,24));ImageDraw.Draw(tile).text((2,2),f'Perotac SA - Trang {pi+1} NGUON',fill='black');pics.append(tile)
 print('PAGE',pi+1,item['source_image'],'hidden runs',len(text),'OCR hints',len(words),flush=True)
sheet=Image.new('RGB',(1600,600*6),'white')
for k,pic in enumerate(pics):sheet.paste(pic,((k%2)*800,(k//2)*600))
sheet.save(fresh(root/'MUC LUC 11 TRANG NGUON.png'))
out=dict(task='Kiểm toán toàn bộ biểu đồ Perotac SA, chỉ đọc trước',source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),read_only=True,pdf_written=False,previous_acceptance=accept,already_accepted_points=16,already_accepted_models=['4SA16/23','4SA16/18'],pages=items,progress_read=True,source_graphs_only_not_patches=True)
Path(fresh(root/'DINH VI VA NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
