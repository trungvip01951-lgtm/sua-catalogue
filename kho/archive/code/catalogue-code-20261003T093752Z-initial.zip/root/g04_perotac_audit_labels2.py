from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from pathlib import Path
from PIL import Image
import json,numpy as np

root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));src=S.src('Perotac bơm giếng SA_compressed (bản mới).pdf');E=Editor(src);R=Raster(E)
cols=[(1058,1118),(1434,1502),(1057,1103),(1415,1461),(247,297),(1133,1179),(265,311),(1139,1185),(285,331),(1158,1205),(281,332),(1158,1210),(280,332),(1066,1121),(1415,1468),(153,205),(524,579)]
out=[]
for rec,(a,b) in zip(DATA,cols):
 im=max(R.images(rec['page']-1),key=lambda im:im.W*im.H);cv=R.canvas(im);x0,y0,x1,y1=rec['plot_native_box'];box=(a,y0+18,b,y1-8)
 # A high-contrast OCR helper only, no change to any PDF or source file.
 orig=cv.orig;z=orig.astype(int);g=orig.astype(float)@np.array([.299,.587,.114]);cyan=(z[:,:,1]-z[:,:,0]>3)&(z[:,:,2]-z[:,:,0]>4)
 black=(g<145)&~cyan;cv.work=np.repeat(np.where(black,0,255).astype('uint8')[:,:,None],3,axis=2)
 words=R.ocr(cv,box,scale=6,psm=6)
 cv.work=orig.copy();file='NHAN NGUON '+rec['family'].replace('.','_')+'.png';cv.save_png(fresh(root/file),box,scale=5)
 lines={}
 for w in words:lines.setdefault(str(w['line']),[]).append(w)
 hints=[]
 for ws in lines.values():
  ws.sort(key=lambda w:w['box'][0]);bb=[min(w['box'][0] for w in ws),min(w['box'][1] for w in ws),max(w['box'][2] for w in ws),max(w['box'][3] for w in ws)]
  hints.append(dict(raw_text=' '.join(w['text'] for w in ws),box=bb,words=ws))
 out.append(dict(page=rec['page'],family=rec['family'],native_label_strip_box=box,original_label_image=file,hints=hints))
 print('LABEL2',rec['family'],[(h['raw_text'],round(h['box'][1],2),round(h['box'][3],2)) for h in hints],flush=True)
Path(fresh(root/'GOI Y NHAN COT LAN2.json')).write_text(json.dumps(dict(source=src,pdf_written=False,hint_only=True,graphs=out),ensure_ascii=False,indent=2),encoding='utf8');E.close()
