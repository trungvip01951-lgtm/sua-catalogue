from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,datetime
P='G05/KIEM TOAN TOAN BO/'
d=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'));bad=[c for c in d['curves'] if c['confirmed_failed_Q']]
current_source=hashlib.sha256(Path(d['source_path']).read_bytes()).hexdigest();current_output=hashlib.sha256(Path(d['output_path']).read_bytes()).hexdigest()
v=dict(source_sha256=current_source,output_sha256=current_output,source_unchanged=current_source==d['source_sha256'],output_is_audited_snapshot=current_output==d['output_sha256'],time=datetime.datetime.now().isoformat())
Path(fresh(S.report(P+'DOI CHIEU FILE SAU KIEM TOAN.json'))).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# KIỂM TOÁN ĐỘC LẬP G05 – BẢNG VÀ ĐƯỜNG Q–H',
 '',f"Đã đối chiếu {d['panel_count']} biểu đồ trên {d['page_count']} trang, {d['curve_count']} đường và {d['point_count']} mốc có số trong bảng của đúng bản PDF đích. Có {d['numeric_counts']['CHƯA ĐẠT']} mốc lệch chắc thuộc {len(bad)} đường. G05 chưa nghiệm thu xong. Trong đợt kiểm toán này chỉ đọc PDF và tạo hồ sơ đo.",
 '', 'Q là lưu lượng (m³/h); H là cột áp (m). Một đường thủy lực có thể dùng cho mã động cơ 1 pha và 3 pha; hai mã cùng hàng được lưu trong table_models. Không đếm hai mã đó thành hai đường.',
 '', '## Phiên tài liệu và tính bất biến', '',
 '- Bản được đo: '+d['output_path'],
 '- SHA256 bản được đo (mã kiểm tra nội dung): `'+d['output_sha256']+'`.',
 '- Nguồn: '+d['source_path'],
 '- SHA256 nguồn: `'+d['source_sha256']+'`.',
 '- Đối chiếu sau đo: nguồn không đổi = '+str(v['source_unchanged'])+'; đích đúng phiên đã chụp = '+str(v['output_is_audited_snapshot'])+'.',
 '- Đã chạy BƯỚC 0 qua catwork.start() trước khi dùng thư viện. Không chạy lại thao tác đánh dấu sửa PDF.',
 '', '## Phương pháp và giới hạn', '',
 'Các bảng được đọc bằng mắt từ ảnh đầy đủ. Dữ liệu nhận dạng chữ tự động chỉ hỗ trợ dò vị trí, không dùng làm số nghiệm thu. Ba chi tiết đã phóng to xác nhận: 6SP18-58 tại Q18=433; tiêu đề 10SP135 có Q126; hai mã 6SP36-26 lặp thật.',
 '', 'Trục chính được hiệu chuẩn theo các vạch Q/H. Trục Q đối chiếu với L/phút và m³/h phía dưới; không dùng trục gallon để suy nhầm. Đo bằng ít nhất ba lát sắc độ có đủ số đường theo nhãn/thứ tự thật. H bảng chỉ đưa vào sau khi xác định nét. Các nét đứt được nội suy giữa tiết diện có nét thật; đầu/cuối chỉ ngoại suy đoạn ngắn tối đa 1,8 điểm PDF. Điểm chữ che hoặc không giữ nét ổn định được ghi CHƯA THỂ.',
 '', 'Ảnh nền thật khoảng 150 điểm/inch, kiểm qua kích thước ảnh và ma trận đặt trên trang; ảnh chụp 600 điểm/inch chỉ phóng to. Sai số vị trí cộng bảo thủ: trục 0,24 điểm PDF; nét ít nhất 0,24 điểm, thêm độ dư fit và 0,06 điểm định tâm; sai số X 0,30 điểm đổi qua độ dốc nét thật. ĐẠT khi độ lệch cộng sai số ≤ max(1m,2%H); CHƯA ĐẠT khi độ lệch trừ sai số > ngưỡng; còn lại CHƯA THỂ. Các số nhiều chữ số lẻ trong JSON/CSV phục vụ đối chiếu tính toán, không thể hiện độ chính xác vật lý như vậy.',
 '', '## Phạm vi và kết quả', '',
 '| Trang | Họ bảng/đường | Đường | Mốc | Đạt về số | Lệch chắc | Chưa thể về số | Chưa đo được nét |',
 '|---|---|---:|---:|---:|---:|---:|---:|']
for z in d['summary']:
 f=z['family'] if z['family']!='4SP14' else '4SP14 / 4SP15 (tên chưa thống nhất)';n=z['numeric_counts'];lines.append(f"| {z['page']} | {f} | {z['curves']} | {z['points']} | {n['ĐẠT']} | {n['CHƯA ĐẠT']} | {n['CHƯA THỂ']} | {z['unmeasured']} |")
lines+=['',f"Tổng số: {d['numeric_counts']['ĐẠT']} ĐẠT, {d['numeric_counts']['CHƯA ĐẠT']} CHƯA ĐẠT, {d['numeric_counts']['CHƯA THỂ']} CHƯA THỂ về sai lệch. Trong số chưa thể có {d['unmeasured']} mốc chưa tách được nét. Nếu kể bất nhất danh tính, kết quả toàn mốc là {d['overall_counts']['ĐẠT']} ĐẠT / {d['overall_counts']['CHƯA ĐẠT']} CHƯA ĐẠT / {d['overall_counts']['CHƯA THỂ']} CHƯA THỂ.",
 '', '220 đường đều có đủ danh sách Q/H bảng; tổng mốc được cộng trực tiếp từ từng hàng, không nhập tay. Không dựng dữ liệu cho ô trống. Các đồ thị hiệu suất có ở dưới biểu đồ Q–H nhưng không có bảng hiệu suất bằng số trong PDF này nên chưa xác minh được bằng số.',
 '', '## Đường lệch rõ', '', '| Trang | Mã đường | Các Q lệch chắc (m³/h) |', '|---|---|---|']
for c in bad:lines.append(f"| {c['page']} | {c['curve_model']} | {', '.join(str(q) for q in c['confirmed_failed_Q'])} |")
lines+=['', 'Họ 6SP30: 17 đường có lệch chắc; 6SP30-2/-3 còn CHƯA THỂ. Họ 6SP60: 10 đường có lệch chắc; ba đường nhỏ còn CHƯA THỂ. Hai điểm 10SP135-5/-7 ở Q180 lệch nhỏ hơn nhiều so với hai họ trên, cần kiểm độc lập ảnh và sai số trước sửa.',
 '', 'Ví dụ 6SP30-42 tại Q42: bảng 148 m, nét khoảng 171,12 m; Q36: bảng 241 m, nét khoảng 259,96 m. 6SP60-20 tại Q72: bảng 103 m, nét khoảng 109,56 m; Q78: bảng 72 m, nét khoảng 79,62 m.',
 '', '## Hai dòng 6SP36-26 và họ 4SP14/4SP15', '',
 'Trang6 có hai hàng 26: hàng19 H0=351, hàng20 H0=378; đều 37kW (đơn vị công suất), 50HP (mã lực). Đối chiếu tất cả 21 đường cho thấy mỗi hàng khớp duy nhất một đường tại mọi Q: hàng19 với nhãn26, hàng20 với nhãn28. Hàng20 đạt đủ10/10 mốc khi kể sai số ảnh. Hàng19 có9 mốc đạt và1 mốc sát ngưỡng; danh tính vẫn phân biệt rõ với đường28/24 vì các đối chiếu chéo sai ở mọi mốc. Có căn cứ nội bộ cho AI điều phối sửa tên hàng20 thành28, giữ nguyên số Q/H.',
 '', 'Trang8 chỉ có một hàng6SP36-26 rồi hàng30. Hàng26: chiều dài cụm bơm P=2768mm, động cơ3pha M(t)=1208mm, tổng T(t)=3976mm, khối lượng tương ứng55,7/117,3/173,0kg. Không có kích thước hàng28; không suy ra hay bổ sung số thiếu.',
 '', 'Họ4SP14/4SP15: cả bảng ghi14 còn biểu đồ/nhãn đường ghi15. Đã đo theo cùng số tầng và lưu hai tên. Chưa có căn cứ chọn tên chuẩn, giữCHƯA THỂ danh tính và không đổi mã.',
 '', '## Hồ sơ chính để đọc tiếp', '',
 '- `NGHIEM THU QH.json` và `NGHIEM THU QH.csv`: đủ2218 mốc, sai lệch, sai số, trạng thái và tiết diện nét thực.',
 '- `NGHIEM THU TUNG DUONG.csv`: đủ220 đường và từng Q/H.',
 '- `BANG QH DOC BANG MAT.json/.csv`: bảng đọc trực tiếp từ ảnh.',
 '- `HIEU CHUAN TRUC V2.json`: toàn bộ vạch/ma trận trục.',
 '- `NGHIEM THU/`: đủ15 ảnh đánh dấu; tím là số bảng, xanh là đạt, đỏ là lệch chắc, cam làchưa thể.',
 '- `BANG DAY DU/`: ảnh15 bảng đủ cột; `CHI TIET/`: các chứng cứ cần phóng lớn.',
 '- `HAI DUONG UU TIEN.json`: hai mẫu6SP30-6/6SP60-20, đủ số bảng, tọa độ mục tiêu và số đo.',
 '- `HAI HANG 6SP36-26 - CAN CU NOI BO.json`: công suất, kích thước thật và đối chiếu duy nhất.',
 '- `DO PHAN GIAI ANH GOC.json`, `DOI CHIEU FILE SAU KIEM TOAN.json`: độ phân giải và mã kiểm tra.',
 '', 'Các tệp `DO NET BAN DAU`, `DUONG THEO DOI BAN DAU`, `DO NET DOC LAP` và `MOC DO`/`KIEM NET THEO DOI` là bản thử bị loại vì nhận nhầm chữ hoặc quầng nén. Không dùng chúng để kết luận. `DO NET DOC LAP V2` là phép đo trung gian; hồ sơ cuối đọc `NGHIEM THU QH` vì đã cộng đầy đủ sai số X/Y/trục/nét.',
 '', '## Bàn giao', '',
 'Đợt đọc đã hoàn tất; PDF chưa được sửa trong đợt kiểm toán. AI điều phối đã giao người kiểm toán làm người ghi duy nhất G05 ở bước kế tiếp: tạo ảnh mẫu sạch, sửa các đường có căn cứ, rồi nghiệm thu lại PDF cuối. Không dùng kết quả này để ghi G05 XONG.']
Path(fresh(S.report(P+'BAO CAO KIEM TOAN DOC LAP.md'))).write_text('\n'.join(lines)+'\n',encoding='utf8')
S.progress('G05 – kiểm toán độc lập','CHƯA XONG',f"Đã đọc đủ15 biểu đồ/220 đường/2218 mốc; số1109 đạt,83 lệch chắc,1026chưa thể (90chưa tách nét);83 lệch thuộc29đường. Hồ sơ G05/KIEM TOAN TOAN BO/NGHIEM THU QH.json. Chưa sửa PDF trong lượt đo; tiếp theo tạo mẫu và sửa đường.")
print('REPORT',S.report(P+'BAO CAO KIEM TOAN DOC LAP.md'),'HASH',v,flush=True)
