"""Pure source-alpha contour math: no files, tasks, PDF API or brand data."""
import numpy as np
import cv2
from scipy.ndimage import gaussian_filter

def optical_mass_smooth(a,sigma=.5):
    a=np.asarray(a,float);z=gaussian_filter(np.pad(a,8),sigma,mode='constant')[8:-8,8:-8]
    lo,hi=.5,2.
    for _ in range(60):
        k=(lo+hi)/2
        if np.clip(z*k,0,1).sum()<a.sum():lo=k
        else:hi=k
    factor=(lo+hi)/2
    return np.clip(z*factor,0,1),factor

def rounded_loop(c,up=4,epsilon=.15,radius=1.):
    """Source pixel coordinates, including half-high-res-pixel foreground offset."""
    raw=np.asarray(c,dtype=np.float32)
    if len(raw)<3:return []
    simplified=cv2.approxPolyDP(raw,epsilon*up,True)[:,0,:].astype(float)
    if len(simplified)<3:return []
    # High-resolution contour points are pixel centres. Expand the foreground by
    # half a high-res pixel to undo OpenCV boundary-centre shrinkage; tree hole
    # orientation is inverse, so the same left normal shrinks white holes.
    p=(simplified+.5)/up
    shifted=[]
    for i,v in enumerate(p):
        prev=p[i-1];nxt=p[(i+1)%len(p)];a=v-prev;b=nxt-v
        na=np.array([-a[1],a[0]])/max(np.linalg.norm(a),1e-12)
        nb=np.array([-b[1],b[0]])/max(np.linalg.norm(b),1e-12)
        n=na+nb;nn=np.linalg.norm(n)
        if nn<1e-9:n=na
        else:n=n/nn
        denom=max(.5,float(n@na));shifted.append(v+n*(.5/up)/denom)
    p=np.array(shifted);entry=[];exit=[]
    for i,v in enumerate(p):
        prev=p[i-1];nxt=p[(i+1)%len(p)];la=np.linalg.norm(v-prev);lb=np.linalg.norm(nxt-v)
        r=min(radius,.35*la,.35*lb)
        entry.append(v+(prev-v)*r/max(la,1e-12));exit.append(v+(nxt-v)*r/max(lb,1e-12))
    path=[('m',[exit[-1].tolist()])]
    for v,a,b in zip(p,entry,exit):
        path.append(('l',[a.tolist()]))
        path.append(('c',[(a+(v-a)*2/3).tolist(),(b+(v-b)*2/3).tolist(),b.tolist()]))
    path.append(('h',[]))
    return path

def source_vector_layers(alpha,sigma=.5,up=4,steps=32,epsilon=.15,radius=1.):
    z,factor=optical_mass_smooth(alpha,sigma)
    fine=cv2.resize(z.astype(np.float32),(z.shape[1]*up,z.shape[0]*up),interpolation=cv2.INTER_CUBIC)
    fine=np.clip(fine,0,1);layers=[]
    for i in range(steps):
        threshold=(i+.5)/steps;value=(i+1)/steps
        m=(fine>=threshold).astype(np.uint8)
        contours,hierarchy=cv2.findContours(m,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        if hierarchy is None:continue
        loops=[]
        for idx,c in enumerate(contours):
            path=rounded_loop(c,up=up,epsilon=epsilon,radius=radius)
            if not path:continue
            depth=0;parent=hierarchy[0,idx,3]
            while parent>=0:depth+=1;parent=hierarchy[0,parent,3]
            loops.append(dict(path=path,tree_depth=int(depth),foreground=bool(depth%2==0)))
        if loops:layers.append(dict(threshold=float(threshold),alpha_equivalent=float(value),gray_fill=float(1-value),loops=loops))
    return dict(smooth_alpha=z.tolist(),source_area_pixel=float(np.asarray(alpha).sum()),smooth_area_pixel=float(z.sum()),
        mass_normalization=factor,gaussian_sigma_px600=sigma,physical_smoothing_sigma_pt=sigma*.12,
        contour_upsampling=up,levels=steps,polygon_simplification_tolerance_px600=epsilon,
        corner_fillet_radius_px600=radius,foreground_offset_px600=.5/up,layers=layers)
