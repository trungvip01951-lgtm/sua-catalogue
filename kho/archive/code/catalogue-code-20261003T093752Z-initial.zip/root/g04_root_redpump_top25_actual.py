"""ROOT: đọc mực PDF thật của 4SL16/25; chỉ tạo hồ sơ, không ghi catalogue."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
import json, hashlib, math
import numpy as np
import pymupdf as fitz
from PIL import Image, ImageDraw

root = Path(S.report('G04/ROOT REDPUMP DIEM CUOI 25'))
manifest_path = Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO/DANH MUC BANG NGUON 196 DONG V2.json'))
manifest = json.loads(manifest_path.read_text(encoding='utf8'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(manifest['source']) == manifest['source_SHA256']
assert sha(manifest['current']) == manifest['current_SHA256']
row = next(r for r in manifest['rows'] if r['model'] == '4SL16/25')
# Đã đọc trực tiếp toàn trang nguồn: hàng /25, đúng đầu cột Q 21.
assert row['Q'] == [0, 3, 6, 9, 12, 15, 18, 21]
assert row['H'] == [148, 145, 138, 125, 110, 93, 75, 54]
ax, bx, ay, by = [12.332833970672802, 59.078002472685455,
                   1.2403508488278085, 321.690994341148]
scale = 600 / 72
out = []
for tag, path in [('NGUON', manifest['source']), ('BAN GIAO', manifest['current'])]:
    with fitz.open(path) as doc:
        page = doc[7]
        pageheight = page.rect.height
        clip = fitz.Rect(ax * 20.5 + bx, pageheight - (ay * 65 + by),
                         ax * 21.55 + bx, pageheight - (ay * 44 + by))
        pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), clip=clip, alpha=False)
        raw = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, pix.n)[:, :, :3].copy()
        columns = []
        for q in [20.85, 20.93, 21.0, 21.07, 21.15]:
            xx = int(round((ax * q + bx) * scale)) - pix.x
            profile = raw[:, xx].astype(float)
            chroma = profile[:, 1:].mean(axis=1) - profile[:, 0]
            gray = profile @ np.array([.299, .587, .114])
            indices = np.flatnonzero((chroma > 7) & (gray < 235))
            groups = np.split(indices, np.flatnonzero(np.diff(indices) > 1) + 1) if len(indices) else []
            runs = []
            for group in groups:
                if len(group) < 3:
                    continue
                v = float(np.average(group, weights=chroma[group]))
                top_y = (pix.y + v) / scale
                got_h = (pageheight - top_y - by) / ay
                runs.append(dict(pixel_interval=[int(group[0]), int(group[-1])],
                                 observed_H_m=float(got_h), center_pixel=v,
                                 chroma_weight=float(chroma[group].sum())))
            assert len(runs) >= 2, (tag, q, runs)
            # Chính nét trên cùng đã được nối với nhãn /25 trên ảnh toàn đồ thị;
            # không chọn nhánh bằng độ gần H=54 trong bảng.
            columns.append(dict(Q_requested=q, Q_actual=((pix.x + xx) / scale - bx) / ax,
                                runs_top_to_bottom=runs, selected_run_index=0))
        target = columns[2]
        h21 = target['runs_top_to_bottom'][0]['observed_H_m']
        actual_x = bx + ax * target['Q_actual']
        draw = ImageDraw.Draw(Image.fromarray(raw))
        image_out = Image.fromarray(raw)
        draw = ImageDraw.Draw(image_out)
        col_x = int(round(actual_x * scale)) - pix.x
        center = target['runs_top_to_bottom'][0]['center_pixel']
        draw.line((col_x, 0, col_x, image_out.height - 1), fill=(220, 20, 20), width=1)
        draw.ellipse((col_x - 4, center - 4, col_x + 4, center + 4), outline=(220, 20, 20), width=1)
        image_out.resize((image_out.width * 3, image_out.height * 3), Image.Resampling.NEAREST).save(fresh(root / (tag + ' Q21 MUC PDF THAT 600dpi.png')))
        # Giữ riêng ảnh không đánh dấu cho phép đọc lại độc lập.
        Image.fromarray(raw).save(fresh(root / (tag + ' Q21 600dpi KHONG DANH DAU.png')))
        label_clip = fitz.Rect(130, 89, 168, 104)
        label = page.get_pixmap(matrix=fitz.Matrix(12, 12), clip=label_clip, alpha=False)
        label.save(fresh(root / (tag + ' NHAN TREN CUNG PDF THAT.png')))
        out.append(dict(file=path, SHA256=sha(path), page=8, H_table_m=54,
                        H_actual_Q21_m=h21, delta_m=h21-54, tolerance_m=1.08,
                        native_H_pixel_m=150/387.5,
                        actual_render_H_pixel_m=1/(scale*ay),
                        columns=columns, clip_top_left=list(clip), pix_origin=[pix.x,pix.y],
                        identity='Nét trên cùng nối với nhãn hiện hành 4SL16/25; không chọn theo H bảng.'))
assert max(abs(z['H_actual_Q21_m'] - 57.184555416358144) for z in out) < .6
assert abs(out[0]['H_actual_Q21_m'] - out[1]['H_actual_Q21_m']) < .01
# Giữ độ bất định thận trọng của phép đọc riêng nguồn, không dùng dpi600 để
# giả định ảnh nén150dpi có thêm độ phân giải vật lý.
uncertainty_m = .65
assert all(abs(z['delta_m']) - uncertainty_m > z['tolerance_m'] for z in out)
result = dict(source_manifest=str(manifest_path), model='4SL16/25', records=out,
              source_table_directly_viewed=True, source_axis_previously_verified_by_ROOT=True,
              independent_method='Tâm tiết diện mực màu trên PDF thật600dpi; nhóm mực trên cùng được khóa bằng nhãn/nét, không khớp theo H bảng.',
              uncertainty_m=uncertainty_m, result='CHƯA ĐẠT: Q21 phải H54, mực thật khoảng H57.2',
              original_and_canonical_written=False)
Path(fresh(root / 'ROOT DOC MUC Q21 DOC LAP.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
assert sha(manifest['source']) == manifest['source_SHA256']
assert sha(manifest['current']) == manifest['current_SHA256']
print(json.dumps(dict(model='4SL16/25', H_table=54, actual_H=[z['H_actual_Q21_m'] for z in out],
                      uncertainty_m=uncertainty_m, result=result['result'], report=str(root)), ensure_ascii=False))
