from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from pathlib import Path
import json
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf';E=Editor(S.src(NAME));TL=TextLayer(E);out={}
for label,rect in [('outlets',(1100,620,1150,715)),('800header',(909,548,938,559)),('technical8',(800,620,950,635)),('thread',(750,247,783,260))]:
    gs=TL.glyphs(0,rect=rect);out[label]=[dict(char=g.ch,code=g.cb.hex(),font=g.run.font.basefont,name=str(g.run.fontname),size=g.run.size_page,rect=g.bbox,origin=g.o,run=g.run.index) for g in gs]
    print(label,out[label],flush=True)
out['myriad']=[dict(text=r.text,rect=[r.glyphs[0].o,r.glyphs[-1].e],size=r.size_page,name=str(r.fontname)) for r in TL.runs(0) if r.font and 'MyriadPro' in r.font.basefont and r.glyphs]
print('Myriad:',out['myriad'],flush=True)
seen=set();out['fonts']=[]
for r in TL.runs(0):
    f=r.font
    if id(f) in seen:continue
    seen.add(id(f));codes={}
    for ch in '38G ”':
        try:codes[ch]=f.encode(ch).hex()
        except Exception as ex:codes[ch]=str(ex)
    prog=f._font_program();cmap={}
    if prog and prog[0]=='tt' and prog[1] is not None:
        cmap=[dict(pid=t.platformID,eid=t.platEncID,for3=t.cmap.get(51),for8=t.cmap.get(56)) for t in prog[1]['cmap'].tables]
    if prog and prog[0]=='cff' and prog[1] is not None:cmap=list(prog[1].CharStrings.charStrings.keys())
    out['fonts'].append(dict(font=f.basefont,name=str(r.fontname),codes=codes,cmap=cmap))
json.dump(out,open(fresh(Path(S.report('G07'))/'numeric-fonts.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
