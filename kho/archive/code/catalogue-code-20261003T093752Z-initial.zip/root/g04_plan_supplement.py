from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster

base=json.loads(Path(S.report('G04/KE HOACH Redpump.json')).read_text(encoding='utf-8'))
d=base['file'];E=Editor(d['src']);R=Raster(E);cvs={}
def cv_for(page):
    if page not in cvs:
        im=R.images(page-1)[0]
        cvs[page]=R.render_canvas(page-1,(0,0,d['width'],d['height']),dpi=300) if im.has_stencil_mask else R.canvas(im)
    return cvs[page]

changes=[]
for task,page,old,new,rr,learn,action,label in [
    (39,3,'7.5','8.7',(761,265,772.5,274.3),(647,250,806,498),'replace','3SL3/31 M(T)'),
    (42,9,'2143','2112',(649,341,664,348),(646,338,806,475),'replace','4SL12/32 P(mm)'),
    (45,11,'6SL 35/20','6SL35/20',(72.5,493.5,97,500),(69,392,285,502),'close_gap','Nhãn đầu đường 6SL35/20'),
    (46,10,'.','',(87.5,496.5,94,504),(87.5,496.5,94,504),'dot','Chỉ dấu chấm, không chạm chữ L')]:
    cv=cv_for(page); hits=R.find(cv,old,box=cv.box(rr),scale=4,psm=7)
    if len(hits)==1:hit=hits[0]
    else:
        # Đối chiếu ảnh nguồn đã soi: OCR bỏ dấu chấm/đọc sai chữ; tách đúng số nét gốc.
        cc=R.components(cv,cv.box(rr),expect=len(old.replace(' ','')))
        assert len(cc)==len(old.replace(' ','')),(task,len(cc),old)
        box=(min(c['box'][0] for c in cc)-1,min(c['box'][1] for c in cc)-1,max(c['box'][2] for c in cc)+1,max(c['box'][3] for c in cc)+1)
        hit=dict(text=old,box=box,line_text=old,words=[],manual_source_image_confirmed=True)
    p=dict(task=task,page=page,old=old,new=new,rect=cv.rect(hit['box']),search=rr,learn=learn,align='left' if action in ('dot','close_gap') else 'center',action=action,label=label,hit=hit)
    changes.append(p);print(task,old,'->',new,p['rect'])
plans=[p for p in base['plans'] if p['task']!=46]+changes
assert len(plans)==43
Path(fresh(S.report('G04/KE HOACH Redpump bo sung.json'))).write_text(json.dumps(dict(file=d,plans=plans,fails=[]),ensure_ascii=False,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),encoding='utf-8')
E.close()
