"""Read unit donors in this Perotac source only. No PDF or banks are changed."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from g04_perotac_audit_data import DATA
from g04_perotac_whole_pdf_tools46 import read,sha
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'DON VI CUNG TEP DOI CHIEU NGUON CHI DOC V2 KHONG CHE CROP'
E=Editor(S.src(name),backend='fitz');R=Raster(E)
tiles=[];records=[]
for row in DATA:
    pi=row['page']-1;im=max(R.images(pi),key=lambda z:z.W*z.H);cv=R.canvas(im)
    b=row['plot_native_box'];bottom=b[3];left=b[0];right=b[2]
    unitbox=[right-45,bottom+100,right+15,bottom+145]
    etabox=[left-48,bottom,left-2,bottom+29]
    raw1=cv.orig[unitbox[1]:unitbox[3],unitbox[0]:unitbox[2]]
    raw2=cv.orig[etabox[1]:etabox[3],etabox[0]:etabox[2]]
    tile=Image.new('RGB',(850,1050),'white');dr=ImageDraw.Draw(tile)
    dr.text((5,5),f"p{row['page']} {row['family']} X{im.key} m3-box{unitbox} eta-box{etabox}",fill='black')
    tile.paste(Image.fromarray(raw1).resize((raw1.shape[1]*12,raw1.shape[0]*12),Image.Resampling.NEAREST),(5,40))
    tile.paste(Image.fromarray(raw2).resize((raw2.shape[1]*12,raw2.shape[0]*12),Image.Resampling.NEAREST),(5,650))
    tiles.append(tile);records.append(dict(page=row['page'],family=row['family'],image_name=str(im.name),image_key=im.key,unit_candidate_box=unitbox,eta_candidate_box=etabox))
atlas=Image.new('RGB',(850*3,1050*((len(tiles)+2)//3)),'white')
for i,tile in enumerate(tiles):
    atlas.paste(tile,((i%3)*850,(i//3)*1050))
    tile.save(fresh(root/(f"p{records[i]['page']} {records[i]['family']} HAI CUM NGUON.png")))
atlas.save(fresh(root/'17 BIEU DO DON VI NGUON CUNG CATALOGUE.png'))
Path(fresh(root/'VI TRI DON VI NGUON CUNG TEP CHI DOC.json')).write_text(json.dumps(dict(source_sha256=sha(S.src(name)),canonical_sha256=sha(S.result(name)),records=records,no_other_catalogue_font_or_image=True,no_PDF_bank_or_progress_changed=True),ensure_ascii=False,indent=2),encoding='utf8')
E.close();print(str(root),flush=True)
