from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor,union
from catfix.otext import OutlineText
from catfix import charts
from g02_glyphs import chart_refs,group_labels
from pathlib import Path
import pickle,json
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
E=Editor(S.result(NAME));T=OutlineText(E)
T.__dict__.update(pickle.loads(Path(S.report('G02/glyph-doc-chuan.pkl')).read_bytes()));T.E=E
maps=json.loads(Path(S.report('G02/ban-do-chuan.json')).read_text(encoding='utf-8'))
refs=chart_refs(T);out={}
for ps,mp in maps.items():
    p=int(ps)-1;gx,gy=mp['grid'];b=mp['curve_bbox']
    # Lattice positions at both boundaries may sit just beyond existing curves.
    box=[min(gx),min(gy)-20,max(gx),max(gy)+20]
    labels,unknown=group_labels(T,p,box,refs)
    out[ps]={'plot_coarse':box,'labels':[dict(text=l['text'],bbox=l['bbox'],angle=l['angle'],y=l['y'],res=l['res'],ois=[g.oi for g in l['glyphs']]) for l in labels],'unknown':[{'oi':g.oi,'bbox':g.bbox,'char':g.char} for g in unknown]}
    print('PAGE',ps,[(l['text'],round(l['y'],2),round(l['angle'],1)) for l in labels],'UNKNOWN',[(g.oi,g.char) for g in unknown],flush=True)
Path(fresh(S.report('G02/nhan-da-doc-lan-2.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=1),encoding='utf-8')
E.close()
