from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor,union
from catfix.otext import OutlineText
from catfix import charts
from pathlib import Path
import pickle,json,numpy as np
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';E=Editor(S.result(NAME));T=OutlineText(E)
T.__dict__.update(pickle.loads(Path(S.report('G02/glyph-doc-chuan.pkl')).read_bytes()));T.E=E
maps=json.loads(Path(S.report('G02/ban-do-chuan.json')).read_text(encoding='utf-8'))
out={}
for ps,mp in maps.items():
    p=int(ps)-1;P=E.page(p);coarse=mp['coarse'];b=mp['curve_bbox'];gx,gy=mp['grid']
    x0=min(gx);x1=max(gx)
    # Filter actual numeric glyphs in the narrow strip to exclude the vertical orange caption.
    xt=charts.ticks_from_labels(T,p,(x0-15,coarse[1]-35,x1+15,min(gy)+5),'x')
    yt=charts.ticks_from_labels(T,p,(x0-45,min(gy)-24,x0-7,max(gy)+26),'y')
    objs=[]
    for oi in P.objects_in(coarse):
        o=P.objs[oi];bb=o['bbox'];col=P.color_of(oi,'fill')
        if (bb[2]-bb[0]>120 and bb[3]-bb[1]<1.5) or (bb[3]-bb[1]>120 and bb[2]-bb[0]<1.5):
            objs.append({'oi':oi,'op':o['op'],'bbox':bb,'fill':col,'stroke':P.color_of(oi,'stroke')})
    out[ps]={'xt':xt,'yt':yt,'major':objs}
    print('PAGE',ps,'XT',xt,'YT',yt,'MAJOR',objs,flush=True)
Path(fresh(S.report('G02/truc-nguon.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=1),encoding='utf-8')
E.close()
