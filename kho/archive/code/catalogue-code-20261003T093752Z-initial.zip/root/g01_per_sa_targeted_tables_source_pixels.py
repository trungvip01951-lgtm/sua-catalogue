from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=S.src('Perotac bơm giếng SA_compressed (bản mới).pdf');dst=S.result('Perotac bơm giếng SA_compressed (bản mới).pdf')
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));d=json.loads((O/'g01_DO MOC TU TIET DIEN MUC THUC VA VACH ETA - V2 CHO DOC NHAN.json').read_text(encoding='utf8'));E=Editor(src);R=Raster(E);proof=[]
for g in d['graphs']:
 if not g['points']:continue
 rec=next(z for z in DATA if z['family']==g['family']);im=max(R.images(g['page']-1),key=lambda z:z.W*z.H);rgb=R.canvas(im).orig;box=rec['table_native_box'];x0,y0,x1,y1=box;fp=Path(fresh(O/f'g01_{g["family"]}_BANG CHINH JPEG NGUON KHONG CHINH PIXEL.png'));Image.fromarray(rgb[y0:y1,x0:x1]).save(str(fp));proof.append({'page':g['page'],'family':g['family'],'source_table_native_bbox':box,'path':str(fp),'sha256':sha(fp),'all_cells_transcribed_from_prior_audit':rec['rows'],'Q_columns_from_same_table':rec['Q_m3_h'],'target_points':[(p['model'],p['Q_m3_h'],p['H_table_m']) for p in g['points']],'only_audit_target_cells_need_new_visual_review':True,'new_visual_source_review_pending':True,'source_pixels_unchanged':True})
fp=Path(fresh(O/'g01_DANH SACH13 BANG CUNG FILE CAN DOC231 MOC.json'));fp.write_text(json.dumps({'source':src,'source_sha256':sha(src),'current_sha256':sha(dst),'read_only':True,'no_source_image_retouched':True,'tables':proof},ensure_ascii=False,indent=2),encoding='utf8');E.close();print('TABLES',len(proof),'TARGETS',sum(len(p['target_points']) for p in proof),'FILE',str(fp),'SHA',sha(fp))
