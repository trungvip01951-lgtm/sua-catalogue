"""Ảnh nguồn riêng cho ROOT đọc 104 ô và vạch từng tệp; không ghi catalogue."""
from catwork import start, fresh
S,D,N=start()
from pathlib import Path
import hashlib,json
import pymupdf as fitz
base=Path(S.report('G04/ROOT DOC NGUON104 VA TRUC LOCAL TRANG8'))
assert not base.exists();base.mkdir(parents=True)
rows=[]
for tag,name in [('PEROTAC SA','Perotac bơm giếng SA_compressed (bản mới).pdf'),('REDPUMP SL','Redpump gieng SL_compressed (bản mới).pdf')]:
    src,cur=Path(S.src(name)),Path(S.result(name))
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    before=dict(source=sha(src),current=sha(cur))
    with fitz.open(src) as a,fitz.open(cur) as b:
        p=a[7]
        # Mọi ảnh đọc lại trực tiếp từ đúng PDF nguồn, không lấy ảnh tác nhân làm nguồn.
        table=fitz.Rect(14,390,389,590)
        diagram=fitz.Rect(24,55,385,367)
        for suffix,clip,scale in [('TOAN TRANG',p.rect,2.0),('BANG104 NGUON',table,5.0),('VACH TRUC NGUON',diagram,4.0)]:
            p.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=clip,alpha=False).save(fresh(base/f'{tag} {suffix}.png'))
        im1=p.get_pixmap(matrix=fitz.Matrix(4,4),clip=table,alpha=False)
        im2=b[7].get_pixmap(matrix=fitz.Matrix(4,4),clip=table,alpha=False)
        rows.append(dict(file=name,hashes=before,page=8,table_source_current_identical_pixels=im1.samples==im2.samples,
                         table_clip_top_left=list(table),image_reader='MuPDF chỉ đọc',page_rect=list(p.rect),fonts=p.get_fonts(full=True)))
    assert before==dict(source=sha(src),current=sha(cur))
Path(fresh(base/'ROOT ANH DOC SO104 - CHUA NGHIEM THU MAU.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False),flush=True)
