"""Read-only native glyph/font inventory, independent of old G03 conclusion."""
from catwork import start, fresh, HERE
S, D, N = start()
import sys
sys.path.insert(0, str(HERE))
from pathlib import Path
from collections import Counter
from catfix.vector import Editor
from catfix.otext import OutlineText, shape_of, norm, procrustes
from catfix.textlayer import TextLayer
import pikepdf, pymupdf as fitz, hashlib, json, numpy as np

O = 'G03/PHUC HOI CHU k DUNG NGUON 03-10-2026/'
grp = D['groups']['G03'] if isinstance(D['groups'], dict) else next(z for z in D['groups'] if z.get('id', z.get('group')) == 'G03')
name = 'Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'
assert name in json.dumps(grp, ensure_ascii=False)
src, dst = S.src(name), S.dst(name)
sha = lambda f: hashlib.sha256(Path(f).read_bytes()).hexdigest()
hashes = dict(source=sha(src), canonical=sha(dst))
assert hashes['source'] == 'd5244aa6c2e2772a636a2040fe6853fbcb53fdb417ff7e8ee316528339087c1f'
assert hashes['canonical'] == 'fbc99ed3b402bb373832cd5153e35474a10f2c97c195be4b34f6320f20cf257e'
rootproof = S.report('G03/NGHIEM THU DOC LAP ROOT.json')
old = json.loads(Path(rootproof).read_text(encoding='utf8'))
assert old['curve_count'] == 69 and old['point_count'] == 414
progress = S.read_progress()

font_objects, font_streams, font_alias_dicts, unicode_maps, stream_ops = [], [], [], [], []
resources = []
with pikepdf.open(src) as pdf:
    for i, obj in enumerate(pdf.objects):
        if not isinstance(obj, (pikepdf.Dictionary, pikepdf.Stream)):
            continue
        keys = set(str(k) for k in obj.keys())
        if str(obj.get('/Type', '')) in ['/Font', '/FontDescriptor'] or keys.intersection(['/BaseFont', '/FontName', '/FontDescriptor', '/DescendantFonts']):
            font_objects.append(dict(xref=i+1, object_description=str(obj)))
        for key in ['/FontFile', '/FontFile2', '/FontFile3']:
            if key in obj:
                ff = obj[key]
                font_streams.append(dict(owner=i+1, key=key, font_xref=list(ff.objgen), decoded_bytes=len(ff.read_bytes())))
        if '/Font' in obj:
            font_alias_dicts.append(dict(owner=i+1, aliases=str(obj['/Font'])))
        if '/ToUnicode' in obj or '/CMapName' in obj or '/CIDSystemInfo' in obj:
            unicode_maps.append(dict(owner=i+1, keys=sorted(keys)))
        if isinstance(obj, pikepdf.Stream) and str(obj.get('/Subtype', '')) != '/Image':
            try:
                ops = pikepdf.parse_content_stream(obj)
            except Exception:
                continue
            seen = Counter(str(v.operator) for v in ops)
            text_ops = {k:v for k,v in seen.items() if k in ['BT','ET','Tf','Tj','TJ',"'",'"','Tr']}
            if text_ops:
                stream_ops.append(dict(xref=i+1, type=str(obj.get('/Subtype', '')), text_operators=text_ops))
    resources = [dict(page=i+1, resource_keys=sorted(str(k) for k in pg.obj.get('/Resources', {}).keys())) for i, pg in enumerate(pdf.pages)]

E = Editor(src, backend='fitz'); T = OutlineText(E)
T.learn(range(10), dpi=400, verbose=False)
TL = TextLayer(E); doc = fitz.open(src)
pages, targets, k_sources, stroke_extra = [], [], [], []
paint_total = Counter(); glyph_total = Counter()
for pi in range(10):
    P = E.page(pi)
    native_glyphs = T.page_glyphs(pi)
    chars = Counter(g.char for g in native_glyphs)
    lines = []
    for txt, gs in T.text_lines(pi):
        box = [min(g.bbox[0] for g in gs), min(g.bbox[1] for g in gs), max(g.bbox[2] for g in gs), max(g.bbox[3] for g in gs)]
        lines.append(dict(text=txt, bbox_bottom_left=box, glyphs=[dict(char=g.char, object_index=g.oi, subs=g.g['subs'], bbox=g.bbox, style=g.style, cluster=g.cl) for g in gs]))
    for txt in ['KW', 'Kw', 'kW']:
        for m in T.find(pi, txt):
            row=dict(page=pi+1, old=txt, bbox_bottom_left=m.bbox, source_glyphs=[dict(char=g.char, object_index=g.oi, subs=g.g['subs'], bbox=g.bbox, style=g.style, cluster=g.cl) for g in m.glyphs])
            for c in ['k', 'W']:
                try:
                    gl, scale, sid=T._source(m.glyphs[0].style, c)
                    row['source_'+c]=dict(page=gl.key+1, object_index=gl.oi, bbox=gl.bbox, source_style=sid, scale=scale)
                except Exception as ex:
                    row['source_'+c+'_error']=str(ex)
            targets.append(row)
    for g in native_glyphs:
        if g.char in ['k', 'K']:
            k_sources.append(dict(page=pi+1, char=g.char, object_index=g.oi, bbox=g.bbox, style=g.style, cluster=g.cl, page_path=E.glyph_pagepath(pi,g.oi,g.g)))
    paints=Counter(o['op'] for o in P.objs); paint_total.update(paints)
    merged_counts=Counter()
    for oi, o in enumerate(P.objs):
        if o['op'] not in ['f','F','f*','S','s','B','b','B*','b*']:
            continue
        for g in P.merged_glyphs(oi):
            merged_counts[o['op']]+=1
            bb=g['bbox']; w=bb[2]-bb[0]; h=bb[3]-bb[1]
            if o['op'] not in ['S','s','B','b','B*','b*'] or not (.15<w<90 and .15<h<90):
                continue
            try:
                ops, pts=shape_of(E,pi,oi,g); nn=norm(pts)
            except Exception:
                continue
            matched=[]
            for ci, cl in enumerate(T.clusters):
                if cl['ops']==ops and cl['pts'].shape==nn.shape:
                    delta=float(np.max(abs(cl['pts']-nn)))
                    if delta<.03:
                        matched.append(dict(cluster=ci,char=cl['label'],style=cl['style'],delta_normalized=delta))
            stroke_extra.append(dict(page=pi+1, object_index=oi, op=o['op'], bbox=bb, subs=g['subs'], fill=P.color_of(oi,'fill'),stroke=P.color_of(oi,'stroke'),linewidth=o.get('lw'), matches=matched, path=E.glyph_pagepath(pi,oi,g)))
    glyph_total.update(merged_counts)
    real_runs=TL.runs(pi)
    pages.append(dict(page=pi+1, paint_object_count=len(P.objs), paint_counts=dict(paints), merged_glyph_counts_all_paints=dict(merged_counts), learnt_outline_glyph_count=len(native_glyphs), outline_character_counts=dict(chars), outline_lines=lines, real_text_run_count=len(real_runs),fitz_font_list=doc[pi].get_fonts(full=True),fitz_image_list=doc[pi].get_images(full=True),fitz_extractable_text=doc[pi].get_text()))
    print('SOURCE INVENTORY',pi+1,'OUTLINE',len(native_glyphs),'S EXTRAS',sum(v['page']==pi+1 for v in stroke_extra),'FONTS',len(doc[pi].get_fonts()),'LOWER k',chars.get('k',0),flush=True)

styles=[]
for sid, st in T.styles.items():
    source={}
    for c, ci in st.get('src',{}).items():
        gl=T.clusters[ci]['members'][0]
        source[c]=dict(page=gl.key+1, object_index=gl.oi, bbox=gl.bbox, cluster=ci, subs=gl.g['subs'])
    styles.append(dict(style=sid, chars=''.join(sorted(source)), sources=source, metrics=st.get('metrics')))

out=dict(read_only=True,task=34,group=grp,source=src,canonical=dst,source_sha256=hashes['source'],canonical_sha256=hashes['canonical'],old_root_acceptance=rootproof,old_root_acceptance_sha256=sha(rootproof),old_69_curves_414_points_held=True,source_inventory_complete_objects=True,font_objects=font_objects,font_streams=font_streams,font_alias_dicts=font_alias_dicts,unicode_maps=unicode_maps,actual_nonimage_text_stream_operators=stream_ops,page_resource_keys=resources,pages=pages,targets_KW_Kw=targets,lower_or_upper_K_source_glyphs=k_sources,all_merged_stroke_or_fill_stroke_letter_size_candidates=stroke_extra,paint_objects_all10_counts=dict(paint_total),merged_glyphs_all10_counts=dict(glyph_total),styles=styles,all_lower_k_cluster_candidates=[dict(cluster=i,label=cl['label'],style=cl['style'],member_count=len(cl['members'])) for i,cl in enumerate(T.clusters) if cl['label']=='k'],unknown_outline_cluster_count=sum(cl['label']=='?' for cl in T.clusters),progress_snapshot=progress,no_pdf_written=True,no_shared_progress_written=True,conclusion_pending_shape_visual_review=True)
outfile=fresh(S.report(O+'01 KIEM KE NGUON FONT ALIAS UNICODE VA TAT CA NET VE.json'))
Path(outfile).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda q:q.tolist() if isinstance(q,np.ndarray) else float(q)),encoding='utf8')
for pi in range(10):
    fp=fresh(S.report(O+f'ANH NGUON/P{pi+1} NGUON TOAN TRANG150.png'))
    doc[pi].get_pixmap(matrix=fitz.Matrix(150/72,150/72),alpha=False).save(fp)
E.close();doc.close()
assert sha(src)==hashes['source'] and sha(dst)==hashes['canonical']
print('FONT COUNTS',len(font_objects),len(font_streams),len(font_alias_dicts),len(unicode_maps),'TEXTSTREAMS',len(stream_ops),flush=True)
print('K GLYPHS',Counter(v['char'] for v in k_sources),'TARGETS',len(targets),'STROKE CANDIDATES',len(stroke_extra),'UNKNOWN CLUSTERS',out['unknown_outline_cluster_count'],flush=True)
print('PRIVATE EVIDENCE',outfile,flush=True)
