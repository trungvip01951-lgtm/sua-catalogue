from catwork import start, fresh
S,D,N=start()
from catfix.raster import Raster
from catfix.vector import Editor
from catfix import verify
from pathlib import Path
import json
NAME='Aquaris FS_300dpi_75% (bản mới).pdf'
root=Path(S.report('G06'));E=Editor(S.src(NAME));R=Raster(E)
out=[]
for pi in range(4):
    im=R.image_at(pi,E.mediabox(pi));cv=R.canvas(im)
    words=R.ocr(cv,scale=2,psm=11)
    lines={}
    for w in words:
        lines.setdefault(str(w['line']),[]).append(w)
    body=[]
    for ws in lines.values():
        ws.sort(key=lambda w:w['box'][0]);b=[min(w['box'][0] for w in ws),min(w['box'][1] for w in ws),max(w['box'][2] for w in ws),max(w['box'][3] for w in ws)]
        body.append(dict(text=' '.join(w['text'] for w in ws),box=b,rect=cv.rect(b),words=ws))
    bank=R.glyph_bank(cv,words=words)
    ks=[]
    for sample in bank['samples']:
        if 'k' in sample['text']:
            ks.append(dict(text=sample['text'],box=sample['word']['box'],rect=cv.rect(sample['word']['box']),size=sample['size']))
    out.append(dict(page=pi+1,lines=body,k_sources=ks,image=str(im)))
    print('Trang',pi+1,'k:',ks,flush=True)
    if pi==0:
        verify.crop(S.src(NAME),pi,(25,596,302,681),400).save(fresh(root/'so-do.png'))
    if pi==3:
        verify.crop(S.src(NAME),pi,(286,382,559,697),400).save(fresh(root/'bang-chi-tiet.png'))
json.dump(out,open(fresh(root/'probe.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
