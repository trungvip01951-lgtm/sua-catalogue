from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,csv
from scipy.ndimage import gaussian_filter
from scipy.signal import find_peaks
P='G05/KIEM TOAN TOAN BO/'
bs=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
def intr(a,b,v):return float(np.interp(v,a,b))
out=[];summ=[]
for b in bs:
 f=b['family'];t=TABLES[f];n=len(t['rows']);r=b['rect'];s=72/b['dpi'];im=Image.open(S.report(P+f+'-bieu-do-du-truc.png')).convert('RGB');g=np.array(im.convert('L'),float)
 xt=np.array(b['xticks']);yt=np.array(b['yticks']);xp=lambda q:(intr(xt[:,0],xt[:,1],q)-r[0])/s;yp=lambda h:(r[3]-intr(yt[:,0],yt[:,1],h))/s;hd=lambda y:intr(yt[:,1],yt[:,0],r[3]-y*s)
 l=round(xp(0));right=round(xp(b['Qmax']));top=round(yp(b['Hmax']));bot=round(yp(0));ink=255-g
 full=np.zeros_like(g);full[top+8:bot-8,:]=ink[top+8:bot-8,:]
 # Bỏ ô tên ở góc phải trên, được nhìn rõ trong ảnh nguồn; vùng này không có đường Q-H.
 title_x=int(l+.78*(right-l));title_y=int(yp(b['Hmax']*.85));full[top:title_y,title_x:right+3]=0
 full=gaussian_filter(full,(.5,.5))
 draw=ImageDraw.Draw(im);counts=[]
 for iq,q in enumerate(t['Q']):
  x=xp(q);sets=[]
  offsets=list(range(-32,33,4))
  if q==0:offsets=list(range(8,33,3))
  if iq==len(t['Q'])-1:offsets=list(range(-32,1,3))
  cs=[]
  for dx in offsets:
   xx=round(x+dx);v=np.mean(full[:,xx-1:xx+2],axis=1)
   pk,pr=find_peaks(v,prominence=20,height=70,distance=7)
   pk=pk[(pk>top+10)&(pk<bot-8)];cs.append((dx,len(pk)))
   if len(pk)==n:
    cy=[]
    for p in pk[::-1]:
     ids=np.arange(p-2,p+3);w=np.maximum(0,v[ids]-np.min(v[ids]));cy.append(float(np.sum(ids*w)/sum(w)) if sum(w)>0 else float(p))
    sets.append((float(xx),np.array(cy)))
  counts.append(dict(Q=q,candidates=cs,exact_slices=len(sets)))
  for k,row in enumerate(t['rows']):
   p=dict(page=b['page'],family=f,row=k+1,curve_model=row['curve_model'],table_models=' | '.join(row['table_models']),Q_m3h=q,H_table_m=row['H'][iq],identity_uncertain=row.get('identity_uncertain',False) or t['plot_family']!=f,slices=len(sets))
   cx=x;cy=yp(p['H_table_m']);draw.line((cx-5,cy,cx+5,cy),fill=(180,0,225),width=2);draw.line((cx,cy-5,cx,cy+5),fill=(180,0,225),width=2)
   if len(sets)<3:
    p.update(H_curve_m=None,nominal_status='CHƯA THỂ',confidence_status='CHƯA THỂ',reason='Không đủ ba lát cắt nhận đủ đường độc lập')
   else:
    xx=np.array([v[0] for v in sets]);yy=np.array([v[1][k] for v in sets]);cf=np.polyfit(xx,yy,1);res=np.abs(yy-np.polyval(cf,xx));cy=float(np.polyval(cf,x));hc=hd(cy);spread=float(max(res));extrap=max(min(xx)-x,x-max(xx),0)*s
    uncp=max(2.0,spread)+.5;un=abs(hd(cy+uncp)-hc);dev=abs(hc-p['H_table_m']);lim=max(1,.02*p['H_table_m'])
    if spread>3.5 or abs(cf[0])>1.9 or extrap>1.8:
     p.update(H_curve_m=None,nominal_status='CHƯA THỂ',confidence_status='CHƯA THỂ',reason='Lát cắt không giữ cùng nét ổn định hoặc cách biên quá xa',local_spread_px=round(spread,5),slope=float(cf[0]),extrap_pt=round(extrap,5))
    else:
     confidence='ĐẠT' if dev+un<=lim else ('CHƯA ĐẠT' if dev-un>lim else 'CHƯA THỂ')
     p.update(H_curve_m=round(hc,5),deviation_m=round(dev,5),limit_m=round(lim,5),uncertainty_m=round(un,5),nominal_status='ĐẠT' if dev<=lim else 'CHƯA ĐẠT',confidence_status=confidence,local_spread_px=round(spread,5),slope=float(cf[0]),extrap_pt=round(extrap,5),x_px=round(x,4),y_px=round(cy,4),sample_locations=[dict(x_px=v[0],y_px=float(v[1][k])) for v in sets],reason='')
     color=(0,130,30) if confidence=='ĐẠT' else ((220,20,20) if confidence=='CHƯA ĐẠT' else (220,130,0));draw.ellipse((x-3,cy-3,x+3,cy+3),outline=color,width=2)
   p['overall_status']=p['confidence_status'] if not p['identity_uncertain'] else 'CHƯA THỂ';out.append(p)
 im.save(fresh(S.report(P+'MOC DO DOC LAP V2/'+f+'.png')))
 summ.append(dict(family=f,page=b['page'],curves=n,points=len(t['Q'])*n,profiles=counts))
 print('RANK',f,'points',len(t['Q'])*n,'sets',[v['exact_slices'] for v in counts],flush=True)
Path(fresh(S.report(P+'DO NET DOC LAP V2.json'))).write_text(json.dumps(dict(summary=summ,points=out),ensure_ascii=False,indent=2),encoding='utf8')
fields=list(dict.fromkeys(k for p in out for k in p if k!='sample_locations'))
with open(fresh(S.report(P+'DO NET DOC LAP V2.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(out)
print('TOTAL',len(out),{v:sum(p['confidence_status']==v for p in out) for v in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']},flush=True)
