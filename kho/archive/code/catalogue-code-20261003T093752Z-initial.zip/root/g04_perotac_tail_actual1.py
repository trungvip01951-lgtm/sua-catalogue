"""Đọc lại PDF mẫu thật, tách số trên path khỏi mực nhìn thấy/độ dày.
Không sửa PDF. Không ghi tiến độ. Giữ kết quả chưa được ROOT nhận.
"""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import charts,verify
from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np,hashlib,math,xml.etree.ElementTree as ET
import pymupdf as fitz
name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name);folder=Path(S.report('G04/NAM DUOI NET PDF THAT MAU1'));build=json.loads((folder/'TAO MAU1 VA KIEM NGOAI.json').read_text(encoding='utf8'));trial=build['trial'];plan=json.loads(Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC/PHUONG AN CUOI 5 DIEM DE ROOT KIEM V2.json')).read_text(encoding='utf8'));audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==build['source_sha256'] and sha(current)==build['current_sha256'] and sha(trial)==build['trial_sha256']
E=Editor(trial);R=Raster(E);Eb=Editor(current);Rb=Raster(Eb);numeric=[];styles=[];images=[];pixels=[];equivalent=[];ghosts=[];actualcurves={};protectedchecks=[]
def snap(file,pi,rect):
 with fitz.open(file) as d:
  p=d[pi];T=p.transformation_matrix;scale=600/72;p0=fitz.Point(rect[0],rect[1])*T;p1=fitz.Point(rect[2],rect[3])*T;r=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y));px=p.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=r,colorspace=fitz.csRGB,alpha=False);ar=np.frombuffer(px.samples,dtype=np.uint8).reshape(px.height,px.width,px.n)[:,:,:3].copy();return ar,(T,px.x,px.y,scale)
def at(point,mapinfo):
 T,x0,y0,s=mapinfo;p=fitz.Point(*[float(z) for z in point])*T;return p.x*s-x0,p.y*s-y0
for rec in build['records']:
 pi=rec['page']-1;model=rec['model'];P=E.page(pi);base=Eb.page(pi);want=np.array(rec['RGB'])/255;hits=[]
 for oi,o in enumerate(P.objs):
  col=P.color_of(oi,'stroke')
  if o['op']=='S' and col is not None and max(abs(np.array(col)-want))<1e-7:hits.append((oi,o,P.object_pagepath(oi)))
 assert len(hits)==1,(model,len(hits));oi,o,pp=hits[0];sample=charts.sample_path(pp,n=1600);im=max(R.images(pi),key=lambda z:z.W*z.H);cv=R.canvas(im);native=np.array([cv.to_px(*z) for z in sample]);assert np.all(np.diff(native[:,0])>=-1e-9) and np.all(np.diff(native[:,1])>=-1e-9);actualcurves[model]=native
 g=next(z for z in audit['graphs'] if z['family']==model.split('/')[0]);hc=g['axis']['H_grid_calibration'];cal=g['axis']['calibration'];q=(native[:,0]-cal['u_Q0'])/(cal['u_per_l_min']*1000/60);h=(native[:,1]-hc['v_H0'])/hc['v_per_m']
 for node in rec['numeric_nodes']:
  hh=float(np.interp(node['Q_m3_h'],q,h));delta=hh-node['H_table_m'];tol=max(1,.02*node['H_table_m']);numeric.append(dict(model=model,page=pi+1,Q_m3_h=node['Q_m3_h'],H_table_m=node['H_table_m'],actual_true_path_H_m=hh,delta_m=delta,tolerance_m=tol,result='ĐẠT MỐC PATH' if abs(delta)<=tol else 'CHƯA ĐẠT',join_retains_existing_source_H=node is rec['numeric_nodes'][0],does_not_accept_whole_curve=True));assert abs(delta)<=tol,(model,node,hh)
 assert abs(q[-1]-rec['new_end_stops_at_last_numeric_Q'])<1e-6;assert abs(o['lw']-rec['equivalent_width_pt'])<1e-8;assert o['dash'] is None or not o['dash'][0]
 styles.append(dict(model=model,object_index=oi,actual_RGB=[float(v*255) for v in P.color_of(oi,'stroke')],actual_equivalent_width_pt=o['lw'],clip=o.get('clip'),actual_pagepath=pp,actual_numeric_Q_domain=[float(q[0]),float(q[-1])],monotone_H=True,source_w_not_available_from_JPEG=True))
 # Read actual source/current/trial pixels with exact pixmap origin, using the
 # same source ink color vector for equivalent transverse-area measurements.
 A,mapA=snap(current,pi,rec['page_box']);B,mapB=snap(trial,pi,rec['page_box']);assert A.shape==B.shape
 c=next(z for z in g['curves'] if z['model']==model);pc=next(z for z in plan['items'] if z['model']==model);old=c['native_path'][:-1]+pc['source_tail_core_extension_points'];oldxy=np.array([[p['u'],p['v']] for p in old]);cols=[];width_old=[];width_new=[];cores_old=[];cores_new=[];gridx=[t['u_native'] for t in g['axis']['flow_ticks']];gridy=[t['v_native'] for t in hc['ticks']]
 for u in np.arange(rec['numeric_nodes'][0]['u']+7,rec['numeric_nodes'][-1]['u']-7,1.0):
  ov=float(np.interp(u,oldxy[:,0],oldxy[:,1]));nv=float(np.interp(u,native[:,0],native[:,1]));
  if min(abs(u-x) for x in gridx)<3 or min(abs(ov-y) for y in gridy)<3 or min(abs(nv-y) for y in gridy)<3:continue
  pair=[]
  for ar,mi,vv,path,cores in [(A,mapA,ov,oldxy,cores_old),(B,mapB,nv,native,cores_new)]:
   xx,yy=at(cv.to_page(u,vv),mi);xi=int(round(xx));samp=np.arange(max(0,int(yy)-20),min(ar.shape[0],int(yy)+21));pix=ar[samp,xi].astype(float);background=np.median(np.vstack([pix[:3],pix[-3:]]),axis=0);ink=np.array(rec['RGB']);alpha=np.clip((background-pix)@(background-ink)/np.sum((background-ink)**2),0,1);loc=path[abs(path[:,0]-u)<5];slope=float(np.polyfit(loc[:,0],loc[:,1],1)[0]);pair.append(float(alpha.sum()/np.sqrt(1+slope*slope)*72/600));lum=pix@np.array([.299,.587,.114]);on=pix[lum<220];
   if len(on):cores.extend(on[(on@np.array([.299,.587,.114]))<=np.percentile(on@np.array([.299,.587,.114]),20)].tolist())
  if len(pair)==2:cols.append(float(u));width_old.append(pair[0]);width_new.append(pair[1])
 equivalent.append(dict(model=model,measurement='PDF600dpi, same background-normalized ink-area projection divided by observed local slope; not a literal original pen width',same_native_columns=cols,source_current_median_equivalent_width_pt=float(np.median(width_old)),trial_median_equivalent_width_pt=float(np.median(width_new)),median_width_difference_pt=float(np.median(width_new)-np.median(width_old)),source_current_width_p10_p90=np.percentile(width_old,[10,90]).tolist(),trial_width_p10_p90=np.percentile(width_new,[10,90]).tolist(),source_current_dark_core_RGB=np.median(cores_old,axis=0).tolist(),trial_dark_core_RGB=np.median(cores_new,axis=0).tolist(),physical_600dpi_pixel_size_pt=72/600,visual_acceptance_pending_ROOT=True))
 # Visible centroid at each actual numeric node, including endpoint cap.
 for node in rec['numeric_nodes']:
  xx,yy=at(cv.to_page(node['u'],node['v']),mapB);xi=int(np.floor(xx));ys=np.arange(max(0,int(yy)-18),min(B.shape[0],int(yy)+19));strip=B[ys,max(0,xi-1):min(B.shape[1],xi+2)].astype(float);gray=strip@np.array([.299,.587,.114]);weight=np.maximum(225-gray,0).sum(axis=1);ok=weight>2
  if ok.any():
   yobs=float(np.average(ys[ok]+.5,weights=weight[ok]));pagep=fitz.Point((xx+mapB[1])/mapB[3],(yobs+mapB[2])/mapB[3])*~mapB[0];uobs,vobs=cv.to_px(pagep.x,pagep.y);hobs=(vobs-hc['v_H0'])/hc['v_per_m'];pixels.append(dict(model=model,Q_m3_h=node['Q_m3_h'],H_table_m=node['H_table_m'],visible_centroid_H_m=float(hobs),visible_delta_m=float(hobs-node['H_table_m']),threshold_m=max(1,.02*node['H_table_m']),cap_profile_bias_possible=True,read_from_actual_PDF=True,result='KHỚP MỐC MỰC' if abs(hobs-node['H_table_m'])<=max(1,.02*node['H_table_m']) else 'CHƯA ĐẠT'))
  else:pixels.append(dict(model=model,Q_m3_h=node['Q_m3_h'],result='CHƯA THỂ XÁC MINH',reason='No actual visible ink near numeric path node'))
 # Inspect old center where the corrected curve is clearly separated. Skip
 # real lattice crossing positions, never relabel remaining dark ink as grid.
 flagged=[];evaluated=0
 for u,v in oldxy:
  if u<rec['numeric_nodes'][0]['u']+5 or min(abs(v-y) for y in gridy)<2:continue
  if u<=native[-1,0]:
   nv=float(np.interp(u,native[:,0],native[:,1]));loc=native[abs(native[:,0]-u)<5];sl=float(np.polyfit(loc[:,0],loc[:,1],1)[0]) if len(loc)>3 else 0
   if abs(v-nv)/np.sqrt(1+sl*sl)<2.5:continue
  xx,yy=at(cv.to_page(u,v),mapB);xi=int(round(xx));yi=int(round(yy));reg=B[max(0,yi-2):yi+3,max(0,xi-1):xi+2];l=reg.astype(float)@np.array([.299,.587,.114]);evaluated+=1
  if len(l) and l.min()<215:flagged.append(dict(u_native=float(u),v_native=float(v),visible_min_luminance=float(l.min()),pixel_xy=[xi,yi]))
 ghosts.append(dict(model=model,old_center_sections_checked=evaluated,dark_residual_candidates=flagged,not_visual_accepted_until_ROOT=True));print('ACTUAL',model,'NUM',[(x['Q_m3_h'],round(x['actual_true_path_H_m'],4)) for x in numeric if x['model']==model],'VISIBLE',[(x['Q_m3_h'],round(x.get('visible_centroid_H_m',0),4),x['result']) for x in pixels if x['model']==model],'WIDTH',equivalent[-1]['source_current_median_equivalent_width_pt'],equivalent[-1]['trial_median_equivalent_width_pt'],'GHOST',len(flagged),flush=True)
for pi in range(E.n_pages):
 a=max(Rb.images(pi),key=lambda z:z.W*z.H);b=max(R.images(pi),key=lambda z:z.W*z.H);rawA=Eb.doc.stream_raw(a.ref);rawB=E.doc.stream_raw(b.ref);ctmEqual=np.max(abs(a.ctm-b.ctm))<1e-9;images.append(dict(page=pi+1,source_image_name=str(a.name),raw_JPEG_sha256=hashlib.sha256(rawA).hexdigest(),raw_bytes_equal=rawA==rawB,CTM_equal=bool(ctmEqual)));assert rawA==rawB and ctmEqual
for pc in plan['protected_current_curves']:
 P0=Eb.page(7);P1=E.page(7);entries=[]
 for obj in pc['objects']:
  oi=obj['object_index'];o0=P0.objs[oi];o1=P1.objs[oi];same=P0.object_pagepath(oi)==P1.object_pagepath(oi) and o0['stroke']==o1['stroke'] and o0['lw']==o1['lw'] and o0['dash']==o1['dash'] and np.array_equal(o0['ctm'],o1['ctm']);assert same;entries.append(dict(object_index=oi,path_color_width_dash_CTM_exact=True))
 protectedchecks.append(dict(model=pc['model'],objects=entries,scope='Protect exact already accepted vector objects, no new QH audit'))
def normalizedXML(text):
 return ET.canonicalize(text,strip_text=True,rewrite_prefixes=True) if text.strip() else ''
with fitz.open(current) as a,fitz.open(trial) as b:
 links=lambda d:[[{k:str(v) for k,v in z.items() if k!='xref'} for z in p.get_links()] for p in d]
 fonts=lambda d:[[tuple(f[1:]) for f in p.get_fonts(full=True)] for p in d]
 metadata=dict(page_count=len(a)==len(b)==11,Info=a.metadata==b.metadata,XMP_values_equal=normalizedXML(a.get_xml_metadata())==normalizedXML(b.get_xml_metadata()),bookmarks=a.get_toc()==b.get_toc(),links=links(a)==links(b),sizes=[tuple(p.rect) for p in a]==[tuple(p.rect) for p in b],fonts=fonts(a)==fonts(b));assert all(metadata.values())
sourcebands=[]
for fam in ['3SS3','3SS4','4SA16']:
 g=next(z for z in audit['graphs'] if z['family']==fam);pi=g['page']-1;cv=Rb.canvas(max(Rb.images(pi),key=lambda z:z.W*z.H));left=g['axis']['frame_native']['left'];top=g['axis']['frame_native']['top'];bottom=g['axis']['frame_native']['bottom'];first=min(r['numeric_nodes'][0]['u'] for r in build['records'] if r['page']==pi+1)
 for label,box in [('DASH AND CAPTIONS',(left-20,top-25,first-1,bottom+8)),('AXIS H',(left-65,top-20,left+8,bottom+12))]:
  rect=cv.rect(box);aa=np.asarray(verify.crop(current,pi,rect,600));bb=np.asarray(verify.crop(trial,pi,rect,600));n=int(np.any(aa!=bb,axis=2).sum());assert n==0;sourcebands.append(dict(family=fam,band=label,changed_pixels_600dpi=n))
assert sha(src)==build['source_sha256'] and sha(current)==build['current_sha256'];out=dict(trial=trial,trial_sha256=sha(trial),numeric_true_path_points=numeric,visible_numeric_ink_points=pixels,styles=styles,equivalent_style_measurement_on_PDF600dpi=equivalent,old_ink_residual_checks=ghosts,original_raw_images=images,protected_accepted_curves=protectedchecks,source_head_dash_text_and_axis_pixel_checks=sourcebands,metadata=metadata,outside_200dpi_threshold0=build['outside_200dpi_threshold0'],canonical_written=False,progress_written=False,accepted=False,visual_acceptance_pending_ROOT=True,whole_curve_acceptance_claimed=False)
Path(fresh(folder/'DOC LAI PDF THAT MAU1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda z:z.tolist() if isinstance(z,np.ndarray) else str(z)),encoding='utf8');E.close();Eb.close();print('ACTUAL CHECK DONE; ROOT PENDING; metadata',metadata,'images',len(images),'numeric nodes',len(numeric),'visible',len(pixels),'residual flags',sum(len(g['dark_residual_candidates']) for g in ghosts),flush=True)
