"""Display all13 labels and preserved curves for source5/9 RAM candidates; no PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,sys,hashlib,numpy as np
import pymupdf as fitz
from PIL import Image,ImageDraw
sys.path.insert(0,str(HERE))
from g04_redpump_ram_builder import build_three_fix_RAM
from g04_source_glyph_source_edge_math import sample_path
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/(sys.argv[1] if len(sys.argv)>1 else 'CHU5 9 BIEN NGUON LIEN RAM V6B')
geometry_name=sys.argv[2] if len(sys.argv)>2 else '12 GLYPH RAM V6 CHI THAY BIEN5 9 MOT MAU.json'
variant=sys.argv[3] if len(sys.argv)>3 else 'V6B'
diagnostic_only='--diagnostic' in sys.argv
folder=F/('RENDER CHAN DOAN RAM DOC RO' if '--fresh-caption' in sys.argv else 'RENDER ACTUAL RAM');assert not folder.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json');a=J(M/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')
atlas=J(P/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json');layout=J(P/'13 HOP NHAN CUC BO TRANH DUONG LUOI V1.json')
v=J(F/geometry_name)
holes=J(M/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json');eta=J(M/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
E,placed,expected,qh=build_three_fix_RAM(b,a,atlas,layout,v,holes,eta);PR=E.page(7)
tag=next(i for i,z in enumerate(PR.ops) if z.op=='BMC' and list(map(str,z.operands))==['CfxRedpumpSmallSourceGlyphSingleCoreRAM2'])
objects=[(i,o) for i,o in enumerate(PR.objs) if o['i0']>tag and o['op']=='f*'];assert len(objects)==len(expected)
actual=[];cliptests=[]
boxes={r['model']:r['physical_box'] for r in placed}
for (oi,o),ex in zip(objects,expected):
    path=PR.object_pagepath(oi)
    assert [z[0] for z in path]==[z[0] for z in ex['path']]
    av=np.array([q for _,p in path for xy in p for q in xy])
    ev=np.array([q for _,p in ex['path'] for xy in p for q in xy])
    assert np.max(abs(av-ev))<2e-7
    pts=sample_path(path,64);bb=boxes[ex['model']]
    outside=(pts[:,0]<bb[0]-1e-6)|(pts[:,0]>bb[2]+1e-6)|(pts[:,1]<bb[1]-1e-6)|(pts[:,1]>bb[3]+1e-6)
    # Newly surveyed5/9 must not be accidentally cropped by old word boxes.
    if ex['character'] in '259' and not diagnostic_only:assert not outside.any(),(ex['model'],ex['character'],pts[outside])
    actual.append(dict(ex,actual_RAM_path=path,actual_geometry_error_pt=float(np.max(abs(av-ev))),actual_RAM_object=oi,source_donor=next(r['source_word'] for r in v['records'] if r['character']==ex['character']),
        no_actual_5_9_path_clip=not outside.any() if ex['character'] in '59' else None,
        diagnostic_clip_sample_count=int(outside.sum()),actual_clip_status='CHƯA ĐẠT: glyph vượt hộp thật' if outside.any() else 'Không clip điểm đã lấy mẫu'))

def render(rect,dpi):
    pg=E.doc.doc[7];T=pg.transformation_matrix;u=fitz.Point(rect[0],rect[1])*T;w=fitz.Point(rect[2],rect[3])*T
    clip=fitz.Rect(min(u.x,w.x),min(u.y,w.y),max(u.x,w.x),max(u.y,w.y))
    px=pg.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=clip,colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(px.samples,dtype=np.uint8).reshape(px.height,px.width,px.n)[:,:,:3].copy()

VM={r['character']:r for r in v['records']};metrics=[];images=[]
for dpi in [150,600,2400]:
    if dpi<2400:
        fp=fresh(folder/f'TOAN3LOI RAM {variant} {dpi}dpi KHONG PDF2.png');Image.fromarray(render([53,267,364,511],dpi)).save(fp);images.append(fp)
        rowh=180 if dpi==600 else 90
        sheet=Image.new('RGB',(2200,13*rowh+80),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(16)
    for k,r in enumerate(placed):
        bb=r['physical_box'];rect=[bb[0]-.24,bb[1]-.24,bb[2]+.24,bb[3]+.24]
        old=np.asarray(verify.crop(b['sample'],7,rect,dpi));new=render(rect,dpi);assert old.shape==new.shape
        oa=(255-old.astype(float).mean(2))/255;na=(255-new.astype(float).mean(2))/255
        metrics.append(dict(model=r['model'],dpi=dpi,rect=rect,old_RGB=old.tolist() if dpi==600 else None,
            new_RGB=new.tolist() if dpi==600 else None,source_area_pt2=float(oa.sum()*(72/dpi)**2),
            new_area_pt2=float(na.sum()*(72/dpi)**2),relative_optical_delta=float(na.sum()/oa.sum()-1),
            shape_acceptance='CHƯA CHỐT: chỉ RAM, mực không phải điều kiện duy nhất.'))
        if dpi<2400:
            y=70+k*rowh;p0=Image.fromarray(old);p1=Image.fromarray(new)
            sheet.paste(p0,(210,y));sheet.paste(p1,(480,y));dr.text((5,y),r['model'],fill='blue',font=ft)
            if dpi==600:
                sheet.paste(p0.resize((p0.width*3,p0.height*3),Image.Resampling.NEAREST),(770,y))
                sheet.paste(p1.resize((p1.width*3,p1.height*3),Image.Resampling.NEAREST),(1490,y))
    if dpi<2400:
        five=VM['5'];two=VM['2']
        label=(f'RAM {variant} - 5: {five["source_word"]} p{five["source_page"]}; 2: {two["source_word"]} p{two["source_page"]}; 9 giữ V7 - KHÔNG PDF2')
        if diagnostic_only:label+=' - CHẨN ĐOÁN: CÓ LỖI CLIP, CHƯA ĐẠT'
        else:label+=' - chưa chốt phông/hình thức'
        dr.text((5,3),label,fill='blue',font=ft)
        fp=fresh(folder/f'13 NHAN TRUOC SAU RAM {variant} {dpi}dpi KHONG PDF2.png');sheet.save(fp);images.append(fp)

out=dict(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],
    M1=b['sample'],M1_SHA256=guards[2],RAM_geometry_data=str(F/geometry_name),
    actual_font_paths=actual,actual_RAM_font_paint_objects=len(actual),label_layout_and_advances_unchanged=True,
    common_fill_gray=63,opacity=1,actual_RAM_metrics=metrics,images=images,
    QH_all26paths_fingerprint_unchanged=qh,QH_104_not_remeasured=True,
    eta_2C2_Bezier_recipe_retained=True,eta_numeric='CHƯA THỂ: không có bảng số η',feet_5holes_recipe_retained=True,
    limitations='Biên contour từ JPEG chưa phải font gốc chắc chắn; 5/9 và toàn13nhãn vẫn cần nghiệm thu dáng/đậm độc lập. Không gọi mực/lỗ/đọc mã là phôngPASS.',
    diagnostic_only=diagnostic_only,diagnostic_clipping_issues=[dict(model=z['model'],character=z['character'],outside_samples=z['diagnostic_clip_sample_count']) for z in actual if z['diagnostic_clip_sample_count']],
    diagnostic_acceptance='CHƯA ĐẠT nếu có glyph clip; chỉ giữ bằng chứng, không cho tạo PDF2' if diagnostic_only else 'ỨNG VIÊN RAM chưa chốt hình thức',
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False)
fp=fresh(folder/f'DOC ACTUAL RAM {variant} 13 NHAN VA3LOI KHONG PDF.json')
Path(fp).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print('RAM only fontobjects',len(actual),'QH26 unchanged',
      ('DIAGNOSTIC ONLY; clip issues '+str(out['diagnostic_clipping_issues'])) if diagnostic_only else '2/5/9 not clipped',flush=True)
print(fp,flush=True)
