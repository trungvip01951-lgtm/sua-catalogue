"""ROOT approved plan: sample1 only, /25 tail, guard source/current, no canonical write."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g15_masked_patch import commit_masked
from pathlib import Path
import json,hashlib,numpy as np
from catfix.recipes import Job
from catfix.charts import Chart
from catfix.cs import Instr,Num
from catfix import verify
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads(Path(S.report('G04/REDPUMP 25 PHUONG AN SUA DUOI/PHUONG AN RIENG SUA DUOI 25.json')).read_text(encoding='utf8'))
trace=json.loads(Path(plan['source_curve_evidence']).read_text(encoding='utf8'));cur=plan['current'];src=plan['source'];before=[sha(src),sha(cur)];assert before==[plan['source_SHA256'],plan['current_SHA256']]
lan=2 if '--lan2' in sys.argv else 1
folder=Path(S.report(f'G04/REDPUMP 25 MAU SUA DUOI{lan}'));dst=fresh(folder/Path(cur).name);j=Job(cur,dst,backend='fitz',log_path=fresh(folder/'NHAT KY.json'));im=max(j.R.images(7),key=lambda z:z.W*z.H);cv=j.R.canvas(im);a=cv.orig.copy();f=a.astype(float);g=f@np.array([.299,.587,.114]);C=Chart(*trace['axis']);obs=np.array([[p['u'],p['v']] for p in trace['raw_observed_trace']]);pg=np.array([cv.to_page(u,v) for u,v in obs]);q=(pg[:,0]-C.bx)/C.ax
joinx=C.to_page(18,75)[0];endx=C.to_page(21,54)[0];uclip=int(np.ceil(cv.to_px(joinx,0)[0]));clipx=cv.to_page(uclip,0)[0];uend=int(obs[-1,0])+3;us=np.arange(uclip,uend+1)
centers=np.interp(us,obs[:,0],obs[:,1]);last_slope=float(np.polyfit(obs[-15:,0],obs[-15:,1],1)[0]);centers[us>obs[-1,0]]=obs[-1,1]+last_slope*(us[us>obs[-1,0]]-obs[-1,0])
tube=np.zeros(g.shape,bool)
for u,v in zip(us,centers):tube[max(0,int(round(v))-4):min(len(g),int(round(v))+5),u]=True
weak=(f[:,:,1]-f[:,:,0]>2)&(f[:,:,2]-f[:,:,0]>3);mask=tube&(weak|(g<205));assert not mask[:,:uclip].any()
plot=(57.5,320,326.5,509);u,v,ur,vr=cv.box(plot);z=f[v:vr,u:ur];row=np.median(z,axis=1);col=np.median(z,axis=0);bg=a.copy();bg[v:vr,u:ur]=np.minimum(row[:,None,:],col[None,:,:]).round().clip(0,255).astype(np.uint8)
cv.work[mask]=bg[mask]
changed=np.any(cv.work!=cv.orig,axis=2);assert not changed[:,:uclip].any()
ys,xs=np.nonzero(changed);change_bbox=[*cv.to_page(xs.min(),ys.max()+1),*cv.to_page(xs.max()+1,ys.min())];allowed=plan['allowed_cleanup_bbox'];assert allowed[0]<=change_bbox[0] and allowed[1]<=change_bbox[1] and allowed[2]>=change_bbox[2] and allowed[3]>=change_bbox[3],(allowed,change_bbox)
# Clip only the new stroke. Native-cell boundary is at/afterQ18, so source ink
# and every pixel prefix remain unpainted by this tail. Endpoint clip is exactQ21.
X=np.linalg.inv(im.ctm);rgb=np.array(plan['RGB_measured_own_tail'])/255;width=plan['equivalent_width_pt_measured_own_tail'];xy=plan['proposed_bezier_page']
ins=[Instr([],'q'),Instr([Num(X[0,0]),Num(X[0,1]),Num(X[1,0]),Num(X[1,1]),Num(X[2,0]),Num(X[2,1])],'cm'),Instr([Num(clipx),Num(allowed[1]),Num(endx-clipx),Num(allowed[3]-allowed[1])],'re'),Instr([],'W'),Instr([],'n'),Instr([Num(0)],'J'),Instr([Num(1)],'j'),Instr([[],Num(0)],'d'),Instr([Num(float(c)) for c in rgb],'RG'),Instr([Num(width)],'w'),Instr([Num(z) for z in xy[0]],'m'),Instr([Num(z) for p in xy[1:] for z in p],'c'),Instr([],'S'),Instr([],'Q')]
if lan==1:j.E.insert_instrs(im.key,im.index,ins,before=False)
cv.after=im;cv.pi=7;patches=commit_masked(j);j.R.canvases.clear();j._canvases.clear()
if lan==2:
 P=j.E.page(7);X=np.linalg.inv(P.ctm_at(len(P.ops)));ins[1]=Instr([Num(X[0,0]),Num(X[0,1]),Num(X[1,0]),Num(X[1,1]),Num(X[2,0]),Num(X[2,1])],'cm')
 j.E.insert_instrs(7,len(P.ops)-1,ins,before=False)
j._add(7,allowed,'4SL16/25: chỉ sửa đuôi nốiQ18/H75, chốtQ21/H54; giữ /23,/18 và miền trướcQ18','observed-source-tail25-mask+true-PDF-cubic')
j.save();check=j.check(raster=True);assert check['ok'],check
outside=verify.outside_pixels(cur,dst,{8:[allowed]},dpi=200,thr=0,min_size=0,pad=.4);assert not outside,outside
verify.compare_sheet(cur,dst,[(7,allowed,f'Redpump25: đuôi thật trước | mẫu{lan}')],fresh(folder/'DUOI TRUOC SAU 600dpi.png'),dpi=600,pad=(.3,.3))
verify.compare_sheet(cur,dst,[(7,(57.5,320,356,509),f'Redpump25: toàn bộ biểu đồ trước | mẫu{lan}')],fresh(folder/'TOAN BIEU DO TRUOC SAU 150dpi.png'),dpi=150,pad=(.3,.3))
for dpi in [150,600]:
 verify.crop(dst,7,allowed,dpi).save(fresh(folder/f'DUOI MAU{lan} {dpi}dpi.png'))
verify.crop(dst,7,(0,0,841.9,598.8),150).save(fresh(folder/f'TOAN TRANG8 MAU{lan}.png'))
out=dict(plan_source_sha=plan['source_SHA256'],source=src,source_sha=sha(src),current=cur,current_sha=sha(cur),sample=dst,sample_sha=sha(dst),axis=trace['axis'],RGB=plan['RGB_measured_own_tail'],width_pt=width,width_inferred_from_compressed_source=True,source_label_provenance=plan['source_label'],allowed_bbox=allowed,changed_native_bbox=change_bbox,changed_native_pixels=int(changed.sum()),cleanup_mask_pixels=int(mask.sum()),native_clip_column=uclip,clip_start_page_x=clipx,clip_start_Q=(clipx-C.bx)/C.ax,clip_endpoint_page_x=endx,clip_endpoint_Q=21.,actual_planned_path_QH=plan['proposed_bezier_QH'],actual_planned_path_page=xy,source_observed_old_endpoint=plan['source_observed_endpoint'],patches=patches,check=check,outside_200dpi_threshold0=outside,canonical_written=False,source_and_canonical_SHA_unchanged=before==[sha(src),sha(cur)],accepted=False,status='MẪU1: cần đọc path/ảnh/metadata/prefix và ROOT nghiệm thu trước chốt')
out['sample_number']=lan;out['stroke_after_all_old_masks']=lan==2
out['previous_sample']='Mẫu1 CHƯA ĐẠT hình thức: mask/23 có sẵn che nét/25 vì thứ tự lớp. Giữ mẫu1 làm lịch sử.' if lan==2 else None
Path(fresh(folder/f'TAO VA KIEM MAU{lan}.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print('TAIL25 SAMPLE',lan,check['ok'],outside,'clip startsQ',out['clip_start_Q'],'nativepixels',out['changed_native_pixels'],'SHA',out['sample_sha'],flush=True);j.close()
