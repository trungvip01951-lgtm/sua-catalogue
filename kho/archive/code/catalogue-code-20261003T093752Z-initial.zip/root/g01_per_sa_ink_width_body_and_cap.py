from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,math,collections,io
from scipy.signal import find_peaks
import pymupdf as fitz

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=S.src('Perotac bơm giếng SA_compressed (bản mới).pdf');dst=S.result('Perotac bơm giếng SA_compressed (bản mới).pdf')
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd';assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));d=json.loads((O/'g01_UNG VIEN11 MOC - DO NHAY RAW VA PDF600 THUC RIENG.json').read_text(encoding='utf8'));tr=json.loads((O/'g01_DO TIEU DIEN XAM VA VACH DIA PHUONG - CHO SOI ANH.json').read_text(encoding='utf8'));trace={c['model']:c.get('observed_trace',[]) for g in tr['graphs'] for c in g['curves']};doc=fitz.open(src);out=[]
for p in d['points']:
 page=doc[p['page']-1];im=max(page.get_images(full=True),key=lambda z:z[2]*z[3]);rgb=np.asarray(Image.open(io.BytesIO(doc.extract_image(im[0])['image'])).convert('RGB'));gray=rgb.astype(float)@np.array([.299,.587,.114]);t=trace[p['model']];uu=np.array([z['u'] for z in t]);vv=np.array([z['v'] for z in t]);target=p['Q_source_native_u'];observations=[]
 for dx in [-4.,-3.,-2.,-1.,0.]:
  x=target+dx
  if x<uu[0] or x>uu[-1]+.8:continue
  pv=float(np.interp(x,uu,vv));ys=np.arange(int(math.floor(pv))-6,int(math.ceil(pv))+7);ix=int(math.floor(x));f=x-ix;signal=255-((1-f)*gray[ys,ix]+f*gray[ys,ix+1]);ids,_=find_peaks(signal,height=28,prominence=18,distance=2);ids=[k for k in ids if abs(ys[k]-pv)<2.8];runs=[]
  for k in ids:
   floor=float(min(signal[max(0,k-4):k+1].min(),signal[k:min(len(ys),k+5)].min()));cut=floor+.5*(signal[k]-floor);lo=k;hi=k
   while lo>0 and signal[lo-1]>=cut:lo-=1
   while hi+1<len(ys) and signal[hi+1]>=cut:hi+=1
   runs.append({'width_FWHM_native_px':int(hi-lo+1),'rows':[int(ys[lo]),int(ys[hi])],'source_peak_darkness':float(signal[k])})
  observations.append({'u_native':x,'dx_before_target_native_px':dx,'predicted_source_v':pv,'number_of_plausible_runs':len(runs),'runs':runs,'from_original_JPEG':True})
 widths=[r['width_FWHM_native_px'] for a in observations if a['number_of_plausible_runs']==1 for r in a['runs']];maxwidth=max([p['source_FWHM_width_native_px']]+widths);extra=.5*max(0,maxwidth-p['source_FWHM_width_native_px'])*p['local_H_m_per_pixel'];unc=p['revised_conservative_bound_m']+extra;delta=p['delta_H_m'];tol=p['tolerance_H_m'];stat=('CHƯA ĐẠT' if abs(delta)-unc>tol else ('ĐẠT' if abs(delta)+unc<=tol else 'CHƯA THỂ XÁC MINH'))
 pt={**p,'body_before_cap_FWHM_observations':observations,'max_actual_source_FWHM_in_body_and_cap_native_px':maxwidth,'extra_body_width_uncertainty_m':extra,'final_source_conservative_uncertainty_m':unc,'final_H_uncertainty_range_m':[p['H_curve_measured_m']-unc,p['H_curve_measured_m']+unc],'strict_scalar_result_before_manual_identity':stat,'why_cap_was_checked':'Không lấy đoạn mực đầu-cuối bị cắt làm bút mảnh hơn thân; chọn bề dày thật lớn nhất của đúng nét ở4px phía trong và tại Q. Không xử lý pixel.'};out.append(pt);print('WIDTH',p['model'],p['Q_m3_h'],'FWHM TARGET/BODY',p['source_FWHM_width_native_px'],maxwidth,'UNC',round(unc,5),'STRICT',stat,flush=True)
fp=Path(fresh(O/'g01_BIEN NGUON THAN NET VA DAU CUOI11 MOC - KHONG EP BUT MANH.json'));fp.write_text(json.dumps({'source':src,'source_sha256':sha(src),'current_sha256':sha(dst),'read_only':True,'no_PDF_or_source_pixel_written':True,'points':out},ensure_ascii=False,indent=2,default=lambda z:z.item() if isinstance(z,np.generic) else z.tolist()),encoding='utf8');doc.close();print('FILE',str(fp),'SHA',sha(fp))
