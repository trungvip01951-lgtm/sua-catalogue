"""Phuong phap moi G04: net PDF that tren nen tach mau, khong ve raster/doi anh.
Chi tao mau trong bao cao; giu file giao va file nguon nguyen.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g15_masked_patch import commit_masked
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import binary_dilation,binary_closing,binary_opening
from scipy.interpolate import PchipInterpolator
from catfix.recipes import Job
from catfix.charts import Chart,sample_path
from catfix.cs import Instr,Num
from catfix import verify
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
second='--lan2' in sys.argv
folder=Path(S.report('G04/NET PDF THAT MAU2' if second else 'G04/NET PDF THAT MAU1'))
dst=fresh(folder/name);current=S.result(name);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
j=Job(current,dst,backend='fitz',log_path=fresh(folder/'NHAT KY.json'))
image=j.R.images(7)[0];cv=j.R.canvas(image);ar=cv.orig.copy();g=ar.astype(float)@np.array([.299,.587,.114]);H,W=g.shape
Q=np.array([0,3,6,9,12,15,18,21],float)
series=[('4SA16/23',np.array([136,133,127,115,101,86,69,50],float)),('4SA16/18',np.array([107,104,99,90,79,67,54,39],float))]
ticks=[(100,134.875),(150,172.07),(200,209.15),(250,246.47),(300,283.79)]
cx=np.polyfit([v[0] for v in ticks],[v[1] for v in ticks],1);axisres=max(abs(np.polyval(cx,q)-x) for q,x in ticks);assert axisres<.2
y0=cv.to_page(125,571.5)[1];y150=cv.to_page(125,180.5)[1]
C=Chart(float(cx[0]*1000/60),float(cx[1]),float((y150-y0)/150),float(y0))
u0=int(round(cv.to_px(*C.to_page(0,0))[0]));ue=int(round(cv.to_px(*C.to_page(21.6,0))[0]));us=np.arange(u0,ue+1)
qq=np.array([(cv.to_page(int(u),0)[0]-C.bx)/C.ax for u in us])
a=ar.astype(int);coloured=(a[:,:,1]-a[:,:,0]>8)&(a[:,:,2]-a[:,:,0]>10)&(a[:,:,0]<235)
weak=(a[:,:,1]-a[:,:,0]>2)&(a[:,:,2]-a[:,:,0]>3)
black=(g<140)&((a.max(2)-a.min(2))<10);protect=binary_dilation(black,iterations=2)
allmask=np.zeros((H,W),bool);items=[]
for model,heads in series:
    guide=np.polyval(np.polyfit(Q,heads,3),qq)+2
    vp=np.array([cv.to_px(*C.to_page(float(q),float(h)))[1] for q,h in zip(qq,guide)])
    raw=[]
    for u,v in zip(us,vp):
        rows=np.arange(max(0,int(v)-9),min(H,int(v)+10));good=rows[coloured[rows,u]&~protect[rows,u]]
        if not len(good):raw.append(np.nan);continue
        groups=np.split(good,np.where(np.diff(good)>1)[0]+1)
        centers=[float(np.average(z,weights=255-g[z,u])) for z in groups]
        raw.append(min(centers,key=lambda z:abs(z-v)))
    raw=np.array(raw);ok=np.isfinite(raw);assert ok.sum()>.6*len(us)
    keep=ok.copy()
    for _ in range(4):
        fit=np.polyval(np.polyfit(qq[keep],raw[keep],4),qq);keep=ok&(abs(raw-fit)<1.5)
    tube=np.zeros((H,W),bool)
    for u,v in zip(us,fit):tube[max(0,int(round(v))-4):min(H,int(round(v))+5),u]=True
    mask=tube&weak&~protect;allmask|=mask
    # Estimate ink from actual most chromatic native samples, excluding black text/grid.
    eligible=tube&coloured&~protect
    xgrid=np.zeros(W,bool)
    for u,q in zip(us,qq):
        if 8<q<17:xgrid[u]=True
    pix=ar[eligible&xgrid[None,:]].astype(float);chroma=(pix[:,1]+pix[:,2])/2-pix[:,0]
    ink=np.median(pix[chroma>=np.percentile(chroma,90)],axis=0)
    # One native150dpi full-width ink pixel; same .48pt apparent source family.
    width=float(abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]))
    if second:
        # Trial1 rendered visibly paler/thinner than source. Trial2 fits actual
        # darkest core RGB and perpendicular colour-ink area in native columns.
        lum=pix@np.array([.299,.587,.114]);ink=np.median(pix[lum<=np.percentile(lum,20)],axis=0)
        alpha=np.clip((255-ar.astype(float))@(255-ink)/np.sum((255-ink)**2),0,1)
        native_widths=[]
        for idx,(uu,q) in enumerate(zip(us,qq)):
            if not 8<q<17:continue
            vv=int(round(fit[idx]));rows=np.arange(max(0,vv-4),min(H,vv+5));slope=float(np.gradient(fit)[idx])
            native_widths.append(float((alpha[rows,uu]*coloured[rows,uu]).sum()/np.sqrt(1+slope*slope)))
        width=float(np.median(native_widths))*abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0])
        assert .4<width<1.5,(model,width)
    on=np.array([bool(mask[:,u].any()) for u in us]);on=binary_opening(binary_closing(on,structure=np.ones(3)),structure=np.ones(3))
    on[0]=True
    items.append(dict(model=model,heads=heads,mask=mask,ink=ink,width=width,presence=on,trace_median=float(np.median(abs(raw[keep]-fit[keep])))))
u,v,ur,vr=cv.box((59.5,324,359,513));patch=ar[v:vr,u:ur].astype(float);row=np.median(patch,axis=1);col=np.median(patch,axis=0);bg=ar.copy();bg[v:vr,u:ur]=np.minimum(row[:,None,:],col[None,:,:]).round().clip(0,255).astype(np.uint8)
cv.work[allmask]=bg[allmask]
assert np.array_equal(cv.work[protect],ar[protect])
X=np.linalg.inv(image.ctm);ins=[Instr([],'q'),Instr([Num(X[0,0]),Num(X[0,1]),Num(X[1,0]),Num(X[1,1]),Num(X[2,0]),Num(X[2,1])],'cm'),Instr([Num(0)],'J'),Instr([Num(1)],'j'),Instr([[],Num(0)],'d')]
records=[]
for it in items:
    qend=6.;segments=[];on=it['presence'];run=None
    # Keep native dash runs up toQ6 at their own source x intervals.
    for idx,(q,present) in enumerate(zip(qq,on)):
        if q>qend:break
        if present and run is None:run=0. if idx==0 else max(0.,float(q))
        if not present and run is not None:
            end=min(qend,float(qq[idx-1]));
            if end>run:segments.append((run,end))
            run=None
    if run is not None:segments.append((run,qend))
    segments.append((6.,21.))
    f=PchipInterpolator(Q,it['heads']);ins.extend([Instr([Num(float(z/255)) for z in it['ink']],'RG'),Instr([Num(it['width'])],'w')])
    for lo,hi in segments:
        qs=np.unique(np.r_[lo,Q[(Q>lo)&(Q<hi)],hi]);path=C.smooth_path([(float(q),float(f(q))) for q in qs],method='pchip')
        for op,pts in path:ins.append(Instr([Num(float(z)) for p in pts for z in p],op))
        ins.append(Instr([],'S'))
    records.append(dict(model=it['model'],Q=Q.tolist(),H=it['heads'].tolist(),RGB=it['ink'].tolist(),width_pt=it['width'],native_dash_Q_intervals=segments,source_trace_median_error_px=it['trace_median']))
ins.append(Instr([],'Q'))
j.E.insert_instrs(image.key,image.index,ins,before=False)
# ImageCanvas supplies the same exact page-to-pixel map; the helper needs its anchor.
cv.after=image;cv.pi=7
masked=commit_masked(j);j.R.canvases.clear();j._canvases.clear()
j._add(7,(59.5,324,359,513),'4SA16/23 và4SA16/18: 16mốc bảng, đườngPDF thật; giữảnh/chữ/nét lân cận','source-ink-background+true-PDF-path')
j.save();check=j.check(raster=True)
outside=verify.outside_pixels(current,dst,{8:[[59.5,324,359,513]]},dpi=200,thr=0,min_size=0,pad=.4)
print('G04 NEW PDF',check['ok'],outside,'RGB/lw',[(x['RGB'],x['width_pt']) for x in records],flush=True)
verify.compare_sheet(current,dst,[(7,(59.5,324,359,513),'NET PDF THAT '+('MAU2' if second else 'MAU1'))],fresh(folder/'TRUOC SAU.png'),dpi=450,pad=(.2,.2))
verify.crop(dst,7,(59.5,324,359,513),600).save(fresh(folder/'ANH NET PDF THAT.png'))
Path(fresh(folder/'TAO VA KIEM MAU.json')).write_text(json.dumps(dict(current_sha=sha(current),source_sha=sha(S.src(name)),trial=dst,trial_sha=sha(dst),check=check,outside=outside,records=records,source_ticks=ticks,axis=[C.ax,C.bx,C.ay,C.by],top_v=180.5,bottom_v=571.5,masked_patches=masked,black_native_pixels_exact=True,method='TruePDF path over lossless SMask erasure; trial'+str(2 if second else 1)+'. Previous raster/texturemethods each stoppedafter2.',accepted=False),ensure_ascii=False,indent=2),encoding='utf8')
j.close()
