"""Kiem doc lap profile muc nguon so voi pixel native JPEG thuc."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np,hashlib
from catfix.vector import Editor
from catfix.raster import Raster
source=S.src('Perotac bơm giếng SP_compressed (bản mới).pdf');E=Editor(source,backend='fitz');R=Raster(E);im=max(R.images(10),key=lambda x:x.W*x.H);cv=R.canvas(im);a=cv.orig
folder=Path(S.report('G05/10SP135 HAI MOC CUOI/DO MUC NGUON'));data=json.loads((folder/'DIEN TICH MUC VUONG GOC.json').read_text(encoding='utf8'));out=[]
for c in data['curves']:
 exact=0;mass=[];core=np.array(c['color_RGB'],float);contrast=255-core
 for z in c['samples']:
  x=int(z['native_x']);y=int(np.floor(z['native_y']));profile=np.array(z['source_profile_RGB']);hh=len(profile);matches=[]
  for yy in range(y-3,y+4):
   block=a[yy-hh//2:yy-hh//2+hh,x]
   if np.array_equal(block,profile):matches.append(yy)
  assert matches,(c['model'],x,y);exact+=1
  # Independent channelwise estimate, then median across RGB channels;
  # source JPEG ringing is clipped to physical opacity 0..1.
  alpha=np.clip(np.median((255-profile)/contrast,axis=1),0,1)
  width=float(alpha.sum()*c['source_native_pixel_pt']/np.sqrt(1+z['native_slope']**2));mass.append(width)
 med=float(np.median(mass));delta=med-c['new_width_from_source_opacity_area_pt'];print(c['model'],'ROOT width',med,'plan',c['new_width_from_source_opacity_area_pt'],'delta',delta,flush=True)
 out.append(dict(model=c['model'],source_profiles_exact_to_original_pixels=exact,root_independent_equivalent_width_median_pt=med,planned_width_pt=c['new_width_from_source_opacity_area_pt'],difference_pt=delta,method='Median of channelwise alpha from actualsource RGB, actual normal slope; no figure invented.'))
E.close()
Path(fresh(folder/'ROOT DOC LAI MUC NGUON RAW.json')).write_text(json.dumps(dict(source=source,source_sha=hashlib.sha256(Path(source).read_bytes()).hexdigest(),results=out),ensure_ascii=False,indent=2),encoding='utf8')
print('ROOT native source profiles independently read',out,flush=True)
