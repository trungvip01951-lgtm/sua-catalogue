"""Source glyph proof: same page8 genuine letters, no PDF/design sample or new font."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
words=json.loads((root/'CHU NGUON ALPHA THU DO DOC V2.json').read_text(encoding='utf8'))
source=plan['method']['source'];current=plan['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(source),sha(current)]
assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(source,backend='fitz');R=Raster(E);cv=R.render_canvas(7,words['source_rect'],dpi=600);a=cv.orig.astype(float);byname={p['model']:p for p in words['records']}
donors={'4':('4SL16/23',18,45),'S':('4SL16/20',44,76),'L':('4SL16/23',76,104),'1':('4SL16/20',102,121),'6':('4SL16/16',120,147),'/':('4SL16/12',145,160),'2':('4SL16/20',156,180),'5':('4SL16/25',176,204),'0':('4SL16/20',180,205),'3':('4SL16/23',180,205),'8':('4SL16/18',180,205),'9':('4SL16/9',156,184)}
records=[];pic=Image.new('RGB',(920,len(donors)*112),'white');dr=ImageDraw.Draw(pic)
for i,(ch,(word,x0,x1)) in enumerate(donors.items()):
 z=byname[word];_,y0,_,y1=z['source_render_rect'];p=a[y0:y1,x0:x1];g=p@np.array([.299,.587,.114]);spread=p.max(2)-p.min(2)
 core=(g<105)&(spread<30);candidate=((g<224)&(spread<10))|core
 connected,n=label(candidate);keep=np.zeros_like(candidate)
 for k in range(1,n+1):
  component=connected==k
  if (component&core).any():keep|=component
 alpha=(1-g/255)*keep
 assert core.any() and alpha.any(),ch
 ys,xs=np.nonzero(alpha>.02);box=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]
 trim=alpha[box[1]:box[3],box[0]:box[2]]
 bw=Image.fromarray((255*(1-trim)).round().clip(0,255).astype('uint8')).convert('RGB')
 raw=Image.fromarray(p.round().astype('uint8'))
 dr.text((5,i*112+8),f'{ch} from {word}',fill='blue');pic.paste(raw.resize((raw.width*2,raw.height*2),Image.Resampling.NEAREST),(170,i*112+12));pic.paste(bw.resize((bw.width*2,bw.height*2),Image.Resampling.NEAREST),(430,i*112+12))
 dr.text((650,i*112+20),f'{trim.shape[1]}x{trim.shape[0]} px at600dpi',fill=(0,0,180))
 x=box[0]+x0;y=box[1]+y0;pg=[*cv.to_page(x,box[3]+y0),*cv.to_page(box[2]+x0,y)]
 records.append(dict(character=ch,source_page=8,source_word=word,source_render_glyph_box=[x,y,box[2]+x0,box[3]+y0],source_page_glyph_box=pg,alpha_shape=list(trim.shape),source_alpha=trim.tolist(),black_core_pixels=int(core.sum()),new_font_used=False,source_font_kind='Nét chữ ảnh thực trong CHÍNH trang8 Redpump',status='ỨNG VIÊN GLYPH: phải soi đầy đủ nét/hole/không mảnh đường trước dùng.'))
photo=fresh(root/'GLYPH THAT CUNG TRANG8 NGUON VA MUC TACH.png');pic.save(photo)
out=dict(source=source,source_SHA256=before[0],current_SHA256=before[1],source_rect=list(cv.rect0),dpi=600,records=records,proof_photo=photo,exact_alpha_source_rule='Giữ luminance mực thật trên các component neutral nối tới core đen; không vẽ thêm chữ, không dùngfont ngoài, chưachuẩnhóa haytrơncontour.',source_glyph_bank_candidate_only=True,PDF_sample_written=False,contour_conversion_tested=False,full_source_word_alpha_rejected=['4SL16/11: mực cũ chồng, mất hai số1 và có mảnh đường'],planned_fullword_reconstruction='Chọn các glyph sạch cùng trang/cùng cỡ, ghépđủ13mã theo khoảng chữ nguồn; lỗ0/6/8/9 và dấu/ phải kiểm riêng. Nếu glyph3 hoặc mẫu khác nhiễm mực thì lấy đúngglyph cùngkiểu ởCHÍNHfile vàchứngminh hìnhnét; không tựtạophầnthiếu.')
Path(fresh(root/'GLYPH THAT CUNG TRANG8 NGAN HANG UNG VIEN.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(source),sha(current)]
print('Candidate source glyphs',list(donors),'no PDF or new font',flush=True)
