"""Record source-only dash intervals and local literal-curve crosscheck; no draw."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.optimize import linprog,brentq
from scipy.interpolate import PchipInterpolator
from scipy.integrate import quad
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=base/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON'
v7=json.loads((root/'DO TIET DIEN MUC VA PHA CHUNG NGUON V7 CHUA NGHIEM THU.json').read_text(encoding='utf8'))
v6=json.loads((root/'PHA CHU KY VA DOAN MUC CHUNG TU169 BIEN NGUON V6 CHUA KHOA.json').read_text(encoding='utf8'))
plan=json.loads((base/'PHUONG AN DONG BO P08 DE ROOT KIEM V4.json').read_text(encoding='utf8'))
audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));g=next(t for t in audit['graphs'] if t['family']=='4SA16')
ee=v7['all_source_edges'];step=v6['source_uncertainty_one_native_px_pt'];X=np.array([[1.,r['cycle_index'],int(r['kind']=='end')] for r in ee]);y=np.array([r['source_arc_pt'] for r in ee]);A=np.vstack([X,-X]);b=np.r_[y+step,-y+step];bounds=[(-1,1),(10,10.8),(6.5,8)]
intervals={}
for index,label in enumerate(['phase_pt','cycle_pt','ink_pt','gap_pt']):
    obj=np.zeros(3)
    if index<3:obj[index]=1
    else:obj[1]=1;obj[2]=-1
    lo=linprog(obj,A_ub=A,b_ub=b,bounds=bounds,method='highs');hi=linprog(-obj,A_ub=A,b_ub=b,bounds=bounds,method='highs');assert lo.success and hi.success
    intervals[label]=[float(obj@lo.x),float(obj@hi.x)]
fit=v7['common_fit'];proposal=dict(phase_pt=round(fit['phase_pt'],2),cycle_pt=round(fit['period_pt'],2),ink_pt=round(fit['dash_pt'],2));proposal['gap_pt']=round(proposal['cycle_pt']-proposal['ink_pt'],2)
params=np.array([proposal[k] for k in ['phase_pt','cycle_pt','ink_pt']]);d=(X@params-y)/step
xt=np.array([t['u_native'] for t in g['axis']['flow_ticks']]);qt=np.array([t['litre_per_minute']*.06 for t in g['axis']['flow_ticks']]);ht=np.array([t['H_m'] for t in g['axis']['H_grid_calibration']['ticks']]);vt=np.array([t['v_native'] for t in g['axis']['H_grid_calibration']['ticks']])
result=[]
for row in plan['rows']:
    q=np.array(row['source_Q_m3_h']);h=np.array(row['source_H_m']);u=np.interp(q,qt,xt);v=np.interp(h,ht,vt);p=PchipInterpolator(u,v,extrapolate=False);dp=p.derivative()
    speed=lambda x:float(np.hypot(1,dp(x)))*step
    arc=lambda x:quad(speed,float(u[0]),float(x),points=[float(t) for t in u[1:-1] if t<x],epsabs=1e-9)[0]
    solid_u=brentq(lambda x:arc(x)-(proposal['phase_pt']+7*proposal['cycle_pt']),float(u[0]),float(u[-1]),xtol=1e-10)
    source=next(r for r in v7['records'] if r['model']==row['model']);delta=solid_u-source['source_transition_half_coverage_u']
    edges=[r for r in ee if r['model']==row['model']];err=[r['common_fit_error_native_px'] for r in edges]
    result.append(dict(model=row['model'],source_solid_half_coverage_u=source['source_transition_half_coverage_u'],new_literal_curve_planning_solid_u=solid_u,
       planning_delta_source_native_px=delta,within_actual_source_one_native_pixel=abs(delta)<=1,source_cap_count=len(edges),source_max_abs_edge_error_native_px=max(map(abs,err)),
       new_literal_nodes_from_local_real_Q_and_H_ticks_only=[[float(x),float(y)] for x,y in zip(u,v)],node_count=len(u),
       no_new_PDF_or_actual_saved_path_yet=True,phase_not_chosen_from_table=True))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==v7['source_sha256'] and sha(S.result(name))==v7['current_sha256']
out=dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),same_original_Perotac_X7_only=True,
      common_source_estimate=fit,feasible_intervals_each_parameter_with_all169_source_edges_at_one_pixel=intervals,
      parameter_intervals_correlated_not_independently_combinable=True,phase_origin_hidden_frame_uncertainty_native_px=1.,
      exact_original_PDF_phase='UNKNOWN',half_coverage_edges_are_source_measurement_not_vector_fact=True,
      rounded_physical_style_proposal_pending_ROOT=proposal,rounded_source_edges_within_one_px=int((abs(d)<=1).sum()),rounded_max_source_edge_error_native_px=float(max(abs(d))),
      source_method_replaced_first_colour_pixel_caps=True,local_source_tick_crosscheck_only_after_source_style_fit=result,
      numeric_QH_table_not_used_to_choose_phase_cycle_or_dash=True,PDF_font_or_progress_written=False)
Path(fresh(root/'KHOANG THONG SO PHA VA NHIP NGUON V8 DE ROOT KIEM.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
md=f'''# Nhịp đứt–liền chung đo bằng tiết diện mực nguồn

**Chỉ đọc, chưa PDF. Ước lượng từ 169 biên thuộc 13 nhánh cùng nguồn Perotac; không dùng các ô Q–H để chọn pha hoặc chu kỳ.**

Phương pháp mới lấy tích phân độ tối vuông góc nét, trừ nền thực của hàng/cột ảnh nguồn và xác định biên ở mức 50% tiết diện mực đầy. Mỗi biên có bất định **±1 điểm ảnh 150 dpi**. Việc này tránh nhầm điểm mực rời hoặc một cột JPEG thiếu thành một đoạn mới; ảnh và toàn bộ tiết diện từng nhánh được giữ riêng. Không đổi hay vẽ lại ảnh nguồn.

Khớp chung nguồn: pha **{fit['phase_pt']:.8f} pt**, chu kỳ **{fit['period_pt']:.8f} pt**, đoạn mực **{fit['dash_pt']:.8f} pt**, khe **{fit['period_pt']-fit['dash_pt']:.8f} pt**. Cả **169/169** biên nằm trong ±1 điểm ảnh; sai số tuyệt đối trung vị **{fit['median_abs_error_native_px']:.5f}**, trung bình **{fit['mean_abs_error_native_px']:.5f}**, lớn nhất **{fit['max_abs_error_native_px']:.5f}** điểm ảnh. So cùng bộ biên, phương án V5 pha 0 có trung vị 0,35690/lớn nhất 0,92034; V6 có trung vị 0,32347/lớn nhất 1,13174. Đây là cải thiện toàn bộ phép đo nguồn, không chỉ ba nhánh.

Khung trái che điểm bắt đầu. Phần quy cung dưới khung chỉ tiếp tục tiếp tuyến nguồn khoảng 2,5 điểm ảnh để đo kiểu nét; không tạo số Q–H. **Pha, chiều dài và cap (đầu nét) PDF nguồn chính xác: CHƯA THỂ XÁC MINH** vì bản gốc chỉ còn JPEG. Thông số dưới đây là đề xuất đồ họa nằm trong sai số ảnh nguồn, không phải trạng thái vector gốc đã biết.

Đề xuất chung: **pha {proposal['phase_pt']:.2f} pt, chu kỳ {proposal['cycle_pt']:.2f} pt, mực/khe {proposal['ink_pt']:.2f}/{proposal['gap_pt']:.2f} pt**. Sau làm tròn vẫn {int((abs(d)<=1).sum())}/169 biên trong ±1 điểm ảnh, lớn nhất {max(abs(d)):.5f} điểm ảnh. Chưa khóa trước ROOT/đồ họa kiểm.

| Thông số | Khoảng khả thi khi đủ 169 biên cùng nằm trong ±1 điểm ảnh |
|---|---:|
'''
for key,(lo,hi) in intervals.items():md+=f'| {key} | {lo:.6f}…{hi:.6f} pt |\n'
md+='\nCác khoảng có liên hệ với nhau; không ghép tùy ý các đầu khoảng. Đây chưa bao gồm việc đo độc lập lại hình ảnh PDF được lưu.\n\n| Model | Chuyển liền nguồn đo 50% (x) | Đề xuất trên đường bảng thật (x) | Lệch (điểm ảnh) |\n|---|---:|---:|---:|\n'
for r in result:md+=f"| {r['model']} | {r['source_solid_half_coverage_u']:.6f} | {r['new_literal_curve_planning_solid_u']:.6f} | {r['planning_delta_source_native_px']:+.6f} |\n"
md+='''
Đối chiếu đường mới chỉ dùng mỗi vạch Q/H thực lân cận, sau khi thông số kiểu nét đã khớp nguồn xong; không dùng hệ số khớp toàn trục làm đầu vào vẽ. Chưa tạo PDF nên các tọa độ kế hoạch này chưa phải nghiệm thu 104 tâm nét đã lưu. Các vạch phụ, chữ nguồn và nhãn vẫn phải hoàn tất chứng cứ trước mẫu.

Nguồn, bản giao SHA256 và tiến độ giữ nguyên. Phương pháp đầu màu ở V5/V6 là tham chiếu đã thay; không dùng để ép các biên mới.
'''
Path(fresh(root/'KHOANG THONG SO PHA VA NHIP NGUON V8 DE ROOT KIEM.md')).write_text(md,encoding='utf8')
print('SOURCE INTERVALS',intervals,'ROUNDED',proposal,'SOURCE CAPS',int((abs(d)<=1).sum()),'MAXPX',max(abs(d)),flush=True)
for r in result:print(r['model'],'SOLID SOURCE/NEW',r['source_solid_half_coverage_u'],r['new_literal_curve_planning_solid_u'],'DELTA',r['planning_delta_source_native_px'],flush=True)
