from catwork import start,fresh
S,D,N=start()
from catfix import verify
from pathlib import Path
src=S.src('Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf')
for p in [5,16,22,26,28,30,32]:
    rect=(50,400,560,635) if p==5 else (50,85,560,380)
    verify.crop(src,p-1,rect,dpi=175).save(fresh(S.report(f'G01/bang-day-du-{p}.png')))
