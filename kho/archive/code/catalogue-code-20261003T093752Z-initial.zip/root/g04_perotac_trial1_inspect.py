from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from pathlib import Path
import json
g=Path(S.report('G04'))
for p in [z for d in g.rglob('*V3*') for z in ([d]+list(d.iterdir()) if d.is_dir() else [d])]:
 if 'ROOT' in str(p) and 'MOC' in str(p):
  print('ROOT V3 FILE',p)
  if p.suffix.lower()=='.json':
   r=json.loads(p.read_text(encoding='utf8'));print(json.dumps(r,ensure_ascii=False)[:16000])
E=Editor(S.result('Perotac bơm giếng SA_compressed (bản mới).pdf'))
for pi in [1,2,7]:
 P=E.page(pi);print('PAGE',pi+1,'OPS',len(P.ops),'LAST',[(i.op,[str(v) for v in i.operands]) for i in P.ops[-10:]])
E.close()
