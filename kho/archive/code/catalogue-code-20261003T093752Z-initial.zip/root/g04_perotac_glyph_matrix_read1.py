"""Đọc vị trí từng điểm ảnh chữ nguồn; không tạo/chỉnh PDF."""
from catwork import start
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
import numpy as np
E=Editor(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf'),backend='fitz');R=Raster(E)
cases=[('4SA16/25',7,[282,204,330,215]),('4SA16/20',7,[282,275,330,286]),('4SA16/18',7,[282,304,330,315]),('4SA16/9',7,[282,433,324,444]),('4SA8/33',5,[1160,325,1203,336]),('4SA12/32',6,[1161,229,1209,240])]
for word,pi,b in cases:
    cv=R.canvas(max(R.images(pi),key=lambda z:z.W*z.H));x0,y0,x1,y1=b;a=cv.orig[y0:y1,x0:x1].astype(float)
    al=R.alpha_of(a,np.array([255.,255.,255.]),np.array([57.,55.,57.]))
    print('\n',word,'bbox',b,'native x mod100',flush=True)
    print('     '+''.join(str((x//10)%10) for x in range(x0,x1)),flush=True)
    print('     '+''.join(str(x%10) for x in range(x0,x1)),flush=True)
    for i,row in enumerate(al):print(f'{y0+i:4d} '+''.join('#' if v>=.65 else '+' if v>=.4 else ':' if v>=.18 else '.' if v>=.05 else ' ' for v in row),flush=True)
    print('ALPHA (10ths) >=.2',[(x0+i,[round(float(q),2) for q in al[:,i]]) for i in range(x1-x0) if np.max(al[:,i])>=.2],flush=True)
E.close()
