"""Đọc mực từng cột vị trí nguồn; không tích phân màu để suy pha."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=folder/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON'
m=json.loads((folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'));a0=json.loads((root/'13 NHIP DUT LIEN DOC NGUON CHI KIEM.json').read_text(encoding='utf8'))
audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));g=next(z for z in audit['graphs'] if z['family']=='4SA16')
paths={c['model']:c.get('native_path') for c in g['curves']};paths.update({c['model']:c['observed_source_path'] for c in m['prior_accepted_models_original_source_style_trace_only']})
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float);step=m['source_pixel_to_page_pt'];out=[]
for prior in a0['curves']:
    model=prior['model'];xy=np.array([[p['u'],p['v']] for p in paths[model]])
    if model=='4SA16/18':xy=np.asarray(prior['source_actual_trace_xy']);assert not prior['source_trace_issues']
    cols=[];intervals=[]
    for u in range(max(128,int(xy[0,0])),min(370,int(xy[-1,0]))+1):
        v=float(np.interp(u,xy[:,0],xy[:,1]));iv=int(round(v));win=a[max(181,iv-3):min(571,iv+4),u];ll=win@[.299,.587,.114];cc=win.max(1)-win.min(1)
        vis=(cc>=8)&(ll<220);present=bool(np.any(vis));cols.append(dict(u=u,source_center_v=v,visible_colour_ink=present,source_RGB_window_v_minus3_to_plus3=win.astype(int).tolist()))
        if present:
            if intervals and u==intervals[-1][1]+1:intervals[-1][1]=u
            else:intervals.append([u,u])
    merged=[];weak=[]
    for lo,hi in intervals:
        if merged and lo-merged[-1][1]<=3:weak.append([merged[-1][1]+1,lo-1]);merged[-1][1]=hi
        else:merged.append([lo,hi])
    full=[r for r in merged if r[1]<=271];transition=[r for r in merged if r[0]>=267 and r[0]<=283 and r[1]>=345]
    oldfirst=[[r[0],min(r[1],278)] for r in intervals if r[0]<=278];expected=next(c['source_only_observed_dash_native_intervals'] for c in m['QH_source_styles'] if c['model']==model)
    if model!='4SA16/18':assert oldfirst==expected,(model,oldfirst,expected)
    first=transition[-1][0] if transition else None
    sourceQ=float(np.interp(first,[t['u_native'] for t in g['axis']['flow_ticks']],[t['litre_per_minute']*.06 for t in g['axis']['flow_ticks']])) if first else None
    rec=dict(model=model,source_colour_ink_columns=cols,source_unmerged_ink_intervals=intervals,source_intervals_with_only_max2_missing_columns_merged=merged,source_weak_columns=weak,
             source_first_seven_dash_intervals=full,source_long_continuous_candidate_intervals=transition,source_transition_first_visible_ink_u=first,source_transition_Q_from_local_ticks=sourceQ,
             source_first_visible_not_original_vector_endpoint=True,source_transition_visible_edge_uncertainty_native_px=1.0,source_glyph_crossing_occlusion_limit=True,
             proposed_V3_solid_start_u=prior['V3_planned_solid_start_u'],proposed_V3_solid_start_Q=prior['V3_planned_solid_start_Q'],
             V3_source_edge_difference_native_px=prior['V3_planned_solid_start_u']-first if first else None,
             V3_source_edge_difference_pt=(prior['V3_planned_solid_start_u']-first)*step if first else None,source_identity_from_named_original_paths_not_H_table=True,
             no_numeric_node_used_to_adjust_phase=True,visual_review_still_required=True)
    out.append(rec);print(model,'DASH',full,'LONG',transition,'SOURCE first/Q',first,sourceQ,'V3 delta px',rec['V3_source_edge_difference_native_px'],flush=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(S.src(name))==a0['source_sha256'] and sha(S.result(name))==a0['current_sha256']
Path(fresh(root/'13 NHIP THEO MUC TUNG COT NGUON V2.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),method='Nguồn mỗi cột: trong7pixel theo tâm nét đã định danh, chroma≥8 vàL<220; giữRGBthật/cộttrống. Chỉghéptốiđa2cộtthiếudoJPEGvàghiđủ, không tích phân/nội suy mực vào khe. Nét mới chưa vẽ.',
 source_integral_method_previous_rejected=True,only_original_Perotac_X7=True,all13_source_colours_have_direct_images=True,source_first_ink_not_exact_pdf_vector_phase=True,curves=out,new_PDF_font_or_chart_sample_written=False,common_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close()
