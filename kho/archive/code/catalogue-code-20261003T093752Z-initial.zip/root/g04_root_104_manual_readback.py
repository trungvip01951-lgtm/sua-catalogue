"""ROOT chép riêng số vừa nhìn ở hai ảnh đọc trực tiếp từ PDF; đối chiếu phương án."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,csv
import numpy as np
import pymupdf as fitz
base=Path(S.report('G04/ROOT DOC NGUON104 VA TRUC LOCAL TRANG8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Hai khối chép riêng từ hai ảnh đã mở trong phiên, không lấy bảng hãng này làm nguồn hãng khác.
perotac='''
4 24 23 22 20 18 15 12 9
5 30 29 28 25 22 19 15 11
6 36 35 33 30 26 22 18 13
8 47 46 44 40 35 30 24 17
9 53 52 50 45 40 33 27 19
11 65 64 61 55 48 41 33 24
12 71 70 66 60 53 45 36 26
14 83 81 77 70 62 52 42 30
16 95 93 88 80 70 60 48 35
18 107 104 99 90 79 67 54 39
20 118 116 110 100 88 74 60 43
23 136 133 127 115 101 86 69 50
25 148 145 138 125 110 93 75 54
'''
redpump='''
4 24 23 22 20 18 15 12 9
5 30 29 28 25 22 19 15 11
6 36 35 33 30 26 22 18 13
8 47 46 44 40 35 30 24 17
9 53 52 50 45 40 33 27 19
11 65 64 61 55 48 41 33 24
12 71 70 66 60 53 45 36 26
14 83 81 77 70 62 52 42 30
16 95 93 88 80 70 60 48 35
18 107 104 99 90 79 67 54 39
20 118 116 110 100 88 74 60 43
23 136 133 127 115 101 86 69 50
25 148 145 138 125 110 93 75 54
'''
specs=[('PEROTAC SA','4SA16','Perotac bơm giếng SA_compressed (bản mới).pdf',perotac,
         'G04/PHUONG AN DONG BO TOAN BIEU DO P08/PHUONG AN DONG BO P08 DE ROOT KIEM V3.json',fitz.Rect(194,434,381,558)),
        ('REDPUMP SL','4SL16','Redpump gieng SL_compressed (bản mới).pdf',redpump,
         'G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8/PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json',fitz.Rect(191,429,376,552))]
allrows,receipts=[],[]
for tag,family,name,literal,planrel,clip in specs:
    src,cur=Path(S.src(name)),Path(S.result(name))
    before=dict(source=sha(src),current=sha(cur))
    pp=Path(S.report(planrel));plan=json.loads(pp.read_text(encoding='utf-8'))
    if tag=='PEROTAC SA':
        planned={r['model']:(r['source_Q_m3_h'],r['source_H_m']) for r in plan['rows']}
    else:planned={r['model']:(r['Q'],r['H']) for r in plan['page8_QH_models']}
    records=[]
    for line in literal.strip().splitlines():
        z=list(map(int,line.split()));assert len(z)==9
        model=family+'/'+str(z[0]);q=[0,3,6,9,12,15,18,21];hs=z[1:]
        assert planned.pop(model)==(q,hs),(tag,model)
        for Q,H in zip(q,hs):records.append(dict(file=name,page=8,model=model,Q_m3h=Q,H_source_m=H,plan_matches_source=True))
    assert len(records)==104 and not planned
    with fitz.open(src) as a,fitz.open(cur) as b:
        x=a[7].get_pixmap(matrix=fitz.Matrix(5,5),clip=clip,alpha=False)
        y=b[7].get_pixmap(matrix=fitz.Matrix(5,5),clip=clip,alpha=False)
        aa=np.frombuffer(x.samples,np.uint8);bb=np.frombuffer(y.samples,np.uint8)
        assert aa.shape==bb.shape
        changed=int(np.count_nonzero(aa!=bb))
        assert changed==0,(tag,'ROI cột H có đổi',changed)
    assert before==dict(source=sha(src),current=sha(cur))
    receipts.append(dict(file=name,page=8,hashes=before,plan_sha256=sha(pp),read_models=13,read_QH_cells=104,
                         status='ĐẠT ĐỌC BẢNG NGUỒN VÀ ĐỐI CHIẾU PHƯƠNG ÁN; CHƯA NGHIỆM THU PDF MẪU',
                         source_image=str(base/f'{tag} BANG104 NGUON.png'),
                         actual_H_ROI_source_current_pixel_changes=changed,H_ROI_top_left=list(clip),
                         method='ROOT nhìn ảnh kết xuất trực tiếp đúng nguồn rồi chép riêng toàn104số của từng file; không đọc báo cáo thay ảnh.',
                         eta_numeric='CHƯA THỂ XÁC MINH: Không có bảng hiệu suất',
                         next='Khóa vạch trục thực, bộ chữ sạch, bố trí chữ và nét đứt/liền; kiểm PDF thực sau mẫu.'))
    allrows.extend(records)
Path(fresh(base/'ROOT DOC BANG RIENG HAI FILE104 - DUNG SO NGUON.json')).write_text(json.dumps(dict(receipts=receipts,points=allrows),ensure_ascii=False,indent=2),encoding='utf-8')
with open(fresh(base/'ROOT CHI DOC208 SO BANG HAI NGUON.csv'),'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
print(json.dumps(receipts,ensure_ascii=False),flush=True)
