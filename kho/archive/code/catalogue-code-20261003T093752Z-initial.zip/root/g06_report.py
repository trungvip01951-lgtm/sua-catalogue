from catwork import start,fresh,row
S,D,N=start()
from catfix import verify
from pathlib import Path
import json,datetime
NAME='Aquaris FS_300dpi_75% (bản mới).pdf'
root=Path(S.report('G06'));st=json.loads((root/'final-state-v2.json').read_text(encoding='utf-8'))
acc=json.loads((root/'acceptance-v2.json').read_text(encoding='utf-8'))
assert acc['job_check']['ok'] and not acc['outside_pixels'] and acc['source_preserved']
assert acc['full_model_ocr']['ok'] and all(c['ocr']['ok'] for c in acc['checks'])
assert all(p['pixels_exactly_equal'] for p in acc['unchanged_pages'])
assert acc['metadata_equal'] and acc['xmp']['values_equal'] and acc['bookmarks_equal'] and acc['links_equal']
assert acc['native_image_preserved']['same_jpeg_quantization'] and acc['kept_page4_content_stream_equal']
rows=[
row(51,NAME,1,'Chép nét số/dấu nối cùng kiểu từ model thật đầu bảng; giữ từng nhóm số và lời giải thích',
    'FS 15 15 1.5','FS-35-7-2.2','ĐẠT','So sanh G06.png; G06/acceptance-v2.json; G06/font-probe.json'),
row(52,NAME,'2–3','Không dùng chữ thường khác nét đậm của tiêu đề',
    '(KW)','Còn nguyên (KW); chưa sửa được (kW) đúng kiểu chữ','CHƯA ĐẠT','G06/probe.json; G06/font-probe.json; So sanh G06.png'),
row(53,NAME,4,'Thử hai mẫu bằng nét chữ trong bảng; mẫu chưa đúng nét nên giữ nguyên theo điều kiện prompt',
    'Hàng 5, 13 nhỏ; 15, 18 lớn; 28 sát viền','Giữ nguyên bảng gốc; chưa đạt mục tiêu đồng cỡ','CHƯA ĐẠT',
    'G06/review/mau-sua.png; G06/review/mau-sua-2.png; G06/acceptance-v2.json'),
]
out=fresh(S.report('BAO CAO G06.md'));fresh(Path(out).with_suffix('.json'))
verify.write_report(rows,out,title='BÁO CÁO NHÓM G06 – Aquaris FS (4 trang)')
lines=['# BÁO CÁO NHÓM G06 – Aquaris FS (4 trang)', '',
       '**Tổng: 3 việc cần sửa · ĐẠT 1 · CHƯA ĐẠT 2 · CHƯA THỂ XÁC MINH 0.**', '',
       '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
       '|---|---|---|---|---|---|---|---|']
for r in rows:
    vals=[r[k] for k in ('stt','file','page','old','new','item','result','evidence')]
    lines.append('| '+' | '.join(str(v).replace('|','/') for v in vals)+' |')
lines+=['', '**#136 – GIỮ NGUYÊN:** giữ cả hai catalogue FS vì là hai dòng bơm khác nhau. Không đổi/xóa/ghi file nhóm G07. Không tính #136 vào 3 việc cần sửa.', '',
        '## Phần chưa đạt', '',
        '#52: có chữ k thường tại Power (kW) trang 1 và socket trang 4, nhưng đều khác nét đậm của tiêu đề bảng. Chưa xác minh được mẫu k cùng kiểu đậm trong 4 trang ảnh; giữ KW, không lấy phông/chữ từ ngoài file.', '',
        '#53: mẫu đầu lỗi tách nền tại đường kẻ; mẫu thứ hai sửa nền nhưng còn một số ký tự không đúng nét khi ghép. Dừng cách này sau hai mẫu. Bảng trang 4 được giữ nguyên ảnh và nội dung nguồn đúng điều kiện “không đẹp thì giữ nguyên”; chưa gọi mục tiêu đồng cỡ là hoàn thành.', '',
        'Hai mẫu thử được giữ riêng trong G06/review. Không dùng bảng thử trong file cuối.', '',
        '## Nghiệm thu bản cuối', '',
        '- Đọc lại từng nhóm mới: 35, 7, 2.2; đọc cả ví dụ ra FS - 35 - 7 - 2.2.',
        '- Giữ nguyên tên FS, vị trí từng nhóm, lời giải thích và đường phân cách. Số/dấu nối chép từ dòng FS-35-7-2.2 thật ở bảng trang 2, điều chỉnh về đúng chiều cao chữ sơ đồ.',
        f"- So hình số 5 giữa sơ đồ và mẫu chữ đậm trong bảng: độ trùng vùng nét {100*st['font5_iou']:.2f}%; đã soi ảnh trước/sau.",
        '- Cấu trúc PDF đạt; không đổi ngoài vùng ví dụ ở ngưỡng kiểm ảnh quét. Trang 2, 3, 4 giống nguồn từng điểm ảnh ở 200 điểm ảnh/inch; luồng nội dung trang 4 cũng giống nguồn.',
        '- Giữ 4 trang, khổ trang, dấu trang, liên kết và mọi giá trị thông tin XML. Byte XML có thể đổi cách ghi dấu nháy/khoảng trắng khi lưu; giá trị được kiểm độc lập.',
        '- Ảnh trang 1 vẫn 2480 × 3508 điểm ảnh, khoảng 300 điểm ảnh/inch; giữ bảng lượng tử JPEG và cấu hình màu. Ảnh gốc các trang 2–4 giữ nguyên luồng nén.',
        '- Kiểm ghi lại ảnh không sửa ở trang 1 và 4 đều có sai khác trung bình dưới 1 mức màu.', '',
        f"Nguồn: {st['source']}", '',f"File ra: {st['final']}", '',
        f"SHA256 nguồn trước/sau: {acc['source_sha256']}", '',f"SHA256 file ra: {acc['destination_sha256']}", '',
        'SHA256 là mã kiểm tra nội dung file; kW là kilôoát, đơn vị công suất. KW là cách viết hoa chưa chuẩn còn giữ ở #52. JPEG là định dạng nén ảnh; XML lưu dữ liệu thông tin trong PDF.', '',
        '## Dữ liệu cho kiểm chéo', '',
        '- G06/inspection.json: đường dẫn, mã kiểm tra nguồn, phân loại 4 trang ảnh.',
        '- G06/probe.json: dòng đọc được, tọa độ trang và nguồn k tìm được bằng nhận dạng ảnh.',
        '- G06/font-probe.json: 11 khối hình của model nguồn và nguồn k ở dòng socket; máy đọc số 7 thành / ở model nguồn, đã đối chiếu ảnh và gán đúng.',
        '- G06/font-p2.png, font-p3.png, font-p4.png: ảnh phóng to dòng model và dòng socket.',
        '- G06/geometry.json: đường kẻ bảng, từng ô và từ chữ chuẩn bằng tọa độ ảnh gốc.',
        '- G06/build-state-2.json: dữ liệu mẫu thứ hai, vị trí từng nét mới, chiều cao và hệ số phóng số.',
        '- G06/final-state-v2.json và acceptance-v2.json: trạng thái bản cuối và kiểm độc lập; đây là hai file dùng để chốt kết quả.',
        '- G06/acceptance.json là lần kiểm trước đã bắt ảnh trang 4 chưa khôi phục; đã khắc phục, không dùng kết quả cũ làm nghiệm thu.', '',
        'Mọi PDF được ghi bằng catfix; không cài phần mềm. Không ghi đè, đổi tên hoặc xóa bất kỳ file nguồn nào. Các mẫu không đạt và ảnh kiểm cũ được giữ để đối chiếu.', '',
        'Cần anh quyết: không có câu hỏi duyệt đang chờ; người kiểm chéo có thể tìm thêm nét k đúng kiểu và phương pháp giữ nét bảng. Phần chưa đạt vẫn giữ nguyên.', '',
        'Phát hiện thêm không sửa: chưa đo độ chính xác biểu đồ vì nhóm này không thay bảng cột áp/lưu lượng.', '',
        'Tiến độ: G06 CHƯA XONG – 1/3 ĐẠT, #52 và #53 chưa đạt; #136 giữ nguyên.', '',
        'Lập báo cáo: '+datetime.datetime.now().isoformat()]
Path(out).write_text('\n'.join(lines),encoding='utf-8')
S.progress('G06','CHƯA XONG','1/3 ĐẠT; #52 thiếu k đúng nét đậm; #53 hai mẫu chưa đẹp nên giữ nguyên bảng; #136 giữ cả 2 dòng FS; kiểm bản cuối acceptance-v2.json đạt')
print('G06: 1/3 ĐẠT; #52, #53 CHƯA ĐẠT; #136 GIỮ NGUYÊN',flush=True)
print(out,flush=True)
