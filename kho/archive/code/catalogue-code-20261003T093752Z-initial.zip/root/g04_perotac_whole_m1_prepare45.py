"""Lock preparation and QA NOT RUN; no PDF operation is executed."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from PIL import Image
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_whole_pdf_tools46 import sha, read, snapshot
import json

name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'CHUAN BI M1 RAMV3 CHUA CHAY'
ram=base/'RAM TRANG08 DONG BO LONG4 DUNG V3'
document=read(ram/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json')
fontpath=Path(S.report(document['glyph_source_file']))
axispath=Path(S.report(document['axis_literal_source_file']))
assert sha(S.src(name))==document['source_sha256'] and sha(S.result(name))==document['current_sha256']
assert sha(fontpath)==document['glyph_source_report_SHA256']
assert sha(axispath)==document['axis_source_report_SHA256']
files=[ram/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json',fontpath,axispath,
    ram/'PEROTAC P08 TOAN TRANG RAM150 CHUA NGHIEM THU.png',
    ram/'PEROTAC P08 TOAN BIEU DO RAM600 CHUA NGHIEM THU.png',
    base/'DOI CHIEU VACH PHU NGUON THAT/VACH PHU34 VA TRUC CUC BO NGUON V4 DE ROOT KIEM.json',
    base/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON/KHOANG THONG SO PHA VA NHIP NGUON V8 DE ROOT KIEM.json',
    base/'ETA4 DOAN C2 NGUON VA DAU LAN KHUNG/ETA4 BEZIER C2 VA558 DIEM NGUON CHUA CHOT.json',
    Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/TOAN BO12 DO LAI DUONG CHU V4 LONG4 DUNG NGUON/DO LAI12 DUONG CHU V4 LONG4 NGUON VA MAT NA RAM.json'))]
locked=[dict(path=str(p),sha256=sha(p)) for p in files]
src_snapshot=snapshot(S.src(name));current_snapshot=snapshot(S.result(name))
Path(fresh(root/'NGUON11 TRANG VA TAI NGUYEN TRUOC M1.json')).write_text(json.dumps(src_snapshot,ensure_ascii=False,indent=2),encoding='utf8')
Path(fresh(root/'CANONICAL11 TRANG VA TAI NGUYEN TRUOC M1.json')).write_text(json.dumps(current_snapshot,ensure_ascii=False,indent=2),encoding='utf8')
progress=S.read_progress()
Path(fresh(root/'TIEN DO CHI DOC KHI CHUAN BI M1.txt')).write_text(progress,encoding='utf8')
checks=['Cấu trúc mở đủ bộ đọc; chỉ trang 8 thay nội dung',
 'Ngoài vùng cả 11 trang ở 200dpi/ngưỡng0/cỡ nhỏ0/pad0',
 'Bảng Q-H và bảng kích thước p8; tất cả vùng khác giữ từng điểm ảnh',
 'Mọi ảnh gốc và ảnh/mặt nạ hiện hành giữ byte thô/SMask/dictionary/CTM',
 'Mọi lệnh/nét/chữ thật hiện hành giữ nguyên; chỉ thêm sau lớp cũ',
 'Info/XMP theo giá trị/dấu trang/liên kết/ghi chú/phông/khổ/hộp/xoay/chữ thật',
 'Nhận diện 13 đường từ khóa model-nghĩa source và hình path thật, không xếp hạng',
 '104 điểm đầu/giữa/cuối: đường PDF thật và tâm mực thật theo vạch cục bộ',
 'Đường giảm, đúng miền bảng; không kéo sau Q21 hoặc điền ô trống',
 'Cả 169 biên nhịp nguồn; độ dài vật lý/nhịp/chuyển đứt-liền theo khóa nguồn',
 '13 đường Q-H và η: màu/cỡ/nét đều; ít nhất 5 tiết diện sạch mỗi đường ở600dpi',
 '13 tên/chú giải,/11, toàn bộ chữ/số/dấu nhỏ trục: dữ liệu path thật và soi ảnh',
 'η riêng558 nguồn Perotac: tâm rõ547, 11 tâm đầu chưa rõ, đỉnh/độ trơn/miền',
 'Nền sạch toàn chart, không nét cũ/chấm mực cũ/miếng ảnh vá/sót dòng',
 'Ảnh toàn trang150 và vùng600; ROOT và người kiểm đồ họa nghiệm thu độc lập']
lock=dict(stage='CHƯA CHẠY; CHỜ KHÓA PDF RIÊNG TỪ ROOT',source=str(S.src(name)),canonical=str(S.result(name)),
 source_sha256=sha(S.src(name)),canonical_sha256=sha(S.result(name)),locked_files=locked,
 RAM_graphic_manifest_path=str(ram/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json'),
 RAM_graphic_manifest_sha256=sha(ram/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json'),
 source_native_edit_box=document['edit_source_native_box'],
 current_native_edit_box_white_cleaning_requires_whole_domain_mask_review=True,
 one_new_lossless_white_RGB_and_full_domain_SMask_then_true_PDF_paths_proposed=True,
 original_image_masks_native_operations_left_unchanged=True,
 planned_M1_directory=str(Path(S.report('G04/TOAN BIEU DO P08 NET PDF THAT MAU1'))),
 max_PDF_saves=1,whole_chart_PDF_samples_created=0,checks=[dict(check=c,status='CHƯA CHẠY') for c in checks],
 ROOT_graphic_approval_received=False,ROOT_PDF_execution_lock_received=False,
 no_PDF_written=True,no_common_progress_written=True,
 root_execution_lock_required_fields=dict(allow_Perotac_P08_M1=True,preparation_sha256='SHA256 của tệp khóa này',
    RAM_graphic_manifest_sha256=sha(ram/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json'),
    source_sha256=sha(S.src(name)),canonical_sha256=sha(S.result(name)),
    graphic_real_glyph_review_passed=True,full_chart_clear_domain_SMask_approved=True))
lockpath=Path(fresh(root/'KHOA CHUAN BI M1 VA QA CHUA CHAY.json'))
lockpath.write_text(json.dumps(lock,ensure_ascii=False,indent=2),encoding='utf8')

# Read only source p2/p3 for a separate whole-graph proposal. No p8 glyph reuse.
other=Path(S.report('G04/PHUONG AN TOAN BIEU DO TRANG02 VA03 CHI DOC'))
audit=read(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);inventory=[]
for family in ['3SS3','3SS4']:
 g=next(row for row in audit['graphs'] if row['family']==family)
 pi=g['page']-1;im=max(R.images(pi),key=lambda image:image.W*image.H);cv=R.canvas(im)
 assert 'Cfx' not in str(im.name) and im.W>1000
 source=src_snapshot['pages'][pi]['images'];assert any(r['name']==str(im.name) for r in source)
 if family=='3SS3':plot=[1300,122,1710,635];table=[962,936,1695,1165]
 else:plot=[64,124,791,786];table=[60,936,793,1165]
 images=[]
 for label,box in [('TOAN BIEU DO NGUON',plot),('BANG Q H NGUON',table)]:
  x0,y0,x1,y1=box;path=Path(fresh(other/(family+' '+label+'.png')))
  Image.fromarray(cv.orig[y0:y1,x0:x1]).save(path)
  images.append(dict(label=label,source_native_box=box,path=str(path),sha256=sha(path)))
 axes=[max(0,plot[0]),max(0,plot[1]),plot[2],plot[3]]
 inventory.append(dict(family=family,page=g['page'],source_image=str(im.name),source_native_size=[im.W,im.H],
  own_source_only=True,previous_audit_axis_to_recheck=g['axis'],
  curves=[{k:v for k,v in c.items() if k not in ['points','native_path']} for c in g['curves']],
  images=images,table_and_tick_labels_manual_readback_pending=True,
  p8_glyph_bank_style_not_yet_proven_do_not_reuse=True,no_PDF_or_RAM_new_graph_created=True))
E.close()
Path(fresh(other/'DINH VI BANG NHAN VACH NGUON TRANG02 VA03 CHI DOC.json')).write_text(json.dumps(dict(read_only=True,
 source_sha256=sha(S.src(name)),canonical_sha256=sha(S.result(name)),records=inventory,
 no_new_font_assumption=True,no_PDF_or_progress_written=True),ensure_ascii=False,indent=2),encoding='utf8')
assert sha(S.src(name))==lock['source_sha256'] and sha(S.result(name))==lock['canonical_sha256']
print('PREPARATION',str(lockpath),'SHA256',sha(lockpath),'PDF NOT RUN; current/source unchanged',flush=True)
print('READ ONLY p2/p3',str(other),flush=True)
