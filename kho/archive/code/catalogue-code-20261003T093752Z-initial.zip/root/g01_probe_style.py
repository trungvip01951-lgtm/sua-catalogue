from catwork import start
S,D,N=start()
from catfix.recipes import Job
from catfix.otext import OutlineText
from pathlib import Path
import pickle,collections,copy
j=S.job('Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf');T=j.T
st=pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes());T.__dict__.update(st['data'])
for p,q in [(14,'Components'),(14,'Warranty: 1 year'),(2,'KW'),(14,'AISI 304ss'),(14,'Direct start'),(1,'2')]:
    ms=T.find(p,q)
    print('TRANG',p+1,q)
    for m in ms[:3]:
        print(m,collections.Counter(g.style for g in m.glyphs))
        o=j.E.page(p).objs[m.glyphs[0].oi]
        print({k:v for k,v in o.items() if k not in ['subs','tokens','bbox','path','raw']})
        print([(g.char,g.oi,g.bbox) for g in m.glyphs[:4]])
print('probar filtered')
p=14;U=OutlineText(j.E)
allowed=[copy.copy(g) for g in T.page_glyphs(p) if 80<g.bbox[1]<710 and 150<g.bbox[0]<460 and j.E.page(p).objs[g.oi].get('fill')==('rg',(0.216064,0.204102,0.208008))]
print('count black',len(allowed),collections.Counter(j.E.page(p).objs[g.oi].get('fill') for g in T.page_glyphs(p) if 80<g.bbox[1]<710))
for g in allowed:U._assign_cluster(g)
U.glyphs[p]=allowed
U.learn([p],dpi=400)
U.describe_styles()
U.dump(p)
from catfix.otext import robust_fit
samples=[]
for txt,gl in U.text_lines(p):
    if '?' not in txt:
        samples.append(dict(chars=txt,boxes=[g.bbox for g in gl]))
print('visual metrics',robust_fit(samples))
for m in T.find(14,'Warranty: 1 year'):
    print('warranty glyphs',[(g.char,g.bbox) for g in m.glyphs])
j.close()
