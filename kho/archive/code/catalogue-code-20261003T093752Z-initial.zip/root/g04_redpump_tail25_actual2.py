"""Actual sample2 readback, source preservation and actual displayed ink; no PDF writes."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
import pymupdf as fitz
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Ref
from catfix import verify
root=Path(S.report('G04/REDPUMP 25 MAU SUA DUOI2'));b=json.loads((root/'TAO VA KIEM MAU2.json').read_text(encoding='utf8'));plan=json.loads(Path(S.report('G04/REDPUMP 25 PHUONG AN SUA DUOI/PHUONG AN RIENG SUA DUOI 25.json')).read_text(encoding='utf8'));trace=json.loads(Path(plan['source_curve_evidence']).read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert [sha(b['source']),sha(b['current']),sha(b['sample'])]==[b['source_sha'],b['current_sha'],b['sample_sha']]
ax,bx,ay,by=b['axis'];Ea=Editor(b['current'],backend='fitz');Ez=Editor(b['sample'],backend='fitz');Ra=Raster(Ea);Rz=Raster(Ez);P=Ez.page(7);want=np.array(b['RGB'])/255
hits=[]
for i,o in enumerate(P.objs):
 c=P.color_of(i,'stroke')
 if o['op']=='S' and c is not None and max(abs(np.array(c)-want))<1e-7:hits.append((i,o,P.object_pagepath(i)))
assert len(hits)==1,len(hits);oi,obj,path=hits[0];assert len(path)==2 and path[0][0].lower()=='m' and path[1][0].lower()=='c';seg=np.array([*path[0][1],*path[1][1]],float);assert seg.shape==(4,2)
def bez(t):return (1-t)**3*seg[0]+3*(1-t)**2*t*seg[1]+3*(1-t)*t*t*seg[2]+t**3*seg[3]
def atq(q):
 x=ax*q+bx;assert seg[0,0]-1e-6<=x<=seg[-1,0]+1e-6
 lo=0.;hi=1.
 for _ in range(65):
  t=(lo+hi)/2
  if bez(t)[0]<x:lo=t
  else:hi=t
 return bez((lo+hi)/2)
nodes=[]
for q,h in [(18,75),(21,54)]:
 pt=atq(q);actual=(pt[1]-by)/ay;err=float(actual-h);assert abs(err)<1e-4
 nodes.append(dict(Q=q,H_table=h,H_actual_path=float(actual),error_m=err,limit=max(1,h*.02),result_path_numeric='ĐẠT',visibility='Q18 vẫn dùng mực nguồn được giữ; vector mới bắt đầu nhìn từ clipQ18.0236' if q==18 else 'Điểm cuối hiện thật trong mẫu, clip đúngQ21'))
xy=np.array([bez(t) for t in np.linspace(0,1,601)]);assert np.all(np.diff(xy[:,0])>0) and np.all(np.diff(xy[:,1])<0)
assert abs(obj['lw']-b['width_pt'])<1e-8 and (obj['dash'] is None or obj['dash'][0]==[])
clip=list(obj['clip']);assert abs(clip[0]-b['clip_start_page_x'])<1e-6 and abs(clip[2]-b['clip_endpoint_page_x'])<1e-6
# All earlier actual PDF strokes retain coordinates/color/width/dash/clip.
def stroke_rows(pg):
 out=[]
 for i,o in enumerate(pg.objs):
  if o['op']=='S':out.append(dict(color=pg.color_of(i,'stroke'),lw=o['lw'],dash=o['dash'],clip=o['clip'],path=pg.object_pagepath(i)))
 return out
old_strokes=stroke_rows(Ea.page(7));new_strokes=stroke_rows(P);assert len(new_strokes)==len(old_strokes)+1
same=lambda a,z:json.dumps(a,sort_keys=True,default=lambda v:float(v))==json.dumps(z,sort_keys=True,default=lambda v:float(v))
preserved=[]
for r in old_strokes:
 assert any(same(r,z) for z in new_strokes)
 preserved.append(dict(color=r['color'],width_pt=r['lw'],dash=r['dash'],actual_path_and_clip_exact=True))
pixel=[];prefix=[];points=[];guard=[];bg_check=[];ink=[]
plot=(57.5,320,356,509)
for dpi in [150,200,450,600]:
 a=Ra.render_canvas(7,plot,dpi=dpi);z=Rz.render_canvas(7,plot,dpi=dpi);assert a.rect0==z.rect0 and a.orig.shape==z.orig.shape
 delta=np.any(a.orig!=z.orig,axis=2);xx=np.array([a.to_page(i+.5,0)[0] for i in range(a.orig.shape[1])]);prefixcols=xx<ax*18+bx;cnt=int(delta[:,prefixcols].sum());assert cnt==0,(dpi,'prefix',cnt)
 prefix.append(dict(dpi=dpi,Q_lt18_pixels_checked=int(delta[:,prefixcols].size),pixels_changed=cnt,meaning='Hình thức/nét nguồn trướcQ18 giữ từngpixel, không dùng thay cho sốH chưa đọc được tạiQ0'))
 for q in [0,3,6,9,12,15,18]:
  target=ax*q+bx;col=int(np.argmin(abs(xx-target)))
  if q==18 and xx[col]>=target:col-=1
  changed=int(delta[:,col].sum());assert changed==0
  points.append(dict(dpi=dpi,Q=q,sampled_column_Q=float((xx[col]-bx)/ax),column_pixels_checked=int(delta.shape[0]),changed_pixels=changed,result_preservation='ĐẠT',numeric_H_acceptance='Không tự nâng thànhĐẠT sốH; chỉ chứng minh mẫu không đổi 7 cột/nét trước điểm nối.'))
 for name,rect in [('Nhãn',(131.5,326,164,499)),('Trục H',(49,317,60.5,510)),('Khung trên',(57.5,508.5,356,510.5))]:
  aa=np.asarray(verify.crop(b['current'],7,rect,dpi));zz=np.asarray(verify.crop(b['sample'],7,rect,dpi));count=int(np.any(aa!=zz,axis=2).sum());assert count==0,(dpi,name,count);pixel.append(dict(dpi=dpi,region=name,changed_pixels=count))
 if dpi==600:
  # Narrow guard around every existing true stroke /23,/18, separated from /25.
  for r in old_strokes:
   for op,pts in r['path']:
    if op.lower() not in ['m','c','l']:continue
   native_segments=[];pos=None
   for op,pts in r['path']:
    p0=np.array(pts,float)
    if op.lower()=='m':pos=p0[0]
    elif op.lower()=='c':native_segments.append(np.vstack([pos,p0]));pos=p0[-1]
    elif op.lower()=='l':native_segments.append(np.vstack([pos,p0[0]]));pos=p0[0]
   changed=0;tested=0
   for s in native_segments:
    for t in np.linspace(0,1,151):
     p=(1-t)*s[0]+t*s[1] if len(s)==2 else (1-t)**3*s[0]+3*(1-t)**2*t*s[1]+3*(1-t)*t*t*s[2]+t**3*s[3]
     u,v=a.to_px(*p);u=int(round(u));v=int(round(v));rr=int(np.ceil(r['lw']*dpi/72/2+1.5))
     if rr<=u<a.orig.shape[1]-rr and rr<=v<a.orig.shape[0]-rr:
      sub=delta[v-rr:v+rr+1,u-rr:u+rr+1];changed+=int(sub.sum());tested+=int(sub.size)
   assert changed==0,(r['color'],changed);guard.append(dict(RGB=r['color'],width_pt=r['lw'],pixels_tested_with_repetition=tested,pixels_changed=changed))
# Original images, masks and CTMs including existing pixel patches all unchanged.
images=[]
for pi in range(Ea.doc.n_pages):
 targets=Rz.images(pi)
 for old in Ra.images(pi):
  hit=[z for z in targets if str(z.name)==str(old.name) and z.W==old.W and z.H==old.H and np.array_equal(z.ctm,old.ctm)]
  assert len(hit)==1,(pi,old.name);new=hit[0];raw=Ea.doc.stream_raw(old.ref);assert raw==Ez.doc.stream_raw(new.ref)
  for k in ['SMask','Mask']:
   om=old.d.get(k);nm=new.d.get(k)
   if isinstance(om,Ref):assert isinstance(nm,Ref) and Ea.doc.stream_raw(om)==Ez.doc.stream_raw(nm)
   else:assert str(om)==str(nm)
  images.append(dict(page=pi+1,name=str(old.name),raw_SHA256=hashlib.sha256(raw).hexdigest(),original_raw_masks_CTM_exact=True))
metadata={};fonts=[];contents=[]
with fitz.open(b['current']) as a,fitz.open(b['sample']) as z:
 links=lambda dd:[[{k:str(v) for k,v in r.items() if k!='xref'} for r in p.get_links()] for p in dd]
 metadata=dict(info=a.metadata==z.metadata,raw_XMP=a.get_xml_metadata()==z.get_xml_metadata(),bookmarks=a.get_toc()==z.get_toc(),links=links(a)==links(z),page_count=len(a)==len(z),page_sizes=[tuple(p.rect) for p in a]==[tuple(p.rect) for p in z])
 for pi,(p,q) in enumerate(zip(a,z)):
  eq=p.read_contents()==q.read_contents();assert eq or pi==7;contents.append(dict(page=pi+1,content_same=eq))
  for f in p.get_fonts(full=True):
   candidates=[g for g in q.get_fonts(full=True) if f[1:]==g[1:]];assert candidates;assert any((a.xref_stream(f[0]) or b'')==(z.xref_stream(g[0]) or b'') for g in candidates)
  fonts.append(dict(page=pi+1,original_font_resource_bytes_exact=True))
 drawn=[p for p in z[7].get_drawings() if p.get('type')=='s' and p.get('color') is not None and max(abs(np.array(p['color'])-want))<1e-6];assert len(drawn)==1 and drawn[0].get('stroke_opacity')==1.0
assert all(metadata.values())
# Actual displayed width/color, same alpha-area measurement for old and new.
rect=plan['allowed_cleanup_bbox'];A=np.asarray(verify.crop(b['current'],7,rect,600)).astype(float);Z=np.asarray(verify.crop(b['sample'],7,rect,600)).astype(float);core=np.array(b['RGB']);con=255-core
orig=trace['raw_observed_trace'];base=max(Ra.images(7),key=lambda i:i.W*i.H);obs=np.array([[p['u'],p['v']] for p in orig]);pp=np.array([base.to_page(u,v) for u,v in obs]);srcq=(pp[:,0]-bx)/ax;srch=(pp[:,1]-by)/ay
for q in np.linspace(18.25,20.75,51):
 sH=float(np.interp(q,srcq,srch));npt=atq(q);nH=(npt[1]-by)/ay;x=int(round((ax*q+bx-rect[0])*600/72));oldy=int(round((rect[3]-(ay*sH+by))*600/72));newy=int(round((rect[3]-npt[1])*600/72));slope=(np.interp(q+.02,srcq,srch)-np.interp(q-.02,srcq,srch))/.04*ay/ax
 measures=[];colors=[]
 for ar,y in [(A,oldy),(Z,newy)]:
  rows=np.arange(max(0,y-14),min(len(ar),y+15));pix=ar[rows,x];cc=pix[:,1:].mean(1)-pix[:,0];al=np.clip(np.median((255-pix)/con,axis=1),0,1);al[cc<5]=0;measures.append(float(al.sum()*72/600/np.sqrt(1+slope*slope)));eligible=cc>5;colors.append(pix[eligible][np.argmin(pix[eligible].mean(1))].tolist() if eligible.any() else None)
 ink.append(dict(Q=float(q),source_display_H=sH,new_actual_path_H=float(nH),source_width_area_pt=measures[0],new_width_area_pt=measures[1],source_core_RGB=colors[0],new_core_RGB=colors[1]))
# Old /25 continuation beyondQ21 has no remaining dark/chromatic core at actual
# source center; this is not a claim that JPEG noise outside the stroke vanished.
continuation=[]
for q in np.arange(21.08,min(21.56,float(srcq.max())),.04):
 sh=float(np.interp(q,srcq,srch));x=int(round((ax*q+bx-rect[0])*600/72));y=int(round((rect[3]-(ay*sh+by))*600/72));ys=np.arange(max(0,y-10),min(len(Z),y+11));p=Z[ys,x];lum=p@np.array([.299,.587,.114]);ch=p[:,1:].mean(1)-p[:,0];count=int(((lum<220)&(ch>7)).sum());assert count==0,(q,count)
 continuation.append(dict(Q=float(q),source_center_H=sh,remaining_dark_chromatic_core_pixels=count))
Ea.close();Ez.close();outside=verify.outside_pixels(b['current'],b['sample'],{8:[b['allowed_bbox']]},dpi=200,thr=0,min_size=0,pad=.4);assert not outside
out=dict(sample=b['sample'],sample_sha=sha(b['sample']),source_sha=sha(b['source']),current_sha=sha(b['current']),actual_path_object=oi,actual_path=path,actual_clip_bbox=clip,actual_visible_Q_domain=[b['clip_start_Q'],21.],points_path_numeric=nodes,clip_Q18_limitation='Path neoQ18/H75 có tọa độ đúng nhưng stroke clip từQ18.0236 để giữ pixelnguồn miềnQ<18. TạiQ18, mực nguồnH≈74.972 nằm trongngưỡng1.5m; không tuyên bố neo vector này đã thay mực nguồn.',previous_7_Q_columns_preserved=points,prefix_pixels=prefix,original_strokes_preserved=preserved,old_23_18_pixel_guards=guard,original_label_axis_pixels=pixel,original_images_masks_CTM=images,metadata=metadata,fonts=fonts,other_page_contents=contents,actual_source_new_ink_measurements=ink,source_actual600_core_medianRGB=np.median([r['source_core_RGB'] for r in ink],axis=0).tolist(),new_actual600_core_medianRGB=np.median([r['new_core_RGB'] for r in ink],axis=0).tolist(),source_actual_width_median_pt=float(np.median([r['source_width_area_pt'] for r in ink])),new_actual_width_median_pt=float(np.median([r['new_width_area_pt'] for r in ink])),width_limit='Bề rộng tương đương suy từ ảnhnén, khôngphải bútgốc chínhxác; đoalpha/tiết diện cùngquy tắc600dpi vàsoi150/600dpi.',no_dark_core_old_continuation=continuation,outside_200dpi_threshold0=outside,canonical_written=False,sample1_status='CHƯA ĐẠT vìmaskcũ che nét, đãgiữ riêng',sample2_visual='Đãsoi toànvùng150dpi vàđầu cuối600dpi: khôngkhetrắng, nétliền/mượt; chờROOT đọcđộc lập',accepted_by_ROOT=False,status='MẪU2 ĐẠT các kiểmtrong hồsơ, CHỜ ROOT NGHIỆM THU')
Path(fresh(root/'DOC LAI PDF MAU2 VA BAO VE NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('ACTUAL2 nodes',nodes,'prefix0changed',prefix,'inkWidth',out['source_actual_width_median_pt'],out['new_actual_width_median_pt'],'colors',out['source_actual600_core_medianRGB'],out['new_actual600_core_medianRGB'],'allmetadata/images/styles same',flush=True)
