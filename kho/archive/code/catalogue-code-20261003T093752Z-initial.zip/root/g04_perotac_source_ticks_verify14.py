"""Locate printed source unit stems and correct read13 profile axis; read only."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
from scipy.signal import find_peaks
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/DOI CHIEU VACH PHU NGUON THAT'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float);L=a@[.299,.587,.114]
profiles={}
for key,y0,y1,x0,x1,axis in [('H LEFT STEM',181,572,120,124,1),('H RIGHT STEM',181,572,747,751,1),('Q TOP US',128,164,125,746,0),('Q TOP IMP',164,181,125,746,0),('Q LMIN',676,695,125,746,0),('Q M3',695,723,125,746,0)]:
    d=255-L[y0:y1,x0:x1];v=np.sum(d,axis=axis)
    profiles[key]=dict(native_first_index=y0 if axis==1 else x0,native_probe_box=[x0,y0,x1,y1],sum_original_darkness=v.tolist(),sum_over_pixel_axis=axis,original_RGB=cv.orig[y0:y1,x0:x1].tolist())
    peaks,props=find_peaks(v,prominence=40,distance=9)
    print(key,'RAW REGIONAL PEAKS NEED SHAPE REVIEW',[[int(p+(y0 if axis==1 else x0)),round(float(v[p]),1)] for p in peaks],flush=True)
row=[]
for y in range(125,187):
    reg=255-L[y,125:745];row.append([y,float(np.median(reg)),float(np.mean(reg))])
bot=[]
for y in range(668,734):
    reg=255-L[y,125:745];bot.append([y,float(np.median(reg)),float(np.mean(reg))])
print('TOP MAJOR ROW',sorted(row,key=lambda z:z[1],reverse=True)[:9],flush=True)
print('BOTTOM MAJOR ROW',sorted(bot,key=lambda z:z[1],reverse=True)[:12],flush=True)
for key,box in {'H PHAI':(736,166,802,580),'Q DUOI CO TOA DO':(110,669,752,734)}.items():
    x0,y0,x1,y1=box;raw=Image.fromarray(cv.orig[y0:y1,x0:x1]);raw.save(fresh(root/(key+' NGUON150dpi.png')));raw.resize((raw.width*5,raw.height*5),Image.Resampling.NEAREST).save(fresh(root/(key+' NGUON PHONG5LAN.png')))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'PROFILE VACH NGUON DUNG CHIEU CHI DOC V2.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),
    previous_read13_sum_darkness_rejected_wrong_axis=True,previous_read13_original_RGB_and_crops_valid=True,
    source_profiles=profiles,top_axis_source_row_darkness=row,bottom_axis_source_row_darkness=bot,
    peak_rank_must_not_assign_tick_values=True,original_Perotac_X7_only=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
