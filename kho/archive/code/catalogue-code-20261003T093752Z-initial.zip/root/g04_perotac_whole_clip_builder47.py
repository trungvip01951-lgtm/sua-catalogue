"""Pure CATFIX whole-chart builder. No file or PDF writer runs on import.

Old paint is excluded with an even-odd geometric clip. No white cover, raster
recompression, font substitution, or other-catalogue data is used.
"""
from pathlib import Path
from io import BytesIO
import hashlib
import numpy as np
import pikepdf
from catfix.vector import Editor, VPage
from catfix.raster import Raster
from catfix.cs import Instr, Num, Name, parse
from g04_perotac_whole_pdf_tools46 import read, sha

NAME='Perotac bơm giếng SA_compressed (bản mới).pdf'
RAM_REL='G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAM TRANG08 DONG BO LONG4 DUNG V3/RAM13 QH104 O VA ETA CHUA NGHIEM THU.json'

def ins(op,*operands):
    return Instr([Num(v) if isinstance(v,(int,float,np.floating)) else v for v in operands],op)

def corners(box):
    x0,y0,x1,y1=box
    return [[x0,y0],[x1,y0],[x1,y1],[x0,y1]]

def transform(points,matrix):
    return (np.c_[np.asarray(points,float),np.ones(len(points))]@matrix)[:,:2].tolist()

def polygon(points):
    return [ins('m',*points[0])]+[ins('l',*p) for p in points[1:]]+[ins('h')]

def intersects(a,b):
    return min(a[2],b[2])>max(a[0],b[0]) and min(a[3],b[3])>max(a[1],b[1])

def memory_bytes(editor,content,pi=7):
    # Serialize CATFIX's constructed stream in memory. No file save occurs.
    editor.doc.set_page_content(pi,content)
    buffer=BytesIO()
    editor.doc.pdf.save(buffer,object_stream_mode=pikepdf.ObjectStreamMode.preserve,
                        compress_streams=True,recompress_flate=False)
    return buffer.getvalue()

def prepare(S):
    base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
    ram_path=Path(S.report(RAM_REL));ram=read(ram_path)
    fontpath=Path(S.report(ram['glyph_source_file']));axispath=Path(S.report(ram['axis_literal_source_file']))
    fontdoc=read(fontpath);axisdoc=read(axispath);font={g['character']:g for g in fontdoc['glyphs']}
    geo=read(base/'KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json')
    assert sha(S.src(NAME))==ram['source_sha256'] and sha(S.result(NAME))==ram['current_sha256']
    assert sha(fontpath)==ram['glyph_source_report_SHA256'] and sha(axispath)==ram['axis_source_report_SHA256']
    ed=Editor(S.result(NAME),backend='pikepdf');R=Raster(ed);page=ed.page(7)
    im=max(R.images(7),key=lambda image:image.W*image.H)
    assert str(im.name)=='X7' and im.key==7 and im.W==1754 and im.H==1247
    cv=R.canvas(im);native_box=ram['edit_source_native_box'];roi=list(cv.rect(native_box))
    title=next(word for word in axisdoc['words'] if word['key']=='TITLE')
    assert title['literal_source_read']=='4SA16' and title['source_native_box']==[568,188,663,217]
    island=list(cv.rect(title['source_native_box']))
    mb=ed.mediabox(7);outer=[mb[0]-2,mb[1]-2,mb[2]+2,mb[3]+2]
    original_content=ed.build(7);original_ops=page.ops
    assert np.max(abs(page.ctm_at(len(page.ops))-np.eye(3)))<1e-10
    depth=0
    for op in page.ops:
        if op.op=='q':depth+=1
        elif op.op=='Q':depth-=1
        assert depth>=0
    assert depth==0
    main_index=next(image['i'] for image in page.images if image['name']=='X7')
    behind=[dict(op=o['op'],bbox=list(o['bbox']),index=o['i1']) for o in page.objs
            if o['i1']<main_index and o['op']!='n' and intersects(o['bbox'],roi)]
    assert not behind,'Painted native backdrop below X7 requires independent review'
    clips=[]
    for image in page.images:
        points=transform([[0,0],[1,0],[1,1],[0,1]],image['ctm'])
        p=np.asarray(points);bbox=np.r_[p.min(0),p.max(0)].tolist()
        clip=image.get('clip')
        effective=[max(bbox[0],clip[0]),max(bbox[1],clip[1]),min(bbox[2],clip[2]),min(bbox[3],clip[3])] if clip else bbox
        if not intersects(effective,roi):continue
        assert not image.get('textclip'),'A native text clipping region needs separate preservation'
        inverse=np.linalg.inv(image['ctm'])
        newclip=polygon(transform(corners(outer),inverse))+polygon(transform(corners(roi),inverse))
        keep=image['name']=='X7'
        if keep:newclip+=polygon(transform(corners(island),inverse))
        ed.insert_instrs(7,image['i'],[ins('q')]+newclip+[ins('W*'),ins('n')])
        ed.insert_instrs(7,image['i'],[ins('Q')],before=False)
        error=float(np.max(abs(np.asarray(transform(transform(corners(roi),inverse),image['ctm']))-corners(roi))))
        assert error<1e-8
        clips.append(dict(name=image['name'],original_Do_index=image['i'],CTM=image['ctm'].tolist(),
                          source_bbox=bbox,source_effective_bbox=effective,ROI_transform_max_error_pt=error,
                          keeps_source_title_island=keep))
    oldpaths=[]
    for obj in page.objs:
        if obj['op']=='n':continue
        expanded=[obj['bbox'][0]-obj['lw'],obj['bbox'][1]-obj['lw'],
                  obj['bbox'][2]+obj['lw'],obj['bbox'][3]+obj['lw']]
        if not intersects(expanded,roi):continue
        changes=[op.op for op in page.ops[obj['i0']:obj['i1']+1]
                 if op.op not in {'m','l','c','v','y','h','re','S','s','f','F','f*','B','B*','b','b*'}]
        assert not changes,('Unexpected native state changes inside old path',changes)
        inverse=np.linalg.inv(obj['ctm'])
        newclip=polygon(transform(corners(outer),inverse))+polygon(transform(corners(roi),inverse))
        ed.insert_instrs(7,obj['i0'],[ins('q')]+newclip+[ins('W*'),ins('n')])
        ed.insert_instrs(7,obj['i1'],[ins('Q')],before=False)
        oldpaths.append(dict(original_i0=obj['i0'],original_i1=obj['i1'],paint=obj['op'],bbox=list(obj['bbox']),
                             CTM=obj['ctm'].tolist(),original_native_path_unchanged=True))
    clips_only=ed.build(7)
    # Own explicit normal opaque state. All old resources remain intact.
    pg=ed.doc._pages[7];pg.obj.Resources=pikepdf.Dictionary(pg.obj.Resources)
    pg.obj.Resources.ExtGState=pikepdf.Dictionary(pg.obj.Resources.get('/ExtGState',pikepdf.Dictionary()))
    state_name='SAWholeP08Opaque'
    assert '/'+state_name not in pg.obj.Resources.ExtGState
    pg.obj.Resources.ExtGState['/'+state_name]=ed.doc.pdf.make_indirect(pikepdf.Dictionary(
        Type=pikepdf.Name('/ExtGState'),CA=1,ca=1,BM=pikepdf.Name('/Normal'),SMask=pikepdf.Name('/None')))
    group=[ins('q'),ins('gs',Name(state_name))]+polygon(corners(roi))+polygon(corners(island))+[ins('W*'),ins('n')]
    records=[]

    def add_path(path,kind,key,RGB,width=None,paint='S',**extra):
        start=len(group)
        if paint=='S':group.extend([ins('RG',*[v/255 for v in RGB]),ins('w',width),ins('J',0),ins('j',1),ins('d',[],0)])
        else:group.append(ins('rg',*[v/255 for v in RGB]))
        for op,points in path:group.append(ins(op,*[value for point in points for value in point]))
        group.append(ins(paint))
        records.append(dict(kind=kind,key=key,pagepath=[[op,[list(p) for p in points]] for op,points in path],
                            RGB=RGB,width_pt=width,paint=paint,group_instruction_start=start,
                            group_instruction_end=len(group),**extra))

    def pagepoint(point):return tuple(float(v) for v in cv.to_page(*point))
    def line(points,RGB,width,key,kind='line'):
        pp=[pagepoint(p) for p in points]
        add_path([('m',[pp[0]])]+[('l',[p]) for p in pp[1:]],kind,key,RGB,width)
    def rect(box,RGB,width,key):line(corners(box)+[corners(box)[0]],RGB,width,key,'frame')
    gx=[v['native_center'] for v in geo['main_observed_vertical_lines']]
    gy=[v['native_center'] for v in geo['main_observed_horizontal_lines']]
    ex=[v['native_center'] for v in geo['source_eta_vertical_lines']]
    ey=[v['native_center'] for v in geo['source_eta_horizontal_lines']]
    titlebox=[geo['source_title_left_native_u'],gy[0],gx[-1],geo['source_title_bottom_native_v']]
    for i,x in enumerate(gx[1:-1]):
        top=titlebox[3] if titlebox[0]<x<titlebox[2] else gy[0]
        line([(x,top),(x,gy[-1])],[225,225,225],.75,'QH V '+str(i),'grid')
    for i,y in enumerate(gy[1:-1]):line([(gx[0],y),(gx[-1],y)],[225,225,225],.75,'QH H '+str(i),'grid')
    for i,x in enumerate(ex[1:-1]):line([(x,ey[0]),(x,ey[-1])],[225,225,225],.75,'ETA V '+str(i),'grid')
    for i,y in enumerate(ey[1:-1]):line([(ex[0],y),(ex[-1],y)],[225,225,225],.75,'ETA H '+str(i),'grid')
    rect([gx[0],gy[0],gx[-1],gy[-1]],[93,93,93],.55,'QH outer')
    rect([ex[0],ey[0],ex[-1],ey[-1]],[93,93,93],.55,'ETA outer')
    rect(titlebox,[93,93,93],.55,'TITLE outer')
    line([(gx[0],164),(gx[-1],164)],[93,93,93],.55,'US base','frame')
    line([(gx[0],692),(gx[-1],692)],[93,93,93],.55,'M3 base','frame')
    for i,tick in enumerate(ram['source_secondary34_stems_retained']):
        pos=tick['source_tick_center_native'];axis=tick['axis']
        points=[(pos,159),(pos,164)] if axis=='Q US' else [(pos,176),(pos,180)] if axis=='Q IMP' else [(pos,692),(pos,696)] if axis=='Q M3' else [(746,pos),(752,pos)]
        line(points,[93,93,93],.55,'SECONDARY '+str(i),'tick')
    line([(83,164),(83,gy[-1])],[174,174,174],.25,'H decorative','decoration')
    line([(gx[0],725),(gx[-1],725)],[174,174,174],.25,'Q decorative','decoration')
    for row in ram['QH_rows']:
        assert len(row['literal_source_H_m'])==len(row['literal_source_Q_m3_h'])==8
        for j,subpath in enumerate(row['physical_subpaths']):
            segments=subpath['cubics_native'];path=[('m',[pagepoint(segments[0]['start'])])]
            for seg in segments:path.append(('c',[pagepoint(seg[k]) for k in ['control1','control2','end']]))
            add_path(path,'QH',row['model']+' '+str(j),[127,145,150],.90,
                     model=row['model'],subpath_kind=subpath['kind'],cycle=subpath.get('cycle'),
                     source_arc_start_pt=subpath['arc_start_pt'],source_arc_end_pt=subpath['arc_end_pt'])
    eta_path=[('m',[pagepoint(ram['eta_4C2_segments'][0]['start'])])]
    for seg in ram['eta_4C2_segments']:eta_path.append(('c',[pagepoint(seg[k]) for k in ['control1','control2','end']]))
    add_path(eta_path,'eta','ETA own558',[127,145,150],.90,source_numeric_eta_NO_TABLE=True)

    def contour_paths(data,left,top):
        output=[]
        for contour in data:
            segments=contour.get('cubic_segments_local_native')
            if segments:
                first=segments[0][0];output.append(('m',[pagepoint((left+first[0],top+first[1]))]))
                for segment in segments:output.append(('c',[pagepoint((left+x,top+y)) for x,y in segment[1:]]))
            else:
                points=[pagepoint((left+x,top+y)) for x,y in contour['local_native_xy']]
                output.append(('m',[points[0]]));output.extend(('l',[p]) for p in points[1:])
            output.append(('h',[]))
        return output
    def word(record,kind):
        baseline=record['native_baseline']
        for i,position in enumerate(record['glyph_positions']):
            char=position['character'];g=font[char];assert g['source_key']==position['source_key']
            paths=contour_paths(g['cleaned_contour_paths'],position['native_left'],baseline-9)
            add_path(paths,kind,record['model']+' '+str(i),[57,55,57],paint='f*',
                     model=record['model'],character=char,source_glyph_key=g['source_key'],
                     source_advance_native=g['native_advance'],source_glyph_report_sha256=sha(fontpath))
    for i,(row,suffix,legend) in enumerate(zip(ram['QH_rows'],ram['explicit13_suffixes'],ram['explicit13_full_name_legend'])):
        endpoint=row['native_real_tick_nodes'][-1];center=[suffix['native_left'],suffix['native_baseline']-4.5]
        line([(endpoint[0]+2.1,endpoint[1]),(center[0]-3,center[1])],[180,180,180],.30,row['model'],'leader')
        word(suffix,'model_suffix')
        left=legend['native_left'];baseline=legend['native_baseline']
        line([(left-14,baseline-4.5),(left-4,baseline-4.5)],[127,145,150],.90,row['model'],'legend_swatch')
        word(legend,'model_full_name')
    for axis in axisdoc['words']:
        if axis['key']=='TITLE':continue
        box=axis['source_native_box']
        paths=contour_paths(axis['contour_paths'],box[0],box[1])
        add_path(paths,'axis_literal',axis['key'],axis['source_RGB'],paint='f*',
                 literal_source_read=axis['literal_source_read'],source_native_box=box,
                 source_axis_report_sha256=sha(axispath))
    group.append(ins('Q'));ed.insert_instrs(7,len(page.ops),group)
    built=ed.build(7);parsed=VPage(parse(built))
    original_retained=[];position=0
    for instruction in original_ops:
        raw=instruction.raw
        if raw is None:continue
        found=built.find(raw,position);original_retained.append(found>=position)
        if found>=position:position=found+len(raw)
    assert all(original_retained) and ed.touched()==[7]
    assert np.max(abs(parsed.ctm_at(len(parsed.ops))-np.eye(3)))<1e-10
    report=dict(stage='CATFIX Editor.build in memory; NO PDF FILE WRITER CALLED',
        source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)),
        RAM_manifest_path=str(ram_path),RAM_manifest_sha256=sha(ram_path),
        font_report_path=str(fontpath),font_report_sha256=sha(fontpath),axis_report_path=str(axispath),axis_report_sha256=sha(axispath),
        source_native_edit_box=native_box,ROI_page_pt=roi,ROI_not_expanded=True,outer_clip_page_pt=outer,
        outer_clip_expansion_pt=2.,source_title_native_box=title['source_native_box'],source_title_island_page_pt=island,
        source_title_X7_CTMs_and_bytes_unchanged=True,source_X7_raw_sha256=hashlib.sha256(ed.doc.stream_raw(im.ref)).hexdigest(),
        source_title_preserved_native_not_retyped=True,old_native_backdrop_paints_below_X7_touching_ROI=behind,
        old_Do_complement_clips=clips,old_painted_path_complement_clips=oldpaths,
        original_instruction_bytes_retained_in_order=True,original_instruction_count=len(page.ops),
        current_native_images_and_SMask_unmodified=True,new_images_or_new_SMask_count=0,
        new_white_or_other_color_background_cover_count=0,new_normal_opaque_gs=state_name,
        only_page8_content_changed=True,new_objects=records,QH_models13_literal_nodes104=ram['numeric104_RAM_geometry_only'],
        source_eta558_only=ram['eta_4C2_segments'],actual_source_eta_values_UNKNOWN=True,
        prepared_content_sha256=hashlib.sha256(built).hexdigest(),prepared_content_length=len(built),
        clip_only_content_sha256=hashlib.sha256(clips_only).hexdigest(),
        filesystem_PDF_save_count=0,actual_PDF_file_readback_NOT_RUN=True,graphic_review_PENDING=True)
    return ed,R,cv,built,clips_only,report
