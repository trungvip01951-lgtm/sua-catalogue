"""Read every source-island edge and two-pixel exterior halo in true RAM.

All RGB differences are retained. Seed boxes only locate likely glyph ink;
they are never treated as an original font program or automatic acceptance.
"""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
import pymupdf as fitz
import json, hashlib
from g04_perotac_source9_left_halo_builder70 import prepare, memory_bytes, NAME
from g04_perotac_whole_pdf_tools46 import read, sha, pixel_at, page_at_pixel
from g04_perotac_whole_actual_read50 import render_document

base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'RAMV3 KIEM TOAN9 MEP VA HALO NGOAI2PIXEL CHI DOC'
expected_path=base/'RAM CATFIX NGUON9 DAO V3 GIU QUANG200 CHUA LUU PDF/CATFIX NGUON9 DAO RAM V3 DOC LAI MUC THAT VA NGOAI VUNG.json'
expected=read(expected_path)
old=read(base/'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF/CATFIX NGUON9 DAO RAM V2 DOC LAI MUC THAT VA NGOAI VUNG.json')
ed,R,cv,content,cliponly,report=prepare(S)
assert hashlib.sha256(content).hexdigest()==expected['prepared_content_sha256']
assert report['new_objects']==old['new_objects'], 'New glyph/QH/grid/eta path or style changed'
blob=memory_bytes(ed,content)
axis=read(report['axis_report_path']);words={w['key']:w for w in axis['words']}
records=[];tiles=[]
with fitz.open(S.src(NAME)) as source,fitz.open(S.result(NAME)) as current,fitz.open(stream=blob,filetype='pdf') as actual:
    for island in report['source_literal_islands_all']:
        key=island['key'];ib=island['source_native_box'];ob=island['source_literal_original_native_box']
        context=[ob[0]-2,ob[1]-2,ob[2]+2,ob[3]+2]
        a,m=render_document(source,7,600,list(cv.rect(context)))
        z,n=render_document(actual,7,600,list(cv.rect(context)))
        assert a.shape==z.shape and m==n
        yy,xx=np.indices(a.shape[:2]);points=np.array([cv.to_px(*page_at_pixel([x+.5,y+.5],m)) for y,x in zip(yy.ravel(),xx.ravel())]).reshape(a.shape[:2]+(2,))
        changed=np.any(a!=z,axis=2)
        inside=((points>=np.array(ib[:2]))&(points<=np.array(ib[2:]))).all(2)
        original_inside=((points>=np.array(ob[:2]))&(points<=np.array(ob[2:]))).all(2)
        # Use original word coordinates, never the extended clipping box, to
        # locate source contours. Whole two-pixel exterior is counted below.
        glyph_boxes=[];seed=np.zeros(changed.shape,bool)
        for p in words[key]['contour_paths']:
            if p['parent']>=0: continue
            path=np.asarray(p['local_native_xy'])+np.array(ob[:2])
            gb=np.r_[path.min(0),path.max(0)].tolist();glyph_boxes.append(gb)
            seed|=((points>=np.array(gb[:2])-1)&(points<=np.array(gb[2:])+1)).all(2)
        alpha=np.clip((255-a.mean(2))/200,0,1)
        sensitivity=[]
        for level in [.02,.05,.1,.2,.3]:
            fg=(alpha>=level)&seed
            sensitivity.append(dict(alpha_level=level,source_candidate_glyph_or_halo_count=int(fg.sum()),
                changed_candidate_glyph_or_halo=int((changed&fg).sum()),
                changed_candidate_glyph_or_halo_outside_original_box=int((changed&fg&~original_inside).sum()),
                changed_candidate_glyph_or_halo_outside_new_clip=int((changed&fg&~inside).sum()),
                original_font_or_background_identity_not_inferred_from_threshold=True))
        coords=[]
        for y,x in zip(*np.nonzero(changed)):
            coords.append(dict(pixel600=[int(x),int(y)],native_center=points[y,x].tolist(),
                source_RGB=a[y,x].tolist(),actual_RGB=z[y,x].tolist(),difference_RGB=(z[y,x].astype(int)-a[y,x].astype(int)).tolist(),
                inside_new_island=bool(inside[y,x]),inside_original_word_box=bool(original_inside[y,x]),
                within_source_contour_box_plus1px=bool(seed[y,x]),
                identity_requires_position_and_visual_readback=True))
        left=Image.fromarray(a).resize((a.shape[1]*4,a.shape[0]*4),Image.Resampling.NEAREST)
        right=Image.fromarray(z).resize(left.size,Image.Resampling.NEAREST)
        for raw in [left,right]:
            dr=ImageDraw.Draw(raw)
            pp=[pixel_at(cv.to_page(*q),m)*4 for q in [(ib[0],ib[1]),(ib[2],ib[3])]]
            dr.rectangle([*np.minimum(*pp),*np.maximum(*pp)],outline=(20,190,20),width=2)
            for row in coords:
                x,y=np.array(row['pixel600'])*4+2
                color=(220,20,20) if min(row['source_RGB'])<235 else (20,180,200)
                dr.rectangle([x-1,y-1,x+1,y+1],outline=color,width=1)
        tile=Image.new('RGB',(left.width*2+50,left.height+55),'white')
        ImageDraw.Draw(tile).text((8,6),key+' SOURCE / ACTUAL; all edges + full 2-native-pixel exterior; green=clip; red=dark change',fill='black')
        tile.paste(left,(0,35));tile.paste(right,(left.width+40,35))
        tile.save(fresh(root/(key+' NGUON ACTUAL TOAN MEP HALO2.png')));tiles.append(tile)
        records.append(dict(key=key,original_word_native_box=ob,new_clip_native_box=ib,
            entire_compared_native_box=context,exterior_halo_native_pixels=2,
            all_changed_pixels_count=int(changed.sum()),all_changed_source_dark_pixels_count=int((changed&(a.min(2)<235)).sum()),
            changed_pixels_inside_original_box=int((changed&original_inside).sum()),changed_pixels_outside_original_box=int((changed&~original_inside).sum()),
            source_contour_box_localization_only=glyph_boxes,source_candidate_halo_sensitivity=sensitivity,
            every_changed_pixel_native_coordinate_and_RGB=coords,
            full_caption_graphic_acceptance='ROOT AND GRAPHIC REVIEW PENDING',
            no_interior_pixel_exclusion=True,no_area_or_ideal_font_metric_PASS_claim=True))
        print('HALO',key,'ALL',int(changed.sum()),'CANDIDATE',[(p['alpha_level'],p['changed_candidate_glyph_or_halo']) for p in sensitivity],flush=True)
    region=list(cv.rect([80,670,790,732]))
    for dpi in [150,600]:
        a,_=render_document(source,7,dpi,region);b,_=render_document(current,7,dpi,region);z,_=render_document(actual,7,dpi,region)
        tile=Image.new('RGB',(a.shape[1],3*a.shape[0]+75),'white');dr=ImageDraw.Draw(tile)
        for i,(im,label) in enumerate([(a,'ORIGINAL SOURCE'),(b,'CURRENT HANDOFF'),(z,'ACTUAL RAM V3 SOURCE9 LEFT200 +0.5')]):
            dr.text((5,i*(a.shape[0]+25)+3),label,fill='black');tile.paste(Image.fromarray(im),(0,i*(a.shape[0]+25)+22))
        tile.save(fresh(root/(f'TOAN TRUC DUOI NGUON CURRENT RAMV3 {dpi}.png')))
atlas=Image.new('RGB',(max(t.width for t in tiles),sum(t.height+12 for t in tiles)),'white');y=0
for t in tiles: atlas.paste(t,(0,y));y+=t.height+12
atlas.save(fresh(root/'DAY DU9 MEP VA HALO2 NGUON ACTUAL RAMV3.png'))
doc=dict(stage='READ-ONLY ACTUAL RAM V3 FULL PERIMETER + 2-NATIVE-PIXEL EXTERIOR; NO PDF SAVE',
    source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)),
    actual_RAM_report_path=str(expected_path),actual_RAM_report_sha256=sha(expected_path),
    prepared_content_sha256=hashlib.sha256(content).hexdigest(),only_clip_change_H200_left_native_px=.5,
    all383_new_paths_styles_glyphs_QH104_eta_and_grid_unchanged=report['new_objects']==old['new_objects'],
    source_X7_bytes_CTM_unchanged=True,ROI_unchanged=report['ROI_page_pt']==old['ROI_page_pt'],
    fields=records,caption_acceptance_not_inferred_from_source_bytes_or_thresholds=True,
    historical_RAMV2_writer65_not_run_or_changed=True,saved_PDF_count=0,no_progress_written=True)
path=Path(fresh(root/'DAY DU9 MEP HALO2 VA PIXEL NGUON THAT RAMV3.json'))
path.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
print('REPORT',path,'SHA256',sha(path),flush=True)
ed.close()
