"""Read-only p8 glyph donor positions for design plan; no PDF sample."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'CHU NGUON ALPHA THU DO DOC V2.json').read_text(encoding='utf8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
source=plan['method']['source'];current=plan['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(source),sha(current)]
assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(source,backend='fitz');R=Raster(E);cv=R.render_canvas(7,d['source_rect'],dpi=600);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);core=(g<110)&(a.max(2)-a.min(2)<30)
picture=Image.new('RGB',(800,len(d['records'])*125),'white');dr=ImageDraw.Draw(picture);rec=[]
for i,z in enumerate(d['records']):
 x0,y0,x1,y1=z['source_render_rect'];pp=a[y0:y1].round().astype('uint8');good=core[y0:y1].sum(0)>=2;groups=[]
 for x in np.flatnonzero(good):
  if not groups or x-groups[-1][-1]>1:groups.append([])
  groups[-1].append(int(x))
 columns=[(v[0],v[-1],int(core[y0:y1,v].sum())) for v in groups]
 pic=Image.fromarray(pp).resize((pp.shape[1]*2,pp.shape[0]*2),Image.Resampling.NEAREST);picture.paste(pic,(120,i*125+24));dr.text((5,i*125+5),z['model'],fill='blue')
 for v in range(0,pp.shape[1],10):
  x=120+v*2;dr.line((x,i*125+21,x,i*125+27),fill=(180,0,180));dr.text((x-6,i*125+7),str(v),fill=(180,0,180))
 rec.append(dict(model=z['model'],candidate_character_column_groups=columns,source_render_rect=z['source_render_rect'],source_page_rect=z['source_page_rect']))
 print(z['model'],'native glyph columns600',columns,flush=True)
picture.save(fresh(root/'GLYPH NGUON VI TRI CHO SOI.png'))
Path(fresh(root/'GLYPH NGUON COT UNG VIEN.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=rec,status='CANDIDATE: chưa chốt từngkýtự, chưa dựngPDF; nhìnảnh nguồn đểkhóa, khôngcoi connectedcomponent làglyphđúng.'),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(source),sha(current)]
