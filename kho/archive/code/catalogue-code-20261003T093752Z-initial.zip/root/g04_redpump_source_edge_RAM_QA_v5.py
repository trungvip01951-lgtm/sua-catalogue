"""RAM V5 diagnostics/readback/three-fix handoff; no PDF save or progress write."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib,sys,numpy as np,cv2
import pymupdf as fitz
from scipy.ndimage import label,binary_erosion,distance_transform_edt
from scipy.spatial import cKDTree
sys.path.insert(0,str(HERE))
from g04_redpump_ram_builder import build_three_fix_RAM
from g04_source_glyph_source_edge_math import sample_path
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'));P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/(sys.argv[1] if len(sys.argv)>1 else 'CHU NHO BIEN NGUON KHONG EP MUC RAM V5')
geometry_name=sys.argv[2] if len(sys.argv)>2 else '12 GLYPH NHO BIEN MOT MAU RAM V2.json'
variant=sys.argv[3] if len(sys.argv)>3 else 'V5'
folder=F/'SO DO VA KE HOACH GOP3LOI';assert not folder.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json');a=J(M/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')
atlas=J(P/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json');layout=J(P/'13 HOP NHAN CUC BO TRANH DUONG LUOI V1.json')
v=J(F/geometry_name);holes=J(M/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json');eta=J(M/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')
R=J(F/'RENDER ACTUAL RAM'/('13 NHAN MOT MAU VA3LOI ACTUAL RAM.json' if variant=='V5' else 'DOC ACTUAL RAM '+variant+' 13 NHAN VA3LOI KHONG PDF.json'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
assert guards==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
E,placed,expected,qh=build_three_fix_RAM(b,a,atlas,layout,v,holes,eta);PR=E.page(7)
tag=next(i for i,z in enumerate(PR.ops) if z.op=='BMC' and list(map(str,z.operands))==['CfxRedpumpSmallSourceGlyphSingleCoreRAM2'])
objects=[(i,o) for i,o in enumerate(PR.objs) if o['i0']>tag and o['op']=='f*']
assert len(objects)==len(expected),(len(objects),len(expected))
actual=[]
for (oi,o),ex in zip(objects,expected):
    ap=PR.object_pagepath(oi);assert [x[0] for x in ap]==[x[0] for x in ex['path']]
    av=np.array([q for _,pts in ap for xy in pts for q in xy]);pv=np.array([q for _,pts in ex['path'] for xy in pts for q in xy])
    er=float(abs(av-pv).max());assert er<2e-7
    actual.append(dict(model=ex['model'],character=ex['character'],source_part=ex['source_part'],actual_RAM_object_index=oi,
        actual_path=ap,actual_geometry_error_pt=er,fill_rule='f*',operator=o['op']))
draw=E.doc.doc[7].get_drawings();colored=[z for z in draw if z['fill'] is not None and np.max(abs(np.array(z['fill'])-v['core_gray']/255))<1/255]
assert len(colored)==len(expected);assert all(abs(z['fill_opacity']-1)<1e-10 for z in colored)
assert not E.doc.doc[7].get_fonts(full=True)

def render(bb,dpi):
    pg=E.doc.doc[7];T=pg.transformation_matrix;p0=fitz.Point(bb[0],bb[1])*T;p1=fitz.Point(bb[2],bb[3])*T
    clip=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y))
    px=pg.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=clip,colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(px.samples,dtype=np.uint8).reshape(px.height,px.width,px.n)[:,:,:3].copy()

# Font physical shape diagnostics use the *actual RAM path*, including all true
# disconnected source parts. Source weak alpha and source half-core are separate.
glyphs=[];VM={q['character']:q for q in v['records']}
for ch,z in VM.items():
    aa=np.asarray(z['source_alpha']);pad=8;up=8;src=np.pad(aa,pad);h,w=src.shape
    # Intrinsic loops are readback-equivalent to the actual RAM objects above.
    polys=[np.rint((sample_path(lp['path'],64)+pad)*up).astype('int32') for pt in z['parts'] for lp in pt['loops']]
    vec=np.zeros((h*up,w*up),'uint8');cv2.fillPoly(vec,polys,1);vec=vec>0
    low=cv2.resize((src>=.085).astype('uint8'),(w*up,h*up),interpolation=cv2.INTER_NEAREST).astype(bool)
    parts,n=label(src>=.085);half=np.zeros_like(src,bool)
    for k in range(1,n+1):
        mask=parts==k;peak=float(src[mask].max());half|=mask&(src>=.5*peak)
    half=cv2.resize(half.astype('uint8'),(w*up,h*up),interpolation=cv2.INTER_NEAREST).astype(bool)
    lv=distance_transform_edt(~vec)/up;ld=distance_transform_edt(~low)/up
    vb=vec&~binary_erosion(vec);hb=half&~binary_erosion(half)
    vh=distance_transform_edt(~hb)/up;hv=distance_transform_edt(~vb)/up
    yy,xx=np.where(low);sb=np.array([xx.min()/up-pad,yy.min()/up-pad,(xx.max()+1)/up-pad,(yy.max()+1)/up-pad])
    yy,xx=np.where(vec);nb=np.array([xx.min()/up-pad,yy.min()/up-pad,(xx.max()+1)/up-pad,(yy.max()+1)/up-pad])
    fit=[p.get('max_contour_fit_error_px600') for p in z['parts'] if p.get('max_contour_fit_error_px600') is not None]
    forward=float(ld[vec].max()*.12);missing=float(lv[low].max()*.12)
    bound=max(float(vh[vb].max()),float(hv[hb].max()))*.12
    glyphs.append(dict(character=ch,source_page=z['source_page'],source_word=z['source_word'],source_page_box=z['source_page_box'],
        source_weak_ink_bbox_pt=(sb*.12).tolist(),vector_bbox_pt=(nb*.12).tolist(),bbox_edge_difference_pt=((nb-sb)*.12).tolist(),
        scale=1.,source_gray_fill=[63]*3,common_opacity=1.,curves=sum(sum(op=='c' for op,_ in lp['path']) for p in z['parts'] for lp in p['loops']),
        line_segments=sum(sum(op=='l' for op,_ in lp['path']) for p in z['parts'] for lp in p['loops']),
        source_components=n,source_expected_topology=z['expected_topology'],actual_vector_parts=len(z['parts']),
        source_area_pt2=float(aa.sum()*.12**2),vector_area_pt2=z['vector_optical_area_px']*.12**2,
        optical_mass_difference=float(z['vector_optical_area_px']/z['source_area_px']-1),
        max_cubic_fit_to_selected_source_contour_pt=max(fit)*.12 if fit else None,
        vector_ink_outside_weak_source_max_distance_pt=forward,source_weak_ink_missing_max_distance_pt=missing,
        source_halfcore_boundary_bidirectional_Hausdorff_pt=bound,source_native_pixel_uncertainty_pt=.4801362852213916,
        halfcore_comparison_limit_note='Mốc nửa độ phủ của JPEG là chẩn đoán riêng, không phải đường biên CAD gốc chắc chắn.',
        shape_status='CHƯA CHỐT riêng dáng/đậm 5/9, cần ROOT/đồ họa đọc.' if ch in '59' else 'ỨNG VIÊN, chưa nghiệm thu phông gốc chính xác.'))

# Read distances from actual RAM font edges to actual accepted QH paths; no
# numeric H anchors are recalculated. Full centreline is conservative at dashes.
curvepoints=[];maxstep=0.
for m in a['actual_QH_paths']:
    for part in m['parts']:
        pp=sample_path(part['path'],4097)
        maxstep=max(maxstep,float(np.linalg.norm(np.diff(pp,axis=0),axis=1).max()));curvepoints.append(pp)
tree=cKDTree(np.vstack(curvepoints));clearance=[]
for pl in placed:
    names=[o for o in actual if o['model']==pl['model']];pts=np.vstack([sample_path(o['actual_path'],129) for o in names]);bb=np.array(pl['physical_box'])
    outside=(pts[:,0]<bb[0])|(pts[:,0]>bb[2])|(pts[:,1]<bb[1])|(pts[:,1]>bb[3])
    clipped=pts[~outside];d=float(tree.query(clipped)[0].min())-.95/2-maxstep/2
    gd=[]
    for x in layout['vertical_grid_page_x_used']:gd.append(float(abs(clipped[:,0]-x).min())-.65/2)
    for y in layout['horizontal_grid_page_y_used']:gd.append(float(abs(clipped[:,1]-y).min())-.65/2)
    clearance.append(dict(model=pl['model'],actual_font_path_samples=len(pts),samples_clipped_to_approved_word_box=int(outside.sum()),
        approved_word_box=bb.tolist(),QH_ink_clearance_lower_bound_pt=d,grid_ink_clearance_pt=min(gd),
        curve_sampling_halfstep_bound_pt=maxstep/2,QH_all_26_paths_unchanged=True,not_H_numeric_test=True))

wordmetrics=[]
for model in [r['model'] for r in placed]:
    tests=[z for z in R['actual_RAM_metrics'] if z['model']==model]
    t=next(z for z in tests if z['dpi']==600);old=np.array(t['old_RGB']);new=np.array(t['new_RGB'])
    boxes=[]
    for img in [old,new]:
        al=(255-img.astype(float).mean(2))/255;yy,xx=np.where(al>.085);boxes.append([int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)])
    delta=(np.array(boxes[1])-boxes[0])*.12
    wordmetrics.append(dict(model=model,actual_render600_source_bbox_px=boxes[0],actual_render600_new_bbox_px=boxes[1],bbox_edges_delta_pt=delta.tolist(),
        unchanged_advance_and_scale=True,source_nominal_font_name_unavailable=True,
        actual_optical_integral=[dict(dpi=q['dpi'],source_area_pt2=q['source_area_pt2'],new_area_pt2=q['new_area_pt2'],relative_delta=q.get('relative_actual_ink_error',q.get('relative_optical_delta'))) for q in tests],
        dpi_sensitivity_range=float(max(q.get('relative_actual_ink_error',q.get('relative_optical_delta')) for q in tests)-min(q.get('relative_actual_ink_error',q.get('relative_optical_delta')) for q in tests)),
        glyph5_9_specific_unknown=model in ['4SL16/25','4SL16/5','4SL16/9'],visual_acceptance='CHƯA CHỐT: ảnh150/600 cần ROOT/đồ họa đọc.'))

protected=[]
for dpi in [150,200,600]:
    for i,r in enumerate(holes['records']):
        bb=r['source_original_restore_bbox'];s=np.asarray(verify.crop(b['source'],7,bb,dpi));z=render(bb,dpi)
        assert s.shape==z.shape;changed=int(np.any(s!=z,axis=2).sum());assert changed==0
        protected.append(dict(feet_index=i+1,dpi=dpi,source_whole_box_pixels=s.shape[0]*s.shape[1],changed_pixels=changed,full_source_box=bb))
    # Source title hole contains genuine glyph and frame; keep full original box.
    bb=b['protected_title_hole'];s=np.asarray(verify.crop(b['sample'],7,bb,dpi));z=render(bb,dpi)
    assert s.shape==z.shape;changed=int(np.any(s!=z,axis=2).sum());assert changed==0
    protected.append(dict(name='M1 protected title full hole',dpi=dpi,changed_pixels=changed,whole_box=bb))

with fitz.open(b['sample']) as olddoc:
    assert olddoc.metadata==E.doc.doc.metadata
    xo=olddoc.xref_xml_metadata();xn=E.doc.doc.xref_xml_metadata();assert xo==xn
    if xo:assert olddoc.xref_stream_raw(xo)==E.doc.doc.xref_stream_raw(xn)
    contents=[]
    for pi in range(len(olddoc)):
        if pi==7:continue
        ids0=olddoc[pi].get_contents();ids1=E.doc.doc[pi].get_contents();assert ids0==ids1
        assert [olddoc.xref_stream_raw(x) for x in ids0]==[E.doc.doc.xref_stream_raw(x) for x in ids1]
        contents.append(pi+1)
    # All old image resource raw/mask streams survive; only13 old donor paint
    # operators are deactivated, to prevent old soft edges showing underneath.
    images=[]
    for pi in range(len(olddoc)):
        for im in olddoc[pi].get_images(full=True):
            xref,sm=im[:2];assert olddoc.xref_stream_raw(xref)==E.doc.doc.xref_stream_raw(xref)
            if sm:assert olddoc.xref_stream_raw(sm)==E.doc.doc.xref_stream_raw(sm)
            images.append(dict(page=pi+1,xref=xref,SMask_xref=sm,raw_stream_unchanged=True))

out=dict(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],M1=b['sample'],M1_SHA256=guards[2],
    RAM_geometry_data=str(F/geometry_name),RAM_images=R['images'],actual_font_paths=actual,
    actual_font_fill_RGB=[63]*3,actual_PDF_fill_normalized=list(colored[0]['fill']),actual_font_opacity=1.,actual_font_objects=len(actual),font_resources=0,
    glyph_boundary_mass_size=glyphs,word_size_and_mass_dpi=wordmetrics,actual_ink_clearance=clearance,
    QH_fingerprints_26_unchanged=qh,QH_104_not_remeasured=True,QH_104_status='ĐẠT từ M1 được ROOT nghiệm thu, path giữ nguyên.',
    feet15_tests=protected,other10page_contents_unchanged=contents,all_old_image_resources_raw_masks_unchanged=images,
    metadata_info_and_raw_XMP_unchanged=True,three_fix_plan=dict(eta='HaiBézierC2 ROOT chấp nhận, đúngđầu/cuối/đỉnhtrong1pixel; η sốUNKNOWN.',
        feet='5hộp +0,48pt đúnggiao miền;15crop nguồn0pixel, giữ khung/vạch thật.',
        text='Biên glyph nguồn riêng '+variant+', ít Bézier/đoạn, một màu63/opacity1/scale1/advance giữ; không32dải, không font ngoài; không ép quỹ mực.',
        readiness='CHƯA PDF2: phông/đậm/dáng5/9 cần ROOT/đồ họa đọc đủ13 tên. BiênAA/JPEG có điểm vượt1pixel nên không khẳng định biênCAD chính xác.'),
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False,
    status='RAM đủ13tên và hồ sơ, không gọi hìnhthức/phôngĐẠT nếu chưa được đọc độc lập.')
jsonfile=fresh(folder/('NGHIEM THU RAM '+variant+' CHU BIEN CO KHOANG HO VA3LOI.json'));Path(jsonfile).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert guards==[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
print('ACTUAL RAM fontobjects',len(actual),'curvegap',min(r['QH_ink_clearance_lower_bound_pt'] for r in clearance),'gridgap',min(r['grid_ink_clearance_pt'] for r in clearance),flush=True)
print('glyph source missing',[(r['character'],round(r['source_weak_ink_missing_max_distance_pt'],4),round(r['source_halfcore_boundary_bidirectional_Hausdorff_pt'],4)) for r in glyphs],flush=True)
print(jsonfile,flush=True)
