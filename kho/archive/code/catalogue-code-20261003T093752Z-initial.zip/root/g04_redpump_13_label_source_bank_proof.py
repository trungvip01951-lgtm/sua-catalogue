"""Source glyph assembly proof only; no graph or PDF sample."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));bankjson=json.loads((root/'GLYPH HOAN CHINH HOP NGUON THU CONG.json').read_text(encoding='utf8'));bank={p['character']:p for p in bankjson['records']};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(plan['method']['source']),sha(plan['method']['input_current'])];assert before==[bankjson['source_SHA256'],bankjson['current_SHA256']]
advance={ch:24 for ch in '0123456789'};advance.update({'S':32,'L':24,'/':12})
bear={'4':-1,'S':1,'L':-1,'6':1,'3':0,'/':5,'2':0,'5':1,'0':-4,'8':-4,'9':-1,'1':4}
baseline={'4':37,'S':37,'L':37,'6':37,'3':37,'/':37,'2':37,'5':36,'0':35,'8':33,'9':34,'1':36}
names=[p['model'] for p in reversed(plan['page8_QH_models'])]
pic=Image.new('RGB',(760,len(names)*90),'white');dr=ImageDraw.Draw(pic);records=[]
for i,name in enumerate(names):
 width=sum(advance[ch] for ch in name)+12;alpha=np.zeros((52,width),float);x=6;glyphs=[]
 for ch in name:
  a=np.array(bank[ch]['source_alpha']);h,w=a.shape;y=43-baseline[ch];u=x+bear[ch];alpha[y:y+h,u:u+w]=np.maximum(alpha[y:y+h,u:u+w],a);glyphs.append(dict(character=ch,source_word=bank[ch]['source_word'],source_page=bank[ch]['source_page'],origin_source_pixel_units=[u,y],physical_scale=1.));x+=advance[ch]
 ys,xs=np.nonzero(alpha>.01);inkbox=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]
 word=Image.fromarray((255*(1-alpha)).round().clip(0,255).astype('uint8')).convert('RGB');dr.text((5,i*90+7),name,fill='blue');pic.paste(word,(190,i*90+12));pic.paste(word.resize((word.width*2,word.height*2),Image.Resampling.NEAREST),(420,i*90+3))
 records.append(dict(model=name,assembled_alpha_source_only=alpha.tolist(),glyphs=glyphs,inkbox600=inkbox,physical_ink_box_size_pt=[(inkbox[2]-inkbox[0])*72/600,(inkbox[3]-inkbox[1])*72/600],character_count=len(name),same_bank=True,source_scale=1.,font_new=False,PDF_written=False))
photo=fresh(root/'13 NHAN GHEP CHU THAT CUNG BO KHONG LA MAU PDF.png');pic.save(photo)
Path(fresh(root/'13 NHAN GHEP CHU THAT CUNG BO NGUON.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=records,source_bank=str(root/'GLYPH HOAN CHINH HOP NGUON THU CONG.json'),advance600=advance,bearing600=bear,source_baseline600=baseline,proof_photo=photo,physical_scale=1.,PDF_sample_written=False,needs_read_every_character=True,status='NGHIÊN CỨU: ghép13tên từmộtbankglyphsource; chưa vẽPDF hoặcchốtnghiệmthu độsắc.'),ensure_ascii=False,indent=2),encoding='utf8')
assert before==[sha(plan['method']['source']),sha(plan['method']['input_current'])]
print('13source-glyph names assembly only; widths/heights',[(p['model'],p['physical_ink_box_size_pt']) for p in records],flush=True)
