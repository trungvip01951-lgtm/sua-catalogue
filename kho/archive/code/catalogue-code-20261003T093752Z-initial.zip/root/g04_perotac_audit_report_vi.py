from catwork import start,fresh
S,D,N=start()
from pathlib import Path
root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
txt=(root/'KIEM TOAN CUOI DE ROOT DOC.md').read_text(encoding='utf8')
txt=txt.replace('dòng model','mã máy').replace('Model','Mã máy').replace('model','mã máy').replace('ROOT','tác nhân chính').replace('lệch nominal','độ lệch theo tâm nét').replace('tâm nominal','tâm nét')
txt=txt.replace('giữ nguyên mã SHA256','giữ nguyên mã kiểm tra nội dung SHA256')
txt+='\nThuật ngữ trong hồ sơ: PDF là dạng tài liệu theo trang; JPEG là dạng ảnh nén; dpi là số điểm ảnh trên một inch (2,54 cm); SHA256 là mã kiểm tra nội dung tệp; CSV là bảng dữ liệu dạng văn bản. Trên ảnh so sánh, SOURCE/S là nguồn, RESULT/R là bản đang giao.\n'
Path(fresh(root/'KIEM TOAN CUOI TIENG VIET.md')).write_text(txt,encoding='utf8')
print('Vietnamese report saved. No PDF or shared progress changed.',flush=True)
