"""Own Redpump observed head dash lengths, using grey-core presence, no table-H branch choice."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import binary_opening,binary_closing
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
trace=json.loads(Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO/4SL16_25 SO DO NGUON VA BAN GIAO.json')).read_text(encoding='utf8'))
d=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=d['method']['source'];cur=d['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['method']['source_SHA256'],d['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float);gray=a@np.array([.299,.587,.114]);pts=np.array([[z['u'],z['v']] for z in trace['raw_observed_trace']]);us=np.arange(max(int(pts[0,0]),132),268);vs=np.interp(us,pts[:,0],pts[:,1]);xy=np.array([cv.to_page(u,v) for u,v in zip(us,vs)]);ss=np.r_[0.,np.cumsum(np.sqrt((np.diff(xy,axis=0)**2).sum(1)))];xyrange=[xy[0].tolist(),xy[-1].tolist()]
def intervals(on):
 out=[];start=0
 for i in range(1,len(on)+1):
  if i==len(on) or on[i]!=on[start]:
   # Actual cell edges between observed centers define finite dash uncertainty.
   l=ss[start]-(ss[start+1]-ss[start])*.5 if start else 0.;h=ss[i-1]+(ss[i-1]-ss[i-2])*.5 if i<len(on) and i>1 else float(ss[-1]);out.append(dict(ink=bool(on[start]),native_u_first=int(us[start]),native_u_last=int(us[i-1]),arc_length_pt=float(h-l),truncated=start==0 or i==len(on)));start=i
 return out
measure=[]
for threshold in [195,205,215]:
 on=np.array([bool((gray[int(round(v))-3:int(round(v))+4,u]<threshold).any()) for u,v in zip(us,vs)])
 # Same-source grey pulse; 1px chroma dropouts are not actual dash gaps.
 on=binary_opening(binary_closing(on,structure=np.ones(3)),structure=np.ones(3));ivs=intervals(on)
 vals={k:[z['arc_length_pt'] for z in ivs if not z['truncated'] and z['ink']==(k=='dash')] for k in ['dash','gap']}
 measure.append(dict(core_gray_threshold=threshold,intervals=ivs,complete_dash_count=len(vals['dash']),complete_gap_count=len(vals['gap']),median_dash_pt=float(np.median(vals['dash'])),median_gap_pt=float(np.median(vals['gap'])),dash_minmax_pt=[float(min(vals['dash'])),float(max(vals['dash']))],gap_minmax_pt=[float(min(vals['gap'])),float(max(vals['gap']))]))
 print('threshold',threshold,'dash/gap',measure[-1]['median_dash_pt'],measure[-1]['median_gap_pt'],'runs',len(ivs),flush=True)
pic=Image.fromarray(cv.orig);dr=ImageDraw.Draw(pic)
for u,v in zip(us,vs):dr.ellipse((u-1,v-1,u+1,v+1),fill=(180,0,180))
photo=fresh(root/'NET DUT NGUON25 VUNG THUC KHONG LA MAU.png');pic.crop((124,179,280,228)).resize((1560,490),Image.Resampling.NEAREST).save(photo)
chosen=next(p for p in measure if p['core_gray_threshold']==205)
out=dict(source=src,source_SHA256=before[0],current_SHA256=before[1],model='4SL16/25',source_actual_trace=str(S.report('G04/KIEM TOAN REDPUMP TOAN BO/4SL16_25 SO DO NGUON VA BAN GIAO.json')),source_native_roi=[int(us[0]),int(vs.min()-3),int(us[-1]),int(vs.max()+4)],source_page_endpoints=xyrange,measurements=measure,proposed_uniform_dash_pt=round(chosen['median_dash_pt'],2),proposed_uniform_gap_pt=round(chosen['median_gap_pt'],2),proposed_phase_pt=0.,proposed_Q_transition=6.,phase_rule='Chu kỳ áp theo chiều dài cung từQ0, cùngphase0; nềnmới/dườngmới nguyênkhối, không nối các intervalraster cũ.',source_measure_uncertainty_pt=.48,uncertainty_basis='Nửa pixel nguồn mỗi mép x2≈0,48pt; các dash hơi dốc dùng arclength qua tâm mực đã quan sát. Không gọi thông sốCADgốc đã biết.',source_proof_photo=photo,needs_ROOT_and_graphic_review=True,PDF_sample_written=False)
Path(fresh(root/'NET DUT NGUON REDPUMP KHOA SO DE XUAT.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)]
