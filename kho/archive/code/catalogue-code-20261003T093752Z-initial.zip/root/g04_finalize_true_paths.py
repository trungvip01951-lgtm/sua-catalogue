"""Luu hai duong G04 da duoc ROOT doc actual16moc va soi mau2."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,datetime,numpy as np
from catfix.vector import Editor
from catfix import verify
import pymupdf as fitz
root=Path(S.report('G04'));m=root/'NET PDF THAT MAU2'
build=json.loads((m/'TAO VA KIEM MAU.json').read_text(encoding='utf8'))
read=json.loads((m/'DOC LAI ACTUAL PDF.json').read_text(encoding='utf8'))
old=json.loads((root/'DO DIEM 4SA16 Q21.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
name='Perotac bơm giếng SA_compressed (bản mới).pdf';source=S.src(name);prev=Path(S.result(name)).resolve();trial=build['trial']
assert sha(source)==build['source_sha'] and sha(prev)==build['current_sha']==read['current_sha'] and sha(trial)==build['trial_sha']==read['trial_sha']
assert read['point_count']==16 and all(z['result']=='ĐẠT' for z in read['points']) and read['outside']=={} and all(read['metadata'].values())
assert read['font_foreground']['black_source_font_pixels']==9234 and read['font_foreground']['changed_pixels']==0
assert max(z['error_pt'] for z in read['endpoints'])<1e-4
outroot=Path(S.out_dir).resolve();arc=Path(S.report('G04/PHIEN TRUOC NET PDF THAT/'+build['current_sha']+'/'+name)).resolve()
assert prev.is_relative_to(outroot) and arc.is_relative_to(outroot) and prev!=Path(source).resolve() and not arc.exists()
arc.parent.mkdir(parents=True,exist_ok=True);prev.rename(arc)
E=Editor(trial,backend='fitz');E.save(fresh(prev));E.close()
assert sha(source)==build['source_sha'] and sha(arc)==build['current_sha']
structure=verify.structure_check(trial,str(prev));assert structure['ok']
outside=verify.outside_pixels(trial,str(prev),{},dpi=200,thr=0,min_size=0,pad=0);assert not outside
with fitz.open(trial) as a,fitz.open(prev) as b:
 assert a.metadata==b.metadata and a.get_xml_metadata()==b.get_xml_metadata() and a.get_toc()==b.get_toc()
 assert [tuple(p.rect) for p in a]==[tuple(p.rect) for p in b]
 for p,q in zip(a,b):
  assert p.read_contents()==q.read_contents()
  la=[{k:str(v) for k,v in z.items() if k!='xref'} for z in p.get_links()];lb=[{k:str(v) for k,v in z.items() if k!='xref'} for z in q.get_links()];assert la==lb
receipt=dict(time=datetime.datetime.now().astimezone().isoformat(),group='G04',final=str(prev),final_sha=sha(prev),source=source,source_sha=sha(source),archive=str(arc),previous_sha=sha(arc),accepted_sample=trial,accepted_sample_sha=sha(trial),actual_readback=read,final_structure=structure,final_matches_accepted_sample_every_pixel=True,page_content_streams_and_metadata_exact_to_sample=True,visual_root='Mau2 da soi450dpi, mau/do day theo muc nguon, 9234pixelchu nguon giunguyen; 2path smooth/same-model/khongbongchu.',accepted=True,status='14/14 CAN_SUA ĐẠT; bổ sung2đường16mốc ĐẠT. Chưa nghiệm thu toàn bộ các đường còn lại của hai catalogue.')
Path(fresh(root/'NGHIEM THU BAN CUOI NET PDF THAT.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# BÁO CÁO NHÓM G04 – Perotac SA + Redpump SL, bổ sung đường đặc tính','', '**14/14 việc trong danh sách đã ĐẠT. Bổ sung: 2 đường Perotac 4SA16 đạt 16/16 mốc bảng; các đường khác chưa được nghiệm thu toàn bộ.**','', '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|']
for z in old['records']:
 pts=[p for p in read['points'] if p['model']==z['model']];end=next(p for p in pts if p['Q']==21)
 lines.append(f"| Phát hiện thêm – đã được anh cho phép sửa | {name} | 8 – {z['model']} | Q21: H{z['H_curve_m']:.4f}m, bảng {z['H_table_m']}m | Q21: H{end['H_actual']:.5f}m; đủ8mốc bảng | Tách riêng mực2nét ảnh gốc; dựng nét PDF theo bảng bằng catfix, giữ nhãn/lưới/nét khác | ĐẠT8/8mốc | G04/NET PDF THAT MAU2/TRUOC SAU.png;16 MOC ACTUAL PDF.csv;NGHIEM THU BAN CUOI NET PDF THAT.json |")
lines+=['','Tổng bổ sung:2đường · ĐẠT2 · CHƯA ĐẠT0 · CHƯA THỂ XÁC MINH0 trong đúng16mốc được sửa. Kết quả14/14 việc mã# giữ theo BAO CAO G04.md trước.','',f"Đọc lại chính đối tượng đường trong PDF đã lưu: sai số cột áp lớn nhất {max(abs(p['error']) for p in read['points']):.8f}m; sai số vị trí điểm đầu/cuối lớn nhất {max(p['error_pt'] for p in read['endpoints']):.8f}điểm in. Miền bảng Q0–21m³/h giữ đúng đầu/cuối. Đoạn nét đứt ở đầu đường được giữ theo các khoảng sáng/tối đo trực tiếp trên ảnh nguồn.",'','Màu và độ rộng lấy từ mực nét nguồn, có độ bất định do ảnh gốc150điểm ảnh/inch; không tuyên bố có thông số bút nét nguyên thủy vì nguồn là ảnh. Mẫu1 của phương pháp nét PDF bị loại do quá nhạt/mỏng; mẫu2 đã qua xem ảnh và đọc lại số. Hai phương pháp ảnh cũ đã dừng sau hai mẫu không đạt mỗi phương pháp.','', 'Kiểm chữ độc lập:9234điểm ảnh chữ nguồn trong dải nhãn giữ nguyên, 0điểm đổi. Ngoài biểu đồ trang8 không có thay đổi ở200điểm ảnh/inch, ngưỡng màu0 và cỡ nhỏ nhất0. Siêu dữ liệu, liên kết, dấu trang, số trang và khổ trang giữ nguyên. Bản cuối khớp mẫu đã duyệt từng điểm ảnh; nguồn không đổi.','', 'Cần anh quyết: chưa có quyết định mới. Phát hiện thêm: toàn bộ các đường khác của Perotac SA và Redpump SL chưa đo đủ, không gộp thành nghiệm thu toàn bộ.','', f'Tệp hiện hành: {prev}', f'Mã kiểm nội dung SHA-256: {sha(prev)}',f'Bản trước do phiên này tạo giữ tại: {arc}','','Giải thích: PDF là định dạng tài liệu; catfix là bộ công cụ được giao; Q là lưu lượng, H là cột áp; điểm in là1/72inch; SHA-256 là mã kiểm nội dung.','']
Path(fresh(S.report('BAO CAO G04 BO SUNG NET PDF.md'))).write_text('\n'.join(lines),encoding='utf8')
Path(fresh(S.report('BAO CAO G04 BO SUNG NET PDF.json'))).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
S.progress('G04','CHƯA XONG','14/14 CAN_SUA ĐẠT và bổ sung2đường4SA16/23,/18 đạt16/16mốc; ROOT đọc actualPDF,9234pixelchữ không đổi, ngoài vùng/metadata/đầu-cuối đạt; bản cuối cập nhật qua catfix. Còn các đường khác chưa đo hết; báo cáo BAO CAO G04 BO SUNG NET PDF.md.')
print('G04 final',str(prev),'SHA',sha(prev),'16/16 actual anchors PASS; full curves not accepted',flush=True)
