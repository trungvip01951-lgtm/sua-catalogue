"""Only read RAM whole captions, every edge and original curve fragments."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import sys,json,hashlib,numpy as np
import pymupdf as fitz
from PIL import Image,ImageDraw
from scipy import ndimage
from catfix.vector import Editor
sys.path.insert(0,str(HERE))
from g04_redpump_whole_caption_island_RAM_builder import build_caption_islands_RAM

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'));P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/'13 CAPTION NGUYEN NGUON DAO RAM LAN2B';O=F/'SOI NET CHAM VA TAT CA MEP LAN1';assert not O.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json');a=J(M/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')
prior=J(F/'CATFIX13 CAPTION DAO NGUYEN NGUON DOC RAM FULL MEP.json')
holes=J(M/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json');eta=J(M/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
E,report,content=build_caption_islands_RAM(b,a,prior['islands'],holes,eta)
assert hashlib.sha256(content).hexdigest()==prior['content_SHA256']
PR=E.page(7)

def render(doc,rect,dpi):
    pg=doc[7];T=pg.transformation_matrix;points=[fitz.Point(rect[0],rect[1])*T,fitz.Point(rect[2],rect[3])*T]
    rr=fitz.Rect(min(p.x for p in points),min(p.y for p in points),max(p.x for p in points),max(p.y for p in points));z=dpi/72
    px=pg.get_pixmap(matrix=fitz.Matrix(z,z),clip=rr,colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(px.samples,np.uint8).reshape(px.height,px.width,px.n)[:,:,:3].copy(),[px.x,px.y],T*fitz.Matrix(z,z)

def sampled_path(path,step=.03):
    pts=[];tans=[];pos=None
    for op,pp in path:
        if op=='m':pos=np.asarray(pp[0],float)
        elif op=='c':
            c=np.vstack([pos,np.asarray(pp,float)]);steps=max(8,int(np.sum(np.linalg.norm(np.diff(c,axis=0),axis=1))/step));tt=np.linspace(0,1,steps)[:,None]
            p=(1-tt)**3*c[0]+3*(1-tt)**2*tt*c[1]+3*(1-tt)*tt**2*c[2]+tt**3*c[3]
            d=3*(1-tt)**2*(c[1]-c[0])+6*(1-tt)*tt*(c[2]-c[1])+3*tt**2*(c[3]-c[2]);pts.append(p);tans.append(d);pos=c[-1]
    return np.concatenate(pts),np.concatenate(tans)

paths=[]
for r in report['QH26_geometry_kept']:
    oi=r['RAM_actual_object'];o=PR.objs[oi];p=PR.object_pagepath(oi);pts,tans=sampled_path(p)
    paths.append(dict(model=r['model'],object=oi,points=pts,tangents=tans,width=o['lw'],RGB=PR.color_of(oi,'stroke'),fingerprint=r['full_path_fingerprint_SHA256']))

def hits(box,points,pad=0):
    x0,y0,x1,y1=box
    return (points[:,0]>=x0-pad)&(points[:,0]<=x1+pad)&(points[:,1]>=y0-pad)&(points[:,1]<=y1+pad)

records=[];full_tiles=[];five_tiles=[]
focus=['4SL16/23','4SL16/11','4SL16/8','4SL16/5','4SL16/4']
with fitz.open(b['source']) as source,fitz.open(b['input_current']) as current:
    for item in prior['islands']:
        name=item['model'];stem=name.replace('/','_');bb=item['island_page_bbox'];edge_reads=[]
        for dpi in [150,600]:
            old,origin,T=render(source,bb,dpi);new,origin2,T2=render(E.doc.doc,bb,dpi);assert old.shape==new.shape and origin==origin2 and tuple(T)==tuple(T2)
            changed=np.any(old!=new,axis=2);gray=old.astype(float)@np.array([.299,.587,.114]);neutral=old.max(2).astype(int)-old.min(2).astype(int)<35
            yy,xx=np.where(changed);sample=[]
            for y,x in zip(yy,xx):
                pt=fitz.Point(origin[0]+int(x)+.5,origin[1]+int(y)+.5)*~T
                edge_distance=min(pt.x-bb[0],bb[2]-pt.x,pt.y-bb[1],bb[3]-pt.y)
                sample.append(dict(pixel=[int(x),int(y)],PDF_pixel_center=[pt.x,pt.y],edge_distance_pt=float(edge_distance),
                    source_RGB=old[y,x].tolist(),RAM_RGB=new[y,x].tolist(),source_gray=float(gray[y,x]),source_neutral=bool(neutral[y,x])))
            show=Image.fromarray(old.copy());arr=np.array(show);arr[changed]=[255,0,180];show=Image.fromarray(arr)
            sheet=Image.new('RGB',(1650,340),'white');dr=ImageDraw.Draw(sheet);dr.text((2,4),name+f' full {dpi} dpi: SOURCE / RAM / all changed pixels (pink), NO omitted edge',fill='blue')
            scale=5 if dpi==150 else 2
            for i,ar in enumerate([Image.fromarray(old),Image.fromarray(new),show]):sheet.paste(ar.resize((ar.width*scale,ar.height*scale),Image.Resampling.NEAREST),(i*550+5,45))
            sheet.save(fresh(O/(stem+f' ALL MEP {dpi} VA DIEM DOI.png')))
            edge_reads.append(dict(dpi=dpi,all_crop_pixels_checked=int(changed.size),changed_pixels=int(changed.sum()),omitted_pixels=0,
                source_dark100_neutral35_changed=int((changed&(gray<100)&neutral).sum()),
                source_dark160_neutral35_changed=int((changed&(gray<160)&neutral).sum()),
                changed_pixel_list=sample,
                min_changed_source_gray=None if not len(xx) else float(gray[yy,xx].min()),
                max_changed_center_depth_inside_island_pt=None if not sample else max(z['edge_distance_pt'] for z in sample)))
        source600,origin,T=render(source,bb,600);rgb=source600.astype(float);g=rgb@np.array([.299,.587,.114])
        # Diagnostics only. Source JPEG cyan fringes can false-positive; never
        # erase them or count them as a font program or accepted hydraulic curve.
        color=(rgb[:,:,1]-rgb[:,:,0]>8)&(rgb[:,:,2]-rgb[:,:,0]>10)&(g<230)
        labs,n=ndimage.label(color);components=[]
        for k in range(1,n+1):
            yy,xx=np.where(labs==k)
            if len(xx)<8:continue
            pb=[]
            for y,x in zip(yy,xx):
                p=fitz.Point(origin[0]+int(x)+.5,origin[1]+int(y)+.5)*~T;pb.append([p.x,p.y])
            pb=np.asarray(pb);components.append(dict(pixels=len(xx),bbox600=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],
                PDF_bbox=[float(pb[:,0].min()),float(pb[:,1].min()),float(pb[:,0].max()),float(pb[:,1].max())],
                spans_source_pixel_equivalent_x=(xx.max()-xx.min()+1)/4,
                median_RGB=np.median(source600[yy,xx],axis=0).tolist(),RGB_min=source600[yy,xx].min(0).tolist(),RGB_max=source600[yy,xx].max(0).tolist(),
                classification='Ứng viên mực đường/JPEG; cần xem nguyên ảnh. Không phải glyph mask.',
                native_gray_fringe_uncertainty=True))
        curve_intrusions=[]
        for p in paths:
            pp=p['points'];mask=hits(bb,pp,p['width']/2)
            if not mask.any():continue
            ss=pp[mask];curve_intrusions.append(dict(model=p['model'],actual_object=p['object'],sample_hits=int(mask.sum()),
                sampled_center_bbox=[float(ss[:,0].min()),float(ss[:,1].min()),float(ss[:,0].max()),float(ss[:,1].max())],
                source_island_hides_this_new_stroke_footprint=True,
                full_geometry_fingerprint_unchanged=p['fingerprint'],width_pt=p['width'],RGB=p['RGB'],
                logical_path_kept_NOT_proof_of_visible_continuity=True))
        context=(np.array(bb)+[-3,-3,3,3]).tolist();tile=Image.new('RGB',(1800,460),'white');dr=ImageDraw.Draw(tile)
        dr.text((5,4),name+' SOURCE / CURRENT / RAM actual context600 (not retyped; green boxes only in PNG)',fill='blue')
        for i,(doc,kind) in enumerate([(source,'SOURCE'),(current,'CURRENT'),(E.doc.doc,'RAM')]):
            ar,oo,TT=render(doc,context,600);image=Image.fromarray(ar);draw=ImageDraw.Draw(image)
            p0=fitz.Point(bb[0],bb[1])*TT;p1=fitz.Point(bb[2],bb[3])*TT
            box=[min(p0.x,p1.x)-oo[0],min(p0.y,p1.y)-oo[1],max(p0.x,p1.x)-oo[0],max(p0.y,p1.y)-oo[1]]
            draw.rectangle(box,outline=(0,150,20),width=1)
            rawpath=fresh(O/(stem+' '+kind+' CONTEXT600 NGUYEN.png'));Image.fromarray(ar).save(rawpath)
            tile.paste(image.resize((image.width*2,image.height*2),Image.Resampling.NEAREST),(i*600+5,55))
        tile.save(fresh(O/(stem+' SOURCE CURRENT RAM NOI600.png')));full_tiles.append(tile)
        if name in focus:five_tiles.append(tile)
        records.append(dict(model=name,island_bbox=bb,edge_reads_NO_trimming=edge_reads,
            colored_source_connected_component_diagnostics=components,new_QH_stroke_footprints_intersecting_original_caption_box=curve_intrusions,
            graphic_source_label_question='CHƯA THỂ hiện tại: nét nguồn chạm/xuyên chữ' if name in focus else 'CHỜ ROOT/đồ họa soi đủ chữ/biên/nối; không kết luậnPASS tự động.',
            old_curve_fragment_retained_not_pixel_edited=True,new_QH_geometry104_kept=True,
            context_source_current_RAM600=str(O/(stem+' SOURCE CURRENT RAM NOI600.png'))))
    whole=Image.new('RGB',(1800,sum(t.height+15 for t in full_tiles)),'white');y=0
    for t in full_tiles:whole.paste(t,(0,y));y+=t.height+15
    whole.save(fresh(O/'13 CUM NGUYEN NOI DUONG600 FULL CONTEXT.png'))
    atlas=Image.new('RGB',(1800,sum(t.height+15 for t in five_tiles)),'white');y=0
    for t in five_tiles:atlas.paste(t,(0,y));y+=t.height+15
    atlas.save(fresh(O/'5 CUM MUC CHAM GLYPH NGUYEN SOURCE CURRENT RAM600.png'))
data=dict(source=b['source'],source_SHA256=guards[0],canonical=b['input_current'],canonical_SHA256=guards[1],M1=b['sample'],M1_SHA256=guards[2],
    RAM_content_SHA256=prior['content_SHA256'],records=records,caption_count=13,focus5=focus,whole_words_font_size_position_bytes_preserved=True,
    new_font_glyph_fitting_stopped=True,thresholds_diagnostic_only_NOT_image_edit=True,QH104_not_remeasured=True,
    no_NEW_leader_drawn=True,eta2_RAM551_numeric_UNKNOWN=True,canonical_written=False,shared_progress_written=False,PDF_written=False,M2_written=False,
    graphic_status='CHƯA THỂ 5cụm mực nguồn xuyên/chạm chữ; các phần cấu trúc giữ không tự suyđạt đồng bộ.',
    source_JPEG_150dpi_uncertainty='Một pixel nguồn~0,480136pt. Không nhận diện bút/font CAD gốc từ JPEG; khoảng hở nguồn không phải số suy từ bảng.')
p=Path(fresh(O/'SOI13 CAPTION TAT CA MEP VA5 MUC CHAM NGUYEN NGUON.json'));p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert [sha(b[k]) for k in ['source','input_current','sample']]==guards
print([(z['model'],[(q['dpi'],q['changed_pixels'],q['source_dark100_neutral35_changed'],q['source_dark160_neutral35_changed'],q['max_changed_center_depth_inside_island_pt']) for q in z['edge_reads_NO_trimming']],[(q['model'],q['sample_hits']) for q in z['new_QH_stroke_footprints_intersecting_original_caption_box']]) for z in records],flush=True)
print(p,flush=True)
