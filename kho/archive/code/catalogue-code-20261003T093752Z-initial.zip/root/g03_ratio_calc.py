def calculate(TABLES,RATIO_TASKS):
    import numpy as np
    from catfix.charts import Chart
    import copy
    final=copy.deepcopy(TABLES); out={}
    for ident,(page,stage,col,proposal) in RATIO_TASKS.items():
        src=TABLES[page];i=src['stages'].index(stage)
        vals=[dict(model=f"{src['series']}/{st}",stages=st,H=row[col],H_per_stage=row[col]/st) for st,row in zip(src['stages'],src['heads']) if st!=stage]
        median=float(np.median([v['H_per_stage'] for v in vals]));estimate=int(np.floor(median*stage+0.5))
        row=src['heads'][i][:];row[col]=estimate
        fit=Chart.fit_poly(src['q'],row,0.02*max(row))
        if fit is None:
            fits=[Chart.fit_poly(src['q'],row,float('inf'),degrees=(deg,)) for deg in (2,3)]
            fits=[f for f in fits if f is not None]
            if not fits: raise RuntimeError(f'#{ident}: Không có đường khớp đa thức đơn điệu')
            fit=min(fits,key=lambda v:v[2])
        coeff,degree,maxres=fit
        pred=float(np.polyval(coeff,src['q'][col]));dev=abs(estimate-pred)/max(1,abs(pred))
        chosen=int(np.floor(pred+0.5)) if dev>0.02 else estimate
        if abs(chosen-proposal)>2: raise RuntimeError(f'#{ident}: {chosen} vượt ±2 so với {proposal}')
        final[page]['heads'][i][col]=chosen
        out[ident]=dict(page=page,model=f"{src['series']}/{stage}",Q=src['q'][col],units=src['units'],sources=vals,median=median,raw_estimate=median*stage,rounded_estimate=estimate,poly_degree=degree,poly_coeff=coeff.tolist(),poly_at_target=pred,relative_difference=dev,poly_max_residual=maxres,proposal=proposal,chosen=chosen,old=src['heads'][i][col])
    return final,out

if __name__=='__main__':
    from catwork import start,fresh
    S,D,N=start()
    from g03_data import TABLES,RATIO_TASKS
    import json
    from pathlib import Path
    final,out=calculate(TABLES,RATIO_TASKS)
    print(json.dumps(out,ensure_ascii=False,indent=1))
    json.dump(dict(ratios=out,tables=final),open(fresh(Path(S.report('G03'))/'ratio-calculation.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
