from catwork import start,fresh
from pathlib import Path
import json,hashlib,numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.charts import Chart
from catfix import verify
from PIL import Image,ImageDraw
root=Path(S.report('G04/REDPUMP DOC NGUON RIENG'));probe=json.loads((root/'DINH VI.json').read_text(encoding='utf8'));name=probe['name'];source=S.src(name);current=S.result(name)
E=Editor(source,backend='fitz');R=Raster(E);base=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(base);a=cv.orig.astype(int);g=a@np.array([.299,.587,.114]);assert [base.W,base.H]==[1739,1237]
ticks=[(i*50,z['pageX']) for i,z in enumerate(probe['vertical_rules'])];cx=np.polyfit([q for q,x in ticks],[x for q,x in ticks],1);res=max(abs(np.polyval(cx,q)-x) for q,x in ticks)
top=179.5;bottom=567.;y0=cv.to_page(0,bottom)[1];y150=cv.to_page(0,top)[1];C=Chart(float(cx[0]*1000/60),float(cx[1]),float((y150-y0)/150),float(y0));Q=[0,3,6,9,12,15,18,21]
tables=[dict(model='4SL16/23',Q=Q,H=[136,133,127,115,101,86,69,50],source_read='Đọc từng ô trong BANG QH.png và dòng mang tên4SL16/23'),dict(model='4SL16/18',Q=Q,H=[107,104,99,90,79,67,54,39],source_read='Đọc từng ô trong BANG QH.png và dòng mang tên4SL16/18')]
xp=C.to_page(21,0)[0];up=cv.to_px(xp,400)[0];u=int(round(up));records=[]
# These two source row bands are directly inspected on the original pixel crop,
# after following each named line from its own label. Do not enumerate blended
# lower traces from the failed all-13 color-mask procedure.
for table,rows in zip(tables,[list(range(427,435)),list(range(455,464))]):
 assert min(float(np.median(g[v,130:738])) for v in rows)>245,'Lẫn nét kẻ ngang, không được gán nó thành đường'
 weight=np.maximum(0,255-g[rows,u-1:u+2].min(1));center=float(np.average(rows,weights=weight));h=float((bottom-center)/(bottom-top)*150);wanted=table['H'][-1];err=h-wanted;limit=max(1.,wanted*.02);dy_m=150/(bottom-top)
 assert abs(err)>limit+dy_m,'Sai lệch chưa chắc vượt độ phân giải ảnh'
 records.append(dict(model=table['model'],Q=21,H_table=wanted,H_source_curve=h,error=err,limit=limit,source_pixel_rows=rows,source_pixel_center_v=center,vertical_resolution_m=dy_m,axis_x_fit_max_residual_pt=float(res),result='CHƯA ĐẠT',identification='Theo nhãn/source riêng đếnQ21, soi ảnh pixel nguồn; tâm nét thang xám có trọng số, không suy từ màu hoặc Perotac'))
Hrect=(160,39.5,374,177.5);sa=np.asarray(verify.crop(source,7,Hrect,400));ca=np.asarray(verify.crop(current,7,Hrect,400));assert np.array_equal(sa,ca),'Bảng H bản giao khác nguồn'
verify.crop(source,7,(117,379,327,491),600).save(fresh(root/'THEO NHAN23 TOI Q21.png'))
verify.crop(source,7,(117,365,327,455),600).save(fresh(root/'THEO NHAN18 TOI Q21.png'))
detail=cv.orig[410:477,int(up)-9:int(up)+10];im=Image.fromarray(detail).resize((detail.shape[1]*16,detail.shape[0]*16),resample=Image.Resampling.NEAREST);dr=ImageDraw.Draw(im);xx=(up-(int(up)-9))*16;dr.line([(xx,0),(xx,im.height)],fill=(255,150,0),width=2)
for r in records:yy=(r['source_pixel_center_v']-410)*16;dr.ellipse((xx-6,yy-6,xx+6,yy+6),outline=(255,0,0),width=2)
im.save(fresh(root/'Q21 HAI TAM NET THANG XAM.png'))
out=dict(name=name,page=8,source=source,current=current,source_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),source_image_shape=[base.W,base.H],source_image_name=base.name,source_image_ctm=base.ctm.tolist(),source_image_bbox=list(base.page_bbox),source_ticks_lmin=ticks,axis=[C.ax,C.bx,C.ay,C.by],axis_residual_pt=float(res),axis_choice='9 nét lưới dọc của Redpump gắn nhãn lít/phút đã soi; khớp tuyến tính',top_v=top,bottom_v=bottom,tables=tables,Q21_read=records,source_QH_rect=list(Hrect),source_and_current_QH_pixels_exact=True,color_global13_method='Stopped after2unsuccessful counts, not used as acceptance',scope='Chỉ2đường, 16số bảng nguồn đọc đầy đủ; đo chắc2mốcQ21. Các mốc nguồn khác/đường khác chưa đo.')
Path(fresh(root/'BANG VA HAI DUONG NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print('SOURCE SELECTED GRAYSCALE',json.dumps(records,ensure_ascii=False),flush=True);E.close()
