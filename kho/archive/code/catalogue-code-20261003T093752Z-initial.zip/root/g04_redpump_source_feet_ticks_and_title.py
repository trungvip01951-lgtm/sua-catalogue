"""Actual short feet stems and untouched title rectangle from native source pixels."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));fr=json.loads((root/'KHUNG LUOI THAT NGUON TRANG8.json').read_text(encoding='utf8'));src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);q=next(z for z in fr['panels'] if z['name']=='QH');lf,top,rf,bt=q['frame_native_uv'];xx=np.arange(int(np.ceil(rf+1)),int(np.ceil(rf+4)));vs=np.arange(int(top+5),int(bt-4));score=np.mean(255-g[vs[:,None],xx[None,:]],axis=1)
def runs(ids):
 out=[]
 for i in ids:
  if not out or i-out[-1][-1]>1:out.append([])
  out[-1].append(int(i))
 return out
rr=runs(vs[score>65]);ticks=[]
for row in rr:
 v=float(np.average(row,weights=score[np.array(row)-vs[0]]));ys=np.arange(max(int(v)-2,0),int(v)+3);dark=np.mean(255-g[ys, int(rf)+1:int(rf)+12],axis=0);ids=np.flatnonzero(dark>45)+int(rf)+1;end=float(ids.max()+1) if len(ids) else rf+2;box=[int(np.floor(rf-.5)),min(row)-2,int(np.ceil(end))+1,max(row)+3];pb=[*cv.to_page(box[0],box[3]),*cv.to_page(box[2],box[1])];ticks.append(dict(source_native_v=v,source_page_y=cv.to_page(0,v)[1],source_native_row_run=row,source_original_ink_restore_native_bbox=box,source_original_ink_restore_page_bbox=pb,source_native_x_end=end,printed_feet_value=None,source_original_only=True))
assert len(ticks)==4,(len(ticks),rr)
# The fifth (zero feet) stem is merged with the bottom frame and must also be
# kept. Its original small exterior patch is retained, not assigned a fake H.
bb=[int(np.floor(rf-.5)),int(np.floor(bt-2)),int(np.ceil(rf+8)),int(np.ceil(bt+3))];ticks.append(dict(source_native_v=bt,source_page_y=q['frame_page_bbox'][1],source_native_row_run=None,source_original_ink_restore_native_bbox=bb,source_original_ink_restore_page_bbox=[*cv.to_page(bb[0],bb[3]),*cv.to_page(bb[2],bb[1])],printed_feet_value=0,source_original_only=True,merged_bottom_frame=True))
# Find the left side and bottom of the title from its black rules, independently
# from model text or a guessed block box. The top/right coincide with the frame.
xv=np.arange(450,530);xc=(g[184:216,xv]<145).mean(0);xc_runs=runs(xv[xc>.8]);assert len(xc_runs)==1,xc_runs;titleleft=float(np.average(xc_runs[0],weights=xc[np.array(xc_runs[0])-450]));yy=np.arange(207,230);yc=(g[yy,int(titleleft+6):int(rf-5)]<145).mean(1);yr=runs(yy[yc>.85]);assert len(yr)==1,yr;titlebottom=float(np.average(yr[0],weights=yc[np.array(yr[0])-207]));titlepage=[cv.to_page(titleleft,0)[0],cv.to_page(0,titlebottom)[1],q['frame_page_bbox'][2],q['frame_page_bbox'][3]]
pic=Image.new('RGB',(1450,1100),'white');dr=ImageDraw.Draw(pic);raw=Image.fromarray(cv.orig);tcrop=(int(titleleft-5),int(top-5),int(rf+5),int(titlebottom+5));tp=raw.crop(tcrop);pic.paste(tp.resize((tp.width*3,tp.height*3),Image.Resampling.NEAREST),(5,20));dr.text((5,5),'Whole original 4SL16 title: actual source edges',fill='blue')
for i,z in enumerate(ticks):
 x0,y0,x1,y1=z['source_original_ink_restore_native_bbox'];bx=(x0-4,y0-5,x1+35,y1+5);p=raw.crop(bx);pic.paste(p.resize((p.width*8,p.height*8),Image.Resampling.NEAREST),(5+(i%3)*470,250+(i//3)*340));dr.text((5+(i%3)*470,230+(i//3)*340),'original small feet stem '+str(i+1),fill='blue')
photo=fresh(root/'VACH PHU FEET VA KHOI TIEU DE NGUON THAT.png');pic.save(photo)
out=dict(source_SHA256=before[0],current_SHA256=before[1],source_native_ctm=im.ctm.tolist(),short_feet_ticks=ticks,title_original_native_bbox=[titleleft,top,rf,titlebottom],title_original_page_bbox=titlepage,title_font_and_color_policy='Giữ nguyên khối 4SL16 nguồn ở cùng CTM, không ghép chữ tiêu đề lại và không thay màu xanh. Nền/lưới mới có lỗ cắt trừ chính khối này; vùng ruột tiêu đề giữ từng điểm ảnh.',side_tick_policy='Sau khi dựng nền toàn miền, giữ lại chính mực vạch phụ nguồn ở phía ngoài khung trước khi đặt khung mới. Chỉ phần nối mực vào khung nằm dưới bút khung mới0,63pt; tọa độ/đầu ra vạch/số feet ngoài miền giữ nguồn. Không để nền trắng phủ nửa vạch tạo nét rời.',side_tick_font_numbers_unchanged=True,feet_value_assignment='Bốn vạch ngoài đáy đã đọc trên ảnh toàn trục: 400/300/200/100 feet. Không dùng chúng làm bảng H. JSON giữ tọa độ mực, không suy hệ số đơn vị từ thứ hạng.',source_proof_photo=photo,native_tick_edge_uncertainty_pt=.480136,PDF_written=False,status='HỒ SƠ VẠCH PHỤ VÀ KHỐI CHỮ GỐC: phương án chưa áp vào PDF.')
Path(fresh(root/'VACH PHU FEET VA KHOI TIEU DE GIU NGUON V1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('Actual title',titlepage,'4feet small stems +zero bottom',[(z['source_page_y'],z['source_native_x_end']) for z in ticks if 'source_native_x_end'in z],'noPDF',flush=True)
