"""Mẫu2 duy nhất phương pháp1. Chỉ dùng PNG nền đã tách đủ quầng,
giữ đoạn có chữ/nét đứt và khớp nét theo lõi ảnh nguồn600dpi.
"""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import RenderCanvas
from catfix.charts import draw_polyline,bezier
from PIL import Image
from pathlib import Path
import numpy as np,json
I='G05/MAU SUA DUONG/PHUONG PHAP 2 - CHUYEN TIET DIEN MUC/MAU 1/'
O='G05/MAU SUA DUONG/PHUONG PHAP 1 - TACH NET VA VECTOR/MAU 2/'
rec=json.loads(Path(S.report(I+'TOA DO VA PHUONG PHAP.json')).read_text(encoding='utf8'))
fits=json.loads(Path(S.report('G05/MAU SUA DUONG/DO MAU DO DAY ANH RENDER.json')).read_text(encoding='utf8'))
for p in rec['panels']:
 fam=p['family'];fit=next(v for v in fits if v['family']==fam);width=float(np.percentile([v['fwhm_pt'] for v in fit['samples']],25));width=min(.48,width)
 col=tuple(int(round(v)) for v in np.percentile(np.array([v['render_peak_rgb'] for v in fit['samples']]),35,axis=0))
 a=np.array(Image.open(S.report(I+fam+'-nen-da-tach.png')).convert('RGB'));cv=RenderCanvas(p['page']-1,p['rect'],p['dpi'],a,None)
 for c in p['curves']:
  pts=[]
  for seg in c['segments']:pts.extend(bezier(*map(np.array,seg),n=150).tolist())
  draw_polyline(cv,pts,color=col,width_px=width*p['dpi']/72,ss=4)
 Image.fromarray(cv.work).save(fresh(S.report(O+fam+'-sau.png')))
 Image.open(S.report(I+fam+'-truoc.png')).save(fresh(S.report(O+fam+'-truoc.png')))
 q=np.load(S.report(I+fam+'-miếng-anh-600dpi.npz'));np.savez_compressed(fresh(S.report(O+fam+'-miếng-anh-600dpi.npz')),orig=q['orig'],output=cv.work)
 p['method']='Full source-rank ink/JPEG fringe removal and native grid restoration; vector through actual table knots; original left text/dashes retained. Width from native one-pixel stable FWHM and color from35th percentile source rendered core.'
 p['status']='MẪU CHƯA NGHIỆM THU';p['width_pt']=width;p['source_color_rgb']=list(col);p['patch_pixel_count']=int(np.any(q['orig']!=cv.work,axis=2).sum())
 print(fam,'width',width,'RGB',col,'patch px',p['patch_pixel_count'],flush=True)
Path(fresh(S.report(O+'TOA DO VA PHUONG PHAP.json'))).write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf8')
print('Mẫu2 phương pháp1, chưa ghi PDF',flush=True)
