from catwork import start, fresh
S,D,N=start()
from catfix import charts
from catfix.vector import Editor
from catfix.otext import OutlineText
from pathlib import Path
import json
NAME='Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'
E=Editor(S.src(NAME)); T=OutlineText(E); T.learn(range(10),dpi=400,verbose=False)
root=Path(S.report('G03'))
out={}
for pi in range(2,10):
    units=[]
    for q in ['KW','Kw','Hp','S.r.l','diametero95mm','k']:
        for m in T.find(pi,q):
            z=dict(query=q,text=m.text,bbox=m.bbox,styles=[g.style for g in m.glyphs])
            if q in ('KW','Kw','Hp'):
                try: z['plan']=T.replace(m,{'KW':'kW','Kw':'kW','Hp':'HP'}[q],dry_run=True)
                except Exception as ex: z['error']=str(ex)
            units.append(z)
    P=E.page(pi)
    rect=(170,150,540,440)
    gx,gy=charts.gridlines(P,rect)
    cs=[]
    for oi in charts.curve_objects(P,rect,min_span=100):
        pts=charts.sample_path(P.object_pagepath(oi),n=100)
        cs.append(dict(oi=oi,bbox=P.objs[oi]['bbox'],color=P.color_of(oi,'stroke'),endpoints=[pts[0].tolist(),pts[-1].tolist()],n=len(pts)))
    out[pi+1]=dict(units=units,grid=(gx,gy),curves=cs)
    print('PAGE',pi+1,[(v['query'],v.get('error','OK')) for v in units],flush=True)
json.dump(out,open(fresh(root/'probe.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
print('k source glyphs',[(g.key,g.oi,g.bbox,g.style) for cl in T.clusters if cl['label']=='k' for g in cl['members']])
print('Done',flush=True)
E.close()
