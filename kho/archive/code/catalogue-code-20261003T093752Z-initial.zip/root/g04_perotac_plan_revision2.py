from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
import json,numpy as np,hashlib,copy
root=Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC'));old=json.loads((root/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM.json').read_text(encoding='utf8'));new=copy.deepcopy(old);neutral=json.loads((root/'DOI CHIEU LOI XAM 5 NET.json').read_text(encoding='utf8'));doc=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));name='Perotac bơm giếng SA_compressed (bản mới).pdf';E=Editor(S.src(name));R=Raster(E)
for c in new['items']:
 cv=R.canvas(max(R.images(c['page']-1),key=lambda z:z.W*z.H));rgb=cv.orig.astype(int);ar=cv.orig.astype(float);lum=ar@np.array([.299,.587,.114]);cr=rgb[:,:,1]-rgb[:,:,0];cb=rgb[:,:,2]-rgb[:,:,0];weak=(cr>2)&(cb>3);core=(cr>3)&(cb>3)&(cr+cb>11)&(lum>105)&(lum<225)
 g=next(z for z in doc['graphs'] if z['family']==c['family']);curve=next(z for z in g['curves'] if z['model']==c['model']);tail=curve['native_path'][:-1]+c['source_tail_core_extension_points'];p=np.array([[z['u'],z['v']] for z in tail]);ju=c['numeric_nodes'][0]['u'];eu=c['numeric_nodes'][-1]['u'];gx=[z['u_refined_native'] for z in new['independent_axis_measurement'][c['family']]['ticks']];gy=[z['v_native'] for z in g['axis']['H_grid_calibration']['ticks']];samples=[];cols=[]
 for u,v in p:
  u=int(u)
  if not ju<u<eu-5 or min(abs(u-x) for x in gx)<3 or min(abs(v-y) for y in gy)<3:continue
  ys=np.arange(int(round(v))-4,int(round(v))+5);good=ys[core[ys,u]]
  if len(good):samples.extend(ar[good,u].tolist());cols.append(u)
 pix=np.array(samples);l=pix@np.array([.299,.587,.114]);col=np.median(pix[l<=np.percentile(l,20)],axis=0);alpha=np.clip((255-ar)@(255-col)/np.sum((255-col)**2),0,1);widths=[]
 for u in cols:
  v=float(np.interp(u,p[:,0],p[:,1]));ys=np.arange(int(round(v))-4,int(round(v))+5);loc=p[abs(p[:,0]-u)<=5];s=float(np.polyfit(loc[:,0],loc[:,1],1)[0]);widths.append(float((alpha[ys,u]*weak[ys,u]).sum()/np.sqrt(1+s*s)))
 nc=next(z for z in neutral['items'] if z['model']==c['model']);c['original_color_measurement_with_overwide_neutral_protection']={'RGB':c['source_color_RGB'],'width_pt':c['source_equivalent_width_pt']};c['source_color_RGB']=col.tolist();c['source_equivalent_width_native_px']=float(np.median(widths));c['source_equivalent_width_pt']=float(np.median(widths))*c['source_step_pt_per_native_px'];c['width_sample_count']=len(widths);c['width_native_p10_p90']=np.percentile(widths,[10,90]).tolist();c['color_core_sample_count']=int((l<=np.percentile(l,20)).sum());c['neutral_geometry_check']=nc
 c['dark_neutral_protection_pixels_in_edit_rectangle']=c.pop('contains_black_text_or_frame_pixels');c['black_text_or_frame_identified_in_edit_region']=False;c['no_literal_caption_box_intersects_edit_region']=nc['no_literal_text_box_inside_edit_box']
 c['erase_boundary_method']='Khóa đúng mực nguồn theo nhãn/đường liên tục. Chỉ tách hỗ trợ pixel mực/quầng theo vị trí tube hẹp và chênh RGB với nền hàng/cột chính nguồn; gồm lõi xám của chính nét. Không bảo vệ mọi pixel màu xám đen như chữ. Nét khác, chữ và lưới được bảo vệ bằng hình/vị trí. Không quét cả hộp.'
 c['gray_core_specific_requirement']='Các pixel lõi xám đã định vị đỏ trên ảnh phải nằm trong mặt nạ mực cũ nếu thuộc đúng đường đang sửa; pixel màu cam thuộc đường khác phải giữ nguyên. Các giao điểm lưới bị mực cũ che dùng độ đậm vạch lân cận trong chính nguồn để khôi phục, không vẽ thêm vạch hay chạm phần lưới ngoài mặt nạ.'
 c['trial_drawn']=False
 print(c['model'],'RGB',col.tolist(),'WIDTH',c['source_equivalent_width_pt'],'samples',len(widths),'OWN GRAY',nc['neutral_threshold_own_curve_pixels'])
new['revision']='V2: phân loại lõi xám theo vị trí/hình nét; không gọi ngưỡng màu là chữ, khung; đo màu từng nét gồm lõi xám đúng đường.'
new['canonical_or_source_changed']=False
assert hashlib.sha256(Path(S.src(name)).read_bytes()).hexdigest()==new['source_sha256'];assert hashlib.sha256(Path(S.result(name)).read_bytes()).hexdigest()==new['current_sha256']
Path(fresh(root/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM V2.json')).write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf8')
md=(root/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM.md').read_text(encoding='utf8');md=md.replace('Chữ và khung đen trong cả5hộp kế hoạch: [54, 13, 41, 97, 52].','Ngưỡng màu + giãn2pixel trước đó đánh dấu [54,13,41,97,52] pixel trong5hộp; đây không phải số chữ/khung. Đã định vị trực tiếp: lõi xám thuộc chính nét cần sửa lần lượt1,1,3,2,3 pixel; các lõi còn lại thuộc đường lân cận. Không có hộp chữ nhãn/khung thật giao vùng sửa. Xem DOI CHIEU LOI XAM 5 NET.json và5ảnh chấm đỏ/cam.')
for a,b in zip(old['items'],new['items']):md=md.replace(str(a['source_color_RGB'])+' / '+f'{a["source_equivalent_width_pt"]:.4f}',str(b['source_color_RGB'])+' / '+f'{b["source_equivalent_width_pt"]:.4f}')
md+='\nV2 thay cho bản kế hoạch1: lõi xám phải được phân loại bằng vị trí/hình nét, không bảo vệ tất cả xám đen bằng màu. 10pixel lõi xám của đúng5nét đã đối chiếu trên ảnh nguyên độ phân giải; giữ pixel nét khác màu cam. Mặt nạ tính từ mực/quầng trong tube hẹp của chính nét và chênh với nền cùng hàng/cột nguồn; không quét toàn hộp. Lưới ngoài mặt nạ giữ đúng pixel, giao lưới/đường cũ phải khôi phục theo chính vạch nguồn. Màu/độ dày đã đo lại gồm các lõi xám đúng đường. Chưa dựng, chưa ghi bất kỳ mẫu PDF nào.\n'
Path(fresh(root/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM V2.md')).write_text(md,encoding='utf8');E.close()
