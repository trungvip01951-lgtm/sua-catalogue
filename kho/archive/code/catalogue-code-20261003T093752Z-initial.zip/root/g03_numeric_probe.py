from catwork import start
S,D,N=start()
from catfix.vector import Editor
from catfix.otext import OutlineText
E=Editor(S.src('Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'));T=OutlineText(E);T.learn(range(10),dpi=400,verbose=False)
for pi,q,new,r in [(2,'5.0','5.5',(290,452,312,466)),(4,'103','130',(407,493,427,507)),(5,'281','217',(374,465,395,478)),(6,'316','216',(407,437,428,450)),(7,'116','166',(374,465,397,478))]:
    m=T.find(pi,q,rect=r)[0]
    try: plan=T.replace(m,new,align='center',dry_run=True);print(pi+1,q,new,m.bbox,plan,flush=True)
    except Exception as ex: print('FAIL',ex,flush=True)
m=T.find(2,'Hp')[0]
print('Hp glyphs',[(g.char,g.bbox,g.style,g.oi) for g in m.glyphs],flush=True)
src,s,sid=T._source(m.glyphs[-1].style,'P')
print('P source',src.key,src.bbox,src.style,s,sid,flush=True)
for ch in 'HPp': print('METRIC',ch,T.char_metrics(m.glyphs[-1].style,ch),flush=True)
E.close()
