"""Phục hồi nét thẳng /,4 từ chính alpha nguồn, không phông/PDF mới."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
from scipy.ndimage import gaussian_filter,distance_transform_edt,label
from scipy.optimize import differential_evolution,minimize
import numpy as np,json,hashlib,math
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'NET THANG DAU GACH CHEO VA SO4 TU NGUON'
data=json.loads((base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json').read_text(encoding='utf8'));by={r['key']:r for r in data['candidates']}
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));bg=np.array([255.,255.,255.]);ink=np.array([57.,55.,57.]);zoom=48;results=[];tiles=[]
def source_contour(al,thr):
    from catfix.raster import cv2
    up=cv2.resize(np.pad(al,1),((al.shape[1]+2)*zoom,(al.shape[0]+2)*zoom),interpolation=cv2.INTER_LINEAR)
    return up>=thr
def coverage(polys,shape):
    h,w=shape;img=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);d=ImageDraw.Draw(img)
    for poly in polys:d.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in poly],fill=255)
    hi=np.asarray(img)/255.;return hi.reshape(h+2,zoom,w+2,zoom).mean((1,3))[1:-1,1:-1],hi>=.5
for ch,key in [('/','SLASH25'),('4','4_4SA16-25')]:
    rec=by[key];x0,y0,x1,y1=rec['source_native_box'];raw=cv.orig[y0:y1,x0:x1];al=R.alpha_of(raw,bg,ink);assert np.max(abs(al-np.array(rec['alpha'])))<1e-6
    bb=rec['source_iso_native_bbox'];xmin,ymin,xmax,ymax=bb;W=xmax-xmin;H=ymax-ymin
    if ch=='/':
        bounds=[(.6,1.25),(0,.4),(.9,1.12),(0,.035)]
        def polygons(z):
            w=z[0];return [[(xmax-w,ymin),(xmax,ymin),(xmin+w,ymax),(xmin,ymax)]]
        initial=[.93,.13,1.,.01]
    else:
        bounds=[(4.2,5.25),(.8,1.5),(3.35,4.15),(.65,1.3),(5.45,6.55),(.7,1.4),(0,.4),(.9,1.12),(0,.035)]
        def polygons(z):
            xs,wv,xd,wd,yb,wb=z[:6];stemL=xs-wv/2;stemR=xs+wv/2
            # All six outline edges are straight source strokes, no assumed font family.
            return [[(stemL,ymin),(stemR,ymin),(stemR,ymax),(stemL,ymax)],
                    [(xd,ymin),(xd+wd,ymin),(xmin+wd,yb+wb/2),(xmin,yb+wb/2)],
                    [(xmin,yb-wb/2),(xmax,yb-wb/2),(xmax,yb+wb/2),(xmin,yb+wb/2)]]
        initial=[4.9,1.2,3.6,1.0,6.3,1.15,.13,1.,.01]
    def predict(z):
        aa,mm=coverage(polygons(z),al.shape);sigma=z[-3];gain=z[-2];floor=z[-1]
        return np.clip(gaussian_filter(aa,sigma=sigma,mode='constant')*gain+floor,0,1),aa,mm
    def objective(z):
        pred,aa,mm=predict(z);err=pred-al;cost=float(np.mean(np.minimum(err*err,.04+np.maximum(abs(err)-.2,0)*.2)))
        # Keep source amount/box; do not solve JPEG artifacts by making the glyph heavier.
        cost+=.04*float((aa.sum()/al.sum()-1)**2)
        if ch=='4':
            xs,wv,xd,wd,yb,wb=z[:6]
            cost+=.3*max(xs-wv/2-(xd+wd),0)**2 # Source closed triangular counter observed.
            cost+=.3*max((xs+wv/2)-xmax,0)**2
        return cost
    opt=differential_evolution(objective,bounds,seed=4038,popsize=8,maxiter=45,tol=1e-6,polish=False,workers=1)
    fine=minimize(objective,opt.x,bounds=bounds,method='Powell',options={'maxiter':100,'xtol':1e-5,'ftol':1e-7});z=fine.x;pred,aa,mask=predict(z);polys=polygons(z)
    old=source_contour(al,rec['iso_mass_match_threshold']);inside=distance_transform_edt(mask);outside=distance_transform_edt(~mask);edge=mask & (inside<=1.01);oe=old & (distance_transform_edt(old)<=1.01)
    edge_dist1=distance_transform_edt(~oe)[edge]/zoom;edge_dist2=distance_transform_edt(~edge)[oe]/zoom
    n=int(label(mask,np.ones((3,3)))[1]);il,nh=label(~np.pad(mask,1),np.ones((3,3)));ext=set(np.r_[il[0],il[-1],il[:,0],il[:,-1]]);holes=[k for k in range(1,nh+1) if k not in ext]
    ys,xs=np.where(mask);newbb=[float(xs.min()/zoom-1),float(ys.min()/zoom-1),float((xs.max()+1)/zoom-1),float((ys.max()+1)/zoom-1)];step=rec['source_native_px_step_pt']
    out=dict(character=ch,source_key=key,source_page=8,source_image='X7',source_native_box=rec['source_native_box'],source_pixel_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),source_alpha=al.tolist(),
       measured_source_contour_box=bb,source_straight_polygon_geometry_local_native=polys,optimized_source_parameters=z.tolist(),
       JPEG_effect_sigma_only_for_fit_not_final_geometry=float(z[-3]),JPEG_effect_gain_only_for_fit=float(z[-2]),JPEG_effect_floor_only_for_fit=float(z[-1]),
       native_source_predicted_alpha=pred.tolist(),source_alpha_MAE=float(np.mean(abs(pred-al))),source_alpha_RMSE=float(np.sqrt(np.mean((pred-al)**2))),
       native_new_polygon_coverage=aa.tolist(),new_ink_area_native_px=float(aa.sum()),source_alpha_integral_native_px=float(al.sum()),ink_area_delta_percent=float((aa.sum()/al.sum()-1)*100),
       native_polygon_bbox=newbb,new_width_pt=(newbb[2]-newbb[0])*step[0],new_height_pt=(newbb[3]-newbb[1])*step[1],source_width_pt=rec['source_iso_width_pt'],source_height_pt=rec['source_iso_height_pt'],
       width_delta_percent=((newbb[2]-newbb[0])/(bb[2]-bb[0])-1)*100,height_delta_percent=((newbb[3]-newbb[1])/(bb[3]-bb[1])-1)*100,
       maximum_bidirectional_distance_from_source_mass_iso_boundary_native_px=float(max(edge_dist1.max(),edge_dist2.max())),boundary_source_uncertainty_native_px=.5,
       new_components=n,new_holes=len(holes),same_original_glyph_no_external_font=True,straight_edges_only_from_source_geometry_fit=True,new_FontProgram_or_PDF_written=False,
       root_or_graphic_acceptance_not_claimed=True,exact_original_outline_unknown_from_150dpi_JPEG=True)
    results.append(out)
    basename='SLASH' if ch=='/' else '4';Image.fromarray(raw).save(fresh(root/(basename+' NGUON150dpi.png')))
    tile=Image.new('RGB',(1000,400),'white');srcbig=Image.fromarray(raw).resize((raw.shape[1]*24,raw.shape[0]*24),Image.Resampling.NEAREST)
    glyph=np.full((*mask.shape,3),255,np.uint8);glyph[mask]=[57,55,57];gimg=Image.fromarray(glyph).resize((glyph.shape[1]//2,glyph.shape[0]//2),Image.Resampling.LANCZOS)
    pimg=Image.fromarray((255-pred[:,:,None]*(bg-ink)).astype(np.uint8)).resize((raw.shape[1]*24,raw.shape[0]*24),Image.Resampling.NEAREST)
    tile.paste(srcbig,(20,40));tile.paste(gimg,(320,16));tile.paste(pimg,(680,40));tiles.append(tile)
    tile.save(fresh(root/(basename+' NGUON BIEN THANG VA DOC LAI150dpi.png')))
    print(ch,'params',z.tolist(),'MAE/RMSE',out['source_alpha_MAE'],out['source_alpha_RMSE'],'AREA delta',out['ink_area_delta_percent'],'WH delta',out['width_delta_percent'],out['height_delta_percent'],'BOUNDARY maxPX',out['maximum_bidirectional_distance_from_source_mass_iso_boundary_native_px'],'CC/H',n,len(holes),flush=True)
sheet=Image.new('RGB',(1000,800),'white');sheet.paste(tiles[0],(0,0));sheet.paste(tiles[1],(0,400));sheet.save(fresh(root/'DAU GACH CHEO VA SO4 NET THANG DOI CHIEU NGUON.png'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==data['source_sha256'] and sha(S.result(name))==data['current_sha256']
Path(fresh(root/'NET THANG TU NGUON GACH CHEO VA SO4 CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only_source=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_original_only=True,candidates=results,
       all_straight_geometry_has_source_pixel_fit=True,source_alias_reconstruction_limits_native_px=.5,PDF_or_catalogue_or_common_progress_modified=False,
       source_fitting_not_font_guess=True,source_font_family_not_claimed=True,root_acceptance_pending=True),ensure_ascii=False,indent=2),encoding='utf8');E.close()
