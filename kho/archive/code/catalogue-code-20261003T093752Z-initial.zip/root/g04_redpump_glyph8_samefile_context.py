"""Look for stronger source 8 with same graph-label style in this Redpump file."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));p=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17 V2.json').read_text(encoding='utf8'));src=p['method']['source'];cur=p['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[p['method']['source_SHA256'],p['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);requests=[(5,'source4SL4 labels',(551,320,590,510)),(7,'source4SL12 labels',(551,320,590,510))];pic=Image.new('RGB',(850,1720),'white');dr=ImageDraw.Draw(pic);records=[]
for i,(page,name,request) in enumerate(requests):
 cv=R.render_canvas(page-1,request,dpi=600);a=Image.fromarray(cv.orig);pic.paste(a,(i*420,30));dr.text((i*420+5,4),name,fill='blue')
 for v in range(0,a.height,100):dr.text((i*420+5,30+v),str(v),fill=(180,0,180))
 records.append(dict(page=page,description=name,source_request_rect=list(request),actual_rect=list(cv.rect0),size=list(cv.orig.shape),canvas_RGB_SHA256=hashlib.sha256(cv.orig.tobytes()).hexdigest()))
photo=fresh(root/'TIM GLYPH8 SACH CUNG FILE NGUON TRANG5 VA7.png');pic.save(photo);Path(fresh(root/'TIM GLYPH8 SACH CUNG FILE NGUON TRANG5 VA7.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=records,photo=photo,PDF_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('Same-file source8 label contexts only, noPDF',flush=True)
