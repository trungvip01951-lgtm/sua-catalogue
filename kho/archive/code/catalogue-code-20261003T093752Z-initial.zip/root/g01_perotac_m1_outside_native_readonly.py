from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib,math
import fitz
import numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads(Path(S.report('G08/ROOT PHAT HANH MOT PDF ANH V5 CA8 TRANG/ROOT KHOA MOT PDF ANH M1 V5.json')).read_text(encoding='utf8'))
PDF=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs\per_wc_continue_photo_union_v5_PDF_mau1_a1\Catalog cắt rác perotac (bản mới).pdf')
assert sha(PDF)=='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee'
assert sha(lock['canonical_file'])==lock['canonical_sha256'] and sha(lock['source_file'])==lock['source_sha256']
out=[]
def sig(op):return [op.op,[str(v) for v in op.operands]]
old=Editor(lock['canonical_file'],backend='fitz');new=Editor(str(PDF),backend='fitz')
for j in lock['jobs8']:
 pi=j['page']-1;a=old.page(pi).ops;b=new.page(pi).ops
 im=next(i for i in Raster(new).images(pi) if i.name==j['original_source_JPEG_name'])
 bg=next(i for i in Raster(new).images(pi) if i.name.startswith('CfxPerStudioBg'))
 start=max(i for i in range(bg.index) if b[i].op=='q');end=im.index+2
 assert b[end-1].op=='Q' and start==j['original_photo_Do_index']
 assert [sig(o) for o in a[:start]]==[sig(o) for o in b[:start]]
 assert [sig(o) for o in a[start+1:]]==[sig(o) for o in b[end:]]
 with fitz.open(lock['canonical_file']) as before,fitz.open(str(PDF)) as after:
  pa=before[pi].get_pixmap(dpi=200,colorspace=fitz.csRGB,alpha=False);pb=after[pi].get_pixmap(dpi=200,colorspace=fitz.csRGB,alpha=False)
  aa=np.frombuffer(pa.samples,np.uint8).reshape(pa.height,pa.width,pa.n);bb=np.frombuffer(pb.samples,np.uint8).reshape(pb.height,pb.width,pb.n);assert aa.shape==bb.shape
  changed=np.any(aa!=bb,axis=2);outside=changed.copy();r=j['allowed_photo_rect_top_fixed_before_RAM'];z=200/72
  ij=[math.floor(r[0]*z),math.floor(r[1]*z),math.ceil(r[2]*z),math.ceil(r[3]*z)]
  outside[ij[1]:ij[3],ij[0]:ij[2]]=False;n=int(outside.sum())
  out.append({'page':j['page'],'canonical_SHA':lock['canonical_sha256'],'original_instructions_unchanged_except_photo_Do':True,'original_op_count':len(a),'new_op_count':len(b),'replaced_old_Do_index':start,'new_segment_indices_halfopen':[start,end],'product_and_bg_Do_Wn_segment_only':True,'outside200_changed_pixels_threshold0_pad0':n,'changed_pixels_all_inside_photo_scope':int(changed.sum()),'allowed_rect_top_exact':r,'allowed_pixels_halfopen_pad0':ij,'outside_gate':'ĐẠT' if n==0 else 'CHƯA ĐẠT'})
 assert not old.touched() and not new.touched()
old.close();new.close()
assert sha(PDF)=='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee'
assert sha(lock['canonical_file'])==lock['canonical_sha256'] and sha(lock['source_file'])==lock['source_sha256']
d={'PDF':str(PDF),'PDF_SHA':sha(PDF),'pages_read_actual':8,'original_instructions_except_photo_Do_preserved8':True,'outside_read_settings':'two fresh document opens per page, dpi200 DeviceRGB alphaFalse; entire page threshold0; exact locked photo bbox floor/ceil, padding0','page_records':out,'all_outside0':all(x['outside200_changed_pixels_threshold0_pad0']==0 for x in out),'no_PDF_or_pixel_edit':True,'no_TIEN_DO_write':True}
fp=Path(fresh(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_PDF M1 V5 DOC LAP DU8 TRANG/g01_DOC OPS THAT VA NGOAI VUNG200 NGUONG0.json')));fp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',fp,'SHA',sha(fp),'OUTSIDE',[(r['page'],r['outside200_changed_pixels_threshold0_pad0']) for r in out],flush=True)
