"""Read original ink coverage at dash caps, with JPEG uncertainty; no PDF write."""
from catwork import start, fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.ndimage import map_coordinates, median_filter
from scipy.optimize import least_squares, linprog
from scipy.integrate import quad
from PIL import Image
import numpy as np, json, hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON'
v6=json.loads((root/'PHA CHU KY VA DOAN MUC CHUNG TU169 BIEN NGUON V6 CHUA KHOA.json').read_text(encoding='utf8'))
v5=json.loads((root/'13 CHU KY CUNG NGUON VA DE XUAT V5 CHUA KHOA.json').read_text(encoding='utf8'))
colors=json.loads((root/'13 NHIP THEO MUC TUNG COT NGUON V2.json').read_text(encoding='utf8'))
gb={r['model']:r for r in v6['origin_fit_hidden_contact_geometry']}
step=v6['source_uncertainty_one_native_px_pt']
E=Editor(S.src(name),backend='fitz');R=Raster(E)
cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H))
a=cv.orig.astype(float);grey=a@[.299,.587,.114];chroma=a.max(2)-a.min(2)

# Actual row/column background samples are taken from the same original image.
# Median excludes coloured ink, no painted/invented replacement paper is used.
rowbg=np.full(grey.shape[0],255.);colbg=np.full(grey.shape[1],255.)
for yy in range(178,575):
    z=grey[yy,128:277];m=chroma[yy,128:277]<=4
    rowbg[yy]=np.median(z[m]) if m.sum()>15 else np.median(z)
for xx in range(124,282):
    z=grey[184:568,xx];m=chroma[184:568,xx]<=4
    colbg[xx]=np.median(z[m]) if m.sum()>50 else np.median(z)
background=np.minimum(rowbg[:,None],colbg[None,:])
records=[];edges=[];tiles=[]
for rr in v5['curves']:
    model=rr['model'];gg=gb[model];c=np.array(gg['source_head_geometric_fit_coeff']);d=np.polyder(c)
    uf=np.arange(135.,282.0001,.125)
    vf=np.polyval(c,(uf-200)/100);sl=np.polyval(d,(uf-200)/100)/100
    normal=np.arange(-3.5,3.5001,.125)
    nx=-sl/np.hypot(1,sl);ny=1/np.hypot(1,sl)
    xx=uf[:,None]+nx[:,None]*normal;yy=vf[:,None]+ny[:,None]*normal
    observed=map_coordinates(grey,[yy,xx],order=1,mode='nearest')
    bg=map_coordinates(background,[yy,xx],order=1,mode='nearest')
    # Integrate signed darkness; clipping every pixel would add JPEG noise as ink.
    coverage=np.trapezoid(bg-observed,normal,axis=1)
    sm=median_filter(coverage,size=3,mode='nearest')
    arc=lambda x:quad(lambda uu:float(np.hypot(1,np.polyval(d,(uu-200)/100)/100))*step,gg['phase_origin_axis_native_u'],float(x),epsabs=1e-9)[0]
    detail=[]
    for n,(lo,hi) in enumerate(rr['source_first6_full_dash_intervals_native'],1):
        # A split inside a dash is diagnosed from coverage and pixels, not simply joined.
        peak=(uf>=lo+3)&(uf<=hi-3)
        plateau=float(np.median(sm[peak]));floor=float(np.median(sm[(uf>=lo-4)&(uf<=lo-2)]));half=floor+(plateau-floor)/2
        def crossing(center,kind):
            win=np.flatnonzero((uf>=center-3)&(uf<=center+3));pairs=[]
            for k in win[:-1]:
                if (kind=='start' and sm[k]<half<=sm[k+1]) or (kind=='end' and sm[k]>=half>sm[k+1]):
                    x=uf[k]+(half-sm[k])/(sm[k+1]-sm[k])*(uf[k+1]-uf[k]);pairs.append(float(x))
            return min(pairs,key=lambda x:abs(x-center)) if pairs else None
        s=crossing(lo-.5,'start');end=crossing(hi+.5,'end')
        detail.append(dict(cycle_index=n,old_JPEG_visible_run=[lo,hi],plateau_signed_darkness_native=plateau,gap_baseline_signed_darkness_native=floor,
                           half_coverage_threshold=half,start_half_coverage_native_u=s,end_half_coverage_native_u=end,
                           physical_same_dash_visible_RGB_split_not_automatically_merged=True))
        for kind,x in [('start',s),('end',end)]:
            if x is not None:edges.append(dict(model=model,kind=kind,cycle_index=n,source_edge_u=x,source_arc_pt=arc(x),uncertainty_native_px=1.0,method='source perpendicular grey coverage half plateau'))
    lo=rr['source_transition_first_visible_u'];plateau=float(np.median(sm[(uf>=lo+2)&(uf<=lo+5)]));floor=float(np.median(sm[(uf>=lo-4)&(uf<=lo-2)]));half=(plateau+floor)/2
    candidates=[]
    for k in np.flatnonzero((uf>=lo-3)&(uf<=lo+3))[:-1]:
        if sm[k]<half<=sm[k+1]:candidates.append(float(uf[k]+(half-sm[k])/(sm[k+1]-sm[k])*.125))
    solid=min(candidates,key=lambda u:abs(u-(lo-.5))) if candidates else None
    if solid is not None:edges.append(dict(model=model,kind='start',cycle_index=7,source_edge_u=solid,source_arc_pt=arc(solid),uncertainty_native_px=1.,method='source perpendicular grey coverage half plateau'))
    rec=dict(model=model,source_cubic_coefficients=c.tolist(),original_source_geometry_only=True,first6_dash_half_coverage_edges=detail,
             source_transition_old_visible_u=lo,source_transition_half_coverage_u=solid,
             coverage_u=uf.tolist(),signed_darkness_perpendicular_integrals=coverage.tolist(),median3_signed_darkness=sm.tolist(),
             transition_plateau=plateau,transition_gap_baseline=floor,phase_exact_original_PDF_state='UNKNOWN',halfcoverage_not_original_vector_cap_fact=True)
    records.append(rec)
    # Source crop plus measured profile, no text/font generated in the catalogue.
    y0=max(181,int(min(vf))-8);y1=min(571,int(max(vf))+9)
    raw=Image.fromarray(cv.orig[y0:y1,135:282]).resize((1176,(y1-y0)*8),Image.Resampling.NEAREST)
    plot=Image.new('RGB',(1176,170),'white');p=np.array(plot);vmin=min(-30.,float(sm.min()));vmax=max(200.,float(sm.max()))
    px=np.clip(np.rint((uf-135)/(282-135)*1175).astype(int),0,1175);py=np.clip(np.rint(155-(sm-vmin)/(vmax-vmin)*140).astype(int),0,169)
    for x,y in zip(px,py):p[max(0,y-1):min(170,y+2),x]=[20,80,160]
    for r in detail:
        for key in ['start_half_coverage_native_u','end_half_coverage_native_u']:
            if r[key] is not None:
                x=int(round((r[key]-135)/(282-135)*1175));p[:,max(0,x):min(1176,x+1)]=[180,180,180]
    tile=Image.new('RGB',(1176,raw.height+170),'white');tile.paste(raw,(0,0));tile.paste(Image.fromarray(p),(0,raw.height))
    tile.save(fresh(root/(model.replace('/','-')+' DO TIET DIEN MUC NGUON V7.png')))
    print(model,'HALF caps',[(r['start_half_coverage_native_u'],r['end_half_coverage_native_u']) for r in detail],'SOLID',solid,flush=True)

X=np.array([[1.,r['cycle_index'],0. if r['kind']=='start' else 1.] for r in edges]);y=np.array([r['source_arc_pt'] for r in edges])
z=least_squares(lambda v:(X@v-y)/step,[-.1,10.38,7.2],loss='soft_l1',f_scale=.65,bounds=([-1,10,6.5],[1,10.8,8])).x
delta=(X@z-y)/step
for r,dv in zip(edges,delta):r.update(common_fit_error_native_px=float(dv),within_one_native_px=bool(abs(dv)<=1))
def evaluate(v):
    d=(X@np.array(v)-y)/step
    return dict(phase_pt=float(v[0]),period_pt=float(v[1]),dash_pt=float(v[2]),edge_count=len(d),within_one_native_px=int((abs(d)<=1).sum()),
                median_abs_error_native_px=float(np.median(abs(d))),mean_abs_error_native_px=float(np.mean(abs(d))),RMS_error_native_px=float(np.sqrt(np.mean(d*d))),max_abs_error_native_px=float(max(abs(d))))
new=evaluate(z);old=evaluate([v6['common_source_estimate'][k] for k in ['phase_pt','period_pt','dash_length_pt']]);zero=evaluate([0,10.38,7.22])
feas=linprog([0,0,0],A_ub=np.vstack([X,-X]),b_ub=np.r_[y+step,-y+step],bounds=[(-1,1),(10,10.8),(6.5,8)],method='highs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(S.src(name))==v6['source_sha256'] and sha(S.result(name))==v6['current_sha256']
out=dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),method_not_accepted_yet=True,
         method='Signed perpendicular grey darkness, actual original row/column background medians, half local plateau. Every source cap uncertainty1 native pixel. No hydraulic table used.',
         exact_source_phase='UNKNOWN',rowbackground_samples=128,colbackground_samples=384,source_grid_not_invented_or_repainted=True,
         common_fit=new,previous_V6_evaluated_on_same_new_edges=old,previous_V5_phase_zero_evaluated_on_same_new_edges=zero,
         feasible_all_edges_within_one_native_px=bool(feas.success),records=records,all_source_edges=edges,
         data_only_original_Perotac_X7=True,QH_table_nodes_not_used_for_phase=True,PDF_font_or_progress_written=False)
Path(fresh(root/'DO TIET DIEN MUC VA PHA CHUNG NGUON V7 CHUA NGHIEM THU.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close()
print('SOURCE HALF COVERAGE FIT',new,'V6',old,'ZERO',zero,'FEASIBLE',feas.success,flush=True)
