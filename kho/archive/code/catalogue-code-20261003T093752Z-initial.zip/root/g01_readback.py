from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.otext import OutlineText,procrustes
from catfix import verify
from pathlib import Path
import pickle,copy,collections,json,hashlib
import fitz
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';src=S.src(NAME);dst=S.dst(NAME)
records=json.loads(Path(S.report('G01/nhung-cho-da-sua.json')).read_text(encoding='utf-8'))
state=pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes())
Es=Editor(src);Ts=OutlineText(Es);Ts.__dict__.update(state['data'])
# Chân trang được kiểm bằng hình gốc: đây là l, bộ OCR nguồn đọc thành y.
for p in range(2,32):
    for m in Ts.find(p,'Aquaris S.r.y',rect=(0,0,120,60)):
        g=m.glyphs[-1];Ts.clusters[g.cl]['label']='l'
for cl in Ts.clusters:
    for g in cl['members']:g.char=cl['label']
Ea=Editor(dst);Ta=OutlineText(Ea)
Ta.clusters=copy.deepcopy(Ts.clusters);Ta._buckets=copy.deepcopy(Ts._buckets)
for cl in Ta.clusters:cl['members']=[]
byop=collections.defaultdict(list)
for cl in Ts.clusters:
    if cl['label']!='?':byop[(cl['ops'],len(cl['pts']))].append(cl)
actual=[]
for p in range(2,32):
    gs=Ta.page_glyphs(p)
    for g in gs:
        cl=Ta.clusters[g.cl];g.char=cl['label']
        if g.char=='?':
            cand=[]
            for ref in byop.get((g.ops,len(g.pts)),[]):
                s,R,t,res=procrustes(ref['pts'],g.pts,allow_rotation=False)
                if .25<s<3 and res<.03:cand.append((res,ref['label']))
            if cand:g.char=min(cand)[1]
    subset=[r for r in records if r['page']==p+1]
    for r in subset:
        rect=r['rect'];pad=.6
        gl=[g for g in gs if rect[0]-pad<=sum(g.bbox[::2])/2<=rect[2]+pad and rect[1]-pad<=sum(g.bbox[1::2])/2<=rect[3]+pad]
        gl.sort(key=lambda g:g.bbox[0]);txt=''.join(g.char for g in gl)
        expected=r['new'].replace(' ','')
        ok=(txt==expected) if r['mode']!='delete' else not gl
        actual.append(dict(**r,readback=txt,ok=ok,glyph_count=len(gl)))
    print('Đọc lại trang',p+1,sum(r['ok'] for r in actual if r['page']==p+1),'/',len(subset),flush=True)
bad=[r for r in actual if not r['ok']]
before=fitz.open(src);after=fitz.open(dst)
meta=dict(metadata=before.metadata==after.metadata,xml=before.get_xml_metadata()==after.get_xml_metadata(),bookmarks=before.get_toc()==after.get_toc(),pages=len(before)==len(after),page_sizes=all(tuple(a.rect)==tuple(b.rect) for a,b in zip(before,after)))
def linkdata(doc):
    return [[{k:(list(v) if isinstance(v,fitz.Rect) else v) for k,v in lk.items() if k not in ['xref','id']} for lk in p.get_links()] for p in doc]
meta['links']=linkdata(before)==linkdata(after)
before.close();after.close();Es.close();Ea.close()
out=dict(ok=not bad and all(meta.values()),meta=meta,rows=actual,bad=bad)
Path(fresh(S.report('G01/doc-lai-doc-lap.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=1),encoding='utf-8')
print('KẾT QUẢ',out['ok'],'sai',[(r['task'],r['page'],r['readback'],r['new']) for r in bad],meta,flush=True)
for r in [r for r in records if r['task']==18 and r['page'] in [3,4,16,28,32]]:
    verify.crop(dst,r['page']-1,(r['rect'][0]-5,r['rect'][1]-3,r['rect'][2]+5,r['rect'][3]+3),dpi=600).save(fresh(S.report(f"G01/chan-trang-zoom-{r['page']}.png")))
