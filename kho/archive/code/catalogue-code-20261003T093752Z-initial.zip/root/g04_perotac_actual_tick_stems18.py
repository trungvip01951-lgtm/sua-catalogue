"""Locate source tick stem centres from narrow strips; no values by peak order."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/DOI CHIEU VACH PHU NGUON THAT'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float);L=a@[.299,.587,.114];out=[]
cases=[('Q US',124,159,745,164,0),('Q IMP',124,176,745,180,0),('Q LMIN',124,677,745,682,0),('Q M3',124,693,745,698,0),('H M',120,181,124,572,1),('H FEET',747,181,752,572,1)]
for key,x0,y0,x1,y1,axis in cases:
    raw=cv.orig[y0:y1,x0:x1];d=255-L[y0:y1,x0:x1];profile=d.mean(axis=axis);base=float(np.median(profile));w=np.maximum(profile-base,0);present=w>max(16.,w.max()*.15);runs=[]
    for i in np.flatnonzero(present):
        if runs and i==runs[-1][1]+1:runs[-1][1]=int(i)
        else:runs.append([int(i),int(i)])
    ticks=[]
    for lo,hi in runs:
        if hi-lo>6:continue
        cut=w[max(0,lo-1):min(len(w),hi+2)];p=np.arange(max(0,lo-1),min(len(w),hi+2));center=float((p*cut).sum()/cut.sum())+(x0 if axis==0 else y0)
        ticks.append(dict(source_local_interval=[lo,hi],source_native_interval=[lo+(x0 if axis==0 else y0),hi+(x0 if axis==0 else y0)],native_weighted_dark_stem_center=center,
                         numeric_label_value_not_assigned_yet=True,source_uncertainty_native_px=.5))
    rec=dict(axis_row=key,source_probe_box=[x0,y0,x1,y1],source_native_first=x0 if axis==0 else y0,source_native_profile=profile.tolist(),source_baseline_darkness=base,tick_stem_candidates=ticks,
             narrow_source_strip_only=True,no_peak_rank_as_numeric_values=True)
    out.append(rec)
    print(key,'STEM CENTRES',[(r['source_native_interval'],round(r['native_weighted_dark_stem_center'],5)) for r in ticks],flush=True)
    Image.fromarray(raw).resize((raw.shape[1]*5,raw.shape[0]*5),Image.Resampling.NEAREST).save(fresh(root/(key.replace(' ','_')+' VACH THAT STRIP PHONG5LAN.png')))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'TAM VACH NGUON THEO TUNG HANG DON VI V3 CHUA GAN SO.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_original_Perotac_X7_only=True,
       rows=out,major_axis_existing_calibration_not_replaced=True,numeric_tick_mapping_requires_actual_printed_label_bbox_pair=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close()
