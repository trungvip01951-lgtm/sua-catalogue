"""Prepare a new, ROOT-authorized RAM-only half-pixel source island.

Historical builders and reports remain immutable. This script creates fresh
code only; it never saves a PDF or edits the common progress file.
"""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
import json
import hashlib

work = Path(__file__).resolve().parent

def changed_once(text, old, new):
    assert text.count(old) == 1, (old[:80], text.count(old))
    return text.replace(old, new)

builder = (work / 'g04_perotac_whole_source_island_builder60.py').read_text(encoding='utf8')
old = """        source_islands.append(dict(key=key,literal_source_read=literal['literal_source_read'],
            source_native_box=literal['source_native_box'],source_page_box=list(cv.rect(literal['source_native_box'])),
            source_cropped_RGB_SHA256=hashlib.sha256(cv.orig[literal['source_native_box'][1]:literal['source_native_box'][3],literal['source_native_box'][0]:literal['source_native_box'][2]].tobytes()).hexdigest(),
            original_X7_bytes_CTM_native_size_spacing_kept=True,font_program_and_exact_original_vector_outline_UNKNOWN=True))"""
new = """        original_box=list(literal['source_native_box'])
        clip_box=list(original_box)
        if key=='H FEET 200':
            assert original_box==[753,407,784,421]
            clip_box[0]=752.5
        cover=[int(np.floor(clip_box[0])),int(np.floor(clip_box[1])),int(np.ceil(clip_box[2])),int(np.ceil(clip_box[3]))]
        source_islands.append(dict(key=key,literal_source_read=literal['literal_source_read'],
            source_native_box=clip_box,source_page_box=list(cv.rect(clip_box)),
            source_literal_original_native_box=original_box,
            source_cropped_RGB_SHA256=hashlib.sha256(cv.orig[original_box[1]:original_box[3],original_box[0]:original_box[2]].tobytes()).hexdigest(),
            source_halo_raw_cover_box=cover,
            source_halo_raw_cover_RGB_SHA256=hashlib.sha256(cv.orig[cover[1]:cover[3],cover[0]:cover[2]].tobytes()).hexdigest(),
            ROOT_authorized_half_pixel_left_extension=(.5 if key=='H FEET 200' else 0),
            original_X7_bytes_CTM_native_size_spacing_kept=True,font_program_and_exact_original_vector_outline_UNKNOWN=True))"""
builder = changed_once(builder, old, new)
builder_path = Path(fresh(work / 'g04_perotac_source9_left_halo_builder70.py'))
builder_path.write_text(builder, encoding='utf8')

reader = (work / 'g04_perotac_literal_islands_actual_ram61.py').read_text(encoding='utf8')
reader = changed_once(reader, 'from g04_perotac_whole_source_island_builder60 import', 'from g04_perotac_source9_left_halo_builder70 import')
reader = changed_once(reader, 'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF', 'RAM CATFIX NGUON9 DAO V3 GIU QUANG200 CHUA LUU PDF')
reader = changed_once(reader, 'CATFIX NGUON9 DAO RAM V2 DOC LAI MUC THAT VA NGOAI VUNG.json', 'CATFIX NGUON9 DAO RAM V3 DOC LAI MUC THAT VA NGOAI VUNG.json')
reader = changed_once(reader, "        raw=sourcecv.orig[native[1]:native[3],native[0]:native[2]]", "        original_box=island['source_literal_original_native_box']\n        raw=sourcecv.orig[original_box[1]:original_box[3],original_box[0]:original_box[2]]\n        cover=island['source_halo_raw_cover_box']\n        assert hashlib.sha256(sourcecv.orig[cover[1]:cover[3],cover[0]:cover[2]].tobytes()).hexdigest()==island['source_halo_raw_cover_RGB_SHA256']")
reader = changed_once(reader, "        row=dict(key=key,literal_source_read=island['literal_source_read'],source_native_box=native,", "        row=dict(key=key,literal_source_read=island['literal_source_read'],source_native_box=native,\n            source_literal_original_native_box=original_box,source_halo_raw_cover_box=cover,\n            all_perimeter_and_halo_checks_pending_not_inferred_from_interior2=True,")
reader_path = Path(fresh(work / 'g04_perotac_source9_left_halo_actual71.py'))
reader_path.write_text(reader, encoding='utf8')

manifest = dict(stage='FRESH RAM CODE ONLY; ZERO PDF SAVES; ROOT REVIEW REQUIRED',
    ROOT_authorized_max_left_extension_native_px=.5,
    only_changed_clip_field='H FEET 200', unchanged_outer_ROI=True,
    source_sha256=hashlib.sha256(Path(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf')).read_bytes()).hexdigest(),
    canonical_sha256=hashlib.sha256(Path(S.result('Perotac bơm giếng SA_compressed (bản mới).pdf')).read_bytes()).hexdigest(),
    new_scripts=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [builder_path,reader_path]],
    historical_code_unchanged=True, common_progress_written=False)
path=Path(fresh(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/DAO200 MO0_5 PIXEL CODE CHUA LUU PDF/CHUAN BI RAM V3 KHOA CODE.json')))
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(manifest,ensure_ascii=False),flush=True)
