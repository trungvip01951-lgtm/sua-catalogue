"""Observe alternate2/5 in own p8 small labels; no bank/image/PDF mutation."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/'CHU2 5 NGUON P8 NGUYEN CUM LAN3'
assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json');w=J(P/'CHU NGUON ALPHA THU DO DOC V2.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
E=Editor(b['source'],backend='fitz');R=Raster(E);records=[]
for name in ['4SL16/25','4SL16/23','4SL16/20','4SL16/12','4SL16/5']:
    rec=next(z for z in w['records'] if z['model']==name);bb=rec['source_page_rect']
    cv=R.render_canvas(7,bb,dpi=600);a=cv.orig.astype(float);gray=a@np.array([.299,.587,.114])
    source=Image.fromarray(cv.orig);rawfile=Path(fresh(F/(name.replace('/','_')+' NGUYEN NGUON600.png')));source.save(rawfile)
    photo=Image.new('RGB',(source.width*5+40,source.height*5+65),'white');photo.paste(source.resize((source.width*5,source.height*5),Image.Resampling.NEAREST),(20,50));dr=ImageDraw.Draw(photo);ft=verify._font(16)
    dr.text((5,4),name+' – nguyên nguồn600; ô/biên chưa khóa, không đổi glyph',fill='blue',font=ft)
    for x in range(0,source.width,10):
        dr.line((20+x*5,40,20+x*5,49),fill='purple',width=1);dr.text((17+x*5,23),str(x),fill='purple',font=ft)
    for y in range(0,source.height,10):
        dr.line((5,50+y*5,18,50+y*5),fill='purple',width=1);dr.text((3,50+y*5),str(y),fill='purple')
    ruler=Path(fresh(F/(name.replace('/','_')+' NGUYEN NGUON600 THUOC5X.png')));photo.save(ruler)
    core=(gray<110)&(a.max(2)-a.min(2)<25);col=core.sum(0)>=2;groups=[]
    for x in np.flatnonzero(col):
        if not groups or x-groups[-1][-1]>1:groups.append([])
        groups[-1].append(int(x))
    records.append(dict(model=name,page=8,source_SHA256=guards[0],request_rect=bb,actual_canvas_rect=list(cv.rect0),shape=list(cv.orig.shape),
        black_core_column_groups=[[g[0],g[-1]] for g in groups],original_image=str(rawfile),ruler_photo=str(ruler),
        scope='Ứng viên từ chính nhãn nhỏ cùng p8, chưa coi cột mực là từng ký tự hoặc chứng minh biên phông.'))
E.close();assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
p=Path(fresh(F/'2 5 NGUYEN NHAN P8 VI TRI UNG VIEN KHONG DOI BANK.json'))
p.write_text(json.dumps(dict(records=records,source=b['source'],source_SHA256=guards[0],current_SHA256=guards[1],M1_SHA256=guards[2],
    PDF_written=False,M2_written=False,bank_changed=False,shared_progress_written=False,
    status='Nguồn đọc riêng nguyên cụm; tìm biên2/5 rõ và đối chứng4/S/L/slash trước dùng.'),ensure_ascii=False,indent=2),encoding='utf8')
print('SOURCE READ',[(r['model'],r['black_core_column_groups']) for r in records],str(p),flush=True)
