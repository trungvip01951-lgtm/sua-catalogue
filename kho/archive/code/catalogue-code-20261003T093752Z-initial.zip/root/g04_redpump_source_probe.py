"""Docdoclap nguon Redpump: hai duong tuongungSA, khong suadocthu."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
names=['Perotac bơm giếng SA_compressed (bản mới).pdf','Redpump gieng SL_compressed (bản mới).pdf']
out=[];raw=[]
for name in names:
 src=S.src(name);E=Editor(src,backend='fitz');R=Raster(E);ims=R.images(7);item=[]
 for im in ims:
  h=hashlib.sha256(E.doc.stream_raw(im.ref)).hexdigest();item.append(dict(name=im.name,shape=[im.W,im.H],bbox=list(im.page_bbox),rawsha=h))
 base=max(ims,key=lambda z:z.W*z.H);raw.append(R.canvas(base).orig.copy());out.append(dict(name=name,source=src,images=item));E.close()
brand='Redpump';source=S.src(names[1]);folder=Path(S.report('G04/REDPUMP DOI CHIEU NGUON'))
for label,rect in [('HAI CUOI',(288,353,326,381)),('TOAN TRANG',(0,0,850,600))]:
 if label=='TOAN TRANG':continue
 verify.crop(source,7,rect,600).save(fresh(folder/(label+'.png')))
res=dict(files=out,original_base_images_exact=bool(np.array_equal(raw[0],raw[1])),base_shape=[list(a.shape) for a in raw],scope='Only check actualsource identity; no presumption of identical final glyph/model names.')
Path(fresh(folder/'SO SANH ANH NGUON.json')).write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(res,ensure_ascii=False),flush=True)
