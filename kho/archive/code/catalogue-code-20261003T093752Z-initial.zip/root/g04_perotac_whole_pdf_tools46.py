"""Pure helpers for the Perotac whole-chart sample; no tasks run on import."""
from pathlib import Path
import hashlib, json, xml.etree.ElementTree as ET
import numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Ref, fmt_obj, serialize
import pymupdf as fitz

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def xml_values(text):
    return ET.canonicalize(text, strip_text=True, rewrite_prefixes=True) if text.strip() else ''

def masked_image_record(doc, ref):
    d = doc.get(ref)
    raw = doc.stream_raw(ref)
    record = dict(reference=list(ref), dictionary_sha256=hashlib.sha256(fmt_obj(d)).hexdigest(),
                  raw_sha256=hashlib.sha256(raw).hexdigest(), raw_length=len(raw),
                  width=d.get('Width'), height=d.get('Height'), filter=str(d.get('Filter')))
    smask = d.get('SMask')
    record['SMask'] = masked_image_record(doc, smask) if isinstance(smask, Ref) else str(smask)
    return record

def snapshot(path):
    E = Editor(path, backend='fitz')
    R = Raster(E)
    pages = []
    for pi in range(E.n_pages):
        P = E.page(pi)
        ims = []
        for im in R.images(pi):
            row = masked_image_record(E.doc, im.ref)
            row.update(name=str(im.name), key=str(im.key), index=im.index,
                       CTM=im.ctm.tolist(), page_bbox=list(im.page_bbox))
            ims.append(row)
        pages.append(dict(page=pi+1, images=ims, native_instruction_count=len(P.ops),
            content_sha256=hashlib.sha256(E.doc.page_content(pi)).hexdigest(),
            serialized_native_operations_sha256=hashlib.sha256(serialize(P.ops)).hexdigest(),
            native_paint_object_count=len(P.objs)))
    E.close()
    with fitz.open(path) as d:
        links = [[{k:str(v) for k,v in row.items() if k!='xref'} for row in p.get_links()] for p in d]
        annotations = []
        for p in d:
            annotations.append([dict(type=a.type, rect=list(a.rect), info=a.info, flags=a.flags,
                                      colors=a.colors, border=a.border, opacity=a.opacity)
                                for a in (p.annots() or [])])
        meta = dict(page_count=len(d), Info=d.metadata, XMP_semantic=xml_values(d.get_xml_metadata()),
            bookmarks=d.get_toc(simple=False), links=links, annotations=annotations,
            page_rects=[list(p.rect) for p in d], page_rotation=[p.rotation for p in d],
            page_boxes=[dict(Media=list(p.mediabox), Crop=list(p.cropbox), Bleed=list(p.bleedbox),
                              Trim=list(p.trimbox), Art=list(p.artbox)) for p in d],
            fonts=[[list(f[1:]) for f in p.get_fonts(full=True)] for p in d],
            native_text=[p.get_text('text') for p in d])
    return dict(path=str(path), sha256=sha(path), pages=pages, metadata=meta)

def pixel_snapshot(path, pi, rect, dpi=600):
    with fitz.open(path) as d:
        page=d[pi]
        matrix=page.transformation_matrix
        p0=fitz.Point(rect[0],rect[1])*matrix
        p1=fitz.Point(rect[2],rect[3])*matrix
        clip=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y))
        scale=dpi/72
        pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=clip,colorspace=fitz.csRGB,alpha=False)
        a=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[:,:,:3].copy()
        return a,dict(T=[float(v) for v in matrix],origin=[pix.x,pix.y],scale=scale,dpi=dpi)

def pixel_at(point, mapping):
    p=fitz.Point(float(point[0]),float(point[1]))*fitz.Matrix(mapping['T'])
    return np.array([p.x*mapping['scale']-mapping['origin'][0],
                     p.y*mapping['scale']-mapping['origin'][1]])

def page_at_pixel(point, mapping):
    p=fitz.Point((point[0]+mapping['origin'][0])/mapping['scale'],
                 (point[1]+mapping['origin'][1])/mapping['scale'])*~fitz.Matrix(mapping['T'])
    return np.array([p.x,p.y])
