from catwork import start,fresh
S,D,N=start()
from catfix import verify
src=S.src('KTZ - LH Perotac (bản mới).pdf')
verify.crop(src,1,(80,565,147,653),450).save(fresh(S.report('G09/VO DONG CO NGUON.png')))
