"""Đo nét ảnh theo nhãn/thứ tự đường và tính liên tục; H bảng chỉ dùng sau phép đo."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,csv,hashlib
from scipy.ndimage import gaussian_filter,gaussian_filter1d
from scipy.signal import find_peaks

PREFIX='G05/KIEM TOAN TOAN BO/'
GEOM=json.loads(Path(S.report(PREFIX+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
def interp_extrap(a,b,val):
 a=np.array(a,float);b=np.array(b,float);v=np.asarray(val,float)
 ans=np.interp(v,a,b)
 ans=np.where(v<a[0],b[0]+(v-a[0])*(b[1]-b[0])/(a[1]-a[0]),ans)
 ans=np.where(v>a[-1],b[-1]+(v-a[-1])*(b[-1]-b[-2])/(a[-1]-a[-2]),ans)
 return ans
def coords(b):
 s=72/b['dpi'];r=b['rect']
 def xp(q):return (float(interp_extrap(*zip(*b['xticks']),q))-r[0])/s
 def yp(h):return (r[3]-float(interp_extrap(*zip(*b['yticks']),h)))/s
 def hd(y):return float(interp_extrap(np.array(b['yticks'])[:,1],np.array(b['yticks'])[:,0],r[3]-float(y)*s))
 return xp,yp,hd

def prep(b):
 f=b['family'];im=Image.open(S.report(PREFIX+f+'-bieu-do-du-truc.png')).convert('RGB');g=np.asarray(im.convert('L'),float)
 xp,yp,hd=coords(b);l=round(xp(0));rt=round(xp(b['Qmax']));top=round(yp(b['Hmax']));bot=round(yp(0))
 ink=255-g
 bg=np.median(ink[top+8:bot-8,l+8:rt-8],axis=1)
 sig=np.maximum(0,ink[top+8:bot-8,:]-bg[:,None])
 # Vạch dọc nâng nền cả cột; chỉ trừ nền chung, giữ đỉnh riêng của đường.
 col=np.percentile(sig,40,axis=0);sig=np.maximum(0,sig-col[None,:])
 full=np.zeros_like(ink);full[top+8:bot-8,:]=sig
 full=gaussian_filter(full,(.8,.65))
 return im,full,(l,rt,top,bot),(xp,yp,hd)

def peaks_at(sig,x,top,bot):
 x=int(round(x));v=np.mean(sig[:,max(0,x-2):x+3],axis=1)
 peaks,props=find_peaks(v,prominence=8,height=22,distance=5)
 sel=(peaks>top+10)&(peaks<bot-8)
 return peaks[sel],v

def trace(b,im,sig,box,co):
 t=TABLES[b['family']];n=len(t['rows']);l,rt,top,bot=box;xp,yp,hd=co
 end=xp(t['Q'][-1]);candidates=[]
 # Tìm lát cắt đủ n đường ở phần liền, vượt vùng tên đường.
 for frac in [.47,.52,.57,.62,.67,.72,.77,.82,.87]:
  x=l+(end-l)*frac
  for dx in [-12,-8,-4,0,4,8,12]:
   pk,v=peaks_at(sig,x+dx,top,bot)
   if len(pk)==n:
    candidates.append((float(np.min(np.diff(pk))),float(np.min(v[pk])),x+dx,pk.copy()))
 if not candidates:
  counts=[]
  for frac in [.4,.5,.6,.7,.8,.9]:
   pk,v=peaks_at(sig,l+(end-l)*frac,top,bot);counts.append((frac,len(pk),[round(hd(vv),1) for vv in pk]))
  raise RuntimeError(('Không tìm lát đủ đường',b['family'],n,counts))
 # Khoảng cách lớn và sắc độ đều: tránh hai đường thấp sát nhau.
 _,_,seed,pk=max(candidates,key=lambda c:c[0]+c[1]*.025)
 seed=int(round(seed));seed_y=pk[::-1].astype(float)
 print('SEED',b['family'],'n',n,'x',seed,'H',[round(hd(y),1) for y in seed_y],flush=True)
 W=sig.shape[1];ys=np.full((n,W),np.nan);valid=np.zeros((n,W),bool)
 ys[:,seed]=seed_y;valid[:,seed]=True
 step=3
 for direction in [-1,1]:
  histories=[[(seed,float(y))] for y in seed_y]
  prev=seed_y.copy();slope=np.zeros(n)
  stop=int(l+5) if direction<0 else int(end+4)
  for x in range(seed+direction*step,stop,direction*step):
   pred=prev+direction*step*slope
   v=np.mean(sig[:,x-1:x+2],axis=1)
   new=pred.copy();vv=np.zeros(n,bool)
   for k in range(n):
    neigh=[]
    if k>0:neigh.append(abs(pred[k]-pred[k-1]))
    if k<n-1:neigh.append(abs(pred[k]-pred[k+1]))
    radius=min(12,max(4.5,min(neigh)/3 if neigh else 12))
    lo=max(top+8,int(np.floor(pred[k]-radius)));hi=min(bot-7,int(np.ceil(pred[k]+radius))+1)
    if hi<=lo:continue
    pks,props=find_peaks(v[lo:hi],prominence=3,height=14)
    if len(pks):
     pks=pks+lo;score=v[pks]-4.0*np.abs(pks-pred[k]);p=int(pks[np.argmax(score)])
     # Le centre est le barycentre du coeur du trait dans +/-2 pixels affichés.
     sel=np.arange(max(lo,p-2),min(hi,p+3));w=np.maximum(0,v[sel]-min(v[lo:hi]));y=float(np.sum(sel*w)/sum(w)) if sum(w)>0 else float(p)
     if abs(y-pred[k])<=radius:
      new[k]=y;vv[k]=True;histories[k].append((x,y))
      histories[k]=histories[k][-18:]
    # pente indépendante du tableau, ajustée à 18 échantillons du trait observé.
    hs=histories[k]
    if len(hs)>=4:
     coef=np.polyfit(np.array(hs)[:,0],np.array(hs)[:,1],1);slope[k]=float(np.clip(coef[0],-.05,2.0))
   # Nét không được đổi thứ tự. Giữ dự đoán nếu hai theo dõi chạm nhau.
   for k in range(1,n):
    if new[k]>=new[k-1]-3:
     vv[k]=False;vv[k-1]=False;new[k]=pred[k];new[k-1]=pred[k-1]
   ys[:,x]=new;valid[:,x]=vv;prev=new
 # Lưu các điểm nhìn thấy; các đoạn trống không biến thành đạt.
 paths=[]
 for k,row in enumerate(t['rows']):
  ids=np.flatnonzero(valid[k]);paths.append(dict(row=k+1,model=row['curve_model'],x_px=ids.tolist(),y_px=ys[k,ids].tolist()))
 return seed,ys,valid,paths

def measured_point(k,q,h,b,sig,ys,valid,co,box):
 xp,yp,hd=co;x=xp(q);ids=np.flatnonzero(valid[k]);near=ids[np.abs(ids-x)<=18]
 if len(near)<2:
  return dict(H_curve_m=None,reason='Thiếu nét phân biệt được quanh mốc Q',method='chua_do',sample_count=int(len(near)))
 # Không dựa H bảng: vị trí lấy từ đường đã theo dõi bằng tính liên tục.
 xx=near.astype(float);yy=ys[k,near]
 cf=np.polyfit(xx,yy,1);res=yy-np.polyval(cf,xx)
 good=np.abs(res-np.median(res))<=max(2.5,2*np.median(np.abs(res-np.median(res))))
 xx=xx[good];yy=yy[good]
 if len(xx)<2:return dict(H_curve_m=None,reason='Nét bị chữ/lưới che, chưa tách được',method='chua_do',sample_count=int(len(xx)))
 cf=np.polyfit(xx,yy,1);cy=float(np.polyval(cf,x));spread=float(np.max(np.abs(yy-np.polyval(cf,xx))))
 # Điểm ở cột biên dùng đoạn đầu/cuối có nét thật, ngoại suy tối đa 1,8 pt.
 extrap=max(float(min(xx)-x),float(x-max(xx)),0)*72/b['dpi']
 if extrap>1.8:
  return dict(H_curve_m=None,reason='Mốc nằm quá xa nét thật phân biệt được',method='chua_do',sample_count=int(len(xx)),extrapolation_pt=extrap)
 hc=hd(cy)
 # Ảnh gốc 150dpi: nửa pixel 0,24pt; độ rộng/định vị nét cộng sai số fit địa phương.
 pxunc=max(2.0,spread)+.5
 uncertainty=abs(hd(cy+pxunc)-hc)
 if extrap>0:uncertainty+=abs(hd(cy+extrap/(72/b['dpi'])*max(abs(cf[0]),.02)*.2)-hc)
 dev=abs(hc-h);limit=max(1,.02*h)
 nominal='ĐẠT' if dev<=limit else 'CHƯA ĐẠT'
 confidence='ĐẠT' if dev+uncertainty<=limit else ('CHƯA ĐẠT' if dev-uncertainty>limit else 'CHƯA THỂ')
 return dict(H_curve_m=round(hc,5),deviation_m=round(dev,5),limit_m=round(limit,5),uncertainty_m=round(uncertainty,5),nominal_status=nominal,confidence_status=confidence,method='noi_suy_net_thuc' if extrap==0 else 'bien_net_dau_cuoi',sample_count=int(len(xx)),x_px=round(x,4),y_px=round(cy,4),extrapolation_pt=round(extrap,5),local_residual_px=round(spread,5),reason='')

allpoints=[];allpaths=[];summary=[]
for b in GEOM:
 im,sig,box,co=prep(b)
 try:seed,ys,valid,paths=trace(b,im,sig,box,co)
 except RuntimeError as err:
  print('TRACE UNKNOWN',str(err),flush=True);allpaths.append(dict(family=b['family'],error=str(err)));continue
 t=TABLES[b['family']];points=[]
 for k,row in enumerate(t['rows']):
  for q,h in zip(t['Q'],row['H']):
   p=dict(page=b['page'],family=b['family'],row=k+1,table_models=' | '.join(row['table_models']),curve_model=row['curve_model'],Q_m3h=q,H_table_m=h,identity_uncertain=row.get('identity_uncertain',False) or t['family']!=t['plot_family'])
   p.update(measured_point(k,q,h,b,sig,ys,valid,co,box))
   if p['H_curve_m'] is None:p.update(nominal_status='CHƯA THỂ',confidence_status='CHƯA THỂ')
   p['overall_status']=p['confidence_status'] if not p['identity_uncertain'] else 'CHƯA THỂ'
   points.append(p)
 # Chỉ ảnh báo cáo: đánh dấu bảng tím, nét đo đỏ/xanh; không sửa PDF.
 draw=ImageDraw.Draw(im);xp,yp,hd=co
 for p in points:
  x=xp(p['Q_m3h']);y=yp(p['H_table_m']);draw.line((x-5,y,x+5,y),fill=(170,0,230),width=2);draw.line((x,y-5,x,y+5),fill=(170,0,230),width=2)
  if p['H_curve_m'] is not None:
   z=yp(p['H_curve_m']);color=(0,130,20) if p['confidence_status']=='ĐẠT' else ((220,20,20) if p['confidence_status']=='CHƯA ĐẠT' else (220,135,0))
   draw.ellipse((x-3,z-3,x+3,z+3),outline=color,width=2)
 # Xem đường theo dõi khác với bảng có thể chỉ ra lỗi nhận nét.
 preview=im.copy();d2=ImageDraw.Draw(preview)
 for k,path in enumerate(paths):
  xy=list(zip(path['x_px'],path['y_px']));color=[(0,110,255),(240,0,170),(255,130,0)][k%3]
  if len(xy)>1:d2.line(xy,fill=color,width=1)
 im.save(fresh(S.report(PREFIX+'MOC DO/'+b['family']+'.png')))
 preview.save(fresh(S.report(PREFIX+'KIEM NET THEO DOI/'+b['family']+'.png')))
 allpaths.append(dict(family=b['family'],seed_x_px=seed,paths=paths))
 sm=dict(family=b['family'],page=b['page'],curves=len(t['rows']),points=len(points),numeric_counts={s:sum(p['confidence_status']==s for p in points) for s in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']},overall_counts={s:sum(p['overall_status']==s for p in points) for s in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']},unmeasured=sum(p['H_curve_m'] is None for p in points),maximum_deviation=max((p.get('deviation_m',0) for p in points),default=0));summary.append(sm);allpoints.extend(points)
 print('MEASURE',b['family'],sm,flush=True)
Path(fresh(S.report(PREFIX+'DO NET BAN DAU.json'))).write_text(json.dumps(dict(summary=summary,points=allpoints),ensure_ascii=False,indent=2),encoding='utf8')
Path(fresh(S.report(PREFIX+'DUONG THEO DOI BAN DAU.json'))).write_text(json.dumps(allpaths,ensure_ascii=False,indent=2),encoding='utf8')
fields=list(dict.fromkeys(k for p in allpoints for k in p))
with open(fresh(S.report(PREFIX+'DO NET BAN DAU.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=fields);w.writeheader();w.writerows(allpoints)
