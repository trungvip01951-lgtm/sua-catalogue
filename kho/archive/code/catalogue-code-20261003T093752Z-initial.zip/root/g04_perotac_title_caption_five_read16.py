"""Verify all 5 common source letters under the same fixed 4SA transform; no draw."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.ndimage import map_coordinates,gaussian_filter
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'DOI CHIEU 5 CHU LON VA CHU NHAN CUNG FILE'
t=json.loads((base/'CHU LON TIEU DE CUNG FILE CHI DOC/5 CHU LON TIEU DE CUNG FILE CHI DOC.json').read_text(encoding='utf8'));tb={r['character']:r for r in t['title_glyphs']}
cap=json.loads((base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json').read_text(encoding='utf8'));cb={r['key']:r for r in cap['candidates']}
fit=json.loads((base/'DOI CHIEU CHU LON VA CHU NHAN CUNG FILE/CAU NOI 3 CHU LON VA CAPTION NGUON.json').read_text(encoding='utf8'));sx,sy,dy,sigma,floor=fit['common_transform_and_JPEG_readback_fit']
results=[];tiles=[];sub=24
for ch in '4SA16':
    rr=cb[ch+'_4SA16-25'];tt=tb[ch];al=np.array(rr['alpha']);ta=np.array(tt['source_alpha_matrix']);yy,xx=np.mgrid[:al.shape[0]*sub,:al.shape[1]*sub];worldx=rr['source_native_box'][0]+(xx+.5)/sub;worldy=rr['source_native_box'][1]+(yy+.5)/sub
    py,px=np.mgrid[:al.shape[0],:al.shape[1]];ty,tx=np.mgrid[:ta.shape[0],:ta.shape[1]];muR=rr['source_native_box'][0]+float(((px+.5)*al).sum()/al.sum());muT=tt['source_native_box'][0]+float(((tx+.5)*ta).sum()/ta.sum())
    ssx=(worldx-muR)/sx+muT;ssy=(worldy-(212.3+dy))/sy+214.3
    hi=map_coordinates(ta,[ssy-tt['source_native_box'][1]-.5,ssx-tt['source_native_box'][0]-.5],order=1,mode='constant',cval=0,prefilter=False);h,w=al.shape;aa=hi.reshape(h,sub,w,sub).mean((1,3));pred=np.clip(gaussian_filter(aa,sigma,mode='constant')+floor,0,1)
    rb=np.array(rr['source_iso_native_bbox']);bb=np.array(tt['source_iso_native_bbox']);rw=rb[2]-rb[0];rh=rb[3]-rb[1];tw=(bb[2]-bb[0])*sx;th=(bb[3]-bb[1])*sy;rm=al>.45;pm=pred>.45;sel=(al>.2)|(pred>.2)
    rec=dict(character=ch,source_caption_page=8,source_title_page=8,source_caption_native_box=rr['source_native_box'],source_title_native_box=tt['source_native_box'],
       original_source_only=True,same_fixed_common_scale=[sx,sy],same_fixed_baseline_dy=dy,no_per_character_shape_scale_or_rotation=True,horizontal_placement_centroid_only=True,
       source_caption_alpha=al.tolist(),title_transformed_alpha_at_native_resolution=pred.tolist(),
       alpha_RMSE=float(np.sqrt(np.mean((pred-al)**2))),alpha_MAE=float(np.mean(abs(pred-al))),signal_correlation=float(np.corrcoef(al[sel],pred[sel])[0,1]),IoU45=float((rm&pm).sum()/(rm|pm).sum()),
       source_caption_mass=float(al.sum()),transformed_title_mass=float(aa.sum()),mass_delta_percent=float((aa.sum()/al.sum()-1)*100),
       source_caption_mass_bbox_native_WH=[rw,rh],title_transformed_iso50_bbox_native_WH=[tw,th],title_vs_caption_bbox_delta_native=[tw-rw,th-rh],
       source_both_glyph_edges_each_uncertainty_native_px=.5,combined_bbox_measurement_uncertainty_native_px=1.,
       original_font_family_or_program_unknown=True,root_style_acceptance_pending=True)
    results.append(rec)
    src=Image.open(base/'DO BIEN GIU LUONG MUC NGUON'/(ch+'_4SA16-25 NGUON150dpi.png'));srcbig=src.resize((src.width*24,src.height*24),Image.Resampling.NEAREST);predimg=Image.fromarray((255-pred[:,:,None]*np.array([198,200,198])).clip(0,255).astype(np.uint8)).resize((w*24,h*24),Image.Resampling.NEAREST)
    title=Image.open(base/'CHU LON TIEU DE CUNG FILE CHI DOC'/(ch+' TIEU DE NGUON VA BIEN CHI XEM.png'));tile=Image.new('RGB',(1100,360),'white');tile.paste(srcbig,(20,40));tile.paste(predimg,(340,40));tile.paste(title.crop((0,0,360,330)),(700,10));tiles.append(tile);tile.save(fresh(root/(ch+' NGUON NHO LON DOI CHIEU CUNG BIEN DOI.png')))
    print(ch,'RMSE/CORR/IOU',rec['alpha_RMSE'],rec['signal_correlation'],rec['IoU45'],'MASS%',rec['mass_delta_percent'],'DW/DH',rec['title_vs_caption_bbox_delta_native'],flush=True)
sheet=Image.new('RGB',(1100,1800),'white')
for k,tile in enumerate(tiles):sheet.paste(tile,(0,k*360))
sheet.save(fresh(root/'5 CHU 4SA16 NGUON NHO LON DOI CHIEU.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==cap['source_sha256'] and sha(S.result(name))==cap['current_sha256']
Path(fresh(root/'5 CHU DOI CHIEU CUNG BIEN DOI KHONG DOI PHONG.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),
    same_fixed_transform_fitted_from4SA_applied_to1_and6=True,source_Perotac_X7_only=True,results=results,no_actual_font_program_to_assert_same_family=True,
    bigger4_not_selected_until_ROOT_style_check=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
