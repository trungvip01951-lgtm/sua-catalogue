from catwork import start,fresh
from pathlib import Path
import json,numpy as np
from scipy.signal import find_peaks
S,D,N=start()
from catfix import charts
j=S.job('Perotac bơm giếng SP_compressed (bản mới).pdf')
for p,r,qs,hs in [(4,(469,310,768,355),[6,12,18,24,30,36,42],[67,63,58,53,46,34,21]),(6,(275,340,370,400),[72,78],[103,72])]:
    cv=j.R.render_canvas(p,r,dpi=600);g=cv.gray()
    xx=[469.68,506.64,543.60,581.16,617.64,655.08,692.04,729.00,766.44] if p==4 else [71.88,93.24,114.12,135.48,156.72,177.84,198.96,220.08,241.20,262.32,283.68,305.04,326.16,347.28,368.40]
    ys=[313.72,337.24,360.76,383.8,407.32,430.84,453.88,477.4,500.44] if p==4 else [313.24,344.92,376.12,406.84,438.04,469.24,499.96]
    ch=charts.Chart.from_ticks([(i*6,x) for i,x in enumerate(xx)],[(i*(65 if p==4 else 50),y) for i,y in enumerate(ys)])
    print('PAGE',p+1)
    for q,h in zip(qs,hs):
        x=cv.to_px(*ch.to_page(q,h))[0];xc=int(round(x))+8
        v=255-np.mean(g[:,xc-2:xc+3],axis=1)
        peaks,_=find_peaks(v,prominence=10,distance=7)
        vals=[]
        for y in peaks:
            px,py=cv.to_page(xc,int(y));hh=float(ch.to_data(np.array([[px,py]]))[0,1])
            if abs(hh-h)<20:vals.append(dict(H=round(hh,2),score=round(float(v[y]),2),prominent=int(y)))
        print('Q',q,'Htable',h,vals,flush=True)
j.close()
