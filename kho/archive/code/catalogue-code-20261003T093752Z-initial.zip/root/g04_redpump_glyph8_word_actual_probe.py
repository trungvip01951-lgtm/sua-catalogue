"""Actual whole donor word 4SL4/28 in source, with coordinates before extraction."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));p=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17 V2.json').read_text(encoding='utf8'));src=p['method']['source'];cur=p['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[p['method']['source_SHA256'],p['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);request=[525.,391.,566.,403.];cv=R.render_canvas(4,request,dpi=600);rgb=cv.orig;pic=Image.new('RGB',(1300,420),'white');dr=ImageDraw.Draw(pic);raw=Image.fromarray(rgb);pic.paste(raw.resize((raw.width*3,raw.height*3),Image.Resampling.NEAREST),(20,45));dr.text((20,5),'Source p5 actual 4SL4/28: whole label, no new glyph',fill='blue')
for u in range(0,raw.width,20):dr.text((20+u*3,25),str(u),fill=(180,0,180))
for v in range(0,raw.height,10):dr.text((1,45+v*3),str(v),fill=(180,0,180))
photo=fresh(root/'CHU8 NGUON NGUYEN NHAN 4SL4_28 TOA DO.png');pic.save(photo);Path(fresh(root/'CHU8 NGUON NGUYEN NHAN 4SL4_28 TOA DO.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],source_page=5,source_word='4SL4/28',source_render_request_rect=request,source_actual_rect=list(cv.rect0),source_canvas_RGB_SHA256=hashlib.sha256(rgb.tobytes()).hexdigest(),source_native_font_samefile=True,photo=photo,PDF_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('True whole source4SL4/28 glyph8 context; noPDF',flush=True)
