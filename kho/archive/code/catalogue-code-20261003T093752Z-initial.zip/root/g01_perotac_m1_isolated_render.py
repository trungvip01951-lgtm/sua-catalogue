"""One untouched PDF, one fresh process, one image render, exact pixel comparison."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
import fitz
import numpy as np
from PIL import Image
page=int(sys.argv[1]);kind=sys.argv[2];dpi=int(sys.argv[3])
assert page in [1,4,6] and (kind,dpi) in [('whole',150),('photo',150),('photo',600)]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads(Path(S.report('G08/ROOT PHAT HANH MOT PDF ANH V5 CA8 TRANG/ROOT KHOA MOT PDF ANH M1 V5.json')).read_text(encoding='utf8'))
job=next(j for j in lock['jobs8'] if j['page']==page)
root=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs')
pdf=root/'per_wc_continue_photo_union_v5_PDF_mau1_a1'/'Catalog cắt rác perotac (bản mới).pdf'
assert sha(pdf)=='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee'
out=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_PDF M1 V5 DOC LAP DU8 TRANG'))
before=Path(fresh(out/f'g01_ISOLATED p{page:02d} {kind} {dpi}dpi.png'))
with fitz.open(str(pdf)) as doc:
 p=doc[page-1].get_pixmap(dpi=dpi,clip=fitz.Rect(job['allowed_photo_rect_top_fixed_before_RAM']) if kind=='photo' else None,colorspace=fitz.csRGB,alpha=False)
 p.save(str(before));a=np.frombuffer(p.samples,np.uint8).reshape(p.height,p.width,p.n)
ram=root/'per_wc_continue_photo_union_v5_RAM_a1'
rp=next(ram.glob(f'*group{job["group"]}_p{page:02d}_RAM_{"photo" if kind=="photo" else "whole_page"}_{dpi}dpi.png'))
old=out/f'g01_PDF THUC p{page:02d} {kind} {dpi}dpi.png'
def compare(path):
 b=np.array(Image.open(path).convert('RGB'));assert a.shape==b.shape
 changed=np.any(a!=b,axis=2);n=int(changed.sum())
 if n:
  y,x=np.nonzero(changed);box=[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)]
 else:box=None
 return {'other_file':str(path),'other_SHA':sha(path),'pixel_equal':n==0,'changed_pixels_threshold0':n,'changed_bbox':box,'max_channel_difference':int(np.abs(a.astype(np.int16)-b.astype(np.int16)).max()),'entire_image_threshold0_no_relaxed_ROI':True}
result={'process_mode':'one new OS process, BƯỚC0 then only one PDF open and one render; no other PDF touched in this process','page':page,'group':job['group'],'kind':kind,'dpi':dpi,'colorspace':'DeviceRGB','alpha':False,'actual_PDF_SHA':sha(pdf),'image':str(before),'image_SHA':sha(before),'RAM_reference_comparison':compare(rp),'prior_fresh_doc_in_shared_process_comparison':compare(old),'no_PDF_write_or_image_retouch':True}
jp=Path(fresh(out/f'g01_ISOLATED p{page:02d} {kind} {dpi}dpi.json'));jp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'page':page,'kind':kind,'dpi':dpi,'RAM':result['RAM_reference_comparison'],'shared':result['prior_fresh_doc_in_shared_process_comparison'],'JSON':str(jp),'JSON_SHA':sha(jp)},ensure_ascii=False))
