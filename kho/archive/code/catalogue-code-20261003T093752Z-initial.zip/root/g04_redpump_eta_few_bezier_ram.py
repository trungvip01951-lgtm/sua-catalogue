"""ROOT requested source-constrained few-piece eta RAM plans. NO PDF/M2 writes."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.interpolate import BSpline,PPoly
import pymupdf as fitz
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.cs import Instr,Num
from catfix import verify
root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
pr=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
b=json.loads((root/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'));a=json.loads((root/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json').read_text(encoding='utf8'))
source=json.loads((pr/'ETA DOC NET NGUON RIENG.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guard=[sha(b['source']),sha(b['input_current']),sha(b['sample'])];assert guard==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
xy=np.array(source['source_observed_page_points']);x,y=xy.T;L=x[-1]-x[0];t=(x-x[0])/L
native=np.array(source['source_native_ctm']);shape=source['source_native_image_size']
native_pixel_pt=float(native[0,0]/shape[0]);assert abs(native_pixel_pt-.4801362852213916)<1e-8
tests=[];passing=[]
for pieces in [1,2,3,4]:
 inner=np.linspace(0,1,pieces+1)[1:-1];knots=np.r_[np.zeros(4),inner,np.ones(4)]
 matrix=BSpline.design_matrix(t,knots,3).toarray();count=matrix.shape[1]
 rhs=y-matrix[:,0]*y[0]-matrix[:,-1]*y[-1]
 coeff=np.r_[y[0],np.linalg.lstsq(matrix[:,1:-1],rhs,rcond=None)[0],y[-1]]
 f=BSpline(knots,coeff,3,extrapolate=False);pp=PPoly.from_spline((knots,coeff,3));res=f(t)-y
 roots=pp.derivative().roots(extrapolate=False);roots=sorted(set(float(z) for z in roots if 1e-9<z<1-1e-9))
 peak=None;positive_start=float(f.derivative()(0))>0;negative_end=float(f.derivative()(1))<0
 grid_t=np.linspace(0,1,2001);der=np.asarray(f.derivative()(grid_t))
 shape_ok=len(roots)==1 and positive_start and negative_end and np.all(der[grid_t<roots[0]]>=-1e-9) and np.all(der[grid_t>roots[0]]<=1e-9)
 record=dict(pieces=pieces,max_source_center_error_pt=float(max(abs(res))),RMS_source_center_error_pt=float(np.sqrt(np.mean(res**2))),
  max_error_native_pixels=float(max(abs(res))/native_pixel_pt),observed_native_pixel_size_pt=native_pixel_pt,
  comparison_limit_pt=native_pixel_pt,one_increase_then_decrease_peak=bool(shape_ok),derivative_roots_normalized=roots,
  source_first_last_fixed=True,numeric_eta_status='CHƯA THỂ: không có bảngη; chỉ so hình học sourcecenters.',
  within_one_observed_native_pixel=bool(max(abs(res))<=native_pixel_pt),PDF_written=False)
 tests.append(record)
 if shape_ok and max(abs(res))<=native_pixel_pt:
  physical_knots=x[0]+np.linspace(0,1,pieces+1)*L;path=[('m',[xy[0].tolist()])];segments=[];joins=[]
  for u,v in zip(physical_knots,physical_knots[1:]):
   t0=(u-x[0])/L;t1=(v-x[0])/L;d=(v-u)/3
   y0=float(f(t0));y1=float(f(t1));dy0=float(f.derivative()(t0))/L;dy1=float(f.derivative()(t1))/L
   cp=[[float(u),y0],[float(u+d),float(y0+d*dy0)],[float(v-d),float(y1-d*dy1)],[float(v),y1]]
   path.append(('c',cp[1:]));segments.append(dict(page_Bezier=cp,x_interval=[float(u),float(v)],
    source_observed_points_in_span=int(((x>=u-1e-9)&(x<=v+1e-9)).sum()),
    endpoint_dy_dx=[dy0,dy1],endpoint_d2y_dx2=[float(f.derivative(2)(t0))/L**2,float(f.derivative(2)(t1))/L**2]))
  for left,right in zip(segments,segments[1:]):
   joins.append(dict(join_page=left['page_Bezier'][-1],position_difference_pt=float(np.max(abs(np.array(left['page_Bezier'][-1])-np.array(right['page_Bezier'][0])))),
    slope_difference=abs(left['endpoint_dy_dx'][-1]-right['endpoint_dy_dx'][0]),
    second_derivative_difference=abs(left['endpoint_d2y_dx2'][-1]-right['endpoint_d2y_dx2'][0]),C2_continuous=True))
  record.update(path=path,segments=segments,joins=joins,source_551_residuals_pt=res.tolist(),
   peak_page=[float(x[0]+roots[0]*L),float(f(roots[0]))],status='ỨNG VIÊN RAM ĐỦ GIỚI HẠN HÌNH/1PIXEL; không phải sốηĐẠT.')
  passing.append(record)
assert passing,tests
# Render at most the two least-piece passing candidates, both only in RAM.
rendered=[]
for candidate in passing[:2]:
 E=Editor(b['sample'],backend='fitz');P=E.page(7);oi=a['eta_actual']['actual_object'];obj=P.objs[oi]
 assert obj['op']=='S' and abs(obj['lw']-.95)<1e-9
 old_path=P.object_pagepath(oi);assert len(old_path)>len(candidate['path'])
 E.delete_instrs(7,list(range(obj['i0'],obj['i1'])))
 E.insert_instrs(7,obj['i1'],[Instr([Num(float(v)) for p in pts for v in p],op) for op,pts in candidate['path']],before=True)
 E.doc.set_page_content(7,E.build(7));E.pages.clear()
 PP=E.page(7);oo=PP.objs[oi];actual=PP.object_pagepath(oi);assert len(actual)==candidate['pieces']+1
 segments=[];pos=None
 for op,pts in actual:
  if op=='m':pos=np.array(pts[0])
  elif op=='c':segments.append(np.vstack([pos,pts]));pos=np.array(pts[-1])
 def bez(z,t):return (1-t)**3*z[0]+3*(1-t)**2*t*z[1]+3*(1-t)*t*t*z[2]+t**3*z[3]
 def aty(px):
  z=next(z for z in segments if z[0,0]-1e-7<=px<=z[-1,0]+1e-7);lo=0.;hi=1.
  for _ in range(64):
   tt=(lo+hi)/2
   if bez(z,tt)[0]<px:lo=tt
   else:hi=tt
  return bez(z,(lo+hi)/2)
 rr=np.array([aty(px)[1] for px in x])-y
 assert max(abs(rr))<=native_pixel_pt and np.max(abs(segments[0][0]-xy[0]))<1e-8 and np.max(abs(segments[-1][-1]-xy[-1]))<1e-8
 images=[]
 for dpi in [150,600]:
  rect=[55.5,268.5,330.,317.6];pg=E.doc.doc[7];T=pg.transformation_matrix;p0=fitz.Point(rect[0],rect[1])*T;p1=fitz.Point(rect[2],rect[3])*T
  clip=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y));pix=pg.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=clip,colorspace=fitz.csRGB,alpha=False)
  arr=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[:,:,:3].copy()
  path=fresh(root/f'ETA RAM {candidate["pieces"]} BEZIER {dpi}dpi KHONG PDF2.png');Image.fromarray(arr).save(path);images.append(path)
  old=np.asarray(verify.crop(b['sample'],7,rect,dpi));orig=np.asarray(verify.crop(b['input_current'],7,rect,dpi));assert arr.shape==old.shape==orig.shape
  header=36;sheet=Image.new('RGB',(arr.shape[1],3*(arr.shape[0]+header)),'white');dr=ImageDraw.Draw(sheet);font=verify._font(18)
  captions=['Nguồn/bản giao: đường ảnh nén','PDF MẪU1: sát551tâm, còn gợn',f'ỨNG VIÊN RAM {candidate["pieces"]} Bézier — KHÔNG PDFmẫu2']
  for i,v in enumerate([orig,old,arr]):
   dr.text((4,i*(arr.shape[0]+header)+3),captions[i],fill='blue',font=font);sheet.paste(Image.fromarray(v),(0,i*(arr.shape[0]+header)+header))
  comb=fresh(root/f'ETA RAM {candidate["pieces"]} DO NGUON M1 {dpi}dpi KHONG PDF2.png');sheet.save(comb);images.append(comb)
 candidate.update(actual_RAM_path=actual,actual_RAM_max_source_center_error_pt=float(max(abs(rr))),
  actual_RAM_RMS_error_pt=float(np.sqrt(np.mean(rr**2))),actual_RAM_source_endpoints_exact=True,images=images)
 rendered.append(candidate);E.close()
out=dict(source=b['source'],source_SHA256=guard[0],current=b['input_current'],current_SHA256=guard[1],M1=b['sample'],M1_SHA256=guard[2],
 observed_points=551,source_native_pixel_pt=native_pixel_pt,limit_native_pixels=1,limit_pt=native_pixel_pt,
 uncertainty_basis='Ảnh gốc1739×1237 phủ834,957×593,928pt:1pixel≈0,480136pt. Tâm từ mựcJPEG/lưới có lượngtử hóa; ±1pixel là bấtđịnhhình ảnh thật, không dùng làm sai số sốη. Vẫn đọcđủ551tâm và giữđầucuối quan sát, khônggóc giả.',
 fit_trials=tests,RAM_rendered_candidates=rendered,least_piece_candidate=rendered[0]['pieces'],
 numeric_eta_accuracy='CHƯA THỂ: không có bảngη.',PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False,
 accepted=False,status='PHƯƠNG ÁN η ÍT BÉZIER / ẢNH RAM ĐỂ ROOT–ĐỒ HỌA CHỌN; chưa PDF2.')
Path(fresh(root/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert guard==[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
print('RAM fits',[(z['pieces'],z['max_source_center_error_pt'],z['one_increase_then_decrease_peak'],z['within_one_observed_native_pixel']) for z in tests],'rendered',[(z['pieces'],z['actual_RAM_max_source_center_error_pt']) for z in rendered],'NO PDF2',flush=True)
