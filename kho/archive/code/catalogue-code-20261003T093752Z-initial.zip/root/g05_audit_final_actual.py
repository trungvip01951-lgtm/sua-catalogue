"""Đọc actualpaths của bản giao; không sửaPDF. ĐínhchínhcờXMP của hồsơgiao.
Nguồn khôngcóXMP thìkhôngcó streamđểkhôi phục;final cũngphảikhôngcó.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,csv,hashlib,numpy as np,pymupdf as fitz
from catfix.vector import Editor
from catfix import verify,charts
from g05_audit_manual_data import TABLES

name='Perotac bơm giếng SP_compressed (bản mới).pdf';final=S.dst(name);source=S.src(name)
O='G05/GIAO BAN SAU SUA DUONG/'
proof=json.loads(Path(S.report(O+'NGHIEM THU PDF GIAO.json')).read_text(encoding='utf8'))
old=json.loads(Path(S.report('G05/MAU PDF SUA DUONG/DOC LAI DUONG THAT VA BAO TOAN.json')).read_text(encoding='utf8'))
axes={p['family']:p for p in json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))}
E=Editor(final);points=[];styles=[]
def y_at(path,x):
 cur=None
 for op,p in path:
  if op=='m':cur=np.array(p[0]);continue
  if op=='c':
   ctrl=np.vstack([cur,np.array(p)]);end=ctrl[-1]
   if cur[0]-1e-5<=x<=end[0]+1e-5:
    lo=0.;hi=1.
    for _ in range(70):
     t=(lo+hi)/2;v=(1-t)**3*ctrl[0]+3*(1-t)**2*t*ctrl[1]+3*(1-t)*t*t*ctrl[2]+t**3*ctrl[3]
     if v[0]<x:lo=t
     else:hi=t
    return float(v[1])
   cur=end
 raise ValueError((x,'Khôngcóxtrongactualpath'))
for c in old['curve_actual_styles']:
 P=E.page(c['page']-1);oi=c['actual_object'];o=P.objs[oi];assert o['op']=='S'
 rgb=list(P.color_of(oi,'stroke'));assert rgb==c['stroke_rgb'] and o['lw']==c['width_pt'] and np.max(abs(o['ctm']-np.array(c['matrix'])))<1e-8 and str(o['dash'])==c['dash']
 path=P.object_pagepath(oi);sample=charts.sample_path(path,n=200)
 family=c['model'].split('-')[0];b=axes[family];xt=np.array(b['xticks']);yt=np.array(b['yticks']);row=next(r for r in TABLES[family]['rows'] if r['curve_model']==c['model'])
 for q in c['new_Q']:
  x=float(np.interp(q,xt[:,0],xt[:,1]));h=float(np.interp(y_at(path,x),yt[:,1],yt[:,0]));target=row['H'][TABLES[family]['Q'].index(q)];dev=abs(h-target);assert dev<1e-4
  previous=next(p for p in old['points'] if p['model']==c['model'] and p['Q']==q);assert abs(h-previous['H_actual_PDF'])<1e-8
  points.append(dict(page=c['page'],model=c['model'],object_index=oi,Q=q,H_table=target,H_actual_final=h,deviation_m=dev,tolerance_m=max(1,.02*target),status='ĐẠT'))
 styles.append(dict(page=c['page'],model=c['model'],actual_object=oi,stroke_rgb=rgb,width_pt=o['lw'],dash=str(o['dash']),matrix=o['ctm'].tolist(),start=sample[0].tolist(),end=sample[-1].tolist(),same_style_as_root_approved_sample=True))
def resource(p):
 d=fitz.open(p);xr=d.xref_xml_metadata();xmp=d.xref_stream(xr) if xr else None
 z=dict(pages=len(d),rect=[list(p.rect) for p in d],font=[sorted((f[3],hashlib.sha256(d.extract_font(f[0])[3]).hexdigest()) for f in p.get_fonts(full=True)) for p in d],images=[sorted(hashlib.sha256(d.xref_stream_raw(i[0])).hexdigest() for i in p.get_images(full=True)) for p in d],info=d.metadata,toc=d.get_toc(simple=False),links=[p.get_links() for p in d],xmp=xmp,has_xmp=xr>0);d.close();return z
a=resource(source);b=resource(final);pres={k:a[k]==b[k] for k in ['pages','rect','font','info','toc','links','xmp']};pres['original_images_preserved']=all(set(x)<=set(y) for x,y in zip(a['images'],b['images']));assert all(pres.values()),pres
modelocr=verify.ocr_check(final,5,(95,43,121.5,49),'6SP36-28');assert modelocr['ok']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(final)==proof['final_sha256'] and sha(source)==proof['source_sha256']
out=dict(final=final,final_sha256=sha(final),source_sha256=sha(source),new_actual_curve_count=len(styles),new_actual_point_count=len(points),max_actual_deviation_m=max(p['deviation_m'] for p in points),points=points,styles=styles,preservation=pres,source_has_xmp=a['has_xmp'],final_has_xmp=b['has_xmp'],raw_xmp_equal=pres['xmp'],modelrow20_ocr=modelocr,xmp_record_correction='NGHIEM THU PDF GIAO.json cờmetadata_raw_xmp_restored đượcghiTruecốđịnh. Nguồn/finalthậtđều khôngcóXMP; raw_xmp_equal=True, khôngcóstreamđểkhôiphục. Đínhchínhcờrestored=False; giữbáocáocũlàmhồsơ.',group_status='CHƯA XONG')
assert len(styles)==26 and len(points)==52
Path(fresh(S.report(O+'DOC LAI ACTUAL PDF GIAO VA DINH CHINH XMP.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(S.report(O+'52 MOC ACTUAL PDF GIAO.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,list(points[0]));w.writeheader();w.writerows(points)
E.close();print('FINAL_ACTUAL',len(styles),len(points),'maxdev',out['max_actual_deviation_m'],'sourceXMP',a['has_xmp'],'finalXMP',b['has_xmp'],'preservation',pres,flush=True)
