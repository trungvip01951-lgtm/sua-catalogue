"""Mẫu1 cách2: chuyển tiết diện mực nguồn, tâm trơn, đầu-cuối thật.
Giữ nguyên ảnh gốc và không ghi PDF; chỉ tạo PNG, mảng pixel, số đo.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.interpolate import UnivariateSpline,PchipInterpolator,CubicHermiteSpline
from scipy.ndimage import gaussian_filter1d
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib

P='G05/KIEM TOAN TOAN BO/';O='G05/MAU SUA DUONG/PHUONG PHAP 2 - CHUYEN TIET DIEN MUC/MAU 1/'
axes=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
audit=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'))
name='Perotac bơm giếng SP_compressed (bản mới).pdf';dest=S.dst(name)
before=hashlib.sha256(Path(dest).read_bytes()).hexdigest();assert before==audit['output_sha256']
E=Editor(dest);R=Raster(E);out=[]
for fam,startq in [('6SP30',30),('6SP60',66)]:
 b=next(z for z in axes if z['family']==fam);t=TABLES[fam];n=len(t['rows'])
 im=R.image_at(b['page']-1,(b['x0'],b['y0'],b['x1'],b['y1']));cv=R.canvas(im);a=cv.orig.copy();bg=a.copy()
 xt=np.array(b['xticks']);yt=np.array(b['yticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]));qx=lambda x:float(np.interp(x,xt[:,1],xt[:,0]))
 nativeX=lambda x:float(cv.to_px(x,b['y0'])[0]);nativeY=lambda y:float(cv.to_px(b['x0'],y)[1]);pageY=lambda y:float(cv.to_page(0,y)[1])
 xp0=nativeX(b['x0']);xp1=nativeX(b['x1']);yp0=nativeY(b['y1']);yp1=nativeY(b['y0'])
 xbeg=nativeX(px(startq));xend=nativeX(px(t['Q'][-1]));xlo=int(np.ceil(xbeg));xhi=int(np.ceil(xend+12));ylo=int(np.ceil(yp0+3));yhi=int(np.floor(yp1-3))
 native_pt=abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]);models=[]
 for k,row in enumerate(t['rows']):
  ps=[z for z in audit['points'] if z['family']==fam and z['row']==k+1 and z.get('H_curve_m') is not None]
  raw=[]
  for p in ps:
   for z in p['sample_locations']:
    xx=b['rect'][0]+z['x_px']*72/b['dpi'];yy=b['rect'][3]-z['y_px']*72/b['dpi'];raw.append((nativeX(xx),nativeY(yy)))
  bins={}
  for x,y in raw:bins.setdefault(round(x,4),[]).append(y)
  sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx]);spl=UnivariateSpline(sx,sy,s=len(sx)*.06,k=3);res=float(np.max(abs(spl(sx)-sy)))
  assert res<1.0,(fam,row['curve_model'],res)
  models.append(dict(row=row,spl=spl,rank=k+1,samples=len(raw),res=res))
 body=a[int(np.ceil(yp0+3)):int(np.floor(yp1-3)),int(np.ceil(xp0+5)):int(np.floor(xp1-5))].astype(float);vp=np.median(body,axis=0);hp=np.median(body,axis=1);base=np.percentile(body.reshape(-1,3),98,axis=0)
 gridYs=np.array([nativeY(v) for h,v in b['yticks']]);gridXs=np.array([nativeX(v) for q,v in b['xticks']])
 def background(x,ys):
  yy=np.clip(np.round(ys).astype(int)-int(np.ceil(yp0+3)),0,len(hp)-1);xx=int(np.clip(round(x)-int(np.ceil(xp0+5)),0,len(vp)-1))
  hv=np.tile(base,(len(yy),1));use=np.min(abs(np.asarray(ys)[:,None]-gridYs),axis=1)<=3.0;hv[use]=hp[yy[use]]
  return np.minimum(hv,vp[xx])
 tube=np.zeros(a.shape[:2],bool)
 for x in range(xlo,xhi+1):
  for m in models:
   yc=float(m['spl'](min(x,xend)));lo=max(ylo,int(np.floor(yc-13)));hi=min(yhi,int(np.ceil(yc+13)));tube[lo:hi+1,x]=True
  ys=np.nonzero(tube[:,x])[0]
  if len(ys):bg[ys,x]=np.clip(np.round(background(x,ys)),0,255).astype(np.uint8)
 # Source gray stroke profiles are extracted on every actual source column,
 # ranked independently from the source labels, normalized to their real centroid.
 profile_x=np.arange(max(int(xp0)+8,xlo-28),min(a.shape[1]-1,int(xend)-2)+1)
 offsets=np.linspace(-5,5,161);dy=offsets[1]-offsets[0]
 profile_all=[];checks=[]
 for k,m in enumerate(models):
  prof=[];centroid_d=[];area0=[]
  for x in profile_x:
   centres=np.array([float(mm['spl'](x)) for mm in models]);pred=centres[k];nearest=float(np.min(abs(np.delete(centres,k)-pred)));radius=min(3.0,max(.9,nearest*.44))
   ys=np.arange(int(np.floor(pred-radius)),int(np.ceil(pred+radius))+1);orig=a[ys,x].astype(float);back=background(x,ys);d=np.maximum(0,back-orig)
   wt=d.mean(1)**2;ctr=float(np.sum((ys+.5)*wt)/max(wt.sum(),1e-9));centroid_d.append(ctr-pred)
   # Smooth normalized profiles, not raw per-column displaced RGB blocks.
   slope=float(m['spl'].derivative()(x));stretch=np.sqrt(1+slope*slope);pos=ctr+offsets*stretch
   data=np.array([np.interp(pos,ys+.5,d[:,c],left=0,right=0) for c in range(3)]).T
   prof.append(data);area0.append(float(data.mean(1).sum()*dy))
  prof=np.array(prof);prof=gaussian_filter1d(prof,2.0,axis=0,mode='nearest');profile_all.append(prof)
  checks.append(dict(curve_model=m['row']['curve_model'],rank=k+1,source_column_count=len(profile_x),source_rank_fit_residual_max_native_px=m['res'],centroid_adjust_abs_p95_native_px=float(np.percentile(abs(np.array(centroid_d)),95)),mean_source_profile_ink_area=float(np.mean(area0)),median_source_profile_core_rgb=(255-np.percentile(prof,95,axis=(0,1))).tolist()))
 r=b['rect'];step=72/b['dpi'];srcim=Image.open(S.report(P+fam+'-bieu-do-du-truc.png')).convert('RGB');source600=np.array(srcim);clean=source600.copy();H,W=clean.shape[:2]
 xs=r[0]+(np.arange(W)+.5)*step;ys=r[3]-(np.arange(H)+.5)*step
 ux=(xs-im.ctm[2,0])/im.ctm[0,0]*im.W;vy=(1-(ys-im.ctm[2,1])/im.ctm[1,1])*im.H;iu=np.clip(np.floor(ux).astype(int),0,a.shape[1]-1);iv=np.clip(np.floor(vy).astype(int),0,a.shape[0]-1)
 m600=tube[iv[:,None],iu[None,:]];clean[m600]=bg[iv[:,None],iu[None,:]][m600]
 Image.fromarray(clean).save(fresh(S.report(O+fam+'-nen-da-tach.png')))
 output=clean.copy();add=np.zeros(clean.shape,dtype=np.float32);shape_rows=[]
 for k,m in enumerate(models):
  row=m['row'];tx=np.array([px(q) for q in t['Q']]);ty=np.array([py(h) for h in row['H']]);target=PchipInterpolator(tx,ty)
  xjoin=cv.to_page(xlo,0)[0];qjoin=qx(xjoin);yjoin=pageY(m['spl'](xlo));djoin=-float(m['spl'].derivative()(xlo));idx=np.where(tx>xjoin+1e-7)[0];xf=tx[idx[0]];yf=ty[idx[0]];bridge=CubicHermiteSpline([xjoin,xf],[yjoin,yf],[djoin,float(target.derivative()(xf))])
  # Integrate the source ink cross section along a continuous final center.
  sel=np.where((xs>=xjoin)&(xs<=tx[-1]))[0]
  for ii in sel:
   x=xs[ii];f=bridge if x<xf else target;yc=float(f(x));ds=float(f.derivative()(x));yn=nativeY(yc);stretch=np.sqrt(1+ds*ds);lo=max(0,int(np.floor((r[3]-yc)/step-5.2*native_pt*stretch/step)));hi=min(H,int(np.ceil((r[3]-yc)/step+5.2*native_pt*stretch/step)))
   inds=np.arange(lo,hi);normal=(vy[inds]-yn)/stretch
   sxn=float(np.clip(ux[ii],profile_x[0],profile_x[-1]));j0=int(np.floor(sxn-profile_x[0]));j1=min(len(profile_x)-1,j0+1);frac=sxn-profile_x[0]-j0;profile=profile_all[k][j0]*(1-frac)+profile_all[k][j1]*frac
   delta=np.array([np.interp(normal,offsets,profile[:,c],left=0,right=0) for c in range(3)]).T
   # Seam blends only the first0.6nativepx; final real Q endpoints kept exact.
   blend=float(np.clip((ux[ii]-xlo)/.6,0,1));delta*=blend
   add[inds,ii]=np.maximum(add[inds,ii],delta)
  changed=add>1.8
  controls=[];knots=np.r_[xjoin,tx[idx]]
  for il,(xa,xb) in enumerate(zip(knots[:-1],knots[1:])):
   f=bridge if il==0 else target;h=xb-xa;ya=float(f(xa));yb=float(f(xb));da=float(f.derivative()(xa));db=float(f.derivative()(xb));controls.append([[float(xa),ya],[float(xa+h/3),ya+da*h/3],[float(xb-h/3),yb-db*h/3],[float(xb),yb]])
  shape_rows.append(dict(curve_model=row['curve_model'],rank=k+1,Q=t['Q'],H_table=row['H'],Q_join=qjoin,kept_Q=[float(q) for q in t['Q'] if px(q)<xjoin],new_Q=[float(q) for q in t['Q'] if px(q)>=xjoin],start_page=[float(xjoin),float(yjoin)],end_page=[float(tx[-1]),float(ty[-1])],actual_end_Q=t['Q'][-1],segments=controls,style=checks[k]))
 # New curves are carried as native sampled ink; no font/color/line drawn anew.
 nz=np.any(add>1.8,axis=2);output[nz]=np.clip(np.round(clean[nz].astype(float)-add[nz]),0,255).astype(np.uint8)
 Image.fromarray(output).save(fresh(S.report(O+fam+'-sau.png')));srcim.save(fresh(S.report(O+fam+'-truoc.png')))
 np.savez_compressed(fresh(S.report(O+fam+'-miếng-anh-600dpi.npz')),orig=source600,output=output)
 out.append(dict(family=fam,page=b['page'],rect=r,dpi=b['dpi'],image_index=im.index,source_image_key=im.key,actual_end_Q=t['Q'][-1],keep_left_labels_and_dashes=True,patch_pixel_count=int(np.any(output!=source600,axis=2).sum()),curves=shape_rows,method='Actual source ink cross-sections, independent source rank, centroid normalized, smoothed along x, normal-width adjusted to final slope; source labels/dashes unchanged; actual endpoint.',status='MẪU CHƯA NGHIỆM THU',pdf_written=False))
 print('Mẫu chuyển tiết diện',fam,'new knots',len(shape_rows)*len(shape_rows[0]['new_Q']),'changed px',out[-1]['patch_pixel_count'],flush=True)
assert hashlib.sha256(Path(dest).read_bytes()).hexdigest()==before
Path(fresh(S.report(O+'TOA DO VA PHUONG PHAP.json'))).write_text(json.dumps(dict(source_sha256=audit['source_sha256'],before_pdf_sha256=before,pdf_unchanged=True,panels=out),ensure_ascii=False,indent=2),encoding='utf8');E.close()
print('PNG đã lưu, PDF chưa ghi',flush=True)
