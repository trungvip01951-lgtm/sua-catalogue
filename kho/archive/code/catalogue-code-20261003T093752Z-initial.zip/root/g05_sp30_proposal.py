"""Lập phương án cụ thể trước vẽ, chỉ ghi báo cáo/tiến độ."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib
O='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
d=json.loads(Path(S.report(O+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'))
ink=json.loads(Path(S.report(O+'DO MUC JPEG NGUON 13 MAY.json')).read_text(encoding='utf8'))
assert hashlib.sha256(Path(d['current_path']).read_bytes()).hexdigest()==d['current_sha256']
assert hashlib.sha256(Path(d['source_path']).read_bytes()).hexdigest()==d['source_sha256']
with open(fresh(S.report(O+'DINH CHINH DOC ANH V1.md')),'w',encoding='utf8') as fp:
 fp.write('Lượt DOC NGUON đầu là chẩn đoán bị loại. R.image_at trên bản đã sửa chọn CfxPatch2 có SMask (mặt nạ độ che phủ), 600dpi; không phải JPEG gốc. Mọi số màu/cỡ/chữ của lượt đầu KHÔNG được dùng để sửa hay nghiệm thu. DOC NGUON V2 chọn X7 từ PDF nguồn, 1732×1240, khoảng150dpi, mỗi điểm ảnh0,480115pt. Bản giao7335… và nguồn không đổi. V2 cũng thay phép fit dao động trong miền thiếu mẫu bằng nội suy đơn điệu qua số H nét nguồn đọc độc lập; các tâm/độ dốc nối vẫn chỉ là khảo sát, phải lấy lại tiết diện nguồn thật trước tạo mẫu.\n')
lines=['# G05 – phương án trước mẫu: 29 mốc trái 6SP30','',
 'Phạm vi: chỉ 13 đường có danh tính chắc và 29 mốc đã lệch chắc trên đúng PDF giao. Chưa vẽ đường mới, chưa ghi PDF. Bản giao giữ mã kiểm tra '+d['current_sha256']+'.','',
 'Mỗi dòng dưới đây đã có nhãn nguồn nhìn thật, bảng Q/H đầy đủ và ảnh gốc; danh tính không được suy từ khoảng cách tới H bảng. Nguồn6SP30-9/bảng6SP30-8 giữ cả nét và nhãn, 8mốc đều CHƯA THỂ. 4SP14/4SP15 ngoài phạm vi.','',
 '| Mẫu máy | Các Q lệch chắc (m³/h) | Q đầy đủ (m³/h) | H bảng đầy đủ (m) |',
 '|---|---|---|---|']
for z in d['models']:lines.append('| '+z['model']+' | '+','.join(map(str,z['known_bad_Q']))+' | '+','.join(map(str,z['Q']))+' | '+','.join(map(str,z['H_table']))+' |')
lines.extend(['',
 'Cách đề xuất: bảo vệ nét chữ thành một lớp điểm ảnh gốc riêng; tách chỉ mực đường thuộc từng nhãn đã xác định; dựng đường PDF trơn liên tục qua số bảng. Đây là xử lý lớp chữ + lớp đường với mặt nạ điểm ảnh, khác cách dời từng cột RGB và khác cách xoá nguyên ống nét rồi vẽ đè đã làm gập đường hoặc để quầng. RGB nghĩa là ba kênh đỏ–lục–lam; mặt nạ chỉ quy định những điểm ảnh thật được đổi.','',
 '1. Giữ ảnh JPEG gốc và các lớp đã sửa của bản7335…; mọi việc bắt đầu từ bản này. Lấy màu/cỡ từ chính JPEG1732×1240 của nguồn, không từ ảnh vá600dpi.','',
 '2. Lập mặt nạ nét chữ của đủ19nhãn trên chính ảnh nguồn, đối chiếu từng ký tự/cả viền mờ bằng mắt. Dùng vùng hình học và nét thật; màu chữ/màu đường có phần trùng nên không chấp nhận phân loại theo ngưỡng màu đơn thuần. Điểm ảnh chữ được khóa: lớp nền không được xóa/chạm, đường mới không được phủ; nếu một điểm ảnh không tách được hai loại mực thì giữ và đánh dấu chưa thể, không tạo chữ/font khác. Font nghĩa là kiểu chữ. Chưa chốt mặt nạ chỉ từ KHOANG CACH CHU NET - CHI KHAO SAT.json.','',
 '3. Chọn điểm nối theo tiết diện/tâm nét nguồn thật ngay khi có khoảng trống an toàn dưới chữ. Với -5/-10 ưu tiên sau toàn nhãn (≈Q16); với -13/-15 có thể nối sauQ18 vì chỉQ24 lệch chắc; các9modelcao cần nối sớm trong miền dưới nhãn để tránh ép gập gầnQ18. Điểm nối và tiếp tuyến lấy từ nét nguồn theo nhãn/rank, không lấy H bảng để chọn nét. Rank nghĩa là thứ tự đường đã xác định bằng nhãn. Trước duyệt mẫu phải chứng minh nối trơn và không phạm nét chữ.','',
 '4. Thay nét từ điểm nối tớiQ42 qua các Q có số thật18/24/30/36/42 phù hợp miền; không thêm mốc trống. Đo lại cả8mốc mỗi hàng. Mọi Q/H,67 của#47 và433 ởH0 hàng-38 giữ nguyên. Dùng đường Bézier (đường trơn theo các điểm điều khiển) có tiếp tuyến liên tục; giảm độ uốn bất thường bằng ràng buộc đơn điệu, không chọn đường gần H bảng để nhận dạng.','',
 '5. Phải thay đồng bộ đoạn nốiQ30→36 hiện có: đầuQ≈30 của đoạn cũ còn theo H nguồn sai. Các điểmQ36/Q42 đã đạt giữ cùng số. Đề xuất dựng một nét cùng màu/độ dày từ điểm nối→Q42 cho mỗi13model, thay cả phần đuôi của đúng13model này để tránh mối nối độ dày0,48pt với nét nguồn tương đương≈0,75–0,82pt. 3đuôiSP30khác và10đuôiSP60 đã duyệt không thuộc phạm vi. Việc thay kiểu nét13đuôi phải được ROOT xem mẫu trước; không tự nâng phạm vi.','',
 '6. Độ rộng lấy từ lượng mực vuông góc nguồn theo từngmodel; không đặt0,48 cố định. Đã đọc tổng'+str(sum(z['number_of_native_profiles'] for z in ink['curves']))+'tiết diện, tránhlưới/nétlâncận. Lõi20%tối nhất; tổngalpha×kíchthướcđiểmảnh/sqrt(1+độdốc²). Alpha là phần che phủ mực. Do JPEG150dpi và quy ước tách mực, đây là độ rộng tương đương nguồn; không tuyên bố biết bút PDF nguyên thủy.','',
 '| Mẫu máy | Số tiết diện gốc | RGB lõi | Độ rộng mực trung vị (pt) |',
 '|---|---|---|---|'])
for z in ink['curves']:lines.append('| '+z['model']+' | '+str(z['number_of_native_profiles'])+' | '+','.join(map(str,z['source_core_RGB']))+' | '+f"{z['source_opacity_area_width_pt_median']:.6f}"+' |')
lines.extend(['',
 '7. Nền chỉ đổi tại mực đường bị loại, dựng lưới bằng các tiết diện thực cùng hàng/cột gốc; ngoài mặt nạ điểm ảnh giữ nguyên. SMask (mặt nạ độ che phủ) chỉ điểm ảnh thay đổi, dùng Num của catfix giữ số màu; không nén lại trang, không vẽ chữ bằng font hệ thống. Các nhãn giữ nguyên bản nguồn tại vị trí/cỡ/màu. Lưới/chữ/nét đứt/6đường không sửa cần ảnh so/khóa điểm ảnh độc lập.','',
 '8. Mẫu1 gồm đủ13model, cả bảng sai lệch104mốc (13×8), ảnh150dpi và600dpi, ảnh phóng chỗ nối/chữ, lượng mực vuông góc nguồn–mới cùng các Q. ROOT kiểm độc lập trên PDF mẫu được đọc thật. Chưa chuyểnS.dst trước duyệt. Tối đa2mẫu cùng phương pháp; chưa đẹp dừng và giữ CHƯA ĐẠT.','',
 'Nghiệm thu cần: đúng29mốc ≤max(1m,2%H) kể cả biên sai số ảnh; cả8mốc/đầu-cuối được đo riêng, điểm chưa đọc rõ vẫn CHƯA THỂ. Chữ/nét đứt không đổi từng điểm ảnh vùng khóa; các bảng/14biểu đồ khác giữ; nguồn/ảnh/phông/12trang/meta/liên kết/ngoài vùng đạt. Không gọi toànG05XONG từ29mốc. Toàn2218mốc vẫn1115ĐẠT/29CHƯAĐẠT/1074CHƯATHỂ trước mẫu.','',
 'Bằng chứng nguồn: CHUNG CU NGUON 29 MOC 13 MAY.json;29 MOC LECH DA RO.csv;BANG SO PDF GIAO.png/BANG SO PDF NGUON.png;BIEU DO PDF GIAO.png/BIEU DO PDF NGUON.png;NHAN TUNG MAY;DO MUC JPEG NGUON 13 MAY.json. DOC NGUON V1 bị loại vì đọc nhầm lớpSMask, xem DINH CHINH DOC ANH V1.md.','',
 'Chờ ROOT chốt phương án và phạm vi thay13đuôi cùng kiểu trước tạo đường mẫu.'])
Path(fresh(S.report(O+'PHUONG AN TRUOC KHI VE.md'))).write_text('\n'.join(lines),encoding='utf8')
S.progress('G05','CHƯA XONG – KHẢO SÁT 29 MỐC SP30','Bản giao7335… giữ nguyên; đọc13model/29mốc lệch chắc và8QH mỗi hàng; '+str(sum(z['number_of_native_profiles'] for z in ink['curves']))+' tiết diện nguồn, tổng lấy từ dữ liệu. Chưa vẽ/chưa ghiPDF; phương án G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/PHUONG AN TRUOC KHI VE.md chờ ROOT; -9/-8 và4SP14/15 giữ chưa thể. Tổng2218vẫn1115/29/1074.')
print('SP30_PROPOSAL',S.report(O+'PHUONG AN TRUOC KHI VE.md'),'PROFILES',sum(z['number_of_native_profiles'] for z in ink['curves']),flush=True)
