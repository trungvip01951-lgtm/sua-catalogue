from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib
src=Path(HERE/'g05_sp30_sample1.py').read_text(encoding='utf8')
assert src.count("O='G05/6SP30 HAI MUOI CHIN MOC/MAU 1/'")==1
src=src.replace("O='G05/6SP30 HAI MUOI CHIN MOC/MAU 1/'","O='G05/6SP30 HAI MUOI CHIN MOC/MAU 2/'")
i=src.index('bodies={17:');j=src.index('\ncurves=[];traceproof=[]',i)
src=src[:i]+'''bodies={13:(475,481),15:(458,466),17:(443,450),20:(419,426),24:(388,394),26:(372,378),30:(340,346),32:(325,330),35:(302,307),38:(277,283),42:(246,252)}
M='G05/6SP30 HAI MUOI CHIN MOC/MAT NA CHU TU GLYPH SACH V2/'
maskdata=np.load(S.report(M+'MAT NA NGUON.npz'));fontlock=maskdata['fontlock'];fontcore=maskdata['fontcore'];fontsupport=maskdata['support']
fontproof=json.loads(Path(S.report(M+'CHUNG CU MAT NA CHU.json')).read_text(encoding='utf8'))
assert fontproof['source_sha256']==d['source_sha256'] and all(v['retained_curve_candidates_outside_learned_contour']==0 for v in fontproof['rows'])
all_caption=np.zeros_like(fontcore)
for suffix,(top,bot) in bodies.items():all_caption[top-3:bot+4,1132:1187]=True
all_caption[494:580,1132:1187]=True
possible_curve=np.zeros_like(fontcore)
for x in range(1133,1185):
 for sp in splines:
  pred=float(sp(x));ys=np.arange(max(0,int(pred)-3),min(a.shape[0],int(pred)+4));possible_curve[ys,x]|=(abs(ys-pred)<1.8)&(gray[ys,x]<225)
# Mixed pixels within true glyph support are original source font pixels.
# The entire low prefix is locked unchanged, never called separated glyphs.
ambiguous=fontlock&possible_curve&~fontsupport&~fontcore
startq={5:16.35,10:16.35,13:18.12,15:18.12,17:13.8,20:13.8,24:13.8,26:13.8,30:13.8,32:13.8,35:13.8,38:13.8,42:13.8}
''' + src[j:]
src=src.replace('if suffix in [5,10,13,15,26,32]:','if suffix in [5,10,13,15]:')
src=src.replace("base=S.report(O+'BASE CHI BO 13 DUOI.pdf')","base=S.report('G05/6SP30 HAI MUOI CHIN MOC/MAU 1/BASE CHI BO 13 DUOI.pdf')")
src=src.replace("checkpoint=json.loads(Path(S.report(O+'NHAT KY BASE.json')))","checkpoint=json.loads(Path(S.report('G05/6SP30 HAI MUOI CHIN MOC/MAU 1/NHAT KY BASE.json')))")
src=src.replace("sample_number=1","sample_number=2").replace("SP30_SAMPLE1_PNG","SP30_SAMPLE2_PNG")
src=src.replace("Lowcrowded/26/32prefix preserved throughallcaption.","All19sourcecaptions locked with real samefileglyphsupport;26/32joins beforecaptionend; originalRGBkept.")
out=Path(HERE/'g05_sp30_sample2.py');assert not out.exists();out.write_text(src,encoding='utf8')
O='G05/6SP30 HAI MUOI CHIN MOC/MAU 1/'
report=dict(sample_number=1,status='CHƯA ĐẠT',pdf_written=False,canonical_unchanged=True,current_sha256='7335c3a45042d0517e5bb1d033513dad722145dcda0aecdb1a896c9765e7eee1',physical_sample_count=1,reasons=['Mặt nạ mẫu 1 chỉ khóa 9 nhãn cao, vùng xóa nét ảnh làm hỏng một phần nhãn 6SP30-15.','Các đường 6SP30-26 và 6SP30-32 nối muộn tạo chỗ gập nhìn thấy trên ảnh phóng lớn.'],action='Loại mẫu 1. Chỉ còn mẫu 2 cuối cho phương pháp này; chưa đổi PDF giao.')
Path(fresh(S.report(O+'NGHIEM THU PNG MAU 1 - CHUA DAT.json'))).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(out)
