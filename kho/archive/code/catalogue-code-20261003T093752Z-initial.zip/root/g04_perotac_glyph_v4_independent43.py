"""Independently read Font V4; RAM geometry only, never write a PDF."""
from catwork import start, fresh
S, D, N = start()
from catfix.raster import cv2
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
import json, hashlib

name = 'Perotac bơm giếng SA_compressed (bản mới).pdf'
base = Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'))
root = base / 'TOAN BO12 DO LAI DUONG CHU V4 LONG4 DUNG NGUON'
font_relative = 'SO4 LONG CHU DUNG NGUON V4/TOAN BO12 CHU NGUON LONG4 DUNG V4 RAM CHUA NGHIEM THU.json'
read = lambda p: json.loads(Path(p).read_text(encoding='utf8'))
current = read(base / font_relative)
source = read(base / 'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json')
by = {r['key']: r for r in source['candidates']}
scale = 96

def dense_polygon(vertices, samples=256):
    v = np.asarray(vertices, float)
    return np.vstack([p + np.linspace(0, 1, samples, endpoint=False)[:, None] *
                      (v[(i + 1) % len(v)] - p) for i, p in enumerate(v)])

def actual_points(path):
    if not path.get('cubic_segments_local_native'):
        return dense_polygon(path['local_native_xy'])
    points = []
    t = np.linspace(0, 1, 256, endpoint=False)[:, None]
    for segment in path['cubic_segments_local_native']:
        c = np.asarray(segment, float)
        points.append((1-t)**3*c[0] + 3*(1-t)**2*t*c[1] + 3*(1-t)*t**2*c[2] + t**3*c[3])
    return np.vstack(points)

def boundary_distance(a, b):
    return max(float(cKDTree(a).query(b)[0].max()), float(cKDTree(b).query(a)[0].max()))

def area(points):
    return abs(float(np.sum(points[:, 0]*np.roll(points[:, 1], -1) -
                            points[:, 1]*np.roll(points[:, 0], -1))/2))

out = []
for glyph in current['glyphs']:
    r = by[glyph['source_key']]
    alpha = np.asarray(r['alpha'])
    h, w = alpha.shape
    up = cv2.resize(np.pad(alpha, 1), ((w+2)*scale, (h+2)*scale), interpolation=cv2.INTER_LINEAR)
    source_mask = up >= r['iso_mass_match_threshold']
    contours, hierarchy = cv2.findContours(source_mask.astype(np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    paths, pieces = [], []
    newmask = Image.new('L', ((w+2)*scale, (h+2)*scale), 0)
    draw = ImageDraw.Draw(newmask)
    for j, path in enumerate(glyph['cleaned_contour_paths']):
        pts = actual_points(path)
        ref = (contours[j][:, 0, :].astype(float) + .5)/scale - 1
        assert (path['parent'] < 0) == (hierarchy[0, j, 3] < 0)
        proposed_box = np.r_[pts.min(0), pts.max(0)]
        source_box = np.r_[ref.min(0), ref.max(0)]
        src_area = abs(cv2.contourArea(contours[j])/scale**2)
        proposed_area = area(pts)
        poly = dense_polygon(path['local_native_xy'], samples=16)
        pieces.append(dict(parent=path['parent'], source_contour_area_native_px=src_area,
            proposed_exact_curve_area_native_px=proposed_area,
            area_change_percent=(proposed_area/src_area-1)*100,
            source_bbox_native=source_box.tolist(), proposed_bbox_native=proposed_box.tolist(),
            bbox_width_height_delta_percent=(((proposed_box[2:]-proposed_box[:2]) /
                                               (source_box[2:]-source_box[:2])-1)*100).tolist(),
            source_max_symmetric_boundary_distance_native_px=boundary_distance(ref, pts),
            RAM_stored_polygon_vs_exact_curve_max_distance_native_px=boundary_distance(poly, pts),
            exact_cubic_count=len(path.get('cubic_segments_local_native', [])),
            straight_only_polygon=not bool(path.get('cubic_segments_local_native'))))
        draw.polygon([((x+1)*scale, (y+1)*scale) for x, y in pts], fill=255 if path['parent'] < 0 else 0)
        paths.append(pts)
    mask = np.asarray(newmask) > 0
    nc, nh = cv2.findContours(mask.astype(np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    allp = np.vstack(paths)
    bb = np.r_[allp.min(0), allp.max(0)]
    srcbb = np.asarray(r['source_iso_native_bbox'])
    bbox_delta = ((bb[2:]-bb[:2])/(srcbb[2:]-srcbb[:2])-1)*100
    ink = float(mask.sum()/scale**2)
    obj = dict(character=glyph['character'], source_key=glyph['source_key'],
        source_page=r['source_page'], source_image=r['source_image'], source_native_box=r['source_native_box'],
        source_raw_pixel_sha256=r['raw_pixel_sha256'],
        source_RGBA_projected_alpha_area_native_px=r['alpha_integral_native_px'],
        current_RAM_mask_area_native_px=ink, current_RAM_alpha_area_delta_percent=(ink/r['alpha_integral_native_px']-1)*100,
        source_bbox_native=srcbb.tolist(), current_exact_curve_bbox_native=bb.tolist(),
        current_bbox_WH_delta_percent=bbox_delta.tolist(), source_crop_advance_native=float(w),
        current_advance_native=glyph['native_advance'], advance_unchanged=glyph['native_advance']==w,
        source_components=r['components'], source_holes=r['holes'],
        current_components=int(sum(nh[0,k,3] < 0 for k in range(len(nc)))),
        current_holes=int(sum(nh[0,k,3] >= 0 for k in range(len(nc)))),
        source_counter_and_body_each=pieces,
        max_source_boundary_distance_native_px=max(p['source_max_symmetric_boundary_distance_native_px'] for p in pieces),
        current_RAM_polygon_vs_exact_curve_max_distance_native_px=max(p['RAM_stored_polygon_vs_exact_curve_max_distance_native_px'] for p in pieces),
        proposed_single_source_RGB=[57,55,57], opacity=1.,
        no_FontProgram_available_or_invented=True, actual_PDF_readback_not_run=True,
        visual_font_style_same_source_acceptance_pending_ROOT_graphic=True)
    obj['measured_numeric_bounds_only_within_source_one_px_area10pct_bbox2pct'] = bool(
        obj['max_source_boundary_distance_native_px'] <= 1 and abs(obj['current_RAM_alpha_area_delta_percent']) <= 10
        and max(abs(bbox_delta)) <= 2 and obj['source_holes'] == obj['current_holes']
        and obj['source_components'] == obj['current_components'] and obj['advance_unchanged'])
    out.append(obj)
    print(obj['character'], 'ink_delta_pct', round(obj['current_RAM_alpha_area_delta_percent'], 4),
          'box_delta_pct', np.round(bbox_delta, 4), 'boundary_source_px', round(obj['max_source_boundary_distance_native_px'], 4),
          'numeric_bounds_only', obj['measured_numeric_bounds_only_within_source_one_px_area10pct_bbox2pct'], flush=True)

sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(S.src(name)) == current['source_sha256'] and sha(S.result(name)) == current['current_sha256']
doc = dict(read_only=True, source_sha256=sha(S.src(name)), current_sha256=sha(S.result(name)),
    source_original_only=True, current_glyph_source_report=font_relative, current_glyph_source_report_sha256=sha(base/font_relative),
    independently_sampled_actual_current_cubic_data=True, straight_edges_dense_sampled_as_well_as_curves=True,
    previous_V3_number4_counter_FAIL_not_used=True, glyphs=out,
    all_numeric_bounds_pass_only=all(r['measured_numeric_bounds_only_within_source_one_px_area10pct_bbox2pct'] for r in out),
    numeric_bounds_do_not_establish_visual_font_acceptance=True,
    no_PDF_font_or_progress_written=True, ROOT_and_graphic_acceptance_pending=True)
Path(fresh(root/'DO LAI12 DUONG CHU V4 LONG4 NGUON VA MAT NA RAM.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
md = '''# Đọc lại 12 hình chữ theo nguồn Perotac, sửa lòng số 4

Chữ mới hiện ở ảnh trong bộ nhớ, chưa được ghi vào PDF. Số đo chỉ kiểm giới hạn hình học; cần ROOT và người kiểm đồ họa soi dáng chữ, đủ 13 tên và toàn biểu đồ.

Lòng số 4 ở bộ V3 đã bị loại: lệch biên 1,935 điểm ảnh gốc, diện tích tăng 102,26%. Bộ V4 giữ nguyên nét ngoài, cỡ, khoảng tiến và một màu RGB 57/55/57; chỉ sửa lòng bằng hộp, diện tích và biên thực đọc từ chính chữ gốc. Không dùng phông khác hay ký tự của tệp khác.

| Ký tự | Mực đổi | Rộng/cao đổi | Biên lệch lớn nhất | Nét/liền lòng nguồn → đề xuất |
|---|---:|---:|---:|---|
'''
for r in out:
    md += f"| {r['character']} | {r['current_RAM_alpha_area_delta_percent']:+.4f}% | {r['current_bbox_WH_delta_percent'][0]:+.4f}% / {r['current_bbox_WH_delta_percent'][1]:+.4f}% | {r['max_source_boundary_distance_native_px']:.4f} điểm ảnh gốc | {r['source_components']}/{r['source_holes']} → {r['current_components']}/{r['current_holes']} |\n"
four = next(r for r in out if r['character']=='4')
counter = next(p for p in four['source_counter_and_body_each'] if p['parent'] >= 0)
md += f"\nLòng số 4: diện tích nguồn {counter['source_contour_area_native_px']:.8f}, đề xuất {counter['proposed_exact_curve_area_native_px']:.8f} điểm ảnh vuông; biên lệch lớn nhất {counter['source_max_symmetric_boundary_distance_native_px']:.6f} điểm ảnh. Hộp riêng giữ nguyên; số 4 vẫn một khối mực và một lòng.\n"
md += '\nĐã lấy mẫu độc lập cả đường cong và cạnh thẳng, kiểm riêng biên ngoài và từng lòng chữ. Giới hạn nguồn: biên 1 điểm ảnh, cỡ ±2%, tổng mực ±10%; số đo trong giới hạn không tự chứng minh đồ họa đạt. Ảnh nguồn JPEG 150dpi không có chương trình phông; tên phông gốc chưa xác minh. Chữ 3/8 lấy từ cùng Perotac qua đối chiếu các chữ chung 4/S/A; không lấy bộ tiêu đề lớn hoặc chữ bảng nặng hơn. Nguồn, bản giao, tiến độ giữ nguyên.\n'
Path(fresh(root/'DO LAI12 KY TU V4 DE ROOT VA DO HOA DOC.md')).write_text(md,encoding='utf8')
