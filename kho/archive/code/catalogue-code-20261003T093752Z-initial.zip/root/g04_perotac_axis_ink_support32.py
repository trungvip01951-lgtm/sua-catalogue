"""Inspect source punctuation pixel support; no PDF or font substitution."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
import numpy as np,json
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/CHU TRUC NGUON VA RAM CHI DOC'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));out=[]
for key,b in [('LMIN',[722,678,750,691]),('IMP',[702,164,750,179]),('US',[704,146,750,161]),('FLOW',[383,710,475,725])]:
    x0,y0,x1,y1=b;raw=cv.orig[y0:y1,x0:x1];L=raw@[.299,.587,.114]
    Image.fromarray(raw).resize((raw.shape[1]*24,raw.shape[0]*24),Image.Resampling.NEAREST).save(fresh(root/(key+' CHAM DAU GACH CHEO NGUON24x.png')))
    out.append(dict(key=key,box=b,L=L.tolist(),dark_source_core_RGB_median=np.median(raw.reshape(-1,3)[L.ravel()<np.percentile(L,10)],axis=0).tolist()))
Path(fresh(root/'CHAM DAU GACH CHEO MA TRAN NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
