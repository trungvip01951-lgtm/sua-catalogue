from catwork import start,fresh,row
from pathlib import Path
import json,hashlib,datetime
from PIL import Image
S,D,N=start()
from catfix.verify import write_report
checks=[json.loads(Path(S.report('G04/KIEM TRA LAN3 Perotac.json')).read_text(encoding='utf8')),json.loads(Path(S.report('G04/KIEM TRA LAN5 Redpump.json')).read_text(encoding='utf8'))]
readback=json.loads(Path(S.report('G04/NGHIEM THU DOC LAI.json')).read_text(encoding='utf8'))
for pj in checks:
    assert pj['result']['ok']
    assert hashlib.sha256(Path(pj['src']).read_bytes()).hexdigest()==pj['source_sha256']
    assert hashlib.sha256(Path(pj['dst']).read_bytes()).hexdigest()==pj['destination_sha256']
for r in readback['records']:
    r['visual']='ĐẠT: đã đọc từng ô ở ảnh trước/sau phóng to'
    r['evidence']='So sanh LAN3 Perotac.png' if 'Perotac' in r['file'] else 'So sanh LAN5 Redpump.png'
readback['visual_pass']=84;readback['curve_status']='CHƯA XONG';readback['final_time']=datetime.datetime.now().astimezone().isoformat()
Path(fresh(S.report('G04/NGHIEM THU CHOT CHU SO.json'))).write_text(json.dumps(readback,ensure_ascii=False,indent=2),encoding='utf8')
a=Image.open(S.report('G04/So sanh LAN3 Perotac.png'));b=Image.open(S.report('G04/So sanh LAN5 Redpump.png'))
im=Image.new('RGB',(a.width+b.width+24,max(a.height,b.height)),(255,255,255));im.paste(a,(0,0));im.paste(b,(a.width+24,0));im.save(fresh(S.report('So sanh G04.png')))
methods={35:'Chép nét S từ chính câu nguồn',36:'Chép số 1, 7 từ nhãn cùng biểu đồ',37:'Chép nét số cùng bảng',38:'Chép nét số cùng bảng',39:'Chép nét số/dấu thập phân cùng bảng',40:'Chép nét số cùng bảng',41:'Chép nét số/dấu thập phân cùng bảng',42:'Chép nét số cùng bảng',43:'Chép tiêu đề cùng kiểu chữ trong chính PDF',44:'Chép tiêu đề cùng kiểu chữ trong chính PDF',45:'Chép tiêu đề; dời riêng 35/20 sang trái 3 điểm ảnh',46:'Tẩy đúng nét dấu chấm, giữ nét L',131:'Chép số/dấu chấm từ bảng cùng kiểu chữ',132:'Tẩy đúng nét chữ s cuối, giữ nguyên 1 year'}
rows=[]
for task in list(range(35,47))+[131,132]:
    ps=[(pj,p) for pj in checks for p in pj['plans'] if p['task']==task]
    files=list(dict.fromkeys(Path(pj['dst']).name for pj,p in ps));pages=sorted(set(p['page'] for pj,p in ps))
    old='; '.join(dict.fromkeys(p['old'] for pj,p in ps));new='; '.join(dict.fromkeys(p['new'] for pj,p in ps)) or 'Xóa dấu chấm'
    if task==131:old='14 ô kW: 5 hoặc 7; 8 ô HP: 7 / mỗi tệp';new='5.5 kW hoặc 7.5 kW; 7.5 HP; 10 HP giữ nguyên'
    rows.append(row(task,'; '.join(files),','.join(str(p) for p in pages),methods[task],old,new,'ĐẠT','So sanh G04.png; G04/NGHIEM THU CHOT CHU SO.json',positions=len(ps)))
report=fresh(S.report('BAO CAO G04.md'));write_report(rows,report,title='BÁO CÁO NHÓM G04 – Perotac SA + Redpump SL')
lines=['# BÁO CÁO NHÓM G04 – Perotac SA + Redpump SL','',
       '14/14 việc chữ/số ĐẠT, gồm 84 chỗ trên 2 PDF. Phần đường cong CHƯA XONG; hai mẫu chưa được dùng làm bản giao.','',
       '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|']
for r in rows:lines.append('| '+' | '.join(str(r[k]).replace('|','/') for k in ['stt','file','page','old','new','item','result','evidence'])+' |')
lines += ['', 'Tổng danh sách bắt buộc: 14 việc · ĐẠT 14 · CHƯA ĐẠT 0 · CHƯA THỂ XÁC MINH 0.',
          '', 'Việc #162 giữ nguyên: logo Redpump Italy Standard (Chuẩn Ý); không sửa.',
          '', 'Nghiệm thu đã hoàn tất:',
          '- Mỗi PDF 11 trang, khổ trang/độ xoay không đổi; kiểm điểm ảnh ngoài vùng sửa rỗng (ngưỡng 48, vùng tối thiểu 2).',
          '- Toàn bộ ảnh nguồn/lớp mặt nạ và vị trí ảnh trong PDF được giữ nguyên dữ liệu; thông tin tài liệu, liên kết, mục lục giữ nguyên.',
          '- Mã băm SHA-256 (mã xác định tệp) của cả hai tệp đầu vào không đổi.',
          '- Đã đọc 84 chỗ qua ảnh phóng to. OCR (đọc chữ tự động từ ảnh) khớp đúng 56/84; 28 chỗ còn lại đã đọc ảnh trực tiếp, không tính là OCR đạt.',
          '- Chỉ dùng nét chữ/số của chính PDF; lưu miếng ảnh nhỏ nén không mất dữ liệu, giữ đường kẻ/bố cục.',
          '', 'Các phép cộng đã đối chiếu: 779+787=1566; 444+288=732; 535+308=843; 490+329=819; 1194+594=1788; 872−359=857−344=513; 12.6−8.7=11.9−8.0=3.9; 2112+908=3020.',
          '', 'Phát hiện thêm đã đo, chưa sửa đạt:',
          '| Đường | Trang | Q (m³/h) | Cột áp bảng (m) | Đo trên đường (m) | Lệch (m) | Cho phép (m) | Kết quả |',
          '|---|---|---|---|---|---|---|---|',
          '| Perotac 4SA16/23 | 8 | 21 | 50 | 52.59 | +2.59 | 1 | CHƯA ĐẠT |',
          '| Perotac 4SA16/18 | 8 | 21 | 39 | 41.23 | +2.23 | 1 | CHƯA ĐẠT |',
          '', 'Hai điểm trên được nhận diện theo nhãn và độ tối nét; căn trục bằng 5 vạch lưu lượng, sai số đọc khoảng 0.38 m. Bằng chứng: G04/DO DIEM 4SA16 Q21.png và .json.',
          '', 'Đã thử hai mẫu vẽ theo 8 điểm bảng, giữ điểm đầu/cuối ở Q=0 và Q=21. Mẫu 1 nét đứt bị vụn; mẫu 2 nét đứt gần nối thành nét liền. Cấu trúc/vùng ngoài đạt nhưng hình thức CHƯA ĐẠT; dừng cách làm này sau hai mẫu. Mẫu nằm trong G04/MAU DUONG LAN1 và LAN2; không đưa vào tệp giao tại thư mục Giếng.',
          '', 'Chưa đo đủ toàn bộ đường 4SA16/18, /23; chưa đo các đường khác và các đường Redpump tương ứng. Không tính phần chưa đo là ĐẠT. AI điều phối tiếp tục bằng cách khác.',
          '', 'Cần anh quyết: không có yêu cầu duyệt mới; anh đã cấp quyền xử lý thêm đường cong.',
          '', 'Tệp giao hiện tại (phần chữ/số đã đạt):']
lines += ['- '+pj['dst'] for pj in checks]
lines += ['', 'Nhật ký và bằng chứng chi tiết: G04/KIEM TRA LAN3 Perotac.json, G04/KIEM TRA LAN5 Redpump.json, G04/NGHIEM THU CHOT CHU SO.json; ảnh trước/sau: So sanh G04.png. Các bản thử do phiên tạo được giữ trong G04/BAN THU LAN1–LAN4.']
# Đây là báo cáo vừa tạo trong tiến trình này, không phải báo cáo có trước phiên.
Path(report).write_text('\n'.join(lines)+'\n',encoding='utf8')
S.progress('G04','CHƯA XONG','14/14 chữ/số ĐẠT, 84 chỗ/2 PDF; 2 điểm đường 4SA16/23 và /18 chưa đạt; 2 mẫu đường hình thức chưa đạt, chưa đưa vào bản giao; AI điều phối tiếp tục.')
print(report);print('G04: 14/14 chữ/số ĐẠT; CHƯA XONG phần đường cong.')
