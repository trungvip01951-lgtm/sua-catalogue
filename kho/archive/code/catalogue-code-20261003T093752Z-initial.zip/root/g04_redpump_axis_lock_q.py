"""Lock source-only actual printed m3/h ticks after direct inspection of 17 photos."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from graph_image_math import fit_observed_ticks
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'17 TRUC NGUON XY CANDIDATE V4.json').read_text(encoding='utf8'))
values={'2SL0.7':np.arange(0,1.001,.2),'2.5SL1.5':np.arange(0,2.001,.5),'3SL2':np.arange(0,2.501,.5),'3SL3':np.arange(0,3.501,.5),'3SL4':np.arange(6),'4SL2':np.arange(0,3.001,.5),'4SL3':np.arange(0,5.001,.5),'4SL4':np.arange(7),'4SL6':np.arange(10),'4SL8':np.arange(12),'4SL10':np.arange(0,14.001,2),'4SL12':np.arange(0,16.001,2),'4SL16':np.arange(0,22.501,2.5),'6SL15':np.arange(0,20.001,5),'6SL25':np.arange(0,30.001,5),'6SL35':np.arange(0,42.001,6),'6SL45':np.arange(0,50.001,10)}
rows=[]
for p in d['records']:
 q=values[p['family']].tolist();xx=p['Q_tick_candidates_page'][:len(q)];assert len(xx)==len(q)
 fit=fit_observed_ticks(q,xx)
 row=dict(page=p['page'],family=p['family'],unit='m³/h',printed_values=q,printed_tick_page_x=xx,selected_candidate_indices=list(range(len(q))),excluded_candidate_indices=list(range(len(q),len(p['Q_tick_candidates_page']))),excluded_reason='Soi ảnh trực tiếp: đỉnh còn lại ở chữ đơn vị m³/h, không phải vạch chia có số.',fit=fit,source_photo=p['source_photo'],source_SHA256=d['source_SHA256'],verification='Đã soi từng vạch và số in trên 17 ảnh nguồn có định vị; không dùng số bảng Q-H hay dữ liệu catalogue khác để fit trục.',scope='Khóa trục Q riêng; không chấm đường ĐẠT từ kết quả trục.')
 rows.append(row);print(row['family'],np.round([fit['slope'],fit['intercept'],fit['max_residual_px']],6),flush=True)
Path(fresh(root/'17 TRUC Q DOC NGUON RIENG.json')).write_text(json.dumps(dict(records=rows,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
