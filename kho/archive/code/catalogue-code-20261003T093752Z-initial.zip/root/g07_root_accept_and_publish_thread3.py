"""ROOT independently accepts the one native digit repair, then preserves old output."""
from catwork import start, fresh
S,D,N=start()
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone,timedelta
import json,hashlib,math,shutil,os
import numpy as np
import pymupdf as fitz
import pikepdf
from catfix.vector import Editor
from catfix.textlayer import TextLayer

name='Catalog bơm nước thải Aquaris FS (bản mới).pdf'
src,dst=Path(S.src(name)),Path(S.result(name))
trial=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-redpump-kiem-duong\outputs\g07_aquaris_fs_recovery_thread3_candidate_20261003_125038_982452')
candidate=trial/name
planpath=Path(S.report('G07/ROOT DOC DUNG G2 VA CHU3 CUNG PHONG TRUOC SUA/ROOT PHUONG AN REN G2 SANG G3 DOC PDF THAT.json'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
h=dict(source=sha(src),current=sha(dst),candidate=sha(candidate),plan=sha(planpath))
assert h==dict(source='4ae76b0cc2a5d1060763b332093ce952ac964902bd9aaa705f4a36b4ef9ce8fa',current='5785252969ffb1f9cc78bda04f57bf573b555b26acf0a2deef68b61e96988c4e',candidate='928bbda4fdd4aab698bfa49f2af6eb0b1c794f31e1b6b4d6348b956108e49a02',plan='fb06afc266cb0deda99295ec09a606478bcf20d71d01707d7d495a3ff6cf261d')
plan=json.loads(planpath.read_text(encoding='utf-8'))
root=Path(S.report('G07/ROOT REN G3 DOC PDF THAT VA LUU BAN TRUOC'))
assert not root.exists() or not any(root.iterdir()),'An acceptance/publication already wrote evidence here'
root.mkdir(parents=True,exist_ok=True)

def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if hasattr(v,'tolist'):return plain(v.tolist())
    if isinstance(v,bytes):return v.hex()
    return v

def glyph(g):
    r=g.run
    return plain(dict(char=g.ch,code=g.cb,o=g.o,e=g.e,bbox=g.bbox,font=r.font.basefont,
                      resource=r.fontname,size=r.size_page,fill=r.fill,tr=r.tr,
                      tc=r.tc,tw=r.tw,th=r.th,ts=r.ts,ctm=r.ctm))

editors=[Editor(str(p)) for p in [src,dst,candidate]]
layers=[TextLayer(e) for e in editors]
ga,gb=[list(t.glyphs(0,visible_only=True)) for t in layers[1:]]
assert len(ga)==len(gb)==8750
target_index=[]
for i,(a,b) in enumerate(zip(ga,gb)):
    da,db=glyph(a),glyph(b)
    if da['char']!=db['char'] or da['code']!=db['code']:
        assert (da['char'],db['char'],da['code'],db['code'])==('2','3','32','33')
        assert np.allclose(da['o'],[770.6721,251.7104],atol=1e-8,rtol=0)
        da.pop('char');db.pop('char');da.pop('code');db.pop('code')
        target_index.append(i)
    assert da==db,(i,da,db)
assert len(target_index)==1
assert len(layers[2].find(0,'G 3”',rect=(750,247,783,260)))==1
assert len(layers[2].find(0,'G 2”',rect=(750,247,783,260)))==0
assert len(layers[2].find(0,'50',rect=(1100,620,1150,635)))==1
target=glyph(gb[target_index[0]])
assert target['font']=='BBDDVM+UTM-Helve' and target['size']==8 and target['tr']==0
fields=['op','fill','stroke','lw','dash','gs','fill_cs','stroke_cs','clip','textclip','ctm']
pages=[e.page(0) for e in editors]
assert all(len(p.objs)==273 for p in pages)
for oi in range(273):
    packets=[]
    for p in pages:
        o=p.objs[oi]
        packets.append((plain({k:o[k] for k in fields}),[(i.op,plain(i.operands)) for i in p.ops[o['i0']:o['i1']+1]]))
    assert packets[0]==packets[1]==packets[2],oi
for e in editors:e.close()

def streamsha(b):return hashlib.sha256(b).hexdigest()
def assets(doc):
    images=Counter(streamsha(doc.xref_stream_raw(x)) for x in {i[0] for p in doc for i in p.get_images(full=True)})
    fonts=Counter((doc.extract_font(x)[0],streamsha(doc.extract_font(x)[-1])) for x in {f[0] for p in doc for f in p.get_fonts(full=True)})
    return images,fonts
def meta(path):
    with pikepdf.open(path) as p:
        x=p.Root.get('/Metadata')
        return {str(k):str(v) for k,v in p.docinfo.items()},None if x is None else x.read_raw_bytes(),None if x is None else x.read_bytes()
ms,ma,mb=meta(src),meta(dst),meta(candidate)
assert ma==mb and ms[0]==ma[0]
import xml.etree.ElementTree as ET
def xml_semantics(data):
    def node(e):
        return (e.tag,tuple(sorted(e.attrib.items())),e.text if e.text and e.text.strip() else '',tuple(node(c) for c in e))
    return node(ET.fromstring(data))
assert xml_semantics(ms[2])==xml_semantics(ma[2])==xml_semantics(mb[2])
changed=0
with fitz.open(src) as z,fitz.open(dst) as a,fitz.open(candidate) as b:
    assert len(z)==len(a)==len(b)==1
    assert a.metadata==b.metadata==z.metadata
    assert assets(z)==assets(a)==assets(b)
    assert len(assets(b)[0])==7 and len(assets(b)[1])==9
    assert z.get_toc(simple=False)==a.get_toc(simple=False)==b.get_toc(simple=False)
    p,q=a[0],b[0]
    for box in ['mediabox','cropbox','trimbox','bleedbox','artbox','rotation']:
        assert getattr(z[0],box)==getattr(p,box)==getattr(q,box)
    assert z[0].get_links()==p.get_links()==q.get_links()
    assert plain(p.get_image_info(hashes=True,xrefs=True))==plain(q.get_image_info(hashes=True,xrefs=True))
    aa=p.get_pixmap(matrix=fitz.Matrix(200/72,200/72),alpha=False)
    bb=q.get_pixmap(matrix=fitz.Matrix(200/72,200/72),alpha=False)
    x=np.frombuffer(aa.samples,np.uint8).reshape(aa.height,aa.width,aa.n)
    y=np.frombuffer(bb.samples,np.uint8).reshape(bb.height,bb.width,bb.n)
    diff=np.any(x!=y,axis=2);changed=int(diff.sum());assert changed>0
    allowed=fitz.Rect(*target['bbox']);allowed=fitz.Rect(allowed.x0,p.rect.height-allowed.y1,allowed.x1,p.rect.height-allowed.y0)
    scale=200/72
    diff[max(0,math.floor(allowed.y0*scale)-aa.y):min(aa.height,math.ceil(allowed.y1*scale)-aa.y),max(0,math.floor(allowed.x0*scale)-aa.x):min(aa.width,math.ceil(allowed.x1*scale)-aa.x)]=False
    outside=int(diff.sum());assert outside==0,outside
    context=fitz.Rect(750,p.rect.height-264,786,p.rect.height-242)
    for tag,pg in [('TRUOC',p),('SAU',q)]:
        pg.get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=context,alpha=False).save(fresh(root/(tag+' REN G3 KIEM ROOT600.png')))
assert h==dict(source=sha(src),current=sha(dst),candidate=sha(candidate),plan=sha(planpath))
proof=dict(status='ĐẠT ROOT: SỬA RIÊNG REN G2 SANG G3',hashes=h,total_glyphs=8750,
    changed_glyphs=1,other_glyphs_held=8749,drawings_held=273,original_5_curves_held=True,
    target=target,quote_original_code94_held=True,outlet_50_held='CHƯA THỂ: thiếu chữ 8 MyriadPro-Regular trong nguồn',
    current_raw_XMP_Info_images_fonts_pageboxes_toc_links_held=True,
    source_Info_and_XMP_XML_semantics_held=True,
    historical_source_to_previous_raw_XMP_reformatting='XML content equal; source raw '+streamsha(ms[1])+' differs from previous/candidate '+streamsha(ma[1])+'. This digit repair preserves previous raw XMP exactly.',
    outside_200dpi_threshold0=outside,
    changed_pixels_200dpi=changed,visual_ROOT_600='ĐẠT: đã xem trực tiếp trước/sau; cùng kiểu/cỡ/độ đậm',
    whole_task137='CHƯA ĐẠT TOÀN BỘ: cửa xả80 chưa sửa được',PDF_written_by_catfix=True)
proofpath=Path(fresh(root/'ROOT DOC PDF THAT REN G3 8750 CHU273 NET.json'))
proofpath.write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
# Publication copies the exact accepted catfix bytes; originals remain untouched.
assert dst.resolve().is_relative_to(Path(S.out_dir).resolve())
assert not dst.resolve().is_relative_to(Path(S.in_dir).resolve())
backup=root/'BAN GIAO TRUOC KHI SUA REN G3'/name
shutil.copyfile(dst,fresh(backup));assert sha(backup)==h['current']
copied=[]
for f in trial.iterdir():
    if not f.is_file() or f.suffix.lower()=='.pdf':continue
    targetpath=Path(fresh(root/'HO SO TAC NHAN'/f.name));shutil.copyfile(f,targetpath)
    assert sha(targetpath)==sha(f);copied.append(dict(path=str(targetpath),sha256=sha(f)))
stage=dst.with_name('.CHATGPT_G07_REN_G3_DA_NGHIEM_THU.pdf')
assert not stage.exists();shutil.copyfile(candidate,stage)
assert sha(stage)==h['candidate'] and sha(src)==h['source'] and sha(dst)==h['current']
os.replace(stage,dst)
assert sha(dst)==h['candidate'] and sha(src)==h['source'] and sha(backup)==h['current']
receipt=dict(time=datetime.now(timezone(timedelta(hours=7))).isoformat(),source_held=True,
    source_sha256=h['source'],published=str(dst),published_sha256=sha(dst),backup=str(backup),
    backup_sha256=sha(backup),catfix_exact_byte_copy=True,ROOT_proof=str(proofpath),
    ROOT_proof_sha256=sha(proofpath),writer_evidence=copied,group_status='4/5 ĐẠT; #137 renG3 ĐẠT, cửa xả80 CHƯA THỂ')
Path(fresh(root/'ROOT BIEN NHAN BAN GIAO REN G3.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
report='''BÁO CÁO NHÓM G07 – Bổ sung nghiệm thu ren G3 trên PDF thật

| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |
|---|---|---|---|---|---|---|---|
| 137 – ren | Catalog bơm nước thải Aquaris FS (bản mới).pdf | 1 | G 2” còn trong PDF thật | G 3” | Thay riêng mã chữ số 2 bằng 3 từ phông nhúng chính nguồn, giữ G/dấu cách/dấu ” | ĐẠT | ROOT đọc 8.750 chữ, đúng một chữ đổi; 273 nét/5 đường cong giữ; ngoài vùng sửa 200 điểm ảnh trên inch, ngưỡng0: rỗng; đã xem 600 điểm ảnh trên inch |
| 137 – cửa xả | Cùng tệp | 1 | 50 | Chưa sửa thành80 | Nguồn thiếu chữ8 thuộc MyriadPro-Regular; các cầu nối phông khác không khớp | CHƯA THỂ XÁC MINH, chưa nhận hoàn tất | Báo cáo khảo sát phông riêng; bản giao vẫn50 |

Nguồn01-10 giữ nguyên. Bản giao cũ578525… đã sao lưu nguyên byte. Bản mới928bbd… là chính tệp catfix đã nghiệm thu.
Báo cáo lịch sử từng ghi renG3 nhưng PDF vẫnG2; bổ sung này căn cứ PDF thật và khắc phục sai lệch đó. Tổng G07 giữ4/5 việc ĐẠT, chưa nhận toàn bộ #137.
'''
Path(fresh(root/'BAO CAO BO SUNG G07 REN G3 8 COT.md')).write_text(report,encoding='utf-8')
S.progress('G07','4/5 ĐẠT – REN G3 ĐÃ SỬA VÀ NGHIỆM THU PDF THẬT',
    'Bản928bbd… đã lưu sau ROOT đọc độc lập8.750 chữ: đúng2→3,8.749 chữ khác/273 nét/5 đường/9 phông/7 ảnh/Info/XMP/khổ/trang/vùng ngoài200 ngưỡng0 giữ; renG3 đúng8pt và cùng phông nguồn, đã xem600. Bản578525… sao lưu nguyên byte, nguồn4ae76… giữ. #137 cửa xả50→80 vẫn CHƯA THỂ vì thiếu8 MyriadPro-Regular; không nhận cả #137 ĐẠT. Báo cáo bổ sung8cột tại G07/ROOT REN G3 DOC PDF THAT VA LUU BAN TRUOC.')
print(json.dumps({k:receipt[k] for k in ['published','published_sha256','source_held','group_status']},ensure_ascii=False),flush=True)
