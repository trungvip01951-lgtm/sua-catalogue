from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
r=Path(S.report('G04/REDPUMP 25 MAU SUA DUOI2'));a=json.loads((r/'DOC LAI PDF MAU2 VA BAO VE NGUON.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(a['sample'])==a['sample_sha']
text=f'''# G04 — Mẫu riêng sửa đuôi Redpump 4SL16/25, lần 2

Mẫu 2 đã qua các phép kiểm trong hồ sơ; đang chờ ROOT (tác nhân kiểm độc lập) nghiệm thu. Chưa đổi bản giao. Mẫu 1 giữ riêng và ghi **CHƯA ĐẠT** vì mặt nạ cũ che nét mới.

| Việc | Tệp | Trang | Trước | Mẫu 2 | Cách làm | Bằng chứng | Kết quả |
|---|---|---:|---|---|---|---|---|
| Đuôi 4SL16/25 | Redpump giếng SL | 8 | Q21: mực≈57,4m, bảng54m; vượt ngưỡng1,08m | Điểm cuối đường thật Q21/H54; sai số tọa độ số≈4×10⁻¹¹m | Một đường cong cubic (nét PDF thật) giảm đều; chốt miền ởQ21 | DOC LAI PDF MAU2 VA BAO VE NGUON.json | ĐẠT phép đọc điểm cuối; chờ ROOT |
| Chỗ nối | Như trên | 8 | Nét nguồn ởQ18≈74,972m, bảng75m | Neo toán họcQ18/H75; mực nguồn ởQ18 vẫn giữ | Tiếp tuyến vào đo trên mực riêng; clip (giới hạn vùng vẽ) bắt đầuQ18,023575 để giữ điểm ảnh miền trước18 | DUOI TRUOC SAU 600dpi.png | ĐẠT phép nối/ảnh; không gọi neo bị clip là mực mới tạiQ18 |
| 7 cột trước điểm nối | Như trên | 8 | Q0,3,6,9,12,15,18 | Từng cột/miềnQ<18 không đổi điểm ảnh ở150/200/450/600dpi | Đọc lại ảnh hiển thị thực từ PDF | previous_7_Q_columns_preserved, prefix_pixels | ĐẠT giữ nguyên; H tạiQ0 vẫn CHƯA THỂ theo phép đo trước |
| Hai đường đã nghiệm thu | Như trên | 8 | /23 và/18 đã đạt | Path (nét vẽ), màu, bề rộng, khoảng nét, vùng ảnh quanh đường giữ nguyên | So sánh cấu trúc đường thật và mặt nạ điểm ảnh600dpi | original_strokes_preserved, old_23_18_pixel_guards | ĐẠT giữ nguyên; không đo lại16 mốc |
| Xóa mực cũ quáQ21 | Như trên | 8 | Đuôi nguồn kéo tớiQ≈21,566 | Không còn lõi mực tối có màu trên ống nét cũ ngoàiQ21; nét PDF mới clip đúngQ21 | Tẩy pixel (điểm ảnh) trong ống hẹp; giữ ảnh gốc dưới lớp sửa | no_dark_core_old_continuation, ảnh cuối600dpi | ĐẠT kiểm lõi mực; không coi nhiễu JPEG là nét |
| Hình thức/màu/nét | Như trên | 8 | Nét nguồn là ảnh JPEG nén | Màu mực thật trung vị nguồn{a['source_actual600_core_medianRGB']}, mới{a['new_actual600_core_medianRGB']}; bề rộng nguồn{a['source_actual_width_median_pt']:.6f}pt, mới{a['new_actual_width_median_pt']:.6f}pt | Cùng cách đo alpha (độ phủ mực) theo tiết diện600dpi; soi150/600dpi | TOAN BIEU DO TRUOC SAU 150dpi.png, actual_source_new_ink_measurements | ĐẠT phép đo/soi tác nhân; chờ ROOT. Bề rộng là tương đương suy từ ảnh nén |
| Ngoài vùng/chữ/nguồn | Như trên | 1–11 | Bản giao giữ nguyên | Ngoài vùng200dpi/ngưỡng0: rỗng; nhãn/trục0pixel đổi; ảnh cũ/mặt nạ/CTM (ma trận đặt ảnh)/font/link/khổ/info/XMP giữ | Đọc lại tệp đã lưu, backend fitz (bộ đọc/ghi PDF) | original_images_masks_CTM, metadata, fonts | ĐẠT |
| Nguồn/bản giao/tiến độ | Như trên | — | Nguồn và bản giao hiện hành | Mẫu lưu riêng; nguồn/bản giao cùng SHA cũ; không sửa TIEN DO.md | Kiểm SHA-256 (mã kiểm tệp) trước/sau | TAO VA KIEM MAU2.json | ĐẠT bảo vệ tệp; chỉ ROOT ghi sổ tiến độ chung |

Mẫu: `{a['sample']}`

SHA-256 mẫu: `{a['sample_sha']}`

SHA-256 bản giao vẫn giữ: `{a['current_sha']}`

Phạm vi: chỉ đuôi /25. Hai đường /23,/18 và 14 việc bắt buộc G04 đã nghiệm thu vẫn giữ; chưa tuyên bố toàn bộ196 đường Redpump hoặc toàn G04 đã xong. 1.931 ô nguồn/bản giao đã khóa/định vị; điều đó chưa thay cho kiểm độ đúng của từng đường.
'''
Path(fresh(r/'BAO CAO MAU2 8 COT.md')).write_text(text,encoding='utf8');print('Report saved; progress unchanged.')
