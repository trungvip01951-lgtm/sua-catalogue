"""Fresh eight-column RAM handoff. No catalogue or progress write."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
F=M/'CHU5 9 BIEN QUAN SAT RAM V7'
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
q=J(F/'SO DO VA KE HOACH GOP3LOI/NGHIEM THU RAM V7 CHU BIEN CO KHOANG HO VA3LOI.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
rows=[]
for i,wm in enumerate(q['word_size_and_mass_dpi'],1):
    model=wm['model'];rel={x['dpi']:x['relative_delta'] for x in wm['actual_optical_integral']}
    after='Một màu xám 63; tỷ lệ/khoảng tiến giữ.'
    if model in ['4SL16/25','4SL16/5']:after+=' 5 lấy nét nguồn trong nhãn /25 trang 8, liền một cụm, nét ngang/trái ít đoạn.'
    elif model=='4SL16/9':after+=' 9 giữ lỗ trên; khoảng lõm chân mở theo nguồn; bỏ đóng hình.'
    else:after+=' Giữ hình học 10 ký tự còn lại của V5.'
    rows.append(f'| {i} | Redpump SL | 8 | {model} | Nhãn ảnh nguồn nhỏ | {after} | CHƯA CHỐT dáng/đậm/phông; đo mực 150: {rel[150]*100:+.2f}%; 600: {rel[600]*100:+.2f}%; 2400: {rel[2400]*100:+.2f}% | Ảnh 13 nhãn 150/600 và 99 nét chữ thực |')
rows.extend([
'| 14 | Redpump SL | 8 | Đường hiệu suất η | M1 bám nhiễu 551 tâm ảnh | Hai đoạn cong Bézier nối trơn bậc 2; giữ đầu/cuối/đỉnh quan sát | Phương án hình học trong bộ nhớ được ROOT chấp nhận; số η CHƯA THỂ | Phiếu η hai Bézier và ảnh toàn 3 lỗi |',
'| 15 | Redpump SL | 8 | 5 vạch feet | Mép khung dọc đổi điểm ảnh do hộp cắt M1 | Mỗi lỗ nới 0,48 pt đúng miền giao | 15/15 vùng nguồn ở 150/200/600: 0 điểm ảnh đổi | Phiếu RAM V7 feet15_tests |',
'| 16 | Redpump SL | 8 | Giữ 13 Q–H/104 mốc | M1 đã được ROOT kiểm đủ 104 số | 26 nét Q–H giữ nguyên dấu vân tay | ĐẠT bảo toàn nét; không đo lại 104 mốc | Phiếu đường thực trong bộ nhớ |',
'| 17 | Redpump SL | 8 | Khoảng hở/ngoài vùng | Miền sửa nguồn được khóa | Mực chữ cách Q–H ≥0,8781 pt; lưới ≥0,8377 pt | Ngoài toàn trang 200/ngưỡng 0/đệm 0: 0 điểm ảnh đổi | Phiếu bảo toàn và số đo đường thực |',
'| 18 | Redpump SL | 1–11 | Ảnh/phông/thông tin tệp | Bản giao b7c1…d435 | 66 lượt đặt ảnh gốc/mặt nạ/vị trí, 10 trang khác, liên kết, khổ, siêu dữ liệu giữ | ĐẠT bảo toàn; chưa suy thành hình thức chữ ĐẠT | Phiếu bảo toàn RAM V7 |'
])
lines=[
'# Redpump SL — hồ sơ RAM V7, chưa tạo PDF mẫu 2',
'',
'Đã dựng và đọc lại 13 nhãn trong RAM (bộ nhớ máy). Chữ 5 từ nhãn 4SL16/25 trang 8 đã liền nét; chữ 9 từ 3SL4/9 trang 3 giữ lỗ trên và khoảng lõm chân. Một màu xám chung 63, độ đục 1, tỷ lệ 1 và khoảng tiến chữ cũ. **CHƯA CHỐT hình thức/phông**; cần ROOT/đồ họa xem đủ 13 tên ở cỡ 150 và 600 điểm ảnh mỗi inch. Chưa lưu PDF mẫu 2, bản giao hoặc sổ tiến độ.',
'',
'| STT | Tệp | Trang | Việc | Trước | Sau RAM V7 | Nghiệm thu | Chứng cứ |',
'|---|---|---|---|---|---|---|---|',
*rows,
'',
'Các ngưỡng biên là ứng viên từ ảnh JPEG (ảnh nén) nguồn 150 điểm ảnh mỗi inch. Với 5: giữ chính mặt nạ nguồn quan sát, làm ít đoạn ngang/trái. Với 9: mức phủ thân 0,30 và chân 0,40 chuyển trơn tại y22…26 của ô nguồn, giữ đúng lỗ trên, không đóng hình hoặc tô lỗ giả. Cả bộ dùng cùng màu 63; không ép tích phân mực. Mức phủ là phép đo điểm ảnh, không phải đổi màu từng chữ.',
'',
'Sai khác lớn nhất giữa nét vector (nét hình học) và đường biên nguồn được chọn: 5=0,2531 pt; 9=0,1698 pt. Bất định một điểm ảnh gốc ≈0,4801 pt (điểm PDF). **Không khẳng định mọi biên chữ gốc nằm trong một điểm ảnh**: so toàn mép xám yếu mức 0,085 còn 5≈1,0777 pt và 9≈0,9061 pt, có khối xám và sự nhạy với ngưỡng của ảnh nén. Biên CAD (nét trước khi nén ảnh), tên và cỡ phông danh nghĩa chưa thể truy chính xác. Không dùng ngưỡng, số lỗ hoặc xấp xỉ mực để tự gọi phông ĐẠT.',
'',
'Đối chứng bốn ký tự 4/S/L/ nguyên nguồn p5–p8 đã lưu đủ ô và tọa độ, cùng tỷ lệ thật. S/L/ và dáng 4 nhìn cùng họ chữ nhỏ; chân 4 trang 8 có đường bơm cạnh nên các điểm ảnh tối ở đó có giới hạn. Không thay phông ngoài hoặc lấy chữ của Perotac, tiêu đề lớn, bảng đậm.',
'',
'Trình đọc trả 99 đối tượng tô chữ thực trong bộ nhớ, không thêm phông nhúng; 5/9 không bị cắt bởi hộp nhãn. 26 nét Q–H giữ nguyên. Khối tiêu đề được bảo vệ cũng không đổi điểm ảnh ở 150/200/600. Đủ 15 vùng feet nguồn không đổi điểm ảnh. Ngoài vùng 200/ngưỡng 0/đệm 0 rỗng; 66 lượt ảnh nguồn/mặt nạ/ma trận đặt ảnh, 10 trang khác và siêu dữ liệu/liên kết/khổ/phông giữ nguyên.',
'',
'[13 nhãn 150](<RENDER ACTUAL RAM/13 NHAN TRUOC SAU RAM V7 150dpi KHONG PDF2.png>) · [13 nhãn 600](<RENDER ACTUAL RAM/13 NHAN TRUOC SAU RAM V7 600dpi KHONG PDF2.png>) · [Toàn 3 lỗi 150](<RENDER ACTUAL RAM/TOAN3LOI RAM V7 150dpi KHONG PDF2.png>) · [Toàn 3 lỗi 600](<RENDER ACTUAL RAM/TOAN3LOI RAM V7 600dpi KHONG PDF2.png>)',
'',
'[99 nét chữ/13 nhãn thực](<RENDER ACTUAL RAM/DOC ACTUAL RAM V7 13 NHAN VA3LOI KHONG PDF.json>) · [Biên/cỡ/mực/khoảng hở](<SO DO VA KE HOACH GOP3LOI/NGHIEM THU RAM V7 CHU BIEN CO KHOANG HO VA3LOI.json>) · [Bảo toàn ngoài vùng/ảnh](<BAO TOAN NGOAI VUNG RAM V7 LAN1/BAO TOAN RAM V7 NGOAI200 PIXEL0 VA RAW CTM.json>)',
'',
'V6B giữ riêng. Ứng viên chữ 9 có ngưỡng 0,35 từng nhận lỗ nhỏ ở chân thay lỗ trên đã bị chặn trước khi dựng 13 nhãn, chưa vào PDF. V7 là ứng viên cải thiện hình thức; không sửa 104 mốc hay 14 việc CAN đã ĐẠT. Phần toàn 196 model (mã máy)/17 biểu đồ chưa được tính hoàn tất.',
'',
f'Nguồn SHA256 (mã kiểm tệp): `{guards[0]}`',f'Bản giao SHA256: `{guards[1]}`',f'Mẫu 1 SHA256: `{guards[2]}`',
'',
'Kế hoạch gộp khi ROOT chốt: dùng 13 Q–H M1 nguyên nét, η hai Bézier đã được chấp nhận trong bộ nhớ, năm lỗ feet đã được chấp nhận, và bộ chữ được đọc độc lập. Khi đủ dáng/cỡ/đậm mới tạo đúng PDF mẫu 2 bằng catfix (bộ sửa catalogue), đọc PDF thực trước đổi bản giao. Tác nhân này không ghi TIEN DO.md.'
]
fp=fresh(F/'BAO CAO8 COT RAM V7 VA KE HOACH GOP3LOI CHUA PDF2.md')
Path(fp).write_text('\n'.join(lines)+'\n',encoding='utf8')
assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print(fp,'SHA256',sha(fp),flush=True)
