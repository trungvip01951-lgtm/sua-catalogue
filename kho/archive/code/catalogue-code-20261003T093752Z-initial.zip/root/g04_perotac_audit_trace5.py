from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_trace4.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
# A measurement revision only: all source JPEG/PDF bytes stay untouched.
# Permit neutral JPEG ink to contribute its actual darkness to the centroid.
code=code.replace('(lum<125)', '(lum<100)')
code=code.replace('iterations=2', 'iterations=1')
code=code.replace('mask=(mask|grayink)&~letter_edges', 'mask=(mask|grayink)&~letter_edges\n wgt=np.maximum(255-lum,1)*mask')
code=code.replace('LAN4', 'LAN5').replace('V5.json','V6.json').replace('TRACE4','TRACE5')
exec(compile(code,__file__,'exec'))
