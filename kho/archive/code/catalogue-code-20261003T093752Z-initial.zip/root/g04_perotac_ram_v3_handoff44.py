"""Record RAM V3 handoff and hashes; keep source, current PDF, progress unchanged."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
import json, hashlib

name = 'Perotac bơm giếng SA_compressed (bản mới).pdf'
root = Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAM TRANG08 DONG BO LONG4 DUNG V3'))
glyphroot = Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/SO4 LONG CHU DUNG NGUON V4'))
qa = Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/TOAN BO12 DO LAI DUONG CHU V4 LONG4 DUNG NGUON'))
read = lambda p: json.loads(Path(p).read_text(encoding='utf8'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
data = read(root/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json')
metrics = read(qa/'DO LAI12 DUONG CHU V4 LONG4 NGUON VA MAT NA RAM.json')
assert sha(S.src(name)) == data['source_sha256'] == metrics['source_sha256']
assert sha(S.result(name)) == data['current_sha256'] == metrics['current_sha256']
four = next(r for r in metrics['glyphs'] if r['character']=='4')
counter = next(r for r in four['source_counter_and_body_each'] if r['parent'] >= 0)
files = [root/'PEROTAC P08 TOAN TRANG RAM150 CHUA NGHIEM THU.png',
    root/'PEROTAC P08 TOAN BIEU DO RAM600 CHUA NGHIEM THU.png',
    root/'PEROTAC P08 NGUON VA RAM150.png', root/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json',
    glyphroot/'4 NGUON VA LONG CHU DUNG NGUON V4.png',
    glyphroot/'13 TEN CHU NGUON LONG4 DUNG V4 RAM CHUA NGHIEM THU.png',
    glyphroot/'TOAN BO12 CHU NGUON LONG4 DUNG V4 RAM CHUA NGHIEM THU.json',
    qa/'DO LAI12 DUONG CHU V4 LONG4 NGUON VA MAT NA RAM.json', qa/'DO LAI12 KY TU V4 DE ROOT VA DO HOA DOC.md']
manifest = [dict(path=str(p), sha256=sha(p)) for p in files]
doc = dict(stage='ẢNH TRONG BỘ NHỚ, CHỜ ROOT VÀ ĐỒ HỌA KIỂM; CHƯA PDF',
    source_sha256=sha(S.src(name)), current_sha256=sha(S.result(name)),
    old_RAM_V2_and_old_glyph4_counter_rejected=True,
    new_RAM_version3_uses_small_caption_source_glyphsV4=True,
    number4_new_counter_source_bbox_and_area=counter,
    all12_numeric_bounds_only=metrics['all_numeric_bounds_pass_only'],
    graphical_same_source_font_acceptance_PENDING=True,
    axis_literal_words_remain_own_source_contours_and_need_graphic_review=True,
    all104_nodes_RAM_geometry_only_not_actual_PDF=True,
    eta_558_observations_own_Perotac_not_Redpump551=True,
    eta_head11_center_UNKNOWN_eta_values_NO_TABLE=True,
    PDF_sample_count_whole_chart_method=0, progress_and_current_PDF_not_written=True, files=manifest)
Path(fresh(root/'BAN GIAO RAM V3 LONG4 DUNG NGUON VA SHA256.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
md = '''# Ảnh mẫu bộ nhớ V3: sửa lòng số 4 đúng nguồn

Bộ V3 chữ cũ và ảnh RAM V2 chưa được chốt vì lòng số 4 sai. Bộ chữ V4 sửa riêng lòng theo hộp và diện tích mực thực của chính chữ nguồn, giữ nét ngoài, cỡ, đường cơ sở, khoảng tiến, màu và độ trong. Ảnh RAM V3 này dùng bộ chữ V4; đủ 13 tên, gồm đủ hai số 1 trong /11.

'''
md += f"Lòng số 4 có diện tích nguồn {counter['source_contour_area_native_px']:.8f}, đề xuất {counter['proposed_exact_curve_area_native_px']:.8f} điểm ảnh vuông; biên lệch lớn nhất {counter['source_max_symmetric_boundary_distance_native_px']:.6f} điểm ảnh gốc. Hộp riêng giữ nguyên. Tổng mực số 4 đổi {four['current_RAM_alpha_area_delta_percent']:+.4f}%; biên ngoài và trong đều dưới 1 điểm ảnh. Số 4 vẫn một khối mực, một lòng.\n\n"
md += '''Đọc lại độc lập 12 đường chữ, lấy mẫu cạnh thẳng và đường cong, kiểm riêng biên ngoài/từng lòng, cỡ/mực/độ tiến. 12 số đo trong giới hạn được phép, nhưng **chưa thay cho nghiệm thu dáng chữ bằng ảnh**. Cần ROOT và người kiểm đồ họa xem nguồn–đề xuất, đủ 13 tên và toàn trang.

13 đường Q–H đi qua 104 ô H thật theo vạch trục nguồn cục bộ; số đo này hiện chỉ của dữ liệu hình học trong bộ nhớ. Nét 0,90pt, lưới 0,75pt, khung 0,55pt; nhịp đứt 7,00/3,37pt, pha ước lượng −0,04pt từ 169 biên nguồn, pha PDF nguyên bản chưa xác minh. Không ngoại suy sau ô Q21. Đường hiệu suất riêng dùng 558 quan sát Perotac, phần đầu 11 tâm chưa xác minh, không có bảng hiệu suất để nhận số đúng.

Các chữ/số trục và tiêu đề vẫn lấy đường biên từ mực nguyên Perotac; một số biên còn gợn khi phóng lớn. Giữ CHỜ KIỂM ĐỒ HỌA cho phần này, không tự nhận phông hoặc hình thức đạt. Dấu nhỏ ở đơn vị được tách theo nguồn thật, không dùng phông ngoài.

Đã xem ảnh số 4 riêng, 13 tên, toàn trang và biểu đồ phóng 600dpi. Ảnh mẫu trong bộ nhớ không phải kết quả đọc lại PDF, không xác nhận độ dày/mực PDF hay vùng ngoài. Số mẫu PDF của phương pháp toàn biểu đồ vẫn 0. Bản nguồn, bản giao SHA 389a670c… và tiến độ giữ nguyên.

| Tệp | SHA256 |
|---|---|
'''
for r in manifest:
    md += f"| {r['path']} | {r['sha256']} |\n"
Path(fresh(root/'BAN GIAO RAM V3 LONG4 DUNG NGUON VA GIOI HAN.md')).write_text(md,encoding='utf8')
print(json.dumps(dict(source=doc['source_sha256'], current=doc['current_sha256'], four_counter=counter, files=manifest),ensure_ascii=False),flush=True)
