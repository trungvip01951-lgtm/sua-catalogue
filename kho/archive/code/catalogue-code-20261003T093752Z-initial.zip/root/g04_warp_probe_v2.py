"""Thử lần2 phương pháp dời nét nguồn; làm trơn tâm, giữ nhịp đứt và chữ."""
from catwork import start,fresh
from pathlib import Path
import json,numpy as np
from scipy.ndimage import map_coordinates,binary_dilation
from scipy.interpolate import PchipInterpolator
S,D,N=start()
from catfix.recipes import Job
from catfix.charts import Chart
from PIL import Image
name='Perotac bơm giếng SA_compressed (bản mới).pdf';j=Job(S.dst(name),'')
cv=j.R.canvas(j.R.images(7)[0]);ar=cv.orig.copy().astype(float);gray=ar@np.array([.299,.587,.114]);H,W=gray.shape
Q=np.array([0,3,6,9,12,15,18,21],float);heads=[[136,133,127,115,101,86,69,50],[107,104,99,90,79,67,54,39]]
ax=.74446*1000/60;bx=60.379;y0=cv.to_page(125,571.5)[1];y150=cv.to_page(125,180.5)[1];C=Chart(ax,bx,(y150-y0)/150,y0)
u0=int(round(cv.to_px(*C.to_page(0,0))[0]));uend=int(round(cv.to_px(*C.to_page(21.6,0))[0]));us=np.arange(u0,uend+1)
colour=(ar[:,:,1]-ar[:,:,0]>8)&(ar[:,:,2]-ar[:,:,0]>10)&(ar[:,:,0]<235)
weak=(ar[:,:,1]-ar[:,:,0]>2)&(ar[:,:,2]-ar[:,:,0]>3)
# Loại cả viền xám quanh chữ đen. Đường xanh có thể giao chữ nhưng không dời chữ.
black=(gray<140)&((ar.max(2)-ar.min(2))<10);protect=binary_dilation(black,iterations=2)
models=['4SA16/23','4SA16/18'];traces=[];tubes=[];masks=[];fitproof=[]
for model,hs in zip(models,heads):
    qq=np.array([(cv.to_page(u,0)[0]-bx)/ax for u in us]);guide=np.polyval(np.polyfit(Q,hs,3),qq)+2
    vp=np.array([cv.to_px(*C.to_page(float(q),float(h)))[1] for q,h in zip(qq,guide)])
    trace=[]
    for u,v in zip(us,vp):
        ys=np.arange(max(0,int(v)-9),min(H,int(v)+10));valid=ys[colour[ys,u]&~protect[ys,u]]
        if len(valid):
            groups=np.split(valid,np.where(np.diff(valid)>1)[0]+1)
            cands=[(abs(float(np.average(gr,weights=255-gray[gr,u]))-v),float(np.average(gr,weights=255-gray[gr,u]))) for gr in groups]
            trace.append(min(cands)[1])
        else:trace.append(np.nan)
    raw=np.array(trace);good=np.isfinite(raw);assert good.sum()>.60*len(us)
    # Tâm nguồn là đường trơn. Bốn lần loại điểm khác nét, không nội suy răng cưa.
    keep=good.copy()
    for it in range(4):
        fit=np.polyval(np.polyfit(qq[keep],raw[keep],4),qq)
        keep=good&(abs(raw-fit)<1.5)
    trace=fit;traces.append(trace)
    fitproof.append(dict(model=model,n_good=int(good.sum()),n_fit=int(keep.sum()),median_residual_px=float(np.median(abs(raw[keep]-fit[keep]))),max_residual_px=float(np.max(abs(raw[keep]-fit[keep])))))
    tube=np.zeros((H,W),bool)
    for u,v in zip(us,trace):tube[max(0,int(round(v))-4):min(H,int(round(v))+5),u]=True
    tubes.append(tube);masks.append(tube&weak&~protect)
mask=masks[0]|masks[1]
pu0,pv0,pu1,pv1=cv.box((59.5,324,359,513));pa=ar[pv0:pv1,pu0:pu1]
row=np.median(pa,axis=1);col=np.median(pa,axis=0);bg=ar.copy();bg[pv0:pv1,pu0:pu1]=np.minimum(row[:,None,:],col[None,:,:])
base=ar.copy();base[mask]=bg[mask];out=base.copy();proof=[]
for model,hs,trace,source_mask in zip(models,heads,traces,masks):
    delta=np.zeros_like(ar);delta[source_mask]=ar[source_mask]-bg[source_mask]
    dest0=cv.to_px(*C.to_page(0,0))[0];destend=cv.to_px(*C.to_page(21,0))[0]
    ua=int(np.floor(dest0));ub=int(np.ceil(destend));target_us=np.arange(ua,ub+1)
    target_q=np.array([(cv.to_page(u,0)[0]-bx)/ax for u in target_us])
    f=PchipInterpolator(Q,hs);dest_v=np.array([cv.to_px(*C.to_page(float(q),float(f(q))))[1] for q in target_q])
    source_u=u0+(target_us-dest0)*(uend-u0)/(destend-dest0)
    source_v=np.interp(source_u,us,trace);shift=dest_v-source_v
    vv=np.arange(H)[:,None]-shift[None,:];uu=np.broadcast_to(source_u[None,:],vv.shape)
    moved=np.stack([map_coordinates(delta[:,:,c],[vv,uu],order=1,mode='constant',cval=0) for c in range(3)],axis=2)
    out[:,target_us,:]+=moved
    proof.append(dict(model=model,Q=Q.tolist(),H=hs,source_trace_points=len(us),destination_q_end=21,method='Dời nét nguồn; tâm trơn theo hình nguồn; màu/nhịp đứt nguồn',max_y_displacement_px=float(np.max(abs(shift)))))
out=np.rint(out).clip(0,255).astype(np.uint8)
# Chữ và nét đen nguồn tuyệt đối nguyên; không cho mảnh dời đi lên chữ khác.
out[protect]=ar.astype(np.uint8)[protect]
folder=Path(S.report('G04/THU DOI NET GOC LAN2'));assert not folder.exists();folder.mkdir(parents=True)
box=cv.box((59.5,324,359,513));u,v,ur,vr=box
before=Image.fromarray(ar.astype(np.uint8)[v:vr,u:ur]);after=Image.fromarray(out[v:vr,u:ur])
Image.fromarray(out).save(fresh(folder/'Toan anh nguon da doi net.png'))
canvas=Image.new('RGB',(before.width*2+20,before.height),'white');canvas.paste(before,(0,0));canvas.paste(after,(before.width+20,0));canvas.resize((canvas.width*3,canvas.height*3)).save(fresh(folder/'TRUOC SAU.png'))
Path(fresh(folder/'DO NET.json')).write_text(json.dumps(dict(proof=proof,trace_fit=fitproof,source_pixel_size=list(ar.shape),black_letter_pixels_exact=bool(np.array_equal(out[protect],ar.astype(np.uint8)[protect])),image_rect=list(cv.rect(box))),ensure_ascii=False,indent=2),encoding='utf-8')
print('Mẫu ảnh lần2 dời nguyên nét, tâm trơn; chưa ghiPDF.',flush=True);j.close()
