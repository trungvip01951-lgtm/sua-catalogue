"""Đọc độc lập bảng gốc Redpump, không suy danh tính bằng số, không ghi PDF."""
from catwork import start, fresh, HERE
from pathlib import Path
import sys, json, hashlib
S,D,N=start()
sys.path.insert(0,str(HERE))
import pymupdf as fitz
NAME='Redpump gieng SL_compressed (bản mới).pdf'
src=Path(S.src(NAME)); cur=Path(S.result(NAME))
before=[hashlib.sha256(p.read_bytes()).hexdigest() for p in (src,cur)]
base=Path(S.report('G04/ROOT DOC BA O MO/DOC NGUON LAN1'))
assert not base.exists()
base.mkdir(parents=True)
with fitz.open(src) as doc:
    for pi in (4,7):
        p=doc[pi]
        pix=p.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
        pix.save(fresh(base/f'NGUON TRANG {pi+1:02} 144dpi.png'))
        print('source page',pi+1,'rect',list(p.rect),'images',p.get_images(full=True))
assert before==[hashlib.sha256(p.read_bytes()).hexdigest() for p in (src,cur)]
Path(fresh(base/'MA KIEM DOC NGUON.json')).write_text(json.dumps(dict(source=str(src),source_SHA256=before[0],current_SHA256=before[1],source_and_current_held=True),ensure_ascii=False,indent=2),encoding='utf-8')
