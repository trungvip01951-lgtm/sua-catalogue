from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from g04_perotac_audit_data import DATA
from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,numpy as np

root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
E=Editor(src);F=Editor(dst);R=Raster(E);T=Raster(F);imgs=[]
for pi in range(11):
 a=max(R.images(pi),key=lambda z:z.W*z.H);b=max(T.images(pi),key=lambda z:z.W*z.H)
 ar=E.doc.stream_raw(a.ref);br=F.doc.stream_raw(b.ref)
 rows=dict(page=pi+1,source_name=str(a.name),result_original_image_name=str(b.name),source_image_bytes_sha256=hashlib.sha256(ar).hexdigest(),destination_image_bytes_sha256=hashlib.sha256(br).hexdigest(),original_image_bytes_identical=ar==br,source_width=a.W,source_height=a.H,ctm_source=a.ctm.tolist(),ctm_result=b.ctm.tolist(),ctm_identical=bool(np.array_equal(a.ctm,b.ctm)))
 assert rows['original_image_bytes_identical'] and rows['ctm_identical'];imgs.append(rows)
 print('ORIGINAL IMAGE',pi+1,'bytes and placement identical',flush=True)

proof=[]
for fam,models in [('3SS3',['3SS3/37']),('3SS4',['3SS4/20','3SS4/24','3SS4/28']),('4SA16',['4SA16/20','4SA16/25'])]:
 rec=next(x for x in DATA if x['family']==fam);pi=rec['page']-1;im=max(R.images(pi),key=lambda z:z.W*z.H);cv=R.canvas(im)
 plot=rec['plot_native_box'];fullbox=(plot[0]-32,plot[1]-55,plot[2]+42,plot[3]+150)
 rect=cv.rect(fullbox)
 a=verify.crop(src,pi,rect,400);b=verify.crop(dst,pi,rect,400)
 comp=Image.new('RGB',(a.width+b.width,max(a.height,b.height)+22),'white');comp.paste(a,(0,22));comp.paste(b,(a.width,22));dr=ImageDraw.Draw(comp);dr.text((3,2),'SOURCE PDF',fill='black');dr.text((a.width+3,2),'CURRENT RESULT PDF',fill='black')
 fn='DO THI NGUON VA BAN GIAO '+fam+'.png';comp.save(fresh(root/fn))
 # Directly compare actual rendered result pixels at each suspicious source
 # coordinate. A source JPEG equality alone does not prove visible equality
 # if a later patch overlays it.
 j=json.loads((root/'DO NET NGUON LAN4.json').read_text(encoding='utf8'));g=next(x for x in j['graphs'] if x['family']==fam)
 for c in g['curves']:
  if c['model'] not in models:continue
  p=c['points'][-1];u=p['target_u_native'];v=p.get('v_native')
  if v is None:continue
  box=(int(u)-16,int(v)-16,int(u)+17,int(v)+17);pr=cv.rect(box)
  before=verify.crop(src,pi,pr,600);after=verify.crop(dst,pi,pr,600);diff=np.asarray(before).astype(int)-np.asarray(after).astype(int)
  comp=Image.new('RGB',(before.width+after.width,max(before.height,after.height)+23),'white');comp.paste(before,(0,23));comp.paste(after,(before.width,23));dr=ImageDraw.Draw(comp);dr.text((2,2),'SOURCE',fill='black');dr.text((before.width+2,2),'CURRENT RESULT',fill='black')
  fn='DIEM NGUON VA BAN GIAO '+c['model'].replace('/','-')+'.png';comp.save(fresh(root/fn))
  proof.append(dict(model=c['model'],Q_m3_h=p['Q_m3_h'],source_native_box=box,render_dpi=600,evidence_file=fn,actual_visible_pixel_difference_count=int(np.any(diff!=0,axis=2).sum()),max_rgb_difference=int(abs(diff).max())))
  print('ACTUAL RESULT READBACK',c['model'],proof[-1]['actual_visible_pixel_difference_count'],'different pixels',flush=True)

Path(fresh(root/'DOC LAI PDF BAN GIAO.json')).write_text(json.dumps(dict(source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),read_only=True,pdf_written=False,original_images=imgs,suspected_anchor_visible_readback=proof),ensure_ascii=False,indent=2),encoding='utf8')
E.close();F.close()
