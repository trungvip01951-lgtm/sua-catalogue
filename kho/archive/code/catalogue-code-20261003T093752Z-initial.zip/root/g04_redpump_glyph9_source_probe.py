from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=d['method']['source'];cur=d['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['method']['source_SHA256'],d['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cv=R.render_canvas(3,(537,341,565,353),dpi=600);p=Image.fromarray(cv.orig).resize((cv.orig.shape[1]*3,cv.orig.shape[0]*3),Image.Resampling.NEAREST);dr=ImageDraw.Draw(p)
for x in range(0,cv.orig.shape[1],10):dr.text((x*3,0),str(x),fill=(180,0,180))
for y in range(20,cv.orig.shape[0],20):dr.text((0,y*3),str(y),fill=(180,0,180))
photo=fresh(root/'GLYPH9 NGUON TRANG4 NHAN4SL2_9 TOA DO.png');p.save(photo)
Path(fresh(root/'GLYPH9 NGUON TRANG4 NHAN4SL2_9 TOA DO.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],rect=list(cv.rect0),dpi=600,page=4,photo=photo,PDF_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)]
