"""Keep actual source prefix kerning intact and compare to assembled glyphs. No PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json').read_text(encoding='utf8'));bank=json.loads((root/'GLYPH THAT DAY DU_CUNG_BO_NGUON_V3.json').read_text(encoding='utf8')) if (root/'GLYPH THAT DAY DU_CUNG_BO_NGUON_V3.json').exists() else json.loads((root/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['source_SHA256'],d['current_SHA256']]
words=json.loads((root/'CHU NGUON ALPHA THU DO DOC V2.json').read_text(encoding='utf8'));E=Editor(src,backend='fitz');R=Raster(E);cv=R.render_canvas(7,words['source_rect'],dpi=600);whole=cv.orig.astype(float);g=whole@np.array([.299,.587,.114]);x0,y0,x1,y1=20,315,156,351;bg=np.median(g[y0:y1,214:260],axis=1);a=np.clip((bg[:,None]-g[y0:y1,x0:x1])/np.maximum(bg[:,None],1),0,1);a[a<.085]=0
pic=Image.new('RGB',(1150,220),'white');dr=ImageDraw.Draw(pic);raw=Image.fromarray(whole[y0:y1,x0:x1].round().astype('uint8'));clean=Image.fromarray((255*(1-a)).round().clip(0,255).astype('uint8')).convert('RGB');pic.paste(raw.resize((raw.width*3,raw.height*3),Image.Resampling.NEAREST),(5,30));pic.paste(clean.resize((clean.width*3,clean.height*3),Image.Resampling.NEAREST),(470,30));dr.text((5,5),'Actual source prefix 4SL16/: source spacing retained',fill='blue');dr.text((470,5),'Black source ink with local clean background removed',fill='blue')
photo=fresh(root/'TIEN TO 4SL16 NGUYEN KHOANG CHU NGUON.png');pic.save(photo)
out=dict(source_SHA256=before[0],current_SHA256=before[1],source_page=8,source_word='4SL16/20',source_canvas_rect=list(cv.rect0),source_render_box=[x0,y0,x1,y1],source_page_box=[*cv.to_page(x0,y1),*cv.to_page(x1,y0)],source_alpha=a.tolist(),source_background_by_row=bg.tolist(),local_background_columns600=[214,260],source_prefix_glyph_count=6,prefix_literal='4SL16/',physical_scale=1.,prefix_source_advance_to_suffix600=140.,source_suffix_20_start600=160,source_prefix_box_left600=20,source_vertical_baseline600=34,photo=photo,catalogue_written=False,status='ỨNG VIÊN: giữ nguyên cả cụm 4SL16/ và khoảng chữ nguồn; ROOT đọc hình thức trước khi vẽ PDF. Không thay phông.')
Path(fresh(root/'TIEN TO 4SL16 NGUYEN KHOANG CHU NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('Actual prefix kept, no font/spacing reconstruction, noPDF',flush=True)
