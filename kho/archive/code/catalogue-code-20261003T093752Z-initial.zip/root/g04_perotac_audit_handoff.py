from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,math,hashlib,collections,csv,copy

root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
v4=json.loads((root/'DO NET NGUON LAN4.json').read_text(encoding='utf8'));v5=json.loads((root/'DO NET NGUON LAN5.json').read_text(encoding='utf8'))
axes=json.loads((root/'TRUC H DOC VA DOI CHIEU LAN4.json').read_text(encoding='utf8'))['graphs'];av={a['family']:a for a in axes}
all5={c['model']:c for g in v5['graphs'] for c in g['curves']}
# The source captions in these seven cases overlap/intersect multiple lines.
# Trial seeds are not sufficient evidence of literal name -> actual curve.
ambiguous_identity={'4SA6/7','4SA6/8','4SA6/6','4SA8/8','4SA8/6','4SA8/9','4SA8/7'}
manual_variant5={'3SS4/9','6SA45/8'}|{c['model'] for g in v5['graphs'] if g['family']=='6SA25' for c in g['curves']}
graphs=[];rows=[];fails=[];marginal=[];allcurves=[]
for gg in v4['graphs']:
 g=copy.deepcopy(gg);g['axis']=copy.deepcopy(av[g['family']]);g['visual_review_pending']=False;g['trace_pending_visual_review']=False
 g['whole_curve_numerical_acceptance']=False;curves=[]
 for old in gg['curves']:
  c=copy.deepcopy(all5[old['model']] if old['model'] in manual_variant5 else old)
  c['used_measurement_variant']=5 if old['model'] in manual_variant5 else 4
  c['visual_review_pending']=False;c['whole_curve_numerical_acceptance']=False
  if c.get('excluded_previously_accepted'):
   curves.append(c);continue
  if c['model'] in ambiguous_identity:
   c['identity_confirmed']=False;c['reason']='Chữ đen/nét thấp chồng nhau; chưa chứng minh nối tên này với đúng một nét. Không dùng H/kW/thứ hạng để gán.'
   c['rejected_trial_reference']='DO NET NGUON LAN4.json; DO NET NGUON LAN5.json'
   c.pop('native_path',None);c.pop('seed',None);c.pop('seed_candidates',None)
   c['points']=[dict(Q_m3_h=q,H_table_m=h,status='CHƯA THỂ XÁC MINH',reason=c['reason']) for q,h in zip(c['Q_m3_h'],c['H_table_m'])]
  else:
   for p in c.get('points',[]):
    if 'v_native' not in p:continue
    axis=g['axis'];hc=axis['H_grid_calibration'];cal=axis['calibration'];br=p['native_source_bracket'];a,b=br;dx=b['u']-a['u'];sl=(b['v']-a['v'])/dx
    H=(p['v_native']-hc['v_H0'])/hc['v_per_m'];metres_px=1/abs(hc['v_per_m'])
    axis_v_unc=1.0 if hc['only_black_frame_endpoints_used'] else max(.5,hc['max_residual_native_px'])
    uncertainty=math.ceil((axis_v_unc+.5*max(a['width'],b['width'])+.5+abs(sl)*(cal['max_residual_native_px']+.5))*metres_px*10)/10
    delta=H-p['H_table_m'];tol=max(1,.02*p['H_table_m']);amb=p['status']=='CHƯA THỂ XÁC MINH' and p['reason'].startswith('Nét nguồn bị mất/chồng')
    other=next((x for x in all5[c['model']].get('points',[]) if x['Q_m3_h']==p['Q_m3_h']),{})
    disagreement=None
    if c['used_measurement_variant']==4 and 'H_curve_m' in other:
     disagreement=abs(p['H_curve_m']-other['H_curve_m'])
     if disagreement>max(p['uncertainty_H_m'],other['uncertainty_H_m']):amb=True
    if amb:
     status='CHƯA THỂ XÁC MINH';reason='Hai cách đo mực nguồn/nhánh tại chữ chồng chưa cùng cho một tâm nét chắc; giữ chưa xác minh.'
    elif abs(delta)<=tol:status='KHỚP MỐC';reason='Khớp mốc trong ngưỡng max(1m,2%H); không đại diện cho toàn đường giữa các mốc.'
    elif abs(delta)<=tol+uncertainty:status='CHƯA THỂ XÁC MINH';reason='Lệch tâm nominal nhưng chưa vượt ngưỡng cộng độ không chắc của ảnh/trục.'
    else:status='LỆCH CHẮC';reason='Tên/nét đã đối chiếu nguồn; lệch vượt max(1m,2%H) kể cả cộng độ không chắc đọc.'
    p.update(H_curve_m=float(H),delta_H_m=float(delta),delta_percent=float(100*delta/p['H_table_m']) if p['H_table_m'] else None,uncertainty_H_m=float(uncertainty),tolerance_H_m=tol,status=status,reason=reason,H_calibration_used='Khung/vạch H thật và số in trong chính biểu đồ; TRUC H DOC VA DOI CHIEU LAN4.json',variant4_5_difference_H_m=disagreement)
    if abs(delta)>tol and status=='CHƯA THỂ XÁC MINH':marginal.append(dict(page=c['page'],model=c['model'],**p))
  for p in c.get('points',[]):
   rr=dict(page=c['page'],family=c['family'],model=c['model'],identity_confirmed=c.get('identity_confirmed',False),used_measurement_variant=c['used_measurement_variant'],**p);rows.append(rr)
   if p['status']=='LỆCH CHẮC':fails.append(rr)
  curves.append(c);allcurves.append(c)
 g['curves']=curves;g['point_counts']=dict(collections.Counter(p['status'] for c in curves for p in c.get('points',[])));graphs.append(g)

# Separate actual units/rows on 6SA35. The lower 6 m3/h label is at a
# different x from upper 83 l/min; no association based on proximity.
hints=json.loads((root/'GOI Y TRUC VA NHAN LAN1.json').read_text(encoding='utf8'));hg=next(g for g in hints['graphs'] if g['family']=='6SA35')
lower=[]
for w in hg['flow_tick_words']:
 if w['box'][1]>=556 and w['text'] in ['0','6','12','18','24','30','36','42']:
  lower.append(dict(Q_m3_h=float(w['text']),u_native=(w['box'][0]+w['box'][2])/2,word_box=w['box']))
lower.sort(key=lambda t:t['Q_m3_h']);assert len(lower)==8
lowerfit=np.polyfit([t['Q_m3_h'] for t in lower],[t['u_native'] for t in lower],1)
ac=av['6SA35']['calibration'];units=dict(lower_printed_row_m3_h=lower,lower_native_slope_per_m3_h=float(lowerfit[0]),lower_native_intercept=float(lowerfit[1]),upper_from_actual_l_min_ticks_native_slope_per_m3_h=ac['u_per_l_min']*1000/60,upper_native_intercept=ac['u_Q0'],upper_83_u_native=next(t['u_native'] for t in av['6SA35']['flow_ticks'] if t['litre_per_minute']==83),lower_6_u_native=next(t['u_native'] for t in lower if t['Q_m3_h']==6),conclusion='Hai hàng đơn vị có vạch riêng; 83 lít/phút không cùng tọa độ với 6 m³/giờ. Nghi vấn mâu thuẫn trục trước đó đã loại, không coi là lỗi nguồn.')
Path(fresh(root/'DOI CHIEU HAI HANG DON VI 6SA35.json')).write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding='utf8')

counts=dict(collections.Counter(p['status'] for p in rows));assert len(rows)==1915
out=dict(task='Kiểm toán toàn bộ 17 biểu đồ Q-H Perotac SA, 11 trang; chỉ đọc',source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),read_only=True,pdf_written=False,common_progress_written=False,source_only_original_JPEG_images=True,native_image_dpi=150.00556,all_17_source_tables_read_at_400dpi=True,total_source_models=196,total_QH_cells=1931,excluded_previously_accepted_models=['4SA16/23','4SA16/18'],excluded_previously_accepted_points=16,audited_models=194,audited_points=1915,curve_identity_confirmed_count=sum(c.get('identity_confirmed',False) for c in allcurves),point_counts=counts,confirmed_deviating_points=fails,nominal_deviation_unresolved_points=marginal,unknown_curve_identity_models=sorted(ambiguous_identity),efficiency_curve_numerical_coverage=dict(curves=17,accepted_whole_curves=0,reason='Nguồn có 17 đường hiệu suất η nhưng không có bảng η tương ứng; không tạo số và không nghiệm thu số cho toàn đường.'),page9_has_QH_graph=False,graphs=graphs,actual_result_readback_file='DOC LAI PDF BAN GIAO.json',actual_result_readback_tight_file='DOC LAI MUC RIENG BAN GIAO.json',unit_rows_file='DOI CHIEU HAI HANG DON VI 6SA35.json',disclaimer='Khớp các mốc có số thật không chứng minh mọi điểm liên tục giữa các mốc hoặc ngoài miền số bảng.')
Path(fresh(root/'KIEM TOAN CUOI DE ROOT DOC.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
keys=['page','family','model','Q_m3_h','H_table_m','H_curve_m','delta_H_m','delta_percent','uncertainty_H_m','tolerance_H_m','status','identity_confirmed','reason']
with Path(fresh(root/'1915 MOC QH DOI CHIEU.csv')).open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)

E=Editor(src);R=Raster(E)
for fam in ['3SS3','3SS4','4SA16']:
 g=next(x for x in graphs if x['family']==fam);rec=next(x for x in DATA if x['family']==fam);im=max(R.images(rec['page']-1),key=lambda t:t.W*t.H);cv=R.canvas(im)
 x0,y0,x1,y1=rec['plot_native_box'];box=(x0-30,y0-54,x1+35,y1+150);pic=Image.fromarray(cv.orig[box[1]:box[3],box[0]:box[2]]).resize(((box[2]-box[0])*3,(box[3]-box[1])*3),Image.Resampling.NEAREST);d=ImageDraw.Draw(pic)
 for c in g['curves']:
  if not any(p['status']=='LỆCH CHẮC' for p in c.get('points',[])):continue
  for p in c.get('native_path',[]):
   if p['u']%4==0:
    u,v=(p['u']-box[0])*3,(p['v']-box[1])*3;d.ellipse((u-1,v-1,u+1,v+1),fill=(210,0,170))
  for p in c.get('points',[]):
   if p['status']!='LỆCH CHẮC':continue
   u=(p['target_u_native']-box[0])*3;vc=(p['v_native']-box[1])*3;hc=g['axis']['H_grid_calibration'];vt=(hc['v_H0']+hc['v_per_m']*p['H_table_m']-box[1])*3
   d.line((u,vc,u,vt),fill='red',width=2);d.ellipse((u-5,vc-5,u+5,vc+5),outline='red',width=2);d.rectangle((u-4,vt-4,u+4,vt+4),outline='blue',width=2)
 fn='BANG CHUNG LECH CHAC '+fam+'.png';pic.save(fresh(root/fn))
E.close()

md=['# Kiểm toán Perotac SA — hồ sơ chỉ đọc','',f'Nguồn và PDF đang giao giữ nguyên mã SHA256. Chưa ghi PDF, chưa ghi tiến độ chung.','',f'Đã đọc đủ 11 trang, 17 bảng Q-H: 196 dòng model, 1.931 ô số. Loại đúng 2 đường 4SA16/23 và /18 đã ROOT nghiệm thu 16 mốc; xét 194 đường còn lại, 1.915 mốc.', '',f'Kết quả tại mốc: {counts}. Chưa coi khớp mốc là ĐẠT toàn đường. Khóa được danh tính {out["curve_identity_confirmed_count"]}/194 đường; 7 trường hợp chồng chữ/nét giữ CHƯA THỂ XÁC MINH.', '', 'Mốc lệch chắc (Q: m³/giờ; H: mét; Δ: đường trừ bảng):','', '| Trang | Model | Q | H bảng | H đường | Δ m | Δ % | Sai số đọc ±m | Ngưỡng m |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
for p in fails:md.append(f'| {p["page"]} | {p["model"]} | {p["Q_m3_h"]:g} | {p["H_table_m"]:g} | {p["H_curve_m"]:.4f} | {p["delta_H_m"]:.4f} | {p["delta_percent"]:.2f}% | {p["uncertainty_H_m"]:g} | {p["tolerance_H_m"]:g} |')
md+=['','3SS4/24 tại Q=5,4: tâm đường có lệch nominal nhưng khác cách đọc mực ở đầu nét. Dữ liệu cuối dùng cách 4 và sai số ảnh; giữ CHƯA THỂ XÁC MINH, không dùng kết quả dò lần 3 để nâng thành lệch chắc.','', 'Các kết quả dò lớn sai ở 6SA25/3 và phần nhãn chồng 4SA8 đã loại; không sử dụng để kết luận lỗi. Cách 5 theo lại đúng đường xám 6SA25/3,/6, 3SS4/9 và 6SA45/8 từ chính nguồn sau khi xem ảnh.', '', 'Các danh tính chưa khóa: '+', '.join(sorted(ambiguous_identity))+'. Số Q-H của bảng vẫn được đọc đầy đủ; không gán nhánh theo cột áp/công suất hay thứ hạng.', '', 'Ngưỡng đúng: max(1 m; 2% H bảng). Sai số đọc dựa độ dày mực, tọa độ vạch nguồn, độ dốc tại điểm, sai số khớp trục Q, sai số trục H; làm tròn sai số lên 0,1 m. Bảng chi tiết giữ cả điểm khớp, lệch, thiếu đoạn, chồng nhánh và lệch còn trong sai số.', '', 'Trục 4SA10: các số H in 0,40,...240 và lưới có bước riêng. Chỉ dùng hai khung đen H=0/H=240, tăng độ không chắc trục; không tự gắn nhãn 30 vào vạch lưới. Các trục còn lại đọc vạch/nhãn H thật.', '', units['conclusion'], '', 'Đọc lại PDF thật: ảnh gốc 11 trang giữ nguyên byte và ma trận. Các ô nghi sai trang 2–3 không khác điểm ảnh giữa nguồn/bản đang giao. Ô rộng trang 8 có nét /18,/23 đã sửa nên khác; vùng mực riêng /20,/25 được đọc lại ở 600 dpi, 0 điểm ảnh khác. Không đo lại hai đường đã được duyệt.', '', '17 đường hiệu suất η không có bảng số η: chưa nghiệm thu số cho toàn đường. Trang 9 chỉ có bảng kích thước, không có đồ thị Q-H. Phần giữa mốc và ngoài miền bảng chưa có số thật để xác minh mọi tọa độ.', '', 'Phương án sau ROOT kiểm độc lập: chỉ sửa những đường/mốc đã khóa chắc. Các đường này có chuỗi Q-H trong chính tệp; có thể dựng nét giảm trơn theo mốc bảng hoặc chỉnh có giới hạn, giữ màu/độ dày/loại nét, nhãn, lưới và đường khác. Giữ tọa độ hai đầu nguồn ở phần không có số; kiểm miền nối và độ giảm trước khi tạo mẫu. Nếu giữ đầu nguồn mâu thuẫn với mốc cuối thì báo rõ và không dựng theo giả định. ROOT xem mẫu PDF thật trước cập nhật bản đang giao; tối đa hai mẫu thất bại mỗi phương pháp.', '', 'Hồ sơ dùng: KIEM TOAN CUOI DE ROOT DOC.json; 1915 MOC QH DOI CHIEU.csv; BANG QH DOC TU NGUON V6.json; TRUC H DOC VA DOI CHIEU LAN4.json; BANG CHUNG LECH CHAC 3SS3/3SS4/4SA16.png; DOC LAI PDF BAN GIAO.json; DOC LAI MUC RIENG BAN GIAO.json.','',f'SHA256 nguồn: `{sha(src)}`',f'SHA256 bản đang giao: `{sha(dst)}`','']
Path(fresh(root/'KIEM TOAN CUOI DE ROOT DOC.md')).write_text('\n'.join(md),encoding='utf8')
print('HANDOFF POINT COUNTS',counts,'IDENTITY',out['curve_identity_confirmed_count'],flush=True)
for p in fails:print('CONFIRMED',p['model'],p['Q_m3_h'],p['H_table_m'],round(p['H_curve_m'],6),round(p['delta_H_m'],6),p['uncertainty_H_m'],flush=True)
print('No PDF edit. Source/current SHA unchanged.',flush=True)
