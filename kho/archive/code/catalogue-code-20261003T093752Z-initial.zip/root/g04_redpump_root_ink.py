"""ROOT kiểm riêng điểm ảnh mực nguồn Redpump và bản mẫu, không ghi PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np,hashlib
import pymupdf as fitz
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
root=Path(S.report('G04/REDPUMP MAU NET PDF2'))
b=json.loads((root/'TAO VA KIEM MAU.json').read_text(encoding='utf8'))
E=Editor(b['source'],backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);raw=cv.orig
with fitz.open(b['source']) as d:
    hits=[z for z in d[7].get_images(full=True) if z[2:4]==(1739,1237)];assert len(hits)==1
    p=fitz.Pixmap(d,hits[0][0]);assert p.n==3
    native=np.frombuffer(p.samples,dtype=np.uint8).reshape(p.height,p.width,3).copy()
assert raw.shape==native.shape
delta=np.max(abs(raw.astype(int)-native.astype(int)),axis=2)
decode=dict(source_image_name=str(im.name),pixel_count=int(delta.size),different_pixels=int((delta>0).sum()),max_channel_difference=int(delta.max()),Pillow_MuPDF_pixel_arrays_exact=bool(np.array_equal(raw,native)))
ax,bx,ay,by=b['axis'];plot=b['allowed_plot'];dpi=600
before=np.asarray(verify.crop(b['current'],7,plot,dpi)).astype(float)
after=np.asarray(verify.crop(b['trial'],7,plot,dpi)).astype(float)
def pos(q,h):return ((ax*q+bx-plot[0])*dpi/72,(plot[3]-(ay*h+by))*dpi/72)
out=[]
for rec in b['records']:
    core=np.array(rec['RGB'],float);con=255-core
    srcmass=[];newmass=[];cols=[];sourcecores=[]
    for q in np.linspace(8,17,81):
        if min(abs(q*1000/60-v[0]) for v in b['source_ticks_lmin'])<3:continue
        h=float(np.polyval(np.polyfit(rec['Q'],rec['H'],3),q)+2)
        x,y=pos(q,h);x=int(round(x));y=int(round(y))
        vs=np.arange(max(0,y-30),min(len(before),y+31));pix=before[vs,x]
        chroma=pix[:,1:].mean(1)-pix[:,0]
        candidates=np.where(chroma>7)[0]
        if not len(candidates):continue
        groups=np.split(candidates,np.where(np.diff(candidates)>1)[0]+1)
        good=min(groups,key=lambda z:abs(np.average(vs[z],weights=np.maximum(chroma[z],1))-y))
        vc=float(np.average(vs[good],weights=chroma[good]));vv=np.arange(max(0,int(round(vc))-10),min(len(before),int(round(vc))+11))
        profile=before[vv,x];cc=profile[:,1:].mean(1)-profile[:,0]
        eligible=cc>5
        if not eligible.any():continue
        rgb=profile[eligible][np.argmin(profile[eligible].mean(1))];sourcecores.append(rgb.tolist())
        alpha=np.clip(np.median((255-profile)/con,axis=1),0,1);alpha[cc<5]=0
        slope=float(np.polyval(np.polyder(np.polyfit(rec['Q'],rec['H'],3)),q)*ay/ax)
        sw=float(alpha.sum()*72/dpi/np.sqrt(1+slope*slope))
        # Read the actual new path's intersection, not a source-derived fit.
        with fitz.open(b['trial']) as d:
            candidates=[]
            for path in d[7].get_drawings():
                if path.get('type')!='s' or path.get('color') is None:continue
                if max(abs(np.array(path['color'])-core/255))>1e-6:continue
                for item in path['items']:
                    if item[0]!='c':continue
                    xy=np.array([[v.x,d[7].rect.height-v.y] for v in item[1:]],float)
                    xx=ax*q+bx
                    if xy[0,0]-1e-6<=xx<=xy[-1,0]+1e-6:
                        lo=0.;hi=1.
                        for _ in range(45):
                            t=(lo+hi)/2;p0=(1-t)**3*xy[0]+3*t*(1-t)**2*xy[1]+3*t*t*(1-t)*xy[2]+t**3*xy[3]
                            if p0[0]<xx:lo=t
                            else:hi=t
                        candidates.append(p0)
        assert len(candidates)==1,(rec['model'],q,len(candidates))
        p0=candidates[0];ny=int(round((plot[3]-p0[1])*dpi/72));nv=np.arange(max(0,ny-10),min(len(after),ny+11))
        npix=after[nv,x];nc=npix[:,1:].mean(1)-npix[:,0]
        na=np.clip(np.median((255-npix)/con,axis=1),0,1);na[nc<5]=0
        nw=float(na.sum()*72/dpi/np.sqrt(1+slope*slope))
        srcmass.append(sw);newmass.append(nw);cols.append(dict(Q=float(q),source_width_area_pt=sw,new_width_area_pt=nw))
    assert len(cols)>40
    out.append(dict(model=rec['model'],sample_count=len(cols),source_core_actual600dpi_medianRGB=np.median(sourcecores,axis=0).tolist(),source_width_perpendicular_median_pt=float(np.median(srcmass)),new_width_perpendicular_median_pt=float(np.median(newmass)),median_width_difference_pt=float(np.median(newmass)-np.median(srcmass)),native150dpi_pixel_width_pt=abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]),source_width_is_inferred_not_original_PDF_pen=True,samples=cols))
E.close()
Path(fresh(root/'ROOT DO MAU VA MUC ACTUAL.json')).write_text(json.dumps(dict(native_decoder_check=decode,results=out,method='Mực thật render600dpi: trung vị alpha từng kênh, tiết diện vuông góc; chỉ mẫu tránh lưới dọc; sai khác phương pháp đọc/thang xám không tự biến thành ĐẠT.'),ensure_ascii=False,indent=2),encoding='utf8')
print('ROOT source decoders',decode,flush=True)
for z in out:print({k:v for k,v in z.items() if k!='samples'},flush=True)
