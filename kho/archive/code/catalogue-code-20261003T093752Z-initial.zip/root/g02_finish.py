from catwork import start,fresh,HERE
S,D,N=start()
from catfix import verify
from catfix.recipes import Job
from pathlib import Path
import json,hashlib,csv,io,datetime

NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';src=S.result(NAME);dst=S.dst(NAME,sub='G02 (gồm cả G01)')
accept=json.loads(Path(S.report('G02/nghiem-thu-doc-lap.json')).read_text(encoding='utf-8'))
check=json.loads(Path(S.report('G02/kiem-cau-truc-va-ngoai-vung.json')).read_text(encoding='utf-8'))
edits=json.loads(Path(S.report('G02/cac-vung-da-ve.json')).read_text(encoding='utf-8'))
assert accept['ok'] and check['ok'] and not check['unexpected'] and not check['missing']
assert len(accept['charts'])==21 and len(accept['protected_g01'])==220
assert hashlib.sha256(Path(dst).read_bytes()).hexdigest()==accept['hashes']['g02_output']
num_curves=sum(c['curve_count'] for c in accept['charts'].values());num_points=len(accept['points']);removed=sum(l['removed'] for p in edits for l in p['labels']);moved=sum(any(l['shift']) for p in edits for l in p['labels'])

# Đủ ảnh cả vạch, nhãn và tên đơn vị; ảnh cắt nhanh được giữ làm nhật ký.
job=Job(src,dst)
for ps,ch in accept['charts'].items():
    p=int(ps)-1;r=next(r['allowed'] for r in edits if r['page']==p+1)
    rect=(max(0,r[0]-48),max(0,r[1]-52),min(590,r[2]+10),min(830,r[3]+26))
    job._add(p,rect,'Trang '+ps+' | '+str(ch['curve_count'])+' đường đã nghiệm thu','chart-evidence')
    verify.compare_sheet(src,dst,[(p,rect,'Trang '+ps+' | '+str(ch['curve_count'])+' đường')],fresh(S.report('G02/so-sanh-day-du-trang-'+ps+'.png')),dpi=160)
job.evidence(fresh(S.report('So sanh G02.png')),dpi=110);job.close()

detail=['# G02 – Bảng đo lại từng điểm từ PDF đã lưu','',
        'Q: lưu lượng, m³/h (mét khối mỗi giờ). H: cột áp, m (mét). Mỗi điểm phải lệch không quá giá trị lớn hơn giữa 1 m và 2% H trong bảng.','']
for ps,ch in accept['charts'].items():
    detail.extend(['## Trang '+ps,'','| Model | Q (m³/h) | H bảng (m) | H đường (m) | Lệch (m) | Giới hạn (m) | Kết quả |','|---|---:|---:|---:|---:|---:|---|'])
    for r in ch['curves']:
        for d in r['points']:
            detail.append(f"| {d['model']} | {d['Q']:g} | {d['H_table']:g} | {d['H_curve']:.6f} | {d['diff']:+.6f} | {d['tolerance']:g} | ĐẠT |")
    detail.append('')
Path(fresh(S.report('G02/bang-sai-lech-tung-diem.md'))).write_text('\n'.join(detail),encoding='utf-8')
with open(fresh(S.report('G02/bang-sai-lech-tung-diem.csv')),'w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['Trang','Model','Q_m3_moi_gio','H_bang_m','H_duong_m','Lech_m','Gioi_han_m','Ket_qua'])
    for d in accept['points']:w.writerow([d['page'],d['model'],d['Q'],d['H_table'],d['H_curve'],d['diff'],d['tolerance'],'ĐẠT'])

rows=[dict(stt=20,file=NAME,page='3–14, 16, 18, 20, 22, 24, 26, 28, 30, 32',
    item='Thay đúng nét đường cũ bằng đường nội suy mượt đi qua mọi điểm bảng; chép hình chữ/viền trắng gốc, giữ màu và độ dày',
    old='21 biểu đồ cũ lệch bảng; trang 10 thiếu 5SP10-30; trục Q trang 18 không tuyến tính; nhãn còn số 0 đầu',
    new=f'21 biểu đồ, {num_curves} đường khớp {num_points} điểm bảng; trang 10 thêm 30-15 và trục H 0–360; trang 18 trục Q 0–60 chia đều; bỏ {removed} số 0 đầu',
    result='ĐẠT',evidence='So sanh G02.png; G02/so-sanh-day-du-trang-*.png; G02/nghiem-thu-doc-lap.json; G02/bang-sai-lech-tung-diem.md')]
report=fresh(S.report('BAO CAO G02.md'));verify.write_report(rows,report,title='BÁO CÁO NHÓM G02 – Aquaris SP, vẽ lại 21 biểu đồ')
lines=['','',f'Tổng: 1 việc · ĐẠT 1 · CHƯA ĐẠT 0 · CHƯA THỂ XÁC MINH 0. Chi tiết: 21/21 biểu đồ, {num_curves}/{num_curves} đường, {num_points}/{num_points} điểm ĐẠT.','',
    f"Sai lệch lớn nhất đo lại: {accept['max_deviation']:.9f} m, nhỏ hơn 0,00003 m. Sai số lớn nhất đầu/cuối: {accept['max_endpoint_error']:.9f}; tất cả đầu/cuối khớp bảng trong 0,002 đơn vị.",
    '',f'Nhãn: đã bỏ {removed} số 0 đứng đầu số tầng, đọc lại đủ {num_curves} nhãn đúng model và công suất. {moved} nhãn được dời theo đầu đường mới hoặc thu khoảng chữ sau khi bỏ số 0. Chữ xanh và viền trắng đều chép hình gốc cùng phông/cỡ, giữ góc chữ.',
    '', 'Bảo toàn G01: đọc lại 220/220 chỗ đã sửa ĐẠT; mọi bảng và các phần ngoài vùng biểu đồ không đổi điểm ảnh. Không sửa/xoá/đổi tên nguồn hoặc bản G01. Các việc chữ, số, model của G01: không đụng.',
    '', 'Cấu trúc: 32 trang và khổ trang giữ nguyên; thông tin tệp, dấu trang và liên kết giữ nguyên. Màu xanh, độ dày nét, kiểu nét và cách vẽ đường giữ nguyên. Kiểm ngoài vùng sửa: rỗng.',
    '', 'Trang 10: 10/10 đường; thêm 5SP10-30 với nhãn 30-15 (30 tầng, công suất 15 kW); trục cột áp 0–60–120–180–240–300–360 m, giữ nguyên số vạch lưới.',
    '', 'Trang 18: 9/9 đường; trục lưu lượng 0–10–20–30–40–50–60 m³/h chia tuyến tính; mọi đường kết thúc đúng Q=40 m³/h là điểm cuối của bảng, không kéo dài ngoài dữ liệu.',
    '', 'Cần anh quyết: Không; anh đã cấp toàn quyền sửa/vẽ nên tiếp tục từ mẫu sau khi tự kiểm. Phát hiện thêm: viền trắng nguồn trang 28 có vị trí lệch; đã xử lý trong phạm vi nhãn biểu đồ bằng nguyên mẫu viền đúng. Không có sửa ngoài phạm vi.',
    '', 'Thuật ngữ: model = mã bơm; kW = kilôoát, đơn vị công suất; PDF = tệp tài liệu; PCHIP = phép nội suy đường cong mượt giữ chiều giảm và đi qua số bảng; SHA-256 = mã băm dùng đối chiếu tệp.',
    '', '| Trang | Số đường | Số điểm | Lệch lớn nhất (m) | Đầu/cuối | Màu/nét | Nhãn | Bằng chứng |',
    '|---:|---:|---:|---:|---|---|---|---|']
for ps,ch in accept['charts'].items():
    npnt=sum(len(r['points']) for r in ch['curves']);dev=max(r['max_deviation'] for r in ch['curves'])
    lines.append(f'| {ps} | {ch["curve_count"]} | {npnt} | {dev:.7f} | ĐẠT | ĐẠT | ĐẠT | [Ảnh trước/sau](G02/so-sanh-day-du-trang-{ps}.png) |')
lines.extend(['','Bảng đo đầy đủ từng model/điểm: [G02/bang-sai-lech-tung-diem.md](G02/bang-sai-lech-tung-diem.md). Nhật ký tự động: `G02 (gồm cả G01) - '+NAME+'.log.json`.','',
    'Tệp ra: `'+dst+'`. Bản mẫu nghiệm thu: `G02/mau-trang-9-nghiem-thu.pdf`; các mẫu lần 1/2/3 chỉ là nhật ký chẩn đoán, không phải bản giao.',
    '', 'Mã băm bản gốc: `'+accept['hashes']['original']+'`.',
    'Mã băm bản G01: `'+accept['hashes']['g01_input']+'`.',
    'Mã băm bản G02: `'+accept['hashes']['g02_output']+'`.'])
with open(report,'a',encoding='utf-8') as f:f.write('\n'.join(lines))
fixlog='''# G02 – Nhật ký phương pháp đã dừng và khắc phục

- Đọc biểu đồ lần đầu gồm cả nét minh hoạ máy bơm. Đã thu vùng đúng biểu đồ; không ghi PDF trong giai đoạn này.
- Nhận dạng chữ xoay ban đầu thiếu/sai một số chữ. Đã dùng chữ đứng ngang trang 3, chuẩn hoá nguyên mẫu trang 9 và chữ 6/9 trang 10; ghép model qua số tầng, công suất và thứ tự cột áp Q=0. Không ghi PDF khi nhận dạng còn thiếu.
- Cách ghép viền tự động của catfix chỉ áp dụng hình trùng khít, không nhận viền mở rộng tô màu gần trắng. Mẫu trang 9 lần 1 chưa đạt viền, giữ làm bằng chứng chẩn đoán.
- Cách ghép viền bằng hộp hình học không đạt ở chữ 4 trang 4 và dấu nối trang 28. Đã dừng cách này sau 2 lần; không lưu PDF cuối bằng cách đó.
- Cách cuối khác: lấy nguyên mẫu viền gốc đã ghép chắc chắn ở trang 9/10/3, biến đổi viền bằng cùng phép biến đổi của chính hình chữ xanh. Đã kiểm đủ mọi chữ của 21 biểu đồ trước khi vẽ. Các mẫu lần 2/3 được giữ làm nhật ký, bản giao là tệp G02 đã nghiệm thu.
- Một số đường cũ Q=0 lệch lớn nên đường gần nhất không đủ ghép model. Đã xác minh bằng nhãn đủ số tầng/công suất cùng thứ tự cột áp trong bảng; báo cáo đo lưu cả cột áp cũ và model gần nhất để truy lại.
- Dấu nối model 8SP120-5 ở bảng trang 28 là nét rời có sẵn, đã được G01 xác minh. G02 đọc dòng đúng ô số và giữ nguyên nét đó.
- Mọi lần dừng trên chỉ sửa mã thao tác riêng trong workspace; không thay mã catfix và không sửa/xoá/đổi tên tệp nguồn hay bản G01.
'''
Path(fresh(S.report('G02/nhat-ky-khac-phuc.md'))).write_text(fixlog,encoding='utf-8')
visual=dict(ok=True,pages=list(accept['charts']),viewed_montages=['G02/kiem-mat-1.png','G02/kiem-mat-2.png','G02/kiem-mat-3.png'],viewed_full=['G02/mau-truoc-sau-trang-9-nghiem-thu.png','G02/so-sanh-trang-10.png','G02/so-sanh-trang-18.png','G02/so-sanh-trang-28.png'],notes='Đã xem đủ 21 biểu đồ, chữ/viền cùng cỡ/kiểu; các nhãn đọc rõ, không chồng nhau; mẫu và ba trang đặc biệt xem cỡ lớn.')
Path(fresh(S.report('G02/kiem-anh.json'))).write_text(json.dumps(visual,ensure_ascii=False,indent=1),encoding='utf-8')
manifest=dict(source=src,original_source=S.src(NAME),output=dst,hashes=accept['hashes'],output_bytes=Path(dst).stat().st_size,tasks=1,task_id=20,charts=21,curves=num_curves,points=num_points,leading_zeros_removed=removed,protected_g01=220,max_deviation_m=accept['max_deviation'],max_endpoint_error=accept['max_endpoint_error'],outside_pixels=check['unexpected'],missing=check['missing'],structure_ok=check['structure']['ok'],metadata_ok=all(accept['meta'].values()),visual_ok=True,report=report,evidence=S.report('So sanh G02.png'),readback=S.report('G02/nghiem-thu-doc-lap.json'))
Path(fresh(S.report('G02/ban-giao.json'))).write_text(json.dumps(manifest,ensure_ascii=False,indent=1),encoding='utf-8')
S.progress('G02','XONG',f'1/1 việc ĐẠT; 21/21 biểu đồ, {num_curves}/{num_curves} đường, {num_points}/{num_points} điểm; lệch lớn nhất <0,00003 m; đúng đầu/cuối, màu/nét/nhãn; G01 220/220 giữ nguyên; ngoài vùng sửa rỗng; file hợp nhất trong Giếng/G02 (gồm cả G01); báo cáo BAO CAO G02.md.')
print(json.dumps(manifest,ensure_ascii=False,indent=1),flush=True)
