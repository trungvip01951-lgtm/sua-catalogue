"""Source word coordinate sheets; inspection only."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=d['method']['source'];cur=d['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['method']['source_SHA256'],d['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);records=[]
for name,page,rect in [('3 TU NHAN 4SL3_62',5,(123,487,151,504)),('5 TU NHAN 4SL2_52',4,(537,456,565,474)),('5 TU NHAN 4SL3_35',5,(123,412,151,429))]:
 cv=R.render_canvas(page-1,rect,dpi=600);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);core=(g<100)&(a.max(2)-a.min(2)<30);rr=core.sum(1)>3;rows=[]
 for y in np.flatnonzero(rr):
  if not rows or y-rows[-1][-1]>1:rows.append([])
  rows[-1].append(int(y))
 cc=core.sum(0)>3;cols=[]
 for x in np.flatnonzero(cc):
  if not cols or x-cols[-1][-1]>1:cols.append([])
  cols[-1].append(int(x))
 pic=Image.fromarray(cv.orig).resize((cv.orig.shape[1]*3,cv.orig.shape[0]*3),Image.Resampling.NEAREST);dr=ImageDraw.Draw(pic)
 for x in range(0,cv.orig.shape[1],10):dr.line((x*3,0,x*3,6),fill=(180,0,180));dr.text((x*3,6),str(x),fill=(180,0,180))
 for y in range(20,cv.orig.shape[0],20):dr.line((0,y*3,6,y*3),fill=(180,0,180));dr.text((6,y*3),str(y),fill=(180,0,180))
 photo=fresh(root/('GLYPH TOA DO '+name+'.png'));pic.save(photo)
 records.append(dict(name=name,page=page,rect=list(cv.rect0),dpi=600,pixel_shape=list(cv.orig.shape),core_row_groups=[[z[0],z[-1]] for z in rows],core_column_groups=[[z[0],z[-1]] for z in cols],source_photo=photo));print(name,'rows',records[-1]['core_row_groups'],'columns',records[-1]['core_column_groups'],flush=True)
E.close();assert before==[sha(src),sha(cur)]
Path(fresh(root/'GLYPH TRANG4 VA5 TOA DO THUC.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=records,PDF_sample_written=False),ensure_ascii=False,indent=2),encoding='utf8')
