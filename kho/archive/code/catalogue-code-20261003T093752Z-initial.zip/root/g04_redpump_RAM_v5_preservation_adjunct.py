"""RAM-only additional exact preservation checks. Never writes a PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import sys,json,hashlib,math
import numpy as np
import pymupdf as fitz
sys.path.insert(0,str(HERE))
from g04_redpump_ram_builder import build_three_fix_RAM
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Ref

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/(sys.argv[1] if len(sys.argv)>1 else 'CHU NHO BIEN NGUON KHONG EP MUC RAM V5')
geometry_name=sys.argv[2] if len(sys.argv)>2 else '12 GLYPH NHO BIEN MOT MAU RAM V2.json'
variant=sys.argv[3] if len(sys.argv)>3 else 'V5'
folder=F/('BAO TOAN NGOAI VUNG RAM '+variant+' LAN1')
assert not folder.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
a=J(M/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')
atlas=J(P/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json')
layout=J(P/'13 HOP NHAN CUC BO TRANH DUONG LUOI V1.json')
v=J(F/geometry_name)
holes=J(M/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json')
eta=J(M/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[x]) for x in ['source','input_current','sample']]
assert guards==[b[x] for x in ['source_SHA256','input_SHA256','sample_SHA256']]
E,placed,expected,qh=build_three_fix_RAM(b,a,atlas,layout,v,holes,eta)

def render_page(doc,pi,dpi):
    px=doc[pi].get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(px.samples,dtype=np.uint8).reshape(px.height,px.width,px.n)[:,:,:3].copy()

with fitz.open(b['input_current']) as before:
    old=render_page(before,7,200)
    new=render_page(E.doc.doc,7,200)
    assert old.shape==new.shape
    changed=np.any(old!=new,axis=2)
    allowed=np.zeros(changed.shape,bool)
    mb=list(before[7].mediabox)
    scale=200/72
    H,W=changed.shape
    exact_masks=[]
    for r in b['allowed_bboxes']:
        x0=max(0,math.floor((r[0]-mb[0])*scale))
        x1=min(W,math.ceil((r[2]-mb[0])*scale))
        y0=max(0,math.floor((mb[3]-r[3])*scale))
        y1=min(H,math.ceil((mb[3]-r[1])*scale))
        allowed[y0:y1,x0:x1]=True
        exact_masks.append(dict(PDF_rect=r,pixel_rect=[x0,y0,x1,y1]))
    bad=changed&~allowed
    count=int(bad.sum())
    ys,xs=np.where(bad)
    bbox=None if not count else [int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]
    assert count==0,(count,bbox)
    links=lambda doc:[[{k:str(v) for k,v in x.items() if k!='xref'} for x in page.get_links()] for page in doc]
    meta=dict(info=before.metadata==E.doc.doc.metadata,
        raw_XMP=before.get_xml_metadata()==E.doc.doc.get_xml_metadata(),
        bookmarks=before.get_toc()==E.doc.doc.get_toc(),links=links(before)==links(E.doc.doc),
        page_count=len(before)==len(E.doc.doc),
        mediaboxes=[list(p.mediabox) for p in before]==[list(p.mediabox) for p in E.doc.doc],
        cropboxes=[list(p.cropbox) for p in before]==[list(p.cropbox) for p in E.doc.doc],
        rotations=[p.rotation for p in before]==[p.rotation for p in E.doc.doc],
        fonts=[p.get_fonts(full=True) for p in before]==[p.get_fonts(full=True) for p in E.doc.doc])
    assert all(meta.values()),meta
    xr0=before.xref_xml_metadata();xr1=E.doc.doc.xref_xml_metadata()
    if xr0:assert before.xref_stream_raw(xr0)==E.doc.doc.xref_stream_raw(xr1)
    meta['raw_XMP_stream_bytes']=True
    same_pages=[]
    for pi in range(len(before)):
        if pi==7:continue
        assert before[pi].read_contents()==E.doc.doc[pi].read_contents()
        same_pages.append(pi+1)

EA=Editor(b['input_current'],backend='fitz')
RA=Raster(EA);R=Raster(E)
oldimgs=[]
for pi in range(EA.n_pages):
    targets=R.images(pi)
    for src in RA.images(pi):
        hits=[z for z in targets if z.name==src.name and z.W==src.W and z.H==src.H and np.array_equal(z.ctm,src.ctm)]
        assert len(hits)==1,(pi,src.name,len(hits))
        dst=hits[0];raw=EA.doc.stream_raw(src.ref)
        assert raw==E.doc.stream_raw(dst.ref)
        masks=[]
        for key in ['SMask','Mask']:
            x,y=src.d.get(key),dst.d.get(key)
            if isinstance(x,Ref):
                assert isinstance(y,Ref) and EA.doc.stream_raw(x)==E.doc.stream_raw(y)
                masks.append(dict(kind=key,raw_SHA256=hashlib.sha256(EA.doc.stream_raw(x)).hexdigest()))
            else:assert str(x)==str(y)
        oldimgs.append(dict(page=pi+1,name=src.name,size=[src.W,src.H],
            raw_SHA256=hashlib.sha256(raw).hexdigest(),CTM=src.ctm.tolist(),
            CTM_raw_image_and_masks_unchanged=True,masks=masks))

out=dict(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],
    M1=b['sample'],M1_SHA256=guards[2],RAM_recipe=str(F/geometry_name),
    outside_whole_page_actual_RAM=dict(dpi=200,threshold=0,pad_pt=0,rendered_shape=list(old.shape),
        pixels_changed_total=int(changed.sum()),outside_changed_pixels=count,outside_changed_bbox=bbox,
        union_allowed_rects=b['allowed_bboxes'],exact_pixel_masks=exact_masks),
    metadata_links_boxes_fonts=meta,other_page_contents_unchanged=same_pages,
    original_paint_image_raw_masks_CTM=oldimgs,QH_fingerprint_26=qh,QH_104_not_remeasured=True,
    graphics_status='CHƯA CHỐT '+variant+': đang cần ROOT/đồ họa đọc. V5 đã CHƯA ĐẠT dáng5/9; không suy bảo toàn thành font PASS.',
    same_bank_common_gray=63,opacity=1,scale=1,advance_unchanged=True,
    eta_numeric='CHƯA THỂ: chỉ hình học nguồn; không có bảng số.',
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False)
fp=fresh(folder/('BAO TOAN RAM '+variant+' NGOAI200 PIXEL0 VA RAW CTM.json'))
Path(fp).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
EA.close();E.close()
assert guards==[sha(b[x]) for x in ['source','input_current','sample']]
print('RAM only outside200thr0pad0',count,'original imageCTM',len(oldimgs),'meta',all(meta.values()),flush=True)
print(fp,flush=True)
