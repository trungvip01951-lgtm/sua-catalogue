"""Chỉ đo mực nguồn13model SP30. Không ghi/vẽ PDF hoặc đường sửa."""
from catwork import start, fresh, HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.interpolate import PchipInterpolator
from pathlib import Path
import numpy as np,json

O='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
d=json.loads(Path(S.report(O+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'))
E=Editor(d['source_path']);R=Raster(E);im=R.images(4)[0];cv=R.canvas(im);a=cv.orig.astype(float);assert im.W==1732 and im.H==1240
b=d['axis'];xt=np.array(b['xticks']);yt=np.array(b['yticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]));nx=lambda x:float(cv.to_px(x,b['y0'])[0]);ny=lambda y:float(cv.to_px(b['x0'],y)[1]);npt=abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]);gx=np.array([nx(x) for q,x in b['xticks']]);gy=np.array([ny(y) for h,y in b['yticks']])
splines=[]
for z in d['all_19_source_rows']:
 qh=z['source_measured_knots_QH'];splines.append(PchipInterpolator([nx(px(q)) for q,h in qh],[ny(py(h)) for q,h in qh]))
body=a[int(ny(b['y1']))+4:int(ny(b['y0']))-4,int(nx(b['x0']))+5:int(nx(b['x1']))-5];base=np.percentile(body.reshape(-1,3),98,axis=0);out=[]
for z in d['models']:
 k=z['row']-1;sp=splines[k];profiles=[];peaks=[]
 for x in range(int(np.ceil(nx(px(17.2)))),int(np.floor(nx(px(29.2))))+1):
  pred=float(sp(x));centers=np.array([s(x) for s in splines]);sep=float(np.min(abs(np.delete(centers,k)-pred)))
  if min(abs(gx-x))<=3 or min(abs(gy-pred))<=3 or sep<6:continue
  # Locate peak in only this already identified source-ranked tube, never near tableH.
  ids=np.arange(int(round(pred))-4,int(round(pred))+5);rgb=a[ids,x];luma=rgb@np.array([.299,.587,.114]);j=int(np.argmin(luma));peak=rgb[j]
  if base.mean()-peak.mean()<45:continue
  yc=ids[j];ids=np.arange(yc-3,yc+4);rgb=a[ids,x]
  profiles.append(dict(native_x=x,native_y=int(yc),RGB=rgb.tolist(),slope=float(sp.derivative()(x)),core_peak_RGB=peak.tolist(),predicted_center_y=pred));peaks.append(peak)
 assert len(profiles)>=10,(z['model'],len(profiles))
 ps=np.array(peaks);lum=ps@np.array([.299,.587,.114]);ink=np.median(ps[lum<=np.percentile(lum,20)],axis=0);vec=base-ink;norm=float(vec@vec);widths=[]
 for p in profiles:
  alpha=np.clip(np.maximum(0,base-np.array(p['RGB']))@vec/norm,0,1);w=float(alpha.sum()*npt/np.sqrt(1+p['slope']**2));p.update(alpha=alpha.tolist(),equivalent_ink_width_pt=w);widths.append(w)
 rec=dict(model=z['model'],source_core_RGB=ink.tolist(),source_background_RGB=base.tolist(),native_pixel_pt=npt,number_of_native_profiles=len(profiles),source_opacity_area_width_pt_median=float(np.median(widths)),source_width_pt_quantiles=np.percentile(widths,[10,25,50,75,90]).tolist(),profiles=profiles,not_exact_original_PDF_pen=True,method='Lõi20%tối nhất, alpha chiếuRGB. Tổngalpha tiết diện vuông góc, bỏlưới/tiết diện sát nét khác; nguồn150dpi. Không dùng H bảng.')
 out.append(rec);print(z['model'],len(profiles),'RGB',ink,'width',rec['source_opacity_area_width_pt_median'],flush=True)
Path(fresh(S.report(O+'DO MUC JPEG NGUON 13 MAY.json'))).write_text(json.dumps(dict(source_sha256=d['source_sha256'],current_sha256=d['current_sha256'],read_only=True,curves=out),ensure_ascii=False,indent=2),encoding='utf8');E.close()
