"""Observed Redpump frame and actual secondary-axis ticks; candidates only."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.signal import find_peaks
from PIL import Image,ImageDraw
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
axis=json.loads((root/'17 TRUC NGUON CANDIDATE.json').read_text(encoding='utf8'))
panels=json.loads((root/'DUONG VA NHAN HIEN HANH V2/DINH VI ANH V2.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);records=[]
def runs(ids):
 out=[]
 for i in ids:
  if not out or i-out[-1][-1]>1:out.append([])
  out[-1].append(int(i))
 return out
for p,z in zip(panels['records'],axis['records']):
 assert p['family']==z['family']
 a=p['plot_page_rect'];small=p['page'] in [1,2,10,11]
 rect=(a[0],310 if small else 240,a[2],a[3]);cv=R.render_canvas(p['page']-1,rect,dpi=600)
 rgb=cv.orig.astype(float);g=rgb@np.array([.299,.587,.114]);H,W=g.shape
 ht=cv.to_px(0,z['H_frame_top_page'])[1];hb=cv.to_px(0,z['H_frame_bottom_page'])[1]
 xs=(g[int(ht+20):int(hb-20),:]<155).mean(0)
 groups=runs(np.flatnonzero(xs>.86));xx=[float(np.average(c,weights=xs[c])) for c in groups]
 # The source JPEG's horizontal core spans exactly four rendered rows in some
 # boxes. A seven-row mean discards it at .6 coverage. Select the observed core
 # row within the independently located H0 band instead of diluting its ink.
 hs=g[int(hb-8):int(hb+9),:]
 hy=int(np.argmax((hs[:,int(W*.17):int(W*.82)]<155).mean(1)))
 hzero=hs[hy,:]<155
 spans=runs(np.flatnonzero(hzero));span=max(spans,key=len)
 assert len(span)>W*.6,(p['family'],'H0 rule cannot be independently located',len(span),W)
 xx=[x for x in xx if span[0]-5<x<span[-1]+5]
 assert len(xx)==2,(p['family'],xx)
 left,right=xx
 # Select a continuous printed axis under the efficiency box, independently of table.
 etab=cv.to_px(0,z['efficiency_bottom_page'])[1]
 y0=int(etab+18);y1=int(etab+145)
 # Secondary Q rule is gray in p8, unlike the black H frame. Locate a long
 # actual rule by coverage, keeping font strokes out, rather than demanding black.
 ys=(g[y0:y1,int(left+25):int(right-25)]<235).mean(1)
 groups=runs(np.flatnonzero(ys>.83))
 line_candidates=[float(np.average(c+y0,weights=ys[c])) for c in map(np.array,groups)]
 assert line_candidates,(p['family'],z)
 line=min(line_candidates)
 # Actual short black stems below the printed m3/h rule.
 ticks=np.mean(255-g[int(line+3):int(line+10),:],axis=0)
 ids,_=find_peaks(ticks,height=48,prominence=26,distance=28)
 ids=[int(i) for i in ids if left-10<i<right+2]
 im=Image.fromarray(cv.orig)
 ycut=int(etab-10);photo=im.crop((int(left-30),ycut,int(right+5),int(min(H,line+110))))
 draw=ImageDraw.Draw(photo)
 for j,x in enumerate(ids):
  px=x-(left-30);py=line-ycut
  draw.line((px,py-6,px,py+12),fill=(180,0,180),width=1)
  draw.text((px-3,0),str(j),fill=(180,0,180))
 file=fresh(root/'TRUC NGUON DINH VI V4'/f'TRANG {p["page"]:02} {p["family"]} TICK CANDIDATE.png');photo.save(file)
 rec=dict(page=p['page'],family=p['family'],source_render_rect=list(cv.rect0),source_dpi=600,H_frame_x_native_render=[left,right],H_frame_x_page=[cv.to_page(x,0)[0] for x in xx],Q_secondary_axis_y_render=line,Q_secondary_axis_y_page=cv.to_page(0,line)[1],Q_tick_candidates_render=ids,Q_tick_candidates_page=[cv.to_page(x,0)[0] for x in ids],Q_tick_candidate_strength=[float(ticks[x]) for x in ids],source_photo=str(file),status='CANDIDATE: inspect stems and printed labels before fitting')
 records.append(rec);print(p['family'],'frames',np.round(rec['H_frame_x_page'],3),'line',round(rec['Q_secondary_axis_y_page'],3),'ticks',len(ids),np.round(rec['Q_tick_candidates_page'],3),flush=True)
E.close();assert before==[sha(d['source']),sha(d['current'])]
Path(fresh(root/'17 TRUC NGUON XY CANDIDATE V4.json')).write_text(json.dumps(dict(records=records,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
