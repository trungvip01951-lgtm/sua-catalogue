"""Source local tick mapping and original small side-rule evidence. No PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));whole=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));ax=plan['source_axis'];src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
qs=np.array(ax['Q_printed_values']);qx=np.array(ax['Q_printed_tick_page_x']);hs=np.array(ax['H_printed_values_used'])[::-1];hy=np.array(ax['H_printed_grid_page_y'])[::-1]
assert np.all(np.diff(qs)>0) and np.all(np.diff(qx)>0) and np.all(np.diff(hs)>0) and np.all(np.diff(hy)>0)
def local(v,units,coords):
 j=int(np.clip(np.searchsorted(units,v,side='right')-1,0,len(units)-2));f=float((v-units[j])/(units[j+1]-units[j]));assert -1e-12<=f<=1+1e-12
 return dict(value=float(v),page_coord=float(coords[j]+f*(coords[j+1]-coords[j])),between_printed_values=units[j:j+2].tolist(),between_observed_tick_page_coords=coords[j:j+2].tolist(),fraction=f,interpolation='Tuyến tính chỉ trong hai vạch thực lân cận, không fit toàn trục.')
records=[]
for row in plan['page8_QH_models']:
 r=[]
 for q,h in zip(row['Q'],row['H']):
  a,b=local(q,qs,qx),local(h,hs,hy);r.append(dict(Q=q,H_source=h,Q_local=a,H_local=b,page_xy=[a['page_coord'],b['page_coord']],global_fit_xy_crosscheck_only=[ax['axis'][0]*q+ax['axis'][1],ax['axis'][2]*h+ax['axis'][3]]))
 records.append(dict(model=row['model'],anchors=r,first_actual_QH=r[0],last_actual_QH=r[-1],anchors_count=len(r)))
assert sum(z['anchors_count'] for z in records)==104
E=Editor(src,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im)
photo=Image.new('RGB',(1450,1800),'white');dr=ImageDraw.Draw(photo);strips=[]
for i,(name,box) in enumerate([('QH LEFT actual source',(110,165,140,577)),('QH RIGHT actual source feet',(724,165,772,577)),('ETA LEFT actual source',(104,572,143,681)),('ETA RIGHT actual source',(724,572,765,681))]):
 a=Image.fromarray(cv.orig).crop(box);scale=3;p=a.resize((a.width*scale,a.height*scale),Image.Resampling.NEAREST);x=5+340*i;photo.paste(p,(x,40));dr.text((x,5),name,fill='blue');strips.append(dict(name=name,source_native_box=list(box),source_page_bbox=[*cv.to_page(box[0],box[3]),*cv.to_page(box[2],box[1])],photo_x=x,photo_scale=scale))
side_photo=fresh(root/'VACH PHU H VA FEET ETA NGUON THAT.png');photo.save(side_photo)
out=dict(source_SHA256=before[0],current_SHA256=before[1],source_axis_readback_json=str(whole/'17 TRUC DOC NGUON RIENG KHOA V1.json'),Q_observed_ticks=list(map(lambda v,x:dict(Q=v,page_x=x),qs.tolist(),qx.tolist())),H_observed_ticks=list(map(lambda v,y:dict(H=v,page_y=y),hs.tolist(),hy.tolist())),records=records,total_models=13,total_source_H=104,fit_only_crosscheck=ax['axis'],max_source_global_fit_residual_pt=dict(Q=ax['Q']['max_residual_pt'],H=ax['H']['max_residual_pt']),source_tick_uncertainty_pt=.24,source_frame_and_stroke_uncertainty_pt=.48,local_mapping_authority='Mỗi tọa độ vạch nguồn đã đọc thực, được giữ riêng; hệ số fit không dùng dựng neo. Chênh vị trí vạch do ảnh nguồn không đều không được san bằng.',curve_interpolation='Sau khi ánh xạ cục bộ mỗi neo Q/H thành tọa độ trang, nội suy PCHIP trong x/y vật lý để giữ đường trơn và đi qua từng neo thật. Đọc actual Bézier bằng x cục bộ, nghịch đảo H cục bộ để nghiệm thu; không chấm lại theo fit toàn trục.',Q6_transition_local=local(6.,qs,qx),dashes=[6.95,3.41],dash_phase=0.,dash_rule='Tính theo chiều dài cung từ đầu Q0 thực, chuyển kiểu tại x(Q6) cục bộ. Không dịch pha để các mốc bảng rơi vào mực.',side_rule_source_photo=side_photo,side_rule_source_strips=strips,side_rule_policy='Giữ vạch phụ nguồn. Cần đọc từng vạch nhỏ bị miền dựng chạm trước khi cho vẽ; không gán đơn vị/số phụ từ thứ hạng.',secondary_Q_and_units_outside_rebuild=True,feet_labels_outside_rebuild=True,catalogue_written=False,status='KẾ HOẠCH ÁNH XẠ CỤC BỘ 104 NEO; chưa vẽ mẫu PDF.')
Path(fresh(root/'104 NEO QH ANH XA VACH THUC CUC BO V1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('104 source anchors -> local true ticks. Q6 x',out['Q6_transition_local']['page_coord'],'noPDF',flush=True)
