"""Sửa G04 bằng catfix; nét chữ chỉ lấy từ chính PDF đang sửa."""
from catwork import start, fresh
from pathlib import Path
import sys,json,hashlib,copy
import numpy as np
from PIL import Image
S,D,N=start()
from catfix.raster import Raster
from catfix.verify import crop

fi=int(sys.argv[1]); short=['Perotac','Redpump'][fi]
plan=json.loads(Path(S.report('G04/KE HOACH '+short+(' bo sung' if fi else '')+'.json')).read_text(encoding='utf-8'))
d=plan['file']; assert not plan['fails'];fresh(d['dst'])
job=S.job(d['name']);R=job.R;cvs={};banks={};prepared=[]
def cv_for(page):
    pi=page-1
    if page not in cvs:
        im=R.images(pi)[0]
        if im.has_stencil_mask:cv=R.render_canvas(pi,(0,0,d['width'],d['height']),dpi=300)
        else:
            cv=R.canvas(im)
            job._canvases[('img',im.key,im.index)]=cv
        cvs[page]=cv
    return cvs[page]
def mapped(page,r):
    b=R.images(page-1)[0].page_bbox
    return [b[0]+x*(b[2]-b[0])/841.89 if i%2==0 else b[1]+x*(b[3]-b[1])/598.79 for i,x in enumerate(r)]
def sample(cv,hit,text):
    cc=R.components(cv,hit['box'],expect=len(text.replace(' ','')))
    assert len(cc)==len(text.replace(' ','')),(text,len(cc))
    assert ' ' not in text
    hs=[c['box'][3]-c['box'][1] for c in cc]
    bots=[c['box'][3] for c,ch in zip(cc,text) if ch not in R.DESC and ch not in R.LOWMARK]
    return dict(text=text,word=dict(text=text,box=hit['box']),base=float(np.median(bots)),comps=cc,size=float(np.percentile(hs,75)))
def scale_sample(s,target):
    """Co nét ảnh có sẵn, không tạo chữ bằng phông ngoài catalogue."""
    ratio=target/s['size'];out=copy.deepcopy(s)
    out['base']=s['base']*ratio;out['size']=target
    for a,b in zip(s['comps'],out['comps']):
        x0,y0,x1,y1=a['box'];nw=max(1,int(round((x1-x0)*ratio)));nh=max(1,int(round((y1-y0)*ratio)))
        b['alpha']=np.asarray(Image.fromarray(a['alpha'].astype(np.float32),'F').resize((nw,nh),Image.Resampling.LANCZOS)).clip(0,1)
        b['box']=(int(round(x0*ratio)),int(round(y0*ratio)),int(round(x0*ratio))+nw,int(round(y0*ratio))+nh)
    return out
def title_source(page,rect,text):
    cv=cv_for(page);rr=mapped(page,rect)
    hits=R.find(cv,text,box=cv.box(rr),scale=4,psm=7)
    if len(hits)==1:hit=hits[0]
    else:hit=dict(text=text,box=cv.box(rr))
    return sample(cv,hit,text)
sources=[]
if fi==0:
    sources=[title_source(2,(576,499,606,513),'3SS2'),title_source(3,(280,489,335,514),'3SS4')]
else:
    sources=[title_source(2,(576,499,606,513),'3SL2'),title_source(3,(280,489,335,514),'3SL4'),
             title_source(8,(267,491,332,514),'4SL16'),title_source(4,(703,491,760,514),'4SL2'),
             title_source(7,(128,214,156,226),'50Hz')]
numeric_extra=[title_source(8,(116,42,134,51),'7.5')]

# Chuẩn bị đủ mẫu trước khi sửa; giữ mẫu nét nguồn không bị tác động bởi các sửa sau.
for p in plan['plans']:
    cv=cv_for(p['page']);action=p['action'];hit=p['hit']
    bank=None
    if action=='replace':
        oldsample=sample(cv,hit,p['old'])
        if p['task'] in [43,44,45]:
            samples=[oldsample]+[scale_sample(s,oldsample['size']) for s in sources]
            bank=R._bank_from_samples(samples)
        else:
            key=(p['page'],tuple(p['learn']))
            if key not in banks:
                ws=R.ocr(cv,cv.box(p['learn']),scale=3,psm=6)
                # Một vài từ OCR rỗng/kích thước 0 không phải nét chữ để học.
                ws=[w for w in ws if w['box'][2]-w['box'][0]>=2 and w['box'][3]-w['box'][1]>=2]
                banks[key]=R.glyph_bank(cv,words=ws)
            raw=banks[key]
            bank=R._bank_from_samples(raw['samples']+[oldsample]+(numeric_extra if p['task']==131 else []))
        assert all(ch in bank['glyphs'] for ch in p['new'] if ch!=' '),(p['task'],p['new'],set(bank['glyphs']))
    prepared.append((p,bank))
    print('PREP',short,p['task'],p['page'],p['old'],'->',p['new'],flush=True)

source_hash=hashlib.sha256(Path(d['src']).read_bytes()).hexdigest()
for p,bank in prepared:
    cv=cv_for(p['page']);action=p['action'];hit=p['hit']
    if action=='replace':R.replace_word(cv,hit,p['new'],bank,align=p['align'])
    elif action in ['drop_s','dot']:
        cc=R.components(cv,hit['box'],expect=len(p['old'].replace(' ','')))
        assert len(cc)==len(p['old'].replace(' ',''))
        R.erase_components(cv,[cc[-1]])
        job.E.log.append(dict(page=p['page'],kind='raster-delete-last',old=p['old'],new=p['new'],box_px=hit['box']))
    elif action=='close_gap':
        cc=R.components(cv,hit['box'],expect=8)
        assert len(cc)==8
        gaps=[cc[i+1]['box'][0]-cc[i]['box'][2] for i in [0,1,3,4,5,6]]
        delta=max(1,int(round(cc[3]['box'][0]-cc[2]['box'][2]-np.median(gaps))))
        R.erase_components(cv,cc[3:])
        for c in cc[3:]:R.stamp(cv,c,c['box'][0]-delta,c['box'][1])
        job.E.log.append(dict(page=p['page'],kind='raster-close-gap',old=p['old'],new=p['new'],delta_px=delta,box_px=hit['box']))
    else:raise ValueError(action)
    job._add(p['page']-1,p['rect'],f'#{p["task"]} {p["label"]}: {p["old"]} -> {p["new"]}','raster')
    print('EDIT',short,p['task'],p['page'],p['old'],'->',p['new'],flush=True)
job.save();job.close()
assert hashlib.sha256(Path(d['src']).read_bytes()).hexdigest()==source_hash
result=job.check(raster=True)
Path(fresh(S.report('G04/KIEM TRA '+short+'.json'))).write_text(json.dumps(dict(src=d['src'],dst=d['dst'],source_sha256=source_hash,result=result,plans=plan['plans']),ensure_ascii=False,indent=2,default=str),encoding='utf-8')
job.evidence(fresh(S.report('G04/So sanh '+short+'.png')),dpi=350)
print('FINAL',short,len(job.edits),'CHECK',result['ok'],'unexpected',result['unexpected'],'missing',result['missing'],flush=True)
