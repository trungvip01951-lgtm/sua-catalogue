from catwork import start
from pathlib import Path
import json,re
S,D,N=start()
from catfix.otext import robust_fit
data=json.loads(Path(S.report('G09/KHOANG CHU TRANG1 Perotac.json')).read_text(encoding='utf-8'))['samples']
seq=[]
for sample in data:
    index=0
    for token in sample['chars'].split(' '):
        bx=sample['boxes'][index:index+len(token)];index+=len(token)
        if re.fullmatch('[a-z]+',token):seq.append(dict(chars=token,boxes=bx))
F=robust_fit(seq)
print('n',F['n'],'rms',F['rms_x'],'max',F['max_x'],flush=True)
print('metrics',[(c,F['lsb'].get(c),F['adv'].get(c),F['bot'].get(c)) for c in 'eidts'],flush=True)
assert all(0<F['adv'][c]<10 for c in 'eidts')
out=Path(S.report('G09/KHOANG CHU CHOT Perotac.json'));assert not out.exists()
out.write_text(json.dumps(F,ensure_ascii=False,indent=2),encoding='utf-8')
