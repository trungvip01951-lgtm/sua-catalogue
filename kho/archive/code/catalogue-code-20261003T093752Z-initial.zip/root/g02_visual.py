from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
from PIL import Image,ImageDraw
import json
plans=json.loads(Path(S.report('G02/ke-hoach-ve.json')).read_text(encoding='utf-8'));pages=list(plans)
for part in range(3):
    chosen=pages[part*7:(part+1)*7];sheet=Image.new('RGB',(1320,1815),'white');dr=ImageDraw.Draw(sheet)
    for j,ps in enumerate(chosen):
        im=Image.open(S.report('G02/so-sanh-trang-'+ps+'.png')).convert('RGB');w,h=im.size
        im=im.crop((w//2+18,25,w,h));im.thumbnail((425,575))
        x=(j%3)*440;y=(j//3)*605
        dr.text((x+10,y+5),'Trang '+ps+' | '+str(len(plans[ps]['curves']))+' duong',fill='black')
        sheet.paste(im,(x+4,y+25))
    out=fresh(S.report('G02/kiem-mat-'+str(part+1)+'.png'));sheet.save(out)
    print(out,flush=True)
