"""Mẫu1 phương án mới SP30: khóa chữ/đường khác, nối thật, PDFtrơn.
Chỉ ghi trong báo cáo; canonical7335… và PDF nguồn không thay đổi.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster,RenderCanvas
from catfix.recipes import Job
from catfix.charts import bezier,draw_polyline
from catfix import verify
from scipy.interpolate import PchipInterpolator,CubicHermiteSpline
from scipy.ndimage import binary_dilation
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib

I='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
O='G05/6SP30 HAI MUOI CHIN MOC/MAU 1/'
d=json.loads(Path(S.report(I+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'))
ink=json.loads(Path(S.report(I+'DO MUC JPEG NGUON 13 MAY.json')).read_text(encoding='utf8'))
current=d['current_path'];source=d['source_path'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)==d['current_sha256'] and sha(source)==d['source_sha256']
b=d['axis'];xt=np.array(b['xticks']);yt=np.array(b['yticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]));qx=lambda x:float(np.interp(x,xt[:,1],xt[:,0]))
ES=Editor(source);RS=Raster(ES);im=RS.images(4)[0];native=RS.canvas(im);a=native.orig;af=a.astype(float);gray=af@np.array([.299,.587,.114]);assert im.W==1732 and im.H==1240
nx=lambda x:float(native.to_px(x,b['y0'])[0]);ny=lambda y:float(native.to_px(b['x0'],y)[1]);pagey=lambda y:float(native.to_page(0,y)[1]);nativept=abs(native.to_page(1,0)[0]-native.to_page(0,0)[0])
splines=[]
for z in d['all_19_source_rows']:
 qh=z['source_measured_knots_QH'];splines.append(PchipInterpolator([nx(px(q)) for q,h in qh],[ny(py(h)) for q,h in qh]))

# Sourcefont body rowbounds read by eye on THUOC HANG DIEM ANH, never OCR
# underscore that is actually a curve. Masks are source pixels, no font synthesis.
bodies={17:(443,450),20:(419,426),24:(388,394),26:(372,378),30:(340,346),32:(325,330),35:(302,307),38:(277,283),42:(246,252)}
fontcore=np.zeros(a.shape[:2],bool);fontband=np.zeros_like(fontcore)
for suffix,(top,bot) in bodies.items():
 fontband[top-2:bot+3,1133:1185]=True
 fontcore[top:bot+1,1134:1184]|=gray[top:bot+1,1134:1184]<180
grown=binary_dilation(fontcore,iterations=2)&fontband&(gray<250)
# Each dark curve seen inside a label band is explicitly ambiguity, not a glyph.
# Its sourceprefix will be retained; never use that pixel as a newly retained glyph.
possible_curve=np.zeros_like(fontcore)
for x in range(1133,1185):
 for sp in splines:
  pred=float(sp(x));ys=np.arange(max(0,int(pred)-3),min(a.shape[0],int(pred)+4));possible_curve[ys,x]|=(abs(ys-pred)<1.8)&(gray[ys,x]<225)
ambiguous=grown&possible_curve;fontlock=grown&~ambiguous
all_caption=np.zeros_like(fontcore)
for suffix,(top,bot) in bodies.items():all_caption[top-2:bot+3,1132:1187]=True
# Low crowded labels and labels13/15 are preserved as an entire sourceprefix;
# these fields are not claimed as automatically separated glyphs.
all_caption[494:580,1132:1187]=True
all_caption[472:484,1132:1187]=True
all_caption[455:470,1132:1187]=True
fontlock|=ambiguous  # Lock ambiguous source pixels; checked as prefix, not as glyphs.

# Curves whose native line intersects a neighbour caption (-26/-32) start AFTER
# the caption, keeping all inseparable oldpixels in an unchangedprefix.
startq={5:16.35,10:16.35,13:18.12,15:18.12,17:13.8,20:13.8,24:13.8,26:16.35,30:13.8,32:16.35,35:13.8,38:13.8,42:13.8}

curves=[];traceproof=[]
for z in d['models']:
 k=z['row']-1;sp=splines[k];suffix=int(z['model'].rsplit('-',1)[1]);xlo=int(np.ceil(nx(px(startq[suffix]))));xjoin=float(native.to_page(xlo,0)[0]);qjoin=qx(xjoin)
 samples=[]
 # Sourcecolor only selects actual ink within independently identified ranktube.
 # Use right-sided clean slices when a caption was intersected at the join.
 for x in range(xlo,xlo+18):
  if suffix in [5,10,13,15,26,32]:
   lo=int(np.ceil(ny(b['y1'])+5));hi=int(np.floor(ny(b['y0'])-5));v=gaussian_filter1d(255-gray[lo:hi,x],.45);peaks,_=find_peaks(v,prominence=18,height=55,distance=3)
   if len(peaks)!=19:continue
   center=int(peaks[::-1][k]+lo);ids=np.arange(center-2,center+3);wt=np.maximum(0,255-gray[ids,x]-np.min(255-gray[ids,x]));yc=float(np.sum(ids*wt)/wt.sum());samples.append([float(x),yc]);continue
  pred=float(sp(x));ys=np.arange(int(round(pred))-2,int(round(pred))+3);rgb=af[ys,x];ch=rgb[:,1]-rgb[:,0];bl=rgb[:,2]-rgb[:,0];contrast=255-gray[ys,x]
  ok=(ch>4)&(bl>4)&(contrast>35)&~fontlock[ys,x]
  if not ok.any():continue
  wt=contrast[ok];yc=float(np.sum(ys[ok]*wt)/wt.sum());samples.append([float(x),yc])
 assert len(samples)>=10,(z['model'],'not enough source-only slices',len(samples))
 ss=np.array(samples);coef=np.polyfit(ss[:,0]-xlo,ss[:,1],1);res=float(max(abs(np.polyval(coef,ss[:,0]-xlo)-ss[:,1])))
 assert res<.9,(z['model'],'unstable source trace',res)
 yc=float(np.polyval(coef,0));slope=float(coef[-2]);rss=ss[:,1]-np.polyval(coef,ss[:,0]-xlo);slope_se=float(np.sqrt(np.sum(rss*rss)/max(1,len(ss)-2)/np.sum((ss[:,0]-ss[:,0].mean())**2)));source_slope_raw=slope;zero_within_error=False
 if slope<0:
  assert slope+2*slope_se>=0,(z['model'],'source slope not monotone beyond measured error',slope,slope_se)
  slope=0.;zero_within_error=True
 yjoin=pagey(yc);dyjoin=-slope
 tx=np.array([px(q) for q in z['Q']]);ty=np.array([py(h) for h in z['H_table']]);target=PchipInterpolator(tx,ty);use=np.where(tx>xjoin+1e-7)[0];first=use[0];bridge=CubicHermiteSpline([xjoin,tx[first]],[yjoin,ty[first]],[dyjoin,float(target.derivative()(tx[first]))])
 segs=[];knots=np.r_[xjoin,tx[use]]
 for il,(xa,xb) in enumerate(zip(knots[:-1],knots[1:])):
  fun=bridge if il==0 else target;delta=xb-xa;ya=float(fun(xa));yb=float(fun(xb));da=float(fun.derivative()(xa));db=float(fun.derivative()(xb));segs.append([[float(xa),ya],[float(xa+delta/3),ya+da*delta/3],[float(xb-delta/3),yb-db*delta/3],[float(xb),yb]])
 xx=np.linspace(xjoin,tx[-1],1800);yy=np.where(xx<=tx[first],bridge(np.minimum(xx,tx[first])),target(xx));assert np.all(np.diff(yy)<=1e-7),(z['model'],'nonmonotone')
 st=next(v for v in ink['curves'] if v['model']==z['model'])
 rec=dict(model=z['model'],rank=k+1,suffix=suffix,source_label=z['model'],Q=z['Q'],H_table=z['H_table'],known_bad_Q=z['known_bad_Q'],Q_join=qjoin,xjoin_native=xlo,source_native_y_join=yc,source_tangent_page=dyjoin,source_slope_native_raw=source_slope_raw,source_slope_standard_error=slope_se,source_zero_slope_within_2SE=zero_within_error,start_page=[xjoin,yjoin],end_page=segs[-1][-1],new_Q=[z['Q'][i] for i in use],segments=segs,source_core_RGB=st['source_core_RGB'],width_pt=st['source_opacity_area_width_pt_median'],source_center_samples=samples,source_center_residual_native_px=res,maximum_negative_slope_native=float(max(np.diff(yy)/np.diff(xx))),source_center_selected_without_H_table=True)
 curves.append(rec);traceproof.append(dict(model=z['model'],Q_join=qjoin,fit_residual_native_px=res,source_color_only_within_native_rank=True))
 print('SOURCE_JOIN',z['model'],qjoin,yc,slope,res,flush=True)

# Remove only the13previous own-vectorobjects; keep original image+patch+3other
# SP30paths exactly. Fresh intermediate in reports, never canonical.
base=S.report(O+'BASE CHI BO 13 DUOI.pdf');reuse_base=Path(base).exists();jb=None
if reuse_base:
 checkpoint=json.loads(Path(S.report(O+'NHAT KY BASE.json')).read_text(encoding='utf8'));assert str(Path(checkpoint['src']))==str(Path(current)) and str(Path(checkpoint['dst']))==str(Path(base));ET=Editor(current);P=ET.page(4)
else:
 jb=Job(current,fresh(base),backend='fitz',log_path=fresh(S.report(O+'NHAT KY BASE.json')));P=jb.E.page(4)
oldpaths=[]
for c in curves:
 p=next(p for p in d['models'] if p['model']==c['model']);ois={v['actual_object_index'] for v in p['all_8_current_points'] if v.get('actual_vector')};assert len(ois)==1,(c['model'],ois);oi=next(iter(ois));o=P.objs[oi];assert o['op']=='S';path=P.object_pagepath(oi)
 assert abs(path[0][1][0][0]-px(30))<1,(c['model'],'old path source')
 if jb is not None:jb.E.delete_object(4,oi)
 oldpaths.append(dict(model=c['model'],object_index=oi,path=path))
if jb is not None:
 jb._add(4,b['rect'],'Intermediate only: bỏ13nét đuôi của chính phiên đãsửa để dựng một nét liên tục','diagnostic-base');jb.save();ck=jb.check(raster=False);assert ck['ok'];jb.close()
else:
 BX=Editor(base);remaining=[P.object_pagepath(oi) for oi,o in enumerate(P.objs) if o['op']=='S' and oi not in [v['object_index'] for v in oldpaths]];BP=BX.page(4);actual=[BP.object_pagepath(oi) for oi,o in enumerate(BP.objs) if o['op']=='S'];assert actual==remaining and len(actual)==3;BX.close();ET.close();ck=dict(ok=True,reused_own_checkpoint_base=True,remaining3paths_exact=True)

EB=Editor(base);RB=Raster(EB);rc=RB.render_canvas(4,b['rect'],600);r=rc.rect0;scale=72/600;origbase=rc.orig.copy();orig=np.array(verify.crop(current,4,r,600));assert orig.shape==origbase.shape
H,W=orig.shape[:2];xs=r[0]+(np.arange(W)+.5)*scale;ys=r[3]-(np.arange(H)+.5)*scale;iu=np.clip(np.floor((xs-im.ctm[2,0])/im.ctm[0,0]*im.W).astype(int),0,im.W-1);iv=np.clip(np.floor((1-(ys-im.ctm[2,1])/im.ctm[1,1])*im.H).astype(int),0,im.H-1)
native_font=fontlock[iv[:,None],iu[None,:]];native_caption=all_caption[iv[:,None],iu[None,:]]

# Native ink removal only on real sourceprefix up to the existing corrected
# rasterbackground edge. Voronoi ownership prevents adjacentcurve deletion.
xp0=nx(b['x0']);xp1=nx(b['x1']);yp0=ny(b['y1']);yp1=ny(b['y0']);ylo=int(np.ceil(yp0+3));yhi=int(np.floor(yp1-3));xl=int(np.ceil(xp0+5));xr=int(np.floor(xp1-5));body=af[ylo:yhi,xl:xr];vp=np.median(body,axis=0);hp=np.median(body,axis=1);basecolor=np.percentile(body.reshape(-1,3),98,axis=0);gridY=np.array([ny(y) for h,y in b['yticks']]);gridX=np.array([nx(x) for q,x in b['xticks']]);native_tube=np.zeros(a.shape[:2],bool);native_bg=a.copy();ambig_changed=[]
for x in range(min(c['xjoin_native'] for c in curves),int(np.ceil(nx(px(30.11))))+1):
 centers=np.array([sp(x) for sp in splines]);yy=np.arange(ylo,yhi);dist=abs(yy[:,None]-centers);owner=dist.argmin(1)
 for c in curves:
  if x<c['xjoin_native']:continue
  k=c['rank']-1;sep=float(np.min(abs(np.delete(centers,k)-centers[k])));rad=min(13.,max(2.,sep*.5-.8));ids=yy[(owner==k)&(dist[:,k]<=rad)&~fontlock[yy,x]]
  native_tube[ids,x]=True
  bgr=np.tile(basecolor,(len(ids),1));on=np.min(abs(ids[:,None]-gridY),axis=1)<=3.;bgr[on]=hp[np.clip(ids[on]-ylo,0,len(hp)-1)];bgr=np.minimum(bgr,vp[int(np.clip(x-xl,0,len(vp)-1))]);native_bg[ids,x]=np.clip(np.round(bgr),0,255).astype(np.uint8)
  # Any ambiguous pixel retained in a curve that is being modified is NOT a
  # glyphpass. Keep explicit list for rejection/alternate join if nonempty.
  ambids=yy[(owner==k)&(dist[:,k]<1.8)&ambiguous[yy,x]]
  if len(ambids):ambig_changed.append(dict(model=c['model'],native_x=x,native_y=ambids.tolist()))
mask=native_tube[iv[:,None],iu[None,:]];background=origbase.copy();background[mask]=native_bg[iv[:,None],iu[None,:]][mask]
preview=RenderCanvas(4,r,600,background.copy(),None)
for c in curves:
 pts=[]
 for seg in c['segments']:pts.extend(bezier(*map(np.array,seg),n=230).tolist())
 draw_polyline(preview,pts,color=tuple(map(lambda v:int(round(v)),c['source_core_RGB'])),width_px=c['width_pt']/scale,ss=4)
preview.work[native_font]=orig[native_font]
Image.fromarray(orig).save(fresh(S.report(O+'TRUOC.png')));Image.fromarray(preview.work).save(fresh(S.report(O+'SAU PNG.png')));Image.fromarray(background).save(fresh(S.report(O+'NEN PNG.png')))
Image.fromarray((native_font*255).astype(np.uint8)).save(fresh(S.report(O+'KHOA CHU PNG.png')))
Image.fromarray((native_caption*255).astype(np.uint8)).save(fresh(S.report(O+'TRUONG NHAN CAN SOI.png')))
np.savez_compressed(fresh(S.report(O+'CAC LOP 600dpi.npz')),orig=orig,base=origbase,background=background,preview=preview.work,fontmask=native_font,captionmask=native_caption,native_ambiguous=ambiguous,native_fontlock=fontlock,native_fontcore=fontcore,native_tube=native_tube)
counts=bool(np.array_equal(preview.work[native_font],orig[native_font]));assert counts
rec=dict(current_path=current,current_sha256=d['current_sha256'],source_path=source,source_sha256=d['source_sha256'],base_path=base,base_sha256=sha(base),base_check=ck,rect=r,dpi=600,axis=b,curves=curves,old_13_paths=oldpaths,source_traceproof=traceproof,source_native_ctm=im.ctm.tolist(),source_native_pixel_pt=nativept,native_font_body_rows=bodies,native_font_core_count=int(fontcore.sum()),native_source_fringe_locked_count=int(fontlock.sum()),font_locked600_count=int(native_font.sum()),font_locked_pixels_equal_preview=counts,ambiguous_source_pixels_not_called_glyphs=int(ambiguous.sum()),ambiguous_core_inside_edited_curve=ambig_changed,old_curve_as_font_gate=not ambig_changed,caption_fields_need_actual_pixel_readback=True,source_curves_identified_before_table=True,pdf_written=False,sample_number=1,status='MẪU CHƯA NGHIỆM THU',method='Real sourceforeground lock; source-ranked stroke removal; smooth actual PDF paths through fulltable; sourceperpendicular opacitywidth;13ownoldtails replaced as one stroke. Lowcrowded/26/32prefix preserved throughallcaption.')
Path(fresh(S.report(O+'TOA DO VA LOP NGUON.json'))).write_text(json.dumps(rec,ensure_ascii=False,indent=2,default=lambda v:float(v)),encoding='utf8')
EB.close();ES.close();assert sha(current)==d['current_sha256'] and sha(source)==d['source_sha256']
print('SP30_SAMPLE1_PNG',S.report(O+'SAU PNG.png'),'ambiguity',len(ambig_changed),'fontlocked',int(native_font.sum()),flush=True)
