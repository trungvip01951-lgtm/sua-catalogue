"""Kế hoạch V4: sửa phạm vi ký tự và công khai hạn chế tách chữ nguồn."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
plan=json.loads((folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V3.json').read_text(encoding='utf8'))
unmix=json.loads((folder/'DOC MAU CHU DEN TACH NET BOM CHI NGHIEN CUU.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==plan['source_sha256'] and sha(current)==plan['current_sha256']
plan['stage']='CHỈ KẾ HOẠCH V4 — HÌNH HỌC V3 GIỮ; CHỮ CẦN XÉT TRƯỚC MẪU'
plan['styles']['caption_font']['clear_glyph_bank_covers']='Ký tự cần: A,S,/,0,1,2,3,4,5,6,8,9. Không có7 trong caption p8 và không cần7 cho13tên. Phải chọn mẫu sạch; chưa cóbank.'
plan['styles']['caption_font']['clear_glyph_bank_claimed_ready']=False
plan['styles']['caption_font']['charset_for_literal_model_names']=sorted(set(''.join(r['model'] for r in plan['rows'])))
plan['styles']['caption_font']['automatic_components_without_expected_count_unreliable']=True
plan['styles']['caption_font']['source_color_unmixing_condition_number']=unmix['color_basis_condition_number']
plan['styles']['caption_font']['source_unmixing_only_not_shape_accepted']=True
plan['styles']['caption_font']['manual_clean_glyph_selection_required']=True
plan['styles']['caption_font']['old_11_crossing_line_not_safe_to_copy_as_is']=True
plan['styles']['caption_font']['two_ones_11']='Chọn chữ1 sạch cùng kiểu trong prefix của nhãn sạch như4SA16/25; khi dựng/11 phải có2glyph1 và giữ khoảng chữ/đường cơ sở theo nguồn. Không chép vùng/11 đang bị đường xanh đi xuyên mà chưa tách sạch.'
plan['source_font_readonly_addendum']=dict(
    original_13labels_nearest8x='13 NHAN CHU NGUON PHONG8LAN KHONG DUNG MOI.png',
    automatic_components='DOC THUC 13 NHAN KHONG EP TACH KY TU.json',
    source_ink_math='DOC MAU CHU DEN TACH NET BOM CHI NGHIEN CUU.json',
    every_item_is_source_reading_not_new_font_or_vector_sample=True,
    warning='Các nhãn /23,/11,/8,/4 có nét nguồn chạy qua/vào ảnhcrop. Đếmcomponent ép8không chứng minh8ký tự nguyên; màuđen/xanhxám gần nhau khiến unmixnhạyJPEG. Không nhậnfontPASS trước kiểm hình glyph sạch và PDF thật.')
Path(fresh(folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V4.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Bổ sung chữ nguồn — kế hoạch V4

**V4 giữ toàn bộ số, vạch và bộ nét của V3. Chữ chưa đạt bước xác minh nên chưa tạo mẫu catalogue.**

13 nhãn source (nguồn) đã xem ở nguyên150dpi và phóng8lần bằng điểm ảnh gốc. Các nhãn /23,/11,/8,/4 bị nét bơm chạy qua trong vùng trích; /11 nhìn rõ cả hai số1 nhưng không được chép lẫn đường xanh vào chữ mới.

Đính chính mô tả “0–9” ở V2/V3: tên trang8 cần đúng **A, S, /, 0, 1, 2, 3, 4, 5, 6, 8, 9**. Không có7 trong caption (nhãn đường) p8, và13tên không cần7. Chưa có ngân hàng glyph (mẫu hình ký tự) sạch được nhận.

Tách thành phần bằng catfix không ép số ký tự cho số lượng không ổn. Nghiên cứu tách màu đen/xanh xám bằng hai màu lõi nguồn cũng nhạy nhiễu JPEG: hệ số điều kiện26,3. Đếm đúng8phần tại một ngưỡng không chứng minh đúng8chữ, không đủ để chốt kiểu chữ/độ sắc. Đã lưu cả hai kết quả chỉ đọc, không che hạn chế.

Phương án chữ cần ROOT xét: chọn từng glyph sạch từ nhãn nguồn đúng kiểu; prefix4SA16/25 sạch hơn vùng/11. Có thể lấy chữ1 sạch ở prefix để đặt đúng hai chữ1 cho suffix/11, với khoảng chữ và đường cơ sở đọc từ nguồn. Chữ khác cũng phải có ảnh đối chứng nguồn, hình/lỗ/tỷ lệ/đậm đúng; không tự ép phần cắt thành chữ thiếu nét. Sau đó mới tạo đường bao PDF từ mực nguyên, không phông hệ thống.

Biên đẳng mực và làm mượt0,10pixel còn là phương án chưa được thử. Nếu không chọn đủ glyph sạch/cùng kiểu hoặc vector hóa đổi hình/cỡ/đậm thì mẫu CHƯA ĐẠT; không đổi phông để vượt hạn chế. Chưa tạo glyph vector, ngân hàng mới, PDF hay hình mẫu catalogue.

Đọc V4.json là bộ kế hoạch mới nhất; KHOA PHUONG AN V3 DE ROOT KIEM.md là hình học, V2.md là bảng104ô và phương pháp. Nguồn/canonical (bản giao hiện hành) giữSHA; không ghiTIEN DO.md. Chờ ROOT và tác nhân đồ họa xét trước mẫu.
'''
fix={'13 nhãn source (nguồn)':'13 nhãn nguồn','nguyên150dpi':'nguyên 150dpi','phóng8lần':'phóng 8 lần','số1':'số 1','Không có7':'Không có 7','và13tên':'và 13 tên','không cần7':'không cần 7','điều kiện26':'điều kiện 26','đúng8phần':'đúng 8 phần','đúng8chữ':'đúng 8 chữ','prefix4SA16':'prefix (phần đầu tên) 4SA16','suffix/11':'suffix (phần sau dấu gạch chéo) /11','mượt0':'mượt 0','V4.json':'V4.json','bảng104ô':'bảng 104 ô','giữSHA':'giữ SHA','ghiTIEN':'ghi TIEN'}
for old,new in fix.items():md=md.replace(old,new)
md+='\nSHA nguồn: '+sha(src)+'\n\nSHA bản giao: '+sha(current)+'\n'
Path(fresh(folder/'GIOI HAN CHU NGUON VA KHOA KE HOACH V4.md')).write_text(md,encoding='utf8')
print('PLAN V4; required caption characters',plan['styles']['caption_font']['charset_for_literal_model_names'],flush=True)
print('NO GLYPH BANK/VECTOR/PDF; SOURCE/CURRENT UNCHANGED',sha(src),sha(current),flush=True)
