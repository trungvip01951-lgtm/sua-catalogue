"""M1 actual displayed-ink checks and feet-edge diagnosis; no PDF/canonical edits."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import map_coordinates
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
planroot=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
b=json.loads((root/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'))
a=json.loads((root/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json').read_text(encoding='utf8'))
l=json.loads((planroot/'104 NEO QH ANH XA VACH THUC CUC BO V1.json').read_text(encoding='utf8'))
keep=json.loads((planroot/'VACH PHU FEET VA KHOI TIEU DE GIU NGUON V1.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(b['sample'])==b['sample_SHA256'] and sha(b['input_current'])==b['input_SHA256']
E=Editor(b['sample'],backend='fitz');R=Raster(E)
cv=R.render_canvas(7,(54,268,363,512),dpi=600);ar=cv.orig.astype(float)
con=np.array([121.,106.,103.]);f=np.array([134.,149.,152.])
ticks=l['Q_observed_ticks'];qq=np.array([z['Q'] for z in ticks]);xx=np.array([z['page_x'] for z in ticks])
def bez(v,t):return (1-t)**3*v[0]+3*(1-t)**2*t*v[1]+3*(1-t)*t*t*v[2]+t**3*v[3]
def vec(v,t):return 3*(1-t)**2*(v[1]-v[0])+6*t*(1-t)*(v[2]-v[1])+3*t*t*(v[3]-v[2])
def geom(path):
 out=[];pos=None
 for op,pts in path:
  if op=='m':pos=np.array(pts[0],float)
  elif op=='c':v=np.vstack([pos,pts]);out.append(v);pos=v[-1]
 return out
def point_tangent(segments,x):
 z=next(v for v in segments if v[0,0]-1e-8<=x<=v[-1,0]+1e-8);lo=0.;hi=1.
 for _ in range(60):
  t=(lo+hi)/2
  if bez(z,t)[0]<x:lo=t
  else:hi=t
 t=(lo+hi)/2;v=vec(z,t);n=np.array([-v[1],v[0]])/np.linalg.norm(v)
 return bez(z,t),n
grid=b['grids'][0];measure=[];summary=[]
distance=np.linspace(-1.6,1.6,641)
for record in a['actual_QH_paths']:
 seg=sum([geom(p['path']) for p in record['parts']],[]);rr=[]
 for target in [7.5,10.5,13.5,16.5,19.5]:
  opts=[]
  for q in np.linspace(target-.8,target+.8,81):
   x=float(np.interp(q,qq,xx));point,n=point_tangent(seg,x)
   gridgap=min([abs(point[0]-z) for z in grid['vertical_page_x']]+[abs(point[1]-z) for z in grid['horizontal_page_y']])
   opts.append((gridgap,q,point,n))
  gap,q,point,n=max(opts,key=lambda v:v[0]);assert gap>1.9,(record['model'],target,gap)
  xy=point[None,:]+distance[:,None]*n[None,:]
  coords=np.array([[(cv.rect0[3]-y)/cv.s-.5,(x-cv.rect0[0])/cv.s-.5] for x,y in xy]).T
  rgb=np.vstack([map_coordinates(ar[:,:,k],coords,order=1,mode='nearest') for k in range(3)]).T
  alpha=np.clip((255-rgb)@con/(con@con),0,1)
  width=float(np.trapezoid(alpha,distance))
  threshold_positions={}
  mid=len(distance)//2
  for level in [.1,.9]:
   ids=np.flatnonzero(alpha>=level);assert len(ids)>0
   left,right=ids[0],ids[-1]
   def cross(i,j):return float(distance[i]+(level-alpha[i])/(alpha[j]-alpha[i])*(distance[j]-distance[i]))
   lp=cross(left-1,left) if left else float(distance[left]);rp=cross(right,right+1) if right+1<len(alpha) else float(distance[right])
   threshold_positions[str(level)]=[lp,rp]
  edges=[abs(threshold_positions['0.1'][i]-threshold_positions['0.9'][i])*600/72 for i in range(2)]
  core=rgb[alpha>.999]
  colors=np.median(core,axis=0).tolist() if len(core) else None
  r=dict(model=record['model'],Q_sample_m3h=float(q),physical_point=point.tolist(),normal=n.tolist(),
   grid_distance_pt=float(gap),width_area_pt=width,width_declared_pt=.95,relative_width_difference=float(width/.95-1),
   core_RGB=colors,edges_10_90_pixels_at600=edges,profile_distances_pt=distance.tolist(),profile_alpha=alpha.tolist())
  measure.append(r);rr.append(r)
 widths=np.array([z['width_area_pt'] for z in rr]);median=float(np.median(widths));spread=float(max(abs(widths/median-1)))
 summary.append(dict(model=record['model'],samples=5,width_median_pt=median,max_relative_width_dispersion=spread,
  median_vs_declared_relative_error=float(median/.95-1),max_10_90_edge_pixels=max(max(z['edges_10_90_pixels_at600']) for z in rr),
  core_RGBs=[z['core_RGB'] for z in rr],width_5percent_pass=bool(abs(median/.95-1)<=.05 and spread<=.05),
  sharpness_2pixel_pass=bool(max(max(z['edges_10_90_pixels_at600']) for z in rr)<=2.)))

# All reconstructed colored ink must be a mixture of the single vector RGB and
# neutral white/grid/black; excluded original protected title and source stems.
halorecord=[]
for panel in b['grids']:
 box=panel['allowed'];u0,v0,u1,v1=cv.box(box);sub=cv.orig[v0:v1,u0:u1].astype(int)
 mask=np.ones(sub.shape[:2],bool)
 for hole in panel['protected_holes']:
  hu,hv,hur,hvr=cv.box(hole);mask[max(0,hv-v0):min(v1-v0,hvr-v0),max(0,hu-u0):min(u1-u0,hur-u0)]=False
 # Exclude a single rendered boundary pixel which straddles the paint rectangle.
 mask[[0,-1],:]=False;mask[:,[0,-1]]=False
 gr=sub[:,:,1]-sub[:,:,0];br=sub[:,:,2]-sub[:,:,0]
 chromatic=(sub.max(2)-sub.min(2)>2)&mask
 difference=abs(18*gr-15*br)
 unexpected=chromatic&(difference>33)
 ids=np.argwhere(unexpected)
 photo=None
 if len(ids):
  pic=Image.fromarray(sub.astype(np.uint8));dr=ImageDraw.Draw(pic)
  for v,u in ids[::max(1,len(ids)//500)]:dr.point((int(u),int(v)),fill=(220,0,0))
  photo=fresh(root/f'{panel["name"]} MUC KHAC MAU CHUAN CHI ANH BAO CAO.png');pic.save(photo)
 halorecord.append(dict(panel=panel['name'],chromatic_pixels_checked=int(chromatic.sum()),
  chroma_residual_limit_integer=33,unexpected_chroma_pixels=int(unexpected.sum()),
  exception_pixel_positions_uv_in_crop=ids.tolist(),annotated_report_image=photo,
  meaning='Đo màu hiển thị; không có quầng màu JPEG ngoài bộ RGB mới và các vùng nguồn bảo vệ. Viền1pixel cắt loại vì giao miền; ROOT cần soi hình thực.'))

feet=[];sheet=Image.new('RGB',(1450,5*310),'white');draw=ImageDraw.Draw(sheet)
for i,tick in enumerate(keep['short_feet_ticks']):
 box=tick['source_original_ink_restore_page_bbox'];raw0=np.asarray(verify.crop(b['input_current'],7,box,600));raw1=np.asarray(verify.crop(b['sample'],7,box,600))
 changed=np.any(raw0!=raw1,axis=2);yy,xx2=np.where(changed)
 d=np.max(abs(raw0.astype(int)-raw1.astype(int)),axis=2)
 center0=np.mean(raw0,axis=2);center1=np.mean(raw1,axis=2)
 where=list(zip(xx2.tolist(),yy.tolist()))
 # Image crop x pixels begin at floor(box.x * 600/72), source range is given.
 changedcols=sorted(set(xx2.tolist()))
 stemrect=[max(box[0],355.6),box[1],box[2],box[3]]
 ar0=np.asarray(verify.crop(b['input_current'],7,stemrect,600));ar1=np.asarray(verify.crop(b['sample'],7,stemrect,600))
 stem_changed=int(np.any(ar0!=ar1,axis=2).sum())
 feet.append(dict(index=i+1,whole_original_restore_bbox=box,dpi=600,changed_pixels=int(changed.sum()),
  changed_columns=changedcols,changed_bbox_uv=[int(xx2.min()),int(yy.min()),int(xx2.max()+1),int(yy.max()+1)] if len(xx2) else None,
  maximum_RGB_change=int(d.max()),original_ink_changed_pixels=int((changed&(center0<230)).sum()),
  stem_to_the_right_of_frame_bbox=stemrect,stem_to_the_right_of_frame_changed_pixels=stem_changed,
  status='MÉP HỘP GIỮ THAY PIXEL: chưa gọi toàn vạch ĐẠT.',exact_changed_coordinates=where))
 enlarged0=Image.fromarray(raw0).resize((raw0.shape[1]*8,raw0.shape[0]*8),Image.Resampling.NEAREST)
 enlarged1=Image.fromarray(raw1).resize((raw1.shape[1]*8,raw1.shape[0]*8),Image.Resampling.NEAREST)
 y0=i*310;sheet.paste(enlarged0,(15,y0+35));sheet.paste(enlarged1,(710,y0+35))
 draw.text((15,y0+5),f'Source/current feet tick{i+1}',fill='blue');draw.text((710,y0+5),f'M1:changed {int(changed.sum())} pixels; columns {changedcols}',fill='blue')
sheet.save(fresh(root/'5 VACH FEET MEP HOP GIU DOC THAT 600dpi.png'))

out=dict(sample=b['sample'],sample_SHA256=sha(b['sample']),source_style_inferred_from_JPEG=True,
 profiles=measure,curve_summaries=summary,chromatic_halo_scan=halorecord,feet_original_clip_edge_diagnosis=feet,
 canonical_written=False,shared_progress_written=False,graphic_final_acceptance='CHƯA ĐẠT/CHỜ ROOT: số đã đủ, nhãn/η/vạch phụ phải đọc độc lập.',
 note='Độ dày/độ sắc đo trên mực actualPDF600dpi. Ngưỡng5%/2pixel là quy chuẩn nội bộ của tác nhân đồ họa, không tiêu chuẩn nhà sản xuất.')
Path(fresh(root/'DO MUC ACTUAL MAU1 VA MEP VACH PHU.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close()
print('widths',[(z['model'],round(z['width_median_pt'],6),round(z['max_relative_width_dispersion'],4),round(z['max_10_90_edge_pixels'],3),z['width_5percent_pass'],z['sharpness_2pixel_pass']) for z in summary],flush=True)
print('halo',[(z['panel'],z['unexpected_chroma_pixels']) for z in halorecord],'feet',[(z['index'],z['changed_columns'],z['stem_to_the_right_of_frame_changed_pixels']) for z in feet],flush=True)
