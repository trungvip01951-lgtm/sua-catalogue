"""Freeze source/RAM/banks and prepare gated M1+saved QA. Does not save PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from g04_perotac_whole_pdf_tools46 import read,sha
from g04_perotac_whole_source_island_builder60 import NAME,RAM_REL
import json,ast
here=Path(__file__).resolve().parent
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'M1 WRITER VA QA CHUAN BI CHUA CHAY'
actual_path=base/'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF/CATFIX NGUON9 DAO RAM V2 DOC LAI MUC THAT VA NGOAI VUNG.json'
report=read(actual_path);ram_path=Path(S.report(RAM_REL));ram=read(ram_path)
font_path=Path(S.report(ram['glyph_source_file']));axis_path=Path(S.report(ram['axis_literal_source_file']))
assert sha(font_path)==ram['glyph_source_report_SHA256'] and sha(axis_path)==ram['axis_source_report_SHA256']
files=[Path(S.src(NAME)),Path(S.result(NAME)),actual_path,ram_path,font_path,axis_path,
    base/'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF/MANIFEST ACTUAL RAM9 DAO V2 SHA256.json',
    base/'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF/LENH CATFIX TRANG08 NGUON9 DAO KHONG CHE TRANG.txt',
    base/'KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json',
    base/'DOI CHIEU VACH PHU NGUON THAT/VACH PHU34 VA TRUC CUC BO NGUON V4 DE ROOT KIEM.json',
    base/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON/KHOANG THONG SO PHA VA NHIP NGUON V8 DE ROOT KIEM.json',
    base/'ETA4 DOAN C2 NGUON VA DAU LAN KHUNG/ETA4 BEZIER C2 VA558 DIEM NGUON CHUA CHOT.json',
    here/'g04_perotac_whole_source_island_builder60.py',here/'g04_perotac_whole_saved_qa63.py',here/'g04_perotac_whole_m1_locked65.py',
    here/'g04_perotac_whole_actual_read50.py',here/'g04_perotac_whole_pdf_tools46.py']
syntax=[]
for path in files:
    if path.suffix=='.py':
        ast.parse(path.read_text(encoding='utf8'),filename=str(path));syntax.append(dict(path=str(path),status='SYNTAX ĐẠT; writer/QA không chạy'))
assert (here/'g04_perotac_whole_m1_locked65.py').read_text(encoding='utf8').count('ed.save(')==1
assert sha(S.src(NAME))==report['source_sha256'] and sha(S.result(NAME))==report['canonical_sha256']
manifest=dict(stage='M1 WRITER VÀ QA SAU LƯU CHƯA CHẠY',filesystem_PDF_save_count=0,
    source_sha256=report['source_sha256'],canonical_sha256=report['canonical_sha256'],
    actual_RAM_report_path=str(actual_path),actual_RAM_report_sha256=sha(actual_path),prepared_content_sha256=report['prepared_content_sha256'],
    source_literal_island_keys=report['source_literal_keys_not_reconstructed'],
    locked_files=[dict(path=str(path),sha256=sha(path)) for path in files],syntax_checks=syntax,
    actual_RAM_checks_reference=report['actual_serialized_RAM_checks'],
    M1_writer_path=str(here/'g04_perotac_whole_m1_locked65.py'),post_save_QA_path=str(here/'g04_perotac_whole_saved_qa63.py'),
    exactly_one_CATFIX_save_call_enabled_only_after_ROOT_lock=True,
    canonical_promotion_NOT_AUTHORIZED=True,source_original_font_program_UNKNOWN=True,
    graphic_source9_island_edges_and_actual_RAM_review_PENDING=True,
    post_save_QA_status='CHƯA CHẠY: cần file PDF mẫu được ROOT cho phép tạo',
    no_white_cover_or_new_image_SMask=True,ROI_page_pt=report['ROI_page_pt'],ROI_not_expanded=True,
    outer_clip_only_MediaBox_pad_pt=2,source_and_canonical_PDF_and_progress_unchanged=True)
path=Path(fresh(root/'KHOA SHA RAM SOURCE9 WRITER QA CHUA CHAY.json'))
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
draft=dict(authority='ROOT',scope='Perotac SA page8 whole chart M1',grant_one_fresh_PDF_M1=False,graphic_actual_RAM_approved=False,
    prepared_manifest_sha256=sha(path),actual_RAM_report_sha256=sha(actual_path),
    note='Mẫu cấu trúc CHƯA CẤP PHÉP; chỉ ROOT tạo lock mới sau nghiệm thu đồ họa đúng phiên bản')
Path(fresh(root/'ROOT LOCK SCHEMA CHUA CAP PHEP.json')).write_text(json.dumps(draft,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Chuẩn bị M1 Perotac SA p8 — CHƯA CHẠY

Bản giao/source giữ nguyên; PDF mẫu whole-chart hiện vẫn 0. Writer chỉ chạy khi ROOT cấp khóa mới cho đúng mã kiểm tra tệp của hồ sơ này sau kiểm đồ họa độc lập.

M1 dùng CATFIX một lần lưu vào thư mục mẫu mới riêng; không ghi bản giao. Giữ 9 cụm chữ trong X7 nguồn bằng clip hình học bù, không che trắng, không thêm ảnh/phông hay SMask. Lưới, 13 Q–H, 104 số bảng, 34 vạch, η theo nguồn Perotac đã khóa; không đọc dữ liệu Redpump/CDX.

QA sau lưu đọc lại PDF thật bằng hai kiểm ngoài vùng ở 200 dpi, ngưỡng 0/pad 0/min-size 0 trên 11 trang; kiểm cấu trúc, khổ, Info bytes/XMP raw, font/chữ thật, ảnh+SMask raw, CTM, liên kết/dấu trang, 10 nội dung trang khác và nội dung p8 đúng SHA. Đọc thật 104 neo và độ dày/đậm từ điểm ảnh PDF600; xuất toàn trang150/600 và 9 cụm nguồn–PDF. Kết quả kỹ thuật không tự nhận toàn đồ họa hoặc promote bản giao.

Giới hạn đang chờ ROOT: mép đảo chữ bị ảnh hưởng khử răng cưa, phân loại mực chữ/vạch theo tọa độ; nguyên phông/biên vector ban đầu không tồn tại trong nguồn JPEG. η thiếu bảng số; 11 điểm đầu lẫn khung chưa xác minh. Bộ 4-cung nghiên cứu không dùng làm phông.

Lệnh mặc định writer không có ROOT lock chỉ báo CHƯA CHẠY và thoát. Mẫu khóa JSON hiện đặt cả hai quyền false, nên chưa mở writer. Không sửa TIEN DO.md.
'''
Path(fresh(root/'HUONG DAN WRITER VA QA M1 CHUA CHAY.md')).write_text(md,encoding='utf8')
print('PREPARED',str(path),'SHA256',sha(path),'PDF SAVES 0',flush=True)
