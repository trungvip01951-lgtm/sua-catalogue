from catwork import start, fresh
S,D,N=start()
from pathlib import Path
import json,io
import pikepdf
from fontTools.ttLib import TTFont
from catfix.vector import Editor
from catfix.textlayer import TextLayer
NAME='Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'
src=S.src(NAME)
out=dict(font_objects=[],embedded_fonts=[],resources=[],text_lines=[])
with pikepdf.open(src) as pdf:
    for i,obj in enumerate(pdf.objects):
        if not isinstance(obj,pikepdf.Dictionary):continue
        if obj.get('/Type')==pikepdf.Name.Font or obj.get('/Type')==pikepdf.Name.FontDescriptor:
            out['font_objects'].append(dict(object=i+1,description=str(obj)))
        for key in ('/FontFile','/FontFile2','/FontFile3'):
            if key in obj:
                b=obj[key].read_bytes(); info=dict(object=i+1,key=key,length=len(b))
                try:
                    font=TTFont(io.BytesIO(b)); info.update(names=[str(n) for n in font['name'].names],has_lower_k=107 in (font.getBestCmap() or {}))
                except Exception as ex: info['decode_error']=str(ex)
                out['embedded_fonts'].append(info)
    for p in pdf.pages:
        out['resources'].append(str(p.obj.get('/Resources')))
E=Editor(src); TL=TextLayer(E)
for pi in range(10): out['text_lines'].append([(t,len(gs)) for t,gs in TL.text_lines(pi)])
E.close()
json.dump(out,open(fresh(Path(S.report('G03'))/'font-resources.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
print({k:v for k,v in out.items() if k!='resources'})
