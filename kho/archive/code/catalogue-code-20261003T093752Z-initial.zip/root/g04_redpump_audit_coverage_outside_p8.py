"""SL saved evidence coverage; does not write catalogue or shared progress."""
from catwork import start, fresh
S,D,N=start()
from pathlib import Path
from datetime import datetime
import hashlib, json

root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
out=root/'RA SOAT HO SO17 NGOAI TRANG8 LAN1'
names=['DANH MUC BANG NGUON 196 DONG V2.json',
       '1931 O NGUON DINH VI VA DOI CHIEU V2.json',
       '17 TRUC DOC NGUON RIENG KHOA V1.json',
       'DINH DANH NHAN VA SEED DOC TRUC TIEP V1.json']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
data=[json.loads((root/n).read_text(encoding='utf8')) for n in names]
tables,cells,axes,identities=data
before=[sha(tables['source']),sha(tables['current'])]
assert before==[tables['source_SHA256'],tables['current_SHA256']]
groups=[]
for a in axes['records']:
    rows=[z for z in tables['rows'] if z['page']==a['page'] and z['family']==a['family']]
    ids=[z for z in identities['records'] if z['page']==a['page'] and z['family']==a['family']]
    unknown=[z['table_model_candidate'] for z in ids if z['model_locked'] is None]
    preserved=[z for z in cells['cells'] if z['page']==a['page'] and z['model'] in [r['model'] for r in rows]]
    assert len(preserved)==sum(len(z['H']) for z in rows)
    assert all(z['current_H_cell_pixels_compared'] and z['current_H_cell_changed_pixels']==0 for z in preserved)
    record=dict(page=a['page'],family=a['family'],model_count=len(rows),
        H_cell_count=sum(len(z['H']) for z in rows),models=[z['model'] for z in rows],
        identity_locked=len(ids)-len(unknown),identity_unknown=unknown,
        source_table_read_and_preserved=True,table_pixel_changes=0,
        source_actual_ticks_file=str(root/names[2]),
        source_tick_photos=[a['Q_source_photo'],a['H_source_photo']],
        source_table_photos=list(dict.fromkeys(z['table_photo'] for z in rows)),
        current_label_photos=list(dict.fromkeys(z['current_names_photo'] for z in ids)),
        numeric_curve_scope='104 mốc/13 đường ở MẪU1 đã ROOT đọc độc lập; hình thức/chữ đang kiểm, chưa bản giao.' if a['page']==8 else 'CHƯA ĐO trong các hồ sơ đã đọc; không có phép đọc actual đủ từng mốc.',
        known_sure_numeric_errors_outside_p8=[],
        graphics_uniformity_scope='CHƯA CHỐT: chỉ p8 đang dựng toàn miền theo yêu cầu mới; bảng và trục không chứng minh nét đồng đều.',
        eta_numeric_status='CHƯA THỂ XÁC MINH: không có bảng số η riêng; chỉ có thể đối chiếu hình học mực nguồn.',
        local_tick_rule='Nội suy giữa hai vạch có số quan sát thật liền kề; fit toàn trục chỉ kiểm chéo. Ngoài miền vạch đã khóa phải đọc vạch phụ thực, không ngoại suy.',
        catalogue_written=False)
    groups.append(record)
outside=[z for z in groups if z['page']!=8]
summary=dict(chart_groups=len(groups),model_rows=sum(z['model_count'] for z in groups),
        H_cells=sum(z['H_cell_count'] for z in groups),outside_p8_chart_groups=len(outside),
        outside_p8_models=sum(z['model_count'] for z in outside),
        outside_p8_H_cells=sum(z['H_cell_count'] for z in outside),
        outside_p8_identity_locked=sum(z['identity_locked'] for z in outside),
        outside_p8_identity_unknown=sum(len(z['identity_unknown']) for z in outside),
        outside_p8_numeric_curve_acceptance='CHƯA ĐO; không gọi bằng chứng giữ bảng là nghiệm thu đường.',
        outside_p8_sure_numeric_FAIL_proven_by_read_saved_files=0,
        sure_FAIL_zero_is_not_PASS=True)
assert summary['model_rows']==196 and summary['H_cells']==1931
assert summary['outside_p8_models']==183 and summary['outside_p8_identity_unknown']==27
evidence=[dict(path=str(root/n),SHA256=sha(root/n)) for n in names]
payload=dict(time=datetime.now().isoformat(),source=tables['source'],source_SHA256=before[0],
    current=tables['current'],current_SHA256=before[1],summary=summary,
    source_evidence=evidence,groups=groups,
    already_accepted_skipped=['MẪU1 p8: 13 đường/104 mốc actual được ROOT đọc độc lập; không đo lại trong lượt rà này.',
        '14/14 CAN chữ/số và 84 vị trí đã nghiệm thu trước: không làm lại.',
        'Mốc bảng tăng nhẹ của 6SL25/12,/14,/16,/18,/20 là số nguồn, không tự coi là lỗi.'],
    next_readonly_steps=['Đọc mực nguồn theo nhãn hiện hành đã khóa, không chọn nhánh bằng H bảng.',
        'Chỉ sau khi có trace thật mới quy về local Q/H và đối chiếu bảng; ghi riêng bất định ảnh, dash và nhánh mơ hồ.',
        'Lỗi chắc ngoài p8: lập phương án toàn biểu đồ bằng SL riêng; không tạo PDF hay đổi bản giao.'],
    catalogue_written=False,shared_progress_written=False,
    status='CHƯA XONG: 16 biểu đồ ngoài p8 chưa có nghiệm thu số toàn bộ, hình thức đồng bộ chưa chốt.')
result=Path(fresh(out/'MA TRAN17 BIEU DO VA PHAM VI NGOAI TRANG8.json'))
result.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# BÁO CÁO G04 – Rà hồ sơ Redpump SL ngoài trang 8', '',
    'Đã đọc lại hồ sơ riêng SL: 196 model / 1.931 ô H. Bảng được giữ nguyên từng điểm ảnh; việc này chưa xác nhận đường cong đúng bảng.', '',
    'Ngoài trang 8 có **183 model / 1.827 ô H**; 156 danh tính đã khóa theo nhãn hiện hành và nét nguồn, 27 danh tính chưa chắc. Hồ sơ đã lưu chưa có phép đo đủ từng mốc của 16 biểu đồ này. Chưa có lỗi số chắc ngoài trang 8 được chứng minh trong lượt rà hồ sơ; không suy thành ĐẠT.', '',
    '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
    '|---|---|---|---|---|---|---|---|']
for i,z in enumerate(groups,1):
    scope='ĐÃ ĐO 13/104 ở mẫu; hình thức CHƯA CHỐT' if z['page']==8 else 'CHƯA ĐO số đường; CHƯA CHỐT hình thức'
    uk=', '.join(z['identity_unknown']) or 'không'
    lines.append(f'| R{i:02} {z["family"]} | Redpump SL | {z["page"]} | {z["model_count"]} model / {z["H_cell_count"]} ô H nguồn | Không đổi PDF | Đọc hồ sơ bảng/trục/nhãn thật; {z["identity_locked"]} tên khóa, chưa chắc: {uk} | {scope}; η CHƯA THỂ số | [Ma trận chi tiết]({result.as_posix()}) – {z["family"]} |')
lines+=['',
    '27 đường có danh tính chưa chắc giữ **CHƯA THỂ XÁC MINH**; các đường đã khóa nhưng chưa đo giữ **CHƯA ĐO**. Các đường η của cả 17 biểu đồ không có bảng số riêng, không dựng số kỹ thuật từ hình.', '',
    'Khi đo tiếp phải dùng tọa độ từng vạch liền kề đã quan sát; không thay bằng hệ số khớp toàn trục, không chọn nhánh theo số H mong đợi. Mốc nằm ngoài miền vạch có số cần đọc vạch phụ thật trước.', '',
    'Không tạo PDF, không sửa nguồn/bản giao/MẪU1, không ghi TIEN DO.md. Nguồn và bản giao đã kiểm lại SHA-256 trước/sau.', '',
    f'Nguồn: `{before[0]}`. Bản giao: `{before[1]}`.', '',
    'Bằng chứng gốc và mã SHA-256 từng hồ sơ được lưu trong ma trận JSON. Phần p8 có 104 mốc đã ROOT đọc độc lập ở MẪU1; giữ nguyên kết quả đó, hình thức mới đang chờ kiểm riêng.']
report=Path(fresh(out/'BAO CAO8 COT RA HO SO17 NGOAI TRANG8.md'))
report.write_text('\n'.join(lines)+'\n',encoding='utf8')
assert before==[sha(tables['source']),sha(tables['current'])]
print(json.dumps(dict(summary=summary,result=str(result),report=str(report),reportSHA256=sha(report)),ensure_ascii=False),flush=True)
