"""Chỉ đọc nguồn Perotac, chuẩn bị phương án đồng bộ p8; không vẽ mẫu PDF."""
from catwork import start, fresh
S, D, N = start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from pathlib import Path
from PIL import Image
from g04_perotac_audit_data import DATA
import json, hashlib, fitz, collections

name = 'Perotac bơm giếng SA_compressed (bản mới).pdf'
src, current = S.src(name), S.result(name)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src) == '3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(current) == '389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
folder = Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
progress = S.read_progress()
Path(fresh(folder / 'TIEN DO CHI DOC.txt')).write_text(progress, encoding='utf8')

old = Path(S.report('G04/NAM DUOI NET PDF THAT MAU1'))
old_pdf = old / name
assert sha(old_pdf) == '66c43922eb5b2b6a97f9895e1e912a2fd74e34711e94cdb10b6d6db0e861f015'
superseded = dict(
    reason='Anh Trung yêu cầu toàn bộ đường/biểu đồ đồng bộ độ đậm, độ dày, độ sắc nét, không cảm giác vá; ROOT truyền chỉ đạo mới.',
    technical_trial= str(old_pdf), technical_trial_sha256=sha(old_pdf),
    graphic_status='CHƯA ĐẠT theo yêu cầu mới; không chốt mẫu vá 5 đuôi',
    numeric_measurements_retained_as_technical_evidence=True,
    further_tail_patch_samples_stopped=True,
    canonical_unchanged=True, current_sha256=sha(current),
    new_method='Dựng đồng bộ toàn biểu đồ từ bảng nguồn; trước hết trang 8',
    sample_for_new_method_not_written=True, root_plan_review_required=True,
    common_progress_written=False)
Path(fresh(old / 'MAU1 KY THUAT CHUA DAT DO HOA THEO YEU CAU MOI.json')).write_text(json.dumps(superseded, ensure_ascii=False, indent=2), encoding='utf8')

audit = json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'))
g = next(z for z in audit['graphs'] if z['family'] == '4SA16')
table = next(z for z in DATA if z['family'] == '4SA16')
E, Ec = Editor(src, backend='fitz'), Editor(current, backend='fitz')
R, Rc = Raster(E), Raster(Ec)
im, imc = max(R.images(7), key=lambda z: z.W * z.H), max(Rc.images(7), key=lambda z: z.W * z.H)
assert str(im.name) == 'X7' and 'Cfx' not in str(im.name)
cv = R.canvas(im)
assert E.doc.stream_raw(im.ref) == Ec.doc.stream_raw(imc.ref)

boxes = {
    'NGUON TRANG08 NGUYEN150dpi': [0, 0, 1754, 1247],
    'NGUON BIEU DO QH VA HIEU SUAT': [65, 117, 790, 730],
    'NGUON BANG QH 104 O': [62, 805, 790, 1163],
    'NGUON TRUC Q BON DON VI': [91, 130, 789, 180],
    'NGUON TRUC Q VA HIEU SUAT': [63, 568, 790, 730],
    'NGUON KHOANG TRONG CHO CHU GIAI': [62, 723, 790, 814],
    'NGUON MODEL TU BANG': [62, 839, 285, 1163],
    'NGUON KY TU TU TRUC': [68, 141, 126, 580],
}
for label, box in boxes.items():
    raw = Image.fromarray(cv.orig[box[1]:box[3], box[0]:box[2]])
    raw.save(fresh(folder / (label + '.png')))
    if label in ['NGUON BANG QH 104 O', 'NGUON MODEL TU BANG', 'NGUON TRUC Q BON DON VI']:
        verify.crop(src, 7, cv.rect(box), 600).save(fresh(folder / (label + ' PDF600dpi.png')))

with fitz.open(src) as fs, fitz.open(current) as fc:
    fonts = [dict(page=i+1, fonts=page.get_fonts(full=True), native_text_length=len(page.get_text())) for i,page in enumerate(fs)]
    current_fonts = [dict(page=i+1, fonts=page.get_fonts(full=True)) for i,page in enumerate(fc)]
    xobjects = [dict(page=i+1, objs=page.get_xobjects()) for i,page in enumerate(fs)]
    # Read raw dictionaries of any font objects if the renderer exposes one.
    refs = sorted({int(f[0]) for row in fonts for f in row['fonts']})
    font_objects = [dict(xref=x, dictionary=fs.xref_object(x, compressed=False)) for x in refs]
    font_summary = dict(source_pages=fonts, current_pages=current_fonts, font_objects=font_objects, source_xobjects=xobjects,
                        same_file_embedded_font_candidate_count=len(refs),
                        outside_file_or_system_font_used=False,
                        conclusion='Không có phông nhúng/chữ thật trong 11 trang nguồn; chữ nguồn nằm trong JPEG gốc.' if not refs else 'Có tài nguyên phông; cần đối chứng kiểu trước khi dùng.')
Path(fresh(folder / 'PHONG VA CHU NGUON CHI DOC.json')).write_text(json.dumps(font_summary, ensure_ascii=False, indent=2), encoding='utf8')

points = []
for row in table['rows']:
    for q, h in zip(table['Q_m3_h'], row['H']):
        points.append(dict(model=row['model'], Q_m3_h=q, Q_l_min=q*1000/60, H_m=h, source='Bảng Perotac trang 8; ô thật'))
assert len(table['rows']) == 13 and len(points) == 104
assert [r['suffix'] for r in table['rows']] == [4,5,6,8,9,11,12,14,16,18,20,23,25]
assert all(all(a >= b for a,b in zip(r['H'], r['H'][1:])) for r in table['rows'])

all_counts = []
for t in DATA:
    rises = [dict(model=r['model'], first_Q_m3_h=t['Q_m3_h'][k], next_Q_m3_h=t['Q_m3_h'][k+1], first_H_m=a, next_H_m=b)
             for r in t['rows'] for k,(a,b) in enumerate(zip(r['H'],r['H'][1:])) if b>a]
    all_counts.append(dict(page=t['page'], family=t['family'], model_count=len(t['rows']),
                           numeric_cell_count=sum(len(r['H']) for r in t['rows']), literal_increases=rises,
                           Q_m3_h=t['Q_m3_h'], eta_numeric_table_available=False))
out = dict(read_only=True, pdf_written=False, sample_image_written=False, source_sha256=sha(src), current_sha256=sha(current),
           source_original_image=dict(name=str(im.name), W=im.W, H=im.H, dpi=float(im.dpi), ctm=im.ctm.tolist(), raw_JPEG_sha256=hashlib.sha256(E.doc.stream_raw(im.ref)).hexdigest()),
           literal_table=table, numeric_points=points,
           actual_QH_model_count=13, source_extra_line='η — hiệu suất, không phải model Q–H thứ 14',
           source_model_7_exists=False, axis_previously_read=g['axis'],
           original_curve_metadata=[{k:v for k,v in c.items() if k!='native_path'} for c in g['curves']],
           all_17_graph_counts=all_counts, source_boxes_native=boxes,
           source_font_program_count=len(refs), graphic_design_not_yet_accepted=True,
           unknown_numeric_points_from_old_whole_audit=235, common_progress_written=False)
Path(fresh(folder / '104 O NGUON VA PHAM VI DONG BO CHI DOC.json')).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf8')
E.close(); Ec.close()
print('READ ONLY', len(table['rows']), 'QH MODELS', len(points), 'CELLS; FONTS', len(refs), 'TOTAL GRAPHS', len(all_counts), flush=True)
print('AXIS', json.dumps(g['axis'],ensure_ascii=False), flush=True)
print('CURVE METADATA KEYS',list(g['curves'][0]), flush=True)
print('SOURCE/CURRENT UNCHANGED', sha(src),sha(current), flush=True)
