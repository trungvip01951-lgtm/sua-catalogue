from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster,RenderCanvas
from pathlib import Path
from PIL import Image
import json,numpy as np,cv2

prefix='G05/KIEM TOAN TOAN BO/'
snap=json.loads(Path(S.report(prefix+'TRANG THAI VA OCR.json')).read_text(encoding='utf8'))
E=Editor(snap['source']);R=Raster(E);out=[]
for st in snap['charts']:
    f=st['table_family'];arr=np.array(Image.open(S.report(prefix+f+'-bang.png')).convert('RGB'))
    g=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
    bw=(g<205).astype(np.uint8)*255
    hh=cv2.morphologyEx(bw,cv2.MORPH_OPEN,np.ones((1,60),np.uint8))
    vv=cv2.morphologyEx(bw,cv2.MORPH_OPEN,np.ones((50,1),np.uint8))
    mask=cv2.dilate(cv2.bitwise_or(hh,vv),np.ones((3,3),np.uint8))
    clean=arr.copy();clean[mask>0]=255
    cv=RenderCanvas(st['page']-1,st['table_rect'],st['table_dpi'],clean,None)
    cv.save_png(fresh(S.report(prefix+'OCR BO DUONG KE/'+f+'.png')))
    words=R.ocr(cv,scale=1,psm=6)
    ws=[dict(text=w['text'],rect=cv.rect(w['box']),conf=w['conf'],line=w['line']) for w in words]
    lines={}
    for w in ws:lines.setdefault(str(w['line']),[]).append(w)
    texts=[' '.join(w['text'] for w in sorted(a,key=lambda w:w['rect'][0])) for a in lines.values()]
    Path(fresh(S.report(prefix+'OCR BO DUONG KE/'+f+'.txt'))).write_text('\n'.join(texts),encoding='utf8')
    out.append(dict(family=f,words=ws,lines=texts))
    print(f,'WORD',len(words),'LINES',len(texts),flush=True)
Path(fresh(S.report(prefix+'OCR BO DUONG KE.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close()
