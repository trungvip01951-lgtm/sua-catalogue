"""Read only observed top Redpump 4SL16/25 ink; no expected-H branch selection."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np,hashlib
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import color_runs
from PIL import Image,ImageDraw
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);base=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(base);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);mask=(a[:,:,1]-a[:,:,0]>6)&(a[:,:,2]-a[:,:,0]>8)&(g<230);weight=255-g
records=[]
for u in [280,300,330,350,370]:
 candidates=color_runs(mask,weight,u,185,320,max_width=12)
 records.append(dict(u=u,candidates=candidates));print(u,[(round(z['v'],3),z['width']) for z in candidates],flush=True)
im=Image.fromarray(cv.orig).crop((250,185,405,325));im.resize((im.width*6,im.height*6),Image.Resampling.NEAREST).save(fresh(root/'4SL16_25 NHAN VA NET NGUON RIENG.png'))
E.close();Path(fresh(root/'4SL16_25 SEED CANDIDATE.json')).write_text(json.dumps(dict(source_SHA256=d['source_SHA256'],native_image=[base.W,base.H],source_only=True,candidates=records,status='Provisional seed ink; not a curve-number result'),ensure_ascii=False,indent=2),encoding='utf8');assert before==[sha(d['source']),sha(d['current'])]
