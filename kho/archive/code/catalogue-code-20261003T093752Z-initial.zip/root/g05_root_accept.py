"""ROOT doc lai actual26paths/52moc cua PDF G05 mau, khong ghi PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib,csv,numpy as np
from PIL import Image
from catfix import verify,charts
from catfix.vector import Editor
root=Path(S.report('G05'))
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
source,current=S.src(name),S.dst(name)
trial=S.report('G05/MAU PDF SUA DUONG/'+name)
spec=json.loads((root/'MAU SUA DUONG/PHAM VI DA BO NET CHUA RO 2/TOA DO VA PHUONG PHAP.json').read_text(encoding='utf8'))
axis=json.loads((root/'KIEM TOAN TOAN BO/HIEU CHUAN TRUC V2.json').read_text(encoding='utf8'))
tables=json.loads((root/'KIEM TOAN TOAN BO/BANG DAY DU.json').read_text(encoding='utf8'))
record=json.loads((root/'MAU PDF SUA DUONG/GHI VA KIEM NGOAI VUNG.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)==spec['before_pdf_sha256']
data=json.loads((root/'KIEM TOAN TOAN BO/BANG QH DOC BANG MAT.json').read_text(encoding='utf8'))
def y_at(path,x):
    last=None
    for op,pts in path:
        if op=='m':last=np.array(pts[0],float)
        elif op=='c':
            ctrl=np.vstack([last,pts]);end=ctrl[-1]
            # Actual serialized endpoint differs from the source tick by <1e-5pt.
            # Use its own endpoint inside that bound; never extend the curve domain.
            if last[0]-1e-5<=x<=end[0]+1e-5:
                x=min(max(x,float(last[0])),float(end[0]))
                lo,hi=0.,1.
                for _ in range(70):
                    t=(lo+hi)/2;v=sum(ctrl[k]*((1-t)**(3-k)*t**k)*[1,3,3,1][k] for k in range(4))
                    if v[0]<x:lo=t
                    else:hi=t
                return float(v[1])
            last=end
        else:raise ValueError(op)
    raise ValueError(('x outside actual path',x))
E=Editor(trial);points=[];pres=[];kept=[]
for panel in spec['panels']:
    b=next(x for x in axis if x['family']==panel['family']);xt=np.array(b['xticks']);yt=np.array(b['yticks']);P=E.page(panel['page']-1)
    table=next(x for x in tables if x['family']==panel['family'])
    table_image=verify.crop(current,table['page']-1,table['rect'],450)
    table_path=root/(panel['family']+' BANG NGUON DOC LAP ROOT.png')
    if table_path.exists():assert np.array_equal(np.asarray(table_image),np.asarray(Image.open(table_path)))
    else:table_image.save(fresh(table_path))
    candidates=[]
    for oi,o in enumerate(P.objs):
        color=P.color_of(oi,'stroke')
        if o['op'] not in ('S','s') or color is None:continue
        path=P.object_pagepath(oi);a=charts.sample_path(path,n=300)
        candidates.append((oi,o,path,a,color))
    used=set()
    for c in panel['curves']:
        # Identify actual object by two ends; avoid relying on insertion indices.
        matches=[v for v in candidates if np.max(np.abs(v[3][0]-c['start_page']))<1e-4 and np.max(np.abs(v[3][-1]-c['end_page']))<1e-4]
        assert len(matches)==1,(panel['family'],c['curve_model'],len(matches))
        oi,o,path,a,color=matches[0];assert oi not in used;used.add(oi)
        assert np.all(np.diff(a[:,0])>0) and np.all(np.diff(a[:,1])<=1e-5)
        assert abs(o['lw']-panel['width_pt'])<1e-8
        assert np.allclose(color,np.array(panel['source_color_rgb'])/255,atol=1e-10)
        # Reading rounded PDF cm numbers leaves a measured 1.90e-8pt translation.
        # Bound every coefficient explicitly; this is far below geometry read tolerance.
        assert np.max(np.abs(np.asarray(o['ctm'])-np.eye(3)))<5e-8 and len(o['dash'][0])==0
        d=next(r for r in data[panel['family']]['rows'] if r['curve_model']==c['curve_model'])
        for q in c['new_Q']:
            x=float(np.interp(q,xt[:,0],xt[:,1]));y=y_at(path,x);h=float(np.interp(y,yt[:,1],yt[:,0]));target=d['H'][data[panel['family']]['Q'].index(q)];limit=max(1,.02*target)
            assert abs(h-target)<=limit and abs(h-target)<1e-4
            points.append(dict(page=panel['page'],model=c['curve_model'],actual_object=oi,Q=q,H_table=target,H_read_actual=h,difference=h-target,tolerance=limit,result='ĐẠT'))
        pres.append(dict(model=c['curve_model'],page=panel['page'],actual_object=oi,rgb=color,lw=o['lw'],line_solid=True,matrix=o['ctm'].tolist(),start_actual=a[0].tolist(),end_actual=a[-1].tolist(),monotone=True))
    join=min(x['start_page'][0] for x in panel['curves']);r=panel['rect'];box=(r[0],r[1],join-.5,r[3])
    same=np.array_equal(np.asarray(verify.crop(current,panel['page']-1,box,300)),np.asarray(verify.crop(trial,panel['page']-1,box,300)));assert same
    kept.append(dict(family=panel['family'],page=panel['page'],rect=box,dpi=300,left_original_pixels_same=same,unmapped_original_labels=panel['kept_curves']))
assert len(points)==52 and len(pres)==26
allowed={}
for e in record['edits']:allowed.setdefault(e['page']+1,[]).append(e['rect'])
model=json.loads((root/'BO SUNG MA MODEL/NGHIEM THU.json').read_text(encoding='utf8'));allowed.setdefault(6,[]).append(model['rect'])
outside=verify.outside_pixels(current,trial,allowed,dpi=200,thr=0,min_size=0,pad=.4);assert not outside
E.close()
out=dict(current_sha=sha(current),source_sha=sha(source),trial=trial,trial_sha=sha(trial),actual_path_count=len(pres),point_count=len(points),max_error=max(abs(p['difference']) for p in points),points=points,actual_curves=pres,source_left_guard=kept,outside=outside,visual_review='ROOT soi actualPDF hai panel: sach; da giu nhan -9/khong ro. Can xac nhan52so bang tren2anh ROOT vua xuat truoc chap nhan cuoi.',stroke_reconstruction='Nguon la anh150dpi, mau111/121/124 va112/118/120; lw.48pt do tu netnguon, khong phai thamso vectorgoc.',scope='52moc sua duoi DAT; cacmoc trai/nhan -9/SP14-SP15 va2moc10SP135 khong suy thanh DAT.')
Path(fresh(root/'NGHIEM THU MAU DOC LAP ROOT.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(root/'52 MOC DOC LAP ROOT.csv'),'w',encoding='utf-8-sig',newline='') as fp:
    w=csv.DictWriter(fp,list(points[0]));w.writeheader();w.writerows(points)
print('ROOT G05 actual',len(pres),'paths',len(points),'anchors PASS',out['max_error'],flush=True)
