"""Rebuild own three unit labels with local source punctuation, RAM only."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/CHU TRUC NGUON VA RAM CHI DOC'));root=base/'DON VI DAU CHAM DAU GACH CHEO VA i NGUON V2'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
old=read(base/'CHU SO TRUC VA TIEU DE DUONG BAO RAM CHUA NGHIEM THU.json');micro=read(base/'DAU CHAM VA GACH CHEO CUNG NGUON TACH RIENG/CAC DAU NHO NGUON TACH KHOI NGUONG CA TU.json');by={r['key']:r for r in micro['source_punctuation_only']};zoom=64
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));ink=np.array([57.,55.,57.]);bg=np.array([255.,255.,255.])
def trace(al,epsilon=.07):
    h,w=al.shape;up=cv2.resize(np.pad(al,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);total=float(al.sum());lo=.001;hi=.95
    for _ in range(35):
        t=(lo+hi)/2
        if (up>=t).sum()/zoom**2>total:lo=t
        else:hi=t
    t=(lo+hi)/2;m=up>=t;co,hh=cv2.findContours(m.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);ps=[]
    for j,c in enumerate(co):
        if cv2.contourArea(c)/zoom**2<.008:continue
        xy=(cv2.approxPolyDP(c,epsilon*zoom,True)[:,0,:].astype(float)+.5)/zoom-1;ps.append(dict(local_native_xy=xy.tolist(),parent=int(hh[0,j,3]),source_iso_mass_threshold=t,source_alpha_local_mass=total))
    return ps
def translated(ps,dx,dy):return [{**p,'local_native_xy':(np.asarray(p['local_native_xy'])+[dx,dy]).tolist()} for p in ps]
special={'US UNIT':['US DOT1','US DOT2'],'IMP UNIT':['IMP DOT1','IMP DOT2'],'LMIN UNIT':['LMIN SLASH']};out=[];evidence=[]
for src in old['words']:
    if src['key'] not in special:out.append(src);continue
    b=src['source_native_box'];x0,y0,x1,y1=b;raw=cv.orig[y0:y1,x0:x1];al=R.alpha_of(raw,bg,ink);body=al.copy();regions=[]
    for key in special[src['key']]:
        reg=by[key]['source_box'];regions.append((key,reg))
    if src['key']=='LMIN UNIT':regions.extend([('i SOURCE DOT',[739,680,741,682]),('i SOURCE STEM',[739,682,742,688])])
    for key,reg in regions:body[reg[1]-y0:reg[3]-y0,reg[0]-x0:reg[2]-x0]=0
    paths=trace(body);micros=[]
    for key,reg in regions:
        dx,dy=reg[0]-x0,reg[1]-y0;rr=cv.orig[reg[1]:reg[3],reg[0]:reg[2]];alpha=R.alpha_of(rr,bg,ink);ps=trace(alpha,.035)
        if key=='LMIN SLASH':
            bbox=by[key]['source_mass_iso_bbox_native'];xmin,ymin,xmax,ymax=bbox;stroke=1.;poly=[[xmax-stroke,ymin],[xmax,ymin],[xmin+stroke,ymax],[xmin,ymax]];reference=np.asarray([xy for p in by[key]['source_mass_iso_paths'] for xy in p['local_native_xy']]);pp=[]
            for i,p in enumerate(poly):
                q=np.array(poly[(i+1)%4]);p=np.array(p);pp.extend((p+np.linspace(0,1,200,endpoint=False)[:,None]*(q-p)).tolist())
            pp=np.asarray(pp);hd=max(float(cKDTree(reference).query(pp)[0].max()),float(cKDTree(pp).query(reference)[0].max()));area=(ymax-ymin)*stroke
            # The very small isolated original iso component is disclosed; the
            # proposed slash has one actual stroke. ROOT must review its shape.
            ps=[dict(local_native_xy=poly,parent=-1,source_derived_straight_slash=True,source_original_full_mass_iso_bbox_kept=True)]
            microprops=dict(proposed_native_polygon=poly,source_iso_bbox_kept=True,proposed_area_native_px=area,source_alpha_local_mass=float(alpha.sum()),area_vs_source_local_alpha_percent=(area/alpha.sum()-1)*100,
                source_iso_component_count=by[key]['source_iso_components'],source_proposed_single_slash_stroke_components=1,max_symmetric_distance_to_source_iso_vertices_native_px=hd,
                tiny_source_component_classification_pending_ROOT=True,ROOT_review_pending=True)
        else:microprops=dict(source_exact_native_box=reg,source_alpha_local_mass=float(alpha.sum()),independent_local_threshold_used=True,letter_or_period_not_taken_from_another_font=True)
        paths+=translated(ps,dx,dy);micros.append(dict(key=key,source_native_box=reg,source_raw_RGB_sha256=hashlib.sha256(rr.tobytes()).hexdigest(),**microprops))
    mask=Image.new('L',((x1-x0+2)*zoom,(y1-y0+2)*zoom),0);d=ImageDraw.Draw(mask)
    for p in paths:d.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p['local_native_xy']],fill=255 if p['parent']<0 else 0)
    cc,hh=cv2.findContours((np.asarray(mask)>0).astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);area=float((np.asarray(mask)>0).sum()/zoom**2);rec={**src,'contour_paths':paths,'local_punctuation_source_regions':micros,
       'unit_literal_unchanged_from_source':True,'source_native_box_and_scale_unchanged':True,'RAM_area_native_px':area,'RAM_vs_original_full_alpha_area_delta_percent':(area/float(al.sum())-1)*100,
       'global_word_threshold_not_used_for_small_dots_or_i':True,'ROOT_graphic_and_literal_acceptance_pending':True}
    out.append(rec);evidence.append(rec);vi=Image.new('RGB',((x1-x0+2)*24,(y1-y0+2)*24),'white');vd=ImageDraw.Draw(vi)
    for p in paths:vd.polygon([((x+1)*24,(y+1)*24) for x,y in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
    tile=Image.new('RGB',(2500,500),'white');tile.paste(Image.fromarray(raw).resize(((x1-x0)*24,(y1-y0)*24),Image.Resampling.NEAREST),(10,10));tile.paste(vi,(1250,0));tile.save(fresh(root/(src['key'].replace(' ','_')+' NGUON VA DAU NHAN DIEN RIENG V2.png')))
    print(src['key'],'FULLAREA%',rec['RAM_vs_original_full_alpha_area_delta_percent'],'MICROS',micros,flush=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==old['source_sha256'] and sha(S.result(name))==old['current_sha256']
Path(fresh(root/'CHU TRUC DAU NHO DOC RIENG V2 RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_original_Perotac_X7_only=True,words=out,three_source_unit_label_evidence=evidence,no_content_guessed_or_system_font=True,no_PDF_font_or_progress_written=True,ROOT_and_graphic_acceptance_pending=True),ensure_ascii=False,indent=2),encoding='utf8');E.close()
