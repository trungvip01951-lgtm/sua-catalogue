from catwork import start
S,D,N=start()
from catfix.recipes import Job
from pathlib import Path
import pickle,collections,json
j=S.job('Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf');T=j.T
T.__dict__.update(pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes())['data'])
for sid in [0,2,6,106,78,52]:
 st=T.styles[sid]
 print('style',sid,'chars',''.join(st['src']),'metrics',bool(st.get('metrics')))
 for c in ['1','2','s','W','K','k','P']:
  if c in st['src']:
   cl=T.clusters[st['src'][c]]
   print(c,[(g.key+1,g.oi,g.bbox) for g in cl['members'][:8]])
j.close()
