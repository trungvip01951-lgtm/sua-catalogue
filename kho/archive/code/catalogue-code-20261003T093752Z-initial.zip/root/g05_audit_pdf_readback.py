"""Nghiệm thu PDF mẫu thật: đường từ toán tử PDF, bảng/ảnh/cấu trúc.
Không ghi/sửa/di chuyển PDF. Không coi mốc source150dpi chưa rõ là đạt.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from catfix.vector import Editor
from catfix import verify,charts
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
import numpy as np,json,csv,hashlib,pymupdf as fitz

name='Perotac bơm giếng SP_compressed (bản mới).pdf';trial=S.report('G05/MAU PDF SUA DUONG/'+name);current=S.dst(name);source=S.src(name)
I='G05/MAU SUA DUONG/PHAM VI DA BO NET CHUA RO 2/';O='G05/MAU PDF SUA DUONG/'
rec=json.loads(Path(S.report(I+'TOA DO VA PHUONG PHAP.json')).read_text(encoding='utf8'));axes=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
saved=json.loads(Path(S.report(O+'GHI VA KIEM NGOAI VUNG.json')).read_text(encoding='utf8'))
model=json.loads(Path(S.report('G05/BO SUNG MA MODEL/NGHIEM THU.json')).read_text(encoding='utf8'))
E=Editor(trial);R=Raster(E);points=[];curves=[];left=[]
def y_at(path,x):
 cur=None
 for op,p in path:
  if op=='m':cur=np.array(p[0]);continue
  if op=='c':
   ctrl=np.vstack([cur,np.array(p)]);end=ctrl[-1]
   if cur[0]-1e-5<=x<=end[0]+1e-5:
    lo=0.;hi=1.
    for _ in range(70):
     t=(lo+hi)/2;v=(1-t)**3*ctrl[0]+3*(1-t)**2*t*ctrl[1]+3*(1-t)*t*t*ctrl[2]+t**3*ctrl[3]
     if v[0]<x:lo=t
     else:hi=t
    t=(lo+hi)/2;v=(1-t)**3*ctrl[0]+3*(1-t)**2*t*ctrl[1]+3*(1-t)*t*t*ctrl[2]+t**3*ctrl[3];return float(v[1])
   cur=end
 raise ValueError(('Không có x trong path',x))
for p in rec['panels']:
 b=next(v for v in axes if v['family']==p['family']);xt=np.array(b['xticks']);yt=np.array(b['yticks']);P=E.page(p['page']-1);wanted=np.array(p['source_color_rgb'])/255
 cand=[]
 for oi,o in enumerate(P.objs):
  col=P.color_of(oi,'stroke')
  if o['op'] not in ['S','s'] or col is None or np.max(abs(np.array(col)-wanted))>1e-8:continue
  path=P.object_pagepath(oi);samples=charts.sample_path(path,n=200);cand.append((oi,o,path,samples))
 cand.sort(key=lambda q:q[3][0,1]);expected=sorted(p['curves'],key=lambda c:c['start_page'][1]);assert len(cand)==len(expected),(p['family'],len(cand),len(expected))
 for (oi,o,path,a),c in zip(cand,expected):
  sd=float(np.max(abs(a[0]-c['start_page'])));ed=float(np.max(abs(a[-1]-c['end_page'])));assert sd<1e-5 and ed<1e-5
  assert abs(o['lw']-p['width_pt'])<1e-10 and np.max(abs(np.asarray(o['ctm'])-np.eye(3)))<1e-7
  assert o.get('dash') is not None and len(o['dash'][0])==0
  table=next(row for row in TABLES[p['family']]['rows'] if row['curve_model']==c['curve_model'])
  dif=[]
  for q in c['new_Q']:
   x=float(np.interp(q,xt[:,0],xt[:,1]));y=y_at(path,x);h=float(np.interp(y,yt[:,1],yt[:,0]));target=table['H'][TABLES[p['family']]['Q'].index(q)];dev=h-target;lim=max(1,.02*target);assert abs(dev)<1e-4 and abs(dev)<=lim
   points.append(dict(page=p['page'],model=c['curve_model'],object_index=oi,Q=q,H_table=target,H_actual_PDF=h,deviation_m=dev,tolerance_m=lim,result='ĐẠT',method='Đọc toán tử nét của PDF mẫu, kiểm điểm Bézier theo tọa độ trục thật'));dif.append(abs(dev))
  curves.append(dict(page=p['page'],model=c['curve_model'],actual_object=oi,stroke_rgb=list(P.color_of(oi,'stroke')),width_pt=o['lw'],matrix=o['ctm'].tolist(),dash=str(o.get('dash')),new_Q=c['new_Q'],max_deviation_m=max(dif),start_error_pt=sd,end_error_pt=ed,join_slope=float((a[1,1]-a[0,1])/(a[1,0]-a[0,0]))))
 # All text/dashes, axes and title pixels to left of join are exact unchanged.
 join=min(c['start_page'][0] for c in p['curves']);rr=(p['rect'][0],p['rect'][1],join-.5,p['rect'][3])
 x0=np.asarray(verify.crop(current,p['page']-1,rr,300));x1=np.asarray(verify.crop(trial,p['page']-1,rr,300));eq=np.array_equal(x0,x1);assert eq,(p['family'],'left changed')
 left.append(dict(page=p['page'],family=p['family'],rect=rr,left_text_dashes_pixels_identical=eq,dpi=300))
tables=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/BANG DAY DU.json')).read_text(encoding='utf8'));tabproof=[]
for t in tables:
 a=np.asarray(verify.crop(current,t['page']-1,t['rect'],450));b=np.asarray(verify.crop(trial,t['page']-1,t['rect'],450));diff=np.any(a!=b,axis=2)
 # The one deliberate model digit update is allowed; every Q/H/dimension number stays exact.
 if t['family']=='6SP36':
  r=t['rect'];s=72/450;mr=model['rect'];u0=max(0,int(np.floor((mr[0]-.5-r[0])/s)));u1=min(a.shape[1],int(np.ceil((mr[2]+.5-r[0])/s)));v0=max(0,int(np.floor((r[3]-mr[3]-.5)/s)));v1=min(a.shape[0],int(np.ceil((r[3]-mr[1]+.5)/s)));diff[v0:v1,u0:u1]=False
 assert not diff.any(),(t['family'],'table altered outside sole model digit')
 tabproof.append(dict(family=t['family'],page=t['page'],QH_numeric_cells=len(TABLES[t['family']]['rows'])*len(TABLES[t['family']]['Q']),all_QH_original_pixels_identical=True,model_row20_updated=t['family']=='6SP36'))
def resources(path):
 d=fitz.open(path);images=[];fonts=[]
 for p in d:
  images.append(sorted(hashlib.sha256(d.xref_stream_raw(im[0])).hexdigest() for im in p.get_images(full=True)))
  fonts.append(sorted((f[3],hashlib.sha256(d.extract_font(f[0])[3]).hexdigest()) for f in p.get_fonts(full=True)))
 x=d.xref_xml_metadata();raw=d.xref_stream(x) if x else None
 v=dict(pages=len(d),rect=[list(p.rect) for p in d],images=images,fonts=fonts,info=d.metadata,raw_xmp=raw,toc=d.get_toc(simple=False),links=[p.get_links() for p in d]);d.close();return v
a=resources(source);b=resources(trial)
pres={}
for k in ['pages','rect','fonts','info','raw_xmp','toc','links']:
 pres[k]=a[k]==b[k];assert pres[k],k
pres['original_images_preserved']=all(set(x)<=set(y) for x,y in zip(a['images'],b['images']));assert pres['original_images_preserved']
allowed={};
for e in saved['edits']:allowed.setdefault(e['page']+1,[]).append(e['rect'])
allowed.setdefault(6,[]).append(model['rect'])
outside=verify.outside_pixels(current,trial,allowed,dpi=200,thr=0,min_size=0,pad=.4);assert not outside,outside
keepers=[]
for p in [0,3,8,10]:
 rr=(20,480,220,535);eq=np.array_equal(np.asarray(verify.crop(source,p,rr,200)),np.asarray(verify.crop(trial,p,rr,200)));assert eq;keepers.append(dict(task=50,page=p+1,rect=rr,all_pixels_identical=eq))
rr=(728.5,365,823,492);eq=np.array_equal(np.asarray(verify.crop(source,7,rr,200)),np.asarray(verify.crop(trial,7,rr,200)));assert eq;keepers.append(dict(task=134,page=8,rect=rr,all_pixels_identical=eq))
modelocr=verify.ocr_check(trial,5,(95,43,121.5,49),'6SP36-28');assert modelocr['ok']
cv0=R.render_canvas(5,(94,79.4,121.8,86.9),dpi=600);s8=R.glyph_bank(cv0,words=[dict(text='6SP36-18',box=cv0.box((95.4,80.7,120.8,85.9)))])['samples'][0]['comps'][-1]
cv1=R.render_canvas(5,(93.6,42.3,122.4,49.3),dpi=600);n8=R.components(cv1,cv1.box((95.5,43.6,120.8,48.4)),expect=8)[-1]
aa=np.array(Image.fromarray((s8['alpha']*255).astype(np.uint8)).resize((32,48)));bb=np.array(Image.fromarray((n8['alpha']*255).astype(np.uint8)).resize((32,48)));corr=float(np.corrcoef(aa.ravel(),bb.ravel())[0,1]);assert corr>.95,corr
out=dict(trial=trial,trial_sha256=hashlib.sha256(Path(trial).read_bytes()).hexdigest(),current_primary_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),curve_count=len(curves),new_point_count=len(points),max_deviation_m=max(abs(v['deviation_m']) for v in points),points=points,curve_actual_styles=curves,left_text_and_dashes=left,all_table_QH_numeric_cell_count=sum(v['QH_numeric_cells'] for v in tabproof),table_pixel_guard=tabproof,model_row20_ocr=modelocr,glyph8_source_same_font_shape_correlation=corr,glyph8_height_source_pt=model['source_glyph8_rect'][3]-model['source_glyph8_rect'][1],glyph8_height_output_pt=model['rect'][3]-model['rect'][1],preservation=pres,outside200=outside,kept_tasks_50_134=keepers,not_full_group_accepted=True,limitations='Đạt52mốc mới của26đuôi đường; còn mốc gốc150dpi chưa rõ/lệch. Nét nguồn6SP30-9 giữ nguyên vì không xác định bảng-8. Chưa thay bản giao cho đến root nghiệm thu.')
Path(fresh(S.report(O+'DOC LAI DUONG THAT VA BAO TOAN.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda v:float(v)),encoding='utf8')
with open(fresh(S.report(O+'52 MOC DUONG THAT.csv')),'w',newline='',encoding='utf-8-sig') as fp:
 w=csv.DictWriter(fp,list(points[0]));w.writeheader();w.writerows(points)
E.close();print('PDF mẫu26đường/52mốc exact, lệchmax',out['max_deviation_m'],'model28 và glyph8corr',corr,'toàn2218ô QH pixels giữ; nguồn/ảnh/phông/XMP/ngoaivung đạt',flush=True)
