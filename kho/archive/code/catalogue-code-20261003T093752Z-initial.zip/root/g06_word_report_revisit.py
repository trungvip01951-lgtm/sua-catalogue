from catwork import start,fresh,row
S,D,N=start()
from catfix import verify
from catfix.vector import Editor
from pathlib import Path
import json,hashlib,datetime,numpy as np
root=Path(S.report('G06'));name='Aquaris FS_300dpi_75% (bản mới).pdf';src,dst=S.src(name),S.dst(name)
old=json.loads((root/'final-state-v2.json').read_text(encoding='utf-8'))
st=json.loads((root/'review'/'native-word-build-2.json').read_text(encoding='utf-8'))
acc=json.loads((root/'review'/'native-word-acceptance-stage-2.json').read_text(encoding='utf-8'))
word=json.loads((root/'review'/'native-word-verification-stage-2.json').read_text(encoding='utf-8'))
edge=json.loads((root/'review'/'native-word-edge-original-ink.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==old['source_sha256']==st['source_sha256']
assert sha(dst)==old['final_sha256']==st['prior_sha256']
structure=verify.structure_check(src,dst);assert structure['ok']
EA,EB=Editor(src),Editor(dst)
kept_content=[EA.doc.page_content(p)==EB.doc.page_content(p) for p in (1,2,3)];EA.close();EB.close();assert all(kept_content)
rows=[row(51,name,1,'Giữ bản đã nghiệm thu','FS 15 15 1.5','FS-35-7-2.2','ĐẠT','G06/acceptance-v2.json; mã nội dung file ra hiện tại khớp bản đã đạt'),
      row(52,name,'2–3','Giữ nguyên do chưa tìm thấy k chữ thường đúng nét đậm','(KW)','Còn (KW)','CHƯA ĐẠT','G06/review/word-copy-source-geometry.json; không có phông nhúng; trang 2–3 giữ nguyên'),
      row(53,name,4,'Thử hai cách mới, mỗi cách hai mẫu; giữ bản gốc vì mẫu cuối còn mực C sát lưới','Dòng 5/13 nhỏ; 15/18 lớn; 28 sát viền','Giữ nguyên bảng trong file ra','CHƯA ĐẠT','G06/review/native-word-edge-original-ink.json; native-word-edge-row5-1200dpi.png')]
out=dict(created=datetime.datetime.now().isoformat(),group='G06',status='CHƯA XONG',can_sua=3,passed=1,not_passed=2,rows=rows,
    source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),destination_unchanged_from_final_v2=True,
    final_structure=structure,source_page_2_3_4_content_streams_equal=kept_content,
    preserved_task_136='Giữ cả hai catalogue FS; không ghi file G07',
    methods=[dict(method='Ngân hàng ký tự',trials=2,result='Không đạt, đã dừng trước lượt bổ sung'),
             dict(method='Nguyên từ nhưng mặt nạ theo vùng dựng ảnh',trials=2,result='Đổi mép mờ của lưới; không dùng'),
             dict(method='Nguyên từ theo tọa độ ảnh gốc, mặt nạ từng từ',trials=2,result='Giữ lưới, còn mực C ở cột 1297; không dùng')],
    trial_only_results=dict(source_images_in_trial_preserved=all(r['ok'] for r in acc['prior_image_streams_preserved']),
        grid_400_500_600_exact=all(r['pixels_exactly_equal'] for r in acc['grid_checks']),
        numbers_400_500_600_exact=all(r['pixels_exactly_equal'] for r in acc['number_column_checks']),
        outside_new_200dpi=acc['outside_pixels_200dpi'],source_words_count=len(word['saved_word_provenance']),
        all_29_saved_word_ink_samples_exact=all(r['source_hashes_match'] and r['saved_ink_samples_exact'] for r in word['saved_word_provenance']),
        old_C_not_cleared=True,accepted=False))
json.dump(out,open(fresh(S.report('BAO CAO BO SUNG G06.json')),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
md=['# BÁO CÁO BỔ SUNG G06 – nghiệm thu lại bảng trang 4','',
    '**Kết quả hiện tại: 1/3 ĐẠT; #52 và #53 CHƯA ĐẠT. File ra vẫn là bản đã nghiệm thu #51 trước đó.**','',
    '| Việc | Trang | Nội dung | Kết quả | Bằng chứng |','|---|---|---|---|---|',
    '| #51 | 1 | Ví dụ model FS-35-7-2.2 đã đạt; giữ nguyên | ĐẠT | G06/acceptance-v2.json; mã file hiện tại khớp |',
    '| #52 | 2–3 | (KW) chưa đổi được thành (kW) đúng nét đậm | CHƯA ĐẠT | Không có phông nhúng; chưa có k cùng kiểu |',
    '| #53 | 4 | Chỉnh năm dòng bằng nguyên từ nguồn; mẫu cuối còn mực C sát lưới nên không dùng | CHƯA ĐẠT | Ảnh mép ô 1200 điểm ảnh/inch và dữ liệu nguồn mực |','',
    '**#136 giữ nguyên:** hai catalogue FS là hai dòng bơm khác nhau; không ghi file G07.','',
    '## Các phương pháp và giới hạn','',
    'Cách ghép từng ký tự đã thất bại hai mẫu trước lượt bổ sung và đã dừng. Lượt này thử hai phương pháp khác, mỗi phương pháp tối đa hai mẫu:','',
    '1. Chép nguyên từ nhưng xoá theo vùng ảnh dựng: bố cục gọn, nền sạch nhưng mặt nạ chạm mép mờ của đường ngang. Hai mẫu word-copy-mau-1/2.pdf không dùng.',
    '2. Chép nguyên từ theo tọa độ ảnh gốc, chỉ xoá mực/quầng của từng từ: mẫu đầu bảo vệ lưới quá rộng nên giữ mẩu C/d; mẫu hai thu vùng bảo vệ theo nét ngang/dọc thật. Lưới, số thứ tự và 29 từ mới đạt phép kiểm, nhưng cạnh C cũ ở dòng 5 vẫn còn. Hai mẫu native-word-mau-1/2.pdf không dùng.','',
    'Không tạo mẫu thứ ba bằng cùng cách và không ghi các mẫu thử vào bản đích.','',
    '## Đối chứng mực C còn sót','',
    'Các điểm chưa sạch dòng 5 ở ảnh 600 điểm ảnh/inch nằm x=311,34 điểm, y≈623,82–624,42 điểm. Chúng ánh xạ vào cột 1297, hàng 906–908 của ảnh gốc; nằm trong miếng từ Cruss dùng làm nguồn chép, ngoài mặt nạ lưới gốc. Mực có độ che 0,184–0,431; mức xám nguồn 208–145. Vùng bảo vệ vách đã giữ nguyên các điểm đó. Ảnh phóng 1200 cho thấy đoạn xám ngắn đúng cao độ C cũ. Chưa đủ căn cứ gọi toàn bộ đoạn này là mép lưới, nên không nghiệm thu đạt.','',
    'Các điểm dòng 13 và điểm góc dòng 18 chủ yếu nằm sát mép lưới; kết quả thô được giữ để người kiểm đối chiếu. Không bỏ điểm nghi ngờ chỉ theo màu hoặc chỉ vì nằm gần lưới.','',
    '## Phần đo được của bản thử cuối','',
    '- Lưới cả hai bảng, kể cả mép khử răng cưa, và số thứ tự giống bản trước từng điểm ảnh ở 400/500/600 điểm ảnh/inch.',
    '- Đọc lại 29 từ từ luồng ảnh và mặt nạ trong PDF đã lưu: mọi giá trị mực khớp nét nguồn sau phép co/phóng đồng tỷ lệ. Có tọa độ và mã kiểm tra từng miếng nguồn. Không ghép từng ký tự, không dùng phông ngoài.',
    '- Mẫu chữ M ở dòng Motor có chiều cao 23 điểm ảnh ở độ phân giải ảnh gốc. Các hệ số dòng 5/13/15/18/28 lần lượt: 1,27778; 1,15; 0,95833; 1; 1,04545. Dòng 18 giữ chiều cao vốn đã 23 điểm ảnh, chỉ ngắt dòng/căn lại trong mẫu.',
    '- Dòng 5/13 ngắt sau head; dòng 15/18 ngắt sau head; dòng 28 một dòng và căn trong ô. Giữ nguyên mọi cách viết của nguồn, kể cả Cruss và assemblie.',
    '- Sai khác ngoài năm ô ở 200 điểm ảnh/inch bằng rỗng, ngưỡng màu 0, không bỏ điểm ảnh nhỏ. Ảnh gốc không nén lại; chỉ thêm năm miếng nhỏ với mặt nạ trong suốt. Những điều đạt riêng này không làm #53 trở thành ĐẠT khi còn mực chữ cũ.','',
    '## Bản đích hiện tại','',
    f'- Nguồn: {src}',f'- File ra: {dst}',f'- Mã SHA256 nguồn: {sha(src)}',f'- Mã SHA256 file ra: {sha(dst)}',
    '- Mã file ra khớp bản final-state-v2.json đã đạt #51. Trang 2–4 giữ nguyên luồng nội dung nguồn; cấu trúc PDF đạt. Không cập nhật PDF, không xóa/đổi tên/ghi đè file nguồn.','',
    '## Hồ sơ kiểm chéo','',
    '- G06/review/word-copy-build-1/2.json và word-copy-grid-diagnostic.json: cách dùng vùng dựng ảnh và lỗi mép lưới.',
    '- G06/review/native-word-build-1/2.json: cách ảnh gốc, tọa độ 29 từ và mặt nạ.',
    '- G06/review/native-word-acceptance-stage-2.json: kiểm thô lưới, số thứ tự, ảnh, thông tin, liên kết, đọc chữ và nền; kết quả tổng chưa đạt.',
    '- G06/review/native-word-verification-stage-2.json: đọc lại mực từng từ từ PDF; kết quả tổng chưa đạt, không dùng phép loại mép để chốt.',
    '- G06/review/native-word-edge-point-coordinates.json và native-word-edge-original-ink.json: tọa độ điểm nghi ngờ, đối chiếu đúng ảnh và mực nguồn.',
    '- G06/review/native-word-edge-row5/row13/row28-1200dpi.png: trước/sau tại mép ô; các ảnh marked đánh dấu điểm nghi ngờ.',
    '- G06/review/native-word-mau-2-400dpi/500dpi/600dpi.png, native-word-toan-bang-2.png, native-word-nguyen-tu-chung-cu-2.png: ảnh mẫu và đối chứng nguyên từ.',
    '- So sanh bo sung G06.png: nguồn và bản đích hiện tại; bảng cuối giữ nguyên.','',
    'SHA256 là mã kiểm tra nội dung file; PDF là định dạng tài liệu; kW là kilôoát, đơn vị công suất; điểm là đơn vị bố cục bằng 1/72 inch; độ che mực 0 là trong suốt, 1 là đen kín. Motor nghĩa là động cơ, head nghĩa là đầu. Các từ nguyên gốc còn lại trong hình được giữ theo yêu cầu #53.','',
    'Tiến độ: G06 CHƯA XONG – 1/3 ĐẠT. Phần thử bổ sung #53 đã dừng theo quy tắc hai mẫu; cần phương pháp khác có thể xóa mực sát lưới mà chứng minh giữ lưới trước khi coi hoàn thành.','',
    'Lập: '+datetime.datetime.now().isoformat()]
Path(fresh(S.report('BAO CAO BO SUNG G06.md'))).write_text('\n'.join(md),encoding='utf-8')
verify.compare_sheet(src,dst,[(0,(50,657,286,681),'#51 đã đạt; bản hiện tại'),(1,(164,227,193,242),'#52 giữ KW; chưa có k đúng kiểu'),(2,(172,255,205,272),'#52 giữ KW; chưa có k đúng kiểu'),(3,(286,382,559,697),'#53 bản hiện tại giữ nguyên; mẫu thử chưa đạt')],fresh(S.report('So sanh bo sung G06.png')),dpi=300)
S.progress('G06','CHƯA XONG','1/3 ĐẠT; bổ sung #53 đã thử hai cách mới, mỗi cách hai mẫu; mẫu cuối còn mực C ở cột ảnh gốc 1297 nên không dùng; giữ PDF final-state-v2; #52 thiếu k đúng kiểu; BAO CAO BO SUNG G06.md/json')
print('G06 hiện tại 1/3 ĐẠT; bản đích không thay đổi; đã lưu báo cáo bổ sung và tiến độ.',flush=True)
print(sha(dst),flush=True)
