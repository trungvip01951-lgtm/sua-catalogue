"""Own small-glyph source contours, merged-three-fix RAM only. Never save M2 PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib,sys,numpy as np
sys.path.insert(0,str(HERE))
from g04_source_glyph_vector_math import source_vector_layers
import pymupdf as fitz
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.cs import Instr,Num,Name
from catfix import verify

root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
planroot=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
folder=root/'CHU NHO VECTOR RAM V1B';assert not folder.exists()
b=json.loads((root/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'))
a=json.loads((root/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json').read_text(encoding='utf8'))
bank=json.loads((planroot/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
atlas=json.loads((planroot/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json').read_text(encoding='utf8'))
layout=json.loads((planroot/'13 HOP NHAN CUC BO TRANH DUONG LUOI V1.json').read_text(encoding='utf8'))
holeplan=json.loads((root/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json').read_text(encoding='utf8'))
etaplan=json.loads((root/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b['source']),sha(b['input_current']),sha(b['sample'])];assert guards==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
vectors=[]
for rec in bank['records']:
    v=source_vector_layers(rec['source_alpha'],sigma=.5,up=4,steps=32,epsilon=.15,radius=1.)
    v.update(character=rec['character'],source_page=rec['source_page'],source_word=rec['source_word'],source_page_box=rec['source_page_box'],
        source_alpha=rec['source_alpha'],source_ink_area_pt2=float(np.array(rec['source_alpha']).sum()*.12**2),
        vector_coordinate_pixel_pt=.12,physical_scale=1.,font_source_uncertainty_pt=.24,new_font=False,
        strategy='32 mức alpha từ mực nhỏ nguồn, đườngbiên fillvector bo góc; khôngngưỡngđen đơn làm mấtchân5/lỗ8.')
    vectors.append(v)
    print('Source contours',rec['character'],'layers',len(v['layers']),'mass',v['mass_normalization'],flush=True)
vf=fresh(folder/'12 KY TU NHO NGUON VA BIEN VECTOR RAM.json');Path(vf).write_text(json.dumps(dict(source_SHA256=guards[0],current_SHA256=guards[1],records=vectors,PDF_written=False),ensure_ascii=False,indent=2),encoding='utf8')
V={z['character']:z for z in vectors};AA={z['model']:z for z in atlas['records']};LB={z['model']:z for z in layout['records']}
E=Editor(b['sample'],backend='fitz');P=E.page(7);tag=next(i for i,z in enumerate(P.ops) if z.op=='BMC' and list(map(str,z.operands))==['CfxRedpumpWholePage8M1'])
def I(op,*v):return Instr([Num(float(x)) for x in v],op)
def rect(x):return I('re',x[0],x[1],x[2]-x[0],x[3]-x[1])
removed=[]
for r in b['labels']:
    matches=[z['i'] for z in P.images if z['i']>tag and z['name']==r['image_name']];assert len(matches)==1
    E.delete_instrs(7,matches);removed.append(dict(model=r['model'],name=r['image_name'],Do_index=matches[0]))
# Two already-approved non-font RAM changes are only prepared in the same buffer.
for r in holeplan['records']:
    x=r['proposed_effective_hole_after'];vals=[x[0],x[1],x[2]-x[0],x[3]-x[1]]
    for i in r['changed_rect_instruction_indices']:E.modify_instr(7,i,Instr([Num(float(z)) for z in vals],'re'))
eta=next(z for z in etaplan['RAM_rendered_candidates'] if z['pieces']==2)
o=P.objs[a['eta_actual']['actual_object']]
E.delete_instrs(7,range(o['i0'],o['i1']))
E.insert_instrs(7,o['i1'],[Instr([Num(float(v)) for xy in pts for v in xy],op) for op,pts in eta['actual_RAM_path']],before=True)

ins=[Instr([Name('CfxRedpumpSmallSourceGlyphVectorRAM1')],'BMC'),Instr([],'q')];placements=[]
for label in b['labels']:
    name=label['model'];lb=LB[name];word=AA[name];origin=lb['source_word_array_page_origin'];bb=lb['physical_box']
    ins += [Instr([],'q'),rect(bb),Instr([],'W'),Instr([],'n')]
    chars=[]
    for glyph in word['glyphs']:
        ch=glyph['character'];v=V[ch];dx,dy=glyph['assembled_offset600'];ox=origin[0]+dx*.12;oy=origin[1]-dy*.12
        for layer in v['layers']:
            ins += [I('g',layer['gray_fill'])]
            for loop in layer['loops']:
                for op,points in loop['path']:
                    values=[z for x,y in points for z in [ox+x*.12,oy-y*.12]]
                    ins.append(Instr([Num(float(z)) for z in values],op))
            ins += [Instr([],'f*')]
        chars.append(dict(character=ch,source_page=glyph['source_page'],source_word=glyph['source_word'],source_page_box=glyph['source_page_box'],
            word_offset600=[dx,dy],vector_glyph_page_origin=[ox,oy],physical_scale=1.,area_source_pt2=v['source_ink_area_pt2']))
    ins += [Instr([],'Q')]
    placements.append(dict(model=name,physical_box=bb,source_array_origin=origin,chars=chars,
        nominal_box_clearance_from_all_QH_grid_pt=lb['min_clearance_pt'],clip_to_original_word_box=True))
ins += [Instr([],'Q'),Instr([],'EMC')]
E.insert_instrs(7,len(P.ops),ins,before=True)
E.doc.set_page_content(7,E.build(7));E.pages.clear();PR=E.page(7)
# Preserve all13 already-accepted QH curves by actual path/style fingerprints,
# without calculating their104anchors again.
qh=[]
for m in a['actual_QH_paths']:
    for part in m['parts']:
        oi=part['object_index'];path=PR.object_pagepath(oi)
        # JSON readback stores tuples as lists; compare normalized numeric paths.
        assert json.dumps(path,separators=(',',':'))==json.dumps(part['path'],separators=(',',':'))
        qh.append(dict(model=m['model'],actual_object=oi,path_unchanged=True,not_remeasured_104anchors=True))
assert len(qh)==26
assert not E.doc.doc[7].get_fonts(full=True)
def ramrender(rect,dpi):
    pg=E.doc.doc[7];T=pg.transformation_matrix;p0=fitz.Point(rect[0],rect[1])*T;p1=fitz.Point(rect[2],rect[3])*T
    clip=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y));pix=pg.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=clip,colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[:,:,:3].copy()
images=[];metrics=[]
for dpi in [150,600,2400]:
    scale=dpi/72
    if dpi in [150,600]:
        rectall=[53,267,364,511];pic=ramrender(rectall,dpi);f=fresh(folder/f'TOAN3LOI GOP RAM {dpi}dpi KHONG PDF2.png');Image.fromarray(pic).save(f);images.append(f)
    rowheight=170 if dpi==600 else 90
    sheet=Image.new('RGB',(1900,13*rowheight+50),'white');draw=ImageDraw.Draw(sheet);font=verify._font(16)
    for k,r in enumerate(placements):
        box=r['physical_box'];rectm=[box[0]-.24,box[1]-.24,box[2]+.24,box[3]+.24]
        old=np.asarray(verify.crop(b['sample'],7,rectm,dpi));after=ramrender(rectm,dpi);assert old.shape==after.shape
        source_alpha=(255-old.astype(float).mean(2))/255;new_alpha=(255-after.astype(float).mean(2))/255
        metrics.append(dict(model=r['model'],dpi=dpi,rect=rectm,pixel_size_pt=72/dpi,
            area_source_pt2=float(source_alpha.sum()*(72/dpi)**2),area_RAM_pt2=float(new_alpha.sum()*(72/dpi)**2),
            relative_ink_mass_error=float(new_alpha.sum()/source_alpha.sum()-1),
            source_alpha_actual_render=source_alpha.tolist() if dpi==600 else None,
            RAM_alpha_actual_render=new_alpha.tolist() if dpi==600 else None))
        if dpi in [150,600]:
            mul=3 if dpi==600 else 1;p0=Image.fromarray(old);p1=Image.fromarray(after)
            sheet.paste(p0,(210,k*rowheight+40));sheet.paste(p1,(480,k*rowheight+40))
            if dpi==600:
                sheet.paste(p0.resize((p0.width*mul,p0.height*mul),Image.Resampling.NEAREST),(750,k*rowheight+40))
                sheet.paste(p1.resize((p1.width*mul,p1.height*mul),Image.Resampling.NEAREST),(1330,k*rowheight+40))
            draw.text((5,k*rowheight+42),r['model'],fill='blue',font=font)
    if dpi in [150,600]:
        draw.text((5,3),'CHỈ RAM: trướcPDFM1 / sauglyphnguồn vector32mức; KHÔNG PDFM2',fill='blue',font=font)
        f=fresh(folder/f'13 NHAN TRUOC SAU RAM {dpi}dpi KHONG PDF2.png');sheet.save(f);images.append(f)
out=dict(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],M1=b['sample'],M1_SHA256=guards[2],
    vector_glyph_data=vf,bank_source=str(planroot/'GLYPH THAT DAY DU CUNG BO NGUON V3.json'),atlas_source=str(planroot/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json'),
    removed_only_M1_glyph_Do=removed,placements=placements,actual_RAM_word_metrics=metrics,images=images,
    QH_source_paths_26_unchanged=qh,merged_eta_plan='HaiBezierC2đãROOTchấpnhận;UNKNOWNsốη.',merged_feet_plan='5lỗgiữnới0,48ptgiao đúngmiền,đãthửRAM15crop0pixel.',
    source_font_physical_scale=1.,external_font=False,large_title_glyph_used=False,Perotac_asset_used=False,
    optical_mass_preserved_in_math=True,source_gray_levels=32,source_smoothing_sigma_pt=.06,corner_rounding_max_radius_pt=.12,
    original_M1_file_unchanged=True,PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False,
    status='ỨNG VIÊN CHỮ VECTOR NHỎ CHỈ RAM: cầnđọc13mã/diện tích/cỡ/biên/khoảnghở,CHƯA CHỐT.')
Path(fresh(folder/'13 NHAN VECTOR32MUC RAM VA KE HOACH GOP3LOI.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert guards==[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
print('RAM source smallglyphs13 only,sourceAlpha32levels,no externalfont;areaErrors',[(r['model'],round(r['relative_ink_mass_error'],4)) for r in metrics if r['dpi']==2400],'NO PDF2',flush=True)
