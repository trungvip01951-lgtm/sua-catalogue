from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,math,collections
from scipy.signal import find_peaks
import fitz

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=S.src('Perotac bơm giếng SA_compressed (bản mới).pdf');dst=S.result('Perotac bơm giếng SA_compressed (bản mới).pdf')
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));d=json.loads((O/'g01_DO MOC TU TIET DIEN MUC THUC VA VACH ETA - V2 CHO DOC NHAN.json').read_text(encoding='utf8'));ds=fitz.open(src);dd=fitz.open(dst);out=[]

def hm(v,yt):
 yt=sorted(yt,key=lambda p:p[1]);x=np.array([z[1] for z in yt]);y=np.array([z[0] for z in yt]);j=min(max(int(np.searchsorted(x,v)),1),len(x)-1);return float(y[j-1]+(v-x[j-1])*(y[j]-y[j-1])/(x[j]-x[j-1]))

for g in d['graphs']:
 ps=[p for p in g['points'] if p['status_pending_visual'].startswith('ỨNG VIÊN')]
 if not ps:continue
 pi=g['page']-1;page=ds[pi];i=max(page.get_images(full=True),key=lambda z:z[2]*z[3]);w,h=i[2:4];bbox=page.get_image_rects(i[0])[0];raw=ds.extract_image(i[0])['image'];rgb=np.asarray(Image.open(__import__('io').BytesIO(raw)).convert('RGB'));gray=rgb.astype(float)@np.array([.299,.587,.114]);yt=g['source_H_local_ticks']
 for p in ps:
  u=p['Q_source_native_u'];v=p['source_section_candidates'][0]['source_native_v'];ys=np.arange(int(v)-6,int(v)+7);variants=[]
  for du in [-.5,0.,.5]:
   ux=u+du;ix=int(math.floor(ux));tx=ux-ix;sig=255-((1-tx)*gray[ys,ix]+tx*gray[ys,ix+1]);ids,_=find_peaks(sig,height=28,prominence=18,distance=2);ids=[k for k in ids if abs(ys[k]-v)<3]
   if len(ids)!=1:variants.append({'du_native_px':du,'only_one_run':False,'runs':len(ids)});continue
   k=ids[0]
   for frac in [.25,.5,.75]:
    floor=float(min(sig[max(0,k-4):k+1].min(),sig[k:min(len(ys),k+5)].min()));threshold=floor+frac*(sig[k]-floor);lo=k;hi=k
    while lo>0 and sig[lo-1]>=threshold:lo-=1
    while hi+1<len(ys) and sig[hi+1]>=threshold:hi+=1
    ws=np.maximum(sig[lo:hi+1]-floor,0);vc=float(np.average(ys[lo:hi+1],weights=ws));variants.append({'du_native_px':du,'fraction':frac,'only_one_run':True,'native_v':vc,'H_m':hm(vc,yt),'source_support_rows':[int(ys[lo]),int(ys[hi])]})
  # Fresh saved source/current PDFs, 600 dpi, original-pixel centre convention.
  clip=fitz.Rect(bbox.x0+(u-8)*bbox.width/w,bbox.y0+(v-9)*bbox.height/h,bbox.x0+(u+9)*bbox.width/w,bbox.y0+(v+10)*bbox.height/h);pix=page.get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=clip,colorspace=fitz.csGRAY,alpha=False);pix2=dd[pi].get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=clip,colorspace=fitz.csGRAY,alpha=False);assert pix.samples==pix2.samples,(p['model'],'Actual current/source point differs');arr=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width);physical_x=bbox.x0+(u+.5)*bbox.width/w;xp=physical_x*600/72-pix.x-.5;cols=np.arange(max(0,int(round(xp))-1),min(arr.shape[1],int(round(xp))+2));sig=255-np.mean(arr[:,cols],axis=1);ids,_=find_peaks(sig,height=28,prominence=18,distance=3);native_vs=((np.arange(len(sig))+.5+pix.y)/(600/72)-bbox.y0)*h/bbox.height-.5;ids=[k for k in ids if abs(native_vs[k]-v)<3]
  actualruns=[]
  for k in ids:
   floor=float(min(sig[max(0,k-14):k+1].min(),sig[k:min(len(sig),k+15)].min()));cut=floor+.5*(sig[k]-floor);lo=k;hi=k
   while lo>0 and sig[lo-1]>=cut:lo-=1
   while hi+1<len(sig) and sig[hi+1]>=cut:hi+=1
   ws=np.maximum(sig[lo:hi+1]-floor,0);vc=float(np.average(native_vs[lo:hi+1],weights=ws));actualruns.append({'native_v':vc,'H_m':hm(vc,yt),'source_FWHM_pdf600_pixel_interval':[lo,hi],'source_peak_darkness':float(sig[k])})
  fp=O/f'g01_{p["model"].replace("/","-")}_Q{p["Q_m3_h"]:g}_NGUON PDF THUC600dpi KHONG DANH DAU.png'
  if fp.exists():assert np.array_equal(np.asarray(Image.open(fp)),arr),'Existing evidence changed: '+str(fp)
  else:pix.save(fresh(fp))
  pt={**p,'source_profile_sensitivity':variants,'raw_profile_all_9_variants_single_run':len(variants)==9 and all(z['only_one_run'] for z in variants),'PDF_actual_600dpi_runs':actualruns,'current_equals_source_actual600dpi_pixels':True,'actual600dpi_image':str(fp),'actual600dpi_sha256':sha(fp),'native_pixel_convention':'index của tâm mẫu RGB là số nguyên; vị trí tâm vật lý khi dựng PDF=(index+0.5)*CTM/sourceSize'}
  vs=[z['H_m'] for z in variants if z.get('only_one_run')]+[z['H_m'] for z in actualruns];pt['H_m_minmax_all_raw_and_PDF_variants']=[min(vs),max(vs)];extra=max(abs(z-p['H_curve_measured_m']) for z in vs);pt['source_profile_variation_extra_m']=extra;pt['revised_conservative_bound_m']=p['uncertainty_bound_m']+extra;out.append(pt);print('ACTUAL',p['model'],p['Q_m3_h'],'H',round(p['H_curve_measured_m'],5),'RAW/PDF RANGE',[round(min(vs),5),round(max(vs),5)],'OLDUNC',round(p['uncertainty_bound_m'],5),'PLUS',round(extra,5),'ACTUAL RUNS',len(actualruns),flush=True)
fp=Path(fresh(O/'g01_UNG VIEN11 MOC - DO NHAY RAW VA PDF600 THUC RIENG.json'));fp.write_text(json.dumps({'source':src,'source_sha256':sha(src),'current':dst,'current_sha256':sha(dst),'read_only':True,'PDF_written':False,'source_and_current_11_point_actual600_equal':True,'all_statuses_pending_manual_source_visual':True,'points':out},ensure_ascii=False,indent=2,default=lambda z:z.item() if isinstance(z,np.generic) else z.tolist()),encoding='utf8');ds.close();dd.close();print('FILE',str(fp),'SHA',sha(fp))
