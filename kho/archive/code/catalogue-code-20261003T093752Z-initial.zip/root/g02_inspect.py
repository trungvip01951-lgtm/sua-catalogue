from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.otext import OutlineText,procrustes
from catfix import charts,verify
from pathlib import Path
import pickle,copy,collections,json,numpy as np,hashlib

NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
src=S.result(NAME)
assert hashlib.sha256(Path(src).read_bytes()).hexdigest()=='d1ba36df84342b3949f445dee82abc557240bf099ef98002319614a080108dae'
E=Editor(src);T=OutlineText(E)
state=pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes())['data']
T.clusters=copy.deepcopy(state['clusters']);T._buckets=copy.deepcopy(state['_buckets'])
byop=collections.defaultdict(list)
for cl in T.clusters:
    if cl['label']!='?':byop[(cl['ops'],len(cl['pts']))].append(cl)
    cl['members']=[]
tables=json.loads(Path(S.report('G01/bang-so-da-nghiem-thu-cho-G02.json')).read_text(encoding='utf-8'))
result={}
for ps in tables:
    p=int(ps)-1;P=E.page(p);gs=T.page_glyphs(p)
    for g in gs:
        g.char=T.clusters[g.cl]['label']
        if g.char=='?':
            cand=[]
            for ref in byop.get((g.ops,len(g.pts)),[]):
                s,R,t,res=procrustes(ref['pts'],g.pts,allow_rotation=True)
                if .25<s<3 and res<.03:cand.append((res,ref['label'],s,float(np.degrees(np.arctan2(R[1,0],R[0,0])))))
            if cand:g.char=min(cand)[1]
    rect=(100,70,580,765)
    cur=charts.curve_objects(P,rect,color=(.133,.365,.635))
    if not cur:raise ValueError(('No curves',p+1))
    plot=[min(P.objs[oi]['bbox'][k] for oi in cur) if k<2 else max(P.objs[oi]['bbox'][k] for oi in cur) for k in range(4)]
    # Wider plot area catches grid edges outside the existing curves.
    box=(plot[0]-5,plot[1]-45,plot[2]+25,plot[3]+45)
    grid=charts.gridlines(P,box)
    info={'curve_bbox':plot,'grid':grid,'curves':[], 'labels':[],'near_text':[]}
    for oi in cur:
        pts=charts.sample_path(P.object_pagepath(oi),n=60)
        info['curves'].append({'oi':oi,'bbox':P.objs[oi]['bbox'],'start':pts[0].tolist(),'end':pts[-1].tolist(),'stroke':P.objs[oi]['stroke'],'lw':P.objs[oi]['lw']})
    for oi in P.objects_in(box):
        gl=[g for g in gs if g.oi==oi]
        if not gl:continue
        gl.sort(key=lambda g:g.bbox[0]);txt=''.join(g.char for g in gl)
        color=P.color_of(oi,'fill')
        ob={'oi':oi,'bbox':P.objs[oi]['bbox'],'text':txt,'fill':color,'glyphs':[{'char':g.char,'bbox':g.bbox,'subs':g.g['subs']} for g in gl]}
        if color and max(abs(a-b) for a,b in zip(color,(.133,.365,.635)))<.02:info['labels'].append(ob)
    for txt,ln in T.text_lines(p):
        b=[min(g.bbox[k] for g in ln) if k<2 else max(g.bbox[k] for g in ln) for k in range(4)]
        if box[0]-70<b[0]<box[2]+40 and box[1]-30<b[1]<box[3]+30:info['near_text'].append({'text':txt,'bbox':b,'oi':list(set(g.oi for g in ln))})
    result[ps]=info
    print('Trang',p+1,'curve',len(cur),'rows',len(tables[ps]['rows']),'bbox',plot,'grid',grid,'labels',[(x['oi'],x['text']) for x in info['labels']],flush=True)
    if p+1 in [9,10,18]:
        verify.crop(src,p,(80,60,570,765),dpi=110).save(fresh(S.report('G02/dau-vao-trang-'+str(p+1)+'.png')))
Path(fresh(S.report('G02/ban-do-doi-tuong.json'))).write_text(json.dumps(result,ensure_ascii=False,indent=1),encoding='utf-8')
T.E=None
Path(fresh(S.report('G02/glyph-doc-dau-vao.pkl'))).write_bytes(pickle.dumps(T.__dict__))
E.close()
