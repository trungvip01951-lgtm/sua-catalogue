"""Chuẩn bị các cụm chữ nguồn sạch và đọc profile cột, chưa ghép chữ mới."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from g04_perotac_audit_labels_manual import MANUAL
from pathlib import Path
from PIL import Image
import json,numpy as np,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'))
E=Editor(src,backend='fitz');R=Raster(E);cases=[('4SA16',25),('4SA16',20),('4SA16',18),('4SA16',9),('4SA8',33),('4SA8',37),('4SA12',32),('4SA3',30),('4SA10',30)]
items=[]
for fam,suffix in cases:
    page=next(z['page'] for z in DATA if z['family']==fam);lx,ll=MANUAL[fam];_,top,bottom=next(x for x in ll if x[0]==suffix)
    cv=R.canvas(max(R.images(page-1),key=lambda z:z.W*z.H));bbox=[lx-2,top-2,lx+70,bottom+3];a=cv.orig[bbox[1]:bbox[3],bbox[0]:bbox[2]].astype(float)
    l=a@[.299,.587,.114];chr=a.max(2)-a.min(2);black=(l<100)&(chr<30);profile=np.maximum(180-l,0)*(chr<30)
    raw=Image.fromarray(cv.orig[bbox[1]:bbox[3],bbox[0]:bbox[2]]);label=f'{fam}-{suffix}'
    raw.save(fresh(root/(label+' NGUON150dpi.png')));raw.resize((raw.width*16,raw.height*16),Image.Resampling.NEAREST).save(fresh(root/(label+' NGUON PHONG16LAN.png')))
    cols=[dict(native_x=bbox[0]+i,black_pixels=int(black[:,i].sum()),black_contrast_sum=float(profile[:,i].sum())) for i in range(a.shape[1])]
    item=dict(source_page=page,source_image='X'+str(page-1),literal_model=fam+'/'+str(suffix),source_native_box=bbox,source_core_word_box=[lx,top,lx+70,bottom],
              column_profile=cols,source_only=True,new_glyph_written=False);items.append(item)
    print(item['literal_model'],'PAGE',page,'BOX',bbox,flush=True)
    print('PROFILE',[(v['native_x'],v['black_pixels'],round(v['black_contrast_sum'])) for v in cols if v['black_pixels']>0],flush=True)
Path(fresh(root/'CU M CHU NGUON VA PROFILE COT.json')).write_text(json.dumps(dict(read_only=True,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),cases=items,PDF_written=False,common_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
