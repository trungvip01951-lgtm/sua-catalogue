"""Kiểm giá trị XMP/XML chỉ đọc; dùng sau catwork.start(), đường dẫn do S cấp."""
import xml.etree.ElementTree as ET
import pikepdf

def _xml_values(element):
    text = element.text or ''
    tail = element.tail or ''
    return (element.tag, tuple(sorted(element.attrib.items())),
            text if text.strip() else '', tail if tail.strip() else '',
            tuple(_xml_values(child) for child in element))

def check_xmp(source_path, final_path):
    values = []
    for path in (source_path, final_path):
        with pikepdf.open(path) as pdf:
            stream = pdf.Root.get('/Metadata')
            raw = stream.read_bytes() if stream is not None else None
        values.append((raw, _xml_values(ET.fromstring(raw)) if raw is not None else None))
    return dict(values_equal=values[0][1]==values[1][1],
                stream_bytes_equal=values[0][0]==values[1][0],
                source_has_xmp=values[0][0] is not None,
                final_has_xmp=values[1][0] is not None)
