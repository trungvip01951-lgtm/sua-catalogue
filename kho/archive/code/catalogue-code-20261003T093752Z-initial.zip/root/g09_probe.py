from catwork import start,fresh
from pathlib import Path
import json,sys,contextlib,io
S,D,N=start()
from catfix.inspect_pdf import what_is_at
from catfix.vector import union
fi=int(sys.argv[1]) if len(sys.argv)>1 else 0
d=json.loads(Path(S.report('G09/NGUON.json')).read_text(encoding='utf-8'))[fi]
j=S.job(d['name']);info=[]
regions=[(0,(60,565,550,710),'#71 built-in'),(0,(300,194,500,212),'#71 Civil'),(1,(90,450,229,715),'#76 hình cắt'),(2,(60,45,554,311),'#73 bảng50'),(3,(46,48,543,313),'#73-74 bảng60'),(4,(65,610,546,738),'#72 pressure'),(6,(75,525,265,725),'#75 SH637')]
for pi,rect,label in regions:
    w=what_is_at(j.src,pi,rect,E=j.E)
    j.T.learn([pi],rect=rect,dpi=450,verbose=True)
    lines=[dict(text=j.T.line_text(gl),rect=union(g.bbox for g in gl),glyphs=[dict(char=g.char,oi=g.oi,style=g.style,bbox=g.bbox) for g in gl]) for gl in j.T.lines(pi,rect)]
    print(label,pi+1,w,flush=True)
    for line in lines:print(line['rect'],line['text'],flush=True)
    info.append(dict(page=pi+1,label=label,rect=rect,what=w,lines=lines))
Path(fresh(S.report(f'G09/PROBE {d["short"]}.json'))).write_text(json.dumps(info,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
j.close()
