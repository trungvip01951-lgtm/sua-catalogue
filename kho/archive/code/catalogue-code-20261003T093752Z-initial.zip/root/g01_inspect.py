from catwork import start,fresh
S,D,N=start()
from catfix.recipes import Job
from catfix import verify
from pathlib import Path
import json,time
name='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
job=S.job(name)
print(S,flush=True)
job.T.learn([2,4,14],dpi=400)
for p in [2,4,14]:
    print('TRANG',p+1,flush=True)
    job.T.dump(p)
    verify.page_overview(job.src,job.src,p,fresh(S.report(f'G01/nguon-{p+1}.png')),dpi=90)
job.close()
