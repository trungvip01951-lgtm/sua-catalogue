from catwork import start,fresh
import json
from pathlib import Path
S,D,N=start()
from catfix.otext import robust_fit
j=S.job('KTZ - LH Perotac (bản mới).pdf');j.T.learn([0],dpi=450)
lines=[
(694,704,'The body of motor and pump is made of rigid cast iron for long-lasting durability.'),
(681,690,'Greatly increased maximum submersion depth due to mechanical seal resistant to high pressure.'),
(668,677,'Semi-open impeller made of high chrome alloy match with wear plate(ductile iron) achieves superior'),
(654,664,'durability.'),
(641,651,'Effective motor cooling due to discharge channel cast as part of the motor housing.Space economically'),
(628,638,'by a top outlet.'),
(602,612,'Hermetically sealed motor equipped build-in thermal protection for the power below 15kW.'),
]
seq=[]
for y0,y1,text in lines:
    r=(79,y0,531,y1);gl=[g for ln in j.T.lines(0,r) for g in ln];gl.sort(key=lambda g:g.bbox[0])
    print(len(gl),len(text.replace(' ','')),j.T.line_text(gl),flush=True)
    assert len(gl)==len(text.replace(' ','')),text
    seq.append(dict(chars=text,boxes=[g.bbox for g in gl]))
F=robust_fit(seq)
print('fit',F,flush=True)
Path(fresh(S.report('G09/KHOANG CHU TRANG1 Perotac.json'))).write_text(json.dumps(F,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
j.close()
