"""ROOT đối chiếu bảy đường FS với đúng bảng và chú giải màu nguồn; chỉ đọc."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,csv,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
name='Aquaris FS_300dpi_75% (bản mới).pdf';source=S.src(name);final=S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source)=='a297ed5b1dec97c33b6d2327d25d30bd3f317690548b9d5895c59e1376a63b31'
assert sha(final)=='97db44101b00605e71ce8996e8d4d08d672a8475cdcfa51ae1b1d5aa9597e033'
root=Path(S.report('G06/KIEM DUONG DOC LAP ROOT V2'));E=Editor(source,backend='fitz');R=Raster(E)
specs=[dict(page=1,Q=list(range(0,141,20)),Hmax=25,models=[
('FS-35-7-2.2',[17,12,5],(76,323,98,330)),
('FS-50-7-3.0',[17,15,10,4],(184,323,207,330)),
('FS-50-10-4.0',[20,17,13,7,2],(293,323,315,330)),
('FS-100-7-5.5',[21.5,21,19,16,12,7,1],(405,323,428,330)),
('FS-100-10-7.5',[24,23,22,19,15,10,4],(240,297,260,304))]),
dict(page=2,Q=list(range(0,251,50)),Hmax=30,models=[
('FS-150-15-11',[26,25,21,15,6],(185,323,207,330)),
('FS-150-20-15',[30,29,26,20,11,0],(294,323,316,330))])]
def runs(vs):
    return [z for z in np.split(vs,np.where(np.diff(vs)>1)[0]+1) if len(z)]
pages=[];rows=[]
for spec in specs:
    pi=spec['page'];im=max(R.images(pi),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float)
    clip=(75,389,548,707);u,v,ur,vr=cv.box(clip);ar=a[v:vr,u:ur]
    gray=ar@np.array([.299,.587,.114]);neutral=(ar.max(2)-ar.min(2)<22)&(gray<246)&(gray>80)
    xx=np.where(neutral.mean(0)>.65)[0];yy=np.where(neutral.mean(1)>.65)[0]
    xs=[float(u+z.mean()) for z in runs(xx)];ys=[float(v+z.mean()) for z in runs(yy)]
    assert len(xs)==len(spec['Q']),(pi,'X',xs)
    assert len(ys)==spec['Hmax']//5+1,(pi,'Y',ys)
    xfit=np.polyfit(spec['Q'],xs,1);yfit=np.polyfit(list(range(spec['Hmax'],-1,-5)),ys,1)
    xres=float(max(abs(np.polyval(xfit,spec['Q'])-xs)))
    yres=float(max(abs(np.polyval(yfit,list(range(spec['Hmax'],-1,-5)))-ys)))
    print('Source axes',pi+1,'X',xs,'Y',ys,'fit residual px',xres,yres,flush=True)
    assert xres<3 and yres<3,(pi,xs,ys,xres,yres)
    plot=[float(cv.to_page(xs[0],ys[-1])[0]),float(cv.to_page(xs[0],ys[-1])[1]),float(cv.to_page(xs[-1],ys[0])[0]),float(cv.to_page(xs[-1],ys[0])[1])]
    verify.crop(source,pi,(19,119 if pi==1 else 199,570,284 if pi==1 else 311),450).save(fresh(root/f'TRANG{pi+1} BANG SO NGUON.png'))
    verify.crop(source,pi,(70,296,560,334),450).save(fresh(root/f'TRANG{pi+1} CHU GIAI NGUON.png'))
    forcheck=np.asarray(verify.crop(source,pi,E.mediabox(pi),300));after=np.asarray(verify.crop(final,pi,E.mediabox(pi),300));same=bool(np.array_equal(forcheck,after));assert same
    image=Image.fromarray(cv.orig.copy());draw=ImageDraw.Draw(image)
    uu=np.arange(int(round(xs[0]))-2,int(round(xs[-1]))+3);vv=np.arange(int(round(ys[0]))-2,int(round(ys[-1]))+3)
    region=a[np.ix_(vv,uu)];contrast=255-region
    colourspread=region.max(2)-region.min(2)
    identities=[]
    for model,heads,leg in spec['models']:
        lu,lv,lur,lvr=cv.box(leg);lp=a[lv:lvr,lu:lur].reshape(-1,3);ch=lp.max(1)-lp.min(1)
        lp=lp[(ch>40)&(lp.mean(1)<225)];assert len(lp)>20,(model,leg,len(lp))
        core=np.median(lp[lp.max(1)-lp.min(1)>=np.percentile(lp.max(1)-lp.min(1),70)],axis=0)
        direction=255-core;norm=np.linalg.norm(direction)
        cos=(contrast@direction)/(np.maximum(np.linalg.norm(contrast,axis=2),1)*norm)
        alpha=(contrast@direction)/(norm*norm)
        mask=(cos>.982)&(alpha>.15)&(colourspread>30)
        identities.append(dict(model=model,legend_rect=leg,legend_actual_RGB=core.tolist(),identification='ROOT đọc tên/chú giải thật tại CHU GIAI NGUON.png; chọn đường theo chính màu marker của tên, không dựa H hoặc thứ hạng'))
        for q,h in zip(spec['Q'],heads):
            x=float(xs[spec['Q'].index(q)]);ix=int(round(x));cols=np.where(abs(uu-ix)<=2)[0]
            mm=mask[:,cols];present=np.where(mm.any(1))[0];grps=runs(present)
            good=[z for z in grps if len(z)>=2]
            if len(good)!=1:
                rows.append(dict(page=pi+1,model=model,Q=q,H_table=h,H_actual=None,error=None,tolerance=max(1,.02*h),result='CHƯA THỂ XÁC MINH',reason=f'Số cụm mực cùng màu tại mốc={len(good)}; không chọn theo H bảng'));continue
            z=good[0];weights=(alpha[z][:,cols]*mm[z]).sum(1);y=float(np.average(vv[z],weights=weights));actual=float((y-yfit[1])/yfit[0]);err=actual-h;lim=max(1,.02*h)
            # Interval covers actual source stroke thickness and +/-2 native
            # columns; no interpolation/extrapolation beyond measured ink.
            interval=sorted([float((vv[z[0]]-1-yfit[1])/yfit[0]),float((vv[z[-1]]+1-yfit[1])/yfit[0])])
            upper=max(abs(interval[0]-h),abs(interval[1]-h));lower=0 if interval[0]<=h<=interval[1] else min(abs(interval[0]-h),abs(interval[1]-h))
            result='ĐẠT' if upper<=lim else 'CHƯA ĐẠT' if lower>lim else 'CHƯA THỂ XÁC MINH'
            rows.append(dict(page=pi+1,model=model,Q=q,H_table=h,H_actual=actual,error=err,tolerance=lim,result=result,source_ink_interval_H=interval,max_possible_error=upper,native_x_center=ix,native_y_ink_center=y,method='Tâm mực theo màu chú giải tại đúng cột lưới nguồn; cửa sổ ±2pixel được công khai, không ngoại suy'))
            draw.ellipse((ix-6,y-6,ix+6,y+6),outline=(255,0,0),width=2)
    image.crop((u,v,ur,vr)).save(fresh(root/f'TRANG{pi+1} MOC DO NGUON.png'))
    pages.append(dict(page=pi+1,source_native_size=[im.W,im.H],image_name=str(im.name),source_plot_rect=plot,vertical_rules_native=xs,horizontal_rules_native_top_down=ys,xfit_pixel_diagnostic=xfit.tolist(),yfit_pixel=yfit.tolist(),xfit_residual_px=xres,yfit_residual_px=yres,actual_Q_columns='Dùng từng nét lưới X thật ứng với Q đã soi, không dùng xfit.',identities=identities,whole_page_final_pixels_equal_source300dpi=same))
E.close()
counts={label:sum(r['result']==label for r in rows) for label in ('ĐẠT','CHƯA ĐẠT','CHƯA THỂ XÁC MINH')}
assert len(rows)==37
out=dict(source=source,source_sha=sha(source),final=final,final_sha=sha(final),method='Nguồn300dpi, đọc trực tiếp37ô/H và đúng7 tên/chú giải; lưới nguồn đo độc lập; chỉ đọc mẫu mực thật.',pages=pages,points=rows,counts=counts,known_anchor_count=37,known_curve_count=7,pdf_written=False,limits='Các ô H trống và đoạn kéo tới H0 nằm ngoài cột bảng cuối vẫn chưa có số nguồn để xác minh. Không coi việc giữ nguyên bảy đường là đã đo đủ toàn miền. #52 còn thiếu k đúng kiểu; #53 giữ nguyên theo điều kiện hướng dẫn.')
Path(fresh(root/'NGHIEM THU QH ROOT.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(root/'37 MOC DOC LAP ROOT.csv'),'w',encoding='utf-8-sig',newline='') as fp:
    fields=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(fp,fields);w.writeheader();w.writerows(rows)
print('G06 ROOT QH 37 mốc',counts,'SHA nguồn/bản giao giữ nguyên',flush=True)
