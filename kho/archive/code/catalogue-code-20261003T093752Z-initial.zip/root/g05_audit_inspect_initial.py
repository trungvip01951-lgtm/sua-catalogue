from catwork import start
S,D,N=start()
from pathlib import Path
import json
p='G05/KIEM TOAN TOAN BO/'
a=json.loads(Path(S.report(p+'DO NET DOC LAP V2.json')).read_text(encoding='utf8'))['points']
for fam,model in [('6SP30','6SP30-6'),('6SP30','6SP30-42'),('6SP60','6SP60-20')]:
 print('MODEL',fam,model)
 for r in a:
  if r['family']==fam and r['curve_model']==model: print({k:r.get(k) for k in ['Q_m3h','H_table_m','H_curve_m','deviation_m','uncertainty_m','confidence_status','sample_count','reason']})
for fam in sorted(set(r['family'] for r in a)):
 r=sorted([v for v in a if v['family']==fam and v['confidence_status']=='CHƯA ĐẠT'],key=lambda x:x['deviation_m'],reverse=True)
 print('FAIL',fam,[(v['curve_model'],v['Q_m3h'],v['H_table_m'],v['H_curve_m']) for v in r[:8]])
 print('COUNT',fam,{v:sum(r['family']==fam and r['confidence_status']==v for r in a) for v in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']},'UNKNOWN_Q',sorted(set(r['Q_m3h'] for r in a if r['family']==fam and r['H_curve_m'] is None)))
