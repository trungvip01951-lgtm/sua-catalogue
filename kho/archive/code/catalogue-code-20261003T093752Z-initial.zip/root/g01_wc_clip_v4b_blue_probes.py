"""Read original RGB only; locate retained cyan ink candidates without image creation."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,csv,math
import numpy as np
from PIL import Image
INP=HERE/'wc_clip_source_du_lieu_20261003'/'DU LIEU DUONG CAT NGUON V4B BIEN THAN DUNG'/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(INP)=='d2356789b101589037eb587a6e75af4ce899e0c5297e6f316969217c162cce7a'
data=json.loads(INP.read_text(encoding='utf8'))
OUT=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B'))
def polygons(g):
    out=[]
    for q in g['combined_clip_subpaths']:
        p=np.array([c[1:] for c in q['commands_pixel'] if not isinstance(c,str) and c[0] in ('M','L')],dtype=float)
        if np.array_equal(p[0],p[-1]):p=p[:-1]
        out.append(p)
    return out
def rowintervals(polys,y):
    xs=[];vs=[]
    for p in polys:
        a=p;b=np.roll(p,-1,axis=0)
        keep=((a[:,1]<=y)&(b[:,1]>y))|((a[:,1]>y)&(b[:,1]<=y))
        a=a[keep];b=b[keep]
        if len(a):
            xx=a[:,0]+(y-a[:,1])*(b[:,0]-a[:,0])/(b[:,1]-a[:,1])
            xs.extend(xx.tolist());vs.extend(np.where(b[:,1]>a[:,1],1,-1).tolist())
    if not xs:return []
    ix=np.argsort(xs);xs=np.array(xs)[ix];vs=np.array(vs)[ix]
    acc=0;left=None;intervals=[]
    for x,v in zip(xs,vs):
        old=acc;acc+=v
        if old==0 and acc!=0:left=float(x)
        if old!=0 and acc==0:intervals.append([left,float(x)])
    assert acc==0
    return intervals

res=[];allpoints=[]
for g in data['groups']:
    group=g['group'];jp=Path(g['source_JPEG']);assert sha(jp)==g['source_JPEG_sha256']
    a=np.array(Image.open(jp).convert('RGB'),dtype=int);w,h=g['source_canvas_pixel'];ps=polygons(g)
    # This filter only locates candidates; it does not classify a pixel as material/background.
    candidate=(a[:,:,1]-a[:,:,0]>=15)&(a[:,:,2]-a[:,:,0]>=25)
    yy,xx=np.nonzero(candidate);kept=[]
    for y in np.unique(yy):
        xis=xx[yy==y]
        for lo,hi in rowintervals(ps,float(y)+.5):
            kept.extend([(int(x),int(y)) for x in xis[(xis+.5>=lo)&(xis+.5<hi)]])
    pool=set(kept);comps=[]
    while pool:
        seed=pool.pop();todo=[seed];cc=[seed]
        while todo:
            x,y=todo.pop()
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    if not(dx or dy):continue
                    n=(x+dx,y+dy)
                    if n in pool:pool.remove(n);todo.append(n);cc.append(n)
        comps.append(cc)
    comps.sort(key=len,reverse=True);cr=[]
    for i,c in enumerate(comps):
        xs=[x for x,y in c];ys=[y for x,y in c]
        rgb=[a[y,x].tolist() for x,y in c]
        best=max(c,key=lambda xy:int(a[xy[1],xy[0],2]-a[xy[1],xy[0],0]))
        r={'group':group,'component':i,'pixel_count':len(c),'bbox_source_pixel_halfopen':[min(xs),min(ys),max(xs)+1,max(ys)+1],'strongest_pixel':list(best),'strongest_RGB':a[best[1],best[0]].tolist(),'classification':'CANDIDATE ONLY; requires original source + RAM visual + material boundary proof'}
        cr.append(r)
        for x,y in c:allpoints.append({'group':group,'component':i,'x':x,'y':y,'R':int(a[y,x,0]),'G':int(a[y,x,1]),'B':int(a[y,x,2])})
    res.append({'group':group,'source_JPEG_sha256':sha(jp),'source_RGB_threshold_candidates':len(xx),'retained_threshold_candidates':len(kept),'8_connected_candidate_components':cr})
    print('GROUP',group,'RETAINED',len(kept),'COMPONENTS',len(cr),flush=True)
    print(json.dumps(cr[:24],ensure_ascii=False,indent=1),flush=True)
fp=OUT/'g01_02_TOA DO MUC XANH GIU LAI CHI LA UNG VIEN.json'
Path(fresh(fp)).write_text(json.dumps({'input_sha256':sha(INP),'method':'Pixel original JPEG, threshold G-R>=15 and B-R>=25; exact nonzero polygon intervals at pixel centers; no raster output, no automatic classification','groups':res,'PDF_written':False,'source_RGB_modified':False,'new_raster_written':False},ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(OUT/'g01_02_TOA DO TUNG PIXEL MUC XANH UNG VIEN.csv'),'w',encoding='utf-8-sig',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=['group','component','x','y','R','G','B']);wr.writeheader();wr.writerows(allpoints)
print('SAVED',str(fp),sha(fp),flush=True)
