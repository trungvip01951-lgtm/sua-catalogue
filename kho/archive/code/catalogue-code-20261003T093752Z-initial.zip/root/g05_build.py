from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix import verify,charts
from catfix.recipes import Job
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
trial=fresh(S.report('G05/THU LAN 2/'+name))
j=Job(S.src(name),trial,log_path=fresh(S.report('G05/THU LAN 2/'+name+'.log.json')))
proof=[]

def manual_bank(cv,items):
    return j.R.glyph_bank(cv,words=[dict(text=t,box=cv.box(r)) for t,r in items])

def numeric_bank(p,cv):
    if p==4:
        matrix=[[23,22,21,19,18,15,11,7],[34,33,31,29,27,23,17,11],
                [46,44,42,39,36,31,23,14],[57,56,53,48,44,38,29,18],
                [68,57,63,58,53,46,34,21],[80,78,74,68,62,54,40,25]]
        items=[]
        for ii,nums in enumerate(matrix):
            y=177.91-ii*7.92
            for cc,v in enumerate(nums):
                x=612.73+cc*23.32;items.append((str(v),(x-6,y-3.0,x+6,y+3.0)))
        return manual_bank(cv,items)
    if p==8:
        vals=[181,180,1750,162,147,133,119,100]
        return manual_bank(cv,[(str(v),(594.14+cc*25.45-7.5,90.55,594.14+cc*25.45+7.5,96.65)) for cc,v in enumerate(vals)])
    if p==6:
        vals=[280,279,278,273,259,240,224,206,193,176,159,135,110,80]
        return manual_bank(cv,[(str(v),(211.24+cc*13.30-5.5,33.1,211.24+cc*13.30+5.5,39.3)) for cc,v in enumerate(vals)])
    if p==7:
        return manual_bank(cv,[('1767',(713.2,401.1,727,406.9)),('2000',(713.2,393.4,727,399.0)),
                               ('1649',(713.2,409.0,727,414.8)),('18.6',(730,401.1,742,406.9))])
    return None

banks={}
def replace(p,old,new,r,lr,bank_extra=None):
    cv=j.canvas(p)
    hs=j.R.find(cv,old,box=cv.box(r),scale=3,psm=7)
    if len(hs)!=1:
        hs=j.R.find(cv,old,box=cv.box(r),scale=3,psm=8)
    if len(hs)!=1:
        # Chữ cũ đã soi ảnh: khoanh đúng nét, tách đúng số ký tự, không dùng phông ngoài.
        comps=j.R.components(cv,cv.box(r),expect=len(old.replace(' ','')))
        assert len(comps)==len(old.replace(' ','')),(p,old,len(comps))
        hs=[dict(text=old,box=tuple(cv.box(r)),words=[])]
    if p in [4,6,7,8]:
        if p not in banks:banks[p]=numeric_bank(p,cv)
        b=banks[p]
    else:
        if p not in banks:
            items=([('431',(106,87.5,115.8,93.2)),('304',(106,79.0,115.8,84.7))] if p==0
                   else [('431',(99.5,87.2,108.8,93.0)),('304',(99.5,79.5,109,85.5))])
            banks[p]=manual_bank(cv,items)
        b=banks[p]
    if bank_extra:
        b=j.R._bank_from_samples(b['samples']+bank_extra)
    assert all(c in b['glyphs'] for c in new.replace(' ','')),(p,new,list(b['glyphs']))
    oldbox=cv.rect(hs[0]['box'])
    j.R.replace_word(cv,hs[0],new,b,align='center')
    j._add(p,(r[0]-.5,r[1]-.5,r[2]+.5,r[3]+.5),f'{old} → {new}','raster')
    proof.append(dict(page=p+1,old=old,new=new,rect=r,method='Ghép nét chữ cùng file; căn tâm ô; giữ đường bảng.',glyph_box=oldbox))

replace(4,'57','67',(628,142,644,150),(610,25,785,180))
replace(7,'1767','1827',(713.2,401.1,727,406.9),(635,365,730,480))
replace(8,'1750','175',(636,90,655,97),(586,35,787,162))
replace(6,'110','103',(365,33.7,374.4,39.3),(205,42,385,156))
replace(6,'80','72',(378,33,386,39),(205,42,385,156))

# Dùng mẫu 6 có sẵn trong bảng vật liệu của trang9, cùng họ chữ trong tài liệu.
# Cỡ mẫu được đối chiếu với bảng đích; nguồn ảnh không bị sửa.
cv9=j.canvas(8)
bank9=manual_bank(cv9,[('316',(134.1,88.8,143.6,94.1))])
part=bank9['samples'][0]
six_samples=[dict(text='6',comps=[part['comps'][2]],base=part['base'],size=part['size'])]
assert six_samples
for p,x,ys in [(0,(105.8,116.0),(88.4,79.9)),(3,(99.0,109.0),(88.2,80.4))]:
    for idx,y in enumerate(ys):
        replace(p,'431' if idx==0 else '304','316',(x[0],y-.8,x[1],y+4.5),
                (88 if p==3 else 94,42,150,128),six_samples)

# Trang9/11 có sẵn toàn câu AISI316SS ở đúng hai dòng; chuyển câu đó về đầu ô,
# xóa hai lựa chọn cũ bằng tẩy nét ảnh, không vẽ ô che, giữ nguyên đường kẻ.
for p,left,source_x,rows in [(8,87.0,(124.3,151.4),[(88.3,94.4),(80.6,86.7)]),
                            (10,82.0,(119.4,146.1),[(90.9,97.0),(83.2,89.3)])]:
    cv=j.canvas(p)
    for y0,y1 in rows:
        source=cv.box((source_x[0],y0,source_x[1],y1))
        a=cv.work[source[1]:source[3],source[0]:source[2]].copy()
        target=cv.box((left,y0,source_x[1]+1,y1))
        # Lưu mẫu sang một phần đệm của chính canvas rồi dùng copy_box?
        # copy_box đọc trước khi ghi: chuyển câu trước, sau đó tẩy vùng bên phải riêng.
        dest=cv.to_px(left,y1)
        shift=(round(dest[0])-source[0],round(dest[1])-source[1])
        j.R.copy_box(cv,source,(source[0]+shift[0],source[1]+shift[1]))
        keep_right=source[0]+shift[0]+(source[2]-source[0])
        # Chỉ tẩy nét ký tự thừa; không lấp nguyên hình chữ nhật và không kéo nét bảng vào nền.
        box=(keep_right+1,target[1],target[2],target[3])
        bg,ink=j.R.bg_ink(cv.work,box)
        mask=np.zeros(cv.work.shape[:2],bool)
        mask[box[1]:box[3],box[0]:box[2]]=j.R.alpha_of(cv.work[box[1]:box[3],box[0]:box[2]],bg,ink)>.04
        j.R.erase(cv,mask=mask,dilate=0,color=bg)
        r=(left,y0,source_x[1]+1,y1)
        j._add(p,r,'#135 AISI316SS duy nhất trong ô, chép câu gốc cùng dòng','raster')
        proof.append(dict(page=p+1,old='①AISI431/304SS ②AISI316SS',new='AISI 316 SS',rect=r,method='Chép nguyên câu đúng có sẵn trong cùng dòng; tẩy nét lựa chọn thừa.'))

src_one=manual_bank(j.canvas(10),[('10SP135-2',(212.2,120.8,260.4,128.6))])['samples'][0]
one_sample=dict(text='1',comps=[src_one['comps'][0]],base=src_one['base'],size=src_one['size'])
for p in [0,3,8,10]:
    cv=j.canvas(p)
    rr=(78,171,116,181.8) if p==0 else ((69.4,213.5,107.6,222) if p==3 else ((69.0,211.5,105.3,220) if p==8 else (63.8,214.4,100.1,223.8)))
    parts=j.R.components(cv,cv.box(rr),expect=6)
    assert len(parts)==6
    b=j.R._bank_from_samples([one_sample])
    target=dict(text='2',box=parts[0]['box'])
    j.R.replace_word(cv,target,'1',b,align='left',erase_method='median')
    j.R.erase_components(cv,[parts[-1]],method='median',dilate=1)
    r=rr
    j._add(p,r,'Warranty:2 years → 1 year','raster')
    proof.append(dict(page=p+1,old='2 years',new='1 year',rect=r,method='Ghép nét chữ cùng cỡ, giữ đầu dòng.'))

# Chỉ ghi miếng ảnh đổi bằng nén không mất dữ liệu, giữ byte JPEG/ảnh tiêu đề nguồn.
for cv in list(j._canvases.values()):j.R.commit(cv,mode='patch',encoding='flate')
j._canvases={}
j.save()
ck=j.check(raster=True)
print('G05 thử1',ck['ok'],'unexpected',ck['unexpected'],'missing',ck['missing'],flush=True)
Path(fresh(S.report('G05/THU LAN 2/KIEM TRA.json'))).write_text(json.dumps(dict(check=ck,proof=proof,edits=j.edits),ensure_ascii=False,indent=2,default=lambda x:float(x)),encoding='utf-8')
j.evidence(fresh(S.report('G05/THU LAN 2/SO SANH.png')),dpi=250)
j.close()
