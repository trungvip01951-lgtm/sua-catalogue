"""Restore4 counter from actual source box/area/edge; RAM only, no PDF."""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import cv2
from scipy.spatial import cKDTree
from scipy.optimize import minimize_scalar
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'SO4 LONG CHU DUNG NGUON V4'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
data=read(base/'CHU2 CHU5 GIU NET THANG NGUON V3/TOAN BO12 CHU NGUON NET THANG V3 RAM CHUA NGHIEM THU.json');source=read(base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json');r=next(v for v in source['candidates'] if v['key']=='4_4SA16-25');g=next(v for v in data['glyphs'] if v['character']=='4');zoom=96;al=np.asarray(r['alpha']);h,w=al.shape
up=cv2.resize(np.pad(al,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);m=up>=r['iso_mass_match_threshold'];co,hh=cv2.findContours(m.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);ref=(co[1][:,0,:].astype(float)+.5)/zoom-1;bb=np.r_[ref.min(0),ref.max(0)];area=abs(cv2.contourArea(co[1])/zoom**2);height=bb[3]-bb[1];width=bb[2]-bb[0];topwidth=2*area/height-width
def poly(cx):return np.array([[cx-topwidth/2,bb[1]],[cx+topwidth/2,bb[1]],[bb[2],bb[3]],[bb[0],bb[3]]])
def samples(p):
    return np.vstack([p[i]+np.linspace(0,1,512,endpoint=False)[:,None]*(p[(i+1)%len(p)]-p[i]) for i in range(len(p))])
def loss(cx):
    pp=samples(poly(cx));d1=cKDTree(ref).query(pp)[0];d2=cKDTree(pp).query(ref)[0];return float(np.mean(d1**2)+np.mean(d2**2))
fit=minimize_scalar(loss,bounds=(bb[0]+topwidth/2,bb[2]-topwidth/2),method='bounded',options={'xatol':1e-10});p=poly(fit.x);ss=samples(p);hd=max(float(cKDTree(ref).query(ss)[0].max()),float(cKDTree(ss).query(ref)[0].max()));path=dict(local_native_xy=p.tolist(),parent=0,source_actual_counter_bbox_restored=True,source_actual_counter_area_restored=True,source_counter_straight_sides=True)
glyph=dict(**g);glyph['cleaned_contour_paths']=[g['cleaned_contour_paths'][0],path];glyph.update(old_counterV3_rejected_area102percent_and_edge1_935px=True,source_counter_restore_from_original_own_glyph=True,
   actual_source_counter_box=bb.tolist(),actual_source_counter_area_native_px=area,proposed_counter_area_native_px=float(abs(cv2.contourArea(p.astype(np.float32)))),proposed_counter_max_symmetric_distance_source_native_px=hd,
   source_counter_bbox_unchanged=True,source_outer_contour_and_advance_unchanged=True,source_RGB=[57,55,57],source_opacity=1.,ROOT_and_graphic_acceptance_pending=True)
mask=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);d=ImageDraw.Draw(mask)
for q in glyph['cleaned_contour_paths']:d.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in q['local_native_xy']],fill=255 if q['parent']<0 else 0)
mi=np.asarray(mask)>0;areaall=float(mi.sum()/zoom**2);glyph['current_source_fixed4_area_native_px']=areaall;glyph['current_source_fixed4_area_delta_percent']=(areaall/r['alpha_integral_native_px']-1)*100
print('SOURCE4 COUNTER',bb.tolist(),area,'NEWAREA',glyph['proposed_counter_area_native_px'],'HD',hd,'ALLAREA%',glyph['current_source_fixed4_area_delta_percent'],flush=True)
rawim=Image.open(base/'DO BIEN GIU LUONG MUC NGUON/4_4SA16-25 NGUON150dpi.png');vi=Image.new('RGB',((w+2)*30,(h+2)*30),'white');vd=ImageDraw.Draw(vi)
for q in glyph['cleaned_contour_paths']:vd.polygon([((x+1)*30,(y+1)*30) for x,y in q['local_native_xy']],fill=(57,55,57) if q['parent']<0 else 'white')
tile=Image.new('RGB',(1000,380),'white');tile.paste(rawim.resize((w*30,h*30),Image.Resampling.NEAREST),(10,10));tile.paste(vi,(500,0));tile.save(fresh(root/'4 NGUON VA LONG CHU DUNG NGUON V4.png'))
glyphs=[glyph if v['character']=='4' else v for v in data['glyphs']];bank={v['character']:v for v in glyphs};sheet=Image.new('RGB',(1750,2600),'white');dr=ImageDraw.Draw(sheet)
for i,word in enumerate(data['words']):
    x=15.;y=i*200+140.;scale=14
    for char in word['literal']:
        item=bank[char]
        for q in item['cleaned_contour_paths']:dr.polygon([(x+xx*scale,y+(yy-9)*scale) for xx,yy in q['local_native_xy']],fill=(57,55,57) if q['parent']<0 else 'white')
        x+=item['native_advance']*scale
sheet.save(fresh(root/'13 TEN CHU NGUON LONG4 DUNG V4 RAM CHUA NGHIEM THU.png'));sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest();assert sha(S.src(name))==data['source_sha256'] and sha(S.result(name))==data['current_sha256']
Path(fresh(root/'TOAN BO12 CHU NGUON LONG4 DUNG V4 RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_small_caption_only=True,source_one_color_RGB=[57,55,57],glyphs=glyphs,words=data['words'],V3_number4_counter_rejected=True,no_PDF_font_or_progress_written=True,ROOT_and_graphic_acceptance_pending=True),ensure_ascii=False,indent=2),encoding='utf8')
