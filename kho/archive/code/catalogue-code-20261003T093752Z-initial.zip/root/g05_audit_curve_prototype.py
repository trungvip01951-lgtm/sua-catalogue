"""Mẫu PNG: tách toàn tiết diện nét nguồn theo rank, nền SMask, nét trơn.
Chưa ghi PDF. Chữ/nét đứt bên trái được giữ nguyên từng pixel.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from catfix.vector import Editor
from catfix.raster import Raster,RenderCanvas
from catfix.charts import draw_polyline
from scipy.interpolate import UnivariateSpline,PchipInterpolator,CubicHermiteSpline
from PIL import Image
from pathlib import Path
import numpy as np,json,hashlib

P='G05/KIEM TOAN TOAN BO/'
O='G05/MAU SUA DUONG/PHUONG PHAP 1 - TACH NET VA VECTOR/MAU 1/'
axes=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
audit=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'))
name='Perotac bơm giếng SP_compressed (bản mới).pdf';dest=S.dst(name)
before=hashlib.sha256(Path(dest).read_bytes()).hexdigest()
assert before==audit['output_sha256'],'Phiên G05 đã đổi, phải đọc lại'
E=Editor(dest);R=Raster(E);out=[]

def page_to_render(cv,b):
 r=b['rect'];step=72/b['dpi'];h,w=cv.shape[:2]
 xs=r[0]+(np.arange(w)+.5)*step;ys=r[3]-(np.arange(h)+.5)*step
 return xs,ys

for fam,startq in [('6SP30',16.5),('6SP60',66)]:
 b=next(z for z in axes if z['family']==fam);t=TABLES[fam];n=len(t['rows'])
 im=R.image_at(b['page']-1,(b['x0'],b['y0'],b['x1'],b['y1']));cv=R.canvas(im);a=cv.orig.copy();bg=a.copy()
 xt=np.array(b['xticks']);yt=np.array(b['yticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]));qx=lambda x:float(np.interp(x,xt[:,1],xt[:,0]))
 nativeX=lambda x:float(cv.to_px(x,b['y0'])[0]);nativeY=lambda y:float(cv.to_px(b['x0'],y)[1]);pageY=lambda y:float(cv.to_page(0,y)[1])
 xp0=nativeX(b['x0']);xp1=nativeX(b['x1']);yp0=nativeY(b['y1']);yp1=nativeY(b['y0'])
 xbeg=nativeX(px(startq));xend=nativeX(px(t['Q'][-1]));xlo=int(np.ceil(xbeg));xhi=int(np.ceil(xend+2));ylo=int(np.ceil(yp0+3));yhi=int(np.floor(yp1-3))
 native_px_pt=abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0])
 models=[]
 # Source centers come only from independent grayscale rank samples, no table H.
 for k,row in enumerate(t['rows']):
  ps=[z for z in audit['points'] if z['family']==fam and z['row']==k+1 and z.get('H_curve_m') is not None]
  raw=[]
  for p in ps:
   for q in p['sample_locations']:
    xx=b['rect'][0]+q['x_px']*72/b['dpi'];yy=b['rect'][3]-q['y_px']*72/b['dpi']
    raw.append((nativeX(xx),nativeY(yy)))
  bins={}
  for x,y in raw:bins.setdefault(round(x,4),[]).append(y)
  sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx]);spl=UnivariateSpline(sx,sy,s=len(sx)*.06,k=3)
  resid=float(np.max(abs(spl(sx)-sy)))
  assert resid<1.0,(fam,row['curve_model'],'source rank residual',resid)
  models.append(dict(row=row,spl=spl,rank=k+1,source_samples=int(len(raw)),source_residual_max_native_px=resid))
 # Measured horizontal grid samples only around known actual grid positions.
 body=a[int(np.ceil(yp0+3)):int(np.floor(yp1-3)),int(np.ceil(xp0+5)):int(np.floor(xp1-5))].astype(float)
 vp=np.median(body,axis=0);hp=np.median(body,axis=1)
 base=np.percentile(body.reshape(-1,3),98,axis=0)
 gridYs=np.array([nativeY(v) for h,v in b['yticks']]);gridXs=np.array([nativeX(v) for q,v in b['xticks']])
 grid_half=3.0
 def background(x,y):
  xx=np.clip(x-int(np.ceil(xp0+5)),0,len(vp)-1);yy=np.clip(y-int(np.ceil(yp0+3)),0,len(hp)-1)
  hc=hp[yy] if np.min(abs(gridYs-y))<=grid_half else base
  return np.minimum(hc,vp[xx])
 tube=np.zeros(a.shape[:2],bool)
 for x in range(xlo,xhi+1):
  for m in models:
   yc=float(m['spl'](min(x,xend)));lo=max(ylo,int(np.floor(yc-6)));hi=min(yhi,int(np.ceil(yc+6)))
   tube[lo:hi+1,x]=True
  yy=np.nonzero(tube[:,x])[0]
  if len(yy):bg[yy,x]=np.clip(np.round([background(x,y) for y in yy]),0,255).astype(np.uint8)
 # No label/axis/title pixels in correction rectangles, left native original retained.
 assert not np.any(tube[:ylo]) and not np.any(tube[yhi+1:])
 # Match effective source ink area and color using separated real gray strokes.
 cores=[];areas=[]
 for x in np.linspace(nativeX(px(20 if fam=='6SP30' else 42)),nativeX(px(30 if fam=='6SP30' else 60)),70):
  xi=round(x)
  if np.min(abs(gridXs-x))<3:continue
  centres=np.array([float(m['spl'](x)) for m in models])
  for k,c in enumerate(centres):
   near=np.min(abs(np.delete(centres,k)-c))
   if near<6:continue
   yy=np.arange(round(c)-3,round(c)+4);orig=a[yy,xi].astype(float);backs=np.array([background(xi,int(y)) for y in yy]);dif=np.maximum(0,backs-orig)
   kk=np.argmax(dif.mean(1));cores.append(orig[kk]);areas.append(dif.sum(0)*native_px_pt)
 cores=np.array(cores);areas=np.array(areas)
 color=np.round(np.percentile(cores,12,axis=0)).astype(int)
 width=float(np.median(areas.mean(1))/np.mean(255-color))
 width=float(np.clip(width,.25,.8))
 assert len(cores)>20
 print(fam,'source style',color,width,'pt','samples',len(cores),'native res',max(m['source_residual_max_native_px'] for m in models),'erase px',int(tube.sum()),flush=True)
 # New source-native joining value/tangent then exact table knots, same actual last Q.
 r=b['rect'];dpi=b['dpi'];srcim=Image.open(S.report(P+fam+'-bieu-do-du-truc.png')).convert('RGB');renderarr=np.array(srcim)
 render=RenderCanvas(b['page']-1,r,dpi,renderarr,None)
 xs,ys=page_to_render(renderarr,b)
 ux=(xs-im.ctm[2,0])/im.ctm[0,0]*im.W;vy=(1-(ys-im.ctm[2,1])/im.ctm[1,1])*im.H
 iu=np.clip(np.floor(ux).astype(int),0,a.shape[1]-1);iv=np.clip(np.floor(vy).astype(int),0,a.shape[0]-1)
 m600=tube[iv[:,None],iu[None,:]]
 render.work[m600]=bg[iv[:,None],iu[None,:]][m600]
 Image.fromarray(render.work).save(fresh(S.report(O+fam+'-nen-da-tach.png')))
 shape_rows=[]
 for m in models:
  row=m['row'];xx=np.array([px(q) for q in t['Q']]);yy=np.array([py(h) for h in row['H']]);tar=PchipInterpolator(xx,yy)
  xjoin=cv.to_page(xlo,0)[0];qjoin=qx(xjoin)
  native_y=m['spl'](xlo);native_slope=m['spl'].derivative()(xlo)
  yjoin=pageY(native_y);djoin=-native_slope
  use=np.where(xx>xjoin+1e-7)[0];first=use[0];xf=xx[first];yf=yy[first]
  bridge=CubicHermiteSpline([xjoin,xf],[yjoin,yf],[djoin,float(tar.derivative()(xf))])
  xp=np.linspace(xjoin,xx[-1],1100);yp=np.where(xp<=xf,bridge(np.minimum(xp,xf)),tar(xp))
  points=list(zip(xp.tolist(),yp.tolist()));draw_polyline(render,points,color=tuple(map(int,color)),width_px=width*dpi/72,ss=4)
  controls=[]
  # Store Hermite -> cubic Bezier controls in page coords for later catfix insertion.
  knots=np.r_[xjoin,xx[use]]
  for il,(xa,xb) in enumerate(zip(knots[:-1],knots[1:])):
   fun=bridge if il==0 else tar;h=xb-xa;ya=float(fun(xa));yb=float(fun(xb));da=float(fun.derivative()(xa));db=float(fun.derivative()(xb))
   controls.append([[float(xa),ya],[float(xa+h/3),float(ya+da*h/3)],[float(xb-h/3),float(yb-db*h/3)],[float(xb),yb]])
  shape_rows.append(dict(curve_model=row['curve_model'],rank=m['rank'],table_Q=t['Q'],table_H=row['H'],kept_source_Q=[float(q) for q in t['Q'] if px(q)<xjoin],new_Q=[float(q) for q in t['Q'] if px(q)>=xjoin],Q_join=float(qjoin),join_page=[float(xjoin),float(yjoin)],source_tangent_page=float(djoin),bezier_segments=controls,source_sample_count=m['source_samples'],source_center_residual_max_native_px=m['source_residual_max_native_px'],source_last_Q=t['Q'][-1]))
 Image.fromarray(render.work).save(fresh(S.report(O+fam+'-sau.png')))
 srcim.save(fresh(S.report(O+fam+'-truoc.png')))
 # Native patch pixels only, no new curve baked into raster: final curves will be vector.
 np.savez_compressed(fresh(S.report(O+fam+'-nen-va-mask.npz')),orig=a,background=bg,mask=tube)
 out.append(dict(family=fam,page=b['page'],image_key=im.key,image_index=im.index,image_ref=[im.ref.obj,im.ref.gen] if hasattr(im.ref,'obj') else str(im.ref),ctm=im.ctm.tolist(),image_shape=list(a.shape),image_rect=[float(im.ctm[2,0]),float(im.ctm[2,1]),float(im.ctm[2,0]+im.ctm[0,0]),float(im.ctm[2,1]+im.ctm[1,1])],native_patch_box=[xlo,ylo,xhi+1,yhi+1],erased_native_pixels=int(tube.sum()),source_color_rgb=color.tolist(),width_pt=width,style_samples=len(cores),axis=b,curves=shape_rows,method='Tubes from actual source rank samples, full RGB stroke/JPEG-fringe replacement by sampled native grid; vector Pchip/Hermite; labels and dashed segments left untouched.',status='MẪU CHƯA NGHIỆM THU',pdf_written=False))

assert hashlib.sha256(Path(dest).read_bytes()).hexdigest()==before
Path(fresh(S.report(O+'TOA DO VA PHUONG PHAP.json'))).write_text(json.dumps(dict(before_pdf_sha256=before,pdf_unchanged=True,panels=out),ensure_ascii=False,indent=2),encoding='utf8')
E.close();print('Mẫu PNG xong, PDF chưa ghi',flush=True)
