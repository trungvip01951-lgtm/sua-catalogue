from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from pathlib import Path
from PIL import Image
import json,csv,numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter1d

PREFIX='G05/KIEM TOAN TOAN BO/'
axes=json.loads(Path(S.report(PREFIX+'TRUC VA NHAN.json')).read_text(encoding='utf8'))
# Giá trị trục cuối được đọc từ L/phút ở trục dưới, đối chiếu m3/h.
# (x trái, x phải, y H0, y Hmax, Qmax, Hmax, bước Q của vạch chính, bước H).
cfg={
 '4SP3':(479,777,314,500,4.8,400,.6,50),
 '4SP5':(52,205,405,509,7.2,400,.6,50),
 '4SP8':(230,385,405,509,12,240,1.2,30),
 '4SP10':(470,625,404,507,16.2,210,1.8,30),
 '4SP14':(649,803,404,507,19.8,180,1.8,30),
 '6SP10':(473,783,317,508,19.2,600,2.4,100),
 '6SP18':(71,368,314,501,27,720,3,120),
 '6SP30':(470,766,314,500,48,520,6,65),
 '6SP36':(76,373,315,502,60,450,6,50),
 '6SP46':(473,770,315,501,72,350,6,50),
 '6SP60':(72,368,313.24,500,84,300,6,50),
 '8SP77':(492,788,314,501,108,450,12,50),
 '8SP95':(62,359,316,502,132,400,12,50),
 '10SP135':(487,783,315.64,502,198,350,18,50),
 '10SP160':(55,352,321,508,240,350,24,50),
}
def bounds(im,a,c):
 r=a['rect'];scale=72/a['dpi'];g=np.asarray(im.convert('L')).astype(float)
 def px(x,y):return ((x-r[0])/scale,(r[3]-y)/scale)
 x0,x1,h0,hm,_,_,_,_=c
 ys=slice(round(px(0,hm-18)[1]),round(px(0,h0+18)[1]))
 xp=np.median(255-g[ys,:],axis=0)
 def edge_x(x):
  k=round(px(x,0)[0]);lo=max(0,k-65);hi=min(g.shape[1],k+66)
  arr=gaussian_filter1d(xp[lo:hi],1)
  p=lo+int(np.argmax(arr));sel=np.arange(max(lo,p-6),min(hi,p+7))
  baseline=np.min(xp[sel]);w=np.maximum(0,xp[sel]-baseline)
  p=float(np.sum(sel*w)/sum(w))
  return r[0]+p*scale
 x0=edge_x(x0);x1=edge_x(x1)
 xs=slice(round(px(x0+8,0)[0]),round(px(x1-8,0)[0]))
 yp=np.median(255-g[:,xs],axis=1)
 def edge_y(y):
  k=round(px(0,y)[1]);lo=max(0,k-65);hi=min(g.shape[0],k+66)
  arr=gaussian_filter1d(yp[lo:hi],1)
  peaks,_=find_peaks(arr,prominence=40,distance=15)
  peaks=[lo+int(v) for v in peaks if arr[v]>120]
  assert peaks,(a['family'],y)
  p=min(peaks,key=lambda v:abs(v-k))
  sel=np.arange(max(lo,p-6),min(hi,p+7));baseline=np.min(yp[sel]);w=np.maximum(0,yp[sel]-baseline)
  p=float(np.sum(sel*w)/sum(w));return r[3]-p*scale
 h0=edge_y(h0);hm=edge_y(hm)
 # Vạch lưới nhẹ: nền tách qua trung vị, giúp tránh lấy chữ/model làm vạch.
 xticks=[];yticks=[]
 for q in np.arange(0,c[4]+c[6]/2,c[6]):
  x=x0+(x1-x0)*q/c[4];k=round(px(x,0)[0]);lo=max(0,k-9);hi=min(g.shape[1],k+10)
  w=xp[lo:hi];peak=lo+int(np.argmax(gaussian_filter1d(w,.7)))
  kk=np.arange(max(lo,peak-4),min(hi,peak+5));ww=np.maximum(0,xp[kk]-min(xp[lo:hi]));peak=float(np.sum(kk*ww)/sum(ww)) if sum(ww)>0 else peak
  xticks.append([round(float(q),8),r[0]+peak*scale])
 for h in np.arange(0,c[5]+c[7]/2,c[7]):
  y=h0+(hm-h0)*h/c[5];k=round(px(0,y)[1]);lo=max(0,k-9);hi=min(g.shape[0],k+10)
  w=yp[lo:hi];peak=lo+int(np.argmax(gaussian_filter1d(w,.7)))
  kk=np.arange(max(lo,peak-4),min(hi,peak+5));ww=np.maximum(0,yp[kk]-min(yp[lo:hi]));peak=float(np.sum(kk*ww)/sum(ww)) if sum(ww)>0 else peak
  yticks.append([round(float(h),8),r[3]-peak*scale])
 # Trung tâm vạch lưới dùng vị trí đỉnh; đường biên dùng trọng tâm dải đen.
 xticks[0][1]=x0;xticks[-1][1]=x1;yticks[0][1]=h0;yticks[-1][1]=hm
 xc=np.polyfit(np.array(xticks)[:,0],np.array(xticks)[:,1],1)
 yc=np.polyfit(np.array(yticks)[:,0],np.array(yticks)[:,1],1)
 xf=float(max(abs(np.polyval(xc,np.array(xticks)[:,0])-np.array(xticks)[:,1])))
 yf=float(max(abs(np.polyval(yc,np.array(yticks)[:,0])-np.array(yticks)[:,1])))
 return dict(family=a['family'],page=a['page'],rect=r,dpi=a['dpi'],Qmax=c[4],Hmax=c[5],x0=x0,x1=x1,y0=h0,y1=hm,xticks=xticks,yticks=yticks,x_coeff=xc.tolist(),y_coeff=yc.tolist(),axis_fit_x_max_pt=xf,axis_fit_y_max_pt=yf)

out=[]
for a in axes:
 f=a['family'];im=Image.open(S.report(PREFIX+f+'-bieu-do-du-truc.png'));b=bounds(im,a,cfg[f]);out.append(b)
 print(f,'BOUND',*[round(b[k],3) for k in ['x0','x1','y0','y1']],'SCALE',np.round(b['x_coeff'],4),np.round(b['y_coeff'],4),'FIT',round(b['axis_fit_x_max_pt'],3),round(b['axis_fit_y_max_pt'],3),flush=True)
Path(fresh(S.report(PREFIX+'HIEU CHUAN TRUC V2.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
if not Path(S.report(PREFIX+'BANG QH DOC BANG MAT.json')).exists():
 Path(fresh(S.report(PREFIX+'BANG QH DOC BANG MAT.json'))).write_text(json.dumps(TABLES,ensure_ascii=False,indent=2),encoding='utf8')
rows=[]
for f,t in TABLES.items():
 for i,r in enumerate(t['rows']):
  for q,h in zip(t['Q'],r['H']):
   rows.append(dict(family=f,row=i+1,table_models=' | '.join(r['table_models']),curve_model=r['curve_model'],Q_m3h=q,H_table_m=h,identity_uncertain=r.get('identity_uncertain',False) or t['plot_family']!=f,table_image='BANG DAY DU/'+f+'.png'))
if not Path(S.report(PREFIX+'BANG QH DOC BANG MAT.csv')).exists():
 with open(fresh(S.report(PREFIX+'BANG QH DOC BANG MAT.csv')),'w',encoding='utf-8-sig',newline='') as fp:
  w=csv.DictWriter(fp,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('PHAM VI',len(TABLES),'bảng',sum(len(t['rows']) for t in TABLES.values()),'dòng đường',len(rows),'mốc có số; tất cả H đọc được',all(r['H_table_m'] is not None for r in rows),flush=True)
