"""Local source-only ring/counter recovery, RAM. No PDF file writes.

The JPEG does not contain an original font program. These contours are fitted
to each actual source character, with its native position and field size kept.
No other catalogue, system font, or caption glyph is used for these axes.
"""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from g04_perotac_whole_pdf_tools46 import read,sha
from scipy.optimize import least_squares
from scipy.special import expit
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,copy,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
oldpath=base/'CHU TRUC NGUON VA RAM CHI DOC/DON VI DAU CHAM DAU GACH CHEO VA i NGUON V2/CHU TRUC DAU NHO DOC RIENG V2 RAM CHUA NGHIEM THU.json'
root=base/'CHU TRUC TACH RING NGUON RAM V3B CHUA NGHIEM THU'
doc=read(oldpath);out=copy.deepcopy(doc);words={w['key']:w for w in out['words']}
E=Editor(S.src(name),backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);assert str(im.name)=='X7';cv=R.canvas(im)
zoom=96;records=[]

def alpha(key):
    w=words[key];b=w['source_native_box'];return R.alpha_of(cv.orig[b[1]:b[3],b[0]:b[2]],255,np.array(w['source_RGB']))

def path(segments,parent=-1,**extra):
    seg=np.asarray(segments,float);t=np.linspace(0,1,160,endpoint=False)[:,None];pts=[]
    for p in seg:pts.extend(((1-t)**3*p[0]+3*(1-t)**2*t*p[1]+3*(1-t)*t**2*p[2]+t**3*p[3]).tolist())
    return dict(local_native_xy=pts,cubic_segments_local_native=seg.tolist(),parent=parent,curve_segments=len(seg),**extra)

def area(p):
    xy=np.asarray(p['local_native_xy']);return abs(float(np.sum(xy[:,0]*np.roll(xy[:,1],-1)-xy[:,1]*np.roll(xy[:,0],-1))/2))

def ellipse(cx,cy,rx,ry,parent=-1):
    k=4*(np.sqrt(2)-1)/3
    ps=[[[cx,cy-ry],[cx+k*rx,cy-ry],[cx+rx,cy-k*ry],[cx+rx,cy]],
        [[cx+rx,cy],[cx+rx,cy+k*ry],[cx+k*rx,cy+ry],[cx,cy+ry]],
        [[cx,cy+ry],[cx-k*rx,cy+ry],[cx-rx,cy+k*ry],[cx-rx,cy]],
        [[cx-rx,cy],[cx-rx,cy-k*ry],[cx-k*rx,cy-ry],[cx,cy-ry]]]
    return path(ps,parent,own_source_ring_four_cubics=True)

def translate(p,dx,dy):
    q=copy.deepcopy(p);q['local_native_xy']=(np.asarray(p['local_native_xy'])+[dx,dy]).tolist()
    if p.get('cubic_segments_local_native'):q['cubic_segments_local_native']=(np.asarray(p['cubic_segments_local_native'])+[dx,dy]).tolist()
    return q

def from_knots(points,controls):
    seg=[]
    for i,p in enumerate(points):
        q=points[(i+1)%len(points)]
        if i in controls:c1,c2=controls[i]
        else:
            p=np.array(p);q=np.array(q);c1=p+(q-p)/3;c2=p+2*(q-p)/3
        seg.append([p,c1,c2,q])
    return path(seg,-1,source_horizontal_or_vertical_parts_preserved=True)

def actual_source_geometry_check(key,role,ps,window,threshold):
    a=alpha(key);x0,y0,x1,y1=window;aa=a[y0:y1,x0:x1];ref,_=source_reference(aa,np.array([x0,y0]),threshold)
    rp=np.concatenate(ref);pp=np.concatenate([np.asarray(p['local_native_xy']) for p in ps]);hd=max(float(cKDTree(rp).query(pp)[0].max()),float(cKDTree(pp).query(rp)[0].max()))
    inkarea=sum(area(p)*(1 if p['parent']<0 else -1) for p in ps);mass=float(aa.sum())
    records.append(dict(key=key,role=role,own_source_window=window,source_window_alpha_mass=mass,
        recovered_area_native_px=inkarea,recovered_vs_source_local_alpha_delta_percent=(inkarea/mass-1)*100,
        source_iso_reference_threshold=threshold,symmetric_boundary_to_local_source_iso_native_px=hd,
        source_JPEG_boundary_uncertainty_native_px=1.,boundary_within_source1pixel=hd<=1.,
        source_original_font_name_and_original_outline_UNKNOWN=True,other_font_or_catalogue_donor_used=False))

def topology(ps,w,h):
    mi=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);dr=ImageDraw.Draw(mi)
    for p in ps:dr.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p['local_native_xy']],fill=255 if p['parent']<0 else 0)
    mm=np.asarray(mi)>0;co,hi=cv2.findContours(mm.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
    return dict(components=sum(int(hi[0,i,3]<0) for i,c in enumerate(co) if cv2.contourArea(c)>zoom**2*.02),
                holes=sum(int(hi[0,i,3]>=0) for i,c in enumerate(co) if cv2.contourArea(c)>zoom**2*.02),area_native_px=float(mm.sum()/zoom**2))

def trace_local(a,offset,desired_components=1,desired_holes=0,area_allowance=.10):
    h,w=a.shape;up=cv2.resize(np.pad(a,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);mass=float(a.sum());choices=[]
    for threshold in np.arange(.30,.551,.001):
        mm=up>=threshold;co,hi=cv2.findContours(mm.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        good=[i for i,c in enumerate(co) if cv2.contourArea(c)/zoom**2>.06]
        nc=sum(hi[0,i,3]<0 for i in good);nh=sum(hi[0,i,3]>=0 for i in good)
        if nc==desired_components and nh==desired_holes:
            delta=(mm.sum()/zoom**2/mass-1);choices.append((abs(delta),threshold,co,hi,good,delta))
    if not choices:raise RuntimeError('No source-only topology candidate')
    _,thr,co,hi,good,delta=min(choices,key=lambda z:z[0]);result=[]
    for i in good:
        c=co[i];pp=(cv2.approxPolyDP(c,.085*zoom,True)[:,0,:].astype(float)+.5)/zoom-1
        seg=[]
        def tangent(k):
            before=pp[k]-pp[(k-1)%len(pp)];after=pp[(k+1)%len(pp)]-pp[k]
            angle=np.degrees(np.arccos(np.clip(before@after/max(np.linalg.norm(before)*np.linalg.norm(after),1e-9),-1,1)))
            return np.zeros(2) if angle>70 else (pp[(k+1)%len(pp)]-pp[(k-1)%len(pp)])*.12
        for j,p in enumerate(pp):
            k=(j+1)%len(pp);seg.append([p,p+tangent(j),pp[k]-tangent(k),pp[k]])
        p=path(seg,-1 if hi[0,i,3]<0 else 0,source_local_iso_threshold=float(thr),source_local_alpha_mass=mass)
        ref=np.repeat(pp,1,axis=0);dense=[]
        for j,point in enumerate(ref):dense.extend(point+np.linspace(0,1,80,endpoint=False)[:,None]*(ref[(j+1)%len(ref)]-point))
        dense=np.asarray(dense);prop=np.asarray(p['local_native_xy']);hd=max(float(cKDTree(dense).query(prop)[0].max()),float(cKDTree(prop).query(dense)[0].max()))
        p['source_iso_symmetric_boundary_distance_native_px']=hd;result.append(translate(p,*offset))
    return result,dict(source_local_alpha_mass=mass,selected_local_iso_threshold=float(thr),iso_area_delta_percent=float(delta*100),
                       source_local_topology_components=int(desired_components),source_local_topology_holes=int(desired_holes),
                       area_within10percent=abs(delta)<=area_allowance)

def source_reference(a,offset,threshold=.35):
    h,w=a.shape;up=cv2.resize(np.pad(a,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR)
    co,hi=cv2.findContours((up>=threshold).astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
    return [((c[:,0,:].astype(float)+.5)/zoom-1+offset) for i,c in enumerate(co) if cv2.contourArea(c)/zoom**2>.06],threshold

def fit_ring(key,role,window,bbox):
    full=alpha(key);x0,y0,x1,y1=window;a=full[y0:y1,x0:x1].copy();mass=float(a.sum())
    bx0,by0,bx1,by1=bbox;cx=(bx0+bx1)/2;cy=(by0+by1)/2;rx=(bx1-bx0)/2;ry=(by1-by0)/2
    # Integrate the actual observed source pixels rather than matching a binary
    # contour that has lost the weak JPEG bridge of a closed counter.
    yy,xx=np.mgrid[y0:y1,x0:x1];sub=(np.arange(6)+.5)/6;yy=yy[:,:,None,None]+sub[None,None,:,None];xx=xx[:,:,None,None]+sub[None,None,None,:]
    def coverage(par):
        ix,iy,irx,iry=par
        ro=np.sqrt(((xx-cx)/rx)**2+((yy-cy)/ry)**2);ri=np.sqrt(((xx-ix)/irx)**2+((yy-iy)/iry)**2)
        outer=expit((1-ro)*min(rx,ry)/.10);hole=expit((1-ri)*min(irx,iry)/.10)
        return (outer*(1-hole)).mean((2,3))
    def residual(par):
        ix,iy,irx,iry=par;pred=coverage(par);geometric_mass=np.pi*(rx*ry-irx*iry)
        return np.r_[(pred-a).ravel(),(geometric_mass-mass)*.16]
    inner_area=max(.6,rx*ry-mass/np.pi);start_rx=min(rx-.6,1.45);start_ry=min(ry-.45,inner_area/start_rx)
    p0=[cx,cy,start_rx,start_ry]
    low=[cx-.32,cy-.36,.65,max(.65,ry-1.9)];high=[cx+.32,cy+.36,rx-.35,ry-.35]
    p0=np.clip(p0,np.asarray(low)+.001,np.asarray(high)-.001)
    result=least_squares(residual,p0,bounds=(low,high),max_nfev=700,ftol=1e-12,xtol=1e-12,gtol=1e-12)
    ps=[ellipse(cx,cy,rx,ry),ellipse(*result.x,parent=0)];geometric_mass=area(ps[0])-area(ps[1])
    ref,thr=source_reference(a,np.array([x0,y0]))
    allref=np.concatenate(ref);allproposed=np.concatenate([np.asarray(p['local_native_xy']) for p in ps]);hd=max(float(cKDTree(allref).query(allproposed)[0].max()),float(cKDTree(allproposed).query(allref)[0].max()))
    evidence=dict(key=key,role=role,source_word_box=words[key]['source_native_box'],own_local_native_source_window=window,
        source_window_alpha_mass=mass,outer_bbox_native=bbox,outer_bbox_kept_from_source_field_envelope=True,
        inner_ellipse_parameters_native=result.x.tolist(),outer_four_cubics_and_inner_four_cubics=True,
        recovered_ring_area_native_px=geometric_mass,ring_vs_source_local_alpha_delta_percent=(geometric_mass/mass-1)*100,
        local_source_alpha_RMSE=float(np.sqrt(np.mean((coverage(result.x)-a)**2))),
        source_iso_reference_threshold=thr,source_iso_reference_only_not_original_vector_program=True,
        symmetric_boundary_to_local_source_iso_native_px=hd,source_JPEG_boundary_uncertainty_native_px=1,
        boundary_within_source1pixel=hd<=1.,native_field_box_and_advance_preserved=True,
        source_true_font_name_and_original_outline_UNKNOWN=True,other_font_or_catalogue_donor_used=False)
    records.append(evidence);return ps

def keep_before(key,right):
    kept=[]
    for p in words[key]['contour_paths']:
        if np.asarray(p['local_native_xy'])[:,0].max()<right:kept.append(copy.deepcopy(p))
    return kept

zero_cases=[('Q US 10','last zero',[12,2,19,11],[12.9765625,2.9296875,18.0859375,10.2578125]),
            ('Q US 30','last zero',[12,2,19,11],[12.8515625,2.9453125,17.9609375,10.2109375]),
            ('H FEET 200','first zero',[5,2,11,11],[5.82,2.6484375,10.41,9.9609375]),
            ('H FEET 200','second zero',[10,2,17,11],[10.88,2.6484375,16.0078125,9.9609375]),
            ('Q LMIN 150','last zero',[16,0,23,10],[16.96,.9453125,22.1171875,8.1015625]),
            ('Q LMIN 250','last zero',[16,0,23,10],[16.6953125,1.0234375,21.5859375,8.4921875]),
            ('Q LMIN 350','last zero',[16,0,23,10],[16.6015625,.9453125,22.0234375,8.4296875])]
rings={}
for key,role,win,bbox in zero_cases:rings.setdefault(key,[]).extend(fit_ring(key,role,win,bbox))
for key,ps in rings.items():
    if key=='H FEET 200':kept=keep_before(key,5.4)
    elif key=='Q LMIN 150':
        kept=keep_before(key,10.4)
        p5=[[16.35,.98],[16.35,1.98],[13.02,1.98],[12.82,3.51],[14.21,3.25],
            [16.61,5.61],[14.42,8.35],[12.02,7.31],[12.39,6.46],[14.36,7.30],
            [15.48,5.65],[13.89,4.31],[12.11,4.87],[11.96,4.15],[12.27,.98]]
        co5={3:[[13.11,3.3],[13.55,3.18]],4:[[15.43,3.25],[16.63,4.34]],
             5:[[16.66,7.19],[15.66,8.35]],6:[[13.43,8.36],[12.49,7.96]],
             8:[[12.99,7.14],[13.64,7.38]],9:[[15.16,7.26],[15.61,6.74]],
             10:[[15.36,4.56],[14.82,4.04]],11:[[13.2,4.15],[12.56,4.4]]}
        five=[from_knots(p5,co5)];actual_source_geometry_check(key,'5 separated from its neighbouring zero',five,[11,0,17,10],.4);kept.extend(five)
    elif key=='Q LMIN 250':kept=keep_before(key,16.5)
    elif key=='Q LMIN 350':kept=keep_before(key,16.5)
    else:kept=keep_before(key,12.5)
    # Parent references are local to a ring; even-odd PDF filling is invariant
    # to indices. Retain a meaningful actual index in the JSON for inspection.
    for i,p in enumerate(ps):
        q=copy.deepcopy(p);q['parent']=-1 if i%2==0 else len(kept)-1;kept.append(q)
    words[key]['contour_paths']=kept
    words[key]['local_source_recovery_applied']=True

# Eta(%) E is kept exactly. The local t and a use independent actual source
# alpha, not the threshold for the complete six-character field.
key='ETA UNIT';a=alpha(key);ps=keep_before(key,9.25)
pt=[[10.12,4.77],[11.45,4.77],[11.45,5.83],[12.68,5.83],[12.68,6.79],
    [11.45,6.79],[11.45,9.78],[12.18,10.14],[12.38,11.02],[10.12,9.91],
    [10.12,6.79],[9.58,6.79],[9.58,5.83],[10.12,5.83]]
ct={6:[[11.46,10.17],[11.93,10.29]],8:[[11.04,11.5],[10.09,10.91]]}
t=[from_knots(pt,ct)];actual_source_geometry_check(key,'t own source crossbar and stem separated from a',t,[9,3,13,12],.4);ps.extend(t)
ap,ev=trace_local(a[5:12,12:18],(12,5),1,1);records.append(dict(key=key,role='a',**ev));ps.extend(ap)
for role,reg in [('left parenthesis',[18,3,22,14]),('right parenthesis',[30,3,35,14])]:
    x0,y0,x1,y1=reg;q,ev=trace_local(a[y0:y1,x0:x1],(x0,y0),1,0);records.append(dict(key=key,role=role,**ev));ps.extend(q)
# The percent rings are measured separately, so the diagonal's blurred fringe
# cannot join a ring at the source threshold for the whole field.
upper=[ellipse(23.73,5.70,1.56,1.78),ellipse(23.73,5.70,.66,1.05,parent=0)]
lower=[ellipse(28.390625,9.4765625,1.5234375,1.65625),ellipse(28.390625,9.4609375,.6328125,.953125,parent=0)]
diag=np.asarray([[27.55,3.85],[28.38,3.85],[24.93,10.99],[24.10,10.99]])
diagsegs=[]
for i,p in enumerate(diag):
    q=diag[(i+1)%4];diagsegs.append([p,p+(q-p)/3,p+2*(q-p)/3,q])
percent=upper+lower+[path(diagsegs,-1,source_percent_straight_diagonal=True)]
for p in percent:
    q=copy.deepcopy(p);q['parent']=-1 if p['parent']<0 else len(ps)-1;ps.append(q)
ref,threshold=source_reference(a[3:12,22:31],np.array([22,3]),.35)
reference=np.concatenate(ref);prop=np.concatenate([np.asarray(p['local_native_xy']) for p in percent]);hd=max(float(cKDTree(reference).query(prop)[0].max()),float(cKDTree(prop).query(reference)[0].max()))
mass=float(a[3:12,22:31].sum());inkarea=sum(area(p)*(1 if p['parent']<0 else -1) for p in percent)
records.append(dict(key=key,role='percent two source rings and one diagonal',source_window_alpha_mass=mass,
    proposed_percent_ink_area_native_px=inkarea,percent_vs_source_local_alpha_delta_percent=(inkarea/mass-1)*100,
    source_iso_reference_threshold=threshold,symmetric_boundary_to_local_source_iso_native_px=hd,
    source_JPEG_boundary_uncertainty_native_px=1.,boundary_within_source1pixel=hd<=1,
    original_percent_vector_shape_UNKNOWN=True,own_source_only=True))
words[key]['contour_paths']=ps;words[key]['local_source_recovery_applied']=True

tiles=[]
for key in list(rings)+['ETA UNIT']:
    w=words[key];b=w['source_native_box'];raw=cv.orig[b[1]:b[3],b[0]:b[2]];h,ww=raw.shape[:2]
    measure=topology(w['contour_paths'],ww,h);w['local_recovered_topology']=measure
    mass=float(alpha(key).sum());w['local_recovered_vs_original_word_alpha_delta_percent']=(measure['area_native_px']/mass-1)*100
    visual=Image.new('RGB',(ww*32,h*32),'white');dr=ImageDraw.Draw(visual)
    for p in w['contour_paths']:dr.polygon([(x*32,y*32) for x,y in p['local_native_xy']],fill=tuple(w['source_RGB']) if p['parent']<0 else 'white')
    tile=Image.new('RGB',(max(1200,ww*64+100),h*32+80),'white');td=ImageDraw.Draw(tile)
    td.text((10,8),key+' SOURCE X7 / LOCAL RECOVERY RAM ONLY',fill='black')
    tile.paste(Image.fromarray(raw).resize((ww*32,h*32),Image.Resampling.NEAREST),(0,45));tile.paste(visual,(ww*32+50,45))
    tile.save(fresh(root/(key+' NGUON VA RING RAM V3 CHUA NGHIEM THU.png')));tiles.append(tile)
    print(key,measure,'WORD AREA DELTA%',w['local_recovered_vs_original_word_alpha_delta_percent'],flush=True)
atlas=Image.new('RGB',(max(t.width for t in tiles),sum(t.height+10 for t in tiles)),'white');yy=0
for tile in tiles:atlas.paste(tile,(0,yy));yy+=tile.height+10
atlas.save(fresh(root/'7 FIELD TACH RING NGUON VA RAM V3 CHUA NGHIEM THU.png'))
out.update(stage='LOCAL SOURCE RECOVERY RAM ONLY; GRAPHIC REVIEW PENDING',previous_axis_bank_path=str(oldpath),previous_axis_bank_SHA256=sha(oldpath),
    local_recovery_evidence=records,caption_font4_or_QH_or_ticks_or_eta_curve_not_changed=True,
    M3_unit_still_unrepaired_source_resolution_limit=True,all_axis_fields_accepted=False,no_PDF_font_or_progress_written=True,
    source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)))
assert out['source_sha256']==doc['source_sha256'] and out['current_sha256']==doc['current_sha256']
Path(fresh(root/'CHU TRUC0 VA PHANTRAM TACH RIENG NGUON V3B RAM CHUA NGHIEM THU.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),encoding='utf8')
print('LOCAL RING EVIDENCE',[(r['key'],r['role'],r.get('ring_vs_source_local_alpha_delta_percent'),r.get('symmetric_boundary_to_local_source_iso_native_px')) for r in records],flush=True)
E.close()
