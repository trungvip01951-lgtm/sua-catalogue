"""Source-only local observed seeds, current labels visible; candidates, never count=identity."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import color_runs
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));v=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'));a=json.loads((root/'17 TRUC DOC NGUON RIENG KHOA V1.json').read_text(encoding='utf8'));f=json.loads((root/'17 TRUC NGUON XY CANDIDATE V4.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(v['source']),sha(v['current'])];assert before==[v['source_SHA256'],v['current_SHA256']]
Ea=Editor(v['source'],backend='fitz');Ez=Editor(v['current'],backend='fitz');Ra=Raster(Ea);Rz=Raster(Ez);out=[]
for z,frame in zip(a['records'],f['records']):
 assert z['family']==frame['family'];left,right=frame['H_frame_x_page'];bottom=min(z['H_printed_grid_page_y']);top=max(z['H_printed_grid_page_y']);rect=(left-2,bottom-1,right+1,top+1);cv=Ra.render_canvas(z['page']-1,rect,dpi=300);ar=cv.orig.astype(float);g=ar@np.array([.299,.587,.114]);mask=(ar[:,:,1]-ar[:,:,0]>4)&(ar[:,:,2]-ar[:,:,0]>6)&(g<235);weights=255-g;seedx=left+(right-left)*.47;u=int(round(cv.to_px(seedx,0)[0]));raw=color_runs(mask,weights,u,4,len(g)-5,max_width=18);candidates=[dict(index=i,**r,page=list(cv.to_page(u,r['v']))) for i,r in enumerate(raw) if r['strength']>=60]
 current=Rz.render_canvas(z['page']-1,(left+(right-left)*.14,bottom-1,seedx+9,top+1),dpi=600);plain=Image.fromarray(current.orig);plainfile=fresh(root/'NHAN VA SEED HIEN HANH'/f'TRANG {z["page"]:02} {z["family"]} NHAN KHONG DANH DAU.png');plain.save(plainfile);marked=plain.copy();draw=ImageDraw.Draw(marked)
 for c in candidates:
  xx,yy=current.to_px(*c['page']);draw.ellipse((xx-3,yy-3,xx+3,yy+3),outline=(180,0,180),width=1);draw.text((xx+5,yy-4),str(c['index']),fill=(180,0,180))
 photo=fresh(root/'NHAN VA SEED HIEN HANH'/f'TRANG {z["page"]:02} {z["family"]} UNG VIEN SEED.png');marked.save(photo)
 models=[r['model'] for r in v['rows'] if r['family']==z['family']];rec=dict(page=z['page'],family=z['family'],source_SHA256=v['source_SHA256'],current_SHA256=v['current_SHA256'],source_dpi=300,source_rect=list(cv.rect0),source_seed_column=u,source_seed_page_x=cv.to_page(u,0)[0],source_H_band=[bottom,top],source_raw_runs=raw,candidates=candidates,current_names_photo=str(plainfile),current_names_seed_photo=str(photo),table_models_unassigned=models,classification='CANDIDATE ONLY. Khóa mỗi tên theo nhãn hiện hành và nối nét quan sát riêng; không ép số lượng hoặc thứ hạng theo H bảng.',catalogue_written=False)
 out.append(rec);print(z['family'],'local candidates',len(candidates),'table rows',len(models),'ids',[p['index'] for p in candidates],flush=True)
Ea.close();Ez.close();assert before==[sha(v['source']),sha(v['current'])]
Path(fresh(root/'17 NHOM SEED CANDIDATE.json')).write_text(json.dumps(dict(records=out,source_SHA256=v['source_SHA256'],current_SHA256=v['current_SHA256'],catalogue_written=False,curve_numeric_acceptance=False),ensure_ascii=False,indent=2),encoding='utf8')
