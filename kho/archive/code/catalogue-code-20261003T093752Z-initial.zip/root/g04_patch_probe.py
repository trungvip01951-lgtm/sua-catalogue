from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix.recipes import Job
plan=json.loads(Path(S.report('G04/KE HOACH Perotac.json')).read_text(encoding='utf8'))
p=[p for p in plan['plans'] if p['task']==37][0]
for mode in ['native','render']:
    j=Job(plan['file']['src'],fresh(S.report('G04/THU NHO '+mode+' 37.pdf')))
    R=j.R
    cv=R.canvas(R.images(0)[0]) if mode=='native' else R.render_canvas(0,(0,0,841.89,598.79),dpi=300)
    hit=dict(text='1546',box=cv.box(p['rect']))
    comps=R.components(cv,hit['box'],expect=4);assert len(comps)==4
    sample=dict(text='1546',word=hit,base=float(np.median([c['box'][3] for c in comps])),comps=comps,size=float(np.percentile([c['box'][3]-c['box'][1] for c in comps],75)))
    bank=R._bank_from_samples([sample])
    R.replace_word(cv,hit,'1566',bank,erase_method='ring')
    yy,xx=np.where(np.any(cv.work!=cv.orig,axis=2));box=(int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1))
    R._write_patch(cv,box,encoding='flate');cv.orig=cv.work.copy()
    j._add(0,p['rect'],'1546 ->1566','raster');j.save();j.close()
    r=j.check(raster=True);j.evidence(fresh(S.report('G04/THU NHO '+mode+' 37.png')),dpi=350)
    print(mode,'box',box,'check',r,flush=True)
