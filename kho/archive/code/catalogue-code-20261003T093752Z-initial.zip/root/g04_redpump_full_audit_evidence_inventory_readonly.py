"""Inspect saved SL-specific audit coverage, hashes and schema. No PDF writes."""
from catwork import start
S,D,N=start()
from pathlib import Path
import json,hashlib,collections
R=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
for fn in ['DANH MUC BANG NGUON 196 DONG V2.json','1931 O NGUON DINH VI VA DOI CHIEU V2.json',
    '17 TRUC DOC NGUON RIENG KHOA V1.json','DINH DANH NHAN VA SEED DOC TRUC TIEP V1.json',
    '4SL16_25 SO DO NGUON VA BAN GIAO.json']:
    path=R/fn;d=json.loads(path.read_text(encoding='utf8'))
    print('FILE',fn,'SHA',hashlib.sha256(path.read_bytes()).hexdigest(),'KEYS',list(d),flush=True)
    for k,v in d.items():
        if k in ['source','current','source_SHA256','current_SHA256','status','scope','source_axis_scope','unknown_models','unknown_H_cells']:
            print(' FIELD',k,str(v)[:1600],flush=True)
        elif isinstance(v,list):
            print(' LIST',k,len(v),'FIRST',str(v[:1])[:4000],flush=True)
            if k in ['records','rows'] and v and isinstance(v[0],dict):
                for key in ['page','family','model_locked','status','result','source_identity_locked']:
                    if any(key in z for z in v):print('  COUNTS',key,dict(collections.Counter(str(z.get(key)) for z in v)),flush=True)
    if 'source' in d and 'current' in d:
        print('LIVE_SOURCE_CURRENT_SHA',[(k,hashlib.sha256(Path(d[k]).read_bytes()).hexdigest()) for k in ['source','current']],flush=True)
for fn in ['KIEM KE NGUON RIENG VA FONT 17 BIEU DO.json','PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json']:
    path=P/fn;d=json.loads(path.read_text(encoding='utf8'));print('PLANFILE',fn,'KEYS',list(d),flush=True)
    for key in ['all_17_groups','whole_file_framework','source_data']:
        if key in d:print('PLAN',key,json.dumps(d[key],ensure_ascii=False)[:18000],flush=True)
