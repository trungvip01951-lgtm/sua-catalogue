from catwork import start,fresh
from pathlib import Path
import json
S,D,N=start();j=S.job('KTZ - LH Perotac (bản mới).pdf');P=j.E.page(6);r=(116,602,138,612)
data=[]
for oi in P.objects_in(r):
    o=P.objs[oi]
    if o['bbox'][2]-o['bbox'][0]>30 or o['bbox'][3]-o['bbox'][1]>20:continue
    v=dict(oi=oi,op=o['op'],bbox=o['bbox'],fill=P.color_of(oi,'fill'),stroke=P.color_of(oi,'stroke'),lw=o.get('lw'),path=P.object_pagepath(oi),subs=[dict(index=si,bbox=s['bbox'],j0=s['j0'],j1=s['j1']) for si,s in enumerate(o['subs'])])
    data.append(v);print({k:v[k] for k in v if k!='path'},flush=True)
Path(fresh(S.report('G09/CAC LOP NHAN637.json'))).write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding='utf-8');j.close()
