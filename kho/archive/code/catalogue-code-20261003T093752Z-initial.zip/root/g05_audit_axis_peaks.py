from catwork import start,HERE
S,D,N=start()
from pathlib import Path
from PIL import Image
import numpy as np,json
from scipy.signal import find_peaks
p='G05/KIEM TOAN TOAN BO/'
for b in json.loads(Path(S.report(p+'HIEU CHUAN TRUC.json')).read_text(encoding='utf8')):
 g=np.array(Image.open(S.report(p+b['family']+'-bieu-do-du-truc.png')).convert('L'),float)
 r=b['rect'];s=72/b['dpi'];x0=round((b['x0']+8-r[0])/s);x1=round((b['x1']-8-r[0])/s)
 prof=np.median(255-g[:,x0:x1],axis=1);pk,props=find_peaks(prof,distance=12,prominence=15)
 vals=[(round(r[3]-float(y)*s,3),round(float(prof[y]),1)) for y in pk if (r[3]-y*s)>b['y0']-15 and (r[3]-y*s)<b['y0']+15]
 print(b['family'],'H0 neighborhood',vals,flush=True)
