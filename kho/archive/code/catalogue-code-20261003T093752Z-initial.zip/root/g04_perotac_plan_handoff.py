from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import charts,verify
from pathlib import Path
from PIL import Image,ImageDraw
from scipy.interpolate import CubicHermiteSpline
from scipy.spatial import cKDTree
from g04_perotac_audit_data import DATA
from g04_perotac_audit_labels_manual import MANUAL
import json,numpy as np,hashlib,math
name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name)
root=Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC'))
measure=json.loads((root/'SO DO VA DO NET 5 PHUONG AN.json').read_text(encoding='utf8'))
build=json.loads(Path(S.report('G04/NET PDF THAT MAU2/TAO VA KIEM MAU.json')).read_text(encoding='utf8'))
receipt=json.loads(Path(S.report('G04/NGHIEM THU BAN CUOI NET PDF THAT.json')).read_text(encoding='utf8'))
Ec=Editor(dst,backend='fitz');Rc=Raster(Ec);P=Ec.page(7);cvcur=Rc.canvas(max(Rc.images(7),key=lambda z:z.W*z.H));protected=[]
for r in build['records']:
 objects=[];coords=[]
 for oi,o in enumerate(P.objs):
  col=P.color_of(oi,'stroke')
  if o['op']!='S' or col is None or max(abs(np.array(col)-np.array(r['RGB'])/255))>1e-7:continue
  path=P.object_pagepath(oi);a=charts.sample_path(path,n=1200);native=np.array([cvcur.to_px(*z) for z in a]);coords.extend(native.tolist())
  obj=dict(object_index=oi,op=o['op'],stroke=col,lw=o['lw'],dash=o.get('dash'),actual_pagepath=path)
  obj['signature_sha256']=hashlib.sha256(json.dumps(obj,sort_keys=True,default=str).encode()).hexdigest();objects.append(obj)
 assert len(objects)==len(r['native_dash_Q_intervals'])
 protected.append(dict(model=r['model'],objects=objects,native_path_for_protection_only=coords,no_reaudit_of_QH=True))
Ec.close();E=Editor(src);R=Raster(E);items=[]
for it in measure['items']:
 c=dict(it);cv=R.canvas(max(R.images(it['page']-1),key=lambda z:z.W*z.H));nodes=it['numeric_nodes'];xs=np.array([n['u'] for n in nodes]);ys=np.array([n['v'] for n in nodes]);poly=CubicHermiteSpline(xs,ys,it['proposed_tangent_dv_du']);u=np.linspace(xs[0],xs[-1],901);points=np.c_[u,poly(u)]
 c['protected_current_curve_distances']=[]
 if c['family']=='4SA16':
  for p in protected:
   xy=np.array(p['native_path_for_protection_only']);mind=float(cKDTree(xy).query(points)[0].min());c['protected_current_curve_distances'].append(dict(model=p['model'],minimum_center_distance_native_px=mind,minimum_center_distance_page_pt=mind*c['source_step_pt_per_native_px']))
 lx,labels=MANUAL[c['family']];nearest=[]
 x0,y0,x1,y1=c['proposed_native_edit_bounding_box']
 for suffix,t,b in labels:
  bb=(lx,t,lx+65,b);dx=max(bb[0]-x1,x0-bb[2],0);dy=max(bb[1]-y1,y0-bb[3],0);dist=math.hypot(dx,dy);nearest.append(dict(source_literal_label=c['family']+'/'+str(suffix),native_box=bb,distance_from_edit_box_native_px=dist))
 c['nearby_text_boxes']=sorted(nearest,key=lambda z:z['distance_from_edit_box_native_px'])[:3]
 c['source_table_re_read']=dict(last_Q_m3_h=c['original_point']['Q_m3_h'],last_Q_l_min=c['original_point']['Q_l_min'],last_H_m=c['original_point']['H_table_m'],join_Q_m3_h=c['numeric_join']['Q_m3_h'],join_H_table_m=c['numeric_join']['H_table_m'],whole_row_H_table_m=next(r['H'] for d in DATA if d['family']==c['family'] for r in d['rows'] if r['model']==c['model']),literal_cells_viewed_at_dpi=500)
 c['join_existing_H_is_retained']=True;c['H_table_join_not_replaced_by_new_number']=True
 c['not_numeric_accepted_whole_curve']=True;c['proposal_status']='CHỜ ROOT KIỂM PHƯƠNG ÁN; CHƯA VIẾT MẪU PDF'
 c['erase_boundary_method']='Chỉ mặt nạ mực/quầng của đúng nét nguồn từ điểm nối đến hết endpoint cũ, kể cả đoạn ngoài Q cuối. Khôi phục nền từ chính hàng/cột lưới nguồn. Không quét cả ô, không dùng patch đã sửa làm nguồn.'
 c['draw_method']='Nét PDF thật chỉ trong miền từ Q nối đến Q cuối có số. Hermite giảm trơn: giữ tọa độ và tiếp tuyến nguồn tại nối; mốc cuối bằng H bảng. Đo lại actual path trong PDF mẫu, không dùng bản vẽ trong bộ nhớ làm nghiệm thu.'
 c['dash_preservation']='Giữ toàn bộ đầu nét đứt nguyên nguồn; vùng đuôi đang xét là nét liền, giữ màu và độ dày tương đương nguồn đo riêng.'
 c['old_extra_tail']='Lưu nguyên ảnh nguồn và tọa độ mực cũ làm chứng; khi dựng kết thúc tại mốc cuối có số, không gán hay vẽ thêm Q-H cho đoạn kéo dài cũ.'
 c['image_preservation']='Giữ toàn bộ JPEG gốc đúng byte/ma trận; chỉ thêm miếng ảnh lossless (không mất dữ liệu) có SMask (mặt nạ độ trong suốt) tại pixel thật đổi, rồi nét PDF vector.'
 c['acceptance_before_canonical']=['ROOT xem đúng ảnh PDF thật ở 400–600 dpi','Đọc lại actual path: Q/H mốc cuối, mốc nối và mọi mốc có số thuộc đoạn mới; phải giảm liên tục, không vượt miền bảng','Vùng ngoài 5 hộp: 0 pixel khác; chữ đen/lưới và nét lân cận kiểm độc lập','Hai đường /23,/18 giữ nguyên mọi path/style/dash và điểm ảnh vùng riêng','11 ảnh JPEG gốc đúng SHA256/ma trận; metadata XML sau chuẩn hóa, Info, links, bookmarks, page sizes giữ','Nhiều nhất 2 mẫu thất bại cùng phương pháp; chưa tính ĐẠT khi chỉ có file']
 if c['family']=='3SS3':c['extra_table_anchor_inside_repair']=dict(Q_m3_h=3.3,H_table_m=75,old_status='CHƯA THỂ XÁC MINH',reason='Có số 75 thật trong bảng; dùng nó làm neo đoạn mới, không gọi nét cũ tại đó sai chắc. Chỉ xét lại sau mẫu được đọc thực tế.')
 items.append(c)
 # Actual source tail at its original resolution, plus the same enlarged view.
 box=c['proposed_native_edit_bounding_box'];view=(box[0]-8,box[1]-8,box[2]+8,box[3]+8);raw=Image.fromarray(cv.orig[view[1]:view[3],view[0]:view[2]]);raw.save(fresh(root/c['model'].replace('/','-')/'DUOI NGUON NGUYEN DO PHAN GIAI.png'));raw.resize((raw.width*8,raw.height*8),Image.Resampling.NEAREST).save(fresh(root/c['model'].replace('/','-')/'DUOI NGUON PHONG 8 LAN.png'))
for fam in ['3SS3','3SS4','4SA16']:
 d=next(z for z in DATA if z['family']==fam);cv=R.canvas(max(R.images(d['page']-1),key=lambda z:z.W*z.H));box=d['plot_native_box'];left=box[0];raw=Image.fromarray(cv.orig[box[1]-12:box[3]+12,left-55:left+12]);raw.resize((raw.width*5,raw.height*5),Image.Resampling.NEAREST).save(fresh(root/('NHAN SO VA VACH H GOC '+fam+'.png')))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
out=dict(read_only=True,pdf_written=False,trial_pdf_written=False,common_progress_written=False,source_sha256=sha(src),current_sha256=sha(dst),prior_accepted_two_curve_receipt=receipt,protected_current_curves=protected,independent_axis_measurement=measure['Q_axis_independent_refinement'],five_confirmed_points_still_fail_after_independent_actual_tick_measurement=all(c['independent_refined_grid_still_fail'] for c in items),unknown_points_from_whole_audit_unchanged=235,model_identity_locked_from_literal_labels_and_continuous_source_ink_not_H_or_power=True,items=items,approved_technical_choice='ROOT chọn /20,/25 kết thúc Q21/H cuối bảng; đuôi thiếu số cũ lưu bằng chứng và không đưa vào dựng lại.')
Path(fresh(root/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda z:z.tolist() if isinstance(z,np.ndarray) else str(z)),encoding='utf8')
md=['# Phương án 5 mốc lệch — chỉ đọc, chưa tạo mẫu PDF','','Bản gốc và bản đang giao giữ nguyên SHA256. Đã đọc lại 5 ô cuối và các ô nối trong bảng ở 500 dpi; nhãn, vạch và mực từng nét đã xem trực tiếp. 5 mực riêng source/current ở 600 dpi đều 0 pixel khác. Đo lại trọng tâm vạch Q thật độc lập vẫn xác nhận cả 5 điểm lệch vượt dung sai cộng độ không chắc; không dùng tâm số in làm vạch.','','| Model / trang | Q cuối / H bảng | H nét cũ | Lệch / ngưỡng / độ không chắc (m) | Điểm nối Q, H bảng, H nét giữ | Vùng sửa native | RGB lõi / độ dày tương đương pt |','|---|---|---:|---|---|---|---|']
for c in items:
 p=c['original_point'];j=c['numeric_join'];md.append(f'| {c["model"]} / {c["page"]} | {p["Q_m3_h"]:g} / {p["H_table_m"]:g} | {p["H_curve_m"]:.4f} | +{p["delta_H_m"]:.4f} / {p["tolerance_H_m"]:g} / ±{p["uncertainty_H_m"]:g} | {j["Q_m3_h"]:g}, {j["H_table_m"]:g}, {j["H_curve_m"]:.4f} | {c["proposed_native_edit_bounding_box"]} | {c["source_color_RGB"]} / {c["source_equivalent_width_pt"]:.4f} |')
md+=['','Q: m³/giờ; H: mét. Điểm nối giữ đúng mực nguồn hiện hữu và tiếp tuyến đo trên mực trước nối; H bảng của điểm nối được ghi để đối chiếu, không đổi H hiện hữu thành một số tự tạo. 3SS3/37 nối tại Q3, giữ H≈92,0307 (bảng91, đang khớp); đoạn mới đi qua số thật Q3,3/H75 rồi Q3,6/H54. Mốc Q3,3 cũ vẫn được ghi CHƯA THỂ XÁC MINH, chỉ nghiệm thu lại khi PDF mẫu đã lưu và được đọc độc lập.','','Các vùng sửa ở tọa độ pixel của nguyên ảnh JPEG 1754×1247, ~150 dpi. Tọa độ trang PDF đầy đủ và tiếp tuyến/đạo hàm giảm lưu trong JSON. Hộp chỉ giới hạn thay đổi; không xóa cả hộp. Mặt nạ phải chỉ lấy mực/quầng đúng nét, giữ chữ, lưới và nét khác. Miếng SMask là mặt nạ độ trong suốt, giữ nguyên toàn ảnh JPEG gốc. Nét mới là đường vector PDF thật.','','Màu và độ dày là đo tương đương từ ảnh JPEG gốc từng nét, chưa có chương trình nét vector gốc để đọc một thông số w tuyệt đối. Đã lưu số mẫu, độ phân tán 10–90%, và ảnh đuôi ở nguyên độ phân giải + phóng8lần. ROOT cần xét độ đậm/độ dày trong PDF mẫu thật trước khi nhận.','','Hai đường 4SA16/23 và /18 đã được duyệt: chỉ lấy path đang có làm vùng bảo vệ, không đo lại nghiệm thu. Chữ và khung đen trong cả5hộp kế hoạch: '+str([c['contains_black_text_or_frame_pixels'] for c in items])+'. Khoảng cách gần nhất tới path đã duyệt trong từng phương án p8:']
for c in items:
 if c['family']=='4SA16':md.append('- '+c['model']+': '+', '.join(z['model']+' '+f'{z["minimum_center_distance_native_px"]:.3f}px ({z["minimum_center_distance_page_pt"]:.3f}pt)' for z in c['protected_current_curve_distances'])+'.')
md+=['','ROOT đã chọn p8 kết thúc đúng Q21/H43 hoặc54. Đuôi nguồn kéo tới u684–685 vẫn lưu trong ảnh/bằng chứng; vùng xóa phải đến hết endpoint và quầng cũ để không sót nét. Không dựng đoạn sau Q21 và không chốt thêm Q-H. Đầu nét đứt của cả5 đường nằm trước điểm nối, giữ nguyên.','','Kỹ thuật dựa phương pháp /23,/18 NET PDF THAT MAU2 đã được duyệt trong chính Perotac; chỉ tái dùng tách mực theo pixel + true vector, không tái dùng guide H+2 để khóa nhánh, không sao chép màu/độ dày của hai đường đó. Danh tính 5 đường được khóa bằng nhãn và bám mực nguồn liên tục.','','Các ảnh SO DO PHUONG AN CHI DINH VI.png có đường màu xanh và vòng đỏ chỉ là chú giải tọa độ kế hoạch; không phải ảnh catalogue đã sửa. Bộ thực tế mỗi model có bảng nguồn/hiện hành500dpi, nhãn600dpi, biểu đồ nguồn/hiện hành400dpi, đuôi nguồn/hiện hành600dpi và đuôi gốc150dpi.','','Chưa ghi mẫu PDF, chưa sửa bản đang giao, chưa ghi tiến độ chung. 235 mốc chưa rõ từ kiểm toán toàn bộ giữ nguyên trạng thái; không nâng toàn đường lên ĐẠT. Sau ROOT kiểm kế hoạch: nhiều nhất2mẫu thất bại/một phương pháp; PDF mẫu phải được đọc lại actualpath, nhìn 400–600dpi, kiểm ngoài vùng0pixel, chữ/lưới và hai path đã duyệt giữ nguyên; metadata/links/11JPEG nguồn cũng phải giữ.','','SHA nguồn: '+sha(src),'SHA bản đang giao: '+sha(dst),'']
Path(fresh(root/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM.md')).write_text('\n'.join(md),encoding='utf8');E.close()
print('READONLY PLAN',len(items),'5FAIL',out['five_confirmed_points_still_fail_after_independent_actual_tick_measurement'],'BLACK',[c['contains_black_text_or_frame_pixels'] for c in items])
for c in items:print('PROTECT',c['model'],c['protected_current_curve_distances'],'TEXT',c['nearby_text_boxes'][0])
