"""Independent read-only source/geometry QA. Never save PDF or raster images."""
from catwork import start, fresh, HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,math,csv,io
import numpy as np
from PIL import Image
import fitz

INP=HERE/'wc_clip_source_du_lieu_20261003'/'DU LIEU DUONG CAT NGUON V4B BIEN THAN DUNG'/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json'
LOCK='d2356789b101589037eb587a6e75af4ce899e0c5297e6f316969217c162cce7a'
RAM=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs\per_wc_continue_photo_union_v4B_RAM_a1')
OUT=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(INP)==LOCK
raw=json.loads(INP.read_text(encoding='utf8'))
name='Catalog cắt rác perotac (bản mới).pdf'
src=Path(S.src(name));can=Path(S.dst(name))
guards={str(src):'622bcc5a8bb0562bea11474bda8801f30fe91839db3b84980dcb4ead056131d4',str(can):'5418b7bddd8d76eb09148f0f1f469609c2af77544a4ef4196e314900110b7f3d',str(INP):LOCK}
for p,h in guards.items():assert sha(p)==h,(p,'SHA changed')

def parse(q):
    cs=q['commands_pixel'];pts=[];ops=[]
    for c in cs:
        op=c if isinstance(c,str) else c[0]
        assert op in ('M','L','Z'),op
        ops.append(op)
        if op!='Z':
            assert len(c)==3,c
            pts.append([float(c[1]),float(c[2])])
    assert ops[0]=='M' and ops[-1]=='Z' and ops.count('M')==1 and ops.count('Z')==1
    p=np.array(pts,dtype=float)
    if np.array_equal(p[0],p[-1]):p=p[:-1]
    assert len(p)>=3 and np.isfinite(p).all()
    return p

def area(p):return float(.5*np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1]))
def cross(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]
def winding(p,pts):
    z=np.array(pts,dtype=float).reshape(-1,2)
    a=p;b=np.roll(p,-1,axis=0);r=b-a
    out=[]
    for i in range(0,len(z),256):
        t=z[i:i+256];v=t[:,None,:]-a[None,:,:]
        c=cross(r[None,:,:],v)
        up=(a[None,:,1]<=t[:,None,1])&(b[None,:,1]>t[:,None,1])&(c>0)
        dn=(a[None,:,1]>t[:,None,1])&(b[None,:,1]<=t[:,None,1])&(c<0)
        out.extend((up.sum(axis=1)-dn.sum(axis=1)).tolist())
    return np.array(out,dtype=int)
def windall(polys,pts):
    t=np.zeros(len(pts),dtype=int)
    for p in polys:t+=winding(p,pts)
    return t
def dist(p,pt):
    a=p;b=np.roll(p,-1,axis=0);r=b-a
    t=np.sum((np.array(pt)-a)*r,axis=1)/np.maximum(np.sum(r*r,axis=1),1e-30)
    return float(np.linalg.norm(a+np.clip(t,0,1)[:,None]*r-np.array(pt),axis=1).min())
def intersections(p,q,same=False):
    """Actual strict crossings + non-adjacent contacts, no raster conversion."""
    qa=q;qb=np.roll(q,-1,axis=0);s=qb-qa
    mn=np.minimum(qa,qb);mx=np.maximum(qa,qb);hits=[]
    for i,a in enumerate(p):
        b=p[(i+1)%len(p)];r=b-a;lo=np.minimum(a,b);hi=np.maximum(a,b)
        ix=np.flatnonzero((mn[:,0]<=hi[0]+1e-10)&(mx[:,0]>=lo[0]-1e-10)&(mn[:,1]<=hi[1]+1e-10)&(mx[:,1]>=lo[1]-1e-10))
        for j in ix.tolist():
            if same and (j<=i or j==i+1 or (i==0 and j==len(p)-1)):continue
            den=float(cross(r,s[j]));v=qa[j]-a
            if abs(den)>1e-10:
                t=float(cross(v,s[j])/den);u=float(cross(v,r)/den)
                if -1e-10<=t<=1+1e-10 and -1e-10<=u<=1+1e-10:
                    typ='strict_cross' if 1e-10<t<1-1e-10 and 1e-10<u<1-1e-10 else 'endpoint_contact'
                    hits.append({'edge1':i,'edge2':j,'kind':typ,'xy':(a+t*r).tolist()})
            elif abs(float(cross(v,r)))<1e-10:
                rr=float(np.dot(r,r))
                if rr<1e-20:continue
                t0=float(np.dot(qa[j]-a,r)/rr);t1=float(np.dot(qb[j]-a,r)/rr)
                left=max(0,min(t0,t1));right=min(1,max(t0,t1))
                if left<=right+1e-10:hits.append({'edge1':i,'edge2':j,'kind':'collinear_overlap' if right-left>1e-10 else 'endpoint_contact','xy':(a+left*r).tolist()})
    return hits

groups=[];POLYS={};RGB={};loops=[]
for g in raw['groups']:
    num=g['group'];w,h=g['source_canvas_pixel'];jp=Path(g['source_JPEG'])
    assert sha(jp)==g['source_JPEG_sha256']
    guards[str(jp)]=g['source_JPEG_sha256']
    im=Image.open(jp);assert im.size==(w,h);RGB[num]=np.array(im.convert('RGB'))
    polys=[];lr=[];selfhits=[];pairhits=[]
    for k,q in enumerate(g['combined_clip_subpaths']):
        p=parse(q);polys.append(p);ar=area(p)
        assert (p[:,0]>=0).all() and (p[:,0]<=w).all() and (p[:,1]>=0).all() and (p[:,1]<=h).all()
        bbox=[float(p[:,0].min()),float(p[:,1].min()),float(p[:,0].max()),float(p[:,1].max())]
        assert abs(ar-q['signed_area_source_pixel2'])<1e-8
        assert np.allclose(bbox,q['bbox_source_pixel'],atol=1e-12)
        assert (ar>0)==(q['role']=='outer')
        sh=intersections(p,p,True);selfhits.extend([dict(ring=k,**x) for x in sh])
        lr.append({'group':num,'ring':k,'role':q['role'],'command_count':len(q['commands_pixel']),'vertex_count':len(p),'signed_area_pixel2':ar,'bbox_source_pixel':bbox,'self_strict_crossings':sum(x['kind']=='strict_cross' for x in sh),'self_contacts':len(sh)})
    for i in range(len(polys)):
        for j in range(i+1,len(polys)):
            hh=intersections(polys[i],polys[j]);pairhits.extend([dict(ring1=i,ring2=j,**x) for x in hh])
    outer=[i for i,q in enumerate(g['combined_clip_subpaths']) if q['role']=='outer']
    holes=[i for i,q in enumerate(g['combined_clip_subpaths']) if q['role']=='hole']
    containment=[]
    for i in holes:
        # Every hole vertex and edge midpoint must lie within its sole outer.
        pts=np.vstack([polys[i],(polys[i]+np.roll(polys[i],-1,axis=0))/2])
        parent=[j for j in outer if np.all(winding(polys[j],pts)!=0)]
        assert len(parent)==1,(num,i,parent)
        containment.append({'hole_ring':i,'outer_parent':parent[0],'tested_vertices_and_midpoints':len(pts)})
    POLYS[num]=polys;loops.extend(lr)
    groups.append({'group':num,'pages':g['pages'],'JPEG':str(jp),'JPEG_sha256':sha(jp),'canvas_pixel':[w,h],'rings':lr,'outer_components':len(outer),'hole_contours':len(holes),'hole_containment':containment,'self_intersections':selfhits,'pair_intersections':pairhits,'continuous_nonzero_area_pixel2':sum(area(p) for p in polys),'continuous_area_fraction':sum(area(p) for p in polys)/(w*h),'fill_rule':'nonzero','PDF_clip_operator':'W n','construction_not_used':True,'no_W_star':True,'geometry_quantization_note':g.get('coordinate_quantization'),'UNKNOWN_source_regions':g['unknown_regions']})

# JPEG identities are read independently from both immutable source/current PDF.
pdfs={};raw_source={}
for tag,path in [('source',src),('canonical',can)]:
    doc=fitz.open(path);pages=[];identities=[]
    assert len(doc)==8
    for g in raw['groups']:
        w,h=g['source_canvas_pixel'];expected=g['source_JPEG_sha256']
        found={}
        for pg in g['pages']:
            page=doc[pg-1];matching=[]
            for ent in page.get_images(full=True):
                xr,sm,width,height=ent[:4]
                if width!=w or height!=h:continue
                img=doc.extract_image(xr);actual=hashlib.sha256(img['image']).hexdigest()
                if actual!=expected:continue
                ids=page.get_image_info(xrefs=True)
                placements=[{k:v for k,v in x.items() if k not in ('digest',)} for x in ids if x['xref']==xr]
                matching.append({'page':pg,'group':g['group'],'xref':xr,'resource':ent[7],'SMask_xref':sm,'raw_JPEG_sha256':actual,'image_dictionary':doc.xref_object(xr),'placements':placements})
                if tag=='source':raw_source[g['group']]=img['image']
                if sm:
                    m=doc.extract_image(sm);mi=Image.open(io.BytesIO(m['image']));a=np.array(mi)
                    matching[-1]['SMask_readback']={'size':list(mi.size),'min':int(a.min()),'max':int(a.max()),'all255':bool(np.all(a==255)),'pixel_count':int(a.size),'decoded_stream_sha256':hashlib.sha256(doc.xref_stream(sm)).hexdigest(),'extract_bytes_sha256':hashlib.sha256(m['image']).hexdigest()}
            assert len(matching)==1,(tag,pg,matching)
            pages.extend(matching)
        identities.append({'group':g['group'],'JPEG_sha256':expected,'pages':g['pages']})
    pdfs[tag]={'path':str(path),'sha256':sha(path),'pages':pages,'identities':identities,'page_count':len(doc)}
    doc.close()
for a,b in zip(pdfs['source']['pages'],pdfs['canonical']['pages']):
    assert a['page']==b['page'] and a['group']==b['group']
    assert a['raw_JPEG_sha256']==b['raw_JPEG_sha256']
    assert [(x['bbox'],x['transform'],x['width'],x['height']) for x in a['placements']]==[(x['bbox'],x['transform'],x['width'],x['height']) for x in b['placements']]

# Witness schema is explicitly reported before selecting coordinate/expected fields.
print('LANDMARK_SCHEMA',json.dumps(raw['source_landmarks'][:2],ensure_ascii=False),flush=True)
print('FOOT_SCHEMA',json.dumps(raw['groups'][0]['clear_foot_background_tests'],ensure_ascii=False),flush=True)
WIT=[]
for g in raw['groups']:
    n=g['group']
    for q in [x for x in raw['source_landmarks'] if x['group']==n]+g['clear_foot_background_tests']:
        coord=q.get('source_xy',q.get('pixel',q.get('point_source_pixel',q.get('point_pixel',q.get('point',q.get('xy'))))))
        if coord is None:
            coord=q.get('source_pixel')
        assert coord is not None,q
        exp=q.get('meaning','background' if q in g['clear_foot_background_tests'] else None)
        x,y=coord;wi=int(windall(POLYS[n],[coord])[0]);cent=int(windall(POLYS[n],[[x+.5,y+.5]])[0]);md=min(dist(p,coord) for p in POLYS[n])
        passed=(wi!=0)==(exp=='product')
        WIT.append({'group':n,'source_record':q,'point_source_pixel':coord,'nonzero_winding':wi,'pixel_center_winding':cent,'visible':wi!=0,'distance_to_clipping_boundary_pixel':md,'source_RGB':RGB[n][int(y),int(x)].tolist(),'expected_source_label':exp,'result':'ĐẠT' if passed else 'CHƯA ĐẠT'})

ROIS=[(1,'chữ 7.5KW',[184,18,233,35]),(1,'nước xa trái',[0,194,39,239]),(2,'chữ 11KW',[58,82,224,130]),(2,'nước xa trái',[0,891,163,1037]),(3,'nước xa trái',[0,650,154,800])]
roiout=[]
for num,label,bb in ROIS:
    x0,y0,x1,y1=bb;yy,xx=np.mgrid[y0:y1,x0:x1];pts=np.column_stack([xx.ravel()+.5,yy.ravel()+.5]);ww=windall(POLYS[num],pts)
    rect=np.array([[x0,y0],[x1,y0],[x1,y1],[x0,y1]],dtype=float)
    boundaries=[];insideverts=0
    for k,p in enumerate(POLYS[num]):
        boundaries.extend([dict(ring=k,**q) for q in intersections(p,rect)])
        insideverts+=int(np.sum((p[:,0]>x0)&(p[:,0]<x1)&(p[:,1]>y0)&(p[:,1]<y1)))
    center=(x0+x1)/2,(y0+y1)/2;cw=int(windall(POLYS[num],[center])[0])
    roiout.append({'group':num,'label':label,'rectangle_source_pixel':bb,'tested_pixel_centers':len(pts),'visible_pixel_centers':int(np.sum(ww!=0)),'boundary_rect_intersections':boundaries,'clipping_vertices_strictly_inside':insideverts,'center_winding':cw,'whole_continuous_rectangle_excluded':not boundaries and insideverts==0 and cw==0,'result':'ĐẠT' if np.all(ww==0) and not boundaries and insideverts==0 and cw==0 else 'CHƯA ĐẠT'})

manifest=json.loads((RAM/'per_wc_continue_photo_union_v4_manifest.json').read_text(encoding='utf8'))
print('MANIFEST_SCHEMA',json.dumps(manifest['files'][:1],ensure_ascii=False),flush=True)
print('WITNESS_COUNT',len(WIT),'ROIs',[(x['label'],x['visible_pixel_centers'],len(x['boundary_rect_intersections'])) for x in roiout],flush=True)
result={'purpose':'Nghiệm thu độc lập chỉ đọc đúng V4B; chưa nghiệm thu toàn ảnh hay PDF ảnh','input':str(INP),'input_sha256':sha(INP),'source_PDF':pdfs,'groups':groups,'witnesses27':WIT,'excluded_regions5':roiout,'RAM_manifest_read':{'path':str(RAM/'per_wc_continue_photo_union_v4_manifest.json'),'sha256':sha(RAM/'per_wc_continue_photo_union_v4_manifest.json'),'files':manifest['files'],'PDF_file_written_on_disk':manifest['PDF_file_written_on_disk']},'raster_images_created':False,'PDF_written':False,'TIEN_DO_written':False,'source_RGB_modified':False,'construction_paths_used':False,'W_star_used':False,'whole_product_structure':'CHƯA THỂ XÁC MINH; 27 điểm và 5 vùng chỉ là phạm vi hữu hạn','RAM_appearance':'CHƯA ĐẠT: nhìn trực tiếp ảnh ghép 150/600 còn mực nước xanh ngoài sản phẩm; cần hồ sơ tọa độ riêng'}
for p,h in guards.items():assert sha(p)==h
fp=OUT/'g01_01_NGHIEM THU DOC LAP V4B NGUON VA GEOMETRY.json'
Path(fresh(fp)).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',str(fp),'SHA',sha(fp),flush=True)
print('LOOPS',[(g['group'],g['outer_components'],g['hole_contours'],g['continuous_nonzero_area_pixel2'],len(g['self_intersections']),len(g['pair_intersections'])) for g in groups],flush=True)
