"""Pure contour fit from a supplied source-observed mask. No task/file work."""
import numpy as np
import cv2
from scipy.spatial import cKDTree
from g04_source_glyph_source_edge_math import sample_path,smooth_loop
from g04_source_glyph_vector_math import rounded_loop
from g04_source_glyph_core_math import signed_area,topology,hole_centres

def source_mask_contours(mask,pad=8,up=8,curvy=True,epsilon=2.5,radius=1.25,expected=(1,0)):
    assert topology(mask)==expected
    fine=cv2.resize(np.asarray(mask,np.uint8),(mask.shape[1]*up,mask.shape[0]*up),interpolation=cv2.INTER_NEAREST)
    contours,tree=cv2.findContours(fine,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
    loops=[];area=0
    for j,c in enumerate(contours):
        if curvy:
            loop=smooth_loop(c,up=up,pad=pad,curvy=True)
        else:
            path=rounded_loop(c,up=up,epsilon=epsilon,radius=radius)
            path=[(op,[[x-pad,y-pad] for x,y in ps]) for op,ps in path]
            raw=c[:,0,:]/up+.5/up-pad
            fitted=sample_path(path,64)
            distance=max(float(cKDTree(raw).query(fitted)[0].max()),float(cKDTree(fitted).query(raw)[0].max()))
            loop=dict(path=path,max_contour_fit_error_px600=distance,cubic_segments=sum(op=='c' for op,_ in path),
                simplification_px600=epsilon,corner_radius_px600=radius)
        assert loop is not None
        assert loop['max_contour_fit_error_px600']<=4
        depth=0;p=tree[0,j,3]
        while p>=0:depth+=1;p=tree[0,p,3]
        ar=abs(signed_area(loop['path']));area+=ar*(-1 if depth%2 else 1)
        loop.update(tree_depth=depth,foreground=depth%2==0,area_px=ar);loops.append(loop)
    actual=np.zeros_like(fine)
    polys=[np.rint((sample_path(z['path'],64)+pad)*up).astype('int32') for z in loops]
    cv2.fillPoly(actual,polys,1)
    assert topology(actual)==expected,(topology(actual),expected)
    if expected[1]:
        ref=hole_centres(mask);cent=hole_centres(actual)/up
        assert np.max(np.linalg.norm(ref[:,None,:]-cent[None,:,:],axis=2).min(1))<=4
    return loops,area,actual
