"""Kiểm kê thật file nguồn và bản giao; chỉ đọc PDF, không sửa tài liệu."""
from catwork import start,fresh
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
S,D,N=start()
import pymupdf as fitz
from catfix.verify import structure_check
baseline=next(z['hashes_before'] for z in json.loads(Path(S.report('BAO CAO BUOC0.json')).read_text(encoding='utf8')) if 'hashes_before' in z)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
sourcechecks=[];outputs=[]
def semantic(xml):
 if not xml:return None
 def tree(e):return (e.tag,tuple(sorted(e.attrib.items())),(e.text or '').strip(),tuple(tree(x) for x in e))
 return tree(ET.fromstring(xml))
for path,expected in baseline.items():
 p=Path(path);actual=sha(path);sourcechecks.append(dict(file=path,expected=expected,actual=actual,unchanged=actual==expected));assert actual==expected,path
 if p.suffix.lower() not in ('.pdf','.xlsx'):continue
 assert S.src(p.name)==path
 rename=p.name.replace('ngnag','ngang') if 'ngnag' in p.name else None
 dst=S.dst(p.name,rename=rename);r=dict(source=path,destination=dst,exists=Path(dst).is_file())
 if not r['exists']:r['status']='ĐANG XỬ LÝ';outputs.append(r);continue
 r['sha256']=sha(dst);r['bytes']=Path(dst).stat().st_size
 if p.suffix.lower()=='.pdf':
  a=fitz.open(path);b=fitz.open(dst)
  r['pages_source']=len(a);r['pages_output']=len(b);r['page_sizes_identical']=[tuple(x.rect) for x in a]==[tuple(x.rect) for x in b]
  r['info_identical']=a.metadata==b.metadata;r['xmp_raw_identical']=a.get_xml_metadata()==b.get_xml_metadata();r['xmp_values_identical']=semantic(a.get_xml_metadata())==semantic(b.get_xml_metadata());r['bookmarks_identical']=a.get_toc()==b.get_toc();r['links_identical']=[x.get_links() for x in a]==[x.get_links() for x in b]
  r['structure']=structure_check(path,dst)
  r['status']='ĐẠT phần bảo toàn' if all(r[k] for k in ('page_sizes_identical','info_identical','xmp_values_identical','bookmarks_identical','links_identical')) and r['structure']['ok'] else 'CHƯA ĐẠT phần bảo toàn'
  a.close();b.close()
 else:r['status']='CÓ FILE; nội dung và bản in nghiệm thu riêng G18'
 outputs.append(r);print(p.name,r['status'],'XML raw',r.get('xmp_raw_identical'),flush=True)
extra=S.result('Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf',sub='G02 (gồm cả G01)')
report=dict(source_count=len(sourcechecks),source_pass=sum(x['unchanged'] for x in sourcechecks),catalogue_count=len(outputs),existing_outputs=sum(x['exists'] for x in outputs),source_checks=sourcechecks,outputs=outputs,G02_additional=dict(file=extra,sha256=sha(extra)),scope='Đây là kiểm bảo toàn/hiện diện, không phải nghiệm thu nội dung toàn bộ nhóm. Các lỗi/việc chưa đủ căn cứ vẫn theo báo cáo nhóm.')
Path(fresh(S.report('KIEM KE DOC LAP CAC FILE.json'))).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('NGUỒN',report['source_pass'],'/',len(sourcechecks),'BẢN RA',report['existing_outputs'],'/',len(outputs),'thêmG02',flush=True)
