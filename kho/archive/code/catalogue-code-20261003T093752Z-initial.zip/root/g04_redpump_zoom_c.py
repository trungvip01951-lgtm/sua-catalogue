from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from PIL import Image
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
for family in ['4SL6','4SL8']:
 im=Image.open(root/f'BANG NGUON 06 {family}.png').convert('RGB');w,h=im.size;p=im.crop((int(w*.45),int(h*.80),w,h));p=p.resize((p.width*2,p.height*2),Image.Resampling.NEAREST);p.save(fresh(root/f'SOI {family} BA HANG CUOI.png'))
