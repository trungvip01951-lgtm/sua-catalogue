"""Pure post-save QA entry point; nothing runs on import and no PDF writer.

Run only after ROOT has authorized one fresh CATFIX M1 save. Passing technical
checks never declares whole graphic acceptance or promotes the canonical PDF.
"""
from pathlib import Path
import json,hashlib,copy
import numpy as np
import pymupdf as fitz,pikepdf
from catfix.vector import Editor,VPage
from catfix.raster import Raster
from catfix.cs import parse
from catfix import verify
from g04_perotac_whole_pdf_tools46 import sha,pixel_at
from g04_perotac_whole_actual_read50 import render_document,outside_read,metadata,image_resources,actual_paths_and_ink

NAME='Perotac bơm giếng SA_compressed (bản mới).pdf'

def raw_info(pdf):
    out={}
    for key,value in pdf.docinfo.items():
        try:out[str(key)]=bytes(value).hex()
        except (TypeError,ValueError):out[str(key)]=str(value)
    return out

def raw_xmp(pdf):
    obj=pdf.Root.get('/Metadata')
    return hashlib.sha256(obj.read_raw_bytes()).hexdigest() if isinstance(obj,pikepdf.Stream) else str(obj)

def post_save(S,path,expected,ram,output_dir):
    """Read a genuinely saved sample. Only fresh evidence files are written."""
    from catwork import fresh
    from PIL import Image,ImageDraw
    sample=Path(path).resolve();root=Path(output_dir).resolve()
    assert sample.is_file() and sample.suffix.lower()=='.pdf'
    assert sample!=Path(S.src(NAME)).resolve() and sample!=Path(S.result(NAME)).resolve()
    assert sha(S.src(NAME))==expected['source_sha256'] and sha(S.result(NAME))==expected['canonical_sha256']
    beforeE=Editor(S.result(NAME),backend='pikepdf');beforeR=Raster(beforeE)
    im=max(beforeR.images(7),key=lambda z:z.W*z.H);assert str(im.name)=='X7';cv=beforeR.canvas(im)
    roi=expected['ROI_page_pt']
    structure=verify.structure_check(S.result(NAME),str(sample))
    outside_catfix=verify.outside_pixels(S.result(NAME),str(sample),allowed={8:[roi]},pages=range(11),dpi=200,thr=0,min_size=0,pad=0,merge=0)
    source_reads=[];tiles=[]
    with fitz.open(S.result(NAME)) as before,fitz.open(S.src(NAME)) as source,fitz.open(sample) as actual:
        content=actual[7].read_contents();content_sha=hashlib.sha256(content).hexdigest()
        ar600,map600=render_document(actual,7,600,roi);ar150,_=render_document(actual,7,150)
        Image.fromarray(ar600).save(fresh(root/'M1 PEROTAC P08 ACTUAL PDF600 CHUA NGHIEM THU.png'))
        Image.fromarray(ar150).save(fresh(root/'M1 PEROTAC P08 ACTUAL TOAN TRANG150 CHUA NGHIEM THU.png'))
        checks=actual_paths_and_ink(content,expected,ram,cv,ar600,map600)
        checks['actual_image_render_is_serialized_memory_not_saved_file']=False
        checks['PDF_file_readback_NOT_RUN']=False
        checks['actual_image_render_is_saved_PDF']=True
        outside_direct=outside_read(before,actual,roi,dpi=200)
        bmeta=metadata(before);ameta=metadata(actual);meta_equal={k:bmeta[k]==ameta[k] for k in bmeta}
        P=VPage(parse(content));ctms=[]
        for row in expected['old_Do_complement_clips']:
            hits=[i for i in P.images if i['name']==row['name'] and np.max(abs(i['ctm']-np.asarray(row['CTM'])))<1e-9]
            ctms.append(dict(name=row['name'],same_original_CTM_matches=len(hits),kept=len(hits)==1))
        for island in expected['source_literal_islands_all']:
            b=island['source_page_box'];a,ma=render_document(source,7,600,b);z,mz=render_document(actual,7,600,b)
            assert a.shape==z.shape and ma==mz
            change=np.any(a!=z,axis=2);dark=a.min(2)<235;yy,xx=np.indices(change.shape)
            p0=pixel_at(b[:2],mz);p1=pixel_at(b[2:],mz);lo=np.minimum(p0,p1);hi=np.maximum(p0,p1)
            points=np.stack([xx+.5,yy+.5],axis=-1);inside=((points>=lo+2)&(points<=hi-2)).all(2)
            source_reads.append(dict(key=island['key'],literal_source_read=island['literal_source_read'],
                native_source_box=island['source_native_box'],all_crop_pixels_changed=int(change.sum()),
                source_dark_all_crop_changed=int((change&dark).sum()),interior2actual600_pixels_changed=int((change&inside).sum()),
                source_dark_interior2actual600_pixels_changed=int((change&inside&dark).sum()),
                clip_perimeter_aliasing_must_be_read_separately=True,original_font_program_and_exact_original_outline_UNKNOWN=True))
            tile=Image.new('RGB',(max(1200,a.shape[1]*4+80),max(220,a.shape[0]*2+60)),'white');dr=ImageDraw.Draw(tile)
            dr.text((10,5),island['key']+' SOURCE600 / SAVED M1 PDF600',fill='black')
            aa=Image.fromarray(a).resize((a.shape[1]*2,a.shape[0]*2),Image.Resampling.NEAREST);zz=Image.fromarray(z).resize(aa.size,Image.Resampling.NEAREST)
            tile.paste(aa,(0,35));tile.paste(zz,(aa.width+40,35));tiles.append(tile)
    with pikepdf.open(S.result(NAME)) as before,pikepdf.open(sample) as actual:
        raw_images_equal=image_resources(before)==image_resources(actual)
        info_equal=raw_info(before)==raw_info(actual);xmp_equal=raw_xmp(before)==raw_xmp(actual)
        other_pages_equal=all(before.pages[i].Contents.read_bytes()==actual.pages[i].Contents.read_bytes() for i in range(11) if i!=7)
        gs=actual.pages[7].Resources.ExtGState['/'+expected['new_normal_opaque_gs']]
        opaque={key:str(gs.get('/'+key)) for key in ['CA','ca','BM','SMask']}
    atlas=Image.new('RGB',(max(t.width for t in tiles),sum(t.height+10 for t in tiles)),'white');y=0
    for tile in tiles:atlas.paste(tile,(0,y));y+=tile.height+10
    atlas.save(fresh(root/'M1 NGUYEN9 CUM NGUON VA SAVED PDF600.png'))
    technical_ok=bool(structure['ok'] and not outside_catfix and all(r['outside_changed_pixels']==0 for r in outside_direct)
        and all(meta_equal.values()) and info_equal and xmp_equal and raw_images_equal and other_pages_equal
        and all(r['kept'] for r in ctms) and checks['all104_path_and_visible_points_match'] and checks['all_named_new_objects_match']
        and content_sha==expected['prepared_content_sha256'] and opaque=={'CA':'1','ca':'1','BM':'/Normal','SMask':'/None'}
        and all(r['interior2actual600_pixels_changed']==0 for r in source_reads))
    record=dict(stage='SAVED M1 PDF TECHNICAL READBACK; ROOT GRAPHIC ACCEPTANCE PENDING',
        sample_path=str(sample),sample_sha256=sha(sample),source_sha256=expected['source_sha256'],canonical_sha256=expected['canonical_sha256'],
        saved_content_SHA256=content_sha,saved_content_matches_locked_RAM=content_sha==expected['prepared_content_sha256'],
        catfix_structure_check=structure,catfix_outside200_thr0_min0_pad0=outside_catfix,independent_outside200_all11=outside_direct,
        metadata_all11_equal=meta_equal,current_Info_value_bytes_equal=info_equal,current_XMP_raw_bytes_equal=xmp_equal,
        all_current_images_and_SMask_raw_values_equal=raw_images_equal,all_old_Do_CTMs_kept=ctms,other10page_contents_bytes_equal=other_pages_equal,
        new_opaque_gs=opaque,original9_source_island_reads=source_reads,actual_path_and_ink=checks,
        technical_checks_pass=technical_ok,all_graphic_or_font_acceptance_NOT_CLAIMED=True,source_eta11_head_centers_UNKNOWN=True,source_eta_numeric_values_UNKNOWN=True,
        canonical_not_promoted=True,PDF_writer_count_this_execution=1,no_progress_written=True)
    Path(fresh(root/'M1 ACTUAL SAVED PDF QA DE ROOT DOC.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
    assert sha(S.src(NAME))==expected['source_sha256'] and sha(S.result(NAME))==expected['canonical_sha256']
    beforeE.close();return record
