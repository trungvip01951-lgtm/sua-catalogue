"""Source glyph readability study only, no catalogue or PDF sample creation."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
import sys
from scipy.ndimage import label,binary_dilation
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
source=plan['method']['source'];current=plan['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest()
before=[sha(source),sha(current)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(source,backend='fitz');R=Raster(E);cv=R.render_canvas(7,(132.,346.5,164.,500.5),dpi=600);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);spread=a.max(2)-a.min(2)
dark=(g<105)&(spread<30)
rows=(dark.sum(axis=1)>2);groups=[]
for y in np.flatnonzero(rows):
 if not groups or y-groups[-1][-1]>3:groups.append([])
 groups[-1].append(int(y))
second='--lan2' in sys.argv
raw_groups=list(groups)
if second:groups=[z for z in groups if dark[z].sum()>=100]
print('source black glyph rows',[(z[0],z[-1],int(dark[z].sum())) for z in groups],flush=True)
if len(groups)!=13:
 out=dict(status='CHƯA THỂ: tự tách hàng mực không đủ13nhãn; cần tọa độ nhãn bằng mắt. Không ép đếm.',source_SHA256=before[0],current_SHA256=before[1],raw_black_row_groups=groups,PDF_written=False)
else:
 names=['4SL16/25','4SL16/23','4SL16/20','4SL16/18','4SL16/16','4SL16/14','4SL16/12','4SL16/11','4SL16/9','4SL16/8','4SL16/6','4SL16/5','4SL16/4']
 # Every name below was read from source/current full words by eye already.
 # Only source dark pixels within the manual observed name-row band may seed alpha.
 picture=Image.new('RGB',(980,13*88),(255,255,255));dr=ImageDraw.Draw(picture);records=[]
 for index,(name,ys) in enumerate(zip(names,groups)):
  y0=max(0,ys[0]-8);y1=min(len(g),ys[-1]+9);patch=a[y0:y1]
  core=dark[y0:y1]
  candidates=(patch@np.array([.299,.587,.114])<205)&((patch.max(2)-patch.min(2))<19)
  connected,n=label(candidates);keep=np.zeros_like(candidates)
  for k in range(1,n+1):
   mm=connected==k
   if (mm&core).any():keep|=mm
  # Grow only within native glyph softness; chromatic curve and grey grid excluded.
  alpha=(1-patch.mean(2)/255)*keep
  black=np.repeat((255*(1-alpha)).round().clip(0,255).astype('uint8')[:,:,None],3,axis=2)
  crop=Image.fromarray(patch.round().astype('uint8'));clean=Image.fromarray(black)
  dr.text((5,index*88+4),name,fill=(0,0,180));picture.paste(crop,(160,index*88+10));picture.paste(clean,(570,index*88+10))
  records.append(dict(model=name,source_render_rect=(0,y0,a.shape[1],y1),source_page_rect=[*cv.to_page(0,y1),*cv.to_page(a.shape[1],y0)],dark_core_pixels=int(core.sum()),alpha_pixels=int((alpha>0).sum()),fullword_alpha_candidate_only=True,source_font_metadata_available=False))
 photo=fresh(root/('CHU NGUON VA ALPHA THU DO DOC V2 KHONG LA MAU PDF.png' if second else 'CHU NGUON VA ALPHA THU DO DOC KHONG LA MAU PDF.png'));picture.save(photo)
 out=dict(status='NGHIÊN CỨU CHỮ NGUỒN: chỉ tách mực quan sát, cần soi đủ từng chữ/lỗ nét trước dùng. Không tạo phông mới.',source_SHA256=before[0],current_SHA256=before[1],source_rect=list(cv.rect0),source_dpi=600,records=records,raw_black_row_groups=groups,source_alpha_candidate_photo=photo,PDF_written=False,shape_polishing_applied=False,new_font_used=False,limitation='Ảnh source150dpi nén; alpha600 giữ nguồn mờ. Có thể dựng nét-outline từ contour chính glyph sau khóa đủ chữ, nhưng chưa làm và không được thay font. Nếu thiếu mực phảiCHƯA THỂ, khôngbịa nét.')
out['raw_unfiltered_groups']=raw_groups
out['glyph_study_round']=2 if second else 1
Path(fresh(root/('CHU NGUON ALPHA THU DO DOC V2.json' if second else 'CHU NGUON ALPHA THU DO DOC.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(source),sha(current)]
print(out['status'],flush=True)
