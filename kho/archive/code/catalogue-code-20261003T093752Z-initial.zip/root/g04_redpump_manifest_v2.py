"""Resolve three values by ROOT direct-source read, leaving V1 history intact."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,datetime
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));path=root/'DANH MUC BANG NGUON 196 DONG V1.json'
out=json.loads(path.read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert [sha(out['source']),sha(out['current'])]==[out['source_SHA256'],out['current_SHA256']]
fixes={('4SL3/15',3.0):76,('4SL16/4',15.0):15,('4SL16/12',6.0):66};records=[]
for row in out['rows']:
 for i,q in enumerate(row['Q']):
  if (row['model'],q) in fixes:
   assert row['H'][i] is None
   row['H'][i]=fixes[(row['model'],q)]
   row['ambiguous_cells']=[]
   row['table_read']+='; ô trước UNKNOWN đã ROOT đọc trực tiếp ảnh nguyên nguồn144dpi và context V2 có cùng hàng tên/đầu cột.'
   row['independent_source_read']=dict(Q=q,H_source=row['H'][i],reader='ROOT',evidence_directory=str(root/'O CHUA DOC CHAC V2'),approval_message='ROOT đọc nguyên nguồn trang5 và cả3 context V2: 76,15,66; căn cứ toàn hàng và đầu cột, không suy số theo tầng/công suất.',curve_acceptance='CHƯA ĐO – nhận dạng ô không phải nghiệm thu đường')
   records.append(row['independent_source_read']|dict(model=row['model']))
for cell in out['source_cells']:
 if (cell['model'],cell['Q']) in fixes:
  cell['H_source']=fixes[(cell['model'],cell['Q'])];cell['status']='ĐÃ ĐỌC NGUỒN VÀ ROOT ĐỌC ĐỘC LẬP – chưa nghiệm thu đường'
assert len(records)==3 and all(c['H_source'] is not None for c in out['source_cells'])
out.update(time=datetime.datetime.now().astimezone().isoformat(),version=2,previous_manifest=str(path),previous_manifest_SHA256=sha(path),H_cells_read=1931,unknown_cells=[],independent_resolved_cells=records,excluded_context_directory=str(root/'O CHUA DOC CHAC'),excluded_context_reason='Sai chiều y khi đổi hộp ảnh thành PDF, không dùng định vị ô hoặc đường',status='CHƯA XONG:1931ô bảng đã đọc, riêng16mốc của2đường đã ĐẠT;194đường khác chưa nghiệm thu đủ số.')
Path(fresh(root/'DANH MUC BANG NGUON 196 DONG V2.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert [sha(out['source']),sha(out['current'])]==[out['source_SHA256'],out['current_SHA256']]
print('Manifest V2:196 models,1931 source values read;3 ROOT independently resolved; new curves not accepted',flush=True)
