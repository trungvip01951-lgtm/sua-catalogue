"""Read observed SL ink using previously visually locked labels, local ticks.
No H table enters seed/path tracing. Does not write a PDF or shared progress.
"""
from catwork import start, fresh
S,D,N=start()
from pathlib import Path
from datetime import datetime
import hashlib, json, sys, collections
import numpy as np
from PIL import Image, ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import color_runs, follow_observed_ink

root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
family=sys.argv[1] if len(sys.argv)>1 else '2.5SL1.5'
assert family!='4SL16', 'p8 already measured; not this task'
slug=family.replace('.','_')
out=root/f'DOC MUC LOCAL NGOAI P8 {slug} LAN1'
read=lambda n:json.loads((root/n).read_text(encoding='utf8'))
manifest=read('DANH MUC BANG NGUON 196 DONG V2.json')
axes=read('17 TRUC DOC NGUON RIENG KHOA V1.json')
ids=read('DINH DANH NHAN VA SEED DOC TRUC TIEP V1.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(manifest['source']),sha(manifest['current'])]
assert before==[manifest['source_SHA256'],manifest['current_SHA256']]
a=next(z for z in axes['records'] if z['family']==family)
group=[z for z in ids['records'] if z['family']==family and z['model_locked'] is not None]
assert group and a['page']!=8
source=Editor(manifest['source'],backend='fitz')
current=Editor(manifest['current'],backend='fitz')
RS,RC=Raster(source),Raster(current)
rect=group[0]['source_rect']
cv=RS.render_canvas(a['page']-1,rect,dpi=300)
ccv=RC.render_canvas(a['page']-1,rect,dpi=300)
assert cv.orig.shape==ccv.orig.shape
assert list(cv.rect0)==list(ccv.rect0), 'Actual source/current crop pixel origins differ'
ar=cv.orig.astype(float); gray=ar@np.array([.299,.587,.114])
mask=(ar[:,:,1]-ar[:,:,0]>4)&(ar[:,:,2]-ar[:,:,0]>6)&(gray<235)
weights=255-gray
cache={}
def col(u):
    if u not in cache:
        cache[u]=[z for z in color_runs(mask,weights,u,4,len(gray)-5,max_width=18) if z['strength']>=60]
    return cache[u]
Qv=np.array(a['Q_printed_values'],float);Qx=np.array(a['Q_printed_tick_page_x'],float)
Hv=np.array(a['H_printed_values_used'],float);Hy=np.array(a['H_printed_grid_page_y'],float)
order=np.argsort(Hy); Hy,Hv=Hy[order],Hv[order]
def local_q(x):
    if x<Qx.min()-1e-8 or x>Qx.max()+1e-8:return None
    return float(np.interp(x,Qx,Qv))
def local_h(y):
    if y<Hy.min()-1e-8 or y>Hy.max()+1e-8:return None
    return float(np.interp(y,Hy,Hv))
def value_to_x(Q):
    if Q<Qv.min() or Q>Qv.max():return None
    return float(np.interp(Q,Qv,Qx))
records=[]; proof=Image.fromarray(cv.orig); pd=ImageDraw.Draw(proof)
native_x,native_y=a['native_pixel_pt']
for iz,z in enumerate(group):
    px,py=z['source_seed']['page'];u,v=cv.to_px(px,py);u=int(round(u))
    candidates=[r for r in col(u) if abs(r['v']-v)<3]
    if len(candidates)!=1:
        records.append(dict(model=z['model_locked'],status='CHƯA THỂ',reason='Seed khóa cũ không còn một run chắc trong crop render này.',candidate_count=len(candidates)))
        continue
    seed=dict(u=u,**candidates[0])
    left,il=follow_observed_ink(col,seed,4,-1,radius=8,max_gap=28,history=15,ambiguity_margin=3)
    right,ir=follow_observed_ink(col,seed,cv.orig.shape[1]-5,1,radius=8,max_gap=28,history=15,ambiguity_margin=3)
    pts=sorted(left[1:]+right,key=lambda p:p['u'])
    uv=np.array([[p['u'],p['v']] for p in pts],float)
    xy=np.array([cv.to_page(*p) for p in uv],float)
    issues=il+ir
    issue_x=[float(cv.to_page(p['u'],0)[0]) for p in issues]
    row=next(t for t in manifest['rows'] if t['model']==z['model_locked'])
    numeric=[]
    for Q,H in zip(row['Q'],row['H']):
        xp=value_to_x(Q)
        rec=dict(model=z['model_locked'],Q=Q,H_table=H,limit=max(1,float(H)*.02),
                 H_curve=None,status='CHƯA THỂ',source_current_tube_changed_pixels=None)
        if xp is None:
            rec['reason']='Q ngoài miền vạch thực có số đã khóa; chưa đọc vạch phụ, không dùng fit toàn trục ngoại suy.'
            numeric.append(rec);continue
        if xp<xy[:,0].min() or xp>xy[:,0].max():
            rec['reason']='Không có mực bao cả hai phía tại vạch Q; không ngoại suy đầu/cuối.'
            numeric.append(rec);continue
        i=int(np.searchsorted(xy[:,0],xp));i0=max(0,i-1);i1=min(len(xy)-1,i)
        yp=float(np.interp(xp,xy[:,0],xy[:,1]));Hp=local_h(yp)
        if Hp is None:
            rec['reason']='H ngoài miền vạch đã khóa; không ngoại suy.'
            numeric.append(rec);continue
        bracket=xy[[i0,i1]]
        slope=abs(float((bracket[1,1]-bracket[0,1])/(bracket[1,0]-bracket[0,0]))) if i0!=i1 else 0
        hy_idx=min(max(int(np.searchsorted(Hy,yp)),1),len(Hy)-1)
        h_per_pt=abs(float((Hv[hy_idx]-Hv[hy_idx-1])/(Hy[hy_idx]-Hy[hy_idx-1])))
        width_pt=max(pts[i0]['width'],pts[i1]['width'])*72/300
        gap_pt=float(bracket[1,0]-bracket[0,0])
        # Source JPEG native pixel, actual-ink width, axis-center/sample error;
        # missing-dash chord error is bounded conservatively by half its H change.
        u_h=h_per_pt*(native_y + .5*width_pt + native_x*slope + .5*gap_pt*slope)
        error=Hp-H;lim=rec['limit']
        unknown_branch=any(min(px,xp)-native_x<=t<=max(px,xp)+native_x for t in issue_x)
        xx,yy=cv.to_px(xp,yp);xx,yy=int(round(xx)),int(round(yy))
        r=3
        A=cv.orig[max(0,yy-r):yy+r+1,max(0,xx-r):xx+r+1]
        B=ccv.orig[max(0,yy-r):yy+r+1,max(0,xx-r):xx+r+1]
        changed=int(np.any(A!=B,axis=2).sum())
        status='CHƯA THỂ' if unknown_branch or changed else 'ỨNG VIÊN CHƯA ĐẠT' if abs(error)-u_h>lim else 'ỨNG VIÊN ĐẠT' if abs(error)+u_h<=lim else 'CHƯA THỂ'
        rec.update(H_curve=Hp,error=error,uncertainty_H=u_h,local_page_point=[xp,yp],
             local_H_bracket=dict(values=Hv[hy_idx-1:hy_idx+1].tolist(),positions=Hy[hy_idx-1:hy_idx+1].tolist()),
             observed_ink_bracket=bracket.tolist(),source_current_tube_changed_pixels=changed,
             branch_before_this_point=unknown_branch,status=status,
             reason='Cần soi trace thực trước chốt; mực đã bám độc lập, H bảng chỉ so sau tracing.' if not unknown_branch else 'Có nhánh cạnh tranh giữa nhãn khóa và mốc; chưa khóa tiếp tuyến danh tính qua chỗ giao.')
        numeric.append(rec)
        if Hp is not None:
            pd.ellipse((xx-3,yy-3,xx+3,yy+3),outline=(255,0,0),width=1)
    color=[(220,0,0),(0,100,220),(220,0,180),(0,130,0),(240,130,0)][iz%5]
    for u0,v0 in uv[::4]:pd.ellipse((u0-1,v0-1,u0+1,v0+1),fill=color)
    model_proof=Image.fromarray(cv.orig); md=ImageDraw.Draw(model_proof)
    for u0,v0 in uv[::3]:md.ellipse((u0-1,v0-1,u0+1,v0+1),fill=(255,0,0))
    name=z['model_locked'].replace('/','_').replace('.','_')
    model_image=Path(fresh(out/f'{name} TRACE QUAN SAT CHUA CHOT.png'))
    model_proof.save(model_image)
    records.append(dict(model=z['model_locked'],page=a['page'],source_seed=seed,
        seed_basis=z['identity_basis'],name_source_current_photo=z['current_names_photo'],
        trace_inputs='Nguồn Redpump riêng, seed từ nối nhãn hiện hành và nét đã soi; không truyền Q/H bảng cho follow_observed_ink.',
        trace_pts=pts,trace_xy=xy.tolist(),branch_issues=issues,
        observed_page_x_range=[float(xy[:,0].min()),float(xy[:,0].max())],
        source_current_pixel_appearance_verified_only_at_tubes=True,
        numeric_points=numeric,source_table_photo=row['table_photo'],
        photo=str(model_image),status='ỨNG VIÊN CHƯA CHỐT; cần soi mực/nhánh/đầu cuối',
        num_status_counts=dict(collections.Counter(p['status'] for p in numeric))))
    print(z['model_locked'], 'observed',len(pts),'branches',len(issues),
          [(p['Q'],round(p['H_curve'],3) if p['H_curve'] is not None else None,round(p.get('uncertainty_H',0),3),p['status']) for p in numeric],flush=True)
photo=Path(fresh(out/'TOAN NHOM TRACE QUAN SAT CHUA CHOT.png'));proof.save(photo)
raw=Path(fresh(out/'DO MUC LOCAL DOC NGUON VA BAN GIAO CHUA CHOT.json'))
payload=dict(time=datetime.now().isoformat(),family=family,page=a['page'],
    source=manifest['source'],source_SHA256=before[0],current=manifest['current'],current_SHA256=before[1],
    source_axes_file=str(root/'17 TRUC DOC NGUON RIENG KHOA V1.json'),
    local_Q_values=Qv.tolist(),local_Q_positions=Qx.tolist(),
    local_H_values=Hv.tolist(),local_H_positions=Hy.tolist(),
    source_crop_rect=list(cv.rect0),source_crop_dpi=300,source_native_pixel_pt=a['native_pixel_pt'],
    records=records,photo=str(photo),unknown_identity_skipped=[z['table_model_candidate'] for z in ids['records'] if z['family']==family and z['model_locked'] is None],
    catalogue_written=False,shared_progress_written=False,
    acceptance=False,scope='Phép bám mực nguồn readonly; trạng thái ứng viên chưa thay nghiệm thu nhìn thực từng trace.',
    rule='No H table in branch selection. Local real adjacent ticks only. Do not extrapolate absent ink/axes.')
raw.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf8')
source.close();current.close()
assert before==[sha(manifest['source']),sha(manifest['current'])]
print('SAVED',str(raw),flush=True)
