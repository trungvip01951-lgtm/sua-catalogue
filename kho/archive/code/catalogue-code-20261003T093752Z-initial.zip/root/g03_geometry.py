from catwork import start, fresh
S,D,N=start()
from catfix.vector import Editor
from pathlib import Path
import json
E=Editor(S.src('Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'))
out={}
for pg,oi in [(3,252),(4,276),(5,278),(6,289),(7,262),(8,265),(9,316),(10,302)]:
    P=E.page(pg-1)
    pp=P.object_pagepath(oi)
    out[pg]=dict(oi=oi,path=pp,bbox=P.objs[oi]['bbox'])
    print(pg,oi,pp,flush=True)
json.dump(out,open(fresh(Path(S.report('G03'))/'geometry.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
