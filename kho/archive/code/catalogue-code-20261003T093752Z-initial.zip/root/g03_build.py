from catwork import start, fresh, row
S,D,N=start()
from catfix import verify,charts
from catfix.otext import Match
from catfix.pdfdoc import PdfDoc
from g03_data import TABLES,RATIO_TASKS,SIMPLE,RATIO_REGIONS,CONTENTS
from g03_ratio_calc import calculate
from pathlib import Path
import json,hashlib,numpy as np,datetime

NAME='Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'
root=Path(S.report('G03'));root.mkdir(exist_ok=True)
dst=S.dst(NAME)
fresh(dst)
job=S.job(NAME)
E=job.E; T=job.T; T.learn(range(10),dpi=400,verbose=False)
final,ratios=calculate(TABLES,RATIO_TASKS)
checks=[];special=[];axes=[];curve_rows=[];content_rows=[]

def match1(pg,old,rect=None):
    ms=T.find(pg-1,old,rect=rect)
    if len(ms)!=1:raise RuntimeError(f'{pg}: cần đúng 1 chỗ {old}, thấy {len(ms)}')
    return ms[0]

def replace_num(ident,pg,old,new,rect):
    m=match1(pg,old,rect)
    # Kiểm toạ độ thật của từng nét mới trước khi sửa.
    plan=T.replace(m,new,align='center',dry_run=True)
    for char,x in plan['plan']:
        g,s,ss=T._source(m.glyphs[0].style,char)
        ls,ad,bo=T.char_metrics(m.glyphs[0].style,char)
        predicted=[x+ls,plan['base']+bo,x+ls+(g.bbox[2]-g.bbox[0])*s,plan['base']+bo+(g.bbox[3]-g.bbox[1])*s]
        if not (rect[0]-1 <= predicted[0] <= predicted[2] <= rect[2]+1 and rect[1]-1 <= predicted[1] <= predicted[3] <= rect[3]+1):
            raise RuntimeError(f'#{ident}: toạ độ nét mới ra ngoài ô: {predicted}')
    T.replace(m,new,align='center',verbose=False)
    job._add(pg-1,m.bbox,f'#{ident}: {old} → {new}','outline')
    checks.append(dict(id=ident,page=pg,old=old,new=new,rect=list(m.bbox),method='Chép nét chữ cùng phông/cỡ/màu trong chính PDF, căn giữa'))
    print(f'#{ident} {pg}: {old} -> {new}',flush=True)

for ident,pg,old,new,rect in SIMPLE:replace_num(ident,pg,old,new,rect)
for ident,z in ratios.items():replace_num(ident,z['page'],str(z['old']),str(z['chosen']),RATIO_REGIONS[ident])

# Căn 8 tên model trong 6 ô mục lục theo chữ mô tả cùng cột và cùng hàng.
for name,x,y in CONTENTS:
    m=match1(2,name)
    dx=x-float(m.bbox[0]);dy=y-float(m.bbox[1]);T.move(m,dx,dy)
    newbox=[m.bbox[0]+dx,m.bbox[1]+dy,m.bbox[2]+dx,m.bbox[3]+dy]
    rect=[min(m.bbox[0],newbox[0]),min(m.bbox[1],newbox[1]),max(m.bbox[2],newbox[2]),max(m.bbox[3],newbox[3])]
    job._add(1,rect,f'#33: căn {name}','move')
    content_rows.append(dict(name=name,old=list(m.bbox),new=newbox,dx=dx,dy=dy))

for pg in range(3,11):
    pi=pg-1
    # HP: dùng mẫu P cùng phông (catfix xác nhận bằng so hình), giữ kích thước và tâm cụm.
    m=match1(pg,'Hp'); h,p=m.glyphs
    src,s,ss=T._source(p.style,'P')
    newwidth=(src.bbox[2]-src.bbox[0])*s
    dx=-0.5*(newwidth-(p.bbox[2]-p.bbox[0]))
    T.move(Match(pi,[h],'H',[h]),dx,0)
    tx=p.bbox[0]+dx;ty=h.bbox[1]
    mx=np.array([[s,0,0],[0,s,0],[tx-s*src.bbox[0],ty-s*src.bbox[1],1]])
    E.delete_group(pi,p.oi,p.g)
    E.insert_path(pi,p.oi,E.glyph_pagepath(src.key,src.oi,src.g),Mx=mx)
    if abs((src.bbox[3]-src.bbox[1])*s-(h.bbox[3]-h.bbox[1]))>0.02:raise RuntimeError('P sai chiều cao chữ hoa H')
    rect=[min(m.bbox[0],m.bbox[0]+dx),min(m.bbox[1],ty),max(m.bbox[2],tx+newwidth),max(m.bbox[3],ty+(src.bbox[3]-src.bbox[1])*s)]
    job._add(pi,rect,'#34: Hp → HP','outline-copy')
    special.append(dict(id=34,page=pg,old='Hp',new='HP',rect=rect,source_page=src.key+1,source_bbox=src.bbox,scale=s))

    # Chỉ thêm dấu chấm cuối S.r.l., giữ tên Aquaris và mọi nét chữ cũ.
    m=match1(pg,'S.r.l'); dot=m.glyphs[-2]; r=m.glyphs[-3];last=m.glyphs[-1]
    gap=max(0.15,float(dot.bbox[0]-r.bbox[2]))
    dotdx=float(last.bbox[2]+gap-dot.bbox[0])
    E.insert_path(pi,last.oi,E.glyph_pagepath(pi,dot.oi,dot.g),dx=dotdx)
    rect=[m.bbox[0],m.bbox[1],dot.bbox[2]+dotdx,m.bbox[3]]
    job._add(pi,rect,'#34: S.r.l → S.r.l.','outline-copy')
    special.append(dict(id=34,page=pg,old='S.r.l',new='S.r.l.',rect=rect))

    # Chèn khoảng trắng bằng dời đúng phần sau; không thay hình ký tự ϕ.
    m=match1(pg,'diametero95mm')
    if len(m.glyphs)!=13:raise RuntimeError('Cần 13 nét diameterϕ95mm')
    space=float(T.space(m.glyphs[0].style)) if hasattr(T,'space') else 2.5
    if not 1.5<=space<=3.5:space=2.5
    gl=m.glyphs
    T.move(Match(pi,gl[8:11],'ϕ95',gl),space,0)
    T.move(Match(pi,gl[11:],'mm',gl),2*space,0)
    rect=[m.bbox[0],m.bbox[1],m.bbox[2]+2*space,m.bbox[3]]
    job._add(pi,rect,'#34: diameterϕ95mm → diameter ϕ95 mm','move')
    special.append(dict(id=34,page=pg,old='diameterϕ95mm',new='diameter ϕ95 mm',rect=rect,space=space))
print('Đã sửa số, mục lục và 24 phần chữ chung làm được',flush=True)

for pg,tab in final.items():
    pi=pg-1;P=E.page(pi);border=P.objs[tab['grid_oi']]['bbox']
    x0,y0,x1,y1=[float(v) for v in border]
    ch=charts.Chart.from_ticks([(0,x0),(max(tab['q']),x1)],[(0,y0),(tab['maxH'],y1)])
    axes.append(dict(page=pg,rect=border,units=tab['units'],maxQ=max(tab['q']),maxH=tab['maxH'],residual=ch.residual,warning=ch.warning))
    candidates=[]
    for oi in charts.curve_objects(P,(x0-25,y0-2,x1+2,y1+2),min_span=100):
        col=P.color_of(oi,'stroke')
        if col is None or col[2]<0.8 or col[1]<0.6 or col[0]>0.3:continue
        pts=charts.sample_path(P.object_pagepath(oi),n=400)
        start=pts[np.argmin(abs(pts[:,0]-x0))]
        candidates.append(dict(oi=oi,points=pts,H_start=float(ch.to_data([start])[0,1]),color=col))
    candidates.sort(key=lambda v:v['H_start'])
    if len(candidates)!=len(tab['stages']):raise RuntimeError(f'Trang {pg}: đường {len(candidates)}, bảng {len(tab["stages"])}')

    # Nhãn mỗi model gồm 3 đối tượng 4, S, phần còn lại; giữ cả kiểu nghiêng của nhãn.
    names=[]
    for oi,o in enumerate(P.objs):
        if o['op'] not in ('f','f*'):continue
        b=o['bbox'];c=P.color_of(oi,'fill')
        if c is None or not(c[0]<0.6 and c[1]<0.6 and c[2]>0.4):continue
        if b[0]<x0-2 or b[2]>280 or b[1]<y0-4 or b[3]>y1+2 or b[2]-b[0]>65 or b[3]-b[1]>25:continue
        if not any(g.oi==oi for g in T.page_glyphs(pi)):continue
        names.append(oi)
    names.sort()
    if len(names)!=3*len(tab['stages']):raise RuntimeError(f'Trang {pg}: đối tượng nhãn {len(names)}, cần {3*len(tab["stages"])}')
    labels=[]
    for i in range(0,len(names),3):
        group=names[i:i+3]
        b=[min(P.objs[j]['bbox'][0] for j in group),min(P.objs[j]['bbox'][1] for j in group),max(P.objs[j]['bbox'][2] for j in group),max(P.objs[j]['bbox'][3] for j in group)]
        labels.append(dict(objects=group,bbox=b))
    labels.sort(key=lambda v:(v['bbox'][1]+v['bbox'][3])/2)

    for stage,heads,cur,label in zip(tab['stages'],tab['heads'],candidates,labels):
        model=f"{tab['series']}/{stage}";pts=list(zip(tab['q'],heads));olddata=ch.to_data(cur['points'])
        deviations=ch.compare(olddata,pts,tol_rel=0.02)
        for z in deviations:z['tolerance']=max(1,0.02*abs(z['H_table']));z['ok']=z['diff'] is not None and abs(z['diff'])<=z['tolerance']
        # Nội suy đơn điệu qua đúng từng điểm, bảo đảm hai đầu đúng điểm bảng.
        path=ch.smooth_path(pts,method='pchip');newdata=ch.to_data(charts.sample_path(path,n=400))
        newdev=ch.compare(newdata,pts,tol_rel=0.02)
        for z in newdev:z['tolerance']=max(1,0.02*abs(z['H_table']));z['ok']=z['diff'] is not None and abs(z['diff'])<=z['tolerance']
        if not all(z['ok'] for z in newdev):raise RuntimeError(f'Đường mới {model} lệch bảng')
        endpoints=[newdata[0].tolist(),newdata[-1].tolist()]
        if np.max(np.abs(np.array(endpoints)-np.array([pts[0],pts[-1]])))>1e-7:raise RuntimeError('Hai đầu đường mới chưa khớp')
        E.replace_path(pi,cur['oi'],path)
        job._add(pi,[x0,y0,x1,y1],f'Biểu đồ: {model}, đúng 6 điểm bảng','curve')
        dy=float(ch.to_page(0,heads[0])[1]-ch.to_page(0,cur['H_start'])[1])
        moved=False
        if abs(dy)>2:
            for oi in label['objects']:
                gs=[g for g in T.page_glyphs(pi) if g.oi==oi]
                T.move(Match(pi,gs,model,gs),0,dy)
            nb=[label['bbox'][0],label['bbox'][1]+dy,label['bbox'][2],label['bbox'][3]+dy]
            r=[min(label['bbox'][0],nb[0]),min(label['bbox'][1],nb[1]),max(label['bbox'][2],nb[2]),max(label['bbox'][3],nb[3])]
            job._add(pi,r,f'Nhãn {model}: dời theo đầu đường {dy:.2f} pt','move');moved=True
        curve_rows.append(dict(page=pg,model=model,oi=cur['oi'],units=tab['units'],table_points=pts,color=cur['color'],before=deviations,after=newdev,endpoints=endpoints,method=ch.last_method,label_shift=dy if moved else 0,label_objects=label['objects']))
    print(f'Trang {pg}: {len(candidates)} đường biểu đồ đã đồng bộ bảng',flush=True)

job.save()
print('Đã lưu PDF',dst,flush=True)
state=dict(source=job.src,destination=job.dst,source_sha256=hashlib.sha256(Path(job.src).read_bytes()).hexdigest(),ratios=ratios,tables=final,axes=axes,checks=checks,special=special,contents=content_rows,curves=curve_rows,edits=job.edits,missing=dict(task=34,reason='Không có mẫu chữ thường k, không có font nhúng hoặc lớp chữ thật/ẩn trong 10 trang. KW/Kw chưa sửa.'),created=datetime.datetime.now().isoformat())
json.dump(state,open(fresh(root/'build-state.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
job.close()
