"""Actual source table ruled-cell positions; source/current H pixels compared, no PDF writes."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image,ImageDraw,ImageFont
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'));geom=json.loads((root/'HOA TIET BANG NGUON CANDIDATE2.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);F=Editor(d['current'],backend='fitz');RF=Raster(F);cells=[];tables=[];font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
def runs(a):
 out=[]
 for i in np.flatnonzero(a):
  if not out or i-out[-1][-1]>1:out.append([])
  out[-1].append(int(i))
 return out
for t in geom['records']:
 rows=[r for r in d['rows'] if r['page']==t['page'] and r['family']==t['family']];cv=R.render_canvas(t['page']-1,t['rect'],dpi=300);other=RF.render_canvas(t['page']-1,t['rect'],dpi=300);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);spread=a.max(2)-a.min(2);H,W=g.shape
 var=next(v for v in t['variants'] if v['threshold']==210);ys=np.array(var['body_candidates']);assert len(ys)==len(rows)+1
 # Every body rule is observed; the final 6SL15 row is taller in the source,
 # so equal row height is NOT imposed when locating actual cells.
 body0=int(np.ceil(ys[0]+3));body1=int(np.floor(ys[-1]-3));m=(g[body0:body1,:]<225)&(spread[body0:body1,:]<32);cov=m.mean(0);xc=runs(cov>.88);xall=[float(np.average(z,weights=cov[z])) for z in xc];nq=len(rows[0]['Q']);xs=np.array(xall[-nq-1:]);assert len(xs)==nq+1 and xs[0]>W*.39 and xs[-1]>W*.92,(t['family'],xall)
 step=np.diff(xs);assert np.all(step>8) and max(step)/min(step)<1.35,(t['family'],xs,step)
 base=max(R.images(t['page']-1),key=lambda z:z.W*z.H)
 pic=Image.fromarray(cv.orig);draw=ImageDraw.Draw(pic)
 for rnum,row in enumerate(rows):
  ycenter=(ys[rnum]+ys[rnum+1])/2;draw.text((6,ycenter-7),row['model'],font=font,fill=(180,0,180))
  for col,(q,h) in enumerate(zip(row['Q'],row['H'])):
   bounds=[int(np.ceil(xs[col]+2)),int(np.ceil(ys[rnum]+2)),int(np.floor(xs[col+1]-2)),int(np.floor(ys[rnum+1]-2))];assert bounds[2]>bounds[0] and bounds[3]>bounds[1]
   im1=cv.orig[bounds[1]:bounds[3],bounds[0]:bounds[2]];im2=other.orig[bounds[1]:bounds[3],bounds[0]:bounds[2]];count=int(np.any(im1!=im2,axis=2).sum());assert count==0,(row['model'],q,count)
   x0,y1=cv.to_page(xs[col],ys[rnum]);x1,y0=cv.to_page(xs[col+1],ys[rnum+1]);native0=base.to_px(x0,y1);native1=base.to_px(x1,y0)
   cells.append(dict(page=row['page'],model=row['model'],Q=q,H_source=h,page_rect=[x0,y0,x1,y1],render_rect_300=bounds,native_uv_rect=[native0[0],native0[1],native1[0],native1[1]],current_H_cell_pixels_compared=int(im1.shape[0]*im1.shape[1]),current_H_cell_changed_pixels=count,source_value_read_basis=row['table_read'],geometry_basis='Tâm vạch kẻ thực neutral210/coverage65%; vị trí từ bảng nguồn Redpump, không suy từ bảng Perotac',curve_numeric_acceptance=False))
 # External purple model captions are REPORT ONLY, overlaid in the model column.
 photo=root/'VI TRI CAC O NGUON V2'/f'TRANG {t["page"]:02} {t["family"]} BANG DINH VI.png';pic.save(fresh(photo))
 tables.append(dict(page=t['page'],family=t['family'],rect=list(cv.rect0),dpi=300,body_horizontal_centres=ys.tolist(),all_vertical_centres=xall,numeric_vertical_centres=xs.tolist(),column_spacing_residual_px=float(abs(step-step.mean()).max()),model_row_count=len(rows),Q_column_count=nq,native_image_size=[base.W,base.H],native_image_bbox=list(base.page_bbox),native_image_ctm=base.ctm.tolist(),image_raw_SHA256=hashlib.sha256(E.doc.stream_raw(base.ref)).hexdigest(),report_caption_image=str(photo),layout_note='6SL15 last row height is observed, not forced equal.' if t['family']=='6SL15' else 'Each table body row assigned in actual printed order, not inferred by stage ratio.'))
 print(t['page'],t['family'],len(rows)*nq,'source/canonical cells exact',flush=True)
E.close();F.close();assert len(cells)==1931 and before==[sha(d['source']),sha(d['current'])]
out=dict(source=d['source'],source_SHA256=d['source_SHA256'],current=d['current'],current_SHA256=d['current_SHA256'],H_cells=len(cells),changed_cell_pixels=sum(c['current_H_cell_changed_pixels'] for c in cells),tables=tables,cells=cells,catalogue_written=False,curve_numeric_acceptance=False,status='1931 ô bảng nguồn đã định vị theo vạch kẻ thực, vùng trong ô giữ từng pixel300dpi. Đây là kiểm dữ liệu/vị trí bảng, không phải độ đúng của194đường chưa nghiệm thu.')
Path(fresh(root/'1931 O NGUON DINH VI VA DOI CHIEU V2.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print('1931 real source cell positions; H cells0 changed; no new curve acceptance',flush=True)
