"""ROOT-authorized M1 only: own Redpump V2/atlasV4/layoutV1. No canonical/ledger."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
import hashlib, json, zlib
import numpy as np
from scipy.interpolate import UnivariateSpline, PPoly
from catfix.recipes import Job
from catfix.cs import Instr, Num, Name
from catfix import verify

P = Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
read = lambda n: json.loads((P/n).read_text(encoding='utf8'))
plan = read('PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17 V2.json')
local = read('104 NEO QH ANH XA VACH THUC CUC BO V1.json')
paths = read('13 DUONG BEZIER CUC BO VA CHIEU DAI CUNG KE HOACH.json')
atlas = read('13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json')
labels = read('13 HOP NHAN CUC BO TRANH DUONG LUOI V1.json')
frames = read('KHUNG LUOI THAT NGUON TRANG8.json')
keep = read('VACH PHU FEET VA KHOI TIEU DE GIU NGUON V1.json')
eta = read('ETA DOC NET NGUON RIENG.json')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
src, cur = plan['method']['source'], plan['method']['input_current']
guards = [sha(src), sha(cur)]
assert guards == [plan['method']['source_SHA256'], plan['method']['input_SHA256']]
for x in [local, paths, atlas, labels, keep, eta]:
    assert x['source_SHA256'] == guards[0] and x['current_SHA256'] == guards[1]
assert len(paths['records']) == len(atlas['records']) == len(labels['records']) == 13
assert np.allclose(paths['records'][0]['style']['RGB'], [134,149,152])
folder = Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
assert not folder.exists(), 'M1 folder already exists: do not write another PDF/overwrite.'
dst = fresh(folder/Path(cur).name)
j = Job(cur, dst, backend='fitz', log_path=fresh(folder/'NHAT KY CATFIX.json'))
oldpage = j.E.page(7)
assert np.max(abs(oldpage.ctm_at(len(oldpage.ops))-np.eye(3))) < 1e-12
assert sum(z.op=='q' for z in oldpage.ops) == sum(z.op=='Q' for z in oldpage.ops)
assert tuple(j.E.mediabox(7)) == (0.,0.,834.,593.)

def I(op,*nums):
    return Instr([Num(float(z)) for z in nums],op)
def rect(box):
    x,y,r,t = box
    return I('re',x,y,r-x,t-y)
def path_instrs(path):
    return [Instr([Num(float(z)) for xy in a['points'] for z in xy],a['op']) for a in path]
def clip_domain(box, holes=()):
    # Separate outer clip prevents even-odd holes extending outside the outer rect.
    out = [rect(box),Instr([],'W'),Instr([],'n')]
    if holes:
        out += [rect(box)] + [rect(b) for b in holes] + [Instr([],'W*'),Instr([],'n')]
    return out
def clip_intersection(a,b):
    c = [max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])]
    return c if c[2]>c[0] and c[3]>c[1] else None

panels = {z['name']:z for z in frames['panels']}
title = np.array(keep['title_original_page_bbox'],float)
# Retain full source block and its JPEG edge, including the original title border.
title_hole = (title+np.array([-1.1,-1.1,1.1,1.1])).tolist()
holes = [title_hole] + [z['source_original_ink_restore_page_bbox'] for z in keep['short_feet_ticks']]
allowed = [z['allowed_rebuild_bbox_proposed'] for z in frames['panels']]
ins = [Instr([Name('CfxRedpumpWholePage8M1')],'BMC'),Instr([],'q'),I('J',0),I('j',1),I('M',10)]
gridrecords=[]
for g in plan['observed_grids']:
    name=g['name']; box=panels[name]['frame_page_bbox']; body=panels[name]['allowed_rebuild_bbox_proposed']
    protected=[x for b in (holes if name=='QH' else []) if (x:=clip_intersection(body,b)) is not None]
    ins += [Instr([],'q')] + clip_domain(body,protected)
    ins += [I('rg',1,1,1),rect(body),Instr([],'f')]
    ins += clip_domain(box)
    ins += [I('RG',224/255,224/255,224/255),I('w',.65),Instr([[],Num(0)],'d')]
    for x in g['vertical_page_x']:
        ins += [I('m',x,box[1]),I('l',x,box[3])]
    for y in g['horizontal_page_y']:
        ins += [I('m',box[0],y),I('l',box[2],y)]
    ins += [Instr([],'S'),Instr([],'Q')]
    gridrecords.append(dict(name=name,box=box,allowed=body,protected_holes=protected,
        vertical_page_x=g['vertical_page_x'],horizontal_page_y=g['horizontal_page_y'],
        width_pt=.65,RGB=[224,224,224]))

modelrecords=[]
for record in paths['records']:
    path=record['planned_path']; assert len(path)==8 and path[0]['op']=='m'
    x0=path[0]['points'][0][0]; end=path[-1]['points'][-1]; x1=end[0]
    split=path[2]['points'][-1]
    assert abs(split[0]-local['Q6_transition_local']['page_coord'])<1e-10
    assert record['split_tangent_angle_deg']<1e-6
    first=path[:3]; second=[dict(op='m',points=[split])]+path[3:]
    ins += [Instr([],'q')] + clip_domain([x0,panels['QH']['frame_page_bbox'][1],x1,panels['QH']['frame_page_bbox'][3]])
    ins += [I('RG',134/255,149/255,152/255),I('w',.95),I('J',0),I('j',1)]
    ins += [Instr([[Num(6.95),Num(3.41)],Num(0)],'d')] + path_instrs(first) + [Instr([],'S')]
    ins += [Instr([[],Num(0)],'d')] + path_instrs(second) + [Instr([],'S'),Instr([],'Q')]
    modelrecords.append(dict(model=record['model'],source_anchors=record['source_anchors'],
        new_Q0_page=path[0]['points'][0],new_Q6_page=split,new_Q21_page=end,
        single_whole_PCHIP_then_split=True,phase_not_shifted=True,source_plan_file=str(P/'13 DUONG BEZIER CUC BO VA CHIEU DAI CUNG KE HOACH.json')))

# Smooth only observed eta ink. No eta values and no visible extrapolation to frame.
xy=np.array(eta['source_observed_page_points'],float); assert len(xy)==551 and np.all(np.diff(xy[:,0])>0)
x,y=xy.T; span=x[-1]-x[0]
chosen=None
for rms in [.12,.10,.08,.06,.04]:
    f=UnivariateSpline(x,y,k=3,s=len(x)*rms*rms,ext=2)
    d0=y[0]-float(f(x[0])); d1=y[-1]-float(f(x[-1])); slope=(d1-d0)/span
    def fun(t): return f(t)+d0+(np.asarray(t)-x[0])*slope
    error=np.asarray(fun(x))-y
    if max(abs(error))<=.24:
        chosen=(f,d0,slope,error,rms);break
assert chosen is not None, 'eta source smoothing exceeded half-native-pixel allowance'
f,d0,slope,error,rms=chosen
der=f.derivative(); pp=PPoly.from_spline(f._eval_args)
knots=np.unique(np.r_[x[0],pp.x[(pp.x>x[0])&(pp.x<x[-1])],x[-1]])
epath=[dict(op='m',points=[xy[0].tolist()])]
for l,r in zip(knots,knots[1:]):
    width=(r-l)/3.; yl=float(fun(l)); yr=float(fun(r))
    epath.append(dict(op='c',points=[[l+width,yl+width*(float(der(l))+slope)],
        [r-width,yr-width*(float(der(r))+slope)],[r,yr]]))
assert np.max(abs(np.array(epath[-1]['points'][-1])-xy[-1]))<1e-10
ins += [Instr([],'q')] + clip_domain(panels['eta']['frame_page_bbox'])
ins += [I('RG',134/255,149/255,152/255),I('w',.95),I('J',0),I('j',1),Instr([[],Num(0)],'d')]
ins += path_instrs(epath) + [Instr([],'S'),Instr([],'Q')]

letterrecords=[]
bank={z['model']:z for z in atlas['records']}
for lb in labels['records']:
    a=np.asarray(bank[lb['model']]['assembled_alpha_source_only'],float)
    alpha=np.ascontiguousarray(np.clip(np.rint(a*255),0,255).astype(np.uint8))
    h,w=alpha.shape; black=np.zeros((h,w,3),np.uint8)
    sm=j.E.doc.new_image_xobject(zlib.compress(alpha.tobytes(),9),w,h,Name('DeviceGray'),8,'FlateDecode',extra={'Interpolate':False})
    ref=j.E.doc.new_image_xobject(zlib.compress(black.tobytes(),9),w,h,Name('DeviceRGB'),8,'FlateDecode',smask=sm,extra={'Interpolate':False})
    nm=j.R._register(7,ref)
    x0,y1=lb['source_word_array_page_origin']; xw,yh=w*.12,h*.12
    ins += [Instr([],'q'),I('cm',xw,0,0,yh,x0,y1-yh),Instr([Name(nm)],'Do'),Instr([],'Q')]
    letterrecords.append(dict(model=lb['model'],image_name=nm,source_atlas_V4=str(P/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json'),
        physical_ink_box=lb['physical_box'],image_array_shape=[h,w],array_page_origin=[x0,y1],
        physical_pixel_size=.12,image_CTM=[[xw,0,0],[0,yh,0],[x0,y1-yh,1]],
        alpha_SHA256=hashlib.sha256(alpha.tobytes()).hexdigest(),source_scale=1.,external_font_used=False))

# Source title/feet-stem holes are also retained in the new frame painting.
for name,panel in panels.items():
    box=panel['frame_page_bbox']; body=panel['allowed_rebuild_bbox_proposed']
    protected=[x for b in (holes if name=='QH' else []) if (x:=clip_intersection(body,b)) is not None]
    ins += [Instr([],'q')]+clip_domain(body,protected)+[I('RG',0,0,0),I('w',.63),I('J',0),I('j',1),Instr([[],Num(0)],'d'),rect(box),Instr([],'S'),Instr([],'Q')]
ins += [Instr([],'Q'),Instr([],'EMC')]
# Append after ALL current page layers. Images/old two paths stay unchanged below.
j.E.insert_instrs(7,len(oldpage.ops),ins,before=True)
for body in allowed:
    j._add(7,body,'13 QH/104 mốc cục bộ và eta nguồn: dựng toàn miền cùng nét/chữ thật Redpump','whole-panel-uniform-source-only-M1')
j.R.canvases.clear(); j._canvases.clear()
j.save()
sample_sha=sha(dst)
assert guards==[sha(src),sha(cur)], 'Source/canonical drift while writing M1'
build=dict(source=src,source_SHA256=guards[0],input_current=cur,input_SHA256=guards[1],sample=dst,sample_SHA256=sample_sha,
    parent_authorized_sample_number=1,writer_backend='catfix Job/Editor/PdfDoc fitz',canonical_written=False,shared_progress_written=False,
    page=8,actual_page_mediabox=[0,0,834,593],allowed_bboxes=allowed,protected_title_hole=title_hole,
    protected_feet_holes=holes[1:],grids=gridrecords,models=modelrecords,labels=letterrecords,
    style=dict(RGB=[134,149,152],width_pt=.95,opacity=1.,cap=0,join=1,dash=[6.95,3.41],phase=0,Q_switch=6.,grid_width=.65,grid_RGB=[224,224,224],frame_width=.63),
    eta=dict(source_point_count=551,source_points=xy.tolist(),source_first_and_last=xy[[0,-1]].tolist(),
        smoothing_RMS_requested_pt=rms,max_source_center_difference_pt=float(max(abs(error))),RMS_source_center_difference_pt=float(np.sqrt(np.mean(error**2))),
        spline_piece_count=len(epath)-1,source_endpoint_exact=True,visible_extrapolation=False,hidden_candidate_extension_drawn=False,
        head_limit='Chỉ 551 tâm mực quan sát. Không nối phần mờ/khung che 2,4pt vì chưa chứng minh đoạn ứng viên bị khung che toàn bộ.',
        numeric_accuracy='CHƯA THỂ: không có bảng hiệu suất eta.',actual_PDF_read=False),
    source_font_limit='13 nhãn từ một bộ mực glyph thật trong đúng Redpump, cỡ vật lý nguồn1.0; chữ JPEG150dpi có giới hạn sắc, phải nghiệm thu PDF/ảnh thực.',
    geometric_source_uncertainty_pt=.48,model25_source_and_current_label='25, chưa từng đổi 28→25',status='MẪU1 ĐÃ LƯU; CHƯA NGHIỆM THU PDF/ĐỒ HỌA/ROOT')
Path(fresh(folder/'TAO MAU1 VA BAO VE NGUON.json')).write_text(json.dumps(build,ensure_ascii=False,indent=2),encoding='utf8')
j.close()
# Evidence is always from the saved actual PDF, never a simulated canvas.
for dpi in [150,600]:
    verify.crop(cur,7,(53,267,364,511),dpi).save(fresh(folder/f'TRUOC TOAN QH VA ETA {dpi}dpi.png'))
    verify.crop(dst,7,(53,267,364,511),dpi).save(fresh(folder/f'SAU TOAN QH VA ETA {dpi}dpi.png'))
verify.crop(dst,7,(0,0,834,593),150).save(fresh(folder/'TOAN TRANG8 MAU1 150dpi.png'))
verify.compare_sheet(cur,dst,[(7,(53,267,364,511),'Redpump: toàn13 QH + eta, chữ nguồn')],fresh(folder/'TRUOC SAU TOAN BIEU DO 150dpi.png'),dpi=150,pad=(0,0))
print('M1 SAVED',dst,'SHA256',sample_sha,'eta center max',max(abs(error)),'sample only; no canonical/ledger',flush=True)
