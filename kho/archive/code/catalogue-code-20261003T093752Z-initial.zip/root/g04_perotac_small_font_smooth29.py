"""Smooth caption contour curves within JPEG uncertainty; no PDF/font program."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.raster import cv2
from scipy.ndimage import distance_transform_edt
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'CHU NHO BIEN CONG TRONG BAT DINH JPEG'
data=json.loads((base/'CHU NHO PHUC HOI BIEN CHO RAM/12 KY TU NHO VA13 TEN RAM CHUA NGHIEM THU.json').read_text(encoding='utf8'));out=[];scale=96
def closed_bezier(points):
    p=np.array(points,float);segs=[];samples=[]
    for i,v in enumerate(p):
        j=(i+1)%len(p);vv=p[j]
        def tangent(k):
            prev=p[(k-1)%len(p)];next=p[(k+1)%len(p)];vin=p[k]-prev;vout=next-p[k];cos=float(vin@vout/max(np.linalg.norm(vin)*np.linalg.norm(vout),1e-9));angle=np.degrees(np.arccos(np.clip(cos,-1,1)))
            return np.zeros(2) if angle>75 else (next-prev)*.145
        c1=v+tangent(i);c2=vv-tangent(j);tt=np.linspace(0,1,32,endpoint=False)[:,None];a=(1-tt)**3*v+3*(1-tt)**2*tt*c1+3*(1-tt)*tt**2*c2+tt**3*vv
        segs.append([v.tolist(),c1.tolist(),c2.tolist(),vv.tolist()]);samples.extend(a.tolist())
    return segs,np.array(samples)
def mask_of(paths,w,h):
    img=Image.new('L',((w+2)*scale,(h+2)*scale),0);d=ImageDraw.Draw(img)
    for p in paths:d.polygon([((x+1)*scale,(y+1)*scale) for x,y in p['local_native_xy']],fill=255 if p['parent']<0 else 0)
    return np.asarray(img)>0
for src in data['glyphs']:
    ch=src['character'];new=[]
    for p in src['cleaned_contour_paths']:
        if ch in '/4':samples=np.array(p['local_native_xy']);segs=[]
        else:segs,samples=closed_bezier(p['local_native_xy'])
        new.append(dict(local_native_xy=samples.tolist(),parent=p['parent'],cubic_segments_local_native=segs))
    xy=np.array([q for p in new for q in p['local_native_xy']]);nb=np.array([xy[:,0].min(),xy[:,1].min(),xy[:,0].max(),xy[:,1].max()]);target=np.array(src['clean_bbox_native']);factor=(target[2:]-target[:2])/(nb[2:]-nb[:2]);offset=target[:2]-nb[:2]*factor
    for p in new:
        p['local_native_xy']=(np.array(p['local_native_xy'])*factor+offset).tolist()
        if p['cubic_segments_local_native']:p['cubic_segments_local_native']=(np.array(p['cubic_segments_local_native'])*factor+offset).tolist()
    h=len(src['source_alpha']);w=len(src['source_alpha'][0]);oldmask=mask_of(src['cleaned_contour_paths'],w,h);newmask=mask_of(new,w,h);oc,_=cv2.findContours(oldmask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);cc,hh=cv2.findContours(newmask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);edgeold=np.zeros_like(oldmask);edgenew=np.zeros_like(newmask)
    for co in oc:edgeold[co[:,0,1],co[:,0,0]]=True
    for co in cc:edgenew[co[:,0,1],co[:,0,0]]=True
    d1=distance_transform_edt(~edgeold)[edgenew]/scale;d2=distance_transform_edt(~edgenew)[edgeold]/scale;dist=max(float(d1.max()),float(d2.max()));area=newmask.sum()/scale**2
    item={**src,'cleaned_contour_paths':new,'cubic_cleaning_from_source_polygons_not_a_new_font':True,'source_bbox_restored_exactly_after_curve_smoothing':True,
       'bbox_restoration_scale':factor.tolist(),'bbox_restoration_offset':offset.tolist(),'smooth_area_native_px':float(area),'smooth_vs_original_alpha_area_delta_percent':float((area/src['source_alpha_area_native_px']-1)*100),
       'max_bidirectional_outline_difference_from_source_candidate_native_px':dist,'within_source_half_pixel_boundary_uncertainty':dist<=.5,
       'smooth_outer_components':int(sum(hh[0,i,3]<0 for i in range(len(cc)))),'smooth_holes':int(sum(hh[0,i,3]>=0 for i in range(len(cc)))),'ROOT_or_graphic_acceptance_pending':True}
    out.append(item);print(ch,'SOURCE AREA%',item['smooth_vs_original_alpha_area_delta_percent'],'HAUSDORFF',dist,'TOPOLOGY',item['smooth_outer_components'],item['smooth_holes'],flush=True)
font={r['character']:r for r in out};sheet=Image.new('RGB',(1750,2600),'white');dr=ImageDraw.Draw(sheet)
for i,word in enumerate(data['words']):
    x=15.;y=i*200+140.;sc=14
    for ch in word['literal']:
        ff=font[ch]
        for p in ff['cleaned_contour_paths']:dr.polygon([(x+xx*sc,y+(yy-9)*sc) for xx,yy in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
        x+=ff['native_advance']*sc
imagepath=root/'13 TEN MODEL BIEN CONG NGUON RAM.png'
if imagepath.exists():
    assert np.array_equal(np.asarray(Image.open(imagepath).convert('RGB')),np.asarray(sheet)), 'Own previous evidence image differs; do not overwrite'
else:sheet.save(fresh(imagepath))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==data['source_sha256'] and sha(S.result(name))==data['current_sha256']
Path(fresh(root/'12 GLYPH BIEN CONG NGUON RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_small_caption_only=True,
    no_table_or_header_glyph_use=True,advance_source_unchanged=True,glyphs=out,words=data['words'],source_style_name_not_invented=True,source_native_uncertainty_half_pixel=True,
    no_actual_PDF_or_FontProgram_written=True,root_or_graphic_style_acceptance_pending=True,progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
