from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from g04_perotac_audit_labels_manual import MANUAL
from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,hashlib

root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
E=Editor(S.src(name));R=Raster(E)
axes=json.loads((root/'TRUC DA DOI CHIEU LAN4.json').read_text(encoding='utf8'))['graphs']
steps=[5,10,30,20,15,60,50,60,50,50,30,30,25,45,40,50,25]
result=[]
for rec,ax,step in zip(DATA,axes,steps):
 im=max(R.images(rec['page']-1),key=lambda p:p.W*p.H);arr=R.canvas(im).orig
 gray=arr.astype(float)@np.array([.299,.587,.114]);f=ax['frame_native']
 lo,hi=int(f['left'])+5,int(f['right'])-5
 med=np.median(gray[:,lo:hi],axis=1);ticks=[]
 for h in range(0,ax['H_printed_max']+1,step):
  approximate=f['bottom']-h/ax['H_m_per_native_px']
  yy=np.arange(int(round(approximate))-5,int(round(approximate))+6)
  dark=255-med[yy];peak=int(yy[np.argmax(dark)])
  # Centre only the actual long horizontal line at the selected location.
  yy2=np.arange(peak-1,peak+2);ww=np.maximum(255-med[yy2],0)
  keep=ww>=.6*ww.max();v=float(np.average(yy2[keep],weights=ww[keep]))
  ticks.append(dict(H_m=h,v_native=v,raw_darkness_peak=float(dark.max())))
 fit=np.polyfit([t['H_m'] for t in ticks],[t['v_native'] for t in ticks],1)
 res=np.array([t['v_native'] for t in ticks])-np.polyval(fit,[t['H_m'] for t in ticks])
 ax['H_grid_calibration']=dict(v_per_m=float(fit[0]),v_H0=float(fit[1]),max_residual_native_px=float(abs(res).max()),ticks=ticks,printed_values_review_pending=True)
 box=(int(f['left'])-31,int(f['top'])-8,int(f['left'])+13,int(f['bottom'])+9)
 pic=Image.fromarray(arr[box[1]:box[3],box[0]:box[2]]).resize(((box[2]-box[0])*4,(box[3]-box[1])*4),Image.Resampling.NEAREST)
 d=ImageDraw.Draw(pic)
 for t in ticks:
  y=(t['v_native']-box[1])*4;x=(f['left']-box[0])*4
  d.line((x+1,y,x+20,y),fill='red',width=2)
 fn='TRUC H NGUON '+rec['family'].replace('.','_')+'.png';pic.save(fresh(root/fn));ax['H_tick_evidence_image']=fn
 result.append(ax);print(rec['family'],'HGRID',np.round([t['v_native'] for t in ticks],3),'res',round(float(abs(res).max()),3),flush=True)

for fam,ya,yb in [('4SA4',455,550),('4SA10',450,540)]:
 rec=next(r for r in DATA if r['family']==fam);im=max(R.images(rec['page']-1),key=lambda p:p.W*p.H);arr=R.canvas(im).orig
 labelx=MANUAL[fam][0];x0=labelx-10;x1=labelx+66
 pic=Image.new('RGB',((x1-x0)*10+65,(yb-ya)*10),'white');pic.paste(Image.fromarray(arr[ya:yb,x0:x1]).resize(((x1-x0)*10,(yb-ya)*10),Image.Resampling.NEAREST),(65,0));d=ImageDraw.Draw(pic)
 for y in range(ya,yb,5):
  yy=(y-ya)*10;d.text((2,yy),str(y),fill='red');d.line((40,yy,65,yy),fill='red')
 pic.save(fresh(root/('NHAN CHONG TOA DO '+fam+' LAN2.png')))
Path(fresh(root/'TRUC H DOC VA DOI CHIEU.json')).write_text(json.dumps(dict(source=S.src(name),read_only=True,pdf_written=False,graphs=result),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
