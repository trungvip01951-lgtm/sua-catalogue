"""Mẫu 2 đường 4SA16: dữ liệu bảng, nét/độ dày lấy từ ảnh nguồn."""
from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix.recipes import Job
from catfix.charts import Chart,draw_polyline,sample_path
from catfix.verify import compare_sheet,outside_pixels
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
src=S.dst(name);dst=fresh(S.report('G04/MAU DUONG LAN2/'+name));j=Job(src,dst)
R=j.R;cv=R.canvas(R.images(7)[0]);original=cv.work.copy();g=cv.gray();H,W=g.shape
Q=np.array([0,3,6,9,12,15,18,21],float)
series=[('4SA16/23',[136,133,127,115,101,86,69,50]),('4SA16/18',[107,104,99,90,79,67,54,39])]
ax=.74446*1000/60;bx=60.379;top=180.5;bottom=571.5
y0=cv.to_page(125,bottom)[1];y150=cv.to_page(125,top)[1];C=Chart(ax,bx,(y150-y0)/150,y0)
u0=int(round(cv.to_px(*C.to_page(0,0))[0]));uend=int(round(cv.to_px(*C.to_page(21.6,0))[0]));us=np.arange(u0,uend+1)
colour=(original[:,:,1].astype(int)-original[:,:,0].astype(int)>10)&(original[:,:,2].astype(int)-original[:,:,0].astype(int)>14)&(original[:,:,0]<235)
traces=[];allmask=np.zeros((H,W),bool);inks=[];widths=[]
for model,heads in series:
    coeff=np.polyfit(Q,heads,3);guide=np.polyval(coeff,(np.array([cv.to_page(u,0)[0] for u in us])-bx)/ax)+2
    vp=np.array([cv.to_px(*C.to_page(float(q),float(h)))[1] for q,h in zip((np.array([cv.to_page(u,0)[0] for u in us])-bx)/ax,guide)])
    trace=[];present=[]
    for u,v in zip(us,vp):
        ys=np.arange(max(0,int(round(v))-9),min(H,int(round(v))+10));valid=ys[colour[ys,u]]
        if len(valid):
            groups=np.split(valid,np.where(np.diff(valid)>1)[0]+1)
            candidates=[]
            for gr in groups:
                wt=255-g[gr,u];vv=float(np.average(gr,weights=wt));candidates.append((abs(vv-v),vv,gr))
            _,vv,gr=min(candidates,key=lambda z:z[0]);trace.append(vv);present.append(True)
        else:trace.append(np.nan);present.append(False)
    tr=np.array(trace);good=np.isfinite(tr);assert good.sum()>.65*len(us),(model,good.sum(),len(us))
    tr=np.interp(us,us[good],tr[good]);pres=np.array(present)
    # Định vị lại tại nét đã nhận diện để không chọn rìa nhạt của nhịp đứt.
    tr2=[]
    for u,v in zip(us,tr):
        ys=np.arange(max(0,int(round(v))-4),min(H,int(round(v))+5));valid=ys[colour[ys,u]]
        if len(valid):
            wt=255-g[valid,u];tr2.append(float(np.average(valid,weights=wt)))
        else:tr2.append(np.nan)
    t2=np.array(tr2);gd=np.isfinite(t2);tr=np.interp(us,us[gd],t2[gd])
    tube=np.zeros((H,W),bool)
    for u,v in zip(us,tr):tube[max(0,int(round(v))-3):min(H,int(round(v))+4),u]=True
    # Chỉ xóa sắc nét đường trong hành lang hẹp, giữ chữ đen và đường lân cận.
    mask=tube&(original[:,:,1].astype(int)-original[:,:,0].astype(int)>2)&(original[:,:,2].astype(int)-original[:,:,0].astype(int)>3)
    pix=original[colour&tube];lum=pix.astype(float)@np.array([.299,.587,.114]);ink=np.median(pix[lum<=np.percentile(lum,20)],axis=0)
    from scipy.ndimage import binary_closing,binary_opening
    on=np.array([mask[:,u].any() for u in us]);pres=binary_opening(binary_closing(on,structure=np.ones(3)),structure=np.ones(3))
    pres[0]=on[0];pres[-1]=on[-1]
    al=np.clip((255-original.astype(float))@(255-ink)/np.sum((255-ink)**2),0,1)
    sample_cols=[u for u in us if 8<((cv.to_page(u,0)[0]-bx)/ax)<17]
    vals=[]
    for u in sample_cols:
        vi=tr[u-u0];v=int(round(vi));sl=al[v-3:v+4,u];der=np.gradient(tr)[u-u0]
        vals.append(sl.sum()/np.sqrt(1+der**2))
    width=float(np.median(vals));assert .7<width<4,(model,width)
    traces.append(dict(model=model,heads=heads,u=us,v=tr,present=pres,mask=mask,ink=ink,width=width));allmask|=mask
    inks.append(ink);widths.append(width)
    print('SOURCE',model,'ink',ink,'width',width,'n',good.sum(),len(us),flush=True)

# Giữ kẻ lưới: lấy nền theo đúng hàng/cột, chỉ áp lên mặt nạ nét cũ.
plotbox=cv.box((59.5,324,359,513));pu0,pv0,pu1,pv1=plotbox
pa=original[pv0:pv1,pu0:pu1].astype(float)
row=np.median(pa,axis=1);col=np.median(pa,axis=0)
bg=np.minimum(row[:,None,:],col[None,:,:]);background=original.copy();background[pv0:pv1,pu0:pu1]=bg.round().clip(0,255).astype(np.uint8)
R.erase(cv,mask=allmask,dilate=0,color=background[allmask])
proof=[]
for tr in traces:
    pts=[(float(q),float(h)) for q,h in zip(Q,tr['heads'])]
    path=C.smooth_path(pts,method='pchip');pagepts=sample_path(dict(path=path)) if False else None
    # Tính dày đặc từ cùng nội suy PCHIP, qua chính các số bảng.
    from scipy.interpolate import PchipInterpolator
    f=PchipInterpolator(Q,tr['heads']);qq=np.linspace(0,21,1401)
    page=[C.to_page(float(q),float(f(q))) for q in qq]
    # Dùng hình nhịp ngắt của đường nguồn tới hết phần nét đứt.
    pres=tr['present'];cut=int(round(cv.to_px(*C.to_page(6,0))[0]))
    runs=[];current=[]
    for q,p in zip(qq,page):
        u=int(round(cv.to_px(*p)[0]));draw=True
        if u<=cut:draw=bool(pres[np.clip(u-u0,0,len(pres)-1)])
        if draw:current.append(p)
        elif current:runs.append(current);current=[]
    if current:runs.append(current)
    for run in runs:
        if len(run)>1:draw_polyline(cv,run,tr['ink'],tr['width'],ss=8)
    proof.append(dict(model=tr['model'],points=pts,colour=tr['ink'].tolist(),width_px=tr['width'],method='pchip',native_source_trace_count=int(np.sum(tr['present'])),source_endpoint_Q=21.6,new_endpoint_Q=21))

# Miếng ảnh hẹp theo từng 12 cột, không ghép cả hình thành ảnh mới.
diff=np.any(cv.work!=original,axis=2);patches=[]
for ua in range(u0-1,uend+2,12):
    ub=min(W,ua+12);ys,xs=np.where(diff[:,ua:ub])
    if not len(ys):continue
    # Hai đường tách nhau: phân nhóm theo chiều dọc trong lát ảnh.
    yr=np.unique(ys);grs=np.split(yr,np.where(np.diff(yr)>8)[0]+1)
    for gr in grs:
        box=(ua,int(gr.min()),ub,int(gr.max()+1));R._write_patch(cv,box,encoding='flate');patches.append(cv.rect(box))
cv.orig=cv.work.copy();j._add(7,(59.5,324,359,513),'Hai đường 4SA16/23 và 4SA16/18 theo bảng','raster-curve')
j.save();j.close();ck=j.check(raster=True)
Path(fresh(S.report('G04/MAU DUONG LAN2/KIEM TRA.json'))).write_text(json.dumps(dict(src=src,dst=dst,check=ck,proof=proof,patches=patches),ensure_ascii=False,indent=2,default=str),encoding='utf8')
compare_sheet(src,dst,[(7,(59.5,324,359,513),'4SA16/23, 4SA16/18')],fresh(S.report('G04/MAU DUONG LAN2/TRUOC SAU.png')),dpi=150,pad=(0,0))
print('CHECK',ck['ok'],'unexpected',ck['unexpected'],'missing',ck['missing'],flush=True)


