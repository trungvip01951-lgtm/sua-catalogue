"""Manifest of separate source readings; it is not curve acceptance."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,datetime
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'))
final=json.loads(Path(S.report('G04/REDPUMP NGHIEM THU BAN CUOI NET PDF.json')).read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
current=S.result(catalog['name']);before=[sha(catalog['source']),sha(current)]
assert before==[catalog['source_SHA256'],final['final_SHA256']]
rows=[];batches=[]
for part in ['A','B V2','C','D']:
 path=root/f'BANG SO DA DOC TRUC TIEP {part}.json'
 d=json.loads(path.read_text(encoding='utf8'))
 assert d['source_SHA256']==before[0] and not d['catalogue_written']
 batches.append(dict(batch=part,path=str(path),SHA256=sha(path),model_rows=len(d['rows'])))
 for row in d['rows']:
  assert sha(row['table_photo'])==row['table_photo_SHA256'] and row['source_file_SHA256']==before[0]
  rows.append(row)
assert len(rows)==196 and len({x['model'] for x in rows})==196
cells=[dict(page=row['page'],family=row['family'],model=row['model'],Q=q,H_source=h,table_photo=row['table_photo'],status='CHƯA THỂ' if h is None else 'ĐÃ ĐỌC NGUỒN – chưa phải nghiệm thu đường') for row in rows for q,h in zip(row['Q'],row['H'])]
assert len(cells)==1931
unknown=[c for c in cells if c['H_source'] is None]
already=[r for r in rows if r['model'] in ['4SL16/18','4SL16/23']]
assert len(already)==2
out=dict(time=datetime.datetime.now().astimezone().isoformat(),source=catalog['source'],source_SHA256=before[0],current=str(current),current_SHA256=before[1],model_rows=len(rows),table_count=len({(r['page'],r['family']) for r in rows}),H_cell_count=len(cells),H_cells_read=len(cells)-len(unknown),unknown_cells=unknown,batches=batches,rows=rows,source_cells=cells,catalogue_written=False,curve_acceptance_new=False,curve_scope='Chỉ hai đường 4SL16/18 và/23 đã được nghiệm thu16mốc ở hồ sơ bản cuối; không đo lại lượt này.194 đường còn lại cần đọc nhãn hiện hành, khóa trục và đo độc lập.',already_accepted_curves_reference=str(S.report('G04/REDPUMP NGHIEM THU BAN CUOI NET PDF.json')),current_name_corrections_reference=str(S.report('G04/NGHIEM THU CHOT CHU SO.json')),excluded_drafts=['BANG SO DA DOC TRUC TIEP B.json không dùng vì2lỗi nhập116/308 và1ô chưa chắc76/78'],status='CHƯA XONG: nguồn số còn3ô chưa chắc và194đường chưa nghiệm thu số.')
Path(fresh(root/'DANH MUC BANG NGUON 196 DONG V1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert before==[sha(catalog['source']),sha(current)]
print(out['table_count'],'tables',out['model_rows'],'models',out['H_cells_read'],'of',out['H_cell_count'],'read;',len(unknown),'unknown; catalogue unchanged',flush=True)
