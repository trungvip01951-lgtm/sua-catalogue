"""Straight source-derived A legs and crossbar, RAM research only."""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import cv2
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'CHU A NET XIEN THANH NGANG NGUON'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
data=read(base/'CHU NGUON IT DOAN CONG VA NET THANG/CHU IT DOAN CONG TU NGUON RAM CHUA NGHIEM THU.json');bank=read(base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json');source=next(r for r in bank['candidates'] if r['key']=='A_4SA16-25');old=next(r for r in data['glyphs'] if r['character']=='A');alpha=np.asarray(source['alpha']);zoom=96;h,w=alpha.shape
up=cv2.resize(np.pad(alpha,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);mask=up>=source['iso_mass_match_threshold'];co,hh=cv2.findContours(mask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);outer=(co[0][:,0,:].astype(float)+.5)/zoom-1;hole=(co[1][:,0,:].astype(float)+.5)/zoom-1
def L(a,b):a=np.asarray(a,float);b=np.asarray(b,float);return [a.tolist(),(a+(b-a)/3).tolist(),(a+2*(b-a)/3).tolist(),b.tolist()]
def C(a,b,c,d):return [list(a),list(b),list(c),list(d)]
segments=[C((3.5078,.664),(3.30,.73),(3.11,.88),(3.00,1.00)),L((3.00,1.00),(.164,8.492)),
 C((.164,8.492),(.19,8.76),(.62,8.84),(1.164,8.523)),L((1.164,8.523),(2.148,6.492)),
 C((2.148,6.492),(2.28,6.20),(2.34,6.16),(2.508,6.164)),L((2.508,6.164),(4.539,6.164)),
 C((4.539,6.164),(4.82,6.17),(5.04,6.26),(5.242,6.507)),L((5.242,6.507),(6.289,8.633)),
 C((6.289,8.633),(6.62,8.85),(7.10,8.68),(7.164,8.492)),L((7.164,8.492),(7.08,7.48)),L((7.08,7.48),(4.804,1.539)),
 C((4.804,1.539),(4.59,1.03),(4.23,.66),(3.5078,.664))]
def sample(ss,n=200):
    pts=[]
    for s in ss:
        p=np.asarray(s);t=np.linspace(0,1,n,endpoint=False)[:,None];pts.extend(((1-t)**3*p[0]+3*(1-t)**2*t*p[1]+3*(1-t)*t**2*p[2]+t**3*p[3]).tolist())
    return np.asarray(pts)
outpts=sample(segments);bb=np.r_[outer.min(0),outer.max(0)];nb=np.r_[outpts.min(0),outpts.max(0)];f=(bb[2:]-bb[:2])/(nb[2:]-nb[:2]);off=bb[:2]-nb[:2]*f;segments=(np.asarray(segments)*f+off).tolist();outpts=sample(segments)
# The source A counter is triangular under JPEG blur. Its measured box and
# area determine the small flat apex; no font substitution is introduced.
hb=np.r_[hole.min(0),hole.max(0)];ha=abs(cv2.contourArea(co[1])/zoom**2);height=hb[3]-hb[1];width=hb[2]-hb[0];topwidth=2*ha/height-width;apex=(3.49-hb[0])/width;cx=hb[0]+width*apex
hpoly=np.array([[cx-topwidth/2,hb[1]],[cx+topwidth/2,hb[1]],[hb[2],hb[3]],[hb[0],hb[3]]]);hsegs=[L(hpoly[i],hpoly[(i+1)%4]) for i in range(4)];hpts=sample(hsegs)
paths=[dict(local_native_xy=outpts.tolist(),cubic_segments_local_native=segments,parent=-1,straight_leg_and_crossbar_segments=[1,3,5,7,9,10],curve_segments=12),dict(local_native_xy=hpts.tolist(),cubic_segments_local_native=hsegs,parent=0,straight_source_counter_edges=True,curve_segments=4)]
im=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);d=ImageDraw.Draw(im)
for p in paths:d.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p['local_native_xy']],fill=255 if p['parent']<0 else 0)
mi=np.asarray(im)>0;cc,ch=cv2.findContours(mi.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);area=float(mi.sum()/zoom**2);hdout=max(float(cKDTree(outer).query(outpts)[0].max()),float(cKDTree(outpts).query(outer)[0].max()));hdhole=max(float(cKDTree(hole).query(hpts)[0].max()),float(cKDTree(hpts).query(hole)[0].max()));raww=np.array([p for p in hpoly]);result=dict(**old)
result['cleaned_contour_paths']=paths;result.update(A_periodic_curved_legs_from36_rejected_visually=True,source_A_diagonal_legs_and_horizontal_crossbar_used=True,
 source_original_outer_bbox=bb.tolist(),source_original_counter_bbox=hb.tolist(),source_original_counter_area_native_px=ha,new_counter_area_native_px=abs(float(cv2.contourArea(hpoly.astype(np.float32)))),
 new_A_area_native_px=area,new_A_vs_source_alpha_area_delta_percent=(area/source['alpha_integral_native_px']-1)*100,
 new_A_outer_max_source_boundary_distance_native_px=hdout,new_A_counter_max_source_boundary_distance_native_px=hdhole,
 new_A_bbox_original_restored=True,new_A_advance_source_unchanged=True,new_A_total_segments=16,new_A_straight_legs_and_bar=True,
 new_A_outer_components=int(sum(ch[0,i,3]<0 for i in range(len(cc)))),new_A_holes=int(sum(ch[0,i,3]>=0 for i in range(len(cc)))),ROOT_and_graphic_acceptance_pending=True)
print('A STRAIGHT AREA%',result['new_A_vs_source_alpha_area_delta_percent'],'HD',hdout,hdhole,'COUNTER',ha,result['new_counter_area_native_px'],'TOPO',result['new_A_outer_components'],result['new_A_holes'],flush=True)
rawim=Image.open(base/'DO BIEN GIU LUONG MUC NGUON/A_4SA16-25 NGUON150dpi.png');vi=Image.new('RGB',((w+2)*24,(h+2)*24),'white');dd=ImageDraw.Draw(vi)
for p in paths:dd.polygon([((x+1)*24,(y+1)*24) for x,y in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
tile=Image.new('RGB',(800,330),'white');tile.paste(rawim.resize((w*24,h*24),Image.Resampling.NEAREST),(10,10));tile.paste(vi,(400,0));tile.save(fresh(root/'A NGUON VA THANH NGANG NET XIEN RAM.png'))
glyphs=[result if r['character']=='A' else r for r in data['glyphs']];font={r['character']:r for r in glyphs};sheet=Image.new('RGB',(1750,2600),'white');dr=ImageDraw.Draw(sheet)
for i,word in enumerate(data['words']):
    x=15.;y=i*200+140.;scale=14
    for c in word['literal']:
        g=font[c]
        for p in g['cleaned_contour_paths']:dr.polygon([(x+xx*scale,y+(yy-9)*scale) for xx,yy in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
        x+=g['native_advance']*scale
sheet.save(fresh(root/'13 TEN CHU NGUON A NET THANG RAM CHUA NGHIEM THU.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==data['source_sha256'] and sha(S.result(name))==data['current_sha256']
Path(fresh(root/'CHU A NET THANG TU NGUON VA13 TEN RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_small_caption_only=True,source_color_RGB=[57,55,57],glyphs=glyphs,words=data['words'],A_previous_curved_legs_rejected=True,no_PDF_font_or_progress_written=True,ROOT_and_graphic_acceptance_pending=True),ensure_ascii=False,indent=2),encoding='utf8')
