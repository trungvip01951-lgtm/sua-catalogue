"""Read only exact source fields rejected by the graphic reviewer."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from PIL import Image, ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
import numpy as np
import json
from g04_perotac_whole_pdf_tools46 import read, sha

name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'CHU TRUC FAIL DOC RIENG NGUON V3'
axispath=base/'CHU TRUC NGUON VA RAM CHI DOC/DON VI DAU CHAM DAU GACH CHEO VA i NGUON V2/CHU TRUC DAU NHO DOC RIENG V2 RAM CHUA NGHIEM THU.json'
doc=read(axispath);E=Editor(S.src(name),backend='fitz');R=Raster(E)
im=max(R.images(7),key=lambda item:item.W*item.H);cv=R.canvas(im);assert str(im.name)=='X7'
fields=['Q US 10','Q US 30','H FEET 200','Q LMIN 150','Q LMIN 250','Q LMIN 350','M3 UNIT','ETA UNIT']
records=[];tiles=[]
for key in fields:
    word=next(row for row in doc['words'] if row['key']==key)
    x0,y0,x1,y1=word['source_native_box'];raw=cv.orig[y0:y1,x0:x1];h,w=raw.shape[:2];sc=24
    src=Image.fromarray(raw).resize((w*sc,h*sc),Image.Resampling.NEAREST)
    proposed=Image.new('RGB',(w*sc,h*sc),'white');p=ImageDraw.Draw(proposed)
    for contour in word['contour_paths']:
        p.polygon([(x*sc,y*sc) for x,y in contour['local_native_xy']],fill=tuple(word['source_RGB']) if contour['parent']<0 else 'white')
    rawpath=Path(fresh(root/(key.replace('/','-')+' NGUON PIXEL THUC.png')));Image.fromarray(raw).save(rawpath)
    tile=Image.new('RGB',(max(900,w*sc*2+80),h*sc+70),'white');d=ImageDraw.Draw(tile)
    d.text((10,5),key+' SOURCE X7 '+str(word['source_native_box']),fill='black')
    tile.paste(src,(0,40));tile.paste(proposed,(w*sc+50,40));tiles.append(tile)
    path=Path(fresh(root/(key.replace('/','-')+' NGUON VA BIEN V3 FAIL.png')));tile.save(path)
    records.append(dict(key=key,literal_source_read=word['literal_source_read'],source_native_box=word['source_native_box'],
        source_raw_pixel_sha256=sha(rawpath),source_RGB_raster_sha256=__import__('hashlib').sha256(raw.tobytes()).hexdigest(),
        proposed_paths=[dict(parent=p['parent'],bbox=np.r_[np.asarray(p['local_native_xy']).min(0),np.asarray(p['local_native_xy']).max(0)].tolist(),
                            cubic_count=len(p.get('cubic_segments_local_native',[]))) for p in word['contour_paths']],
        graphic_status='CHƯA ĐẠT; chỉ đọc nguyên nguồn để sửa',no_font_reuse_from_caption=True))
W=max(tile.width for tile in tiles);H=sum(tile.height+15 for tile in tiles);atlas=Image.new('RGB',(W,H),'white');y=0
for tile in tiles:atlas.paste(tile,(0,y));y+=tile.height+15
atlas.save(fresh(root/'8 FIELD CHU TRUC NGUON VA RAM V3 FAIL.png'))
Path(fresh(root/'8 FIELD NGUON DUNG PIXEL VA CONTROUR V3 CHUA SUA.json')).write_text(json.dumps(dict(source_sha256=sha(S.src(name)),
    canonical_sha256=sha(S.result(name)),axis_report_sha256=sha(axispath),own_Perotac_page8_X7_only=True,records=records,
    no_PDF_font_bank_or_progress_changed=True),ensure_ascii=False,indent=2),encoding='utf8')
E.close();print('SOURCE8 FIELDS',str(root),'READ ONLY',flush=True)
