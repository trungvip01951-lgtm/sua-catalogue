from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.recipes import Job
from catfix.raster import RenderCanvas
from catfix.cs import Instr,Num,Ref
from g15_masked_patch import commit_masked
from catfix import verify
from pathlib import Path
import numpy as np,json,hashlib,pymupdf as fitz

name='Perotac bơm giếng SP_compressed (bản mới).pdf'
I='G05/MAU SUA DUONG/PHAM VI DA BO NET CHUA RO 2/'
O='G05/MAU PDF SUA DUONG/'
rec=json.loads(Path(S.report(I+'TOA DO VA PHUONG PHAP.json')).read_text(encoding='utf8'))
modeltrial=S.report('G05/BO SUNG MA MODEL/'+name);assert Path(modeltrial).exists()
primary_sha=hashlib.sha256(Path(S.dst(name)).read_bytes()).hexdigest();assert primary_sha==rec['before_pdf_sha256']
trial=fresh(S.report(O+name));j=Job(modeltrial,trial,backend='fitz',log_path=fresh(S.report(O+'NHAT KY.json')))
records=[]
for p in rec['panels']:
 pi=p['page']-1;im=j.R.image_at(pi,p['rect']);arrays=np.load(S.report(I+p['family']+'-miếng-anh-600dpi.npz'));orig=arrays['orig'];background=arrays['background']
 cv=RenderCanvas(pi,p['rect'],p['dpi'],orig.copy(),im);cv.work=background.copy();j.R.canvases[('render',pi,tuple(p['rect']))]=cv
 X=np.linalg.inv(im.ctm);invctm=[Num(X[0,0]),Num(X[0,1]),Num(X[1,0]),Num(X[1,1]),Num(X[2,0]),Num(X[2,1])]
 ins=[Instr([],'q'),Instr(invctm,'cm'),Instr([Num(v/255) for v in p['source_color_rgb']],'RG'),Instr([Num(p['width_pt'])],'w'),Instr([Num(0)],'J'),Instr([Num(1)],'j'),Instr([[],Num(0)],'d')]
 for c in p['curves']:
  first=c['segments'][0][0];ins.append(Instr([Num(first[0]),Num(first[1])],'m'))
  for seg in c['segments']:
   ins.append(Instr([Num(v) for pt in seg[1:] for v in pt],'c'))
  ins.append(Instr([],'S'))
  records.append(dict(page=p['page'],curve_model=c['curve_model'],rank=c['rank'],source_actual_label=c['curve_model'],start_page=c['start_page'],end_page=c['end_page'],new_Q=c['new_Q'],width_pt=p['width_pt'],RGB=p['source_color_rgb'],segments=c['segments']))
 ins.append(Instr([],'Q'))
 # Insert paths first, then pixel masks after original image: masks end up BEFORE paths.
 j.E.insert_instrs(im.key,im.index,ins,before=False)
 diff=np.any(background!=orig,axis=2);yy,xx=np.nonzero(diff);rr=cv.rect((int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)))
 allnew=[v for c in p['curves'] for seg in c['segments'] for v in seg]
 nr=(min(v[0] for v in allnew)-.4,min(v[1] for v in allnew)-.4,max(v[0] for v in allnew)+.4,max(v[1] for v in allnew)+.4)
 allowed=(min(rr[0],nr[0]),min(rr[1],nr[1]),max(rr[2],nr[2]),max(rr[3],nr[3]))
 j._add(pi,allowed,p['family']+' chỉ sửa đuôi '+str(len(p['curves']))+' nét nhận dạng chắc; không đổi nhãn/đường chưa rõ','raster-grid-background+vector')
patches=commit_masked(j);j.R.canvases.clear();j._canvases.clear()
source=fitz.open(S.src(name));xref=source.xref_xml_metadata();raw=source.xref_stream(xref) if xref else None;source.close()
if raw is not None:
 xr=j.E.doc.doc.xref_xml_metadata();assert xr;j.E.doc.set_stream(Ref(xr,0),raw)
j.save();ck=j.check(raster=False);print('PDF mẫu',ck['ok'],ck['unexpected'],ck['missing'],flush=True)
assert ck['ok'],ck
allowed={e['page']+1:[e['rect']] for e in j.edits}
outside=verify.outside_pixels(modeltrial,trial,allowed,dpi=200,thr=0,min_size=0)
assert not outside,outside
for p in rec['panels']:
 verify.crop(trial,p['page']-1,p['rect'],600).save(fresh(S.report(O+p['family']+'-PDF-doc-lai.png')))
 verify.page_overview(S.dst(name),trial,p['page']-1,fresh(S.report(O+'TRANG '+str(p['page'])+'.png')),dpi=120)
assert hashlib.sha256(Path(S.dst(name)).read_bytes()).hexdigest()==primary_sha
Path(fresh(S.report(O+'GHI VA KIEM NGOAI VUNG.json'))).write_text(json.dumps(dict(trial=trial,primary_unchanged_sha256=primary_sha,source_sha256=hashlib.sha256(Path(S.src(name)).read_bytes()).hexdigest(),check=ck,outside200=outside,edits=j.edits,records=records,patches=patches,raw_xmp_original_restored=raw is not None),ensure_ascii=False,indent=2,default=lambda v:float(v)),encoding='utf8')
j.close();print('Đã ghi PDF mẫu26 đường vào báo cáo, bản giao chưa đổi',flush=True)
