from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from PIL import Image
import numpy as np,json
from scipy.signal import find_peaks
P='G05/KIEM TOAN TOAN BO/'
bs=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
out=[]
for b in bs:
 if b['family'] not in ['6SP30','6SP60']:continue
 r=b['rect'];s=72/b['dpi'];g=np.array(Image.open(S.report(P+b['family']+'-bieu-do-du-truc.png')).convert('L'),float);xt=np.array(b['xticks']);yt=np.array(b['yticks'])
 qs=[0,6,12,18,24,30,36,42] if b['family']=='6SP30' else [0,6,12,18,24,30,36,42,48,54,60,66,72,78]
 for q in qs:
  x=(np.interp(q,xt[:,0],xt[:,1])-r[0])/s
  profiles=[]
  for dx in [-16,-8,8,16]:
   xc=round(x)+dx;v=255-np.mean(g[:,xc-2:xc+3],axis=1);pk,pr=find_peaks(v,prominence=20,distance=7,height=45)
   hs=[dict(y_px=int(y),H=float(np.interp(r[3]-y*s,yt[:,1],yt[:,0])),score=float(v[y]),prominence=float(pr['prominences'][i])) for i,y in enumerate(pk) if yt[0,1]+1<r[3]-y*s<yt[-1,1]-1]
   profiles.append(dict(dx_px=dx,x_px=xc,peaks=hs))
  out.append(dict(family=b['family'],Q=q,profiles=profiles))
  if q in [0,6,12,36,42,72,78]:print(b['family'],q,[(p['dx_px'],len(p['peaks']),[(round(z['H'],2),round(z['score'])) for z in p['peaks']]) for p in profiles],flush=True)
Path(fresh(S.report(P+'2 DUONG UU TIEN - LAT SAC DO.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
