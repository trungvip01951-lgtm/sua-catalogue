"""Inspect clean / and4 from same-file caption alternatives, no PDF/font write."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from pathlib import Path
from scipy.ndimage import label
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/DAU GACH VA4 NHAN KHAC CUNG FILE'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);page={};cases=[('SLASH_P6_37','/',5,'4SA8/37',[1188,295,1192,304]),('4_P6_37','4',5,'4SA8/37',[1160,295,1167,304]),
    ('SLASH_P6_33','/',5,'4SA8/33',[1188,325,1192,334]),('4_P6_33','4',5,'4SA8/33',[1160,325,1167,334]),
    ('SLASH_P7_30','/',6,'4SA10/30',[315,270,319,279]),('4_P7_30','4',6,'4SA10/30',[283,270,290,279]),
    ('SLASH_P5_30','/',4,'4SA3/30',[294,386,298,395]),('4_P5_30','4',4,'4SA3/30',[266,386,273,395])]
bg=np.array([255.,255.,255.]);ink=np.array([57.,55.,57.]);zoom=48;out=[];tiles=[]
for key,ch,pi,word,box in cases:
    if pi not in page:im=max(R.images(pi),key=lambda z:z.W*z.H);page[pi]=(im,R.canvas(im))
    im,cv=page[pi];x0,y0,x1,y1=box;raw=cv.orig[y0:y1,x0:x1];al=R.alpha_of(raw,bg,ink);up=cv2.resize(np.pad(al,1),((al.shape[1]+2)*zoom,(al.shape[0]+2)*zoom),interpolation=cv2.INTER_LINEAR)
    lo=.05;hi=.85
    for k in range(40):
        mid=(lo+hi)/2
        if (up>=mid).sum()/zoom**2>al.sum():lo=mid
        else:hi=mid
    threshold=(lo+hi)/2;mask=up>=threshold;lab,n=label(mask,np.ones((3,3)));il,nh=label(~np.pad(mask,1),np.ones((3,3)));ext=set(np.r_[il[0],il[-1],il[:,0],il[:,-1]]);holes=[k for k in range(1,nh+1) if k not in ext];ys,xs=np.where(mask);bb=[float(xs.min()/zoom-1),float(ys.min()/zoom-1),float((xs.max()+1)/zoom-1),float((ys.max()+1)/zoom-1)]
    contours,hierarchy=cv2.findContours(mask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);paths=[]
    for j,c in enumerate(contours):paths.append(dict(local_native_xy=((c[:,0,:]+.5)/zoom-1).tolist(),parent=int(hierarchy[0,j,3]),area_native_px=float(cv2.contourArea(c)/zoom**2)))
    step=[float(np.linalg.norm(im.ctm[:2,0])/im.W),float(np.linalg.norm(im.ctm[:2,1])/im.H)]
    rec=dict(key=key,character=ch,source_page=pi+1,source_word=word,source_box=box,source_pixel_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),source_alpha=al.tolist(),
       source_mass_iso_threshold=threshold,source_alpha_integral=float(al.sum()),source_iso_area_native_px=float(mask.sum()/zoom**2),source_mass_delta_percent=float((mask.sum()/zoom**2/al.sum()-1)*100),
       contour_components=int(n),contour_holes=len(holes),contour_bbox_local_native=bb,source_contour_paths=paths,source_step_pt=step,
       contour_width_pt=(bb[2]-bb[0])*step[0],contour_height_pt=(bb[3]-bb[1])*step[1],
       shape_or_same_style_acceptance_pending=True,physical_source_only_no_JPEG_curve_ink_reused_as_font=True,bank_or_PDF_written=False)
    out.append(rec)
    src=Image.fromarray(raw);src.save(fresh(root/(key+' NGUON150dpi.png')));big=src.resize((src.width*24,src.height*24),Image.Resampling.NEAREST);mimg=np.full((*mask.shape,3),255,np.uint8);mimg[mask]=[57,55,57];mi=Image.fromarray(mimg).resize((mask.shape[1]//2,mask.shape[0]//2),Image.Resampling.LANCZOS)
    tile=Image.new('RGB',(560,330),'white');tile.paste(big,(20,30));tile.paste(mi,(290,6));tile.save(fresh(root/(key+' NGUON VA BIEN CHI XEM.png')));tiles.append(tile)
    print(key,'MASS ISO',threshold,'CC/H',n,len(holes),'WIDTH HEIGHT',rec['contour_width_pt'],rec['contour_height_pt'],flush=True)
sheet=Image.new('RGB',(1120,1320),'white')
for k,t in enumerate(tiles):sheet.paste(t,((k%2)*560,(k//2)*330))
sheet.save(fresh(root/'8 UNG VIEN GACH VA4 NGUON NHAN KHAC.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'8 UNG VIEN DAU GACH VA4 CHI DOC.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),
    source_only_Perotac_no_header_font_substitution=True,candidates=out,font_style_not_accepted_by_topology_alone=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
