"""Source-observed straight parts5 and open tail9; RAM candidates, no PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import sys,json,hashlib,numpy as np,copy,cv2
from scipy.ndimage import gaussian_filter,distance_transform_edt
from PIL import Image,ImageDraw
sys.path.insert(0,str(HERE))
from g04_source_observed_mask_contour_math import source_mask_contours
from g04_source_glyph_core_math import hole_centres
from catfix import verify
M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
F=M/'CHU5 9 BIEN QUAN SAT RAM V7';assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
prev=J(M/'CHU5 9 BIEN NGUON LIEN RAM V6B/12 GLYPH RAM V6 CHI THAY BIEN5 9 MOT MAU.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
replacements=[];pad=8;up=8
for ch in ['5','9']:
    old=next(z for z in prev['records'] if z['character']==ch)
    alpha=np.array(old['source_alpha']);A=np.pad(alpha,pad)
    sigma=1.5 if ch=='5' else 1.25;field=gaussian_filter(A,sigma)
    if ch=='5':
        levels=np.full_like(field,.25);ex=(1,0)
        note='Giữ đúng mask nguồn5 p8; giảm sốđoạn ở nét ngang/trái, không đổi kíchthước, không co quỹ mực.'
    else:
        # This is a source-edge hypothesis for the observed concave/open tail,
        # not an optical-mass target. The upper true source counter stays fixed.
        t=np.clip((np.arange(A.shape[0])[:,None]-pad-22)/4,0,1)
        t=t*t*(3-2*t);levels=.3+.1*t;ex=(1,1)
        note='Ứngviên theo khoảng lõm/chân quan sát nguồn9: ngưỡng.30 thân,.40 chân, chuyểnmượt y22..26; khôngclose/co/tôlỗgiả. Chưa stylePASS.'
    mask=field>=levels
    if ch=='9':
        centers=hole_centres(mask)-pad;ref=hole_centres(A>=.085,largest=1)-pad
        assert len(centers)==len(ref)==1 and np.linalg.norm(centers-ref)<4
    loops,area,actual=source_mask_contours(mask,pad=pad,up=up,curvy=ch=='9',epsilon=2.5,radius=1.25,expected=ex)
    weak=cv2.resize((A>=.1).astype('uint8'),(actual.shape[1],actual.shape[0]),interpolation=cv2.INTER_NEAREST).astype(bool)
    missing=float(distance_transform_edt(actual==0)[weak].max()/up*.12)
    extra=float(distance_transform_edt(~weak)[actual>0].max()/up*.12)
    yy,xx=np.where(actual);bbox=[float(xx.min()/up-pad),float(yy.min()/up-pad),float((xx.max()+1)/up-pad),float((yy.max()+1)/up-pad)]
    z=copy.deepcopy(old);coverage=1-63/255
    z.update(vector_optical_area_px=area*coverage,parts=[dict(source_part=1,loops=loops,kind='source_observed_edge_contour',
        source_smoothing_sigma_px600=sigma,source_smoothing_sigma_pt=sigma*.12,levels_by_row=levels[:,0].tolist(),
        close_px600=0,source_mass_px=float(alpha.sum()),loop_area_px=area,relative_math_ink_error=float(area*coverage/alpha.sum()-1),
        actual_vector_bbox600=bbox,topology=list(ex),source_weak_alpha_point1_missing_distance_pt=missing,
        source_weak_alpha_point1_extra_distance_pt=extra,max_contour_fit_error_px600=max(lp['max_contour_fit_error_px600'] for lp in loops),
        source_counter_centres=(hole_centres(mask)-pad).tolist(),candidate_counter_centres=(hole_centres(actual)/up-pad).tolist(),
        no_mass_tightening=True,no_geometry_scale=True,method_note=note,status='ỨNGVIÊN; cầnsoi cỡthật/600 và xét biên JPEG, không fontPASS.')])
    replacements.append(z)
    H,W=alpha.shape;gray=(255-192*actual.astype(float)).clip(0,255).astype('uint8')
    v=Image.fromarray(gray).crop((pad*up,pad*up,(pad+W)*up,(pad+H)*up)).convert('RGB')
    s=Image.fromarray(np.round(255*(1-alpha)).clip(0,255).astype('uint8')).convert('RGB')
    sheet=Image.new('RGB',(1400,650),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(18)
    dr.text((5,5),ch+' nguyênalpha nguồn / RAM V7 - mộtmàu63, chỉứngviên, không PDF2',fill='blue',font=ft)
    sheet.paste(s.resize((W*10,H*10),Image.Resampling.NEAREST),(30,60));sheet.paste(v.resize((W*10,H*10),Image.Resampling.LANCZOS),(500,60))
    dr.text((800,90),'Dáng/lòng/chân: CHƯA CHỐT\nΔmực '+str(round(z['vector_optical_area_px']/z['source_area_px']-1,4))+'\nKhông ép mực\nNguồn150dpiJPEG, biênkhôngchắcfontCAD',fill='blue',font=ft)
    sheet.save(fresh(F/(ch+' BIEN QUAN SAT RAM V7 KHONG PDF.png')))
out=copy.deepcopy(prev);rep={z['character']:z for z in replacements};out['records']=[rep.get(z['character'],z) for z in out['records']]
out.update(RAM_variant='V7_source5_same_mask_fewer_lines;source9_open_observed_tail_no_closing;other10unchanged',
    common_gray=63,opacity=1,no_mass_tightening=True,source_boundary_scope='Fit≤1nativepixel tới contour nguồn được chọn; mép AA/JPEGα.1 là chẩnđoán riêng, có thể vượt1pixel nên không khẳngđịnh mọi biênglyphgốc chínhxác.',
    status='ỨNGVIÊN RAM; không tự fontPASS hoặc thôngqua khácmực.',PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False)
fp=fresh(F/'12 GLYPH RAM V7 BIEN5 9 MOT MAU.json');Path(fp).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print('RAM only',[(z['character'],z['parts'][0]['topology'],z['parts'][0]['actual_vector_bbox600'],z['parts'][0]['max_contour_fit_error_px600']*.12) for z in replacements],flush=True)
print(fp,flush=True)
