"""Read the persisted V5 JSON/SVG independently. Geometry/source only, no images/PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,math,re,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
from g01_wc_clip_math import parse,area,bbox,dist,winding,windall,intersections,intervals
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 DU LIEU HINH HOC'))
ip=O/'g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(ip)=='8fabfa4986246865c6e0931cb4e63881326e58358aa099bfcb6ffb47a108c4fa'
d=json.loads(ip.read_text(encoding='utf8'));old=json.loads(Path(d['base_geometry_file']).read_text(encoding='utf8'))
assert sha(d['base_geometry_file'])==d['base_geometry_sha256']
qa=json.loads((O/'g01_NGHIEM THU HINH HOC V5 DOC LAI SVG VA NGUON.json').read_text(encoding='utf8'))
for p,h in qa['source_guards'].items():assert sha(p)==h
res=[];hp=[]
for g in d['groups']:
    n=g['group'];og=old['groups'][n-1];pol=[parse(q) for q in g['combined_clip_subpaths']];ops=[parse(q) for q in og['combined_clip_subpaths']]
    assert len(pol)==len(ops)
    im=Image.open(g['source_JPEG']);ar=np.array(im.convert('RGB'))
    assert list(im.size)==g['source_canvas_pixel'] and sha(g['source_JPEG'])==g['source_JPEG_sha256']
    boundary=[]
    for k,p in enumerate(pol):
        q=g['combined_clip_subpaths'][k];assert area(p)==q['signed_area_source_pixel2'] and bbox(p)==q['bbox_source_pixel']
        if q['role']=='hole':
            assert np.array_equal(p,ops[k])
            y=float((p[:,1].min()+p[:,1].max())/2);ints=intervals([p],y)
            assert ints
            lo,hi=max(ints,key=lambda v:v[1]-v[0]);pt=[(lo+hi)/2,y]
            assert int(windall(pol,[pt])[0])==0 and int(windall(ops,[pt])[0])==0
            x,y=pt;hp.append({'group':n,'ring':k,'verified_interior_point_source_pixel':pt,'source_RGB':ar[int(math.floor(y)),int(math.floor(x))].tolist(),'V4B_and_V5_nonzero_winding':0,'boundary_exactly_unchanged':True,'mechanical_hole_identity':'Not inferred; original clip contour preserved only'})
            continue
        if np.array_equal(p,ops[k]):continue
        oo=ops[k];hits=intersections(p,oo);edges={i:[0.,1.] for i in range(len(p))}
        for hit in hits:
            i=hit['edge1'];a=p[i];r=p[(i+1)%len(p)]-a;rr=float(np.dot(r,r))
            if rr>0:edges[i].append(float(np.clip(np.dot(np.array(hit['xy'])-a,r)/rr,0,1)))
        count=0;maxoutside=0.;fail=[]
        for i,vals in edges.items():
            ts=sorted(set(round(t,12) for t in vals));a=p[i];b=p[(i+1)%len(p)];r=b-a
            for l,h in zip(ts[:-1],ts[1:]):
                if h-l<1e-11:continue
                point=a+(l+h)/2*r;wi=int(winding(oo,[point])[0]);dd=dist(oo,point);count+=1
                if wi==0 and dd>1e-7:
                    fail.append({'edge':i,'interval':[l,h],'point':point.tolist(),'distance':dd});maxoutside=max(maxoutside,dd)
        assert not fail,(n,k,fail[:5])
        boundary.append({'ring':k,'actual_new_line_subintervals_read':count,'positive_length_outside_old_boundary':len(fail),'max_outside_distance_pixel':maxoutside,'new_boundary_inside_old_or_on_old_boundary':True})
    xml=ET.fromstring(Path(g['geometry_svg']).read_text(encoding='utf8'));node=xml.find('{http://www.w3.org/2000/svg}path');assert node.attrib['fill-rule']=='nonzero'
    tokens=re.findall(r'[MLZ]|[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?',node.attrib['d']);rr=[];buf=[];i=0
    while i<len(tokens):
        op=tokens[i];i+=1
        if op=='Z':buf.append('Z');rr.append(parse({'commands_pixel':buf}));buf=[]
        else:buf.append([op,float(tokens[i]),float(tokens[i+1])]);i+=2
    assert len(rr)==len(pol) and all(np.array_equal(a,b) for a,b in zip(pol,rr))
    assert not xml.findall('.//{http://www.w3.org/2000/svg}image')
    res.append({'group':n,'SVG_read_sha256':sha(g['geometry_svg']),'actual_JSON_SVG_equal':True,'boundary_continuous_subset_checks':boundary,'hole_exact_count':sum(q['role']=='hole' for q in g['combined_clip_subpaths']),'outer_count':sum(q['role']=='outer' for q in g['combined_clip_subpaths'])})
    for w in d['original27_witnesses_read_again']+d['additional_water_and_metal_witnesses']:
        if w['group']!=n:continue
        wn=int(windall(pol,[w['point_source_pixel']])[0]);assert wn==w.get('winding_V5',wn) and (wn!=0)==w['expected_visible']
for p,h in qa['source_guards'].items():assert sha(p)==h
result={'saved_geometry':str(ip),'saved_geometry_sha256':sha(ip),'read_persisted_JSON_and_all_SVG':True,'groups':res,'hole_interior_probes':hp,'original_witnesses_recomputed':len(d['original27_witnesses_read_again']),'additional_witnesses_recomputed':len(d['additional_water_and_metal_witnesses']),'all_source_guards_unchanged':qa['source_guards'],'PDF_or_raster_image_written':False,'TIEN_DO_written':False,'whole_product_appearance':'CHƯA KIỂM RAM V5; no extrapolation from mathematical checks'}
op=Path(fresh(O/'g01_DOC LAI TEP V5 DA LUU - TAP CON LIEN TUC VA 12 KHE.json'))
op.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',op,'SHA',sha(op),flush=True)
print('CHECKS',[(x['group'],x['boundary_continuous_subset_checks']) for x in res],flush=True)
