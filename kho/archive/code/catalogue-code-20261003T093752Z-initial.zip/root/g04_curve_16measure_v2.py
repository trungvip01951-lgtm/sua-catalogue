from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image,ImageDraw
name='Perotac bơm giếng SA_compressed (bản mới).pdf';E=Editor(S.src(name));R=Raster(E);cv=R.canvas(R.images(7)[0])
a=cv.work;g=cv.gray();u0,vtop,u1,vbottom=cv.box((59.5,324.0,359,513))
def frame(v):
    rr=np.arange(v-5,v+6);cnt=(g[rr,u0+10:u1-10]<150).sum(1)
    good=rr[cnt>(u1-u0-20)*.8];assert len(good)
    return float(np.average(good,weights=cnt[cnt>(u1-u0-20)*.8]))
top=frame(vtop);bottom=frame(vbottom)
ticks=[(100,134.875),(150,172.07),(200,209.15),(250,246.47),(300,283.79)]
coef=np.polyfit([t[0] for t in ticks],[t[1] for t in ticks],1)
res=max(abs(np.polyval(coef,q)-x) for q,x in ticks);assert res<.2
q=21;xpt=float(np.polyval(coef,q*1000/60));u=cv.to_px(xpt,400)[0]
col=g[int(top)+3:int(bottom)-2,int(round(u))-1:int(round(u))+2]
level=col.min(1);ys=np.where(level<215)[0]+int(top)+3
groups=[]
for y in ys:
    if not groups or y>groups[-1][-1]+1:groups.append([int(y)])
    else:groups[-1].append(int(y))
peaks=[]
for gr in groups:
    if len(gr)>5:continue
    # Loại đúng các nét kẻ ngang / đáy ô tiêu đề, kiểm trên toàn chiều ngang.
    horizontal=False
    for y in gr:
        xx=np.where(g[y,u0:u1]<225)[0]
        runs=np.split(xx,np.where(np.diff(xx)>1)[0]+1) if len(xx) else []
        if runs and max(len(z) for z in runs)>(u1-u0)*.20:horizontal=True
    if horizontal:continue
    weight=255-g[gr,int(round(u))-1:int(round(u))+2].min(1)
    v=float(np.average(gr,weights=weight));head=(bottom-v)/(bottom-top)*150
    peaks.append(dict(v=v,H=head,span=gr))
print('axis',dict(top=top,bottom=bottom,xpt=xpt,u=u,res=res),'peaks',peaks,flush=True)
box=cv.box((59.5,324,359,513));im=Image.fromarray(a[box[1]:box[3],box[0]:box[2]]).resize(((box[2]-box[0])*2,(box[3]-box[1])*2))
dr=ImageDraw.Draw(im);xx=(u-box[0])*2;dr.line([(xx,0),(xx,im.height)],fill=(255,100,0),width=2)
for p in peaks[:4]:
    yy=(p['v']-box[1])*2;dr.ellipse((xx-5,yy-5,xx+5,yy+5),outline=(255,0,0),width=2)
im.save(fresh(S.report('G04/DO 4SA16 Q21 LAN2.png')))
out=dict(file=name,page=8,Q=q,ticks_lmin=ticks,x_fit=list(coef),x_res_pt=res,top_v=top,bottom_v=bottom,peaks=peaks,status='ĐO 1 ĐIỂM / ĐƯỜNG, CHƯA NGHIỆM THU ĐƯỜNG',uncertainty_m=150/(bottom-top),measured=[dict(model='4SA16/23',Q=21,H_table=50,H_curve=peaks[1]['H'],difference_m=peaks[1]['H']-50,tolerance_m=1,result='CHƯA ĐẠT'),dict(model='4SA16/18',Q=21,H_table=39,H_curve=peaks[3]['H'],difference_m=peaks[3]['H']-39,tolerance_m=1,result='CHƯA ĐẠT')])
assert len(peaks)==13,('Số đường/đỉnh',len(peaks))
Path(fresh(S.report('G04/DO 4SA16 Q21 LAN2.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()




