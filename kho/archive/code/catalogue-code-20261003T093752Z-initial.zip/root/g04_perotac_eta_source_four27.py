"""Four C2 source-geometry segments; frame-occluded initial eta centres uncertain."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.interpolate import BSpline
from scipy.optimize import least_squares
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=base/'ETA4 DOAN C2 NGUON VA DAU LAN KHUNG'
m=json.loads((base/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'));pts=m['eta_source']['source_native_observed_points'];u=np.array([r['u'] for r in pts],float);v=np.array([r['v'] for r in pts],float)
assert len(u)==558
clean=u>=138;lo,hi=float(u[0]),float(u[-1]);nc=7
def spline(z):
    internal=z[:3];knots=np.r_[[lo]*4,internal,[hi]*4];coeff=np.r_[v[0],z[3:],v[-1]];return BSpline(knots,coeff,3,extrapolate=False)
initknots=[210.,390.,585.];kn=np.r_[[lo]*4,initknots,[hi]*4];B=BSpline.design_matrix(u,kn,3).toarray();coeff=np.linalg.lstsq(B[clean,1:-1],v[clean]-B[clean,0]*v[0]-B[clean,-1]*v[-1],rcond=None)[0];z0=np.r_[initknots,coeff]
lower=[155,300,490]+[575.]*5;upper=[275,480,650]+[685.]*5
fit=least_squares(lambda z:spline(z)(u[clean])-v[clean],z0,bounds=(lower,upper),loss='soft_l1',f_scale=.22,max_nfev=3000,xtol=1e-10,ftol=1e-10,gtol=1e-10);spl=spline(fit.x);vv=spl(u);err=vv-v;breaks=np.r_[lo,fit.x[:3],hi];segments=[]
for a,b in zip(breaks,breaks[1:]):
    dx=(b-a)/3;p0=[float(a),float(spl(a))];p3=[float(b),float(spl(b))];p1=[float(a+dx),float(p0[1]+spl.derivative()(a)*dx)];p2=[float(b-dx),float(p3[1]-spl.derivative()(b)*dx)];segments.append(dict(start=p0,control1=p1,control2=p2,end=p3))
du=spl.derivative();xs=np.linspace(lo,hi,20000);dy=du(xs);sign=np.sign(dy);roots=[]
for j in range(len(xs)-1):
    if sign[j]<0 and sign[j+1]>=0:roots.append(float((xs[j]+xs[j+1])/2))
checks=dict(source_observed_count=558,source_clear_body_count=int(clean.sum()),source_head_frame_or_first_edge_uncertain_count=int((~clean).sum()),
 clear_source_points_within_one_native_px=int((abs(err[clean])<=1).sum()),clear_source_points_within_half_native_px=int((abs(err[clean])<=.5).sum()),
 clear_source_abs_error_median_native_px=float(np.median(abs(err[clean]))),clear_source_max_abs_error_native_px=float(max(abs(err[clean]))),
 whole558_abs_error_max_native_px=float(max(abs(err))),C2_true=True,geometry_eta_single_peak_count=len(roots),geometry_peak_native_u=roots,
 exact_source_eta_values='UNKNOWN',source_efficiency_table_absent=True)
head=[]
for r,pv,d in zip(pts,vv,err):
    if r['u']<138:head.append(dict(source_u=r['u'],original_observed_v=r['v'],original_component_v_interval=[r['lo'],r['hi']],original_component_strength=r['strength'],original_component_width=r['width'],
       smooth_geometry_v=float(pv),delta_from_mixed_trace_native_px=float(d),true_eta_center='UNKNOWN',
       trace_pixel_support_not_equal_vector_center=True,reason='Khung dưới và nénJPEG lẫn vào mực/điểm đầu chỉ là một điểm quầng màu; không ép tâm nhiễu thành tâmη.'))
bad=[dict(source_u=float(x),observed_v=float(y),smooth_v=float(pv),delta_native_px=float(d)) for x,y,pv,d,c in zip(u,v,vv,err,clean) if c and abs(d)>1]
doc=dict(read_only=True,source_sha256=m['source_sha256'],current_sha256=m['current_sha256'],only_original_Perotac_X7_source=True,
    Redpump_eta551_never_read_or_used=True,source_knots=spl.t.tolist(),source_coefficients=spl.c.tolist(),source_four_C2_bezier_segments_native=segments,
    source_endpoint_coordinate_127_674_kept_as_observed_edge_not_certain_center=True,source_last_observed_endpoint_kept=True,no_extension_left_or_right_of_source_observed_u=True,
    source_558_original_points_preserved=pts,source_clear_body_checks=checks,head_source_uncertainty=head,clear_body_points_outside_one_native_px=bad,
    numeric_eta_acceptance='UNKNOWN',QH_table_not_used_for_eta=True,PDF_font_or_progress_written=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==m['source_sha256'] and sha(S.result(name))==m['current_sha256']
Path(fresh(root/'ETA4 BEZIER C2 VA558 DIEM NGUON CHUA CHOT.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
raw=Image.open(base/'NGUON TRANG08 NGUYEN150dpi.png');crop=raw.crop((118,577,749,682)).resize((2524,420),Image.Resampling.NEAREST);dr=ImageDraw.Draw(crop);dr.line([((x-118)*4,(float(spl(x))-577)*4) for x in np.arange(lo,hi+.001,.125)],fill=(190,35,35),width=1);crop.save(fresh(root/'ETA NGUON VA4 DOAN C2 SOI TAM.png'))
headimg=raw.crop((120,660,159,679)).resize((624,304),Image.Resampling.NEAREST);dr=ImageDraw.Draw(headimg);dr.line([((x-120)*16,(float(spl(x))-660)*16) for x in np.arange(lo,159,.1)],fill=(190,35,35),width=1);headimg.save(fresh(root/'DAU ETA NGUON VA KHUNG SOI RIENG.png'))
print('ETA4 CHECKS',checks,'KNOTS',breaks.tolist(),'CLEAR BAD',bad[:20],flush=True)
