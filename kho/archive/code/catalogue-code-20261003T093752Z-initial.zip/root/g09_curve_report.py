from catwork import start,fresh,row
from pathlib import Path
import json,hashlib,datetime,csv
from PIL import Image
S,D,N=start()
from catfix import verify
from catfix.vector import Editor
old=json.loads(Path(S.report('G09/DO DUONG/DOI CHIEU LAN1.json')).read_text(encoding='utf8'))
new=json.loads(Path(S.report('G09/DO DUONG/DOI CHIEU MAU1.json')).read_text(encoding='utf8'))
assert new['pass_curves']==new['count_curves']==124 and new['pass_rows']==new['count_rows']==372
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
qa=[json.loads(Path(S.report(f'G09/NGHIEM THU DUONG CUOI {s}.json')).read_text(encoding='utf8')) for s in ['Perotac','Redpump']]
proof=[]
for q in qa:
    assert sha(q['final'])==q['final_sha256'] and sha(q['source'])==q['source_sha256']
    A=Editor(q['sample']);B=Editor(q['final'])
    same=[A.doc.page_content(i)==B.doc.page_content(i) for i in range(7)];assert all(same)
    A.close();B.close();proof.append(dict(file=q['file'],sample_content_identical_to_final=same,final_sha256=q['final_sha256']))
Path(fresh(S.report('G09/NGHIEM THU DUONG CHOT.json'))).write_text(json.dumps(dict(time=datetime.datetime.now().astimezone().isoformat(),checks=qa,proof=proof,before=dict(curves_pass=old['pass_curves'],curves_total=124,checks_pass=old['pass_rows'],checks_total=372),after=dict(curves_pass=124,curves_total=124,checks_pass=372,checks_total=372),available_scope=new['scope'],all_source_defined_checks_pass=True,visual='ĐẠT: đã soi cả 2 ảnh trước/sau mẫu; nét/nhãn/bảng và ngoài vùng giữ nguyên'),ensure_ascii=False,indent=2),encoding='utf8')

table_rows=[];changed=[]
for a,b in zip(old['curves'],new['curves']):
    assert a['file']==b['file'] and a['model']==b['model'] and a['frequency']==b['frequency']
    if not a['ok']:
        changed.append((a,b))
        diffs='; '.join(f'{r["kind"]}: {r["diff"]:+.3f} {r["unit"]}, giới hạn {r["limit"]:.3f}' for r in a['checks'] if not r['ok'])
        qr,hr,qm,hm=b['table']
        table_rows.append(row(a['model']+' / '+str(a['frequency'])+' Hz',a['file'],a['page'],'Chỉnh nét gốc theo các neo bảng, giữ H cuối nguồn',diffs,f'H đầu {hm}; Q/H định mức {qr}/{hr}; Q cuối {qm}','ĐẠT','So sanh G09 Bieu do.png; G09/DO DUONG/DOI CHIEU MAU1.json'))
report=fresh(S.report('BAO CAO G09 BO SUNG BIEU DO.md'));fresh(S.report('BAO CAO G09 BO SUNG BIEU DO.json'))
verify.write_report(table_rows,report,title='BÁO CÁO BỔ SUNG NHÓM G09 – Nghiệm thu biểu đồ KTZ/LH')
im0=Image.open(S.report('G09/DUONG MAU LAN1/TRUOC SAU Perotac.png')).convert('RGB');im1=Image.open(S.report('G09/DUONG MAU LAN1/TRUOC SAU Redpump.png')).convert('RGB')
im=Image.new('RGB',(im0.width+im1.width+24,max(im0.height,im1.height)),(255,255,255));im.paste(im0,(0,0));im.paste(im1,(im0.width+24,0));im.save(fresh(S.report('So sanh G09 Bieu do.png')))

cols=['file','model','frequency','page','chart','kind','Q','H_table','H_curve','Q_curve','diff','limit','unit','ok','note']
with open(fresh(S.report('G09/DO DUONG/TAT CA 372 DOI CHIEU.csv')),'w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');writer.writeheader();writer.writerows(new['rows'])
lines=['# BÁO CÁO BỔ SUNG NHÓM G09 – Nghiệm thu biểu đồ KTZ/LH','',
    'Đã đối chiếu đủ 124 đường (62 đường/tệp), đạt 372/372 phép kiểm tại các mốc có số trong bảng. Đã sửa 32 đường (16 đường/tệp). Sáu việc chữ/số đã đạt tiếp tục được giữ nguyên.','',
    '| # việc / đường | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|']
for r in table_rows:lines.append('| '+' | '.join(str(r[k]).replace('|','/') for k in ['stt','file','page','old','new','item','result','evidence'])+' |')
lines += ['', 'Tổng phần chỉnh đường: 32 đường · ĐẠT 32 · CHƯA ĐẠT 0 · CHƯA THỂ XÁC MINH 0 tại các mốc bảng có số.',
    '', 'Phạm vi và cách đo:',
    '- KTZ: 15 mẫu × 2 tần số = 30 đường/tệp, trang 3–4. LH: 16 mẫu × 2 tần số = 32 đường/tệp, trang 7. Tổng 124 đường trên 2 PDF.',
    '- Đọc trực tiếp các bảng của cả Perotac và Redpump. Ô có dấu / được tách đúng thứ tự 50/60 Hz. Đối chiếu 3 mốc mỗi đường: cột áp đầu đường so cột áp tối đa; Q/H định mức; lưu lượng cuối so lưu lượng tối đa.',
    '- Dùng tọa độ các nét vẽ thật trong PDF, tách từng đường theo nhãn và chuỗi nét nối. Căn trục bằng các vạch lưới có số, kiểm sai số khớp trục dưới 0.12 điểm PDF. Giới hạn từng phép kiểm là max(1 đơn vị, 2% số bảng). Các giá trị trước/sau, số chốt và tọa độ đầu/cuối có đủ trong hai tệp DOI CHIEU LAN1.json và DOI CHIEU MAU1.json.',
    '- Trước sửa: 92/124 đường đạt đủ 3 mốc; 338/372 phép kiểm đạt. Sau sửa: 124/124 đường đạt đủ các mốc có số, 372/372 phép kiểm đạt. Các chỗ sát ngưỡng như LH6110 50 Hz, LH855 50/60 Hz cũng được chỉnh đúng điểm định mức để không còn phụ thuộc phần dư sát ngưỡng.',
    '- Giữ nét nguồn và chỉnh nhỏ theo các neo bảng. Hàm chuyển mượt φ(t)=3t²−2t³ phân bố độ sửa giữa đầu đường, điểm định mức và cuối đường; chèn đúng điểm Q/H định mức vào nét gốc. Dùng catfix.replace_path giữ từng đối tượng nét, màu, độ dày và trạng thái vẽ gốc. Không thay phông, không làm lại trang bằng ảnh.',
    '', 'Giới hạn dữ liệu nguồn – CHƯA THỂ XÁC MINH:',
    '- Bảng chỉ cho các mốc/giới hạn, không có dãy Q–H đầy đủ. Chưa thể chứng minh độ đúng của toàn bộ các điểm trung gian.',
    '- Bảng không ghi H tại Q tối đa. Không giả định H cuối bằng 0; giữ H cuối đo từ nét nguồn, chỉ chỉnh Q cuối theo lưu lượng tối đa trong bảng. Đây là giữ hình thức nguồn, không phải một số cột áp được nhà sản xuất xác nhận.',
    '- Hai nét phụ rời rất nhỏ ở biểu đồ KTZ 60 Hz, gần Q=150, dài tổng dưới 0.11 điểm PDF, không nối với đường chính; giữ nguyên, không dùng chúng để suy ra điểm cuối của mẫu bơm.',
    '', 'Nghiệm thu độc lập:',
    '- Cả 2 bản mẫu đã được đo lại từ nét sau lưu, rồi soi ảnh trước/sau. Bản cuối cùng tên trùng toàn bộ luồng nội dung 7 trang với mẫu đạt và trùng toàn bộ điểm ảnh ở 150 điểm ảnh/inch.',
    '- Khổ, độ xoay và số trang giữ nguyên; điểm ảnh ngoài vùng biểu đồ rỗng (150 điểm ảnh/inch, ngưỡng 12, tối thiểu 1 điểm ảnh).',
    '- Toàn bộ đối tượng nét không sửa giữ nguyên; mọi lệnh ngoài phần dựng nét giữ nguyên, bao gồm trạng thái màu/độ dày, ảnh, chữ thật và đường kẻ. Nhãn biểu đồ, bảng số, logo, ảnh gốc/mặt nạ/vị trí ảnh, XMP (thông tin mở rộng của PDF), thông tin tài liệu, liên kết và mục lục giữ nguyên.',
    '- Trang 1, 2, 5, 6 giữ nguyên luồng nội dung so bản chữ đã đạt; các sửa #71–76 và các mục giữ nguyên #144/#162 tiếp tục được bảo toàn. Hai tệp đầu vào không thay đổi mã SHA-256 (mã nhận diện dữ liệu tệp).',
    '- Bản chỉ sửa chữ/số do phiên tạo được giữ trong G09/BAN CHU SO DA DAT. Chỉ chuyển đúng tệp này sau khi kiểm đường dẫn tuyệt đối nằm trong thư mục đầu ra, khớp mã băm và đích lưu chưa tồn tại.',
    '', 'Cần anh quyết: không có yêu cầu duyệt mới; anh đã cấp quyền xử lý thêm và tự nghiệm thu đường sai qua AI điều phối.',
    '', 'Bằng chứng và tệp giao:',
    '- So sanh G09 Bieu do.png: ảnh mẫu trước/sau của cả 2 PDF.',
    '- G09/DO DUONG/TAT CA 372 DOI CHIEU.csv: đủ 372 phép đo, đơn vị, giới hạn, kết quả.',
    '- G09/DO DUONG/DOI CHIEU LAN1.json và DOI CHIEU MAU1.json: đủ mô hình đường, bảng số nguồn, Q/H và tọa độ đầu/cuối.',
    '- G09/NGHIEM THU DUONG CHOT.json và NGHIEM THU DUONG CUOI Perotac/Redpump.json: kiểm cấu trúc, điểm ảnh, ảnh/nhãn/bảng, thông tin PDF và mã tệp.']
lines += ['- '+q['final'] for q in qa]
Path(report).write_text('\n'.join(lines)+'\n',encoding='utf8')
S.progress('G09','XONG','6/6 chữ/số ĐẠT; đã nghiệm thu 124 đường tại đủ 372 mốc bảng có số, sửa 32 đường, 372/372 đạt; nét/ảnh/nhãn/bảng/XMP và ngoài vùng đạt. Bảng thiếu H ở Q tối đa và dãy Q-H trung gian: chưa xác minh những số không có nguồn.')
print(report);print('G09 curves: 124/124 tại các mốc có số; 372/372 phép kiểm, 32 đường đã sửa.')
