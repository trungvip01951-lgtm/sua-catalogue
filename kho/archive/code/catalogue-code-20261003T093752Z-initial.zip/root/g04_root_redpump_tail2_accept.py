"""ROOT kiểm mẫu2 đuôi /25 trực tiếp; không sửa PDF hay bản giao."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
import numpy as np
import pymupdf as fitz
from PIL import Image

name='Redpump gieng SL_compressed (bản mới).pdf'
source=Path(S.src(name));current=Path(S.result(name))
trial=Path(S.report('G04/REDPUMP 25 MAU SUA DUOI2'))/name
root=Path(S.report('G04/ROOT REDPUMP NGHIEM THU DUOI25 MAU2 V2'))
assert not root.exists();root.mkdir(parents=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(source),sha(current),sha(trial)]
assert before==['a01b7f84c0ebb4960a6b9601d98a04420c4c00f8bf1d48a23e1bde4e8b084038',
               'b7c1febb60e0ebfcb88d233f87d8e10d0c0e5886214acc98e6f5cc2b2d32d435',
               '050ada2d81ecc3c2bf5f308687ebaed7da7c4647794de1b799658490758d7586']
ax,bx,ay,by=12.332833970672802,59.078002472685455,1.2403508488278085,321.690994341148
allowed_bottom=(277.8994905692927,385.4497364591755,327.5521650948821,417.4175331510931)

def normalize(v):
    if isinstance(v,(fitz.Point,fitz.Rect,fitz.Quad)):return list(v)
    if isinstance(v,dict):return {k:normalize(z) for k,z in v.items() if k not in ['seqno']}
    if isinstance(v,(list,tuple)):return [normalize(z) for z in v]
    return v

def pix(pg,dpi,clip=None):
    p=pg.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=clip,alpha=False)
    return np.frombuffer(p.samples,np.uint8).reshape(p.height,p.width,p.n)[:,:,:3].copy(),p

def bez(p,t):return (1-t)**3*p[0]+3*(1-t)**2*t*p[1]+3*(1-t)*t*t*p[2]+t**3*p[3]

def at_x(p,x):
    lo,hi=0.,1.
    assert p[0,0]-.001<=x<=p[-1,0]+.001
    for _ in range(65):
        mid=(lo+hi)/2
        if bez(p,mid)[0]<x:lo=mid
        else:hi=mid
    return bez(p,(lo+hi)/2)

page_records=[];ink_records=[]
with fitz.open(source) as src, fitz.open(current) as cur, fitz.open(trial) as new:
    assert len(cur)==len(new)==len(src)==11
    assert cur.metadata==new.metadata and cur.get_xml_metadata()==new.get_xml_metadata()
    assert cur.get_toc(simple=False)==new.get_toc(simple=False)
    for pi,(p,n) in enumerate(zip(cur,new)):
        assert p.rect==n.rect and p.rotation==n.rotation and p.get_links()==n.get_links()
        assert p.get_fonts(full=True)==n.get_fonts(full=True)
        for font in p.get_fonts(full=True):
            assert cur.extract_font(font[0])==new.extract_font(font[0])
        for im in p.get_images(full=True):
            assert cur.xref_stream_raw(im[0])==new.xref_stream_raw(im[0]),(pi+1,im[0])
            if im[1]:assert cur.xref_stream_raw(im[1])==new.xref_stream_raw(im[1])
            assert p.get_image_rects(im[0],transform=True)==n.get_image_rects(im[0],transform=True)
        od=p.get_drawings();nd=n.get_drawings()
        if pi==7:
            assert len(nd)==len(od)+1
            assert [normalize(z) for z in od]==[normalize(z) for z in nd[:-1]], 'Các đường trước thay đổi'
            path=nd[-1];assert len(path['items'])==1 and path['items'][0][0]=='c'
            points=np.array([[pt.x,n.rect.height-pt.y] for pt in path['items'][0][1:]],float)
            true_anchors=[]
            for q,h in [(18,75),(21,54)]:
                pos=at_x(points,ax*q+bx);got=(pos[1]-by)/ay
                assert abs(got-h)<.0001,(q,h,got)
                true_anchors.append(dict(Q=q,H_table=h,H_actual_path=got,
                    visible_new_ink=q!=18,reason='TạiQ18 giữ mực cũ; clip nét mới bắt đầu18,023575.' if q==18 else 'Điểm cuối hình học đúng và phần đuôi nhìn thấy.'))
            extended=n.get_drawings(extended=True)
            clips=[z for z in extended if z.get('type')=='clip']
            assert clips,'thiếu clip'
            actual_clip=clips[-1]['scissor']
            assert abs(actual_clip.x1-(ax*21+bx))<.001
            assert abs(actual_clip.x0-(ax*18.02357521358278+bx))<.001
            # Kiểm mực đang nhìn thấy, không chỉ tọa độ của nét nằm dưới nền.
            rect=fitz.Rect(allowed_bottom[0],n.rect.height-allowed_bottom[3],allowed_bottom[2],n.rect.height-allowed_bottom[1])
            ar,rp=pix(n,600,rect);scale=600/72
            for q in np.linspace(18.09,20.94,41):
                target=at_x(points,ax*q+bx)
                xx=int(round(target[0]*scale))-rp.x
                yy=int(round((n.rect.height-target[1])*scale))-rp.y
                profile=ar[max(0,yy-6):min(len(ar),yy+7),xx].astype(float)
                contrast=255-profile@np.array([.299,.587,.114])
                assert contrast.max()>80,(q,'nét mới bị lớp nền che')
                ink_records.append(dict(Q=float(q),max_actual_ink_contrast=float(contrast.max())))
            # Chụp riêng chỗ nối và cuối từ đúng mẫu đã kiểm.
            for label,bb in [('NOI',(278,410,289,418)),('CUOI',(311,385,329,395))]:
                clip=fitz.Rect(bb[0],n.rect.height-bb[3],bb[2],n.rect.height-bb[1])
                px=n.get_pixmap(matrix=fitz.Matrix(600/72,600/72),clip=clip,alpha=False)
                px.save(fresh(root/f'{label} MAU2 PDF THAT 600dpi.png'))
            # Source/current nhãn /25 thực chưa đổi: rút lại suy đoán 28→25.
            label_box=fitz.Rect(130,p.rect.height-500,166,p.rect.height-491)
            for dpi in [150,450,600]:
                sa,_=pix(src[7],dpi,label_box);ca,_=pix(p,dpi,label_box);na,_=pix(n,dpi,label_box)
                assert np.array_equal(sa,ca) and np.array_equal(ca,na)
        else:
            assert normalize(od)==normalize(nd)
        ca,cp=pix(p,200);na,_=pix(n,200)
        diff=np.any(ca!=na,axis=2);mask=np.zeros(diff.shape,bool)
        if pi==7:
            x0,y0,x1,y1=allowed_bottom;bb=fitz.Rect(x0,p.rect.height-y1,x1,p.rect.height-y0)
            left=max(0,int(np.floor(bb.x0*200/72))-cp.x);right=min(mask.shape[1],int(np.ceil(bb.x1*200/72))-cp.x)
            top=max(0,int(np.floor(bb.y0*200/72))-cp.y);bottom=min(mask.shape[0],int(np.ceil(bb.y1*200/72))-cp.y)
            mask[top:bottom,left:right]=True
        outside=int((diff&~mask).sum());assert outside==0,(pi+1,outside)
        page_records.append(dict(page=pi+1,original_font_images_raw_masks_and_matrices_held=True,
                                 old_paths_and_styles_held=True,outside_allowed_200dpi_changed_pixels=outside))
    # Tiền tố Q<18 toàn dải đồ thị và7 cột nguồn không đổi ở600dpi.
    prefix=fitz.Rect(bx-.5,cur[7].rect.height-(by+ay*151),ax*18+bx-.05,cur[7].rect.height-by+.5)
    pp,_=pix(cur[7],600,prefix);npix,_=pix(new[7],600,prefix)
    assert np.array_equal(pp,npix),'tiền tố thay đổi'
assert before==[sha(source),sha(current),sha(trial)]
result=dict(source=str(source),current=str(current),trial=str(trial),hashes=before,
            model='4SL16/25',true_anchors=true_anchors,visible_new_Q_domain=[18.02357521358278,21],
            ink_read_points=ink_records,pages=page_records,prefix_600dpi_changed_pixels=0,
            old_curves_23_18_geometry_and_style_held=True,raw_metadata_and_fonts_held=True,
            source_current_sample_label_region_exact_150_450_600dpi=True,
            corrected_label_history='Nhãn p8 không đổi nguồn→hiện hành→mẫu. ROOT rút lại suy đoán cũ /28 đã đổi /25; CAN44 thực ở p7 tiêu đề4SL10/4SL12.',
            original_or_canonical_not_written=True,status='MẪU2 ĐẠT phép đọc độc lập; cần ROOT xem ảnh chỗ nối/cuối và chốt giới hạn suy màu/nét ảnh nén')
Path(fresh(root/'ROOT DOC LAI MAU2 DUOI25.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(dict(model=result['model'],anchors=true_anchors,visible_ink_checks=len(ink_records),outside_pixels=0,
                     prefix_pixels=0,corrected_label_history=result['corrected_label_history'],status=result['status']),ensure_ascii=False),flush=True)
