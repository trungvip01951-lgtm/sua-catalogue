"""Reject physical sample 2; report measurements, keep delivered PDF unchanged."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib,csv

O='G05/6SP30 HAI MUOI CHIN MOC/MAU 2/'
I='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
d=json.loads(Path(S.report(I+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'))
r=json.loads(Path(S.report(O+'TOA DO VA LOP NGUON.json')).read_text(encoding='utf8'))
layers=np.load(S.report(O+'CAC LOP 600dpi.npz'));a=layers['orig'];base=layers['base'];bg=layers['background'];new=layers['preview'];font=layers['fontmask'];nt=layers['native_tube']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(d['current_path'])==d['current_sha256'] and sha(d['source_path'])==d['source_sha256']
E=Editor(d['source_path']);R=Raster(E);im=R.images(4)[0];cv=R.canvas(im);rect=r['rect'];s=72/600;H,W=a.shape[:2];xs=rect[0]+(np.arange(W)+.5)*s;ys=rect[3]-(np.arange(H)+.5)*s
iu=np.clip(np.floor((xs-im.ctm[2,0])/im.ctm[0,0]*im.W).astype(int),0,im.W-1);iv=np.clip(np.floor((1-(ys-im.ctm[2,1])/im.ctm[1,1])*im.H).astype(int),0,im.H-1)
tube=nt[iv[:,None],iu[None,:]];gb=base.astype(float)@np.array([.299,.587,.114]);gn=bg.astype(float)@np.array([.299,.587,.114]);unwanted=tube&~font&(gb>248)&(gn<240)
dark=dict(blank_pixels_before_source_stroke_removal=int((tube&~font&(gb>248)).sum()),blank_pixels_darkened_below240_before_drawing_new_strokes=int(unwanted.sum()),maximum_added_gray_drop=float(np.max((gb-gn)[unwanted])),source_reconstruction_not_accepted=True)
assert dark['blank_pixels_darkened_below240_before_drawing_new_strokes']>0
def pixels(box):
 x0,y0,x1,y1=box;p0=cv.to_page(x0,y0);p1=cv.to_page(x1,y1);xx0=int(np.floor((p0[0]-rect[0])/s));xx1=int(np.ceil((p1[0]-rect[0])/s));yy0=int(np.floor((rect[3]-p0[1])/s));yy1=int(np.ceil((rect[3]-p1[1])/s));return [max(0,xx0),max(0,yy0),min(W,xx1),min(H,yy1)]
proof=[]
for suffix,body in r['native_font_body_rows'].items():
 suffix=int(suffix);top,bot=body;box=[1132,top-3,1187,bot+4];x0,y0,x1,y1=pixels(box);before=a[y0:y1,x0:x1];after=new[y0:y1,x0:x1];fm=font[y0:y1,x0:x1];diff=np.any(before!=after,axis=2);locked_equal=bool(np.array_equal(before[fm],after[fm]));assert locked_equal
 pic=Image.new('RGB',(before.shape[1]*2,before.shape[0]+28),'white');pic.paste(Image.fromarray(before),(0,28));pic.paste(Image.fromarray(after),(before.shape[1],28));draw=ImageDraw.Draw(pic);draw.text((8,7),'TRUOC - '+str(suffix),fill='black');draw.text((before.shape[1]+8,7),'MAU 2 CHUA DAT',fill='black');fn=S.report(O+'NHAN TRUOC SAU/6SP30-'+str(suffix)+'.png');pic.save(fresh(fn))
 proof.append(dict(source_label='6SP30-'+str(suffix),native_box=box,locked_source_RGB_equal=locked_equal,locked_render_pixels=int(fm.sum()),whole_field_changed_pixels=int(diff.sum()),unlocked_fringe_cannot_be_certified=bool(diff.any()),evidence=fn))
x0,y0,x1,y1=pixels([1132,494,1187,580]);low_equal=bool(np.array_equal(a[y0:y1,x0:x1],new[y0:y1,x0:x1]));assert low_equal
lowpic=Image.new('RGB',((x1-x0)*2,y1-y0+28),'white');lowpic.paste(Image.fromarray(a[y0:y1,x0:x1]),(0,28));lowpic.paste(Image.fromarray(new[y0:y1,x0:x1]),(x1-x0,28));ImageDraw.Draw(lowpic).text((8,7),'8 NHAN THAP: TRUOC | MAU 2',fill='black');lowpic.save(fresh(S.report(O+'NHAN TRUOC SAU/8 NHAN THAP GIU NGUYEN.png')))
highlight=bg.copy();highlight[unwanted]=[220,20,120];Image.fromarray(highlight).save(fresh(S.report(O+'DIEM ANH NEN TRANG BI TOI DI.png')))
last=json.loads(Path(S.report('G05/10SP135 HAI MOC CUOI/GIAO BAN/NGHIEM THU ACTUAL PDF GIAO.json')).read_text(encoding='utf8'))
pts=last['full2218_points'];statuses=['ĐẠT','CHƯA ĐẠT','CHƯA THỂ'];counts={v:sum(p['verification_status']==v for p in pts) for v in statuses};assert len(pts)==2218 and counts==last['full2218_counts']
bad=[p for p in pts if p['verification_status']=='CHƯA ĐẠT'];assert len(bad)==29 and len({p['curve_model'] for p in bad})==13 and all(p['family']=='6SP30' and not p['identity_uncertain'] for p in bad)
with open(fresh(S.report(O+'29 MOC VAN CHUA DAT TRONG PDF GIAO.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 keys=['page','curve_model','source_label','Q_m3h','H_table_m','H_curve_m','deviation_m','uncertainty_m','limit_m','verification_status'];w=csv.DictWriter(fp,keys,extrasaction='ignore');w.writeheader();w.writerows(bad)
res=dict(sample_number=2,physical_samples_used_this_method=2,status='CHƯA ĐẠT',method_stopped_after_two_samples=True,pdf_sample2_not_written=True,canonical_unchanged=True,current_path=d['current_path'],current_sha256=sha(d['current_path']),source_path=d['source_path'],source_sha256=sha(d['source_path']),background_artifact=dark,high_caption_proof=proof,low8_caption_whole_field_equal600dpi=low_equal,all19_real_source_caption_locked_RGB_equal=True,all19_full_fringe_acceptance=False,source_glyph_manual_masks='MAT NA CHU TU GLYPH SACH V2/CHUNG CU MAT NA CHU.json',glyph_mask_inference_not_font_acceptance=True,planned_source_data_models=13,planned_numeric_anchors=sum(len(c['new_Q']) for c in r['curves']),planned_path_coordinates_not_counted_as_actual_PDF_acceptance=True,group_status='CHƯA XONG',full2218_counts=counts,known_failed_points=bad,known_failed_models=sorted({p['curve_model'] for p in bad}),unknown_source_identities_unchanged=['4SP14/4SP15','6SP30-9/6SP30-8'],reason=['Nền vùng nối có sọc dọc mờ: trung vị cột lấy qua dãy chữ và đường làm điểm ảnh vốn trắng bị tối đi trước khi vẽ nét mới.','Lõi chữ và RGB khóa giữ nguyên; chưa thể chứng minh toàn bộ viền mờ của chữ -24/-30 tại chỗ giao tách được khỏi nét nguồn. Không nhận mặt nạ học tự động là nghiệm thu phông.'],next_action='Dừng phương pháp này; giữ 29 mốc CHƯA ĐẠT trong PDF giao. Chỉ xét cách thực sự khác sau điều phối, không tự tạo mẫu thứ ba.')
Path(fresh(S.report(O+'NGHIEM THU PNG MAU 2 - CHUA DAT.json'))).write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# G05 – 29 mốc trái SP30: đã dừng phương pháp sau hai mẫu','',
 'Hai ảnh mẫu đều chưa đạt. Không tạo PDF sửa từ mẫu 2, không thay bản giao. Bản giao đang có 1.115 mốc ĐẠT / 29 mốc CHƯA ĐẠT / 1.074 mốc CHƯA THỂ trong 2.218 mốc thật của 220 đường. 6/6 việc chữ/số gốc và 28 đuôi đường/54 mốc bổ sung đã nghiệm thu vẫn giữ nguyên.','',
 '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|']
for i,c in enumerate(r['curves'],1):
 models=[p for p in bad if p['curve_model']==c['model']];qs=', '.join(str(int(p['Q_m3h'])) for p in models);hs=', '.join(str(p['H_table_m']) for p in models)
 lines.append(f'| BS04-{i} | Perotac bơm giếng SP_compressed (bản mới).pdf | 5 | {c["model"]}: Q {qs}; nét bản giao còn lệch | Chưa sửa bản giao; H bảng đúng cần giữ: {hs} m | Thử giữ RGB chữ thật, xóa mực ảnh, nối đường trơn qua bảng; 2 mẫu đã dừng | CHƯA ĐẠT | 29 MOC VAN CHUA DAT TRONG PDF GIAO.csv; SAU PNG.png; NGHIEM THU PNG MAU 2 - CHUA DAT.json |')
lines+=['',f'Kiểm nền mẫu 2 trước khi vẽ đường: {dark["blank_pixels_darkened_below240_before_drawing_new_strokes"]:,} điểm ảnh vốn có độ sáng trên 248 bị làm tối dưới 240 ở ảnh 600 điểm ảnh/inch; giảm độ sáng tối đa {dark["maximum_added_gray_drop"]:.3f} trên thang 0–255. Đây là lỗi nền, không được chấp nhận vì số tọa độ dự kiến đúng.','',
 'Bảo toàn chữ đã kiểm: đủ 19 nhãn trong ảnh nguồn, 11 nhãn cao có RGB phần đã khóa giống từng điểm ảnh, cả vùng 8 nhãn thấp giống từng điểm ảnh 600 điểm ảnh/inch. Tuy vậy viền mờ của nhãn -24 và -30 tại chỗ giao chưa được chứng minh đầy đủ, nên nghiệm thu toàn bộ chữ vẫn CHƯA THỂ. Không dựng hay thay chữ bằng phông hệ thống.','',
 'Mẫu 1 chưa đạt do hỏng một phần nhãn -15 và hai điểm nối bị gập. Mẫu 2 đã đưa điểm nối -26/-32 sớm hơn và dùng đường bao ký tự sạch trong chính tệp, nhưng nền vẫn chưa đạt và viền chữ còn giới hạn phân biệt của ảnh gốc 150 điểm ảnh/inch. Dừng phương pháp, không thử mẫu thứ ba.','',
 'Không lấy số từ bảng tạm, không đổi danh tính -9/-8 hoặc 4SP14/4SP15. Dữ liệu H0=433 của -38 chỉ là đính chính hồ sơ đo về đúng bảng gốc; không sửa bảng catalogue.','',
 '63 mốc dự kiến trên 13 đường trơn chỉ nằm trong ảnh mẫu; chưa đọc từ PDF sửa nên không được tính ĐẠT. 29 mốc trong bảng báo cáo vẫn lấy trực tiếp hồ sơ nghiệm thu bản giao đã khóa.','',
 'Tệp giao giữ nguyên: '+d['current_path'],'SHA256 tệp giao: '+sha(d['current_path']),'SHA256 nguồn bất biến: '+sha(d['source_path']),'',
 'Nguồn và bản giao không bị sửa/đổi tên/xóa. Không có việc mới nào được tính hoàn thành trong lần thử này. Cần phương án khác thật sự hoặc giữ các điểm này chưa đạt để anh thấy đúng phạm vi còn lại.','']
report=S.report('BAO CAO BO SUNG G05 - 29 MOC TRAI SP30 CHUA DAT.md');Path(fresh(report)).write_text('\n'.join(lines),encoding='utf8')
S.progress('G05','CHƯA XONG','29 mốc trái SP30 / 13 mã máy: hai ảnh mẫu chưa đạt, đã dừng phương pháp xóa mực ảnh + giữ RGB chữ + đường trơn. Mẫu 1 mất phần nhãn -15/nối gập; mẫu 2 nền có sọc mờ và viền -24/-30 chưa thể nghiệm thu. Không ghi PDF mẫu 2, không đổi bản giao SHA256 7335c3a4… hoặc nguồn. Toàn 220 đường / 2218 mốc vẫn 1115 ĐẠT / 29 CHƯA ĐẠT / 1074 CHƯA THỂ; 6/6 chữ/số gốc + 28 đuôi/54 mốc mới đã đạt giữ nguyên. Báo cáo: BAO CAO BO SUNG G05 - 29 MOC TRAI SP30 CHUA DAT.md; hồ sơ MAU 2/NGHIEM THU PNG MAU 2 - CHUA DAT.json. Không thử lần ba cùng phương pháp.')
E.close();assert sha(d['current_path'])==d['current_sha256'] and sha(d['source_path'])==d['source_sha256']
print('SP30_METHOD_STOPPED',dark,'FULL',counts,'REPORT',report,flush=True)
