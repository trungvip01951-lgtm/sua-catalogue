"""Correct actual chart panels from page layout, coordinates measured per Redpump page."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
from catfix import verify
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert [sha(d['source']),sha(d['current'])]==[d['source_SHA256'],d['current_SHA256']]
plots=[(1,'2SL0.7',(455,358,635,530)),(1,'2.5SL1.5',(635,358,813,530)),(2,'3SL2',(455,358,635,530)),(2,'3SL3',(635,358,813,530)),(3,'3SL4',(29,308,382,530)),(4,'4SL2',(455,308,813,530)),(5,'4SL3',(29,308,382,530)),(5,'4SL4',(455,308,813,530)),(6,'4SL6',(29,308,382,530)),(6,'4SL8',(455,308,813,530)),(7,'4SL10',(29,308,382,530)),(7,'4SL12',(455,308,813,530)),(8,'4SL16',(29,308,382,530)),(10,'6SL15',(455,358,633,530)),(10,'6SL25',(633,358,813,530)),(11,'6SL35',(27,358,205,530)),(11,'6SL45',(205,358,384,530))]
records=[]
for page,family,rect in plots:
 photo=root/'DUONG VA NHAN HIEN HANH V2'/f'TRANG {page:02} {family}.png';verify.crop(d['current'],page-1,rect,450).save(fresh(photo))
 records.append(dict(page=page,family=family,plot_page_rect=list(rect),photo=str(photo),photo_SHA256=sha(photo),current_SHA256=d['current_SHA256'],status='Ảnh bản giao đúng panel; chờ khóa từng nhãn/trục và đo đường'))
Path(fresh(root/'DUONG VA NHAN HIEN HANH V2/DINH VI ANH V2.json')).write_text(json.dumps(dict(records=records,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],catalogue_written=False,excluded='V1 chọn sai panel trang1/2/4/10/11, không dùng khóa nhãn'),ensure_ascii=False,indent=2),encoding='utf8')
assert [sha(d['source']),sha(d['current'])]==[d['source_SHA256'],d['current_SHA256']]
print('17 current Q-H panels V2; source and current unchanged',flush=True)
