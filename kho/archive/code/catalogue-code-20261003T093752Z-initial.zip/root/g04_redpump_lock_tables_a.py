"""304 source H cells read directly in Redpump table photos, batch A."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'));name=catalog['name'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(catalog['source'])==catalog['source_SHA256'];assert sha(catalog['current'])==catalog['current_SHA256']
groups=[
 (1,'2SL0.7',[i*.12 for i in range(9)],[(26,[35,32,30,28,26,23,20,16,12]),(32,[43,40,37,35,32,29,24,20,15]),(38,[51,47,44,41,38,34,29,24,18])]),
 (1,'2.5SL1.5',[i*.3 for i in range(9)],[(12,[33,30,28,26,23,20,17,11,5]),(17,[46,42,39,37,33,29,24,16,7]),(24,[65,60,56,52,46,40,33,22,10]),(31,[84,77,72,67,60,52,43,29,13])]),
 (2,'3SL2',[i*.3 for i in range(10)],[(8,[34,34,33,33,31,29,26,23,19,14]),(11,[47,46,45,45,43,40,36,32,27,20]),(15,[64,63,62,61,58,54,49,43,36,27]),(21,[89,89,87,85,81,76,68,60,51,38]),(27,[115,114,112,110,104,97,88,77,65,49]),(33,[141,139,136,134,128,119,108,95,80,60]),(38,[162,160,157,154,147,137,124,109,92,69]),(46,[196,194,190,187,178,166,150,132,111,83])]),
 (2,'3SL3',[i*.3 for i in range(13)],[(8,[32,32,32,31,30,29,28,27,26,23,20,16,12]),(11,[44,44,43,43,41,40,39,37,35,31,27,22,16]),(16,[64,64,63,62,60,59,56,54,51,45,39,32,23]),(21,[85,84,83,81,79,77,74,70,67,60,52,43,31]),(26,[105,104,103,100,98,96,91,87,83,74,64,53,38]),(31,[125,124,122,120,116,114,109,104,99,88,76,63,45]),(37,[149,148,146,143,139,136,130,124,118,105,91,75,54])]),
 (3,'3SL4',[i*.6 for i in range(10)],[(6,[25,25,24,23,22,21,19,16,13,8]),(9,[37,37,36,35,33,32,28,24,19,12]),(12,[49,49,48,47,45,42,37,32,25,15]),(16,[66,66,65,62,59,56,50,42,34,21]),(20,[82,82,81,78,74,70,62,53,42,25]),(24,[99,99,97,93,89,84,75,63,51,31]),(28,[115,115,113,109,104,98,87,74,59,36])]),
]
rows=[]
for page,family,q,series in groups:
 photo=root/f'BANG NGUON {page:02} {family}.png';assert photo.exists()
 for suffix,h in series:
  assert len(q)==len(h) and all(z>=0 for z in h)
  row=dict(page=page,family=family,model=f'{family}/{suffix}',Q=[round(x,6) for x in q],H=h,Q_unit='m³/h',H_unit='m',table_photo=str(photo),table_photo_SHA256=sha(photo),source_file=catalog['source'],source_file_SHA256=catalog['source_SHA256'],table_read='Đọc trực tiếp từng ô ảnh Redpump; OCR chỉ hỗ trợ, các số sai OCR không dùng',curve_acceptance='CHƯA ĐO',identity_basis='Nhãn bản giao hiện hành và bảng cùng mã; #36 /17 đã đối chiếu NHAN HIEN HANH 01.png, không gán nhãn lặp của nguồn')
  rows.append(row)
out=dict(name=name,source_SHA256=catalog['source_SHA256'],current_SHA256=catalog['current_SHA256'],batch='A',model_rows=len(rows),H_cells=sum(len(z['H']) for z in rows),rows=rows,catalogue_written=False,curve_numeric_acceptance=False,other_tables='Còn12 bảng chưa khóa số trong lượt này')
Path(fresh(root/'BANG SO DA DOC TRUC TIEP A.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print('LOCK Redpump A',len(rows),sum(len(z['H']) for z in rows),'H cells; curves not yet accepted',flush=True)
