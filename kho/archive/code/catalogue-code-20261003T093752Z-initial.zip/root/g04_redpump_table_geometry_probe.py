"""Discover actual source table row/column rules; candidates require inspection."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,math,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'));d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert [sha(d['source']),sha(d['current'])]==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);records=[]
def groups(ids):
 out=[]
 for x in ids:
  if not out or x-out[-1][-1]>1:out.append([])
  out[-1].append(int(x))
 return out
for t in catalog['tables']:
 page=t['page'];family=t['table_model'];rows=[r for r in d['rows'] if r['page']==page and r['family']==family];rect=t['rect'];base=max(R.images(page-1),key=lambda z:z.W*z.H);cv=R.render_canvas(page-1,rect,dpi=300);a=cv.orig.astype(int);g=a@np.array([.299,.587,.114]);height,width=g.shape
 x0,y0=cv.to_px(rect[0],rect[3]);x1,y1=cv.to_px(rect[2],rect[1]);xx0=int(x0+(x1-x0)*.485);xx1=min(width,int(x1-3));yy0=max(0,int(y0)-2);yy1=min(height,int(y1)+2)
 sub=g[yy0:yy1,xx0:xx1];hr=(sub<155).mean(1);yg=groups(np.flatnonzero(hr>.55));yc=[float(np.average([yy0+i for i in p],weights=hr[p])) for p in yg]
 # Columns are measured in body rows, excluding the blue header.
 body_start=int(yc[3]+3) if len(yc)>=4 else yy0
 vr=(g[body_start:yy1,int(x0):int(x1)]<155).mean(0);xg=groups(np.flatnonzero(vr>.6));xc=[float(np.average([int(x0)+i for i in p],weights=vr[p])) for p in xg]
 rec=dict(page=page,family=family,rows_expected=len(rows),Q_columns=len(rows[0]['Q']),table_rect=rect,image_size=[base.W,base.H],image_bbox=list(base.page_bbox),geometry_render_dpi=300,geometry_render_rect=list(cv.rect0),table_numeric_search_rendered=[xx0,yy0,xx1,yy1],horizontal_rendered_candidates=yc,vertical_rendered_candidates=xc,expected_horizontal=len(rows)+4,expected_num_vertical=len(rows[0]['Q'])+1,status='CANDIDATE ONLY: inspect row/column rules, no curve acceptance')
 records.append(rec);print(page,family,'rows',len(rows),'Hrules',len(yc),'expected',len(rows)+4,'columns',len(xc),'allrules',flush=True)
E.close();assert [sha(d['source']),sha(d['current'])]==[d['source_SHA256'],d['current_SHA256']]
Path(fresh(root/'HOA TIET BANG NGUON CANDIDATE.json')).write_text(json.dumps(dict(records=records,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
