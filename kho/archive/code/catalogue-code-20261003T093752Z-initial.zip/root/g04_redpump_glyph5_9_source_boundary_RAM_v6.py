"""Two source-defined contour candidates only in RAM; one common grey, no PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import sys,json,hashlib,numpy as np,cv2,copy
from scipy.ndimage import gaussian_filter,label,binary_fill_holes,distance_transform_edt
from PIL import Image,ImageDraw
sys.path.insert(0,str(HERE))
from g04_source_glyph_source_edge_math import smooth_loop,sample_path
from g04_source_glyph_core_math import topology,signed_area,hole_centres
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/'CHU5 9 BIEN NGUON LIEN RAM V6B';assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
previous=J(M/'CHU NHO BIEN NGUON KHONG EP MUC RAM V5/12 GLYPH NHO BIEN MOT MAU RAM V2.json')
bank=J(P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json')
five=next(z for z in J(M/'CHU5 SACH NGUON P8 VA2 KY TU CUNG KIEU LAN1/5 CUNG KIEU2 KY TU NGUON VA CO.json')['records'] if z['character']=='5')
source9=next(z for z in bank['records'] if z['character']=='9')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]

def from_source_mask(source,sigma,level,expected,curvy):
    alpha=np.array(source['source_alpha'],float);pad=8;up=8;A=np.pad(alpha,pad)
    field=gaussian_filter(A,sigma);mask=field>=level
    assert topology(mask)==expected,(topology(mask),expected)
    if source['character']=='9':
        centers=hole_centres(mask)-pad
        reference=hole_centres(A>=.085,largest=1)-pad
        assert len(centers)==len(reference)==1
        assert np.linalg.norm(centers[0]-reference[0])<=4,('Wrong source9 counter',centers,reference)
    fine=cv2.resize(mask.astype('uint8'),(mask.shape[1]*up,mask.shape[0]*up),interpolation=cv2.INTER_NEAREST)
    cs,hi=cv2.findContours(fine,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);assert hi is not None
    loops=[];area=0
    for j,c in enumerate(cs):
        lp=smooth_loop(c,up=up,pad=pad,curvy=curvy);assert lp is not None
        depth=0;p=hi[0,j,3]
        while p>=0:depth+=1;p=hi[0,p,3]
        ar=abs(signed_area(lp['path']));area+=ar*(-1 if depth%2 else 1)
        lp.update(tree_depth=depth,foreground=depth%2==0,area_px=ar);loops.append(lp)
    polygons=[np.rint((sample_path(q['path'],64)+pad)*up).astype('int32') for q in loops]
    actual=np.zeros_like(fine);cv2.fillPoly(actual,polygons,1)
    assert topology(actual)==expected,(topology(actual),expected)
    actualcoverage=1-63/255
    y,x=np.where(mask);selectedbbox=[int(x.min()-pad),int(y.min()-pad),int(x.max()+1-pad),int(y.max()+1-pad)]
    y,x=np.where(actual);newbbox=[float(x.min()/up-pad),float(y.min()/up-pad),float((x.max()+1)/up-pad),float((y.max()+1)/up-pad)]
    # Both the low source-support and half-core boundaries remain diagnostic.
    # Neither a one-pixel guard nor optical mass automatically certifies style.
    weak=cv2.resize((A>=.1).astype('uint8'),(actual.shape[1],actual.shape[0]),interpolation=cv2.INTER_NEAREST).astype(bool)
    forward=float(distance_transform_edt(~weak)[actual>0].max()/up*.12)
    inverse=float(distance_transform_edt(actual==0)[weak].max()/up*.12)
    output=dict(source)
    output.update(core_gray=63,opacity=1,physical_scale=1,source_pixel_pt=.12,source_area_px=float(alpha.sum()),
        vector_optical_area_px=float(area*actualcoverage),expected_topology=list(expected),no_mass_tightening=True,
        no_external_font=True,no_gray_band_layers=True,no_image_SMask=True,
        source_native_pixel_uncertainty_pt=.4801362852213916,
        parts=[dict(source_part=1,kind='absolute_source_coverage',coverage_threshold=level,
            source_smoothing_sigma_px600=sigma,source_smoothing_sigma_pt=sigma*.12,
            close_px600=0,boundary_offset_px600=0,no_optical_mass_tightening=True,loops=loops,
            loop_area_px=area,source_mass_px=float(alpha.sum()),topology=list(expected),
            relative_math_ink_error=float(area*actualcoverage/alpha.sum()-1),
            source_selected_mask_bbox600=selectedbbox,actual_vector_bbox600=newbbox,
            source_weak_alpha_point1_extra_distance_pt=forward,source_weak_alpha_point1_missing_distance_pt=inverse,
            max_contour_fit_error_px600=max(z['max_contour_fit_error_px600'] for z in loops),
            source_counter_centres=(hole_centres(mask)-pad).tolist(),candidate_counter_centres=(hole_centres(actual)/up-pad).tolist(),
            status='ỨNG VIÊN RAM: không tự suy phông/đậm ĐẠT từ ngưỡng hoặc số đo. Không đóng hình hoặc co quỹ mực.')])
    return output,actual,pad,up

candidates=[]
for ch,src,sigma,level,expected,curvy in [('5',five,1.5,.25,(1,0),False),('9',source9,1.25,.30,(1,1),True)]:
    z,mask,pad,up=from_source_mask(src,sigma,level,expected,curvy)
    candidates.append(z)
    al=np.array(z['source_alpha']);source=Image.fromarray(np.round(255*(1-al)).clip(0,255).astype('uint8')).convert('RGB')
    glyph=(255-(1-63/255)*255*mask.astype(float)).clip(0,255).astype('uint8')
    pic=Image.fromarray(glyph).convert('RGB')
    sheet=Image.new('RGB',(1350,600),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(19)
    dr.text((5,5),ch+' source '+src['source_word']+' p'+str(src['source_page'])+' / RAM cùng màu63, chưa chốt',fill='blue',font=ft)
    sourcebig=source.resize((source.width*10,source.height*10),Image.Resampling.NEAREST)
    sheet.paste(sourcebig,(40,65))
    # Fine vector raster only for this mathematical shape diagnostic.
    finepic=pic.crop((pad*up,pad*up,(pad+al.shape[1])*up,(pad+al.shape[0])*up))
    sheet.paste(finepic.resize((al.shape[1]*10,al.shape[0]*10),Image.Resampling.LANCZOS),(500,65))
    dr.text((800,90),'Tỷ lệ1; không điều chỉnh tổng mực.\n'+str(z['parts'][0]['topology'])+' cấu trúc source-selected\n'+
        'Δ mực '+str(round(z['vector_optical_area_px']/z['source_area_px']-1,4)),fill='blue',font=ft)
    sheet.save(fresh(F/(ch+' BIEN NGUON THU LIEN RAM KHONG PDF.png')))

out=copy.deepcopy(previous)
replace={z['character']:z for z in candidates}
out['records']=[replace.get(z['character'],z) for z in out['records']]
out.update(core_gray=63,source=b['source'],source_SHA256=guards[0],current_SHA256=guards[1],M1_SHA256=guards[2],
    RAM_variant='V6 source5p8 connected contour;9 unchanged donor no closing; all other10 glyph geometry preserved.',
    source_font_qualification='CHƯA CHỐT: p8 5 cùng nhãn với4/S/L/, cần ROOT/đồhọa đọc đủ dáng/cỡ. Không gọi donor/font PASS.',
    donor5_source_independent_evidence='g01_DOC BO SUNG DONOR5 9 NGUON - CHUA DOI BANK.md',
    no_mass_tightening=True,PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False)
fp=fresh(F/'12 GLYPH RAM V6 CHI THAY BIEN5 9 MOT MAU.json')
Path(fp).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print('Source contour candidates only',[(z['character'],z['parts'][0]['topology'],z['parts'][0]['actual_vector_bbox600'],z['parts'][0]['source_weak_alpha_point1_missing_distance_pt']) for z in candidates],flush=True)
print(fp,flush=True)
