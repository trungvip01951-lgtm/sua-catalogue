"""G04 Redpump only: own-source axes/ink and two real PDF paths, fresh sample."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g15_masked_patch import commit_masked
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import binary_dilation,binary_closing,binary_opening
from scipy.interpolate import PchipInterpolator
from catfix.recipes import Job
from catfix.charts import Chart
from catfix.cs import Instr,Num
from catfix import verify
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads(Path(S.report('G04/REDPUMP DOC NGUON RIENG/BANG VA HAI DUONG NGUON.json')).read_text(encoding='utf8'))
name=proof['name'];current=S.result(name);source=S.src(name)
assert sha(current)==proof['current_sha256'] and sha(source)==proof['source_sha256']
folder=Path(S.report('G04/REDPUMP MAU NET PDF1'));dst=fresh(folder/name)
j=Job(current,dst,backend='fitz',log_path=fresh(folder/'NHAT KY.json'))
image=max(j.R.images(7),key=lambda z:z.W*z.H);cv=j.R.canvas(image)
assert [image.W,image.H]==proof['source_image_shape']
assert np.max(abs(image.ctm-np.array(proof['source_image_ctm'])))<1e-10
ar=cv.orig.copy();g=ar.astype(float)@np.array([.299,.587,.114]);height,width_px=g.shape
C=Chart(*proof['axis']);Q=np.array(proof['tables'][0]['Q'],float)
u0=int(round(cv.to_px(*C.to_page(0,0))[0]));ue=int(round(cv.to_px(*C.to_page(21.6,0))[0]));us=np.arange(u0,ue+1)
qq=np.array([(cv.to_page(int(u),0)[0]-C.bx)/C.ax for u in us])
a=ar.astype(int);coloured=(a[:,:,1]-a[:,:,0]>8)&(a[:,:,2]-a[:,:,0]>10)&(a[:,:,0]<235)
weak=(a[:,:,1]-a[:,:,0]>2)&(a[:,:,2]-a[:,:,0]>3)
black=(g<140)&((a.max(2)-a.min(2))<10);protect=binary_dilation(black,iterations=2)
allmask=np.zeros((height,width_px),bool);items=[]
for table in proof['tables']:
    heads=np.array(table['H'],float);model=table['model']
    # Same-family guide selects the two independently identified source traces.
    # Its values are not used for the new curve; new anchors are exact table H.
    guide=np.polyval(np.polyfit(Q,heads,3),qq)+2
    vp=np.array([cv.to_px(*C.to_page(float(q),float(h)))[1] for q,h in zip(qq,guide)])
    raw=[]
    for u,v in zip(us,vp):
        rows=np.arange(max(0,int(v)-9),min(height,int(v)+10));good=rows[coloured[rows,u]&~protect[rows,u]]
        if not len(good):raw.append(np.nan);continue
        groups=np.split(good,np.where(np.diff(good)>1)[0]+1)
        centers=[float(np.average(z,weights=255-g[z,u])) for z in groups]
        raw.append(min(centers,key=lambda z:abs(z-v)))
    raw=np.array(raw);ok=np.isfinite(raw);assert ok.sum()>.6*len(us),(model,int(ok.sum()),len(us))
    keep=ok.copy()
    for _ in range(4):
        fit=np.polyval(np.polyfit(qq[keep],raw[keep],4),qq);keep=ok&(abs(raw-fit)<1.5)
    tube=np.zeros((height,width_px),bool)
    for u,v in zip(us,fit):tube[max(0,int(round(v))-4):min(height,int(round(v))+5),u]=True
    mask=tube&weak&~protect;allmask|=mask
    eligible=tube&coloured&~protect;xgrid=np.zeros(width_px,bool)
    for u,q in zip(us,qq):
        if 8<q<17:xgrid[u]=True
    pix=ar[eligible&xgrid[None,:]].astype(float);assert len(pix)>200
    lum=pix@np.array([.299,.587,.114]);ink=np.median(pix[lum<=np.percentile(lum,20)],axis=0)
    alpha=np.clip((255-ar.astype(float))@(255-ink)/np.sum((255-ink)**2),0,1)
    native_widths=[]
    for idx,(uu,q) in enumerate(zip(us,qq)):
        if not 8<q<17:continue
        vv=int(round(fit[idx]));rows=np.arange(max(0,vv-4),min(height,vv+5));slope=float(np.gradient(fit)[idx])
        native_widths.append(float((alpha[rows,uu]*coloured[rows,uu]).sum()/np.sqrt(1+slope*slope)))
    width=float(np.median(native_widths))*abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]);assert .4<width<1.5,(model,width)
    on=np.array([bool(mask[:,u].any()) for u in us]);on=binary_opening(binary_closing(on,structure=np.ones(3)),structure=np.ones(3));on[0]=True
    items.append(dict(model=model,heads=heads,ink=ink,width=width,presence=on,trace_median=float(np.median(abs(raw[keep]-fit[keep]))),raw_good=int(ok.sum()),raw_kept=int(keep.sum()),removed_pixels=int(mask.sum()),native_width_px=float(np.median(native_widths))))
plot=(57.5,320.,326.5,509.)
u,v,ur,vr=cv.box(plot);patch=ar[v:vr,u:ur].astype(float);row=np.median(patch,axis=1);col=np.median(patch,axis=0)
bg=ar.copy();bg[v:vr,u:ur]=np.minimum(row[:,None,:],col[None,:,:]).round().clip(0,255).astype(np.uint8)
cv.work[allmask]=bg[allmask];assert np.array_equal(cv.work[protect],ar[protect])
X=np.linalg.inv(image.ctm)
ins=[Instr([],'q'),Instr([Num(X[0,0]),Num(X[0,1]),Num(X[1,0]),Num(X[1,1]),Num(X[2,0]),Num(X[2,1])],'cm'),Instr([Num(0)],'J'),Instr([Num(1)],'j'),Instr([[],Num(0)],'d')]
records=[]
for it in items:
    qend=6.;segments=[];on=it['presence'];run=None
    for idx,(q,present) in enumerate(zip(qq,on)):
        if q>qend:break
        if present and run is None:run=0. if idx==0 else max(0.,float(q))
        if not present and run is not None:
            end=min(qend,float(qq[idx-1]))
            if end>run:segments.append((run,end))
            run=None
    if run is not None:segments.append((run,qend))
    segments.append((6.,21.))
    f=PchipInterpolator(Q,it['heads']);ins.extend([Instr([Num(float(z/255)) for z in it['ink']],'RG'),Instr([Num(it['width'])],'w')])
    for lo,hi in segments:
        qs=np.unique(np.r_[lo,Q[(Q>lo)&(Q<hi)],hi]);path=C.smooth_path([(float(q),float(f(q))) for q in qs],method='pchip')
        for op,pts in path:ins.append(Instr([Num(float(z)) for p in pts for z in p],op))
        ins.append(Instr([],'S'))
    records.append(dict(model=it['model'],Q=Q.tolist(),H=it['heads'].tolist(),RGB=it['ink'].tolist(),width_pt=it['width'],native_dash_Q_intervals=segments,source_trace_median_error_px=it['trace_median'],source_trace_good_pixels=it['raw_good'],source_trace_kept_pixels=it['raw_kept'],source_native_width_px=it['native_width_px'],source_removed_pixels=it['removed_pixels']))
ins.append(Instr([],'Q'));j.E.insert_instrs(image.key,image.index,ins,before=False)
cv.after=image;cv.pi=7;masked=commit_masked(j);j.R.canvases.clear();j._canvases.clear()
j._add(7,plot,'4SL16/23 và 4SL16/18: đúng 16 số bảng, nét PDF thật, giữ hình và chữ nguồn Redpump','Redpump-source-background+true-PDF-path')
j.save();check=j.check(raster=True)
outside=verify.outside_pixels(current,dst,{8:[list(plot)]},dpi=200,thr=0,min_size=0,pad=.4)
verify.compare_sheet(current,dst,[(7,plot,'Redpump hai đường theo đúng bảng')],fresh(folder/'TRUOC SAU.png'),dpi=450,pad=(.2,.2))
verify.crop(dst,7,plot,600).save(fresh(folder/'ANH NET PDF.png'))
verify.crop(dst,7,(0,0,841.9,598.8),150).save(fresh(folder/'TOAN TRANG8.png'))
out=dict(current=current,current_sha=sha(current),source=source,source_sha=sha(source),trial=dst,trial_sha=sha(dst),check=check,outside=outside,records=records,axis=proof['axis'],source_axis_residual_pt=proof['axis_residual_pt'],source_ticks_lmin=proof['source_ticks_lmin'],top_v=proof['top_v'],bottom_v=proof['bottom_v'],source_image_bbox=proof['source_image_bbox'],source_image_ctm=proof['source_image_ctm'],allowed_plot=list(plot),masked_patches=masked,black_native_pixels_exact=True,accepted=False,method='Two true PDF paths over source-only masked pixel cleanup; RGB, equivalent width, dash intervals and axes all measured independently in Redpump')
Path(fresh(folder/'TAO VA KIEM MAU.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('REDPUMP SAMPLE',check['ok'],outside,'RGB/lw',[(x['RGB'],x['width_pt']) for x in records],flush=True);j.close()
