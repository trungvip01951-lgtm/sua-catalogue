"""Chỉ ảnh chứng cứ chữ nguồn có thước hàng điểm ảnh; không sửa catalogue."""
from catwork import start,fresh,HERE
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
O='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
d=json.loads(Path(S.report(O+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'));E=Editor(d['source_path']);R=Raster(E);cv=R.canvas(R.images(4)[0]);a=cv.orig
for z in d['models']:
 x0,y0,x1,y1=z['native_label_box'];crop=a[y0:y1,x0:x1];scale=16;pic=Image.new('RGB',((x1-x0)*scale+70,(y1-y0)*scale),'white');pic.paste(Image.fromarray(crop).resize(((x1-x0)*scale,(y1-y0)*scale),Image.Resampling.NEAREST),(70,0));draw=ImageDraw.Draw(pic)
 for y in range(y0,y1):
  draw.text((3,(y-y0)*scale+2),str(y),fill='black');draw.line((70,(y-y0)*scale,pic.width,(y-y0)*scale),fill=(240,190,210),width=1)
 pic.save(fresh(S.report(O+'THUOC HANG DIEM ANH/'+z['model']+'.png')))
E.close()
