from catwork import start, fresh, HERE
S, D, N = start()
import sys
sys.path.insert(0, str(HERE))
from pathlib import Path
import collections
import csv
import datetime
import hashlib
import json


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def entry(path, **extra):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=sha(path), **extra)


O = Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'))
source = Path(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf'))
current = Path(S.result('Perotac bơm giếng SA_compressed (bản mới).pdf'))
expected_source = '3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
expected_current = '389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
assert sha(source) == expected_source
assert sha(current) == expected_current
result_file = O / 'g01_KET QUA RA SOAT16 BIEU DO NGOAI TRANG8 - KHONG GHI PDF.json'
assert sha(result_file) == 'dd53f90c937035bac1bb5fb00b8cde840872e3274134022c9f638c281b323076'
result = json.loads(result_file.read_text(encoding='utf-8'))
matrix_file = O / 'g01_MA TRAN183 MODEL NOI NHAN VA NET - DU LIEU CHI DOC.json'
matrix = json.loads(matrix_file.read_text(encoding='utf-8'))['matrices']
ledger_file = O / 'g01_SO1827 MOC NGOAI TRANG8 - CU VA DOC MOI TACH RO.csv'
with ledger_file.open(encoding='utf-8-sig', newline='') as stream:
    rows = list(csv.DictReader(stream))

assert len(rows) == 1827
assert len({(r['model'], float(r['Q_m3_h'])) for r in rows}) == 1827
assert len(matrix) == 183 and len({r['model_literal_key'] for r in matrix}) == 183
new_rows = [r for r in rows if r['was_new_read_target'] == 'True']
assert len(new_rows) == 231
prior_counts = collections.Counter(r['prior_status'] for r in rows)
final_counts = collections.Counter(r['final_g01_point_status'] for r in rows)
new_counts = collections.Counter(r['final_g01_point_status'] for r in new_rows)
assert prior_counts == {'KHỚP MỐC': 1596, 'CHƯA THỂ XÁC MINH': 228, 'LỆCH CHẮC': 3}, prior_counts
assert final_counts == {'KHỚP MỐC (KẾ THỪA)': 1596, 'ĐẠT': 1, 'CHƯA ĐẠT': 4, 'CHƯA THỂ XÁC MINH': 226}, final_counts
assert new_counts == {'ĐẠT': 1, 'CHƯA ĐẠT': 4, 'CHƯA THỂ XÁC MINH': 226}, new_counts
cross = collections.Counter((r['prior_status'], r['was_new_read_target'] == 'True', r['final_g01_point_status']) for r in rows)
expected_cross = {
    ('KHỚP MỐC', False, 'KHỚP MỐC (KẾ THỪA)'): 1596,
    ('CHƯA THỂ XÁC MINH', True, 'ĐẠT'): 1,
    ('CHƯA THỂ XÁC MINH', True, 'CHƯA ĐẠT'): 1,
    ('CHƯA THỂ XÁC MINH', True, 'CHƯA THỂ XÁC MINH'): 226,
    ('LỆCH CHẮC', True, 'CHƯA ĐẠT'): 3,
}
assert cross == expected_cross, cross
assert sum(f['models'] for f in result['per_family']) == 183
assert sum(f['points'] for f in result['per_family']) == 1827
assert sum(f['new_target_points'] for f in result['per_family']) == 231
assert len([f for f in result['per_family'] if f['new_target_points']]) == 13
assert sum(r['H_new_candidate_m'] != '' for r in new_rows) == 112
assert len(result['11_point_final_decisions']) == 11
assert sum(p['result'] == 'CHƯA ĐẠT' for p in result['11_point_final_decisions']) == 4

cross_rows = [dict(prior_status=k[0], new_read_target=k[1], final_status=k[2], points=n)
              for k, n in expected_cross.items()]
account = {
    'source': entry(source), 'current': entry(current),
    'graphs_outside_page8': 16, 'models': 183, 'numeric_table_cells': 1827,
    'new_read_targets_are_subset_of_total': True,
    'unique_model_Q_keys': 1827,
    'prior_counts': dict(prior_counts), 'final_counts_separating_inherited': dict(final_counts),
    'new231_counts': dict(new_counts), 'intersection_rows': cross_rows,
    'sum_intersections': sum(r['points'] for r in cross_rows),
    'new_profile_H_candidates': 112, 'new_targets_without_single_H_candidate': 119,
    'prior_certain_points_not_rerun': 1596,
    'newly_accepted_points': 1, 'reconfirmed_prior_failures': 3, 'newly_confirmed_failures': 1,
    'fresh_direct_identity_reviews_for_candidate_point_models': 11,
    'families_with_new_targets': [dict(page=f['page'], family=f['family'], targets=f['new_target_points'])
                                 for f in result['per_family'] if f['new_target_points']],
    'whole_G04_done': False, 'whole_curves_fresh_accepted': False,
    'parent_independent_acceptance_pending': True,
    'PDF_written': False, 'source_pixels_retouched': False, 'TIEN_DO_written': False,
    'result_json': entry(result_file), 'matrix_json': entry(matrix_file), 'ledger_csv': entry(ledger_file),
    'time_host': datetime.datetime.now().astimezone().isoformat(),
}
account_file = Path(fresh(O / 'g01_BANG GIAO NHAU CU MOI183 MODEL1827 MOC - V2.json'))
account_file.write_text(json.dumps(account, ensure_ascii=False, indent=2), encoding='utf-8')
cross_csv = Path(fresh(O / 'g01_BANG GIAO NHAU CU MOI183 MODEL1827 MOC - V2.csv'))
with cross_csv.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(cross_rows[0]))
    writer.writeheader()
    writer.writerows(cross_rows)


def num(value, digits=6):
    return f'{value:.{digits}f}'.replace('.', ',')


def link(label, path):
    return f'[{label}](<{Path(path).resolve()}>)'


border_file = O / 'g01_BIEN NGUON THAN NET VA DAU CUOI11 MOC - KHONG EP BUT MANH.json'
md = [
    'BÁO CÁO NHÓM G04 – RÀ SOÁT CHỈ ĐỌC PEROTAC SA NGOÀI TRANG 8',
    '',
    'Phạm vi đã đọc: **16 biểu đồ, 183 mã máy, 1.827 ô Q–H có số**. Q là lưu lượng, H là cột áp. '
    '**231 mốc đọc bổ sung nằm trong 1.827 mốc**, không cộng thêm vào tổng. '
    'Bản gốc và bản giao giữ nguyên mã kiểm; tác nhân chỉ ghi hồ sơ kiểm tra riêng.',
    '',
    'Kết quả 231 mốc đọc bổ sung: **1 ĐẠT, 4 CHƯA ĐẠT, 226 CHƯA THỂ XÁC MINH**. '
    'Bốn mốc chưa đạt gồm ba mốc cũ được xác minh lại và một mốc mới. '
    '1.596 mốc khớp của hồ sơ trước được giữ riêng là **KHỚP MỐC (KẾ THỪA)**; phiên này không đo lại chúng. '
    'Tổng ghép là 1.597 mốc khớp/đạt, 4 chưa đạt, 226 chưa thể. '
    'Không dùng tổng này để tuyên bố mọi đường hoặc toàn nhóm G04 đã nghiệm thu.',
    '',
    '**Lỗi mới:** 3SS3/31, trang 2, Q = 3,6 m³/h. Bảng ghi H = 45 m; nét nguồn đo được '
    '48,846696 ± 2,259345 m. Biên dưới 46,587351 m vẫn cao hơn 46 m '
    '(45 m cộng dung sai 1 m). Nhãn máy, nét đi từ nhãn, vạch và ô bảng được đọc từ chính Perotac. '
    'Kết quả mới còn chờ điều phối viên kiểm độc lập trước khi dùng để sửa.',
    '',
    'Bảng 8 cột dưới đây theo mẫu báo cáo chung. “RS” là dòng khảo sát, không phải số việc sửa; '
    'cột “Mới” là số đo và biên bất định, chưa phải nội dung đã ghi vào catalogue.',
    '',
    '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
    '|---|---|---|---|---|---|---|---|',
]
for i, p in enumerate(result['11_point_final_decisions'], 1):
    old = f'{p["model"]}; Q = {num(p["Q_m3_h"], 2)} m³/h; H bảng = {num(p["H_table_m"], 0)} m'
    measured = f'H đo = {num(p["H_measured_m"])} ± {num(p["uncertainty_m"])} m'
    evidence = link('Ảnh PDF nguồn 600 điểm/inch', p['source_point_crop_600dpi']) + ' · ' + link('Số đo và biên nguồn', border_file)
    md.append(f'| RS{i:02d} | Perotac bơm giếng SA | {p["page"]} | {old} | {measured} | Chỉ đọc; nhãn thật → nét nguồn → vạch địa phương; đối chiếu tiết diện và đầu/cuối | {p["result"]} | {evidence} |')
md += [
    '',
    'Các mốc 3SS3/26, 3SS4/24, 4SA12/7, 4SA12/29, 4SA12/32 và 6SA25/20 giữ '
    '**CHƯA THỂ XÁC MINH**: khoảng đo còn giao với ranh giới dung sai sau khi tính độ nhạy và bề dày mực. '
    'Mốc ĐẠT mới là 4SA12/23, Q = 3,6 m³/h, H bảng = 129 m: số đo 128,967359 ± 1,509062 m '
    'nằm trọn trong dung sai 2,58 m. Dung sai vẫn là max(1 m, 2% H bảng).',
    '',
    'Bảng giao nhau giữa trạng thái cũ và lần đọc này:',
    '',
    '| Trạng thái cũ | Thuộc 231 mốc đọc bổ sung | Trạng thái cuối | Số mốc |',
    '|---|---|---|---|',
]
for r in cross_rows:
    prior = 'CHƯA ĐẠT (hồ sơ cũ ghi LỆCH CHẮC)' if r['prior_status'] == 'LỆCH CHẮC' else r['prior_status']
    md.append(f'| {prior} | {"Có" if r["new_read_target"] else "Không"} | {r["final_status"]} | {r["points"]:,} |'.replace('1,596', '1.596'))
md += [
    '',
    'Đối chiếu: 228 mốc chưa rõ cũ = 1 đạt mới + 1 lỗi mới + 226 còn chưa rõ. '
    'Ba mốc lệch cũ đều được xác minh lại là chưa đạt. 1.596 + 231 = 1.827; '
    'mọi khóa (mã máy, Q) chỉ xuất hiện một lần.',
    '',
    '| Trang | Họ máy | Mã máy | Ô có số | Khớp kế thừa | Đạt mới | Chưa đạt | Chưa thể | Mốc đọc bổ sung |',
    '|---|---|---|---|---|---|---|---|---|',
]
for f in result['per_family']:
    c = f['counts']
    md.append(f'| {f["page"]} | {f["family"]} | {f["models"]} | {f["points"]} | {c.get("KHỚP MỐC (KẾ THỪA)", 0)} | {c.get("ĐẠT", 0)} | {c.get("CHƯA ĐẠT", 0)} | {c.get("CHƯA THỂ XÁC MINH", 0)} | {f["new_target_points"]} |')
md += [
    '| Tổng | 16 biểu đồ | 183 | 1.827 | 1.596 | 1 | 4 | 226 | 231 |',
    '',
    'Cách đọc và giới hạn: đã tự mở 16 biểu đồ nguồn, 13 bảng có mốc đọc bổ sung và 11 ảnh tiết diện '
    'từ PDF nguồn thật. Trong 231 mốc, 112 mốc có giá trị H ứng viên; 119 mốc chưa có một tiết diện H duy nhất. '
    'Giá trị ứng viên chưa phải số đã đạt. Các ô bảng không có số không dựng thêm điểm.',
    '',
    'Nhận dạng phải đi từ tên máy thật sang nét nối trong ảnh nguồn. '
    'Ma trận lưu 176 liên hệ tên–nét đã khóa trong hồ sơ cũ; phiên này đọc riêng trực tiếp 11 mã ở bảng khảo sát. '
    'Bảy mã 4SA6/6, 4SA6/7, 4SA6/8, 4SA8/6, 4SA8/7, 4SA8/8, 4SA8/9 vẫn chưa nối chắc với nét riêng. '
    'Không chọn đường theo H gần nhất, công suất hoặc thứ hạng. '
    'Mã một pha có M và mã ba pha chỉ được đối chiếu khi cùng hàng số thủy lực trong bảng; '
    'điện áp, công suất và tên in hiện hành giữ nguyên.',
    '',
    'Thước Q dùng vạch thật trên biểu đồ hiệu suất η phía dưới, cùng hàng đơn vị lít/phút, '
    'để tránh nhầm cột chữ trong khung H thành vạch. Thước H dùng nhãn và vạch thật riêng của từng họ. '
    'Ở 6SA35, hàng lít/phút và m³/h có vạch riêng; không ép vạch 83 lít/phút trùng vạch 6 m³/h. '
    'Biên đọc có tính làm tròn nhãn 83, 167… lít/phút. '
    'Ở 4SA10, lưới trung gian không khớp nhãn H nên chỉ dùng khung 0–240 m; giới hạn này được giữ là chưa rõ.',
    '',
    'Ảnh nén JPEG gốc khoảng 150 điểm/inch. Dựng PDF ở 600 điểm/inch giúp soi mực, '
    'không tạo thêm chi tiết nguồn. Biên bảo thủ gồm nửa bề dày mực, định vị điểm ảnh/vạch H, '
    'sai số vạch Q quy đổi theo độ dốc, độ nhạy của 9 tiết diện và bề dày thân nét trước đầu/cuối. '
    'Không lấy đầu nét bị cắt mỏng làm giảm giả biên đo. '
    '11 vùng tiết diện của PDF nguồn và bản giao giống từng điểm ảnh khi dựng cùng cách ở 600 điểm/inch.',
    '',
    'Kiểm kê ảnh gốc, điểm ảnh và ma trận đặt ảnh cho 9 trang có biểu đồ ngoài trang 8 giữ nguyên. '
    '16 đường hiệu suất η chưa có bảng số η nên chưa nghiệm thu số, không trộn vào 1.827 mốc Q–H. '
    'Tác nhân không ghi PDF, không sửa điểm ảnh nguồn, không ghi TIEN DO.md. '
    'Trang 8 và phương án sửa trang 2–3 đang có tác nhân riêng.',
    '',
    'SHA-256 là mã kiểm nhận dạng nội dung tệp:',
    '',
    f'- Nguồn: `{expected_source}`.',
    f'- Bản giao: `{expected_current}`.',
    '',
    'Hồ sơ chi tiết:',
    '',
    '- ' + link('Kết quả đầy đủ', result_file) + '.',
    '- ' + link('Ma trận 183 mã ↔ nhãn và nét', matrix_file) + '.',
    '- ' + link('Sổ 1.827 mốc; có cột tách lần đọc cũ/mới', ledger_file) + '.',
    '- ' + link('231 mốc đọc bổ sung', O / 'g01_231 MOC DOC MOI NGOAI TRANG8.csv') + '.',
    '- ' + link('Bảng giao nhau cũ/mới', account_file) + '.',
    '',
    'Các tệp CSV là bảng văn bản phân cột; JSON là dữ liệu cấu trúc để tính và kiểm độc lập. '
    'Hồ sơ này chốt kết quả đọc riêng, còn chờ điều phối viên khóa nghiệm thu mới. '
    'Kết luận nhóm G04 vẫn **CHƯA XONG**.',
]
report_file = Path(fresh(O / 'g01_BAO CAO8 COT183 MODEL1827 MOC - BAN DE DOC V2.md'))
report_file.write_text('\n'.join(md) + '\n', encoding='utf-8')

# Lock the exact existing evidence, including the source-pixel crops, without
# regenerating a PDF or changing any image pixel. The manifest does not include
# itself, avoiding a circular hash; its own SHA is sent separately to ROOT.
all_evidence = sorted((p for p in O.rglob('*') if p.is_file()), key=lambda p: str(p.relative_to(O)))
evidence_entries = [entry(p, relative_path=str(p.relative_to(O))) for p in all_evidence]
scripts = sorted(HERE.glob('g01_per_sa_*.py'))
inputs = [O.parent / 'KIEM TOAN CUOI DE ROOT DOC.json',
          HERE / 'g04_perotac_audit_data.py', HERE / 'g04_perotac_audit_labels_manual.py',
          HERE / 'graph_image_math.py', HERE / 'catwork.py', HERE / 'batdau.py']
manifest = {
    'manifest_kind': 'Exact SHA-256 inventory; no PDF or pixel mutation',
    'time_host': datetime.datetime.now().astimezone().isoformat(),
    'scope_directory': str(O.resolve()),
    'source': entry(source), 'current': entry(current),
    'authoritative_human_report': entry(report_file),
    'authoritative_result_json': entry(result_file),
    'accounting_json': entry(account_file),
    'matrix_json': entry(matrix_file),
    'full1827_ledger_csv': entry(ledger_file),
    'inherited_evidence_inputs': [entry(p) for p in inputs],
    'own_script_entries': [entry(p) for p in scripts],
    'output_evidence_count': len(evidence_entries),
    'output_evidence_files': evidence_entries,
    'total_unique_model_Q_points': 1827, 'new231_are_subset': True,
    'combined_final_counts': dict(final_counts), 'intersection_rows': cross_rows,
    'previous_format_report_kept': str(O / 'g01_BAO CAO DOC16 BIEU DO NGOAI TRANG8 - CU VA MOI RO RANG.md'),
    'self_hash_is_sent_separately_not_included_circularly': True,
    'PDF_written': False, 'source_pixels_retouched': False, 'TIEN_DO_written': False,
}
manifest_file = Path(fresh(O / 'g01_DANH MUC MA KIEM CHINH XAC183 MODEL1827 MOC - V2.json'))
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

# Read back the completed documents, CSV partition and every recorded byte hash.
back = json.loads(manifest_file.read_text(encoding='utf-8'))
assert len(back['output_evidence_files']) == len(evidence_entries)
for e in back['output_evidence_files'] + back['own_script_entries'] + back['inherited_evidence_inputs']:
    assert sha(e['path']) == e['sha256'], e['path']
with cross_csv.open(encoding='utf-8-sig', newline='') as stream:
    cross_back = list(csv.DictReader(stream))
assert sum(int(r['points']) for r in cross_back) == 1827
assert sha(source) == expected_source and sha(current) == expected_current
for label, p in [('REPORT8', report_file), ('ACCOUNT', account_file), ('MANIFEST', manifest_file)]:
    print(label, str(p), 'SHA256', sha(p))
print('READBACK', json.dumps(dict(points=len(rows), models=len(matrix), new_targets=len(new_rows),
      output_evidence=len(evidence_entries), final=dict(final_counts), intersections=cross_rows), ensure_ascii=False))
