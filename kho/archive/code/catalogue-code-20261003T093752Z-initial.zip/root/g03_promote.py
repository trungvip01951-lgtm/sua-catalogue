from catwork import start, fresh
S, D, N = start()
from catfix import verify
from catfix.vector import Editor
from pathlib import Path
import json, hashlib, datetime

NAME = 'Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'
root = Path(S.report('G03'))
st = json.loads((root / 'build-state.json').read_text(encoding='utf-8'))
info = json.loads((root / 'review' / 'nhan-cuoi.json').read_text(encoding='utf-8'))
job = S.job(NAME)
assert Path(job.src) == Path(st['source']) and Path(job.dst) == Path(st['destination'])
assert Path(job.dst).is_relative_to(Path(S.out_dir))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(job.src) == st['source_sha256']
allowed = {a['page']: [a['rect']] for a in st['axes']}
bad = verify.outside_pixels(job.dst, info['destination'], allowed, dpi=200)
if bad:
    raise RuntimeError('Bản làm rõ nhãn đổi ngoài vùng biểu đồ: ' + repr(bad))

# Chỉ cập nhật kết quả do G03 tạo; giữ nguyên bản kết quả trước và toàn bộ nguồn.
before_hash = sha(job.dst)
backup = fresh(root / 'review' / 'Ban truoc lam ro nhan.pdf')
oldE = Editor(job.dst)
oldE.save(backup)
oldE.close()
logpath = Path(job.log_path)
oldlog = json.loads(logpath.read_text(encoding='utf-8'))
Path(fresh(root / 'review' / 'Nhat ky truoc lam ro nhan.json')).write_bytes(logpath.read_bytes())
proof = Path(S.report('So sanh G03.png'))
Path(fresh(root / 'review' / 'So sanh truoc lam ro nhan.png')).write_bytes(proof.read_bytes())

job.E.close()
job.E = Editor(info['destination'])
job.edits = list(st['edits'])
for a in st['axes']:
    job._add(a['page'] - 1, a['rect'], 'Làm rõ nhãn bằng viền theo nét chữ gốc; giãn 4SA8/8 trang 7', 'outline-label')
job.E.log = list(oldlog['log']) + [dict(op='lam_ro_nhan', details=info['details'])]
job.save()
assert sha(job.src) == st['source_sha256']
revision = dict(created=datetime.datetime.now().isoformat(), source=job.src,
                source_sha256=sha(job.src), destination=job.dst,
                before_destination_sha256=before_hash, destination_sha256=sha(job.dst),
                retained_before_pdf=backup, stage=info['destination'],
                stage_sha256=sha(info['destination']), old_to_final_outside_plot={},
                log_path=job.log_path, edits=job.edits, label_details=info['details'])
json.dump(revision, open(fresh(root / 'final-revision.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1, default=str)
job.close()
print('Đã cập nhật kết quả G03; nguồn giữ nguyên; bản kết quả trước được giữ lại.', flush=True)
print(revision['destination_sha256'], flush=True)
