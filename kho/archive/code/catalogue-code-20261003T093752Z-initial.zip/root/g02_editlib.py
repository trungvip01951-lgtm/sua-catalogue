"""Các phép vẽ G02 dùng nguyên catfix; chữ/nét chỉ chép từ catalogue gốc."""
from catfix.otext import Match,procrustes
from catfix.vector import union
from catfix.charts import sample_path
from g01_fontbank import at_scale
from g02_halobank import make_halobank,plot_halos,insert_halo
import numpy as np,copy

WHITE=(1.,1.,1.)
def white_twins(T,p,g):
    P=T.E.page(p);out=[]
    for oi in P.objects_in((g.bbox[0]-2,g.bbox[1]-2,g.bbox[2]+2,g.bbox[3]+2)):
        col=P.color_of(oi,'fill')
        if col is None or min(col)<.995:continue
        for gg in P.merged_glyphs(oi):
            b=gg['bbox'];a=g.bbox
            centre=max(abs((a[k]+a[k+2]-b[k]-b[k+2])/2) for k in range(2))
            expansion=[b[k+2]-b[k]-a[k+2]+a[k] for k in range(2)]
            contains=all(b[k]<a[k]-.05 and b[k+2]>a[k+2]+.05 for k in range(2))
            if centre<.5 and contains and all(.6<v<3.0 for v in expansion):out.append((oi,gg))
    assert len(out)==1,(p+1,g.oi,g.char,'viền mở rộng',[(oi,gg['bbox']) for oi,gg in out])
    return out

def transfer(E,T,p,g,delta,delete=False):
    peers=[(g.oi,g.g)]+white_twins(T,p,g)
    for oi,gg in peers:
        if delete:E.delete_group(p,oi,gg)
        elif delta[0] or delta[1]:E.move_group(p,oi,gg,*delta)
    return len(peers)-1

def copy_string(E,U,match,new,align='left',dx=0.,dy=0.,target=None,halos=(),emit=True):
    """Dựng chữ bằng nét cùng phông được kiểm hình học, lấy từ tệp gốc."""
    V,M,proof=at_scale(U,match)
    F=V.styles[0]['metrics'];s=proof['scale']
    start,end,base=V.run_extent(M.glyphs)
    width=sum(F['adv'][c] for c in new)
    x=(start if align=='left' else end-width if align=='right' else (start+end-width)/2)+dx;base+=dy
    target=match.glyphs[0].oi if target is None else target
    placed=[];placements=[]
    for c in new:
        if c==' ':x+=F['adv'][c];continue
        g=U.clusters[U.styles[0]['src'][c]]['members'][0]
        path=U.E.glyph_pagepath(g.key,g.oi,g.g)
        tx=x+F['lsb'][c];ty=base+F['bot'][c]
        Mx=np.array([[s,0.,0.],[0.,s,0.],[tx-s*g.bbox[0],ty-s*g.bbox[1],1.]])
        if emit:
            E.insert_path(match.key,target,path,Mx=Mx)
            for oi in halos:E.insert_path(match.key,oi,path,Mx=Mx)
        b=(tx,ty,tx+s*(g.bbox[2]-g.bbox[0]),ty+s*(g.bbox[3]-g.bbox[1]))
        placed.append(b);placements.append(dict(char=c,rect=b))
        x+=F['adv'][c]
    return dict(rect=union(placed),placements=placements,proof=proof,font_rms=[F['rms_x'],F['rms_y']])

def draw_page(job,T,U,ps,plan):
    p=int(ps)-1;E=job.E;P=E.page(p);allgs=T.page_glyphs(p)
    moves=[];axes=[];bank=make_halobank(T);halo_proof=[]
    oldhalos=plot_halos(E,p,plan['plot']);halo_target=min(oi for oi,gg in oldhalos)
    for oi,gg in oldhalos:E.delete_group(p,oi,gg)
    for rec in plan['curves']:
        if rec['oi'] is None:continue
        E.replace_path(p,rec['oi'],rec['path'])
        gl=[]
        for oi in rec['label_ois']:
            candidates=[g for g in allgs if g.oi==oi];assert len(candidates)==1,(ps,oi,len(candidates))
            gl.append(candidates[0])
        gl.sort(key=lambda g:g.bbox[0]);assert ''.join(g.char for g in gl)==rec['label']
        shift=np.array(rec['label_shift']);trim=rec['label'].startswith('0');removed=0;halo_count=0
        if trim:
            assert gl[0].char=='0'
            cg=U.clusters[U.styles[0]['src']['0']]['members'][0]
            s,R,t,res=procrustes(cg.pts,gl[0].pts,allow_rotation=True)
            assert res<.03,(ps,rec['label'],res)
            shift=shift-U.styles[0]['metrics']['adv']['0']*s*R[:,0]
            E.delete_group(p,gl[0].oi,gl[0].g);gl=gl[1:];removed=1
        for g in gl:
            if any(shift):E.move_group(p,g.oi,g.g,*shift)
            halo_proof.append(insert_halo(E,p,halo_target,g,shift,bank));halo_count+=1
        b=union([rec['label_rect'],tuple(rec['label_rect'][k]+shift[k%2] for k in range(4))])
        moves.append(dict(model=rec['model'],old=rec['label'],new=rec['newlabel'],removed=removed,shift=shift.tolist(),halo_glyphs=halo_count,rect=b))
    # Đường bổ sung 5SP10-30 và nhãn cùng kiểu, dùng trạng thái nét của đường mẫu.
    new=[rec for rec in plan['curves'] if rec['oi'] is None]
    if new:
        assert ps=='10' and len(new)==1
        rec=new[0];temp=plan['curves'][0]
        E.insert_object_after(p,temp['oi'],rec['path'])
        gl=sorted([g for g in allgs if g.oi in temp['label_ois']],key=lambda g:g.bbox[0])
        halos=[halo_target]
        oldstart=sample_path(P.object_pagepath(temp['oi']))[0]
        dx,dy=[rec['start'][i]-oldstart[i] for i in range(2)]
        mm=Match(p,gl,temp['label'],gl)
        proof=copy_string(E,U,mm,rec['newlabel'],dx=dx,dy=dy,target=gl[0].oi,emit=False)
        labelgs=[g for g in allgs if g.oi in sum([r['label_ois'] for r in plan['curves'] if r['oi'] is not None],[])]
        for placement in proof['placements']:
            sources=[g for g in labelgs if g.char==placement['char']]
            assert sources,(ps,placement['char'],'thiếu nét viền gốc')
            g=sources[0];b=placement['rect']
            # Cùng chữ, cùng cỡ và hình nguyên mẫu: viền lấy từ chính nhãn trong biểu đồ này.
            assert max(abs((b[k+2]-b[k])-(g.bbox[k+2]-g.bbox[k])) for k in range(2))<.04
            delta=[b[0]-g.bbox[0],b[1]-g.bbox[1]]
            E.insert_path(p,gl[0].oi,E.glyph_pagepath(p,g.oi,g.g),dx=delta[0],dy=delta[1])
            halo_proof.append(insert_halo(E,p,halo_target,g,delta,bank))
        moves.append(dict(model=rec['model'],old=None,new=rec['newlabel'],removed=0,shift=[dx,dy],halo_objects=halos,rect=proof['rect'],proof=proof))
    for axis,before,after in [('x',plan['xticks_before'],plan['xticks']),('y',plan['yticks_before'],plan['yticks'])]:
        if before==after:continue
        for (old,coord),(value,newcoord) in zip(before,after):
            assert abs(coord-newcoord)<1e-6
            if old==value:continue
            plot=plan['plot'];rect=(plot[0]-18,plot[1]-36,plot[2]+18,plot[1]-6) if axis=='x' else (plot[0]-48,plot[1]-8,plot[0]-7,plot[3]+8)
            candidates=[]
            oldglyphs=T.glyphs[p];T.glyphs[p]=[g for g in oldglyphs if P.color_of(g.oi,'fill')==(.216064,.204102,.208008)]
            for text,ln in T.text_lines(p,rect):
                try:v=float(text)
                except ValueError:continue
                b=union(g.bbox for g in ln);centre=(b[0]+b[2])/2 if axis=='x' else (b[1]+b[3])/2
                if v==old and abs(centre-coord)<4.1:candidates.append(Match(p,ln,text,ln))
            T.glyphs[p]=oldglyphs
            assert len(candidates)==1,(ps,axis,old,coord,candidates)
            m=candidates[0];value=str(int(value))
            for g in m.glyphs:E.delete_group(p,g.oi,g.g)
            proof=copy_string(E,U,m,value,align='right' if axis=='y' else 'center')
            axes.append(dict(axis=axis,old=m.text,new=value,rect=union([m.bbox,proof['rect']]),proof=proof))
    allowed=union([plan['plot']]+[m['rect'] for m in moves]+[a['rect'] for a in axes])
    job._add(p,allowed,'Vẽ lại %s đường theo bảng; nhãn bỏ số 0 đầu' % len(plan['curves']),'chart')
    return dict(page=p+1,allowed=allowed,labels=moves,axes=axes,curve_count=len(plan['curves']),halos_deleted=len(oldhalos),halos_inserted=len(halo_proof),halo_proof=halo_proof)
