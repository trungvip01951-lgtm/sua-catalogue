"""Lấy màu/khung chữ đúng nguồn; không dựng glyph mới."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
measure=json.loads((folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'))
E=Editor(src,backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float)
core=[];records=[]
for word in measure['glyph_word_sources']:
    x0,y0,x1,y1=word['original_native_box'];rgb=a[y0:y1,x0:x1];l=rgb@[.299,.587,.114];chroma=rgb.max(2)-rgb.min(2);neutral=(l<90)&(chroma<25)
    samples=[]
    for x in range(rgb.shape[1]):
        rr=np.flatnonzero(neutral[:,x])
        if len(rr):samples.append(rgb[rr[np.argmin(l[rr,x])],x].tolist())
    records.append(dict(literal=word['literal'],source_native_box=word['original_native_box'],
                        darkest_column_sample_count=len(samples),source_dark_core_RGB_median=np.median(samples,axis=0).tolist()))
    core.extend(samples)
box=[400,179,746,227];z=a[box[1]:box[3],box[0]:box[2]];m=(z[:,:,2]-z[:,:,0]>45)&(z[:,:,1]-z[:,:,0]>20)&(z[:,:,0]<120)
v,u=np.where(m);bb=[box[0]+int(u.min()),box[1]+int(v.min()),box[0]+int(u.max()+1),box[1]+int(v.max()+1)]
zz=a[bb[1]:bb[3],bb[0]:bb[2]];ll=zz@[.299,.587,.114];cc=(zz[:,:,2]-zz[:,:,0]>45)&(zz[:,:,0]<120);title=[]
for x in range(zz.shape[1]):
    rr=np.flatnonzero(cc[:,x])
    if len(rr):title.append(zz[rr[np.argmin(ll[rr,x])],x].tolist())
Image.fromarray(cv.orig[bb[1]-3:bb[3]+3,bb[0]-3:bb[2]+3]).save(fresh(folder/'TIEU DE 4SA16 NGUON NGUYEN150dpi.png'))
out=dict(read_only=True,source_caption_core_RGB_median=np.median(core,axis=0).tolist(),source_caption_words=records,
         source_title_literal='4SA16',source_title_ink_native_bbox=bb,source_title_RGB_median=np.median(title,axis=0).tolist(),
         proposed_text_scale=1.0,proposed_opacity=1.0,
         proposed_contour_math='Alpha mực từ ảnh gốc: (255−L)/(255−L_core); đường đẳng alpha0,5, giữ topology, dùng catfix ghi đường bao. Đơn vị/tiêu đề học riêng; không glyph mới trong hồ sơ này.',
         source_caption_color_not_taken_from_Redpump=True,PDF_sample_written=False,new_glyph_written=False,
         source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest())
Path(fresh(folder/'MAU LOI CHU VA TIEU DE GOC.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('CAPTION CORE',out['source_caption_core_RGB_median'],'TITLE BOX',bb,'TITLE CORE',out['source_title_RGB_median'],flush=True)
E.close()
