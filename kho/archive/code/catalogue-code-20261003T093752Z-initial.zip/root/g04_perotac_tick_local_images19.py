"""Enlarge local original tick/number shapes, record narrow stem rows; no PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image,ImageDraw
import numpy as np,json
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/DOI CHIEU VACH PHU NGUON THAT'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));L=cv.orig.astype(float)@[.299,.587,.114]
for key,b in [('Q50 VA2-5',[172,668,218,712]),('H125 STEM',[113,236,136,256]),('Q3 SOURCE GRID MID',[190,564,213,590])]:
    x0,y0,x1,y1=b;raw=Image.fromarray(cv.orig[y0:y1,x0:x1]).resize(((x1-x0)*12,(y1-y0)*12),Image.Resampling.NEAREST);tile=Image.new('RGB',(raw.width+80,raw.height),'white');tile.paste(raw,(80,0));d=ImageDraw.Draw(tile)
    for yy in range(y0,y1,2):d.text((5,(yy-y0)*12+2),str(yy),fill=(20,20,20));d.line((65,(yy-y0)*12+6,78,(yy-y0)*12+6),fill=(150,150,150))
    tile.save(fresh(root/(key+' NGUON CO CHI SO HANG.png')))
out=[]
for key,y0,y1 in [('Q_M3_693_695',693,695),('Q_LMIN_677_678',677,678)]:
    v=(255-L[y0:y1,124:745]).mean(axis=0);b=float(np.median(v));w=np.maximum(v-b,0);runs=[]
    for j in np.flatnonzero(w>25):
        if runs and j==runs[-1][1]+1:runs[-1][1]=int(j)
        else:runs.append([int(j),int(j)])
    print(key,'DARK RUNS',[[a+124,b+124] for a,b in runs],flush=True)
    out.append(dict(key=key,native_rows=[y0,y1],native_col_first=124,source_darkness=v.tolist(),baseline=b,native_dark_runs=[[a+124,b+124] for a,b in runs]))
Path(fresh(root/'VACH DUOI HAI HANG RAT SAT DE DOI CHIEU.json')).write_text(json.dumps(dict(read_only=True,rows=out,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close()
