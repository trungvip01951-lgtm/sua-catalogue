"""Native punctuation source luminance matrix, read-only."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np
root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/CHU TRUC NGUON VA RAM CHI DOC'))
r=json.loads((root/'CHAM DAU GACH CHEO MA TRAN NGUON.json').read_text(encoding='utf8'))
for z in r:
    if z['key'] not in ['LMIN','IMP','US']:continue
    a=np.array(z['L']);print(z['key'],z['box'],flush=True)
    for yy,row in enumerate(a):print(str(z['box'][1]+yy)+' '+''.join('@' if v<100 else '%' if v<120 else '#' if v<160 else '+' if v<200 else '.' if v<235 else ' ' for v in row),flush=True)
    print('Dark min percolumn',[(z['box'][0]+i,round(float(a[:,i].min()))) for i in range(a.shape[1])],flush=True)
