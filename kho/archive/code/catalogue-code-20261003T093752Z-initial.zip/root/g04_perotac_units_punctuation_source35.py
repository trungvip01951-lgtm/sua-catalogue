"""Study true source punctuation separately, preserving tiny local ink mass."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from scipy.optimize import least_squares
from scipy.ndimage import gaussian_filter,distance_transform_edt
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/CHU TRUC NGUON VA RAM CHI DOC'));root=base/'DAU CHAM VA GACH CHEO CUNG NGUON TACH RIENG'
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));ink=np.array([57.,55.,57.]);zoom=64
cases=[('US DOT1',[729,155,731,159]),('US DOT2',[737,155,739,159]),('IMP DOT1',[730,171,732,175]),('IMP DOT2',[737,171,739,175]),('LMIN SLASH',[727,679,731,689])];out=[]
for key,b in cases:
    x0,y0,x1,y1=b;raw=cv.orig[y0:y1,x0:x1];al=R.alpha_of(raw,np.array([255.,255.,255.]),ink);h,w=al.shape;up=cv2.resize(np.pad(al,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);integral=float(al.sum());lo=.02;hi=.95
    for _ in range(35):
        mid=(lo+hi)/2
        if (up>=mid).sum()/zoom**2>integral:lo=mid
        else:hi=mid
    t=(lo+hi)/2;mask=up>=t;contours,hier=cv2.findContours(mask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);ps=[]
    for i,c in enumerate(contours):
        xy=(cv2.approxPolyDP(c,.05*zoom,True)[:,0,:].astype(float)+.5)/zoom-1;ps.append(dict(local_native_xy=xy.tolist(),parent=int(hier[0,i,3])))
    yy,xx=np.where(mask);bbox=[float(xx.min()/zoom-1),float(yy.min()/zoom-1),float((xx.max()+1)/zoom-1),float((yy.max()+1)/zoom-1)];primitive=None
    if key=='LMIN SLASH':
        # Only local source slash; shape is straight under source blur. No
        # outside glyph or claim of a lost FontProgram is introduced.
        def geom(z):
            top,bottom,width,low,high=z[:5];return np.array([[top-width/2,low],[top+width/2,low],[bottom+width/2,high],[bottom-width/2,high]])
        def raster(z):
            mm=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);d=ImageDraw.Draw(mm);d.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in geom(z)],fill=255);return np.array(mm)/255.
        def pred(z):
            m=gaussian_filter(raster(z),z[5]*zoom);return m.reshape(h+2,zoom,w+2,zoom).mean((1,3))[1:-1,1:-1]
        # Smooth raster generation uses native coordinates, fixed source box.
        init=[2.20,1.03,.87,1.06,8.56,.31]
        fit=least_squares(lambda z:np.r_[(pred(z)-al).ravel(),(np.asarray([cv2.contourArea(geom(z).astype(np.float32))])-integral)*.20],init,
            diff_step=.02,bounds=([1.5,.1,.4,.1,7.4,.05],[3.1,1.7,1.3,2.1,9.2,.8]),max_nfev=150)
        poly=geom(fit.x);pm=raster(fit.x)>0;ce=np.zeros_like(mask);pe=np.zeros_like(mask)
        for c in contours:ce[c[:,0,1],c[:,0,0]]=True
        pc,_=cv2.findContours(pm.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
        for c in pc:pe[c[:,0,1],c[:,0,0]]=True
        hd=max(float(distance_transform_edt(~ce)[pe].max()),float(distance_transform_edt(~pe)[ce].max()))/zoom
        area=float(pm.sum()/zoom**2);primitive=dict(source_fitted_straight_polygon_local_native=poly.tolist(),source_blur_fit_sigma_native=float(fit.x[5]),source_alpha_RMSE=float(np.sqrt(np.mean((pred(fit.x)-al)**2))),area_native_px=area,area_vs_local_source_alpha_percent=(area/integral-1)*100,
            max_bidirectional_edge_difference_from_source_mass_iso_native_px=hd,within_half_pixel_source_candidate_edge=hd<=.5,ROOT_review_pending=True)
    rec=dict(key=key,source_box=b,source_raw_RGB_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),source_alpha=al.tolist(),source_alpha_integral_native_px=integral,source_mass_iso_threshold=t,source_mass_iso_bbox_native=bbox,source_mass_iso_paths=ps,
        source_iso_components=int(sum(hier[0,i,3]<0 for i in range(len(contours)))),source_iso_holes=int(sum(hier[0,i,3]>=0 for i in range(len(contours)))),straight_slash_candidate=primitive,
        local_punctuation_measurement_only=True,source_lost_font_program_not_claimed=True,unit_literal_acceptance_pending=True)
    out.append(rec);tile=Image.new('RGB',(900,420),'white');tile.paste(Image.fromarray(raw).resize((w*30,h*30),Image.Resampling.NEAREST),(10,10));vp=Image.new('RGB',((w+2)*30,(h+2)*30),'white');d=ImageDraw.Draw(vp)
    pp=[dict(local_native_xy=primitive['source_fitted_straight_polygon_local_native'],parent=-1)] if primitive else ps
    for p in pp:d.polygon([((x+1)*30,(y+1)*30) for x,y in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
    tile.paste(vp,(400,0));tile.save(fresh(root/(key.replace(' ','_')+' NGUON VA UNG VIEN RIENG.png')))
    print(key,'area',integral,'CC/H',rec['source_iso_components'],rec['source_iso_holes'],'slash',primitive,flush=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();Path(fresh(root/'CAC DAU NHO NGUON TACH KHOI NGUONG CA TU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_original_Perotac_X7_only=True,source_punctuation_only=out,no_PDF_font_or_progress_written=True),ensure_ascii=False,indent=2),encoding='utf8');E.close()
