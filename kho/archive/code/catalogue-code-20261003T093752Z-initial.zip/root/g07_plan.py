from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from catfix import verify
from pathlib import Path
import json,re
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf';root=Path(S.report('G07'))
E=Editor(S.src(NAME));TL=TextLayer(E)
pairs=[('industrian','industriali'),('movimentazionee','movimentazione e'),('utllizzare','utilizzare'),
('peril sollevamentodl','per il sollevamento di'),('inseritidei','inseriti dei'),('spiacevolidanni','spiacevoli danni'),
('50 FHz','50 Hz'),('dean','clean'),('nothigherthan','not higher than'),('anda Schuko','and a Schuko'),
('threephase','three-phase'),('trlphasé','triphasé'),('IPB8','IP68'),('Kg³/m','kg/dm³')]
def gd(g):
    return dict(char=g.ch,rect=g.bbox,origin=g.o,font=g.run.font.basefont,fontname=str(g.run.fontname),
                size=g.run.size_page,fs=g.run.fs,Tm=g.run.Tm,ctm=g.run.ctm,tc=g.run.tc,tw=g.run.tw,th=g.run.th,
                run=g.run.index,k=g.k)
out=dict(pairs=[],table=[],font_k3=[],grids=[])
lines=TL.text_lines(0)
for old,new in pairs:
    for m in TL.find(0,old):
        r=m.glyphs[0].run
        same=[(t,gs) for t,gs in lines if any(g is m.glyphs[0] for g in gs)]
        lt,gs=same[0];rect=[min(g.bbox[0] for g in gs),min(g.bbox[1] for g in gs),max(g.bbox[2] for g in gs),max(g.bbox[3] for g in gs)]
        try:delta=TL.width_ts(r,new)*r.scale_x-(m.glyphs[-1].e[0]-m.glyphs[0].o[0])
        except Exception as ex:delta=str(ex)
        out['pairs'].append(dict(old=old,new=new,rect=m.bbox,line=lt,line_rect=rect,delta=delta,runtext=r.text,glyphs=[gd(g) for g in m.glyphs]))
        print(old,'->',new,'line=',lt,'rect=',rect,'delta=',delta,'run=',r.text,flush=True)
for t,gs in lines:
    if min(g.bbox[0] for g in gs)>640:
        out['table'].append(dict(text=t,glyphs=[gd(g) for g in gs]))
seen=set()
for r in TL.runs(0):
    if id(r.font) in seen:continue
    seen.add(id(r.font));present={}
    for ch in 'k³':
        try:present[ch]=r.font.encode(ch).hex()
        except Exception as ex:present[ch]=str(ex)
    out['font_k3'].append(dict(font=r.font.basefont,fontname=str(r.fontname),present=present,sample=r.text))
for oi,ob in enumerate(E.page(0).objs):
    if ob['op'] in ['S','s','f','f*','B','B*','b','b*'] and ob['bbox'][0]>640:
        out['grids'].append(dict(index=oi,rect=ob['bbox'],fill=ob.get('fill'),stroke=ob.get('stroke'),lw=ob.get('lw')))
json.dump(out,open(fresh(root/'plan.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
verify.crop(S.src(NAME),0,(70,60,570,585),220).save(fresh(root/'mo-ta-truoc.png'))
E.close()
