from catwork import start
S,D,N=start()
from pathlib import Path
import json,numpy as np
from scipy.signal import find_peaks
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));p=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));f=json.loads((root/'KHUNG LUOI THAT NGUON TRANG8.json').read_text(encoding='utf8'));fr=next(z for z in f['panels'] if z['name']=='QH');E=Editor(p['method']['source'],backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);g=R.canvas(im).orig.astype(float)@np.array([.299,.587,.114]);rf=fr['frame_native_uv'][2];print('native frame x',rf,flush=True)
for u in range(int(rf)+1,int(rf)+7):
 score=255-g[190:560,u];peaks,_=find_peaks(score,prominence=5,height=15,distance=10);best=sorted(peaks,key=lambda i:score[i],reverse=True)[:18];print('u',u,[(int(k+190),round(float(score[k]),2)) for k in sorted(best)],flush=True)
E.close()
