from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from PIL import Image
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
im=Image.open(root/'BANG NGUON 05 4SL3.png').convert('RGB');w,h=im.size
p=im.crop((int(w*.756),int(h*.392),int(w*.819),int(h*.443)));p=p.resize((p.width*3,p.height*3),Image.Resampling.NEAREST);p.save(fresh(root/'SOI 4SL3_15 Q3.png'));print('original',im.size,'crop',p.size,flush=True)
