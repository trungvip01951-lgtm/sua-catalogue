from catwork import start,fresh
S,D,N=start()
from catfix.recipes import Job
from catfix import verify
import json,re,time
from pathlib import Path
name='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
job=S.job(name)
T=job.T
T.learn(list(range(32)),dpi=400)
mapping={}
for p in range(32):
    lines=[]
    for text,gl in T.text_lines(p):
        r=(min(g.bbox[0] for g in gl),min(g.bbox[1] for g in gl),max(g.bbox[2] for g in gl),max(g.bbox[3] for g in gl))
        lines.append({'text':text,'rect':r})
    mapping[str(p+1)]=lines
    print('TRANG',p+1,flush=True)
    T.dump(p,rect=(0,0,600,65))
    for pat in ['Warranty: 1 year','Components',r'(\d+SP\d+)-0(\d)','Motor power (Kw)','KW','Hp','Diffuser']:
        ms=T.find(p,pat,regex='\\d' in pat)
        print(pat,[(m.text,tuple(round(v,2) for v in m.bbox)) for m in ms],flush=True)
Path(fresh(S.report('G01/ban-do-chu.json'))).write_text(json.dumps(mapping,ensure_ascii=False,indent=1),encoding='utf-8')
for p in [0,1,15,21,25,27,29,31]:
    verify.crop(job.src,p,(120,380,570,635) if p>1 else (0,0,120,65),dpi=150).save(fresh(S.report(f'G01/bang-nguon-{p+1}.png')))
job.close()
