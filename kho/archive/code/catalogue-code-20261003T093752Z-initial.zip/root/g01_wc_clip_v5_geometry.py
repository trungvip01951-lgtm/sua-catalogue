"""V5 source geometric contours only. No pixel edit, raster output, PDF or ledger write."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,math,csv,copy,re,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
from g01_wc_clip_math import parse,area,dist,bbox,winding,windall,intersections,intervals

IP=HERE/'wc_clip_source_du_lieu_20261003'/'DU LIEU DUONG CAT NGUON V4B BIEN THAN DUNG'/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json'
LOCK='d2356789b101589037eb587a6e75af4ce899e0c5297e6f316969217c162cce7a'
RAM=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs\per_wc_continue_photo_union_v4B_RAM_a1')
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 DU LIEU HINH HOC'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def savej(name,d):
    p=Path(fresh(O/name));p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');return p
assert sha(IP)==LOCK
raw=json.loads(IP.read_text(encoding='utf8'))
file='Catalog cắt rác perotac (bản mới).pdf'
guards={str(IP):LOCK,str(S.src(file)):'622bcc5a8bb0562bea11474bda8801f30fe91839db3b84980dcb4ead056131d4',str(S.dst(file)):'5418b7bddd8d76eb09148f0f1f469609c2af77544a4ef4196e314900110b7f3d'}
for g in raw['groups']:guards[g['source_JPEG']]=g['source_JPEG_sha256']
for p,h in guards.items():assert sha(p)==h

old={g['group']:[parse(q) for q in g['combined_clip_subpaths']] for g in raw['groups']}
RGB={g['group']:np.array(Image.open(g['source_JPEG']).convert('RGB')) for g in raw['groups']}
# These numeric traces were selected from the actual JPEG + visual source and RAM;
# no pixel threshold or color mask is used to derive them.
plans=[
 {'id':'G1_01','group':1,'ring':0,'indices':[0,9],'old_anchors':[[78,20],[78,258]],'new_chain':[[78,20],[78,200],[77,203],[77,237],[78,240],[78,258]],'why':'Mực nước nhô ngoài mép ống đôi bên phải; giữ cột kim loại 75 và mép pha trộn 76.','ink':[[77,207],[78,228],[77,234]],'metal':[[75,207],[75,228],[76,100]],'source_roi':[70,200,83,244]},
 {'id':'G1_02','group':1,'ring':0,'indices':[35,52],'old_anchors':[[98,261],[98,20]],'new_chain':[[98,261],[98,231],[99,228],[99,181],[98,178],[98,20]],'why':'Các cục nước bên trái thanh đơn; mép kim loại thật ở cột 99 được giữ.','ink':[[97,188],[96,223],[97,191]],'metal':[[99,188],[99,223],[102,217]],'source_roi':[93,178,106,232]},
 {'id':'G1_03','group':1,'ring':0,'indices':[53,74],'old_anchors':[[108,20],[108,256]],'new_chain':[[108,20],[108,256]],'why':'Các gai nước ngoài cạnh thẳng phải thanh đơn; giữ toàn cột kim loại 107 và đường thẳng x108 đã có trong nguồn.','ink':[[110,177],[110,214]],'metal':[[107,177],[107,214],[105,223]],'source_roi':[103,167,113,222]},
 {'id':'G1_04','group':1,'ring':0,'indices':[106,108],'old_anchors':[[145,180],[160,162]],'new_chain':[[145,180],[149,175],[149,162],[160,162]],'why':'Cắt khối nước rõ x145–148 ở bên trái quai nhỏ; giữ phần quai x149 trở vào vì ít pixel và mờ.','ink':[[145,168],[145,170],[147,168]],'metal':[[155,166],[157,168],[149,176]],'source_roi':[143,160,164,181]},
 {'id':'G1_05','group':1,'ring':0,'indices':[232,248],'old_anchors':[[53,257],[53,158]],'new_chain':[[53,257],[53,246],[54,243],[54,209],[53,206],[53,158]],'why':'Cục nước xanh nhô trái ống đôi; giữ toàn pixel kim loại 54/55, kể cả phần pha màu sát cạnh.','ink':[[50,239],[52,215],[52,235],[52,231]],'metal':[[54,239],[54,215],[55,235]],'source_roi':[46,205,60,247]},
 {'id':'G2_01','group':2,'ring':2,'indices':[1003,1018],'old_anchors':[[396,838],[395,531]],'new_chain':[[396,838],[396,834],[396.5,830],[396.5,788],[395,785],[395,531]],'why':'Thu biên giữ sai x394–395 quanh vách trái. Chừa phần pha màu sát vật liệu x396; toàn thân từ x397 giữ.','ink':[[395,809],[394,792],[394,823]],'metal':[[397,809],[397,792],[397,823],[396,780]],'source_roi':[390,783,405,838]},
 {'id':'G3_01','group':3,'ring':4,'indices':[557,571],'old_anchors':[[177,779],[177,706]],'new_chain':[[177,779],[177,740],[178,737],[179,733],[179,712],[178,707],[177,706]],'why':'Thu các gai nước ngoài vách trái, giữ cột 179/180 và mép pha trộn; không thay phần thân thấp.','ink':[[177,717],[178,724],[176,726]],'metal':[[180,717],[179,735],[179,714],[178,738]],'source_roi':[171,704,185,741]},
 {'id':'G3_02','group':3,'ring':9,'indices':[309,339],'old_anchors':[[610,532],[593,493]],'new_chain':[[610,532],[607,528],[604,524],[600,520],[597,518],[595,514],[593,510],[593,493]],'why':'Bỏ khối nước ngoài phần động cơ phải, nối các biên nguồn thấy rõ với khoảng giữ thận trọng 1–2 pixel; không cắt phần màu pha ngay vật liệu.','ink':[[591,523],[588,520],[598,523],[600,523],[594,525]],'metal':[[595,508],[598,514],[600,519],[604,521],[606,523],[612,532]],'source_roi':[584,492,623,534]}
]

new={k:[p.copy() for p in v] for k,v in old.items()};edits=[]
for group,ring in sorted(set((q['group'],q['ring']) for q in plans)):
    orig=old[group][ring];chain=orig.tolist()
    # Index references always address V4B, apply from highest to lowest.
    for q in sorted([q for q in plans if (q['group'],q['ring'])==(group,ring)],key=lambda q:q['indices'][0],reverse=True):
        a,b=q['indices'];assert orig[a].tolist()==q['old_anchors'][0] and orig[b].tolist()==q['old_anchors'][1]
        replacement=np.array(q['new_chain'],dtype=float)
        test=np.vstack([orig[:a],replacement,orig[b+1:]])
        removed=area(orig)-area(test)
        assert removed>0,(q['id'],removed)
        delta_poly=np.vstack([orig[a:b+1],replacement[-2:0:-1]])
        d=dict(q)
        d.update(old_chain_source_pixel=orig[a:b+1].tolist(),removed_continuous_area_pixel2=removed,changed_bbox_source_pixel=bbox(delta_poly),original_ring_area=area(orig),individual_modified_ring_area=area(test),evidence_source_JPEG=raw['groups'][group-1]['source_JPEG'],evidence_source_sha256=raw['groups'][group-1]['source_JPEG_sha256'],evidence_before_photo_600=str(RAM/f'per_wc_continue_union_v4_group{group}_p{raw["groups"][group-1]["pages"][0]:02d}_before_photo_600dpi.png'),evidence_V4B_RAM_photo_600=str(RAM/f'per_wc_continue_union_v4_group{group}_p{raw["groups"][group-1]["pages"][0]:02d}_RAM_photo_600dpi.png'),method='Explicit geometric trace only, chosen conservatively after inspecting original source and its row profiles; no image mask')
        edits.append(d)
        chain[a:b+1]=replacement.tolist()
    new[group][ring]=np.array(chain,dtype=float)
edits.sort(key=lambda x:x['id'])

def center_intervals(polys,y):
    out=[]
    for lo,hi in intervals(polys,y+.5):
        a=math.ceil(lo-.5);b=math.ceil(hi-.5)
        if b>a:
            if out and a<=out[-1][1]:out[-1][1]=max(out[-1][1],b)
            else:out.append([a,b])
    return out
def diff_intervals(a,b):
    """a minus b in sorted half-open integer intervals."""
    out=[]
    for l,r in a:
        p=l
        for x,y in b:
            if y<=p:continue
            if x>=r:break
            if x>p:out.append([p,min(x,r)])
            p=max(p,y)
            if p>=r:break
        if p<r:out.append([p,r])
    return out

pixel_changes={};geometry=[]
for g in raw['groups']:
    num=g['group'];w,h=g['source_canvas_pixel'];removed=[];added=[];lr=[];sh=[];ih=[]
    for y in range(h):
        before=center_intervals(old[num],y);after=center_intervals(new[num],y)
        removed.extend([[x0,x1,y] for x0,x1 in diff_intervals(before,after)])
        added.extend([[x0,x1,y] for x0,x1 in diff_intervals(after,before)])
    assert not added,(num,'Geometry unexpectedly added original pixels',added[:10])
    pixel_changes[num]={'removed_intervals_at_pixel_centers':removed,'removed_pixel_centers':sum(b-a for a,b,y in removed),'added_pixel_centers':0,'all8_old_hole_commands_equal':None,'note':'Numerical row intervals only; no bitmap/mask image is constructed or saved.'}
    for k,p in enumerate(new[num]):
        q=g['combined_clip_subpaths'][k];ap=area(p);assert (ap>0)==(q['role']=='outer')
        assert np.all(p[:,0]>=0) and np.all(p[:,0]<=w) and np.all(p[:,1]>=0) and np.all(p[:,1]<=h)
        if q['role']=='hole':assert np.array_equal(old[num][k],p)
        ss=intersections(p,p,True);sh.extend([dict(ring=k,**v) for v in ss]);lr.append({'ring':k,'role':q['role'],'old_area_pixel2':area(old[num][k]),'V5_area_pixel2':ap,'removed_area_pixel2':area(old[num][k])-ap,'old_bbox_source_pixel':bbox(old[num][k]),'V5_bbox_source_pixel':bbox(p),'old_vertices':len(old[num][k]),'V5_vertices':len(p),'commands_unchanged':bool(np.array_equal(old[num][k],p))})
    for i in range(len(new[num])):
        for j in range(i+1,len(new[num])):ih.extend([dict(ring1=i,ring2=j,**v) for v in intersections(new[num][i],new[num][j])])
    assert not any(v['kind']=='strict_cross' for v in sh) and not ih,(num,sh,ih)
    outer=[i for i,q in enumerate(g['combined_clip_subpaths']) if q['role']=='outer'];holes=[i for i,q in enumerate(g['combined_clip_subpaths']) if q['role']=='hole']
    hp=[]
    for i in holes:
        p=new[num][i];t=np.vstack([p,(p+np.roll(p,-1,axis=0))/2]);pa=[j for j in outer if np.all(winding(new[num][j],t)!=0)];assert len(pa)==1
        hp.append({'hole_ring':i,'parent_outer':pa[0],'vertices_midpoints_tested':len(t),'V4B_exact_vertices_preserved':True})
    geometry.append({'group':num,'outer_components_before_after':[len(outer),len(outer)],'holes_before_after':[len(holes),len(holes)],'rings':lr,'hole_containment':hp,'self_contacts':sh,'strict_crossings':0,'cross_ring_intersections':0,'continuous_area_before_pixel2':sum(area(p) for p in old[num]),'continuous_area_V5_pixel2':sum(area(p) for p in new[num]),'removed_continuous_area_pixel2':sum(area(p) for p in old[num])-sum(area(p) for p in new[num]),'added_pixel_centers':0,'removed_pixel_centers':pixel_changes[num]['removed_pixel_centers']})
    pixel_changes[num]['all_old_hole_commands_equal']=True
    pixel_changes[num].pop('all8_old_hole_commands_equal')

def witness(group,pt,visible,label,typ):
    p=[float(x) for x in pt];wi=int(windall(new[group],[p])[0]);passed=(wi!=0)==visible
    rgb=RGB[group][int(math.floor(p[1])),int(math.floor(p[0]))].tolist()
    r={'group':group,'label':label,'kind':typ,'point_source_pixel':p,'winding_V4B':int(windall(old[group],[p])[0]),'winding_V5':wi,'expected_visible':visible,'result':'ĐẠT' if passed else 'CHƯA ĐẠT','min_boundary_distance_pixel':min(dist(r,p) for r in new[group]),'source_RGB':rgb}
    assert passed,r
    return r
wit=[]
for q in raw['source_landmarks']:wit.append(witness(q['group'],q['source_xy'],q['meaning']=='product','điểm cũ '+q['meaning'],'original19'))
for g in raw['groups']:
    for q in g['clear_foot_background_tests']:wit.append(witness(g['group'],q['source_xy'],False,'tâm khe chân cũ','original8feet'))
extra=[]
for q in edits:
    for xy in q['ink']:
        extra.append(witness(q['group'],[xy[0]+.5,xy[1]+.5],False,q['id']+' mực nước '+str(xy),'added_exclude_water'))
    for xy in q['metal']:
        extra.append(witness(q['group'],[xy[0]+.5,xy[1]+.5],True,q['id']+' kim loại '+str(xy),'added_keep_metal'))

rois=[]
for num,label,bb in [(1,'7.5KW',[184,18,233,35]),(1,'nước trái xa',[0,194,39,239]),(2,'11KW',[58,82,224,130]),(2,'nước trái xa',[0,891,163,1037]),(3,'nước trái xa',[0,650,154,800])]:
    x0,y0,x1,y1=bb;rect=np.array([[x0,y0],[x1,y0],[x1,y1],[x0,y1]],dtype=float);hit=[];ins=0
    for k,p in enumerate(new[num]):
        hit.extend([dict(ring=k,**v) for v in intersections(p,rect)]);ins+=int(np.sum((p[:,0]>x0)&(p[:,0]<x1)&(p[:,1]>y0)&(p[:,1]<y1)))
    center=[(x0+x1)/2,(y0+y1)/2];wn=int(windall(new[num],[center])[0]);assert not hit and not ins and wn==0
    rois.append({'group':num,'name':label,'source_rectangle':bb,'whole_rectangle_excluded':True,'boundary_rect_crossings':0,'clip_vertices_interior':0,'center_winding':0,'result':'ĐẠT'})
xx=np.arange(515,822,dtype=float)+.5;tt=np.column_stack([xx,np.full_like(xx,798.5)])
assert np.all(windall(new[3],tt)==0)
gapRGB=RGB[3][798,515:822]
gap={'group':3,'source_row':798,'x_range':[515,822],'pixel_centers_checked':len(tt),'V5_visible_count':int(np.sum(windall(new[3],tt)!=0)),'source_RGB_min_by_channel':gapRGB.min(axis=0).tolist(),'source_RGB_max_by_channel':gapRGB.max(axis=0).tolist(),'source_RGB_median_by_channel':np.median(gapRGB,axis=0).tolist(),'note':'Khe thật giữa hai chi tiết rời bên phải giữ nguyên; không nối cụm. Vòng quai và 8 khe chân không đổi.'}

groups=[];svgchecks=[]
for g in raw['groups']:
    num=g['group'];w,h=g['source_canvas_pixel'];subs=[];ds=[]
    for k,p in enumerate(new[num]):
        role=g['combined_clip_subpaths'][k]['role']
        cs=[['M',*p[0].tolist()]]+[['L',*v.tolist()] for v in p[1:]]+['Z']
        subs.append({'role':role,'commands_pixel':cs,'signed_area_source_pixel2':area(p),'bbox_source_pixel':bbox(p)})
        ds.append(' '.join([('M ' if i==0 else 'L ')+f'{v[0]:.10g} {v[1]:.10g}' for i,v in enumerate(p)])+' Z')
    # Source-coordinate diagrams only: no embedded raster product, no soft mask.
    svg=O/f'g01_NHOM{num} DUONG CAT NGUON V5.svg'
    xml=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><title>V5 - Source coordinate contour diagram only</title><desc>Nonzero clipping geometry; not a production image or soft mask. JPEG bytes unchanged.</desc><path fill="#aeb6be" stroke="none" fill-rule="nonzero" d="'+ ' '.join(ds)+'"/></svg>'
    Path(fresh(svg)).write_text(xml,encoding='utf8')
    node=ET.fromstring(svg.read_text(encoding='utf8'));pa=node.find('{http://www.w3.org/2000/svg}path');assert pa.attrib['fill-rule']=='nonzero'
    toks=re.findall(r'[MLZ]|[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?',pa.attrib['d']);read=[];buf=[];i=0
    while i<len(toks):
        op=toks[i];i+=1
        if op=='Z':buf.append('Z');read.append(parse({'commands_pixel':buf}));buf=[]
        else:
            assert op in ('M','L');buf.append([op,float(toks[i]),float(toks[i+1])]);i+=2
    assert len(read)==len(new[num]) and all(np.array_equal(a,b) for a,b in zip(read,new[num]))
    svgchecks.append({'group':num,'SVG':str(svg),'SVG_sha256':sha(svg),'subpaths_read_directly':len(read),'coordinate_arrays_exact':True,'fill_rule':'nonzero','no_RGB_embedded':True})
    groups.append({'group':num,'pages':g['pages'],'source_JPEG':g['source_JPEG'],'source_JPEG_sha256':g['source_JPEG_sha256'],'source_canvas_pixel':g['source_canvas_pixel'],'fill_rule':'nonzero','pdf_clip_operator':'W n với combined_clip_subpaths; không W*, không construction.','combined_clip_subpaths':subs,'geometry_svg':str(svg),'clear_foot_background_tests':[{'source_xy':q['source_xy'],'expected_visible':False} for q in g['clear_foot_background_tests']],'unknown_regions':g['unknown_regions'],'V5_edits':[q for q in edits if q['group']==num],'unknown_additional':'Mực xanh/phản sắc chồng ngay rìa vật liệu, quai nhỏ mờ và phần chi tiết sáng không phân biệt chắc: giữ pixel gốc, không khoét thêm. V5 chờ ROOT soi RAM.'})

output={'version':'V5_SOURCE_GEOMETRY_ONLY_8_LOCAL_BOUNDARY_EDITS_PENDING_ROOT_RAM_VISUAL','source_only':True,'source_RGB_modified':False,'AI_source_shape_used':False,'PDF_written':False,'final_composite_written':False,'geometry_svg_not_production_asset':True,'base_geometry_file':str(IP),'base_geometry_sha256':LOCK,'source_PDF_sha256':guards[str(S.src(file))],'canonical_untouched_sha256':guards[str(S.dst(file))],'groups':groups,'source_landmarks':[{'group':q['group'],'source_xy':q['source_xy'],'meaning':q['meaning']} for q in raw['source_landmarks']],'original27_witnesses_read_again':wit,'additional_water_and_metal_witnesses':extra,'excluded_regions5':rois,'actual_source_gap_proof_V5':gap,'limitations':['Chỉ đạt hình học/tọa độ ở các đoạn được nêu; 27 điểm/5 vùng không chứng minh toàn cấu tạo.','Không xử lý JPEG, không lấy màu làm mặt nạ, không dựng RGB/chi tiết AI, không có PDF ảnh.','Viền xanh ngay rìa vật liệu và quai mờ vẫn có thể còn; giữ vùng gốc và cần xem RAM ở 150/600dpi.','Sơ đồ SVG chỉ dùng truyền lệnh M/L/Z, không thay ảnh sản phẩm hoặc làm mặt nạ mềm.'],'note_for_writer':'Dùng duy nhất groups[].combined_clip_subpaths[].commands_pixel M/L/Z. Pixel gốc trên trái/y xuống; đổi (u/W,1-v/H) qua đúng CTM ảnh nguồn. Chèn W n, không W*, giữ JPEG/dictionary/SMask/CTM và all native chữ/bảng/đường khác; chưa PDF tới khi ROOT nghiệm thu RAM V5.'}
op=savej('g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json',output)
qa={'geometry_file':str(op),'geometry_sha256':sha(op),'base_file_sha256':LOCK,'edits_count':len(edits),'geometry':geometry,'source_pixel_interval_changes':pixel_changes,'witnesses27':wit,'additional_witnesses':extra,'excluded_regions5':rois,'source_gap_proof':gap,'SVG_actual_readback':svgchecks,'source_guards':guards,'math_result':'ĐẠT các phép kiểm liệt kê; chưa phải nghiệm thu toàn ảnh','RAM_visual_result':'CHƯA KIỂM V5; yêu cầu ROOT dựng RAM từ chính hash này','PDF_written':False,'raster_written':False,'TIEN_DO_written':False,'no_source_RGB_changes':True}
qaop=savej('g01_NGHIEM THU HINH HOC V5 DOC LAI SVG VA NGUON.json',qa)
with open(fresh(O/'g01_TUNG DOAN BIEN SUA V5.csv'),'w',encoding='utf-8-sig',newline='') as f:
    names=['id','group','ring','indices_V4B','old_anchors','new_chain','source_roi','removed_area_pixel2','changed_bbox','why'];wr=csv.DictWriter(f,fieldnames=names);wr.writeheader()
    for q in edits:wr.writerow({'id':q['id'],'group':q['group'],'ring':q['ring'],'indices_V4B':json.dumps(q['indices']),'old_anchors':json.dumps(q['old_anchors']),'new_chain':json.dumps(q['new_chain']),'source_roi':json.dumps(q['source_roi']),'removed_area_pixel2':q['removed_continuous_area_pixel2'],'changed_bbox':json.dumps(q['changed_bbox_source_pixel']),'why':q['why']})
with open(fresh(O/'g01_DIEM THEM MUC LOAI VA KIM LOAI GIU V5.csv'),'w',encoding='utf-8-sig',newline='') as f:
    fields=['group','label','kind','x','y','winding_V4B','winding_V5','expected_visible','distance_pixel','R','G','B','result'];wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
    for q in extra:
        x,y=q['point_source_pixel'];r,g,b=q['source_RGB'];wr.writerow({'group':q['group'],'label':q['label'],'kind':q['kind'],'x':x,'y':y,'winding_V4B':q['winding_V4B'],'winding_V5':q['winding_V5'],'expected_visible':q['expected_visible'],'distance_pixel':q['min_boundary_distance_pixel'],'R':r,'G':g,'B':b,'result':q['result']})
manifest=json.loads((RAM/'per_wc_continue_photo_union_v4_manifest.json').read_text(encoding='utf8'));mchecks=[]
for q in manifest['files']:
    p=RAM/q['file'];mchecks.append({'file':str(p),'sha256_read':sha(p),'expected_sha256':q['sha256'],'bytes_read':p.stat().st_size,'bytes_expected':q['bytes'],'match':sha(p)==q['sha256'] and p.stat().st_size==q['bytes']})
assert all(q['match'] for q in mchecks)
savej('g01_RAM V4B CHUNG CU DA MO VA MA KIEM.json',{'RAM_manifest_sha256':sha(RAM/'per_wc_continue_photo_union_v4_manifest.json'),'files':mchecks,'all19_file_identities_match':True,'images_seen':'Cả 3 nhóm: toàn trang150, trước/sau ảnh150, trước/sau ảnh600; nguồn JPEG cũng đã mở trực tiếp','V4B_appearance':'CHƯA ĐẠT: các mực thừa rõ đã lập 8 đoạn V5; V5 chưa dựng RAM','note':'RAM PDF không được lưu xuống đĩa nên độc lập ở đây không xác nhận byte stream mẫu PDF; chỉ kiểm dữ liệu V5 và ảnh PNG RAM cung cấp.'})
for p,h in guards.items():assert sha(p)==h
md=['# Dữ liệu đường cắt nguồn V5 — chờ soi ảnh ghép trong bộ nhớ','',f'**Đã xong dữ liệu hình học cho 8 đoạn; chưa nghiệm thu ảnh V5 và chưa ghi PDF.** Tệp g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json, SHA256 `{sha(op)}`. SHA256 là mã kiểm nội dung tệp.','', 'Chỉ dùng đường cắt đã hợp nhất V4B có SHA d235…cce7a. Giữ nguyên 3 JPEG (định dạng ảnh gốc), mặt nạ có sẵn, tọa độ đặt ảnh và bản giao 5418…f3d. Mọi thay đổi là tọa độ đường cắt; không sửa điểm ảnh và không dựng lại bơm.', '', f'Đã đọc lại SVG (tệp mô tả đường hình học) đúng M/L/Z và phép W n (cắt theo tổng chiều vòng): 27/27 mốc cũ, {len(extra)}/{len(extra)} mốc bổ sung và 5/5 vùng loại đạt. {sum(q["kind"]=="added_exclude_water" for q in extra)} mốc mực nước bị bỏ; {sum(q["kind"]=="added_keep_metal" for q in extra)} mốc kim loại sát cạnh được giữ. Không có điểm ảnh nguồn nào được thêm vào miền cắt.', '', '| STT | Tệp | Trang | Việc | Trước | Sau | Nghiệm thu | Chứng cứ |','|---|---|---|---|---|---|---|---|']
for q in edits:
    pages=','.join(str(p) for p in raw['groups'][q['group']-1]['pages']);md.append(f'| {q["id"]} | Perotac WC | {pages} | {q["why"]} | Biên V4B giữ mực nước | Thu riêng đoạn biên; bỏ {q["removed_continuous_area_pixel2"]:.4f} pixel² | Mốc mực/kim loại đạt; chờ hình RAM | ROI {q["source_roi"]}; JSON có đoạn cũ/mới, ảnh trước/RAM V4B và RGB nguồn |')
md+=['','| Nhóm | Cụm ngoài giữ | Vòng lỗ giữ | Diện tích trước → V5 (pixel²) | Tâm điểm ảnh bị bỏ |','|---|---|---|---|---|']
for q in geometry:md.append(f'| {q["group"]} | {q["outer_components_before_after"][0]} → {q["outer_components_before_after"][1]} | {q["holes_before_after"][0]} → {q["holes_before_after"][1]} | {q["continuous_area_before_pixel2"]:.4f} → {q["continuous_area_V5_pixel2"]:.4f} | {q["removed_pixel_centers"]} |')
md+=['','Cả 12 vòng lỗ của ba nhóm giữ nguyên tọa độ; mỗi vòng nằm trong đúng cụm cũ. Hai quai dây, 8 tâm khe chân và khe hàng y798 giữa hai chi tiết bên phải nhóm 3 giữ. Diện tích liên tục của đa giác khác số tâm điểm ảnh; không trộn hai phép đếm.','', '**Giới hạn:** các mực xanh pha ngay rìa kim loại, quai nhỏ ít pixel, mép trắng/bóng và vùng không phân biệt chắc vẫn giữ nguồn. 27 điểm cùng 5 vùng chỉ chứng minh đúng phạm vi đó; chưa thể gọi toàn cấu tạo hoặc toàn ảnh sạch. Không có ảnh sản phẩm mới, PNG mới, PDF hay cập nhật TIEN DO.md.','', 'Bước kế tiếp: tác nhân ghi ảnh dựng đúng V5 theo mã kiểm trong bộ nhớ, giữ toàn bộ chữ/bảng/38 đường đã nghiệm thu, rồi ROOT mở cả ba nhóm ở 150/600 điểm ảnh mỗi inch. Chỉ kết luận hình thức sau đọc ảnh thật.']
md[-3]=md[-3].replace('12 vòng','12 vòng') # counts computed explicitly in readback below
md=[line.replace('Cả 12 vòng lỗ','Cả '+str(sum(q['holes_before_after'][0] for q in geometry))+' vòng lỗ') for line in md]
mp=Path(fresh(O/'g01_BAO CAO 8 COT VA BAN GIAO V5.md'));mp.write_text('\n'.join(md),encoding='utf8')
print('GEOMETRY',op,'SHA',sha(op),flush=True)
print('QA',qaop,'SHA',sha(qaop),flush=True)
print('REPORT',mp,flush=True)
print('EDITS',len(edits),'EXTRA',len(extra),'GEOMETRY',[(g['group'],g['continuous_area_V5_pixel2'],g['removed_pixel_centers']) for g in geometry],flush=True)
