"""Own-file small label5 donor reading; no PDF modifications."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
folder=M/'CHU5 NGUON P8 DOI CHIEU LAN1';assert not folder.exists()
b=json.loads((M/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'))
w=json.loads((P/'CHU NGUON ALPHA THU DO DOC V2.json').read_text(encoding='utf8'))
bank=json.loads((P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();h=sha(b['source']);assert h==b['source_SHA256']
E=Editor(b['source'],backend='fitz');R=Raster(E);cv=R.render_canvas(7,w['source_rect'],dpi=600)
sheet=Image.new('RGB',(1500,650),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(17);records=[]
for j,name in enumerate(['4SL16/5','4SL16/25']):
    r=next(q for q in w['records'] if q['model']==name);box=r['source_render_rect'];x0,y0,x1,y1=box
    rgb=cv.orig[y0:y1,x0:x1].copy();rect=[*cv.to_page(x0,y1),*cv.to_page(x1,y0)]
    raw=fresh(folder/(name.replace('/','_')+' NGUYEN CUM600.png'));Image.fromarray(rgb).save(raw)
    dr.text((5,j*260+5),name+' nguyên nguồn p8, cùng kiểu nhỏ; chưa chọn donor',fill='blue',font=ft)
    pic=Image.fromarray(rgb);sheet.paste(pic.resize((pic.width*4,pic.height*4),Image.Resampling.NEAREST),(200,j*260+35))
    Image.fromarray(np.array(verify.crop(b['source'],7,rect,150))).save(fresh(folder/(name.replace('/','_')+' NGUYEN CUM150.png')))
    records.append(dict(model=name,page=8,source_render_box=box,source_page_box=rect,RGB_shape=list(rgb.shape),RGB=rgb.tolist(),source_request_rect=w['source_rect'],actual_render_rect=cv.rect0))
old=next(r for r in bank['records'] if r['character']=='5');pic=Image.fromarray(np.round(255*(1-np.array(old['source_alpha']))).astype('uint8')).convert('RGB')
dr.text((5,525),'5 donor V3: '+old['source_word']+' p'+str(old['source_page']),fill='blue',font=ft)
sheet.paste(pic.resize((pic.width*3,pic.height*3),Image.Resampling.NEAREST),(250,525))
photo=fresh(folder/'NGUYEN2CUM P8 VA5 NGAN HANG NGUON.png');sheet.save(photo)
Path(fresh(folder/'NGUON5 DOI CHIEU TU CHINH FILE.json')).write_text(json.dumps(dict(source=b['source'],source_SHA256=h,records=records,old5source=old,
    source_only=True,PDF_written=False,new_font=False,status='Chỉ đối chứng nguồn nhỏ; chưa thay bank hoặc chốt hình thức.'),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert sha(b['source'])==h
print(photo,flush=True)
