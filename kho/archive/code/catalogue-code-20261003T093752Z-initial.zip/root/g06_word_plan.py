from catwork import start, fresh
S,D,N=start()
from catfix.raster import Raster
from catfix.vector import Editor
from pathlib import Path
from g06_word_tools import grid_mask,word_piece,LABELS
import json,numpy as np

root=Path(S.report('G06'));src=S.src('Aquaris FS_300dpi_75% (bản mới).pdf')
geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
probe=json.loads((root/'review'/'word-copy-source-geometry.json').read_text(encoding='utf-8'))
E=Editor(src);R=Raster(E);cv=R.canvas(R.image_at(3,E.mediabox(3)))
grid,grecs=grid_mask(cv,geo)
standard=[];rows=[]
for rr in probe['rows']:
    ws=[w for w in rr['words'] if any(ch.isalpha() for ch in w['text'])]
    target=rr['row'] in LABELS
    labels=LABELS[rr['row']] if target else [w['text'].strip('|') for w in ws]
    assert len(labels)==len(ws)
    pieces=[word_piece(cv,R,w,rr['box'],grid,label) for label,w in zip(labels,ws)]
    baseline=float(np.median([p['baseline_metric'] for p in pieces if p['baseline_metric'] is not None]))
    cap=pieces[0]['capital_height']
    print('ROW',rr['row'],'cap',cap,'baseline',baseline,'words',[(p['text'],p['box'],p['capital_height'],p['baseline_metric']) for p in pieces],flush=True)
    if not target:standard.append(dict(row=rr['row'],cap=cap))
    else:
        rows.append(dict(row=rr['row'],rect=rr['rect'],box=rr['box'],baseline=baseline,cap=cap,
                         words=[{k:v for k,v in p.items() if k not in ('alpha','bg','ink')} for p in pieces]))
targetcap=float(np.median([p['cap'] for p in standard if p['cap'] is not None]))
out=dict(source=src,grid=grecs,standard=standard,target_cap_px=targetcap,rows=rows)
json.dump(out,open(fresh(root/'review'/'word-copy-plan.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,
          default=lambda x:x.item() if hasattr(x,'item') else str(x))
E.close();print('TARGET CAP',targetcap,flush=True)
