from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_trace2.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
code=code.replace('if x in COLUMN_CACHE:return COLUMN_CACHE[x]','if (x,top,bottom) in COLUMN_CACHE:return COLUMN_CACHE[(x,top,bottom)]')
code=code.replace('COLUMN_CACHE[x]=out','COLUMN_CACHE[(x,top,bottom)]=out')
code=code.replace("' LAN2.png'", "' LAN3.png'")
code=code.replace("'LAN2.png'", "'LAN3.png'")
code=code.replace('BANG QH DOC TU NGUON V3.json','BANG QH DOC TU NGUON V4.json')
code=code.replace('TRUC DA DOI CHIEU LAN2.json','TRUC DA DOI CHIEU LAN3.json')
code=code.replace('DO NET NGUON LAN2.json','DO NET NGUON LAN3.json')
code=code.replace("print('TRACE2'", "print('TRACE3'")
exec(compile(code,__file__,'exec'))
