from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib,pymupdf as fitz
P='G05/KIEM TOAN TOAN BO/'
snap=json.loads(Path(S.report(P+'TRANG THAI VA OCR.json')).read_text(encoding='utf8'))
raw=Path(snap['output']).read_bytes();assert hashlib.sha256(raw).hexdigest()==snap['output_sha256']
doc=fitz.open(stream=raw,filetype='pdf');meta=[]
for i,page in enumerate(doc):
 ims=[]
 for im in page.get_images(full=True):
  xref,_,w,h,_,_=im[:6];rects=page.get_image_rects(xref)
  ims.append(dict(xref=xref,width_px=w,height_px=h,rects=[list(v) for v in rects],ppi_xy=[(w*72/v.width,h*72/v.height) for v in rects]))
 meta.append(dict(page=i+1,images=ims))
 if i==7:
  pix=page.get_pixmap(matrix=fitz.Matrix(4,4),alpha=False)
  pix.save(fresh(S.report(P+'CHI TIET/trang 8 - kich thuoc.png')))
Path(fresh(S.report(P+'DO PHAN GIAI ANH GOC.json'))).write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
print('IMAGES',[(v['page'],[(z['width_px'],z['height_px'],z['ppi_xy']) for z in v['images']]) for v in meta],flush=True)
doc.close()
