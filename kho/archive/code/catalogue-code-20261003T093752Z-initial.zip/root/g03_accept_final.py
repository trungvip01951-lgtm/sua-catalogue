from catwork import start, fresh
S, D, N = start()
from catfix import verify, charts
from catfix.recipes import Job
from catfix.vector import Editor
from pathlib import Path
import json, hashlib, numpy as np, pikepdf
import pymupdf as fitz

root = Path(S.report('G03'))
st = json.loads((root / 'build-state.json').read_text(encoding='utf-8'))
rev = json.loads((root / 'final-revision.json').read_text(encoding='utf-8'))
prior = json.loads((root / 'acceptance.json').read_text(encoding='utf-8'))
src, dst = st['source'], st['destination']
job = Job(src, dst)
job.edits = rev['edits']
out = dict(source=src, destination=dst, job_check=job.check())
allowed = {}
for e in rev['edits']:
    r = e['rect']
    allowed.setdefault(e['page'] + 1, []).append([r[0]-1, r[1]-1, r[2]+1, r[3]+1])
out['outside_pixels_200dpi'] = verify.outside_pixels(src, dst, allowed, dpi=200)
out['nonchart_retained_from_prior_ocr_pass'] = verify.outside_pixels(
    rev['retained_before_pdf'], dst, {a['page']: [a['rect']] for a in st['axes']}, dpi=200)
out['numeric_readback'] = prior['numeric']
out['contents_readback'] = prior['contents']
out['numeric_all_ok'] = prior['numeric_all_ok'] and not out['nonchart_retained_from_prior_ocr_pass']
out['contents_all_ok'] = prior['contents_all_ok'] and not out['nonchart_retained_from_prior_ocr_pass']
out['source_sha256'] = hashlib.sha256(Path(src).read_bytes()).hexdigest()
out['source_preserved'] = out['source_sha256'] == st['source_sha256']
out['destination_sha256'] = hashlib.sha256(Path(dst).read_bytes()).hexdigest()

with pikepdf.open(src) as a, pikepdf.open(dst) as b:
    out['metadata_equal'] = {str(k):str(v) for k,v in a.docinfo.items()} == {str(k):str(v) for k,v in b.docinfo.items()}
    ma, mb = a.Root.get('/Metadata'), b.Root.get('/Metadata')
    out['metadata_stream_equal'] = (ma.read_bytes() if ma is not None else None) == (mb.read_bytes() if mb is not None else None)
    out['image_streams'] = []
    for pg, (pa, pb) in enumerate(zip(a.pages, b.pages), 1):
        xa, xb = pa.Resources.get('/XObject', {}), pb.Resources.get('/XObject', {})
        for key, obj in xa.items():
            if obj.get('/Subtype') == pikepdf.Name.Image:
                out['image_streams'].append(dict(page=pg, name=str(key), ok=key in xb and obj.read_raw_bytes()==xb[key].read_raw_bytes()))
with fitz.open(src) as a, fitz.open(dst) as b:
    out['bookmarks_equal'] = a.get_toc() == b.get_toc()
    norm = lambda link: {k:(list(v) if hasattr(v,'__len__') and not isinstance(v,(str,list,dict)) else v) for k,v in link.items() if k != 'xref'}
    out['links_equal'] = [[norm(v) for v in p.get_links()] for p in a] == [[norm(v) for v in p.get_links()] for p in b]

A, B = Editor(src), Editor(dst)
fields = ('op','fill','stroke','lw','dash','gs','fill_cs','stroke_cs','clip','textclip')
curvechecks = []
for z in st['curves']:
    pi = z['page']-1
    pa, pb = A.page(pi), B.page(pi)
    axis = next(a for a in st['axes'] if a['page'] == z['page'])
    x0,y0,x1,y1 = axis['rect']
    ch = charts.Chart.from_ticks([(0,x0),(axis['maxQ'],x1)], [(0,y0),(axis['maxH'],y1)])
    pts = ch.to_data(charts.sample_path(pb.object_pagepath(z['oi']), n=700))
    deviations = ch.compare(pts, z['table_points'], tol_rel=.02)
    for v in deviations:
        v['tolerance'] = max(1, .02*abs(v['H_table']))
        v['ok'] = v['diff'] is not None and abs(v['diff']) <= v['tolerance']
    ends = float(np.abs(np.array([pts[0],pts[-1]])-np.array([z['table_points'][0],z['table_points'][-1]])).max())
    style = {k:pa.objs[z['oi']].get(k)==pb.objs[z['oi']].get(k) for k in fields}
    style['ctm'] = bool(np.abs(pa.objs[z['oi']]['ctm']-pb.objs[z['oi']]['ctm']).max()<1e-9)
    curvechecks.append(dict(page=z['page'], model=z['model'], units=z['units'], oi=z['oi'], before=z['before'],
                            points=deviations, endpoint_max_error=ends, style_checks=style,
                            ok=all(v['ok'] for v in deviations) and ends<.001 and all(style.values())))
out['curves_saved_readback'] = curvechecks
out['curves_all_ok'] = all(z['ok'] for z in curvechecks)

def glyphs_in(E, pi, rect):
    P = E.page(pi)
    ret = []
    for oi,o in enumerate(P.objs):
        if o['op'] not in ('f','f*'): continue
        b = o['bbox']
        if b[2]<rect[0] or b[0]>rect[2] or b[3]<rect[1] or b[1]>rect[3]: continue
        for g in P.glyphs(oi):
            b = g['bbox']
            if rect[0]-.03<=b[0]<=b[2]<=rect[2]+.03 and rect[1]-.03<=b[1]<=b[3]<=rect[3]+.03:
                ret.append((oi,g))
    return sorted(ret, key=lambda v:v[1]['bbox'][0])

def path_difference(Ea, pia, ga, Eb, pib, gb, scale=1):
    oa, ag = ga; ob, bg = gb
    ap = Ea.glyph_pagepath(pia,oa,ag); bp = Eb.glyph_pagepath(pib,ob,bg)
    M = np.array([[scale,0,0],[0,scale,0],[-ag['bbox'][0]*scale,-ag['bbox'][1]*scale,1]])
    aa = Ea.transform_path(ap, Mx=M)
    bb = Eb.transform_path(bp, dx=-bg['bbox'][0], dy=-bg['bbox'][1])
    if len(aa)!=len(bb) or any(a[0]!=b[0] or len(a[1])!=len(b[1]) for a,b in zip(aa,bb)):
        return None
    ca = np.array([p for op, pts in aa for p in pts], dtype=float)
    cb = np.array([p for op, pts in bb for p in pts], dtype=float)
    return float(np.abs(ca-cb).max()) if ca.size else 0.0

special = []
for z in st['special']:
    pi, rect = z['page']-1, z['rect']
    if z['new']=='S.r.l.':
        ag = [(oi,g) for oi,g in glyphs_in(A,pi,rect) if .15<g['bbox'][2]-g['bbox'][0]<1.6 and .15<g['bbox'][3]-g['bbox'][1]<1.6]
        bg = [(oi,g) for oi,g in glyphs_in(B,pi,rect) if .15<g['bbox'][2]-g['bbox'][0]<1.6 and .15<g['bbox'][3]-g['bbox'][1]<1.6]
        err = path_difference(A,pi,ag[-1],B,pi,bg[-1]) if len(ag)==2 and len(bg)==3 else None
        ok = err is not None and err<.00002
        detail = dict(source_dot_count=len(ag),final_dot_count=len(bg),copied_dot_max_coordinate_error=err,
                       source_dots=[g['bbox'] for oi,g in ag],final_dots=[g['bbox'] for oi,g in bg])
    elif z['new']=='HP':
        sp = z['source_page']-1
        ag = glyphs_in(A,sp,z['source_bbox'])
        bg = glyphs_in(B,pi,rect)
        err = path_difference(A,sp,ag[0],B,pi,bg[-1],z['scale']) if len(ag)==1 and len(bg)==2 else None
        h_err = abs((bg[0][1]['bbox'][3]-bg[0][1]['bbox'][1])-(bg[-1][1]['bbox'][3]-bg[-1][1]['bbox'][1])) if len(bg)==2 else None
        ok = err is not None and err<.00002 and h_err<.02
        detail = dict(source_uppercase_P_count=len(ag),final_letter_count=len(bg),copied_P_max_coordinate_error=err,
                       cap_height_error=h_err,final_glyphs=[g['bbox'] for oi,g in bg])
    else:
        ok = not out['nonchart_retained_from_prior_ocr_pass']
        detail = dict(method='Đọc và soi ảnh trước/sau; nét ký hiệu giữ nguyên, hai khoảng trắng 2.5 pt; vùng giữ nguyên từ lần đọc lại trước')
    special.append(dict(**z,geometry_ok=ok,detail=detail))
    print('Xác minh hình ký tự',z['page'],z['new'],ok,flush=True)
out['special'] = special
out['special_all_done_parts_ok'] = all(z['geometry_ok'] for z in special)
A.close(); B.close(); job.close()
out['visual_review'] = dict(numeric=True,contents=True,common_labels=True,all_pages=True,final_label_charts=True,
    note='Đã xem ảnh trước/sau đầy đủ. OCR dấu chấm trang 5 và 9 không đọc rõ; kiểm nét chấm độc lập. Nhãn 4SA8/8 được giãn 45 pt khỏi 4SA8/6.')
items = [(z['page']-1,z['rect'],f"#{z['id']}: {z['old']} -> {z['new']}") for z in st['checks']]
items += [(1,[min(z['old'][0],z['new'][0]),min(z['old'][1],z['new'][1]),max(z['old'][2],z['new'][2]),max(z['old'][3],z['new'][3])], '#33: '+z['name']) for z in st['contents']]
items += [(z['page']-1,z['rect'],f"#34: {z['old']} -> {z['new']}") for z in st['special']]
items += [(a['page']-1,a['rect'],'Biểu đồ và nhãn trang '+str(a['page'])) for a in st['axes']]
verify.compare_sheet(src,dst,items,S.report('So sanh G03.png'),dpi=220)
for pi in range(2,10):
    verify.page_overview(src,dst,pi,fresh(root/f'so-sanh-cuoi-p{pi+1}.png'),dpi=140)
json.dump(out,open(fresh(root/'acceptance-final.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
print('Nghiệm thu cuối', {k:out[k] for k in ('source_preserved','numeric_all_ok','contents_all_ok','curves_all_ok','special_all_done_parts_ok')}, flush=True)
print('Ngoài vùng',out['outside_pixels_200dpi'], flush=True)
