"""Independent Redpump 4SL16/25 source/canonical observed-ink read, no PDF write."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.charts import Chart
from catfix import verify
from graph_image_math import color_runs,follow_observed_ink
from PIL import Image,ImageDraw
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'));proof=json.loads(Path(S.report('G04/REDPUMP DOC NGUON RIENG/BANG VA HAI DUONG NGUON.json')).read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);base=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(base);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);mask=(a[:,:,1]-a[:,:,0]>6)&(a[:,:,2]-a[:,:,0]>8)&(g<230);weights=255-g;cache={}
def col(u):
 key=(u,185,566)
 if key not in cache:cache[key]=color_runs(mask,weights,u,185,566,max_width=12)
 return cache[key]
seeds=[z for z in col(350) if 233<z['v']<251];assert len(seeds)==1
seed=dict(u=350,**seeds[0]);right,issues_r=follow_observed_ink(col,seed,715,1,radius=4,max_gap=3,history=11);left,issues_l=follow_observed_ink(col,seed,125,-1,radius=4,max_gap=24,history=11)
points=sorted([*left[1:],*right],key=lambda z:z['u']);C=Chart(*proof['axis']);array=np.array([[p['u'],p['v']] for p in points]);xy=np.array([cv.to_page(u,v) for u,v in array]);q=(xy[:,0]-C.bx)/C.ax;h=(xy[:,1]-C.by)/C.ay
assert len(points)>400 and q.max()>21
table=next(r for r in d['rows'] if r['model']=='4SL16/25');read=[]
for Q,H in zip(table['Q'],table['H']):
 if Q<q.min() or Q>q.max():
  read.append(dict(model=table['model'],Q=Q,H_table=H,H_curve=None,result='CHƯA THỂ',reason='Không có mực bao hai phía tại Q, không ngoại suy'));continue
 i=np.searchsorted(q,Q);lo=max(0,i-1);hi=min(len(q)-1,i);gap=q[hi]-q[lo];got=float(np.interp(Q,q,h));error=got-H;limit=max(1,H*.02);native_H_resolution=150/(567-179.5);axis_residual_m=proof['axis_residual_pt']/abs(C.ax)*abs((h[hi]-h[lo])/(q[hi]-q[lo])) if hi!=lo and q[hi]!=q[lo] else 0
 uncertainty=native_H_resolution+axis_residual_m+abs(h[hi]-h[lo])*.5 if gap>.12 else native_H_resolution+axis_residual_m
 result='CHƯA ĐẠT' if abs(error)-uncertainty>limit else 'ĐẠT' if abs(error)+uncertainty<=limit else 'CHƯA THỂ'
 read.append(dict(model=table['model'],Q=Q,H_table=H,H_curve=got,error=error,limit=limit,uncertainty_m=uncertainty,bracket_Q=[q[lo],q[hi]],bracket_native=array[[lo,hi]].tolist(),result=result))
# The traced source path is marked only in a report image, never the PDF.
im=Image.fromarray(cv.orig);draw=ImageDraw.Draw(im)
for u,v in array[::4]:draw.ellipse((u-1.5,v-1.5,u+1.5,v+1.5),fill=(255,0,0))
im.crop((110,185,705,455)).resize((1785,810),Image.Resampling.NEAREST).save(fresh(root/'4SL16_25 TRUY NET QUAN SAT TRUOC.png'))
q21=np.searchsorted(q,21);u21,v21=array[q21];detail=Image.fromarray(cv.orig).crop((int(u21)-25,int(v21)-20,int(u21)+33,int(v21)+28));detail.resize((detail.width*12,detail.height*12),Image.Resampling.NEAREST).save(fresh(root/'4SL16_25 MUC Q21 NGUON.png'))
# Read the same source trace coordinates on actual current appearance at300dpi.
currentcv=R.render_canvas(7,(164,340,339,489),dpi=300);sourcecv=R.render_canvas(7,(164,340,339,489),dpi=300)
# Direct source/current crop proves this untouched top trace strip pixels at Q18..21.
source_strip=np.asarray(verify.crop(d['source'],7,(281,387,331,427),450));current_strip=np.asarray(verify.crop(d['current'],7,(281,387,331,427),450));strip_exact=bool(np.array_equal(source_strip,current_strip))
# Strip spans several lower traces; approved /23 and /18 changed there. Do not
# use whole-strip equality as proof of top trace. Test a tube around top25 only.
tube_records=[];changed=0;tested=0
source_full=np.asarray(verify.crop(d['source'],7,(270,379,334,441),450));current_full=np.asarray(verify.crop(d['current'],7,(270,379,334,441),450));scale=450/72
for Q in np.arange(18,21.51,.08):
 if Q>q.max():break
 vv=float(np.interp(Q,q,array[:,1]));uu=float(np.interp(Q,q,array[:,0]));x,y=cv.to_page(uu,vv);xx=int(round((x-270)*scale));yy=int(round((441-y)*scale))
 if not (4<=xx<source_full.shape[1]-4 and 4<=yy<source_full.shape[0]-4):continue
 A=source_full[yy-3:yy+4,xx-3:xx+4];B=current_full[yy-3:yy+4,xx-3:xx+4];changed+=int(np.any(A!=B,axis=2).sum());tested+=49
 tube_records.append(dict(Q=float(Q),page_point=[x,y],changed_pixels=int(np.any(A!=B,axis=2).sum())))
E.close();assert changed==0,(changed,tested)
out=dict(model=table['model'],page=8,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],source_label_photo=str(root/'4SL16_25 NHAN VA NET NGUON RIENG.png'),current_label_photo=str(root/'DUONG VA NHAN HIEN HANH V2/TRANG 08 4SL16.png'),axis=proof['axis'],axis_evidence=str(S.report('G04/REDPUMP DOC NGUON RIENG/BANG VA HAI DUONG NGUON.json')),seed=seed,seed_basis='Chọn riêng nét thực ngay dưới nhãn4SL16/25 trong nguồn; seedu350/v233..251 chỉ1run. Không dùng H bảng để chọn nhánh hoặc fit trục.',raw_observed_trace=points,source_curve_native_endpoint=[array[-1,0],array[-1,1]],source_curve_observed_Q_interval=[float(q.min()),float(q.max())],source_curve_observed_H_endpoint=float(h[-1]),ambiguous_branches=issues_r+issues_l,table=table,read_points=read,current_top25_tube_exact_to_source=True,current_top25_pixels_tested=tested,current_top25_pixels_changed=changed,current_tube_records=tube_records,source_other_curves_strip_exact=strip_exact,catalogue_written=False,status='Lượt đo nguồn riêng và kiểm mực current; cần ROOT đối chiếu nhãn/trace/đầu cuối trước chốt.',limitation='Pixel native~0.3871m theo H; tâm và x-grid nguồn có sai số, ghi riêng. Q0 có thể chưa bao hai phía thì UNKNOWN. Đường /23,/18 đã chốt không đo lại.')
Path(fresh(root/'4SL16_25 SO DO NGUON VA BAN GIAO.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');assert before==[sha(d['source']),sha(d['current'])]
print('4SL16/25',[(p['Q'],p.get('H_curve'),p['result']) for p in read],'observed Q range',out['source_curve_observed_Q_interval'],'source/current top tube pixels',tested,'changed',changed,'branch issues',len(out['ambiguous_branches']),flush=True)
