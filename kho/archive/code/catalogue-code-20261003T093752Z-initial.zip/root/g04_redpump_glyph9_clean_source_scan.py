"""Look for clean genuine label glyphs in the same Redpump source only; no PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cases=[(3,'3SL4 label source',[129,320,166,509]),(6,'4SL8 label source',[555,320,590,509]),(7,'4SL10 label source',[129,320,168,509]),(7,'4SL12 label source',[555,320,593,509])];records=[]
pic=Image.new('RGB',(1400,1750),'white');dr=ImageDraw.Draw(pic)
for i,(page,name,rect) in enumerate(cases):
 cv=R.render_canvas(page-1,rect,dpi=600);a=Image.fromarray(cv.orig);pic.paste(a,(i*345,65));dr.text((i*345+5,5),name,fill='blue')
 for v in range(0,a.height,100):dr.text((i*345+5,65+v),str(v),fill=(180,0,180))
 records.append(dict(source_page=page,description=name,rect=list(cv.rect0),dpi=600,width=a.width,height=a.height))
photo=fresh(root/'TIM CHU9 SACH TRONG NHAN CUNG FILE.png');pic.save(photo)
Path(fresh(root/'TIM CHU9 SACH TRONG NHAN CUNG FILE.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=records,photo=photo,PDF_written=False,font_source_only=True),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('4 source label strips recorded; no PDF',flush=True)
