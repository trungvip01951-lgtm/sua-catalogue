"""Source small glyph contours cleaned within native uncertainty for RAM only."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.raster import cv2
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'CHU NHO PHUC HOI BIEN CHO RAM'
data=json.loads((base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json').read_text(encoding='utf8'));by={r['key']:r for r in data['candidates']}
geom=json.loads((base/'NET THANG DAU GACH CHEO VA SO4 TU NGUON/NET THANG TU NGUON GACH CHEO VA SO4 CHUA NGHIEM THU.json').read_text(encoding='utf8'));gp={r['character']:r for r in geom['candidates']}
keys={'A':'A_4SA16-25','S':'S_4SA16-25','/':'SLASH25','0':'0_4SA16-20','1':'1_4SA16-25','2':'2_4SA16-25','3':'3_4SA8-37','4':'4_4SA16-25','5':'5_4SA16-25','6':'6_4SA16-25','8':'8_4SA8-37_PREFIX','9':'9_4SA16-9'}
zoom=64;out=[];tiles=[]
for ch,key in keys.items():
    rec=by[key];al=np.array(rec['alpha']);h,w=al.shape;raw=Image.open(base/'DO BIEN GIU LUONG MUC NGUON'/(key+' NGUON150dpi.png'))
    if ch in '/4':
        polys=gp[ch]['source_straight_polygon_geometry_local_native']
        if ch=='/':
            xmin,ymin,xmax,ymax=gp[ch]['measured_source_contour_box'];stroke=1.0
            polys=[[(xmax-stroke,ymin),(xmax,ymin),(xmin+stroke,ymax),(xmin,ymax)]]
        mm=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);draw=ImageDraw.Draw(mm)
        for p in polys:draw.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p],fill=255)
        mask=np.array(mm)>0
    else:
        up=cv2.resize(np.pad(al,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);mask=up>=rec['iso_mass_match_threshold']
    contours,hier=cv2.findContours(mask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);paths=[]
    for i,c in enumerate(contours):
        old=c[:,0,:].astype(np.float32);simp=cv2.approxPolyDP(c,.10*zoom,True)[:,0,:]
        xy=(simp.astype(float)+.5)/zoom-1
        paths.append(dict(local_native_xy=xy.tolist(),parent=int(hier[0,i,3]),old_vertex_count=len(old),clean_vertex_count=len(xy),
                          signed_area_native_px=float(cv2.contourArea(simp.reshape(-1,1,2))/zoom**2)*(1 if hier[0,i,3]<0 else -1)))
    area=sum(r['signed_area_native_px'] for r in paths);oldarea=float(mask.sum()/zoom**2);allxy=np.array([xy for p in paths for xy in p['local_native_xy']]);bb=[float(allxy[:,0].min()),float(allxy[:,1].min()),float(allxy[:,0].max()),float(allxy[:,1].max())]
    origbb=rec['source_iso_native_bbox'];step=rec['source_native_px_step_pt'];wdelta=((bb[2]-bb[0])/(origbb[2]-origbb[0])-1)*100;hdelta=((bb[3]-bb[1])/(origbb[3]-origbb[1])-1)*100;delta=(area/rec['alpha_integral_native_px']-1)*100
    item=dict(character=ch,source_key=key,source_page=rec['source_page'],source_image=rec['source_image'],source_native_box=rec['source_native_box'],source_raw_pixel_sha256=rec['raw_pixel_sha256'],
       source_alpha=rec['alpha'],source_alpha_area_native_px=rec['alpha_integral_native_px'],source_components=rec['components'],source_holes=rec['holes'],
       cleaned_contour_paths=paths,contour_outer_components=sum(p['parent']<0 for p in paths),contour_holes=sum(p['parent']>=0 for p in paths),
       native_advance=float(w),native_crop_baseline=9.,source_iso_bbox=origbb,clean_bbox_native=bb,clean_area_native_px=area,
       source_area_delta_percent=delta,clean_mass_iso_mask_area=oldarea,clean_vs_preclean_mask_area_delta_percent=(area/oldarea-1)*100,
       clean_bbox_WH_delta_percent=[wdelta,hdelta],native_outline_simplification_epsilon=.10,
       straight_source_reconstruction_used=ch in '/4',slash_stroke_native_1px_within_source_edge_uncertainty=ch=='/',
       original_font_name_not_claimed=True,source_only_small_caption_glyph_not_header_or_table=True,
       root_or_graphic_acceptance_pending=True,new_font_program_or_PDF_written=False)
    out.append(item)
    vimg=Image.new('RGB',((w+2)*zoom,(h+2)*zoom),'white');dr=ImageDraw.Draw(vimg)
    for p in paths:dr.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else (255,255,255))
    tile=Image.new('RGB',(700,300),'white');tile.paste(raw.resize((w*24,h*24),Image.Resampling.NEAREST),(10,20));tile.paste(vimg.resize(((w+2)*24,(h+2)*24),Image.Resampling.LANCZOS),(360,0));tile.save(fresh(root/(ch.replace('/','SLASH')+' NGUON VA BIEN NHO RAM.png')));tiles.append(tile)
    print(ch,'CC/H',item['contour_outer_components'],item['contour_holes'],'AREA%',delta,'WH%',item['clean_bbox_WH_delta_percent'],flush=True)
font={r['character']:r for r in out};suffix=[4,5,6,8,9,11,12,14,16,18,20,23,25];words=[];sheet=Image.new('RGB',(1750,13*200),'white');dr=ImageDraw.Draw(sheet)
for i,n in enumerate(suffix):
    literal='4SA16/'+str(n);x=15.;y=i*200+140.;scale=14.;lefts=[]
    for ch in literal:
        ff=font[ch];lefts.append([ch,x])
        for p in ff['cleaned_contour_paths']:dr.polygon([(x+xx*scale,y+(yy-9)*scale) for xx,yy in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
        x+=ff['native_advance']*scale
    words.append(dict(literal=literal,native_total_advance=(x-15)/scale,source_glyph_keys=[font[ch]['source_key'] for ch in literal],source_advance_preserved=True))
sheet.save(fresh(root/'13 TEN MODEL CHU NHO PHUC HOI BIEN RAM.png'));atlas=Image.new('RGB',(2100,1200),'white')
for i,t in enumerate(tiles):atlas.paste(t,((i%3)*700,(i//3)*300))
atlas.save(fresh(root/'12 KY TU NHO NGUON VA BIEN RAM DE ROOT KIEM.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==data['source_sha256'] and sha(S.result(name))==data['current_sha256']
Path(fresh(root/'12 KY TU NHO VA13 TEN RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_Perotac_small_caption_only=True,
    table_font_A_S_heavier_rejected=True,source_font_program_or_name_not_available=True,glyphs=out,words=words,
    source_area_advance_bbox_and_topology_recorded=True,source_native_edge_uncertainty_px=.5,actual_PDF_glyph_readback_not_run=True,
    root_or_graphic_style_acceptance_pending=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
