"""Freeze exact readback counts in a new report, leaving all earlier files intact."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 DU LIEU HINH HOC'))
ip=O/'g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(ip)=='8fabfa4986246865c6e0931cb4e63881326e58358aa099bfcb6ffb47a108c4fa'
d=json.loads(ip.read_text(encoding='utf8'))
q=json.loads((O/'g01_DOC LAI TEP V5 DA LUU - TAP CON LIEN TUC VA 12 KHE.json').read_text(encoding='utf8'))
e=d['additional_water_and_metal_witnesses'];w=[a for a in e if a['kind']=='added_exclude_water'];metal=[a for a in e if a['kind']=='added_keep_metal'];new=[a for a in w if a['winding_V4B']!=0 and a['winding_V5']==0];before=[a for a in w if a['winding_V4B']==0 and a['winding_V5']==0]
assert len(new)+len(before)==len(w) and all(a['winding_V4B']!=0 and a['winding_V5']!=0 for a in metal)
ct={'geometry_sha256':sha(ip),'additional_checks_total':len(e),'water_check_total':len(w),'water_newly_excluded':len(new),'water_already_excluded_in_V4B':len(before),'water_already_excluded_detail':before,'metal_kept_checks':len(metal),'all_additional_passed':all(a['result']=='ĐẠT' for a in e),'actual_continuous_line_subintervals_read':sum(y['actual_new_line_subintervals_read'] for x in q['groups'] for y in x['boundary_continuous_subset_checks']),'hole_boundaries_exactly_unchanged':len(q['hole_interior_probes']),'original_witnesses':len(d['original27_witnesses_read_again']),'whole_excluded_rectangles':len(d['excluded_regions5']),'note':f'Số đếm chốt lấy trực tiếp từ JSON: {len(w)} mốc nước gồm {len(new)} mới loại + {len(before)} đã ngoài V4B; {len(metal)} mốc kim loại giữ; tổng {len(e)}. Tin nhắn trước nhập tay nhầm 24/31 và 21/3, dùng phiếu này. Không thay dữ liệu hình học hoặc SHA, không sửa/xóa báo cáo trước.'}
op=Path(fresh(O/'g01_SO DEM CHINH THUC V5 LAY TU TUNG TOA DO.json'));op.write_text(json.dumps(ct,ensure_ascii=False,indent=2),encoding='utf8')
old=(O/'g01_BAO CAO 8 COT VA BAN GIAO V5.md').read_text(encoding='utf8')
old=old.replace('# Dữ liệu đường cắt nguồn V5 — chờ soi ảnh ghép trong bộ nhớ','# Bản báo cáo V5 chốt số đếm sau đọc lại — chờ soi trong bộ nhớ')
old=old.replace(f'{len(w)} mốc mực nước bị bỏ;',f'{len(w)} mốc kiểm ngoài mực nước gồm {len(new)} mốc mới bị bỏ và {len(before)} mốc đã ngoài V4B;')
old+='\n\nPhiếu này chốt lại cách đếm mực để thay diễn giải trong báo cáo trước; dữ liệu và mã kiểm V5 giữ nguyên. Đọc lại '+str(ct['actual_continuous_line_subintervals_read'])+' tiểu đoạn đường đã lưu: không có đoạn nào ra ngoài miền cắt cũ. '+str(ct['hole_boundaries_exactly_unchanged'])+' vòng lỗ giữ đúng từng tọa độ; không suy thành số lỗ cơ khí.\n'
rp=Path(fresh(O/'g01_BAO CAO CHINH THUC V5 8 COT - SO DEM TU TUNG TOA DO.md'));rp.write_text(old,encoding='utf8')
for p,h in q['all_source_guards_unchanged'].items():assert sha(p)==h
print('COUNT',json.dumps(ct,ensure_ascii=False),flush=True)
print('REPORT',rp,'SHA',sha(rp),flush=True)
