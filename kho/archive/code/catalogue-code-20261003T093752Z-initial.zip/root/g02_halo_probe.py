from catwork import start,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.otext import OutlineText
from pathlib import Path
import pickle
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';E=Editor(S.result(NAME));T=OutlineText(E)
T.__dict__.update(pickle.loads(Path(S.report('G02/nhan-dung-cho-ve.pkl')).read_bytes()));T.E=E
for p,ois in [(27,range(278,296))]:
    P=E.page(p)
    for oi in ois:
        o=P.objs[oi]
        print(p+1,oi,'op',o['op'],'fill',o['fill'],'stroke',o['stroke'],'lw',o['lw'],'bbox',o['bbox'],'glyphs',[(g['bbox'],g['subs']) for g in P.merged_glyphs(oi)],flush=True)
    g=next(g for g in T.page_glyphs(p) if g.oi==290)
    print('TWINS',T.twins_of(p,[g]),flush=True)
E.close()
