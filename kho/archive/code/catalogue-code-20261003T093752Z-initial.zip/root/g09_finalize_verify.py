from catwork import start,fresh
from pathlib import Path
import json,hashlib,datetime,concurrent.futures,re,numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.recipes import Job
from catfix import verify
from catfix.ocr import image_words
from PIL import Image
import pymupdf as fitz
data=json.loads(Path(S.report('G09/NGUON.json')).read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
allchecks=[];reads=[];figs=[]
for fi,d in enumerate(data):
    sample=S.report(f'G09/MAU LAN2/{d["name"]}')
    result=json.loads(Path(S.report(f'G09/MAU LAN2/KIEM TRA {d["short"]}.json')).read_text(encoding='utf-8'))
    assert result['check']['ok'] and sha(sample)==result['sha256'] and sha(d['src'])==d['sha256']
    dst=S.dst(d['name'])
    saved=Path(S.report(f'G09/DIEM LUU {d["short"]}.json'))
    xmp_saved=Path(S.report(f'G09/DIEM LUU {d["short"]} GIU XMP.json'))
    if xmp_saved.exists():saved=xmp_saved
    if Path(dst).exists():
        expected=json.loads(saved.read_text(encoding='utf-8'))['sha256'] if saved.exists() else ('836509fc58ddedc8b662b46efe3a99c72196fe7275622f61cff02d5118d3c0ed' if fi==0 else None)
        assert expected and sha(dst)==expected,'Tệp đích có trước hoặc đã đổi; không ghi đè'
    else:
        E=Editor(sample);E.save(fresh(dst));E.close()
    if not saved.exists():saved.write_text(json.dumps(dict(dst=dst,sha256=sha(dst),sample=sample,sample_sha256=sha(sample)),ensure_ascii=False,indent=2),encoding='utf-8')
    dst=S.dst(d['name']);j=Job(d['src'],dst,log_path=S.report(f'G09/{d["short"]}.log.json'))
    for rec in result['details']:
        j._add(rec['page']-1,rec['rect'],f'#{rec["task"]} {rec["old"]} → {rec["new"]}','outline')
        if 'new_rect' in rec:j._add(rec['page']-1,rec['new_rect'],'#76 thêm 11','outline+leader')
    ck=j.check();assert ck['ok'],ck
    allowed={}
    for e in j.edits:
        r=e['rect'];allowed.setdefault(e['page']+1,[]).append((r[0]-1.5,r[1]-1.5,r[2]+1.5,r[3]+1.5))
    outside=verify.outside_pixels(d['src'],dst,allowed,dpi=150,thr=12,min_size=1)
    assert not outside,outside
    assert not verify.outside_pixels(sample,dst,{},dpi=150,thr=0,min_size=1)
    A=Editor(d['src']);B=Editor(dst);RA=Raster(A);RB=Raster(B);ims=[]
    for pi in range(A.doc.n_pages):
        outims=RB.images(pi);hashes=[hashlib.sha256(B.doc.stream_raw(im.ref)).hexdigest() for im in outims]
        for im in RA.images(pi):
            h=hashlib.sha256(A.doc.stream_raw(im.ref)).hexdigest();assert h in hashes
            mate=[z for z,hh in zip(outims,hashes) if hh==h and np.allclose(z.page_bbox,im.page_bbox,atol=1e-8)];assert mate
            for key in ['SMask','Mask']:
                mask=im.d.get(key);m2=mate[0].d.get(key)
                if isinstance(mask,tuple):assert A.doc.stream_raw(mask)==B.doc.stream_raw(m2)
            ims.append(dict(page=pi+1,width=im.W,height=im.H,sha256=h,raw_same=True,placement_same=True))
    # #144: toàn bộ trang 6 và các nội dung lớp chữ đều giữ nguyên.
    assert A.doc.page_content(5)==B.doc.page_content(5)
    A.close();B.close()
    fA=fitz.open(d['src']);fB=fitz.open(dst)
    assert fA.metadata==fB.metadata and fA.get_xml_metadata()==fB.get_xml_metadata() and fA.get_toc()==fB.get_toc()
    links=lambda doc:[[dict((k,str(v)) for k,v in z.items() if k!='xref') for z in p.get_links()] for p in doc]
    assert links(fA)==links(fB);fA.close();fB.close()
    header=[]
    for pi in range(7):
        r=(0,747,595.28,842.27)
        a=np.asarray(verify.crop(d['src'],pi,r,180));b=np.asarray(verify.crop(dst,pi,r,180));assert np.array_equal(a,b),(fi,pi,'header')
        header.append(dict(page=pi+1,unchanged=True,sha256=hashlib.sha256(a.tobytes()).hexdigest()))
    allchecks.append(dict(file=d['name'],source=d['src'],destination=dst,source_sha256=sha(d['src']),destination_sha256=sha(dst),structure=ck['structure'],outside=outside,sample_pixels_same=True,images=ims,metadata_same=True,xml_metadata_same=True,bookmarks_same=True,links_same=True,headers_unchanged=header,page6_stream_same=True,edits=j.edits))
    specs=[(71,0,(309.8,197.3,389,207.1),'Civel engineering','Civil engineering'),(71,0,(239.8,602.7,274.1,611.2),'build-in','built-in'),(72,4,(432,698,504,711),'high preasure.','high pressure.'),(73,2,(337.4,114.0,355.1,121.7),'1.60','1.50'),(73,3,(323,117.2,340.6,125),'1.60','1.50'),(74,3,(323,225.7,340.8,233.3),'0.60','0.50'),(75,6,(120.8,604,131.8,610.2),'SH637','637'),(76,1,(211.8,661.5,221,668.2),'03',''),(76,1,(87.4,593.3,95.5,600.7),'','11')]
    if fi==1:
        rr=specs[6][2];specs[6]=(75,6,(rr[0]+1.19064,rr[1]-2.1024,rr[2]+1.19064,rr[3]-2.1024),'SH637','637')
    for index,(task,pi,r,old,want) in enumerate(specs):
        label=f'#{task} {old} → {want or "xóa số 03"}'
        path=fresh(S.report(f'G09/DOC LAI/{d["short"]}-{index+1}.png'))
        verify.compare_sheet(d['src'],dst,[(pi,r,label)],path,dpi=450,pad=(1,1))
        figs.append((path,d['short'],task))
        a=np.asarray(verify.crop(dst,pi,r,600))
        g=(a.astype(np.float32)@np.array([.299,.587,.114])).clip(0,255).astype(np.uint8)
        texts=[]
        if not want:
            ok=bool(np.min(a)>=254)
            texts=['vùng số 03 đã trắng hoàn toàn'] if ok else ['vùng còn điểm ảnh']
        else:
            config='-c tessedit_char_whitelist=0123456789.' if want.replace('.','').isdigit() else ''
            for psm in [7,8,13]:
                words=image_words(Image.fromarray(g),psm=psm,config=config)
                texts.append(' '.join(w['text'] for w in words))
                if re.sub(r'\s+','',texts[-1])==re.sub(r'\s+','',want):break
            ok=any(re.sub(r'\s+','',t)==re.sub(r'\s+','',want) for t in texts)
        reads.append(dict(file=d['name'],task=task,page=pi+1,rect=r,old=old,new=want,reads=texts,automatic_exact=ok,evidence=path,visual='CHỜ SOI ẢNH'))
        print('READ',d['short'],task,pi+1,want,texts,ok,flush=True)
    j.close()
out=dict(time=datetime.datetime.now().astimezone().isoformat(),checks=allchecks,reads=reads,figs=figs,automatic_exact=sum(r['automatic_exact'] for r in reads),count=len(reads))
Path(fresh(S.report('G09/NGHIEM THU DOC LAP.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print('DOC LAI',out['automatic_exact'],'/',out['count'],flush=True)
