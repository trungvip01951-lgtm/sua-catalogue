"""Finalize only ROOT-approved Redpump sample2; guarded own-session archive."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import sys,json,hashlib,datetime,numpy as np
import pymupdf as fitz
from catfix.vector import Editor
from catfix import verify,charts
assert '--root-da-chot' in sys.argv,'Chỉ chạy sau ROOT chốt mẫu2.'
root=Path(S.report('G04'));m=root/'REDPUMP MAU NET PDF2';build=json.loads((m/'TAO VA KIEM MAU.json').read_text(encoding='utf8'));read=json.loads((m/'DOC LAI ACTUAL PDF.json').read_text(encoding='utf8'));independent=json.loads((m/'NGHIEM THU DOC LAP ROOT.json').read_text(encoding='utf8'));old=json.loads((root/'REDPUMP DOC NGUON RIENG/BANG VA HAI DUONG NGUON.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();name=old['name'];source=Path(S.src(name)).resolve();prev=Path(S.result(name)).resolve();trial=Path(build['trial']).resolve()
assert sha(source)==build['source_sha']==independent['source_sha'] and sha(prev)==build['current_sha']==read['current_sha']==independent['current_sha'] and sha(trial)==build['trial_sha']==read['trial_sha']==independent['trial_sha']
assert read['point_count']==16==independent['point_count'] and all(z['result']=='ĐẠT' for z in read['points']) and read['outside']=={} and independent['outside']=={} and all(read['metadata'].values())
assert all(z['changed_pixels']==0 for z in read['font_foreground']) and max(z['error_pt'] for z in read['endpoints'])<1e-4
outroot=Path(S.out_dir).resolve();arc=Path(S.report('G04/REDPUMP PHIEN TRUOC NET PDF/'+build['current_sha']+'/'+name)).resolve()
assert prev.is_relative_to(outroot) and arc.is_relative_to(outroot) and prev!=source and not arc.exists() and trial.is_relative_to(outroot)
arc.parent.mkdir(parents=True,exist_ok=True);prev.rename(arc)
E=Editor(str(trial),backend='fitz');E.save(fresh(prev));E.close()
assert sha(source)==build['source_sha'] and sha(arc)==build['current_sha']
structure=verify.structure_check(str(trial),str(prev));assert structure['ok']
exact=verify.outside_pixels(str(trial),str(prev),{},dpi=200,thr=0,min_size=0,pad=0);assert not exact
outside=verify.outside_pixels(str(arc),str(prev),{8:[build['allowed_plot']]},dpi=200,thr=0,min_size=0,pad=.4);assert not outside
with fitz.open(trial) as a,fitz.open(prev) as b:
 assert a.metadata==b.metadata and a.get_xml_metadata()==b.get_xml_metadata() and a.get_toc()==b.get_toc()
 assert [tuple(p.rect) for p in a]==[tuple(p.rect) for p in b]
 for p,q in zip(a,b):
  assert p.read_contents()==q.read_contents()
  assert [{k:str(v) for k,v in z.items() if k!='xref'} for z in p.get_links()]==[{k:str(v) for k,v in z.items() if k!='xref'} for z in q.get_links()]
E=Editor(str(prev),backend='fitz');P=E.page(7);ax,bx,ay,by=build['axis'];actual=[]
for r in build['records']:
 want=np.array(r['RGB'])/255;parts=[]
 for oi,o in enumerate(P.objs):
  col=P.color_of(oi,'stroke')
  if o['op']=='S' and col is not None and max(abs(np.array(col)-want))<1e-7:
   assert abs(o['lw']-r['width_pt'])<1e-8;parts.append(charts.sample_path(P.object_pagepath(oi),n=400))
 assert len(parts)==len(r['native_dash_Q_intervals']);a=np.vstack(parts);a=a[np.argsort(a[:,0])];qq=(a[:,0]-bx)/ax;hh=(a[:,1]-by)/ay
 assert abs(qq.min())<1e-4 and abs(qq.max()-21)<1e-4
 for q,h in zip(r['Q'],r['H']):
  got=float(np.interp(q,qq,hh));error=got-h;limit=max(1,h*.02);assert abs(error)<=limit;actual.append(dict(model=r['model'],Q=q,H_table=h,H_final=got,error=error,limit=limit,result='ĐẠT'))
E.close();verify.compare_sheet(str(arc),str(prev),[(7,build['allowed_plot'],'Redpump hai đường bản giao')],fresh(root/'REDPUMP BAN CUOI TRUOC SAU.png'),dpi=450,pad=(.2,.2))
receipt=dict(time=datetime.datetime.now().astimezone().isoformat(),name=name,final=str(prev),final_SHA256=sha(prev),source=str(source),source_SHA256=sha(source),archive=str(arc),previous_SHA256=sha(arc),accepted_sample=str(trial),accepted_sample_SHA256=sha(trial),ROOT_message_approval='ROOT duyệt mẫu2 sau soi bảng, 16 Bézier thật, ảnh150/600, đầu-cuối/nhãn; cho phép finalize qua catfix trong tin nhắn chỉ đạo.',ROOT_evidence=str(m/'NGHIEM THU DOC LAP ROOT.json'),ROOT_style_evidence=str(m/'ROOT DO MAU VA MUC ACTUAL.json'),style_limit='Nét tương đương suy từ ảnh JPEG150dpi: nguồn600dpi .872884/.867371pt, mới .955048/.938585pt; chênh .082164/.071213pt. MuPDF/Pillow có một số điểm ảnh khác. ROOT chấp nhận hình thức, không coi đây là số bút nguyên thủy chính xác hoặc lấy một pixel làm ngưỡng ĐẠT.',final_actual_points=actual,structure=structure,pixel_exact_to_sample=exact=={},page_contents_metadata_links_exact_to_sample=True,outside_authorized_area=outside,previous_label_fonts_and_original_images_check=read,accepted=True,status='14/14 CAN_SUA và riêng4đường/32mốc hai file ĐẠT. Các đường khác G04 chưa nghiệm thu đủ; nhóm CHƯA XONG.')
Path(fresh(root/'REDPUMP NGHIEM THU BAN CUOI NET PDF.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# BÁO CÁO G04 – bổ sung hai đường Redpump SL','', '**14/14 việc danh sách ĐẠT. Bổ sung hai đường Redpump đạt16/16mốc; cộng hai tệp đã sửa4đường/32mốc. G04 CHƯA XONG vì còn các đường chưa đo.**','', '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |','|---|---|---|---|---|---|---|---|']
for z in old['Q21_read']:
 row=next(p for p in actual if p['model']==z['model'] and p['Q']==21)
 lines.append(f"| Phát hiện thêm, đã được anh cho phép | {name} | 8 – {z['model']} | Q21: đường{z['H_source_curve']:.4f}m, bảng{z['H_table']}m | Q21: {row['H_final']:.6f}m; đủ8mốcQ0–21 | catfix dựng nét PDF thật theo đúng bảng Redpump; giữ nét đứt, nhãn và ảnh nguồn | ĐẠT8/8mốc | G04/REDPUMP DOC NGUON RIENG/BANG VA HAI DUONG NGUON.json;REDPUMP MAU NET PDF2/DOC LAI ACTUAL PDF.json;REDPUMP NGHIEM THU BAN CUOI NET PDF.json |")
lines+=['','Tổng bổ sung lượt này:2đường, ĐẠT2, CHƯA ĐẠT0, CHƯA THỂ0 trong đúng16mốc. Kết quả chữ/số14/14 giữ theo BAO CAO G04.md. Hai đường Perotac đã chốt riêng trong BAO CAO G04 BO SUNG NET PDF.md.','',f"Đọc lại đường trong bản giao: sai H lớn nhất {max(abs(z['error']) for z in actual):.8f}m. Điểm đầu/cuối mẫu lệch dưới0,00000902điểm in so tọa độ bảng; bản cuối giữ nguyên luồng vẽ và từng điểm ảnh mẫu200điểm ảnh/inch. MiềnQ0–21m³/h đúng bảng; không kéo đường đến đầu cuối của đồ thị thay cho miền số.",'','Đã đọc nguồn Redpump riêng, không mượn bảng/trục/phông/màu Perotac. Mẫu1 không đạt khoảng nét đứt; giữ làm bằng chứng, không giao. Mẫu2 được ROOT đọc từng Bézier và soi hình thức rồi duyệt.','',receipt['style_limit'],'','Nhãn nguồn giữ0điểm đổi ở150/450/600điểm ảnh/inch. Các ảnh gốc, lớp mặt nạ và vị trí giữ nguyên; phông, siêu dữ liệu, liên kết, khổ/trang giữ. Bảng/H và10trang khác không đổi. Ngoài vùng sửa kiểm ở200điểm ảnh/inch, ngưỡng màu0/cỡ nhỏ nhất0: rỗng.','',f'Tệp giao: {prev}',f'Mã kiểm nội dung SHA-256: {sha(prev)}',f'Bản trước do phiên tạo được giữ nguyên tại: {arc}','','Phát hiện thêm: đang kiểm các bảng/đường Redpump khác; chưa chuyển việc chưa đo thành ĐẠT. Các tên sai trên nguồn trang1/7/11 đã sửa trong bản giao theo#36/#44/#45, không ghi thành lỗi còn sót. Cần anh quyết: chưa có quyết định mới.','','Giải thích: PDF là định dạng tài liệu; catfix là công cụ được giao; JPEG là dạng ảnh nén; Bézier là đoạn cong toán học trong tài liệu; điểm in là1/72inch; Q là lưu lượng, H là cột áp; SHA-256 là mã kiểm nội dung.','']
Path(fresh(S.report('BAO CAO G04 BO SUNG REDPUMP NET PDF.md'))).write_text('\n'.join(lines),encoding='utf8')
S.progress('G04','CHƯA XONG','14/14 CAN_SUA ĐẠT; hai đường Redpump4SL16/23,/18 đã lưu mẫu2 được ROOT chốt, đủ16/16mốc và chữ/ảnh/metadata/vùng ngoài đạt. Cộng hai tệp4đường/32mốc ĐẠT, chưa tính toàn bộ đường G04. Báo cáo BAO CAO G04 BO SUNG REDPUMP NET PDF.md; tiếp tục đọc riêng Redpump các đường còn lại, chưa ghi PDF.')
print('FINAL REDPUMP',str(prev),'SHA',sha(prev),'16/16 saved-path anchors PASS; overall curves incomplete',flush=True)
