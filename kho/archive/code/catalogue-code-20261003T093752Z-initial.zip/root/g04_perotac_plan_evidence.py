from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from pathlib import Path
from PIL import Image,ImageDraw
from g04_perotac_audit_data import DATA
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
src=S.src(name);dst=S.result(name)
audit=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));out=Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC'))
doc=json.loads((audit/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'))
prep=json.loads((out/'KHOI DONG VA DU LIEU 5 DIEM.json').read_text(encoding='utf8'))
E=Editor(src);R=Raster(E);receipts=[]
for rec in prep['records']:
 model=rec['model'];family=rec['family'];pi=rec['page']-1;slug=model.replace('/','-')
 cv=R.canvas(max(R.images(pi),key=lambda z:z.W*z.H));data=next(z for z in DATA if z['family']==family)
 sub=out/slug
 x0,y0,x1,y1=data['plot_native_box'];box=(x0-35,y0-55,x1+35,y1+150);rect=cv.rect(box)
 a=verify.crop(src,pi,rect,400);b=verify.crop(dst,pi,rect,400)
 pic=Image.new('RGB',(a.width+b.width,max(a.height,b.height)+26),'white');pic.paste(a,(0,26));pic.paste(b,(a.width,26));d=ImageDraw.Draw(pic);d.text((2,5),'NGUON',fill='black');d.text((a.width+2,5),'HIEN HANH',fill='black')
 pic.save(fresh(sub/'DO THI NGUON VA HIEN HANH 400.png'))
 tb=data['table_native_box'];trect=cv.rect((tb[0]-8,tb[1]-12,tb[2]+8,tb[3]+8));verify.crop(src,pi,trect,500).save(fresh(sub/'BANG SO NGUON 500.png'));verify.crop(dst,pi,trect,500).save(fresh(sub/'BANG SO HIEN HANH 500.png'))
 cb=rec['label_native_box'];caprect=cv.rect((cb[0]-25,cb[1]-14,cb[2]+20,cb[3]+22));verify.crop(src,pi,caprect,600).save(fresh(sub/'NHAN VA NET NGUON 600.png'));verify.crop(dst,pi,caprect,600).save(fresh(sub/'NHAN VA NET HIEN HANH 600.png'))
 p=rec['points'][-1];u,v=p['target_u_native'],p['v_native'];vp=rec['axis']['H_grid_calibration']['v_H0']+rec['axis']['H_grid_calibration']['v_per_m']*p['H_table_m'];near=(u-20,min(v,vp)-12,u+27,max(v,vp)+12);nrect=cv.rect(near)
 a=verify.crop(src,pi,nrect,600);b=verify.crop(dst,pi,nrect,600);pic=Image.new('RGB',(a.width+b.width,max(a.height,b.height)+26),'white');pic.paste(a,(0,26));pic.paste(b,(a.width,26));d=ImageDraw.Draw(pic);d.text((2,5),'NGUON',fill='black');d.text((a.width+2,5),'HIEN HANH',fill='black');pic.save(fresh(sub/'CUOI NET NGUON VA HIEN HANH 600.png'))
 tightrect=cv.rect((u-2,v-2,u+2,v+2));ta=np.asarray(verify.crop(src,pi,tightrect,600));tb=np.asarray(verify.crop(dst,pi,tightrect,600));diff=ta.astype(int)-tb.astype(int)
 receipts.append(dict(model=model,page=pi+1,actual_pdf_source_current_tight_difference_pixels=int(np.any(diff!=0,axis=2).sum()),actual_pdf_source_current_maxRGB=int(abs(diff).max()),point=p,native_tail_box=near,page_tail_box=nrect))
 print(model,'MUC CHINH DIFF',receipts[-1]['actual_pdf_source_current_tight_difference_pixels'],'TAIL BOX',near,'PAGE',nrect)
for fam in ['3SS3','3SS4','4SA16']:
 r=next(z for z in prep['records'] if z['family']==fam);data=next(z for z in DATA if z['family']==fam);cv=R.canvas(max(R.images(r['page']-1),key=lambda z:z.W*z.H));plot=data['plot_native_box'];bottom=r['axis']['flow_native_box'][1]
 axisbox=(plot[0]-10,plot[3]-9,plot[2]+10,bottom+48)
 raw=Image.fromarray(cv.orig[axisbox[1]:axisbox[3],axisbox[0]:axisbox[2]]);raw.resize((raw.width*5,raw.height*5),Image.Resampling.NEAREST).save(fresh(out/('VACH VA NHAN Q GOC '+fam+'.png')))
 stem=(plot[0]-15,plot[1]-7,plot[0]+15,plot[3]+8);raw=Image.fromarray(cv.orig[stem[1]:stem[3],stem[0]:stem[2]]);raw.resize((raw.width*5,raw.height*5),Image.Resampling.NEAREST).save(fresh(out/('VACH H GOC '+fam+'.png')))
Path(fresh(out/'DOC LAI 5 MUC VA 3 TRUC.json')).write_text(json.dumps(dict(read_only=True,pdf_written=False,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest(),records=receipts),ensure_ascii=False,indent=2),encoding='utf8');E.close()
