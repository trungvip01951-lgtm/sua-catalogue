"""Read CATFIX RAM source-caption islands at actual150/600; NO PDF writer."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import sys,hashlib,json,math,numpy as np
import pymupdf as fitz
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Ref
sys.path.insert(0,str(HERE))
from g04_redpump_whole_caption_island_RAM_builder import build_caption_islands_RAM

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/'13 CAPTION NGUYEN NGUON DAO RAM LAN2B'
assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json');a=J(M/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')
w=J(P/'CHU NGUON ALPHA THU DO DOC V2.json')
holes=J(M/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json');eta=J(M/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
sourceE=Editor(b['source'],backend='fitz');sourceR=Raster(sourceE);sourceim=max(sourceR.images(7),key=lambda z:z.W*z.H);sourcecv=sourceR.canvas(sourceim)
islands=[]
for z in w['records']:
    cv=sourceR.render_canvas(7,z['source_page_rect'],dpi=600)
    rgb=cv.orig.astype(float);g=rgb@np.array([.299,.587,.114])
    # Detect a WHOLE-WORD candidate box only; never edit, draw or fit a glyph.
    core=(g<100)&(rgb.max(2)-rgb.min(2)<35)
    yy,xx=np.where(core);assert len(xx)>50,z['model']
    box600=[int(xx.min()-8),int(yy.min()-8),int(xx.max()+1+8),int(yy.max()+1+8)]
    bb=[*cv.to_page(box600[0],box600[3]),*cv.to_page(box600[2],box600[1])]
    native=np.r_[sourcecv.to_px(bb[0],bb[3]),sourcecv.to_px(bb[2],bb[1])].tolist()
    islands.append(dict(model=z['model'],source_full_word_request=z['source_page_rect'],source_core100_neutral35_bbox600=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],
        source_margin600_pixels=8,source_margin_pt=.96,island_page_bbox=bb,source_native_bbox_float=native,
        whole_word_detected_box_NOT_a_glyph_mask=True,original_source_font_size_advance_position_CTM_unchanged=True,
        acceptance='CHƯA CHỐT; đọc cả hộp cùng mép và các nét cũ trong hộp.'))
E,report,content=build_caption_islands_RAM(b,a,islands,holes,eta)
R=Raster(E)
report.update(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],M1=b['sample'],M1_SHA256=guards[2],islands=islands)

def render(doc,rect,dpi,pi=7):
    pg=doc[pi];T=pg.transformation_matrix;p0=fitz.Point(rect[0],rect[1])*T;p1=fitz.Point(rect[2],rect[3])*T
    rr=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y));z=dpi/72
    px=pg.get_pixmap(matrix=fitz.Matrix(z,z),clip=rr,colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(px.samples,np.uint8).reshape(px.height,px.width,px.n)[:,:,:3].copy(),dict(pixel_origin=[px.x,px.y],page_to_device=tuple(T*fitz.Matrix(z,z)))
tiles=[];reads=[]
with fitz.open(b['source']) as source,fitz.open(b['input_current']) as current,fitz.open(b['sample']) as m1:
    for k,item in enumerate(islands):
        name=item['model'];stem=name.replace('/','_');bb=item['island_page_bbox'];record=dict(model=name,source_island_bbox=bb,full_edge_read_NO_pixels_omitted=True)
        tile=Image.new('RGB',(1750,350),'white');td=ImageDraw.Draw(tile)
        td.text((5,5),name+'  ORIGINAL SOURCE / CURRENT / RAM ISLAND (FULL edges, no trim); NO PDF2',fill='blue')
        dreads=[]
        for dpi in [150,600]:
            arrays=[render(doc,bb,dpi)[0] for doc in [source,current,E.doc.doc]]
            assert arrays[0].shape==arrays[1].shape==arrays[2].shape
            diffs=np.any(arrays[0]!=arrays[2],axis=2)
            xx,yy=np.meshgrid(np.arange(diffs.shape[1]),np.arange(diffs.shape[0]))
            # No two-pixel interior exclusion: every rendered crop pixel counts.
            read=dict(dpi=dpi,full_rendered_shape=list(arrays[0].shape),all_full_crop_pixels_checked=int(diffs.size),
                full_crop_changed_pixels_source_vs_RAM=int(diffs.sum()),maximum_RGB_difference=int(abs(arrays[0].astype(int)-arrays[2].astype(int)).max()),
                pixel_omission=0,render_maps=[render(doc,bb,dpi)[1] for doc in [source,current,E.doc.doc]],
                images=[])
            for i,(ar,kind) in enumerate(zip(arrays,['SOURCE','CURRENT','RAM'])):
                path=Path(fresh(F/(stem+f' {kind}{dpi} FULL MEP.png')));Image.fromarray(ar).save(path);read['images'].append(str(path))
                scale=3 if dpi==150 else 2;im=Image.fromarray(ar).resize((ar.shape[1]*scale,ar.shape[0]*scale),Image.Resampling.NEAREST)
                tile.paste(im,(5+i*580,45 if dpi==150 else 150))
            dreads.append(read)
        record.update(reads=dreads,source_CTM_bytes_and_complete_caption_NO_retyping=True,source_JPEG150_sharpness_limit=True,
            original_curve_inside_island_cleanliness='CHƯA CHỐT: soi các nét sát/chạm; bảo toàn không tự là hình thứcĐẠT.')
        reads.append(record);tiles.append(tile)
    atlas=Image.new('RGB',(1750,350*13),'white')
    for k,t in enumerate(tiles):atlas.paste(t,(0,k*350))
    atlas.save(fresh(F/'13 CAPTION SOURCE CURRENT RAM150600 FULL MEP KHONG CAT CHU.png'))
    full=[53,267,364,511]
    for dpi in [150,600]:
        for doc,kind in [(source,'SOURCE'),(current,'CURRENT'),(E.doc.doc,'RAM')]:
            ar,_=render(doc,full,dpi);Image.fromarray(ar).save(fresh(F/(f'TOAN QH ETA {kind}{dpi} KHONG PDF2.png')))
    ar,_=render(E.doc.doc,[0,0,834,593],150);Image.fromarray(ar).save(fresh(F/'TOAN TRANG8 RAM150 KHONG PDF2.png'))
    old,_=render(current,[0,0,834,593],200);new,_=render(E.doc.doc,[0,0,834,593],200);assert old.shape==new.shape
    changed=np.any(old!=new,axis=2);allowed=np.zeros(changed.shape,bool);maskrows=[];scale=200/72;H,W=changed.shape
    for bb in b['allowed_bboxes']:
        x0=max(0,math.floor(bb[0]*scale));x1=min(W,math.ceil(bb[2]*scale));y0=max(0,math.floor((593-bb[3])*scale));y1=min(H,math.ceil((593-bb[1])*scale))
        allowed[y0:y1,x0:x1]=True;maskrows.append(dict(PDF_rect=bb,pixel_rect=[x0,y0,x1,y1]))
    bad=changed&~allowed;by,bx=np.where(bad)
    outside=dict(dpi=200,threshold=0,pad_pt=0,changed_total=int(changed.sum()),outside_changed_pixels=int(bad.sum()),
        outside_changed_bbox=None if not len(bx) else [int(bx.min()),int(by.min()),int(bx.max()+1),int(by.max()+1)],exact_allowed_pixel_masks=maskrows)
    links=lambda doc:[[{k:str(v) for k,v in d.items() if k!='xref'} for d in pg.get_links()] for pg in doc]
    meta=dict(info=current.metadata==E.doc.doc.metadata,XMP_value=current.get_xml_metadata()==E.doc.doc.get_xml_metadata(),
        bookmarks=current.get_toc()==E.doc.doc.get_toc(),links=links(current)==links(E.doc.doc),page_count=len(current)==len(E.doc.doc),
        mediaboxes=[list(pg.mediabox) for pg in current]==[list(pg.mediabox) for pg in E.doc.doc],
        cropboxes=[list(pg.cropbox) for pg in current]==[list(pg.cropbox) for pg in E.doc.doc],rotations=[pg.rotation for pg in current]==[pg.rotation for pg in E.doc.doc],
        fonts=[pg.get_fonts(full=True) for pg in current]==[pg.get_fonts(full=True) for pg in E.doc.doc],
        other10_page_contents=all(current[i].read_contents()==E.doc.doc[i].read_contents() for i in range(11) if i!=7))
    xr0=current.xref_xml_metadata();xr1=E.doc.doc.xref_xml_metadata();meta['XMP_raw_stream']=not xr0 or current.xref_stream_raw(xr0)==E.doc.doc.xref_stream_raw(xr1)
    protected=[]
    for dpi in [150,200,600]:
        for r in holes['records']:
            bb=r['source_original_restore_bbox'];ar,_=render(current,bb,dpi);br,_=render(E.doc.doc,bb,dpi)
            protected.append(dict(name='feet'+str(r['index']),dpi=dpi,bbox=bb,changed_pixels=int(np.any(ar!=br,axis=2).sum())))
    report.update(actual_RAM13_caption_source_full_edge_reads=reads,outside200_threshold0_pad0=outside,
        metadata_links_boxes_fonts=meta,protected_original5feet_full_boxes=protected)

currentE=Editor(b['input_current'],backend='fitz');currentR=Raster(currentE);images=[]
for pi in range(11):
    targets=R.images(pi)
    for im in currentR.images(pi):
        hits=[z for z in targets if z.name==im.name and z.W==im.W and z.H==im.H and np.array_equal(z.ctm,im.ctm)]
        assert len(hits)==1
        dst=hits[0];raw=currentE.doc.stream_raw(im.ref);assert raw==E.doc.stream_raw(dst.ref)
        masks=[]
        for key in ['SMask','Mask']:
            x,y=im.d.get(key),dst.d.get(key)
            if isinstance(x,Ref):
                assert isinstance(y,Ref) and currentE.doc.stream_raw(x)==E.doc.stream_raw(y);masks.append(dict(kind=key,SHA256=hashlib.sha256(currentE.doc.stream_raw(x)).hexdigest()))
            else:assert str(x)==str(y)
        images.append(dict(page=pi+1,name=str(im.name),size=[im.W,im.H],CTM=im.ctm.tolist(),raw_SHA256=hashlib.sha256(raw).hexdigest(),masks=masks,raw_bytes_CTM_preserved=True))
report['all_current_native_images_raw_masks_CTM_preserved']=images
Path(fresh(F/'CATFIX13 CAPTION DAO NGUYEN NGUON DOC RAM FULL MEP.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
Path(fresh(F/'LENH CATFIX RAM13 CAPTION DAO KHONG PDF.txt')).write_bytes(content)
assert [sha(b[k]) for k in ['source','input_current','sample']]==guards
currentE.close();sourceE.close();E.close()
print('RAM13 FULL',[(z['model'],[(r['dpi'],r['full_crop_changed_pixels_source_vs_RAM']) for r in z['reads']]) for z in reads],flush=True)
print('OUTSIDE',outside,'META',meta,'FEET',[(z['name'],z['dpi'],z['changed_pixels']) for z in protected],flush=True)
print('NO PDF2',F,flush=True)
