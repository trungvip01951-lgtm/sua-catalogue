from catwork import start
S,D,N=start()
from pathlib import Path
import json,numpy as np
d=json.loads(Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8/GLYPH THAT DAY DU CUNG BO NGUON V3.json')).read_text(encoding='utf8'))
for z in d['records']:
 a=np.array(z['source_alpha']);out=[]
 for t in [.085,.15,.2,.25,.3,.4]:
  y,x=np.nonzero(a>=t);out.append([t,[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)]])
 print(z['character'],out,flush=True)
