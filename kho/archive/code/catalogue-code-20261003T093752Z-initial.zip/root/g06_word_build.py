from catwork import start, fresh
S,D,N=start()
from catfix.raster import Raster
from catfix.vector import Editor
from catfix.recipes import Job
from catfix import verify,ocr
from catfix.cs import Name,Num,Instr
from g06_word_tools import grid_mask,word_piece,scaled_piece,LABELS
from g15_masked_patch import commit_masked
from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,cv2,hashlib,sys,zlib

root=Path(S.report('G06'));name='Aquaris FS_300dpi_75% (bản mới).pdf'
src,prior=S.src(name),S.dst(name)
plan=json.loads((root/'review'/'word-copy-plan.json').read_text(encoding='utf-8'))
probe=json.loads((root/'review'/'word-copy-source-geometry.json').read_text(encoding='utf-8'))
old=json.loads((root/'final-state-v2.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==probe['source_sha256'] and sha(prior)==probe['prior_sha256']
geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
trial=sys.argv[1] if len(sys.argv)>1 else '2'
stage=fresh(root/'review'/f'word-copy-mau-{trial}.pdf')
j=Job(src,stage,log_path=fresh(root/'review'/f'word-copy-mau-{trial}.log.json'))
j.E.close();j.E=Editor(prior);j.edits=old['final_edits'].copy()
base=Editor(src);RS=Raster(base);sCV=RS.canvas(RS.image_at(3,base.mediabox(3)))
grid,_=grid_mask(sCV,geo)
# Chữ M trong Motor (hàng19) là mẫu bình thường có cap23px; các mẫu khác23–24px.
targetcap=23.0
changes=[];placement=[];patches=[]
for rp in plan['rows']:
    rr=next(r for r in probe['rows'] if r['row']==rp['row'])
    ws=[w for w in rr['words'] if any(c.isalpha() for c in w['text'])]
    pieces=[word_piece(sCV,RS,w,rr['box'],grid,label) for label,w in zip(LABELS[rr['row']],ws)]
    factor=targetcap/rp['cap'];gs=[scaled_piece(p,factor,rp['baseline']) for p in pieces]
    cell=rr['rect'];cv=j.R.render_canvas(3,(cell[0]-.6,cell[1]-.4,cell[2]+.6,cell[3]+.4),dpi=300)
    dark=cv.gray()<160;protect=np.zeros(dark.shape,np.uint8)
    for x in np.where(dark.mean(axis=0)>.8)[0]:protect[:,max(0,x-2):min(protect.shape[1],x+3)]=1
    for y in np.where(dark.mean(axis=1)>.85)[0]:protect[max(0,y-2):min(protect.shape[0],y+3),:]=1
    protected=protect.astype(bool)
    oldink=np.any(cv.work<255,axis=2)&~protected
    erase_intent=cv2.dilate(oldink.astype(np.uint8),np.ones((5,5),np.uint8)).astype(bool)&~protected
    j.R.erase(cv,mask=erase_intent,color=(255,255,255),dilate=0)
    if rr['row'] in (5,13):groups=[[0,1,2,3],[4,5,6,7]]
    elif rr['row'] in (15,18):groups=[[0,1,2],[3,4]]
    else:groups=[[0,1,2]]
    widths=[]
    for group in groups:
        width=sum(gs[i]['alpha'].shape[1] for i in group)
        width+=sum(max(2,(pieces[b]['box'][0]-pieces[a]['box'][2])*factor) for a,b in zip(group,group[1:]))
        widths.append(width)
    cellbox=cv.box(cell);top,bottom=cellbox[1],cellbox[3]
    margin=12.0
    asc=[max(g['alpha'].shape[0]-g['boff'] for g in (gs[i] for i in group)) for group in groups]
    desc=[max(g['boff'] for g in (gs[i] for i in group)) for group in groups]
    leading=targetcap*1.42
    height=asc[0]+leading*(len(groups)-1)+desc[-1]
    base0=(top+bottom-height)/2+asc[0]
    boxes=[];linerecs=[]
    for li,group in enumerate(groups):
        if widths[li]>cellbox[2]-cellbox[0]-2*margin:raise RuntimeError('Từ quá dài sau ngắt dòng '+str(rr['row']))
        if rr['row']==28:
            originalLeft=cv.to_px(*sCV.to_page(pieces[0]['box'][0],pieces[0]['box'][1]))[0]
            u=min(originalLeft,cellbox[2]-margin-widths[li])
        else:u=(cellbox[0]+cellbox[2]-widths[li])/2
        baseline=base0+li*leading
        text=[];linebox=[]
        for pos,i in enumerate(group):
            g=gs[i];v=baseline+g['boff']-g['alpha'].shape[0]
            b=(round(u),round(v),round(u)+g['alpha'].shape[1],round(v)+g['alpha'].shape[0])
            if b[0]<cellbox[0]+3 or b[2]>cellbox[2]-3 or b[1]<top+3 or b[3]>bottom-3:
                raise RuntimeError('Chạm khung '+str(rr['row'])+' '+g['text'])
            j.R.stamp(cv,g,u,v,ink=np.zeros(3,np.float32))
            boxes.append(list(cv.rect(b)));linebox.append(b);text.append(g['text'])
            placement.append(dict(row=rr['row'],word=g['text'],source_box=list(pieces[i]['box']),
                                  source_rect=list(sCV.rect(pieces[i]['box'])),source_page=4,factor=factor,
                                  destination_box=list(b),destination_rect=list(cv.rect(b))))
            u+=g['alpha'].shape[1]
            if pos+1<len(group):u+=max(2,(pieces[group[pos+1]]['box'][0]-pieces[i]['box'][2])*factor)
        bbox=(min(b[0] for b in linebox),min(b[1] for b in linebox),max(b[2] for b in linebox),max(b[3] for b in linebox))
        linerecs.append(dict(text=' '.join(text),baseline_px=baseline,bbox_page=list(cv.rect(bbox)),width_px=widths[li]))
    cv.work[protected]=cv.orig[protected]
    rnew=[min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes)]
    change=dict(task=53,page=4,row=rr['row'],rect=list(cell),new_rect=rnew,
                old=' '.join(LABELS[rr['row']]),new='\n'.join(x['text'] for x in linerecs),lines=linerecs,
                source_cap_px=rp['cap'],target_cap_px=targetcap,factor=factor,
                grid_pixels_equal=bool(np.array_equal(cv.work[protected],cv.orig[protected])))
    changes.append(change)
    j._add(3,list(cell),f"#53 dòng{rr['row']}: chép nguyên từ gốc, ngắt/căn trong ô",'raster-word-copy')
    mask=(np.any(cv.work!=cv.orig,axis=2)|erase_intent)&~protected
    h,w=mask.shape;doc=j.E.doc
    sm=doc.new_image_xobject(zlib.compress((mask.astype(np.uint8)*255).tobytes(),9),w,h,Name('DeviceGray'),8,'FlateDecode')
    face=cv.work.copy();face[~mask]=255
    ref=doc.new_image_xobject(zlib.compress(face.tobytes(),9),w,h,Name('DeviceRGB'),8,'FlateDecode',smask=sm)
    nm=j.R._register(3,ref);x0,y1=cv.to_page(0,0);x1,y0=cv.to_page(w,h)
    mtx=[Num(x1-x0),Num(0),Num(0),Num(y1-y0),Num(x0),Num(y0)]
    j.E.insert_instrs(3,len(j.E.page(3).ops)-1,[Instr([],'q'),Instr(mtx,'cm'),Instr([Name(nm)],'Do'),Instr([],'Q')],before=False)
    patches.append(dict(page=4,row=rr['row'],name=str(nm),rect=list(cv.rect((0,0,w,h))),masked=True,
                        original_ink_pixel_count=int(oldink.sum()),erase_intent_pixel_count=int(erase_intent.sum()),
                        transparent_pixel_count=int((~mask).sum())))
    cv.orig=cv.work.copy()
    print('ROW',rr['row'],'scale',factor,'lines',linerecs,'grid',change['grid_pixels_equal'],flush=True)
base.close()
j.save();check=j.check(raster=True)
outside_new=verify.outside_pixels(prior,stage,{4:[(c['rect'][0]-1,c['rect'][1]-1,c['rect'][2]+1,c['rect'][3]+1) for c in changes]},dpi=200,pad=0,thr=0,min_size=0)
for c in changes:
    im=verify.crop(stage,3,c['rect'],600)
    c['ocr_after']=' '.join(w['text'] for w in ocr.image_words(im,psm=6))
for dpi in (400,500,600):
    verify.compare_sheet(prior,stage,[(3,c['rect'],f"#53 row{c['row']}") for c in changes],fresh(root/'review'/f'word-copy-mau-{trial}-{dpi}dpi.png'),dpi=dpi,pad=(2,1))
verify.compare_sheet(prior,stage,[(3,(286,382,559,697),'#53 toàn bảng; giữ số thứ tự/lưới')],fresh(root/'review'/f'word-copy-toan-bang-{trial}.png'),dpi=400,pad=(0,0))
data=dict(source=src,prior=prior,stage=stage,source_sha256=sha(src),prior_sha256=sha(prior),stage_sha256=sha(stage),
          changes=changes,placements=placement,edits=j.edits,patches=patches,check=check,outside_new_200dpi=outside_new,
          method='Chép nguyên từ của mỗi dòng từ đúng ảnh gốc; co/phóng cùng tỉ lệ theo mẫu Motor cap23px; giữ chữ lỗi nguyên; không dùng ngân hàng ký tự hoặc đổi phông.')
json.dump(data,open(fresh(root/'review'/f'word-copy-build-{trial}.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,
          default=lambda x:x.item() if hasattr(x,'item') else str(x))
j.close();print('CHECK',check['ok'],'outside_new',outside_new,flush=True)
