"""Sửa phạm vi nội dung theo đọc độc lập của root, giữ nguyên phương pháp mẫu2.
Giữ các nét chưa xác định/không lệch chắc bằng pixel nguồn, chỉ sửa16+10nét.
Không ghi PDF trong lượt này.
"""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import RenderCanvas
from catfix.charts import draw_polyline,bezier
from scipy.interpolate import UnivariateSpline
from pathlib import Path
from PIL import Image
import numpy as np,json
P='G05/KIEM TOAN TOAN BO/'
V='G05/MAU SUA DUONG/PHUONG PHAP 1 - TACH NET VA VECTOR/MAU 2/'
I='G05/MAU SUA DUONG/PHUONG PHAP 2 - CHUYEN TIET DIEN MUC/MAU 1/'
O='G05/MAU SUA DUONG/PHAM VI DA BO NET CHUA RO 2/'
rec=json.loads(Path(S.report(V+'TOA DO VA PHUONG PHAP.json')).read_text(encoding='utf8'));audit=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'));proof=[]
for p in rec['panels']:
 f=p['family'];axis=next(z for z in json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8')) if z['family']==f);r=p['rect'];s=72/p['dpi']
 orig=np.array(Image.open(S.report(V+f+'-truoc.png')).convert('RGB'));allclean=np.array(Image.open(S.report(I+f+'-nen-da-tach.png')).convert('RGB'));H,W=orig.shape[:2]
 xx=np.arange(W)+.5;yy=np.arange(H)+.5
 models=[]
 for c in p['curves']:
  ps=[v for v in audit['points'] if v['family']==f and v['row']==c['rank'] and v.get('H_curve_m') is not None];bins={}
  for pp in ps:
   for v in pp['sample_locations']:bins.setdefault(round(v['x_px'],4),[]).append(v['y_px'])
  sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx]);spl=UnivariateSpline(sx,sy,s=len(sx)*.96,k=3)
  eligible=any(v['confidence_status']=='CHƯA ĐẠT' for v in ps) and not (f=='6SP30' and c['curve_model']=='6SP30-8')
  models.append((c,spl,eligible))
 centres=np.array([spl(xx) for c,spl,e in models]);eligible=np.array([e for c,spl,e in models])
 oldChanged=np.any(orig!=allclean,axis=2);keep=np.zeros((H,W),bool);protectcore=np.zeros((H,W),bool)
 for x in np.nonzero(oldChanged.any(0))[0]:
  delta=abs(yy[:,None]-centres[:,x]);owner=delta.argmin(1);keep[:,x]=eligible[owner]
  for k,(c,spl,e) in enumerate(models):
   if e:continue
   half=6.0 # Source150dpi pixel core/support in600dpi renderer; background not protected.
   protectcore[:,x]|=(delta[:,k]<half)&(orig[:,x].mean(1)<205)
 m=oldChanged&keep;clean=orig.copy();clean[m]=allclean[m]
 cv=RenderCanvas(p['page']-1,r,p['dpi'],clean,None)
 kept=[];changed=[]
 for c,spl,e in models:
  if not e:
   kept.append(dict(curve_model_in_table=c['curve_model'],actual_source_label='6SP30-9' if f=='6SP30' and c['curve_model']=='6SP30-8' else c['curve_model'],rank=c['rank'],reason='Danh tính -9/-8 chưa đủ8/8' if f=='6SP30' and c['curve_model']=='6SP30-8' else 'Không có mốc lệch chắc theo sai số ảnh'))
   continue
  pts=[]
  for seg in c['segments']:pts.extend(bezier(*map(np.array,seg),n=150).tolist())
  draw_polyline(cv,pts,color=tuple(p['source_color_rgb']),width_px=p['width_pt']*p['dpi']/72,ss=4);changed.append(c)
 # Keep actual source strong pixels of unresolved/unchecked curves exact.
 cv.work[protectcore]=orig[protectcore]
 Image.fromarray(cv.work).save(fresh(S.report(O+f+'-sau.png')));Image.fromarray(orig).save(fresh(S.report(O+f+'-truoc.png')));Image.fromarray(clean).save(fresh(S.report(O+f+'-nen-da-tach.png')))
 np.savez_compressed(fresh(S.report(O+f+'-miếng-anh-600dpi.npz')),orig=orig,output=cv.work,background=clean,protected=protectcore)
 left_x=(min(c['start_page'][0] for c in changed)-r[0])/s-5
 left_eq=bool(np.array_equal(cv.work[:,:int(left_x)],orig[:,:int(left_x)]));assert left_eq
 p['curves']=changed;p['kept_curves']=kept;p['patch_pixel_count']=int(np.any(cv.work!=orig,axis=2).sum());p['strong_unknown_curve_pixels_equal']=bool(np.array_equal(cv.work[protectcore],orig[protectcore]));p['left_text_dashes_pixels_identical']=left_eq;p['scope']='Only unambiguous curves with at least one confidently failed source point; source -9/-8,2/3 and SP60-4 preserved.'
 proof.append(dict(family=f,changed_curves=len(changed),kept_curves=kept,new_points=sum(len(c['new_Q']) for c in changed),left_text_dashes_pixels_identical=left_eq,protected_curve_pixels=int(protectcore.sum()),protected_pixels_identical=p['strong_unknown_curve_pixels_equal']))
 print(f,'only',len(changed),'curves','new points',proof[-1]['new_points'],'left equal',left_eq,flush=True)
rec['scope_correction_only']=True;rec['scope_proof']=proof
Path(fresh(S.report(O+'TOA DO VA PHUONG PHAP.json'))).write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf8')
