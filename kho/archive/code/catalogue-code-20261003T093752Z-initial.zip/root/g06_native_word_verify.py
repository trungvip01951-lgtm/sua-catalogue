from catwork import start,fresh
S,D,N=start()
from catfix import verify
from catfix.raster import Raster
from catfix.vector import Editor
from g06_word_tools import grid_mask,word_piece,scaled_piece,LABELS
from pathlib import Path
import json,numpy as np,cv2,pikepdf,hashlib,sys

root=Path(S.report('G06'));mode=sys.argv[1] if len(sys.argv)>1 else 'stage'
st=json.loads((root/'review'/'native-word-build-2.json').read_text(encoding='utf-8'))
raw=json.loads((root/'review'/f'native-word-acceptance-{mode}-2.json').read_text(encoding='utf-8'))
src=S.src('Aquaris FS_300dpi_75% (bản mới).pdf');dst=st['stage'] if mode=='stage' else S.dst('Aquaris FS_300dpi_75% (bản mới).pdf')
prior=st['prior'] if mode=='stage' else str(root/'review'/'ban-da-dat-51-truoc-sua-53.pdf')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==st['source_sha256'] and sha(dst)==raw['destination_sha256']
geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'));probe=json.loads((root/'review'/'word-copy-source-geometry.json').read_text(encoding='utf-8'));plan=json.loads((root/'review'/'word-copy-plan.json').read_text(encoding='utf-8'))
E=Editor(src);R=Raster(E);cv=R.canvas(R.image_at(3,E.mediabox(3)));grid,_=grid_mask(cv,geo)
out=dict(source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),raw_acceptance=str(root/'review'/f'native-word-acceptance-{mode}-2.json'),
    note='Kiểm nền ở lòng ô cách vách/lưới 1pt; kiểm toàn lưới và mép khử răng cưa riêng, không tính lưới thành bụi chữ. Kết quả kiểm thô được giữ nguyên.')
out['background_checks']=[]
for dpi in (400,500,600):
    for c in st['changes']:
        r=c['rect'];aa=np.array(verify.crop(prior,3,r,dpi));bb=np.array(verify.crop(dst,3,r,dpi))
        old=cv2.dilate((aa.min(axis=2)<230).astype(np.uint8),np.ones((5,5),np.uint8)).astype(bool)
        border=int(np.ceil(dpi/72.0))
        old[:border]=False;old[-border:]=False;old[:,:border]=False;old[:,-border:]=False
        for p in st['placements']:
            if p['row']!=c['row']:continue
            nr=p['destination_rect'];pad=.6;s=dpi/72
            x0=max(0,int(np.floor((nr[0]-pad-r[0])*s)));x1=min(old.shape[1],int(np.ceil((nr[2]+pad-r[0])*s)))
            y0=max(0,int(np.floor((r[3]-nr[3]-pad)*s)));y1=min(old.shape[0],int(np.ceil((r[3]-nr[1]+pad)*s)))
            old[y0:y1,x0:x1]=False
        vals=bb.min(axis=2)[old]
        out['background_checks'].append(dict(dpi=dpi,row=c['row'],checked_pixels=int(len(vals)),minimum=int(vals.min()) if len(vals) else None,pixels_below_254=int((vals<254).sum()),clean=bool(len(vals) and np.all(vals>=254))))
print('Nền lòng ô',[(v['dpi'],v['row'],v['minimum'],v['pixels_below_254']) for v in out['background_checks']],flush=True)

# Đọc lại luồng ảnh/mặt nạ từ PDF đã lưu, không chỉ nhận dữ liệu trước khi lưu.
out['saved_word_provenance']=[]
with pikepdf.open(dst) as pdf:
    resources=pdf.pages[3].Resources.XObject
    for rp in plan['rows']:
        rr=next(z for z in probe['rows'] if z['row']==rp['row']);ws=[w for w in rr['words'] if any(ch.isalpha() for ch in w['text'])]
        pieces=[word_piece(cv,R,w,rr['box'],grid,label) for w,label in zip(ws,LABELS[rr['row']])]
        patch=next(p for p in st['patches'] if p['row']==rr['row']);xobj=resources[pikepdf.Name('/'+patch['name'].lstrip('/'))]
        x0,y0,x1,y1=patch['native_box'];face=np.frombuffer(xobj.read_bytes(),np.uint8).reshape(int(xobj.Height),int(xobj.Width),3);mask=np.frombuffer(xobj.SMask.read_bytes(),np.uint8).reshape(int(xobj.Height),int(xobj.Width))
        assert face.shape[:2]==(y1-y0,x1-x0) and set(np.unique(mask).tolist())<={0,255}
        for piece in pieces:
            proof=next(p for p in st['word_proof'] if p['row']==rr['row'] and p['word']==piece['text']);scaled=scaled_piece(piece,proof['factor'],rp['baseline']);alpha=scaled['alpha']
            bx0,by0,bx1,by1=proof['destination_box'];actual=cv.orig[by0:by1,bx0:bx1].copy()
            ix0,iy0,ix1,iy1=max(x0,bx0),max(y0,by0),min(x1,bx1),min(y1,by1)
            sm=mask[iy0-y0:iy1-y0,ix0-x0:ix1-x0]>0;sub=actual[iy0-by0:iy1-by0,ix0-bx0:ix1-bx0]
            sub[sm]=face[iy0-y0:iy1-y0,ix0-x0:ix1-x0][sm]
            expected=(255*(1-alpha)).round().clip(0,255).astype(np.uint8);actualgray=actual.min(axis=2);ink=alpha>0
            out['saved_word_provenance'].append(dict(row=rr['row'],word=piece['text'],source_box=proof['source_box'],source_rect=proof['source_rect'],
                source_rgb_sha256=hashlib.sha256(cv.orig[piece['box'][1]:piece['box'][3],piece['box'][0]:piece['box'][2]].tobytes()).hexdigest(),
                source_alpha_sha256=hashlib.sha256(piece['alpha'].tobytes()).hexdigest(),scaled_alpha_sha256=hashlib.sha256(alpha.tobytes()).hexdigest(),
                source_hashes_match=proof['source_alpha_sha256']==hashlib.sha256(piece['alpha'].tobytes()).hexdigest() and proof['scaled_alpha_sha256']==hashlib.sha256(alpha.tobytes()).hexdigest(),
                saved_ink_samples_exact=bool(np.array_equal(actualgray[ink],expected[ink])),maximum_gray_delta=int(np.abs(actualgray.astype(int)-expected.astype(int))[ink].max()),
                whole_word=True,factor=proof['factor']))
E.close()
out['common_checks_ok']=all([raw['structure']['ok'],not raw['outside_pixels_200dpi'],all(v['pixels_exactly_equal'] for v in raw['unchanged_pages_1_3']),raw['model_51_ocr']['ok'],
    all(v['pixels_exactly_equal'] for v in raw['unsolved_52_headers_preserved']),raw['metadata_equal'],raw['font_resources_equal'],raw['native_text_equal'],raw['xmp']['values_equal'],raw['bookmarks_equal'],raw['links_equal'],
    all(v['ok'] for v in raw['prior_image_streams_preserved']),len(raw['new_patches'])==5,all(v['masked'] and v['page']==4 for v in raw['new_patches']),
    all(v['pixels_exactly_equal'] for v in raw['grid_checks']),all(v['pixels_exactly_equal'] for v in raw['number_column_checks']),all(v['clean'] for v in out['background_checks']),
    len(out['saved_word_provenance'])==29,all(v['source_hashes_match'] and v['saved_ink_samples_exact'] for v in out['saved_word_provenance']),all(v['all_words_inside_cell'] for v in raw['readback'])])
json.dump(out,open(fresh(root/'review'/f'native-word-verification-{mode}-2.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
print('COMMON',out['common_checks_ok'],'word proof',[(v['row'],v['word'],v['saved_ink_samples_exact'],v['maximum_gray_delta']) for v in out['saved_word_provenance']],flush=True)
