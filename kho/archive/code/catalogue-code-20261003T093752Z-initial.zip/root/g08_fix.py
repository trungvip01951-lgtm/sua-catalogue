from catwork import start,fresh
from pathlib import Path
import json,re,hashlib
import numpy as np
from catwork import row
S,D,N=start()
from catfix import charts,verify
from catfix.vector import Editor
from catfix.textlayer import TextLayer

names=['Catalog cắt rác Aquaris WC (bản mới).pdf','Catalog cắt rác perotac (bản mới).pdf','Catalog cắt rác redpump (bản mới).pdf']
measure=[]
for name in names:
    j=S.job(name)
    for pi,color,Qs,maxq,maxh in [(0,(.886719,.498047,.525391),list(range(0,36,5)),50,50),
                                  (4,(.176025,.329102,.630859),[120],390,45)]:
        P=j.E.page(pi)
        gx,gy=charts.gridlines(P,(690,275 if pi==4 else 292,1150,675))
        ch=charts.Chart.from_ticks([(0,min(gx)),(maxq,max(gx))],[(0,min(gy)),(maxh,max(gy))])
        ids=charts.curve_objects(P,(690,275 if pi==4 else 292,1150,675),color=color,tol=.00001)
        assert len(ids)==1,ids
        pts=ch.to_data(charts.sample_path(P.object_pagepath(ids[0]),n=480))
        vals=[]
        for q in Qs:
            # Sai số 0.000045 m³/h do làm tròn tọa độ PDF tại đầu đường.
            qq=min(max(float(pts[:,0].min()),q),float(pts[:,0].max()))
            assert abs(qq-q)<.025
            val=ch.value_at(pts,qq); assert val is not None,(name,pi,q,pts[:,0].min(),pts[:,0].max())
            vals.append(val)
        measure.append(dict(file=name,page=pi+1,curve_object=ids[0],color=color,
                            x_ticks=[(0,min(gx)),(maxq,max(gx))],y_ticks=[(0,min(gy)),(maxh,max(gy))],
                            Q=Qs,H_measured=vals,H_final=[int(np.floor(v+.5)) for v in vals],
                            method='catfix.charts.sample_path(n=480); nội suy trên nét vẽ và trục gốc; làm tròn số nguyên'))
    j.close()
reference=next(m for m in measure if m['page']==1 and 'Aquaris' in m['file'])
assert reference['H_final']==[30,29,28,25,21,16,10,4]
for m in measure:
    if m['page']==1:
        m['selected_common_values']=reference['H_final']
        m['selection_reason']='Hai đường gốc khác nhau. Chọn đường thực tế Aquaris, đồng bộ cả bảng và đường tương ứng ở 3 file; anh cho phép tự quyết #64 và vẽ lại.'
assert all(m['H_final']==[29] for m in measure if m['page']==5)
mp=Path(S.report('G08/SO DO DUONG CONG.json'))
if mp.exists():
    oldm=json.loads(mp.read_text(encoding='utf-8'))
    assert [m['H_measured'] for m in oldm]==[m['H_measured'] for m in measure]
else:
    mp=Path(fresh(mp)); mp.write_text(json.dumps(measure,ensure_ascii=False,indent=2),encoding='utf-8')
print('Chốt #64: 30–29–28–25–21–16–10–4; #138: 28.747 m → 29 m.')

def exact_replace(j,pi,old,new,rect=None,align='left',expect=1):
    return j.text_replace(pi,old,new,rect=rect,align=align,expect=expect)

def table_row(j,pi,model):
    hdr=j.TL.find(pi,'Q (m³/h)'); assert len(hdr)==1
    ms=[m for m in j.TL.find(pi,model) if m.bbox[3]<hdr[0].bbox[1]]
    assert len(ms)==1,(pi,model,ms)
    m=ms[0]
    return (hdr[0].bbox[2]+4,m.bbox[1]-1,1205,m.bbox[3]+1)

checks=[]
for name in names:
    final=fresh(S.dst(name))
    j=S.job(name)
    j.dst=fresh(S.report('G08/THU LAN 1/'+name))
    j.log_path=fresh(S.report('G08/THU LAN 1/'+name+'.log.json'))
    exact_replace(j,0,'50WC15-80-7.5','50WC15-40-7.5',align='left')
    for pi in range(8):
        exact_replace(j,pi,'irrugation','irrigation')
        exact_replace(j,pi,'(KW)','(kW)',align='center')
        exact_replace(j,pi,'1 years','2 years' if 'Aquaris' in name else '1 year')
    exact_replace(j,1,'1.5-7.5kW','1.5-5.5kW')
    exact_replace(j,1,'36 m','40 m',rect=(30,425,245,480))
    exact_replace(j,2,'DN50','DN80',rect=(30,455,245,505))
    # Giữ bố cục 5 cột giải nghĩa model; thay lưu lượng 49 → 45.
    exact_replace(j,2,'49','45',rect=(40,618,255,648),align='center')
    exact_replace(j,3,'250 m³/h','240 m³/h',rect=(30,435,245,500))
    exact_replace(j,7,'DN350','DN300',rect=(30,450,245,510))
    rr=table_row(j,0,'50WC15-25-3')
    ms=j.TL.find(0,r'\d+',rect=rr,regex=True)
    assert len(ms)==8,(rr,ms)
    bounds=[(m.text,m.bbox) for m in ms]
    for (old,b),new in reversed(list(zip(bounds,[30,29,28,25,21,16,10,4]))):
        if old!=str(new): exact_replace(j,0,old,str(new),rect=(b[0]-.1,b[1]-.1,b[2]+.1,b[3]+.1),align='center')
    mm=next(m for m in measure if m['file']==name and m['page']==1)
    ch=charts.Chart.from_ticks(mm['x_ticks'],mm['y_ticks'])
    # Nội suy đơn điệu đi chính xác qua các số chốt, giữ màu/độ dày/lớp của đường cũ.
    j.E.replace_path(0,mm['curve_object'],ch.smooth_path(list(zip(mm['Q'],mm['selected_common_values'])),method='pchip'))
    j._add(0,(693,296,1028,530),'#64 đồng bộ đường 50WC15-25-3 với bảng đã chốt','curve')
    rr=table_row(j,4,'150WC200-20-18.5')
    ms=j.TL.find(4,r'\d+',rect=rr,regex=True)
    assert len(ms)==13,(rr,ms)
    assert ms[4].text=='27'
    b=ms[4].bbox
    exact_replace(j,4,'27','29',rect=(b[0]-.1,b[1]-.1,b[2]+.1,b[3]+.1),align='center')
    # Lỗi phát hiện thêm: hàng l/min trang 5 đã dùng nhầm hệ số cho bước 10 m³/h.
    hdr=j.TL.find(4,'Q (l/min)')[0]
    nums=j.TL.find(4,r'\d+',rect=(hdr.bbox[2]+3,hdr.bbox[1]-1,1205,hdr.bbox[3]+1),regex=True)
    assert [int(m.text) for m in nums]==[0,167,333,500,667,833,1000,1167,1333,1500,1667,1833,2000]
    for m,new in reversed(list(zip(nums,[0,500,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000]))):
        if m.text!=str(new):
            b=m.bbox
            exact_replace(j,4,m.text,str(new),rect=(b[0]-.1,b[1]-.1,b[2]+.1,b[3]+.1),align='center')
    for pi in range(5):
        head=j.TL.find(pi,'Max head'); assert len(head)==1
        val=j.TL.find(pi,r'\d+\s*m',rect=(130,head[0].bbox[1]-.1,245,head[0].bbox[3]+.1),regex=True)
        assert len(val)==1
        label=head[0]; value=val[0]
        flow=j.TL.find(pi,'Max flow rate')[0]
        step=flow.glyphs[0].o[1]-label.glyphs[0].o[1]
        assert 18<step<25,step
        y=label.glyphs[0].o[1]-step
        label.glyphs[0].run.font.encode('Speed')
        value.glyphs[0].run.font.encode('2900 r.p.m')
        j.TL.insert_like(label,'Speed',(label.glyphs[0].o[0],y),verbose=False)
        j.TL.insert_like(value,'2900 r.p.m',(value.glyphs[0].o[0],y),verbose=False)
        P=j.E.page(pi)
        rules=[oi for oi in P.objects_in((30,label.bbox[1]-8,245,label.bbox[1]+1)) if P.objs[oi]['op']=='S' and P.objs[oi]['bbox'][2]-P.objs[oi]['bbox'][0]>150 and P.objs[oi]['bbox'][3]-P.objs[oi]['bbox'][1]<.2 and 30<=P.objs[oi]['bbox'][0]<=60 and P.objs[oi]['bbox'][2]<=245]
        assert rules,(pi,'không tìm thấy đường kẻ mẫu')
        # Trang 5 chứa 2 đối tượng đường kẻ trùng hoàn toàn; chép đúng một mẫu.
        assert all(P.objs[r]['bbox']==P.objs[rules[0]]['bbox'] and P.color_of(r,'stroke')==P.color_of(rules[0],'stroke') for r in rules)
        oi=rules[0]
        j.E.insert_object_after(pi,oi,j.E.transform_path(P.object_pagepath(oi),dy=-step))
        width=j.TL.width_ts(value.glyphs[0].run,'2900 r.p.m')*value.glyphs[0].run.scale_x
        j._add(pi,(label.bbox[0]-1,y-8,max(241,value.glyphs[0].o[0]+width+1),y+8),'#139 thêm Speed 2900 r.p.m và kẻ bảng cùng kiểu','text-insert')
    for pi in [5,6,7]:
        ms=j.TL.find(pi,'Speed'); assert len(ms)==1
        b=ms[0].bbox
        vals=j.TL.find(pi,r'\d+\s*r\.p\.m',rect=(120,b[1]-.1,245,b[3]+.1),regex=True)
        assert len(vals)==1,vals
        if '1450' not in vals[0].text:
            exact_replace(j,pi,vals[0].text,'1450 r.p.m',rect=(120,b[1]-.1,245,b[3]+.1))
    if 'redpump' in name:
        exact_replace(j,7,'300WC950-20-90','300WC950-20-95')
        exact_replace(j,7,'90','95',rect=(785,132,800,144),align='center')
        exact_replace(j,7,'120','130',rect=(808,132,829,144),align='center')
    j.save()
    # Chỉ nhận bản sửa khi giữ cấu trúc, không đổi điểm ảnh ngoài vùng cho phép.
    ck=j.check()
    print(name,'nghiệm thu',ck['ok'],'unexpected',ck['unexpected'],'missing',ck['missing'])
    checks.append(dict(file=name,trial=j.dst,final=final,check=ck,edits=j.edits))
    Path(fresh(S.report('G08/THU LAN 1/'+name+'.check.json'))).write_text(json.dumps(ck,ensure_ascii=False,indent=2),encoding='utf-8')
    j.evidence(fresh(S.report('G08/THU LAN 1/'+name+'.png')),dpi=180)
    # Bản thử chưa được công bố là nghiệm thu; đối chiếu trực quan trước khi ghi bản cuối.
    j.close()
Path(fresh(S.report('G08/THU LAN 1/KIEM TRA.json'))).write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
