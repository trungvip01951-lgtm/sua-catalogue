from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,collections,math
from scipy.signal import find_peaks
from catfix.vector import Editor
from catfix.raster import Raster

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=S.src('Perotac bơm giếng SA_compressed (bản mới).pdf');dst=S.result('Perotac bơm giếng SA_compressed (bản mới).pdf')
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));RDIR=O.parent
d=json.loads((RDIR/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'));E=Editor(src);R=Raster(E);out=[]
for g in d['graphs']:
 if g['page']==8:continue
 a=g['axis'];f=a['frame_native'];im=max(R.images(g['page']-1),key=lambda z:z.W*z.H);rgb=R.canvas(im).orig;gray=rgb.astype(float)@np.array([.299,.587,.114]);left=int(f['left']);right=int(f['right']);bot=int(f['bottom']);rows=np.arange(bot+8,min(bot+124,gray.shape[0]-2));dark=255-np.median(gray[rows,left+8:right-8],axis=1);ids,_=find_peaks(dark,height=130,distance=12);assert len(ids)>=2,(g['family'],[(int(rows[k]),float(dark[k])) for k in ids]);et=rows[ids[0]];eb=rows[ids[1]]
 ticks=[]
 for t in a['flow_ticks']:
  x=t['u_native'];coords=np.arange(int(round(x))-3,int(round(x))+4);sig=255-np.median(gray[et+4:eb-4,coords],axis=0);w=np.maximum(sig-sig.min(),0);mx=int(np.argmax(w));keep=(abs(coords-coords[mx])<=1.6)&(w>=.20*w.max());pos=float(np.average(coords[keep],weights=w[keep])) if w.max()>3 else x
  ticks.append({'litre_per_minute':t['litre_per_minute'],'prior_source_tick':x,'actual_eta_vertical_tick':pos,'delta_native_px':pos-x,'coords':coords.tolist(),'gray_darkness_profile':sig.tolist()})
 def save_raw_crop_once(fn,box):
  pixels=rgb[box[1]:box[3],box[0]:box[2]]
  if fn.exists():assert np.array_equal(np.asarray(Image.open(fn)),pixels),'Existing source crop changed: '+str(fn)
  else:Image.fromarray(pixels).save(fresh(fn))
 box=[left-33,int(f['top'])-7,left+8,bot+8];fn=O/f'g01_{g["family"]}_TRUC H PIXEL NGUYEN GOC.png';save_raw_crop_once(fn,box)
 qbox=[left-6,int(et)-7,right+7,int(eb)+24];qfn=O/f'g01_{g["family"]}_VACH Q ETA PIXEL NGUYEN GOC.png';save_raw_crop_once(qfn,qbox)
 out.append({'page':g['page'],'family':g['family'],'actual_eta_horizontals_source_native':[int(et),int(eb)],'source_flow_ticks':ticks,'H_source_crop':str(fn),'H_source_crop_native_bbox':box,'Q_source_crop':str(qfn),'Q_source_crop_native_bbox':qbox,'no_pixel_retouched':True});print('TICKS',g['family'],'ETA',[int(et),int(eb)],'DELTA',round(max(abs(t['delta_native_px']) for t in ticks),5),flush=True)
fp=Path(fresh(O/'g01_TRUC Q DO TU VACH ETA THUC RIENG VA TRUC H NGUON.json'));fp.write_text(json.dumps({'read_only':True,'source':src,'source_sha256':sha(src),'current_sha256':sha(dst),'graphs':out,'note':'Hàng nhãn l/min và đường lưới ETA thực; tránh chọn cột chữ trong khung H làm vạch. Phải soi các ảnh gốc đã lưu trước dùng.'},ensure_ascii=False,indent=2,default=lambda z:z.item() if isinstance(z,np.generic) else z.tolist()),encoding='utf8');E.close();print('FILE',str(fp),'SHA',sha(fp))
