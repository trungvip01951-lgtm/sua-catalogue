"""Fresh source-island handoff report and remaining boundaries; no PDF/ledger."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import sys,json,hashlib,numpy as np
import pymupdf as fitz
from PIL import Image
sys.path.insert(0,str(HERE))
from g04_redpump_whole_caption_island_RAM_builder import build_caption_islands_RAM

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'));F=M/'13 CAPTION NGUYEN NGUON DAO RAM LAN2B'
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json');a=J(M/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')
prior=J(F/'CATFIX13 CAPTION DAO NGUYEN NGUON DOC RAM FULL MEP.json');O=F/'SOI NET CHAM VA TAT CA MEP LAN1'
d=J(O/'SOI13 CAPTION TAT CA MEP VA5 MUC CHAM NGUYEN NGUON.json')
holes=J(M/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json');eta=J(M/'ETA IT BEZIER RAM 551 TAM VA BAT DINH NGUON.json')
keep=J(P/'VACH PHU FEET VA KHOI TIEU DE GIU NGUON V1.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
E,rr,content=build_caption_islands_RAM(b,a,prior['islands'],holes,eta)
assert rr['content_SHA256']==prior['content_SHA256']
boxes=[z['island_page_bbox'] for z in prior['islands']]
anchor_geometric_clip=[]
for r in a['points']:
    xy=np.array([r['actual_page_x'],r['actual_page_y']]);dist=[]
    for bb in boxes:
        distance=np.linalg.norm(np.maximum(np.maximum(np.array(bb[:2])-xy,xy-np.array(bb[2:])),0))
        dist.append(float(distance))
    anchor_geometric_clip.append(dict(model=r['model'],Q=r['Q_m3_h'],H_table=r['H_table_m'],
        already_accepted_M1_point=xy.tolist(),nearest_caption_island_distance_pt=min(dist),
        point_inside_any_new_clip_hole=min(dist)==0,pen_radius_pt=.475,
        new_caption_clip_does_not_remove_full_pen_footprint=min(dist)>.475,
        numeric104_NOT_remeasured_from_input=True,full_actual_path_fingerprint_kept=True))
assert len(anchor_geometric_clip)==104 and all(z['new_caption_clip_does_not_remove_full_pen_footprint'] for z in anchor_geometric_clip)

def render(doc,bb,dpi):
    pg=doc[7];T=pg.transformation_matrix;p0=fitz.Point(bb[0],bb[1])*T;p1=fitz.Point(bb[2],bb[3])*T
    clip=fitz.Rect(min(p0.x,p1.x),min(p0.y,p1.y),max(p0.x,p1.x),max(p0.y,p1.y));px=pg.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=clip,colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(px.samples,np.uint8).reshape(px.height,px.width,px.n)[:,:,:3].copy()
title=[];expanded_title=[]
with fitz.open(b['input_current']) as cur:
    bb=keep['title_original_page_bbox']
    for dpi in [150,200,600]:
        aa=render(cur,bb,dpi);zz=render(E.doc.doc,bb,dpi);assert aa.shape==zz.shape
        title.append(dict(dpi=dpi,full_title_rect=bb,pixels_checked=aa.shape[0]*aa.shape[1],changed_pixels=int(np.any(aa!=zz,axis=2).sum())))
        if dpi==600:Image.fromarray(zz).save(fresh(F/'TITLE HO NGUON CHINH XAC RAM600.png'))
        eb=prior['restored_source_island_boxes'][0];xa=render(cur,eb,dpi);xz=render(E.doc.doc,eb,dpi)
        expanded_title.append(dict(dpi=dpi,expanded_clip_hole_rect=eb,changed_pixels=int(np.any(xa!=xz,axis=2).sum()),
            expanded_margin_NOT_the_original_title_box=True))
assert all(z['changed_pixels']==0 for z in title)

focus=d['focus5'];states=[]
for r in d['records']:
    name=r['model'];ed=r['edge_reads_NO_trimming'];intr=r['new_QH_stroke_footprints_intersecting_original_caption_box']
    other=sorted(set(z['model'] for z in intr if z['model']!=name))
    description={
        '4SL16/23':'Nét của đường /25 sát/cắt phần trên số3; mép đảo chuyển từ nét PDF mới sang mực JPEG cũ.',
        '4SL16/11':'Nét /12 chạy qua vùng trên L16/11; band ảnh nguồn khác nét đều mới, không tách khỏi các pixel chữ bằng cắt toàn cụm.',
        '4SL16/8':'Nét /9 chạm phía trên cụm /8 và có mực JPEG sát chân chữ; còn thay đổi mực ở mép đảo.',
        '4SL16/5':'Nét /6 chạm phía trên L16/5; ghép toàn cụm còn đoạn mờ ở trên và dưới cạnh nét mới.',
        '4SL16/4':'Mực JPEG cũ sát phần trên/chân cụm; quan hệ với khung và nét mới còn giới hạn ở mép dưới. Không tự suy là nét chữ hoặc gọi đồng bộĐẠT.'
    }.get(name,'Không dựng lại chữ; dáng/cỡ/vị trí source được giữ. Khoảng mờ JPEG và nét cũ sát chân còn cần ROOT/đồ họa chốt trong toàn biểu đồ.')
    states.append(dict(model=name,native_original_font_shape_preserved=True,core100_changed_all_resolutions=sum(z['source_dark100_neutral35_changed'] for z in ed),
        full_crop_changed150=next(z['changed_pixels'] for z in ed if z['dpi']==150),full_crop_changed600=next(z['changed_pixels'] for z in ed if z['dpi']==600),
        all_crop_edges_checked_without_omission=True,other_actual_QH_curves_crossing_or_touching_caption_island=other,
        individual_graphic_status='CHƯA THỂ đồng bộ mực tại chỗ' if name in focus else 'CHƯA CHỐT hình thức',
        observation=description))
out=dict(stage='RAM source-islands readback/handoff; NO PDF2',source_SHA256=guards[0],current_SHA256=guards[1],M1_SHA256=guards[2],
    RAM_content_SHA256=rr['content_SHA256'],QH26_fingerprints_unchanged=True,QH104_clip_coverage_check=anchor_geometric_clip,
    smallest_caption_hole_distance_from_104_anchor_center_pt=min(z['nearest_caption_island_distance_pt'] for z in anchor_geometric_clip),
    QH_numeric104_previously_accepted_NO_new_numeric_claim=True,source_title_full_pixel_checks=title,
    expanded_title_margin_pixel_changes=expanded_title,
    earlier_title_PNG_filename_incomplete_handoff='KHOI TIEU DE NGUYEN NGUON RAM600 KHONG DOI.png: expanded clip hole, NOT all crop pixels unchanged; retained history, not acceptance evidence.',
    caption_states13=states,graphic5_not_completed=focus,all13_core100_changed0=all(z['core100_changed_all_resolutions']==0 for z in states),
    source_word_shape_read_NO_FONT_CAD_program_claim=True,original_Source_image_raw_bytes_size_CTM_unchanged=True,
    source_subpixels_and_gray_foreign_curve_are_not_separable_by_whole_rectangle=True,
    proposed_leader_alone_does_not_remove_existing_JPEG_curve_through_glyph=True,
    extra_new_leader_NOT_drawn=True,original_caption_CTM_or_position_NOT_changed=True,source_pixels_NOT_erased_recolored_or_refitted=True,
    no_more_contour_fitting_for_this_method=True,method_state='DỪNG cách đảo nguồn ở hồ sơ này: 5cụm CHƯA THỂ đồng bộ trong giới hạn; chờ ROOT/đồ họa đọc.',
    other8_graphics_NOT_automatically_PASS=True,numeric_eta='CHƯA THỂ: không có bảngη.',
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False)
manifest=Path(fresh(F/'BAN GIAO13 DAO NGUON VA5 GIOI HAN KHONG PDF2.json'));manifest.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
rows=[]
for k,z in enumerate(states,1):
    rows.append(f"| {k} | Redpump SL | 8 | {z['model']} | Nhãn source JPEG nhỏ, có đường sát chữ | Giữ nguyên toàn cụm ở đúng ma trận đặt ảnh, cỡ và vị trí | {z['individual_graphic_status']}; toàn mép 150/600 đổi {z['full_crop_changed150']}/{z['full_crop_changed600']} điểm; lõi tối dưới100 không đổi | Ảnh nguồn–bản giao–RAM và tọa độ trong phiếu 13 cụm |")
rows += [
"| 14 | Redpump SL | 8 | 13 Q–H/104 mốc bảng | M1 đã được ROOT kiểm đủ | 26 nét hình học giữ nguyên; 104 neo nằm ngoài đủ bán kính nét ở 13 lỗ | ĐẠT bảo toàn hình học/neo; không đo lại và không gọi mực JPEG lẫn chữ là nét mới ĐẠT | Phiếu 26 dấu vết và kiểm phủ 104 neo |",
"| 15 | Redpump SL | 8 | Hiệu suất η | M1 có gợn ảnh nén | Giữ recipe hai Bézier RAM đã được chấp nhận, 551 tâm riêng SL | Hình học đã được chọn; số η CHƯA THỂ vì nguồn không có bảng | Phiếu ETA hai Bézier và ảnh toàn QH+η |",
"| 16 | Redpump SL | 8 | 5 vạch feet và tiêu đề | M1 cắt một phần mép vạch | 5 lỗ đã nới0,48pt; title là ảnh nguyên source | 15 vùng feet +3 vùng title ở150/200/600 đều0 điểm đổi | Phiếu bảo toàn và title600 |",
"| 17 | Redpump SL | 8 | Ngoài miền sửa | Bản giao giữ b7c1… | Cắt hình học ảnh gốc; không phủ trắng/màu | 200dpi/ngưỡng0/đệm0: ngoài miền0 điểm đổi | CATFIX13…json |",
"| 18 | Redpump SL | 1–11 | Ảnh, mặt nạ, cỡ giấy, liên kết, siêu dữ liệu | Tệp giao hiện hành | 66 lần đặt ảnh cũ và mặt nạ/ma trận, XMP nguyên luồng, giá trị thông tin, 10trang khác giữ | ĐẠT bảo toàn; chưa biến thành hình thức13 nhãn ĐẠT | CATFIX13…json; source/canonical/M1 SHA giữ |"]
lines=[
"# Redpump SL — 13 cụm chữ nguyên nguồn bằng vùng cắt PDF trong bộ nhớ",
"",
"**Chưa đạt hình thức toàn biểu đồ. Dừng cách này tại hồ sơ hiện tại: 5 cụm /23, /11, /8, /5 và /4 chưa thể đồng bộ mực trong giới hạn giữ nguyên chữ/ma trận đặt ảnh/vị trí và byte nguồn.** 13 tên được giữ bằng chính ảnh Redpump nguyên nguồn, không dùng chữ vector thử V7/V10. Chưa tạo PDF mẫu2, không đổi bản giao hoặc sổ tiến độ. Các 8 cụm còn lại đang chờ kiểm hình thức độc lập, không tự tínhĐẠT.",
"",
"| STT | Tệp | Trang | Việc | Trước | Sau RAM đảo nguồn | Nghiệm thu | Chứng cứ |",
"|---|---|---|---|---|---|---|---|",
*rows,"",
"RAM là bản xem dựng trong bộ nhớ; CTM là ma trận giữ vị trí/cỡ của ảnh. Byte là dữ liệu ảnh gốc; JPEG là ảnh nén. Dùng bộ sửa catfix qua backend fitz (bộ đọc PDF MuPDF), chỉ cập nhật nội dung trang trong bộ nhớ, không gọi lệnh lưu PDF.",
"Khối title dùng đúng hộp nguồn [228,064635;488,298121;355,066507;507,983690]pt:0 điểm đổi ở150/200/600. Hộp clip đã nới bên ngoài title có282/405/1238 điểm đổi trong phần lề được phép dựng lại; không gọi toàn hộp nới là0. PNG cũ mang tên KHOI TIEU DE NGUYEN NGUON RAM600 KHONG DOI là ảnh hộp nới của lần kiểm bị chặn, tên chưa chính xác; giữ lịch sử, không dùng để chứng minh0. Ảnh đúng hộp nguồn là TITLE HO NGUON CHINH XAC RAM600.png.",
"",
"Cách dựng: ảnh gốc giữ ngoài hai miền sửa, khối tiêu đề, năm vạch feet và13 đảo chứa trọn tên nguồn. Các lớp đường/lưới mới cắt trừ13 đảo. Hai lớp phủ trắng M1 bị loại khỏi bản RAM; không thêm ảnh, mặt nạ chữ, phông hoặc cách tô màu che nét cũ. Dùng đúng nguồn1739×1237, ma trận834,957×593,928pt; không chuyển trục/màu/chữ của Perotac.",
"",
"Đã mở toàn biểu đồ150 và600; soi đủ13 tên source–current–RAM và5 ảnh nối lớn. Nét cũ trong JPEG không phải một lớp riêng: /23 có /25 chạm phía trên3; /11 có /12 ở L16/11; /8 có /9; /5 có /6; /4 còn mực cũ sát trên/chân và giới hạn mép. Đường dẫn nhẹ chỉ giúp gán tên, không loại được mực cũ trong cùng điểm ảnh với chữ. Thay chữ, tẩy/recolor điểm ảnh, đổi ma trận/vị trí hay fit đường biên lại không nằm trong phương án đang được giao, nên không tiếp tục bằng cách đó.",
"",
"**Không bỏ2 điểm ảnh ở mép để báo đạt.** Mọi điểm trong từng ảnh cắt150/600 đều được so và danh sách điểm đổi/RGB/tọa độ đã lưu. Tại150, đổi0…94điểm/hộp; tại600 đổi0…103. Những tâm điểm đổi sâu nhất chỉ0,24pt và0,060013pt từ mép hộp. Lõi tối neutral (xám trung tính, dưới100) không đổi ở13 tên; điều này chỉ kiểm lõi, không chứng minh mọi mép xám yếu hay toàn bộ phông đạt. Không tự gọi các điểm xám160 là chữ hoặc nét bơm khi chưa có chứng cứ trực tiếp. Hộp cắt và chân chữ đều đã được soi đầy đủ trong ảnh bối cảnh.",
"",
f"104 neo từng được ROOT chấp nhận nằm ngoài các lỗ với khoảng cách tâm nhỏ nhất{out['smallest_caption_hole_distance_from_104_anchor_center_pt']:.9f}pt, lớn hơn bán kính nét0,475pt. 26 đường thực giữ nguyên dấu vết. Nguồn màu/nét ảnh có bất định khoảng0,480136pt/một điểm ảnh gốc; tên phông CAD, cỡ danh nghĩa và bút nguồn trước nén vẫn chưa thể truy chính xác. Không nhận pixel nén là màu bút CAD gốc.",
"",
"Ảnh khung xanh, điểm hồng và chữ chú thích chỉ nằm trong PNG báo cáo, không nằm trong nội dung RAM/PDF. LAN2 là thử kỹ thuật lỗi nhận nhầm chỉ số trang với chỉ số lệnh ảnh, ảnh không hiện, đã giữ làm lịch sử; LAN2B sửa lỗi chỉ số và là bộ đang bàn giao. LAN1 có bộ ảnh đọc dở do lượng tử hóa hộp cắt; LAN1B đọc đủ13 cụm. Không có thêm PDF sau M1 trong các bước đó.",
"",
"[Toàn QH vàη150](<TOAN QH ETA RAM150 KHONG PDF2.png>) · [Toàn QH vàη600](<TOAN QH ETA RAM600 KHONG PDF2.png>) · [13 tên source/current/RAM150/600 đủ mép](<13 CAPTION SOURCE CURRENT RAM150600 FULL MEP KHONG CAT CHU.png>)",
"",
"[5 cụm nguồn chạm chữ và chỗ nối600](<SOI NET CHAM VA TAT CA MEP LAN1/5 CUM MUC CHAM GLYPH NGUYEN SOURCE CURRENT RAM600.png>) · [13 bối cảnh đủ mép600](<SOI NET CHAM VA TAT CA MEP LAN1/13 CUM NGUYEN NOI DUONG600 FULL CONTEXT.png>) · [Tất cả điểm đổi/tọa độ/RGB](<SOI NET CHAM VA TAT CA MEP LAN1/SOI13 CAPTION TAT CA MEP VA5 MUC CHAM NGUYEN NGUON.json>)",
"",
"[Bảo toàn ảnh/ngoài vùng/metadata](<CATFIX13 CAPTION DAO NGUYEN NGUON DOC RAM FULL MEP.json>) · [Bàn giao và kiểm phủ104 neo](<BAN GIAO13 DAO NGUON VA5 GIOI HAN KHONG PDF2.json>) · [Nội dung CATFIX dựng trong bộ nhớ](<LENH CATFIX RAM13 CAPTION DAO KHONG PDF.txt>)",
"",
"Nguồn SHA256 (mã kiểm tệp): `"+guards[0]+"`",
"Bản giao SHA256: `"+guards[1]+"`",
"Mẫu1 SHA256: `"+guards[2]+"`",
"Nội dung RAM SHA256: `"+rr['content_SHA256']+"`",
"",
"V7/V10 giữ lịch sử nghiên cứu, không dùng trong13 đảo nguồn. Số9V7 từng đạt riêng không bị kéo sang bộ ảnh nguồn này. Ngoài p8, hồ sơ kiểm toán17 biểu đồ/196 model còn chưa chốt; 6SL25/Q27 đã có báo cáo riêng. Không suy p8 hoặc bảo toàn cấu trúc thành toàn catalogueĐẠT.",
]
reportpath=Path(fresh(F/'BAO CAO8 COT13 DAO NGUON VA5 CHUA THE KHONG PDF2.md'));reportpath.write_text('\n'.join(lines)+'\n',encoding='utf8')
E.close();assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print('HANDOFF',reportpath,'SHA256',sha(reportpath),flush=True)
print('MANIFEST',manifest,'SHA256',sha(manifest),flush=True)
print('26geometry retained;104centers min clearance',out['smallest_caption_hole_distance_from_104_anchor_center_pt'],'title',title,'NO PDF2',flush=True)
