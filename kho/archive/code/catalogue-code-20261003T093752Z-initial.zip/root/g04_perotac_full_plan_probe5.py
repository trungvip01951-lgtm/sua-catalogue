"""Khóa các vạch/khung η và khung tiêu đề bằng pixel nguồn thật."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from pathlib import Path
from scipy.signal import find_peaks
from PIL import Image
import numpy as np,json,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
E=Editor(src,backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float);l=a@[.299,.587,.114]
def lines(axis, lo,hi,span, distance=5):
    # Median across an actual observed straight line: labels and curved ink
    # occupy a minority of the span and do not define its coordinate.
    gray=np.median(l[lo:hi,span[0]:span[1]],axis=1) if axis=='y' else np.median(l[span[0]:span[1],lo:hi],axis=0)
    score=255-gray;ids,_=find_peaks(score,height=9,distance=distance,prominence=7);out=[]
    for i in ids:
        rr=np.arange(max(0,i-2),min(len(score),i+3));w=np.maximum(score[rr],0);keep=w>=.65*score[i]
        center=float(np.average(rr[keep]+lo,weights=w[keep]));out.append(dict(native_center=center,integer_peak=int(i+lo),source_darkness_peak=float(score[i]),
                                                                            source_perpendicular_profile=[dict(native_coordinate=int(k+lo),darkness=float(score[k])) for k in rr]))
    return out
eta_horizontal=lines('y',579,681,(140,735),distance=8)
eta_vertical=lines('x',118,752,(587,674),distance=10)
title_bottom=lines('y',215,231,(487,739),distance=4)
title_left=lines('x',472,487,(183,220),distance=4)
main_horizontal=lines('y',175,577,(135,469),distance=15)
main_vertical=lines('x',118,752,(184,570),distance=10)
assert len(eta_horizontal)==8,(len(eta_horizontal),eta_horizontal)
assert len(eta_vertical)==9,(len(eta_vertical),eta_vertical)
assert len(title_bottom)==1 and len(title_left)==1
eta_box=[eta_vertical[0]['native_center'],eta_horizontal[0]['native_center'],eta_vertical[-1]['native_center'],eta_horizontal[-1]['native_center']]
source_boxes={'ETA TRUC NHAN VA VACH NGUON':[76,578,132,689],
              'KHUNG TIEU DE 4SA16 NGUON':[472,175,751,232]}
for label,box in source_boxes.items():
    Image.fromarray(cv.orig[box[1]:box[3],box[0]:box[2]]).save(fresh(root/(label+'150dpi.png')))
    verify.crop(src,7,cv.rect(box),600).save(fresh(root/(label+' PDF600dpi.png')))
out=dict(read_only=True,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),
         source_eta_frame_native_box=eta_box,source_eta_horizontal_lines=eta_horizontal,source_eta_vertical_lines=eta_vertical,
         eta_printed_labels='0,20,40,60%; không đặt thêm70% tại đường khung trên',
         eta_top_frame_does_not_define_new_70_label=True,
         source_title_bottom_native_v=title_bottom[0]['native_center'],source_title_left_native_u=title_left[0]['native_center'],
         source_title_top_and_right_are_main_frame=True,source_title_line_measurements=dict(left=title_left,bottom=title_bottom),
         main_observed_horizontal_lines=main_horizontal,main_observed_vertical_lines=main_vertical,
         approximated_eta_box_in_planV2_superseded_by_this_measurement=True,
         new_graph_or_glyph_sample_written=False,PDF_written=False,common_progress_written=False)
Path(fresh(root/'KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('ETA FRAME',eta_box,'HGRID',[z['native_center'] for z in eta_horizontal],'VGRID',[z['native_center'] for z in eta_vertical],flush=True)
print('TITLE LEFT/BOTTOM',out['source_title_left_native_u'],out['source_title_bottom_native_v'],flush=True)
print('MAIN H',[z['native_center'] for z in main_horizontal],'MAIN V',[z['native_center'] for z in main_vertical],flush=True)
E.close()
