"""Đối chiếu nét mới với chính các đoạn nét ảnh nguồn, không suy làpathgốc.
Chỉ đọc PDF/ảnh; số màu/độdàynguồn là phép đo ảnh150dpi, không bytebútPDF.
"""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
from scipy.interpolate import UnivariateSpline
import numpy as np,json,csv

P='G05/KIEM TOAN TOAN BO/'
I='G05/MAU SUA DUONG/PHAM VI DA BO NET CHUA RO 2/'
O='G05/MAU PDF SUA DUONG/'
audit=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'))
axes=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
rec=json.loads(Path(S.report(I+'TOA DO VA PHUONG PHAP.json')).read_text(encoding='utf8'))
segments=[]
for p in rec['panels']:
 f=p['family'];b=next(z for z in axes if z['family']==f);r=p['rect'];s=72/p['dpi'];arr=np.array(Image.open(S.report(I+f+'-truoc.png')).convert('RGB'),float)
 models=[]
 for k in range(1,20 if f=='6SP30' else 14):
  rows=[v for v in audit['points'] if v['family']==f and v['row']==k and v.get('H_curve_m') is not None];bins={}
  for v in rows:
   for loc in v['sample_locations']:bins.setdefault(round(loc['x_px'],4),[]).append(loc['y_px'])
  sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx]);models.append(UnivariateSpline(sx,sy,s=len(sx)*.96,k=3))
 for c in p['curves']:
  spl=models[c['rank']-1]
  for si,seg in enumerate(c['segments']):
   xa=(seg[0][0]-r[0])/s;xb=(seg[-1][0]-r[0])/s;measure=[]
   for xf in np.linspace(xa+12,xb-12,27):
    x=int(round(xf));pred=float(spl(x));allcent=np.array([z(x) for z in models]);sep=float(np.min(abs(np.delete(allcent,c['rank']-1)-pred)))
    if min(abs((np.array(b['xticks'])[:,1]-r[0])/s-x))<7:continue
    if min(abs((r[3]-np.array(b['yticks'])[:,1])/s-pred))<7:continue
    radius=min(12,max(4,sep*.43));ids=np.arange(int(pred-radius),int(pred+radius)+1);ids=ids[(ids>=0)&(ids<len(arr))]
    rgb=arr[ids,x];bg=np.percentile(rgb,90,axis=0);amp=np.maximum(0,bg-rgb).mean(1);baseline=np.percentile(amp,20);amp=np.maximum(0,amp-baseline)
    if amp.max()<45:continue
    peak=int(np.argmax(amp))
    if abs(ids[peak]-pred)>6:continue
    sel=amp>amp.max()*.5;slope=float(spl.derivative()(x));width=float(sel.sum()*s/np.sqrt(1+slope*slope))
    measure.append(dict(source_x_page=r[0]+x*s,source_y_page=r[3]-ids[peak]*s,source_peak_rgb=rgb[peak].astype(int).tolist(),source_normal_fwhm_pt=width,source_vertical_fwhm_pt=float(sel.sum()*s),source_slope=slope,source_rank_separation_px=sep))
   cols=np.array([v['source_peak_rgb'] for v in measure]);widths=np.array([v['source_normal_fwhm_pt'] for v in measure])
   z=dict(family=f,page=p['page'],model=c['curve_model'],rank=c['rank'],segment=si+1,new_segment_x_start_pt=seg[0][0],new_segment_x_end_pt=seg[-1][0],new_rgb=p['source_color_rgb'],new_width_pt=p['width_pt'],source_sample_count=len(measure),samples=measure,interpretation='Số nguồn suy từ lõiJPEG150dpi, trục/khángrăngcưa làm thayđổi màu/biềndày; không có thôngsốbút/pathnguồn đểso byte.')
   if len(measure)>=3:
    z.update(source_peak_rgb_percentile10=np.percentile(cols,10,axis=0).tolist(),source_peak_rgb_percentile35=np.percentile(cols,35,axis=0).tolist(),source_peak_rgb_percentile90=np.percentile(cols,90,axis=0).tolist(),source_normal_width_min_pt=float(widths.min()),source_normal_width_median_pt=float(np.median(widths)),source_normal_width_max_pt=float(widths.max()),new_width_in_source_measurement_range=bool(widths.min()-.12<=p['width_pt']<=widths.max()+.12),closest_source_RGB_max_channel_delta=int(np.min(np.max(abs(cols-np.array(p['source_color_rgb'])),axis=1))))
   else:z['comparison_status']='CHƯA THỂ đo riêng đoạn này: quáítlátcắt tách được lưới và nétliền kề'
   segments.append(z)
out=dict(segment_count=len(segments),curve_count=26,source_effective_dpi=150,render_dpi=600,source_has_native_QH_path=False,segments=segments,source_dashes_preserved='Toàn đoạntrái300dpi giữpixelnguồn theoDOC LAI DUONG THAT VA BAO TOAN.json; đuôiđượcsửa lànétliền, đườngmới[]0d.',style_interpretation='Màu/dàycủa nétmới lấy mẫu chínhảnhnguồn; tham sốvector mới khôngđược tuyênbố làtham sốvectornguồn. ROOTđãsoiPDFmẫuthật vàchấpnhận26đuôi.',measurable_segments=sum(v['source_sample_count']>=3 for v in segments))
Path(fresh(S.report(O+'MAU VA DO DAY TUNG DOAN - SUY TU ANH.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(S.report(O+'MAU VA DO DAY TUNG DOAN.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 fields=list(dict.fromkeys(k for v in segments for k in v if k!='samples'));w=csv.DictWriter(fp,fields,extrasaction='ignore');w.writeheader();w.writerows(segments)
print('SOURCE_STYLE',len(segments),'measurable',out['measurable_segments'],'width_range_accept',sum(v.get('new_width_in_source_measurement_range',False) for v in segments),'RGBnearestmax',max(v.get('closest_source_RGB_max_channel_delta',0) for v in segments),flush=True)
