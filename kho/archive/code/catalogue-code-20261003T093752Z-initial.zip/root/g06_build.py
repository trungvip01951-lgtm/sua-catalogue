from catwork import start,fresh
S,D,N=start()
from catfix.raster import Raster
from catfix.vector import Editor
from catfix.recipes import Job
from catfix import verify
from pathlib import Path
from PIL import Image
import numpy as np,json,copy,hashlib

NAME='Aquaris FS_300dpi_75% (bản mới).pdf'
root=Path(S.report('G06'));geometry=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
src=S.src(NAME);stage=fresh(root/'review'/'mau-sua-2.pdf')
job=Job(src,stage,log_path=fresh(root/'review'/'mau-sua-2.log.json'))
E=job.E;R=job.R;cvs=[R.canvas(R.image_at(i,E.mediabox(i))) for i in range(4)]
noops=[]
for pi in (0,3):
    NE=Editor(src);NR=Raster(NE);z=NR.noop_test(pi);NE.close()
    if z['mean_diff']>=1:raise RuntimeError('Ghi lại ảnh không sửa lệch quá ngưỡng')
    noops.append(dict(page=pi+1,**z))

def scaled(comp,factor):
    g=copy.deepcopy(comp);w=round(comp['alpha'].shape[1]*factor);h=round(comp['alpha'].shape[0]*factor)
    g['alpha']=np.array(Image.fromarray(comp['alpha'].astype('float32')).resize((w,h),Image.Resampling.BICUBIC)).clip(0,1)
    g['box']=(0,0,w,h)
    return g

# Học nguyên 11 hình ở model thật đầu bảng, tự xác nhận 7 máy OCR đọc nhầm thành /.
sc=cvs[1];source_rect=(21,204,103,220)
sourcecomps=R.components(sc,sc.box(source_rect),expect=11)
if len(sourcecomps)!=11:raise RuntimeError('Không đủ 11 hình chữ model nguồn')
source_text='FS-35-7-2.2';font={ch:g for ch,g in zip(source_text,sourcecomps)}
cv=cvs[0];oldregions=[(118,658,143,680),(186,658,213,680),(252,658,283,680)]
replacements=[('15','35'),('15','7'),('1.5','2.2')]
checks=[];allglyphsources=[]
firstold=R.components(cv,cv.box(oldregions[0]),expect=2)
capheight=firstold[-1]['alpha'].shape[0]
sourcecap=np.median([g['alpha'].shape[0] for ch,g in zip(source_text,sourcecomps) if ch.isdigit()])
scale=capheight/sourcecap
numbers={ch:scaled(g,scale) for ch,g in font.items() if ch in '2357-'}
dotold=R.components(cv,cv.box(oldregions[2]),expect=3)[1]
numbers['.']=dotold
# Đối chiếu hình số 5 của sơ đồ với số 5 chữ đậm của model bảng.
aa=Image.fromarray((firstold[-1]['alpha']*255).astype('uint8')).resize((80,100),Image.Resampling.BICUBIC)
bb=Image.fromarray((font['5']['alpha']*255).astype('uint8')).resize((80,100),Image.Resampling.BICUBIC)
am=np.array(aa)>120;bm=np.array(bb)>120;iou=float((am&bm).sum()/(am|bm).sum())
if iou<.65:raise RuntimeError('Hình số nguồn chưa đủ tương đồng kiểu chữ: '+str(iou))
for rect,(old,new) in zip(oldregions,replacements):
    comps=R.components(cv,cv.box(rect),expect=len(old))
    if len(comps)!=len(old):raise RuntimeError('Không đủ chữ cũ '+old)
    ink=R.bg_ink(cv.work,cv.box(rect))[1]
    baseline=float(np.median([g['box'][3] for ch,g in zip(old,comps) if ch!='.']))
    center=(min(c['box'][0] for c in comps)+max(c['box'][2] for c in comps))/2
    gs=[numbers[ch] for ch in new];gap=5.0;total=sum(g['alpha'].shape[1] for g in gs)+gap*(len(gs)-1)
    u=center-total/2;placed=[]
    R.erase_components(cv,comps)
    for ch,g in zip(new,gs):
        v=baseline-g['alpha'].shape[0];R.stamp(cv,g,u,v,ink=ink)
        placed.append([float(u),float(v),float(u+g['alpha'].shape[1]),float(baseline)])
        allglyphsources.append(dict(char=ch,source_page=1 if ch=='.' else 2,scale=1 if ch=='.' else scale))
        u+=g['alpha'].shape[1]+gap
    rectnew=cv.rect((min(b[0] for b in placed),min(b[1] for b in placed),max(b[2] for b in placed),max(b[3] for b in placed)))
    allowed=[min(rect[0],rectnew[0]),min(rect[1],rectnew[1]),max(rect[2],rectnew[2]),max(rect[3],rectnew[3])]
    job._add(0,allowed,'#51: '+old+' → '+new,'raster-glyph-copy')
    checks.append(dict(id=51,page=1,old=old,new=new,rect=allowed,placed=placed,source=source_rect,scale=scale))
# Dấu nối chép từ cùng dòng model; giữ đúng từng nhóm và lời giải thích phía dưới.
dash=numbers['-'];baseline=firstold[-1]['box'][3]
for x in (97.7,165.8,234.2):
    u,v=cv.to_px(x,668.65);u-=dash['alpha'].shape[1]/2;v=baseline-capheight*.48-dash['alpha'].shape[0]/2
    R.stamp(cv,dash,u,v,ink=R.bg_ink(cv.work,cv.box(oldregions[0]))[1])
    rr=cv.rect((u,v,u+dash['alpha'].shape[1],v+dash['alpha'].shape[0]))
    job._add(0,rr,'#51: thêm dấu nối đúng mẫu model nguồn','raster-glyph-copy')

# Chữ chuẩn lấy đúng những dòng bình thường trong cùng bảng chi tiết.
cv=cvs[3];ws=geometry['standard_words']
white=np.full(cv.work.shape[2],255.,dtype='float32');black=np.zeros(cv.work.shape[2],dtype='float32')
def clean_bank(words):
    samples=[]
    for w in words:
        text=w['text']
        if not text or any(not(ch.isalpha() or ch=='-') for ch in text):continue
        comp=R.components(cv,w['box'],bg=white,ink=black,expect=len(text))
        if len(comp)!=len(text):continue
        bots=[c['box'][3] for ch,c in zip(text,comp) if ch not in R.DESC and ch not in R.LOWMARK]
        if not bots:continue
        samples.append(dict(text=text,word=w,base=float(np.median(bots)),comps=comp,
                            size=float(np.percentile([c['box'][3]-c['box'][1] for c in comp],75))))
    return R._bank_from_samples(samples)
bank=clean_bank(ws)
lines=geometry['grids'][0]['lines'];right=geometry['grids'][1]['lines']
socket_rect=(311.3,478.06,419.5,499.94)
kw=R.ocr(cv,cv.box(socket_rect),scale=3,psm=7);kbank=clean_bank(kw)
if 'k' not in kbank['glyphs']:raise RuntimeError('Không có k kiểu chữ thường trong hàng socket')
cap=float(np.median([R.best_glyph(bank,ch)['alpha'].shape[0] for ch in 'CHPRST']))
k=R.best_glyph(kbank,'k');k=scaled(k,cap/k['alpha'].shape[0]);bank['glyphs']['k']=[k]
bank['metrics']['boff']['k']=0.;bank['metrics']['width']['k']=k['alpha'].shape[1];bank['metrics']['height']['k']=k['alpha'].shape[0]
bank['samples']=[]
texts={5:['Cruss recessed pan head','screw and washer assemblie'],13:['Cross recessed pan head','screw and washer assemblie'],
       15:['Hexagon socket head','cap screw'],18:['Hexagon socket head','cap screw'],28:['Mechanical flat pad']}
for num,strings in texts.items():
    if num<=22:rect=(311.3,lines[num+1]+.7,419.5,lines[num]-.7)
    else:
        i=num-22;rect=(447.8,right[i+1]+.7,557.3,right[i]-.7)
    box=cv.box(rect);comps=R.components(cv,box,band=False,bg=white,ink=black)
    if not comps:raise RuntimeError('Không thấy chữ hàng '+str(num))
    R.erase_components(cv,comps,color=white)
    rowtop,rowbottom=box[1],box[3];lineheight=cap*1.12
    baselines=[(rowtop+rowbottom)/2+(i-(len(strings)-1)/2)*lineheight+cap*.36 for i in range(len(strings))]
    placed=[]
    for text,base in zip(strings,baselines):
        layout=R.layout(bank,text);gl=[(ch,x,R.best_glyph(bank,ch)) for ch,x in layout]
        lo=min(x-g['alpha'].shape[1]/2 for ch,x,g in gl);hi=max(x+g['alpha'].shape[1]/2 for ch,x,g in gl)
        off=(box[0]+box[2])/2-(lo+hi)/2
        for ch,x,g in gl:
            u=off+x-g['alpha'].shape[1]/2;v=base+bank['metrics']['boff'].get(ch,0)-g['alpha'].shape[0]
            if u<box[0]+1 or u+g['alpha'].shape[1]>box[2]-1 or v<box[1]+1 or v+g['alpha'].shape[0]>box[3]-1:
                raise RuntimeError('Chữ mới chạm viền hàng '+str(num)+' '+ch)
            R.stamp(cv,g,u,v,ink=np.array([0]*cv.work.shape[2],dtype=float))
            placed.append([float(u),float(v),float(u+g['alpha'].shape[1]),float(v+g['alpha'].shape[0])])
    job._add(3,rect,'#53: đều cỡ hàng '+str(num),'raster-glyph-copy')
    checks.append(dict(id=53,page=4,row=num,rect=rect,new=' '.join(strings),lines=strings,placed=placed))
for c in cvs:
    if np.any(c.work!=c.orig):R.commit(c)
job.save()
state=dict(source=src,stage=stage,destination=S.dst(NAME),source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),
           checks=checks,edits=job.edits,noop=noops,font5_iou=iou,font_cap_px=cap,model_cap_px=capheight,
           glyph_sources=allglyphsources,missing52='Trong 4 trang chỉ có k thường kiểu không đậm ở Power (kW) và socket; không có k thường cùng kiểu chữ đậm của tiêu đề KW.',
           preserve136='Giữ cả hai dòng FS, không đổi hay ghi G07')
json.dump(state,open(fresh(root/'build-state-2.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
verify.compare_sheet(src,stage,[(z['page']-1,z['rect'],f"#{z['id']}: "+z['new']) for z in checks],fresh(root/'review'/'mau-sua-2.png'),dpi=400)
job.close()
print('Đã lưu mẫu G06',stage,'so kiểu số 5',iou,flush=True)
