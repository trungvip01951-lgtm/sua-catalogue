from catwork import start,fresh
S,D,N=start()
import pymupdf as fitz, json
from pathlib import Path
name='KTZ - LH Perotac (bản mới).pdf'
out=[]
for typ,path in [('source',S.src(name)),('sample',S.report('G09/MAU LAN2/'+name)),('final',S.dst(name))]:
    d=fitz.open(path)
    v=dict(typ=typ,metadata=d.metadata,xml=d.get_xml_metadata(),toc=d.get_toc(),links=[p.get_links() for p in d]);out.append(v)
    print(typ,d.metadata,'xml length',len(v['xml']),'toc',v['toc'],flush=True);d.close()
Path(fresh(S.report('G09/DOI CHIEU THONG TIN.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
