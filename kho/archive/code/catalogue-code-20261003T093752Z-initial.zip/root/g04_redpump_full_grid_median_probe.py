"""Source median profiles: recover faint long grid independent of label rank."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.signal import find_peaks
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
f=json.loads((root/'KHUNG LUOI THAT NGUON TRANG8.json').read_text(encoding='utf8'));plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
source=plan['method']['source'];current=plan['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(source),sha(current)];assert before==[f['source_SHA256'],f['current_SHA256']]
E=Editor(source,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);records=[];pic=Image.fromarray(cv.orig);dr=ImageDraw.Draw(pic)
for z in f['panels']:
 x0,y0,x1,y1=z['frame_native_uv'];left,right=int(np.ceil(x0+4)),int(np.floor(x1-4));top,bottom=int(np.ceil(y0+4)),int(np.floor(y1-4));sub=a[top:bottom,left:right];neutral=sub.max(2)-sub.min(2)<14;gray=sub@np.array([.299,.587,.114]);clean=np.where(neutral,gray,np.nan);med=np.nanmedian(clean,axis=1);score=255-med;peaks,_=find_peaks(score,height=2.5,prominence=1.7,distance=8);pys=[];proof=[]
 for k in peaks:
  lo,hi=max(0,int(k)-2),min(len(score),int(k)+3);ids=np.arange(lo,hi);ids=ids[score[ids]>=.8*score[k]];yp=float(np.average(ids+top,weights=score[ids]));pys.append(yp);proof.append(dict(peak_native_v=int(k+top),centroid_native_v=yp,median_RGB=[float(np.nanmedian(np.where(neutral[k],sub[k,:,i],np.nan))) for i in range(3)],median_gray=float(med[k]),contrast=float(score[k]),profile_native_v=list(range(lo+top,hi+top)),profile_contrast=score[lo:hi].tolist(),source_page_y=cv.to_page(0,yp)[1]))
  dr.line((left,yp,right,yp),fill=(180,0,180),width=1)
 rec=dict(name=z['name'],actual_frame_page_bbox=z['frame_page_bbox'],horizontal_inner_grid=proof,prior_coverage_method_rows=z['horizontal_inner_grid_native'],grid_status='Các đỉnh từ median hàng mực nguồn xám thật; cần soi ảnh nguyên trước khóa.',vertical_inner_grid_page=z['vertical_inner_grid_page'],native_to_page_ctm=f['source_original_ctm'],catalogue_written=False)
 records.append(rec);print(z['name'],'median actualgrid',[(p['peak_native_v'],round(p['contrast'],2)) for p in proof],flush=True)
photo=fresh(root/'LUOI MO DOC MEDIAN NGUON TRANG8.png');pic.crop((78,145,783,710)).resize((1410,1130),Image.Resampling.NEAREST).save(photo)
out=dict(source_SHA256=before[0],current_SHA256=before[1],records=records,source_marked_grid_photo=photo,eta_bbox_candidate_correction='Đáy khungη đoTHỰC là271.7568698464pt. Con số269.8trongghi chútrước làphỏngđoán chưađúng, khôngdùngdựngmẫu.',method='Median theo đúngpixelxámtrêntừnghàng, loại riêngchromaticcurve. Không gánH/ηtheothứhạnglưới.',PDF_sample_written=False)
Path(fresh(root/'LUOI MO DOC MEDIAN NGUON TRANG8.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(source),sha(current)]
