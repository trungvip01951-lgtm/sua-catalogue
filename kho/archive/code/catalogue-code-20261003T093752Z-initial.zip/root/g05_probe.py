from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix import charts
j=S.job('Perotac bơm giếng SP_compressed (bản mới).pdf')
targets=[(4,'57',(628,142,644,150),(610,25,785,180)),
         (7,'1767',(710,400,730,409),(635,365,730,480)),
         (8,'1750',(636,90,655,97),(586,35,787,162)),
         (6,'110',(364,33,375,39),(205,42,385,156)),
         (6,'80',(378,33,386,39),(205,42,385,156))]
out=[]
for p,old,r,lr in targets:
    cv=j.canvas(p);hits=j.R.find(cv,old,box=cv.box(r),scale=3,psm=7)
    bank=j.R.glyph_bank(cv,box=cv.box(lr))
    print(p+1,old,[(h['text'],cv.rect(h['box']),h.get('n_glyphs')) for h in hits],'chu',list(bank['glyphs']),flush=True)
    pic=Path(S.report(f'G05/DINH VI/O {p+1} {old}.png'))
    if not pic.exists():cv.save_png(fresh(pic),box=cv.box(r),scale=4)
    out.append(dict(page=p+1,old=old,rect=r,learn_rect=lr,hits=hits,bank_chars=list(bank['glyphs'])))
stages=[2,3,4,5,7,8,10,13,15,17,20,24,26,30,32,35,38,42]
h=[22,33,44,56,78,89,111,145,167,189,222,267,289,334,356,389,422,467]
ratios=np.array(h)/stages;est=round(float(np.median(ratios))*6)
q=np.arange(0,43,6);values=[68,est,63,58,53,46,34,21]
f=charts.Chart.fit_poly(q,values,tol=2)
print('47 trungvi',float(np.median(ratios)),'uoc',est,'fit',f,flush=True)
assert est in [65,66,67,68,69]
Path(fresh(S.report('G05/DINH VI/TOA DO VA TI LE.json'))).write_text(json.dumps(dict(targets=out,ratios=ratios.tolist(),stages=stages,H=h,median=float(np.median(ratios)),estimate=est,row_values=values,fit=None if f is None else dict(coefficients=f[0].tolist(),degree=f[1],max_diff=f[2])),ensure_ascii=False,indent=2,default=lambda x:float(x)),encoding='utf-8')
j.close()
