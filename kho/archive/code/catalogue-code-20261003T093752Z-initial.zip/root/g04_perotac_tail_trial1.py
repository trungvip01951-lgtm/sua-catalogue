"""Mẫu 1 duy nhất: năm đuôi Perotac, mực nguồn riêng + nét PDF thật.
Không ghi canonical, nguồn hay tiến độ. ROOT kiểm mẫu trước chốt.
"""
from catwork import start,fresh
S,D,N=start()
from catfix.recipes import Job
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Instr,Num,Name
from catfix import verify
from pathlib import Path
from PIL import Image,ImageDraw
from scipy.interpolate import CubicHermiteSpline
import numpy as np,json,hashlib,zlib,math
name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
planroot=Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC'));plan=json.loads((planroot/'PHUONG AN CUOI 5 DIEM DE ROOT KIEM V2.json').read_text(encoding='utf8'));audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));rootproof=json.loads(Path(S.report('G04/ROOT PEROTAC NAM MOC V3/ROOT SO DO NAM MOC THUC.json')).read_text(encoding='utf8'))
folder=Path(S.report('G04/NAM DUOI NET PDF THAT MAU1'));trial=fresh(folder/name);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==plan['source_sha256'] and sha(current)==plan['current_sha256'];assert rootproof['hashes']==[sha(src),sha(current)]
j=Job(current,trial,backend='fitz',log_path=fresh(folder/'NHAT KY 5 DUOI.json'));Es=Editor(src);Rs=Raster(Es);records=[];by_page={}
for it in plan['items']:
 pi=it['page']-1;model=it['model'];g=next(z for z in audit['graphs'] if z['family']==it['family']);c=next(z for z in g['curves'] if z['model']==model)
 image=max(j.R.images(pi),key=lambda z:z.W*z.H);cv=j.R.canvas(image);sourceim=max(Rs.images(pi),key=lambda z:z.W*z.H);src_cv=Rs.canvas(sourceim);assert np.array_equal(cv.orig,src_cv.orig);assert j.E.doc.stream_raw(image.ref)==Es.doc.stream_raw(sourceim.ref)
 ar=cv.orig.astype(int);lum=cv.orig.astype(float)@np.array([.299,.587,.114]);hc=g['axis']['H_grid_calibration'];frame=g['axis']['frame_native'];left=int(frame['left'])+3;right=int(frame['right'])-3;top=int(frame['top'])+3;bottom=int(frame['bottom'])-3
 # Recover the white/gray lattice levels from this original Perotac image.
 # Only pixels supported by the named observed curve are allowed to change.
 region=cv.orig[top:bottom,left:right].astype(float);row=np.median(region,axis=1);col=np.median(region,axis=0);bg=cv.orig.copy();bg[top:bottom,left:right]=np.minimum(row[:,None,:],col[None,:,:]).round().clip(0,255).astype(np.uint8)
 path=c['native_path'][:-1]+it['source_tail_core_extension_points'];xy=np.array([[p['u'],p['v']] for p in path]);ju=it['numeric_nodes'][0]['u'];eu=it['numeric_nodes'][-1]['u'];oldlast=xy[-1];box=it['proposed_native_edit_bounding_box'];x0,y0,x1,y1=box
 support=np.zeros(cv.orig.shape[:2],bool);supportdist=np.full((y1-y0,x1-x0),np.inf)
 for u in range(x0,x1):
  rows=np.arange(y0,y1)
  if u<ju-1:continue
  if u<=oldlast[0]:
   v=float(np.interp(u,xy[:,0],xy[:,1]));loc=xy[abs(xy[:,0]-u)<8];s=float(np.polyfit(loc[:,0],loc[:,1],1)[0]) if len(loc)>3 else 0.;dist=abs(rows-v)/np.sqrt(1+s*s)
  else:dist=np.hypot(rows-oldlast[1],u-oldlast[0])
  support[y0:y1,u]=dist<=4.5 if u<=oldlast[0] else dist<=8
  supportdist[:,u-x0]=dist
 diff=ar-bg.astype(int);absdiff=np.max(abs(diff),axis=2);chromadiff=diff.max(2)-diff.min(2);mask=support&(((absdiff>=3)&(chromadiff>=3))|((lum<220)&(absdiff>=8)))
 # Preserve every other source curve by its observed shape, plus both
 # previously accepted current vector paths. Geometry, not color, protects.
 otherprotect=np.zeros_like(mask)
 for other in g['curves']:
  if other['model']==model or not other.get('native_path'):continue
  op=other['native_path'];ou=np.array([p['u'] for p in op]);ov=np.array([p['v'] for p in op])
  for u in range(x0,x1):
   if not ou[0]<=u<=ou[-1]:continue
   v=float(np.interp(u,ou,ov));loc=np.c_[ou,ov][abs(ou-u)<8];sl=float(np.polyfit(loc[:,0],loc[:,1],1)[0]) if len(loc)>3 else 0.;rows=np.arange(y0,y1);otherprotect[y0:y1,u]|=abs(rows-v)/np.sqrt(1+sl*sl)<3.1
 if pi==7:
  for pc in plan['protected_current_curves']:
   pxy=np.array(pc['native_path_for_protection_only']);pxy=pxy[np.argsort(pxy[:,0])]
   for u in range(x0,x1):
    if not pxy[0,0]<=u<=pxy[-1,0]:continue
    v=float(np.interp(u,pxy[:,0],pxy[:,1]));rows=np.arange(y0,y1);otherprotect[y0:y1,u]|=abs(rows-v)<3.5
 mask&=~otherprotect
 ownneutral=[p for p in it['neutral_geometry_check']['pixels'] if p['is_own_curve']];assert all(mask[p['v'],p['u']] for p in ownneutral),(model,'own neutral not erased')
 assert not any(mask[p['v'],p['u']] for p in it['neutral_geometry_check']['pixels'] if not p['is_own_curve']),(model,'other neutral changed')
 # Append each lossless delta after all existing masks; keep source JPEG bytes.
 block=cv.orig[y0:y1,x0:x1].copy();m=mask[y0:y1,x0:x1];block[m]=bg[y0:y1,x0:x1][m];actual=np.any(block!=cv.orig[y0:y1,x0:x1],axis=2);sm=actual.astype(np.uint8)*255;doc=j.E.doc
 sr=doc.new_image_xobject(zlib.compress(np.ascontiguousarray(sm).tobytes(),9),x1-x0,y1-y0,Name('DeviceGray'),8,'FlateDecode');ir=doc.new_image_xobject(zlib.compress(np.ascontiguousarray(block).tobytes(),9),x1-x0,y1-y0,Name('DeviceRGB'),8,'FlateDecode',smask=sr);nm=j.R._register(pi,ir)
 rect=[float(v) for v in cv.rect(box)];jx=float(cv.to_page(ju,0)[0]);clip=[jx,rect[1],rect[2],rect[3]];patch=[Instr([],'q'),Instr([Num(clip[0]),Num(clip[1]),Num(clip[2]-clip[0]),Num(clip[3]-clip[1])],'re'),Instr([],'W'),Instr([],'n'),Instr([Num(rect[2]-rect[0]),Num(0),Num(0),Num(rect[3]-rect[1]),Num(rect[0]),Num(rect[1])],'cm'),Instr([Name(nm)],'Do'),Instr([],'Q')]
 nodes=it['numeric_nodes'];u=np.array([p['u'] for p in nodes]);v=np.array([p['v'] for p in nodes]);slopes=np.array(it['proposed_tangent_dv_du']);pathops=[];pathops.append(Instr([Num(float(z)) for z in cv.to_page(u[0],v[0])],'m'))
 for k in range(len(u)-1):
  step=(u[k+1]-u[k])/3;controls=[cv.to_page(u[k]+step,v[k]+slopes[k]*step),cv.to_page(u[k+1]-step,v[k+1]-slopes[k+1]*step),cv.to_page(u[k+1],v[k+1])];pathops.append(Instr([Num(float(z)) for p in controls for z in p],'c'))
 vector=[Instr([],'q'),Instr([Num(clip[0]),Num(clip[1]),Num(clip[2]-clip[0]),Num(clip[3]-clip[1])],'re'),Instr([],'W'),Instr([],'n'),Instr([Num(float(z/255)) for z in it['source_color_RGB']],'RG'),Instr([Num(it['source_equivalent_width_pt'])],'w'),Instr([Num(0)],'J'),Instr([Num(1)],'j'),Instr([[],Num(0)],'d')]+pathops+[Instr([],'S'),Instr([],'Q')]
 by_page.setdefault(pi,dict(patches=[],vectors=[]));by_page[pi]['patches']+=patch;by_page[pi]['vectors']+=vector
 j._add(pi,rect,model+': đuôi đúng số bảng, giữ đầu/nét đứt nguồn','source-masked-erasure+true-PDF-tail')
 rec=dict(model=model,page=pi+1,RGB=it['source_color_RGB'],equivalent_width_pt=it['source_equivalent_width_pt'],source_raster_has_no_literal_pen_width=True,native_box=box,page_box=rect,clip_at_numeric_join_page=clip,join_uses_old_visible_ink_left_of_clip=True,numeric_nodes=nodes,tangent_dv_du=slopes.tolist(),original_source_core_endpoint_native=oldlast.tolist(),old_source_ink_weak_extent=it['old_weak_tail_pixel_extent'],new_end_stops_at_last_numeric_Q=nodes[-1]['Q_m3_h'],masked_pixel_count=int(actual.sum()),own_neutral_erased=len(ownneutral),other_neutral_preserved=True,protected_source_other_path_pixels=int(otherprotect[y0:y1,x0:x1].sum()),source_raw_JPEG_unchanged_in_memory=True,image_patch_name=str(nm));records.append(rec)
 # Debug evidence is not an acceptance claim: red=own erase footprint.
 pic=Image.fromarray(cv.orig[y0:y1,x0:x1]).resize(((x1-x0)*6,(y1-y0)*6),Image.Resampling.NEAREST);d=ImageDraw.Draw(pic)
 for vv,uu in zip(*np.where(actual)):
  d.rectangle((uu*6,vv*6,uu*6+5,vv*6+5),outline='red',width=1)
 pic.save(fresh(folder/(model.replace('/','-')+' MAT NA MUC CU.png')));print('BUILT',model,'mask',rec['masked_pixel_count'],'gray',len(ownneutral),'clip',clip,flush=True)
for pi,b in by_page.items():j.E.insert_instrs(pi,len(j.E.page(pi).ops)-1,b['patches']+b['vectors'],before=False)
j.R.canvases.clear();j._canvases.clear();j.save();check=j.check(raster=True);assert check['ok'],check
allowed={}
for r in records:allowed.setdefault(r['page'],[]).append(r['page_box'])
outside=verify.outside_pixels(current,trial,allowed,dpi=200,thr=0,min_size=0,pad=.4)
Path(fresh(folder/'TAO MAU1 VA KIEM NGOAI.json')).write_text(json.dumps(dict(trial=trial,trial_sha256=sha(trial),source_sha256=sha(src),current_sha256=sha(current),check=check,outside_200dpi_threshold0=outside,records=records,canonical_written=False,common_progress_written=False,root_proof_reference='G04/ROOT PEROTAC NAM MOC V3',accepted=False,trial_number=1,method='True PDF cubic tails + own source ink footprint delta SMask, after all current masks; exact numeric join clip keeps old ink on the left.'),ensure_ascii=False,indent=2),encoding='utf8')
for r in records:
 verify.compare_sheet(current,trial,[(r['page']-1,r['page_box'],r['model'])],fresh(folder/(r['model'].replace('/','-')+' TRUOC SAU 600.png')),dpi=600,pad=(1,1));verify.crop(trial,r['page']-1,r['page_box'],600).save(fresh(folder/(r['model'].replace('/','-')+' PDF THAT 600.png')))
print('TRIAL1',check['ok'],'OUTSIDE',outside,'SHA',sha(trial),flush=True);j.close();Es.close()
