"""Plan only: Redpump /25 tail, no PDF mutation or simulated-after acceptance."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.charts import Chart
from catfix import verify
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((root/'4SL16_25 SO DO NGUON VA BAN GIAO.json').read_text(encoding='utf8'));v=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
folder=Path(S.report('G04/REDPUMP 25 PHUONG AN SUA DUOI'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(v['source']),sha(v['current'])];assert before==[v['source_SHA256'],v['current_SHA256']]
E=Editor(v['source'],backend='fitz');R=Raster(E);base=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(base);arr=cv.orig.astype(float);g=arr@np.array([.299,.587,.114]);C=Chart(*d['axis']);obs=np.array([[p['u'],p['v']] for p in d['raw_observed_trace']]);page=np.array([cv.to_page(u,vv) for u,vv in obs]);q=(page[:,0]-C.bx)/C.ax;h=(page[:,1]-C.by)/C.ay
fitmask=(q>=17.1)&(q<=17.95);assert fitmask.sum()>15
m0=float(np.polyfit(q[fitmask],h[fitmask],1)[0]);m1=-7.5
sourcejoin=float(np.interp(18,q,h));assert abs(sourcejoin-75)<.5 and -9<m0<-3
# Exact numeric endpoints; controls preserve observed incoming tangent and the
# terminal trend of the last three table columns. No invented intermediate H.
new=[(18.,75.),(19.,75.+m0),(20.,54.-m1),(21.,54.)]
px=np.array([C.to_page(a,b) for a,b in new]);Q=np.linspace(18,21,61);t=(Q-18)/3;H=(1-t)**3*75+3*(1-t)**2*t*new[1][1]+3*(1-t)*t*t*new[2][1]+t**3*54
assert np.all(np.diff(H)<0)
coloured=(arr[:,:,1]-arr[:,:,0]>6)&(arr[:,:,2]-arr[:,:,0]>8)&(g<230);tube=np.zeros(g.shape,bool)
src_cols=[]
for u,vv,qq in zip(obs[:,0],obs[:,1],q):
 if not 18.3<qq<20.1:continue
 u=int(u);ys=np.arange(max(0,int(round(vv))-4),min(arr.shape[0],int(round(vv))+5));good=ys[coloured[ys,u]]
 if len(good):src_cols.extend(arr[good,u].tolist())
samples=np.array(src_cols);assert len(samples)>100;lum=samples@np.array([.299,.587,.114]);ink=np.median(samples[lum<=np.percentile(lum,20)],axis=0)
alpha=np.clip((255-arr)@(255-ink)/np.sum((255-ink)**2),0,1);widths=[]
for i,(u,vv,qq) in enumerate(zip(obs[:,0],obs[:,1],q)):
 if not 18.3<qq<20.1:continue
 u=int(u);ys=np.arange(int(round(vv))-4,int(round(vv))+5);dvdu=float(np.gradient(obs[:,1],obs[:,0])[i]);widths.append(float((alpha[ys,u]*coloured[ys,u]).sum()/np.sqrt(1+dvdu**2)))
pxwidth=abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]);width=float(np.median(widths))*pxwidth;assert .4<width<1.5
join=C.to_page(18,75);end=C.to_page(21,54);oldend=list(page[-1]);union=np.vstack([page[(q>17.94)&(q<=q.max())],px]);bbox=[float(union[:,0].min()-2.5),float(union[:,1].min()-2.5),float(union[:,0].max()+2.5),float(union[:,1].max()+2.5)]
actual=verify.crop(v['current'],7,bbox,600);actual.save(fresh(folder/'DUOI HIEN HANH TRUOC.png'))
marked=actual.copy();draw=ImageDraw.Draw(marked);s=600/72
for label,(x,y) in [('NOI Q18 H75',join),('CHOT Q21 H54',end),('CUOI MUC CU',oldend)]:
 xx=(x-bbox[0])*s;yy=(bbox[3]-y)*s;draw.ellipse((xx-6,yy-6,xx+6,yy+6),outline=(180,0,180),width=2);draw.text((max(0,xx-110),yy+8),label,fill=(180,0,180))
marked.save(fresh(folder/'VI TRI NOI VA CHOT CHI TRONG BAO CAO.png'))
E.close();assert before==[sha(v['source']),sha(v['current'])]
plan=dict(source=v['source'],source_SHA256=v['source_SHA256'],current=v['current'],current_SHA256=v['current_SHA256'],page=8,model='4SL16/25',source_label='Nhãn nguồn /28, đã đổi thành /25 trong bản giao theo CAN; ROOT khóa danh tính hiện hành.',source_curve_evidence=str(root/'4SL16_25 SO DO NGUON VA BAN GIAO.json'),root_independent_evidence=str(S.report('G04/ROOT REDPUMP DIEM CUOI 25/ROOT DOC MUC Q21 DOC LAP.json')),source_table_Q=d['table']['Q'],source_table_H=d['table']['H'],proposed_Q_domain_changed=[18.,21.],preserved_curve_prefix='Giữ nét nguồn trước Q18; không tuyên bố Q0 đã đo khi chưa bao được mực.',join=dict(Q=18,H_table=75,H_source_curve=sourcejoin,page=list(join),incoming_slope_from_observed_Q=[17.1,17.95],incoming_slope_m_per_m3h=m0),end=dict(Q=21,H_table=54,page=list(end)),source_observed_endpoint=dict(Q=float(q[-1]),H=float(h[-1]),page=oldend),proposed_bezier_QH=new,proposed_bezier_page=px.tolist(),monotonic_decreasing_verified=True,RGB_measured_own_tail=ink.tolist(),equivalent_width_pt_measured_own_tail=width,source_native_pixel_pt=pxwidth,width_limitation='Bề rộng tương đương suy từ JPEG150dpi; không gọi là bút PDF gốc chính xác. Nghiệm thu hình thức qua toàn vùng150dpi và chi tiết600dpi.',allowed_cleanup_bbox=bbox,cleanup_method='Lấy nét quan sát /25 từ seed nhãn hiện hành, làm ống hẹp quanh mực cũ Q18 đến endpoint thực; mask chỉ pixel mực/halo, khôi phục lưới/nền từ hàng/cột nguồn riêng bằng phương pháp Redpump mẫu2 đã ĐẠT. Giữ nguyên ảnh/lớp gốc dưới mask, tất cả chữ, đường /23,/18 và đường khác. Không dùng số bảng để chọn nhánh xóa.',join_method='Nét PDF thật cubic từ Q18/H75 đến Q21/H54, tiếp tuyến đầu đo trên mực nguồn phía trái Q18; cap/nét như nguồn, đoạn mới liền nét vì vùng nguồn Q18..21 liền nét. Xóa phần mực nguồn kéo quá Q21; path mới không vượt Q21.',quality_gates=['Ảnh/nội dung/siêu dữ liệu/font/link/khổ nguồn giữ nguyên.','Đọc path thật trong PDF mẫu, hai neo Q18/H75 vàQ21/H54 cùng miền, không ngoại suy.','Ngoài hộp phép sửa0pixel ở200dpi; chữ/đường khác soi450/600dpi0pixel.','Soi nối/đầu-cuối/nét/các mảnh cũ150/600dpi; ROOT đọc độc lập trước bản giao.'],catalogue_written=False,proposal_only=True,max_failed_samples_per_method=2,status='CHỜ ROOT ĐỌC PHƯƠNG ÁN; chưa ghi PDF mẫu hoặc canonical')
Path(fresh(folder/'PHUONG AN RIENG SUA DUOI 25.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
text='''# Phương án riêng đường Redpump 4SL16/25\n\nĐã xác nhận lỗi Q21: bảng54m, mực hiện hành khoảng57,4m (ROOT đọc riêng ±0,65m; vượt ngưỡng1,08m). Nhãn nguồn /28 đã sửa /25; dùng danh tính bản giao.\n\n- Chỉ sửa đuôi Q18→Q21; nối Q18/H75, chốt Q21/H54. Nét cũ ở Q18≈74,972m, đã đúng bảng trong ngưỡng.\n- Tiếp tuyến đầu đo từ mực nguồn riêng Q17,1→17,95; đoạn mới là một đường cubic (nét cong PDF thật), giảm đều, giữ sắc/nét liền. Không vẽ quá Q21.\n- Tẩy ống hẹp theo đúng mực cũ từ chỗ nối tới endpoint gốc thực; khôi phục nền/lưới nguồn, giữ nguyên chữ, /23, /18 và mọi đường khác. Dùng phương pháp mặt nạ nhỏ+nét PDF đã đạt của chính Redpump.\n- Chỉ tính đạt sau đọc đường thật từ PDF mẫu, đối chiếu hai neo, soi nối/đầu-cuối150/600dpi, kiểm0pixel ngoài vùng và ROOT nghiệm thu độc lập.\n\nChưa ghi PDF. Đang chờ ROOT đọc phương án; tối đa hai mẫu mỗi phương pháp. Hồ sơ JSON kèm tọa độ, màu/bề rộng đo từ chính nét nguồn và ảnh vị trí chỉ trong báo cáo.\n'''
Path(fresh(folder/'PHUONG AN RIENG SUA DUOI 25.md')).write_text(text,encoding='utf8');print('PLAN ONLY',sourcejoin,m0,ink.tolist(),width,'bounds',bbox,flush=True)
