from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from g04_perotac_audit_labels_manual import MANUAL
from pathlib import Path
import numpy as np
E=Editor(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf'));R=Raster(E);root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
for ix in [0,1,3,4,8,13,14,15]:
 rec=DATA[ix];im=max(R.images(rec['page']-1),key=lambda i:i.W*i.H);cv=R.canvas(im);a=cv.orig.astype(int);xx,labels=MANUAL[rec['family']]
 for suf,t,b in labels[:3]:
  x=xx-2;rgb=a[t-4:b+16,x];g=rgb@np.array([.299,.587,.114]);c=rgb[:,1]+rgb[:,2]-2*rgb[:,0];kk=np.argsort(c)[-10:]
  print(rec['family'],suf,'x',x,'glyph',t,b,[(int(k+t-4),rgb[k].tolist(),int(c[k]),round(float(g[k]),1)) for k in sorted(kk)],flush=True)
 cv.save_png(fresh(root/('CHU NET MAU '+rec['family'].replace('.','_')+'.png')),(xx-16,labels[0][1]-8,xx+55,labels[2][2]+22),scale=5)
E.close()
