"""Đo thêm chu kỳ nét đứt theo chiều dài cung, lưới/khung từ nguồn p8."""
from catwork import start, fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
measure=json.loads((folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'))
audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'))
g=next(z for z in audit['graphs'] if z['family']=='4SA16');E=Editor(src,backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float)
step=measure['source_pixel_to_page_pt'];paths={c['model']:c.get('native_path') for c in g['curves']}
paths.update({c['model']:c['observed_source_path'] for c in measure['prior_accepted_models_original_source_style_trace_only']})
all_dashes=[];all_gaps=[];details=[]
for c in measure['QH_source_styles']:
    xy=np.array([[p['u'],p['v']] for p in paths[c['model']]])
    def arclength(start,end):
        u=np.linspace(start,end,151);v=np.interp(u,xy[:,0],xy[:,1]);return float(np.sqrt(np.diff(u)**2+np.diff(v)**2).sum()*step)
    intervals=[]
    for lo,hi in c['source_only_observed_dash_native_intervals']:
        if intervals and lo-intervals[-1][1]<=3:intervals[-1][1]=hi
        else:intervals.append([lo,hi])
    # Do not call the clipped first/last interval a full dash.
    full=[(lo,hi) for lo,hi in intervals if lo>=140 and hi<=269 and hi-lo>=8 and lo-.5>=xy[0,0] and hi+.5<=xy[-1,0]]
    ds=[dict(native=[lo-.5,hi+.5],source_arc_length_pt=arclength(lo-.5,hi+.5)) for lo,hi in full]
    gaps=[]
    for aa,bb in zip(full,full[1:]):
        if 4<=bb[0]-aa[1]-1<=10:gaps.append(dict(native=[aa[1]+.5,bb[0]-.5],source_arc_length_pt=arclength(aa[1]+.5,bb[0]-.5)))
    all_dashes.extend(z['source_arc_length_pt'] for z in ds);all_gaps.extend(z['source_arc_length_pt'] for z in gaps)
    details.append(dict(model=c['model'],source_full_dash_measurements=ds,source_gap_measurements=gaps,
                        source_arc_uses_actual_observed_path_not_table=True,
                        source_18_head_reading_limit=c['model']=='4SA16/18'))

grid=[]
for v in [246,311,376,441,506]:
    rgb=np.median(a[v,140:730],axis=0).tolist();region=a[v-3:v+4,140:730];profile=np.median(region,axis=1).tolist()
    grid.append(dict(direction='horizontal',actual_native_v=v,source_core_median_RGB=rgb,source_profile_RGB_v_minus3_to_plus3=profile))
for u in [202,280,358,435,513,591,668]:
    rgb=np.median(a[195:560,u],axis=0).tolist();region=a[195:560,u-3:u+4];profile=np.median(region,axis=0).tolist()
    grid.append(dict(direction='vertical',actual_native_u=u,source_core_median_RGB=rgb,source_profile_RGB_u_minus3_to_plus3=profile))
frames=[]
for label,sl in [('left',a[190:565,124:127]),('right',a[190:565,745:748]),('top',a[179:183,140:450]),('bottom',a[569:574,140:730])]:
    rows=sl.reshape(-1,3);dark=rows[np.mean(rows,axis=1)<140];frames.append(dict(side=label,source_dark_pixels_median_RGB=np.median(dark,axis=0).tolist(),dark_pixel_count=len(dark)))
Image.fromarray(cv.orig[175:576,118:284]).save(fresh(folder/'DAU NET DUT 13 DUONG NGUYEN150dpi.png'))
out=dict(source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(current).read_bytes()).hexdigest(),
         read_only=True,PDF_sample_written=False,new_glyph_written=False,
         source_dash_arc_median_pt=float(np.median(all_dashes)),source_dash_arc_p10_p90_pt=np.percentile(all_dashes,[10,90]).tolist(),
         source_gap_arc_median_pt=float(np.median(all_gaps)),source_gap_arc_p10_p90_pt=np.percentile(all_gaps,[10,90]).tolist(),
         source_dash_count=len(all_dashes),source_gap_count=len(all_gaps),source_measurements=details,
         source_dash_edge_uncertainty_pt=step*.75,
         proposed_locked_dash_pt=[round(float(np.median(all_dashes)),2),round(float(np.median(all_gaps)),2)],
         proposed_locked_dash_phase_pt=0.0,
         dash_phase_definition='Chiều dài cung từ điểm Q0 của mỗi đường mới; cùng chu kỳ và pha cho13model, không lấy khoảng hụt mực JPEG làm pha riêng.',
         source_grid_samples=grid,source_grid_median_core_RGB=np.median([z['source_core_median_RGB'] for z in grid],axis=0).tolist(),
         source_frame_samples=frames,source_frame_median_core_RGB=np.median([z['source_dark_pixels_median_RGB'] for z in frames],axis=0).tolist(),
         glyph_scaling_lock='Giữ glyph1:1 theo tọa độ vật lý nguồn; caption cap7–8nativepx≈3,36–3,84pt. Không tăng lêncap4pt trái±2% quy chuẩn. Tên/suffix cùng một ngân hàng nguồn và đường cơ sở.',
         graphical_acceptance_reference='01-KIEM-SOM-TRANG8-VA-QUY-CHUAN.md của tác nhân đồ họa độc lập',common_progress_written=False)
Path(fresh(folder/'KHOA DASH LUOI KHUNG VA CO CHU NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('SOURCE ARC DASH/GAP',out['source_dash_arc_median_pt'],out['source_gap_arc_median_pt'],'COUNT',len(all_dashes),len(all_gaps),'LOCK',out['proposed_locked_dash_pt'],flush=True)
print('SOURCE GRID RGB',out['source_grid_median_core_RGB'],'FRAME',out['source_frame_median_core_RGB'],flush=True)
E.close()
