from catwork import start,fresh
S,D,N=start()
from catfix import verify
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,cv2,hashlib
root=Path(S.report('G06'));st=json.loads((root/'review'/'native-word-build-2.json').read_text(encoding='utf-8'))
records=[];edgeitems=[]
E=Editor(st['prior']);mb=E.mediabox(3);R=Raster(E);cv=R.canvas(R.image_at(3,mb))
for dpi in (400,500,600):
 for c in st['changes']:
  r=c['rect'];aa=np.array(verify.crop(st['prior'],3,r,dpi));bb=np.array(verify.crop(st['stage'],3,r,dpi))
  old=aa.min(axis=2)<230;grid=np.zeros(old.shape,np.uint8)
  for x in np.where(old.mean(axis=0)>.8)[0]:grid[:,max(0,x-4):min(grid.shape[1],x+5)]=1
  for y in np.where(old.mean(axis=1)>.85)[0]:grid[max(0,y-4):min(grid.shape[0],y+5),:]=1
  old=cv2.dilate(old.astype(np.uint8),np.ones((5,5),np.uint8)).astype(bool)&~grid.astype(bool)
  for p in st['placements']:
   if p['row']!=c['row']:continue
   nr=p['destination_rect'];pad=.6;s=dpi/72
   x0=max(0,int(np.floor((nr[0]-pad-r[0])*s)));x1=min(old.shape[1],int(np.ceil((nr[2]+pad-r[0])*s)))
   y0=max(0,int(np.floor((r[3]-nr[3]-pad)*s)));y1=min(old.shape[0],int(np.ceil((r[3]-nr[1]+pad)*s)))
   old[y0:y1,x0:x1]=False
  yy,xx=np.where(old&(bb.min(axis=2)<254));points=[]
  pxorigin=np.floor((r[0]-mb[0])*dpi/72);pyorigin=np.floor((mb[3]-r[3])*dpi/72)
  for x,y in zip(xx,yy):
   xp=mb[0]+(pxorigin+x+.5)*72/dpi;yp=mb[3]-(pyorigin+y+.5)*72/dpi
   native=cv.to_px(xp,yp)
   points.append(dict(x=int(x),y=int(y),page=[float(xp),float(yp)],native_pixel=[float(z) for z in native],
    source_gray=int(aa[y,x].min()),after_gray=int(bb[y,x].min()),unchanged=bool(np.array_equal(aa[y,x],bb[y,x]))))
  records.append(dict(row=c['row'],dpi=dpi,points=points))
  if points:print('POINTS',dpi,c['row'],'n',len(points),'bbox',([min(p['page'][0] for p in points),min(p['page'][1] for p in points),max(p['page'][0] for p in points),max(p['page'][1] for p in points)]),'unchanged',sum(p['unchanged'] for p in points),flush=True)
for c in st['changes']:
 if c['row'] not in (5,13,28):continue
 r=c['rect'];er=(307.5,r[1]-1.5,319.5,r[3]+1.5) if c['row'] in (5,13) else (548.5,r[1]-1.5,560.5,r[3]+1.5)
 verify.compare_sheet(st['prior'],st['stage'],[(3,er,f'row{c["row"]} source | after; wall/old glyph edge')],fresh(root/'review'/f'native-word-edge-row{c["row"]}-1200dpi.png'),dpi=1200,pad=(0,0))
 # Thể hiện tọa độ tất cả điểm nghi ngờ trên ảnh, giữ ảnh không đánh dấu ở file riêng.
 im=verify.crop(st['stage'],3,er,1200);dr=ImageDraw.Draw(im)
 sx=np.floor((er[0]-mb[0])*1200/72);sy=np.floor((mb[3]-er[3])*1200/72)
 for rec in records:
  if rec['row']!=c['row']:continue
  for p in rec['points']:
   x=(p['page'][0]-mb[0])*1200/72-sx;y=(mb[3]-p['page'][1])*1200/72-sy
   dr.ellipse((x-2,y-2,x+2,y+2),outline='red',width=1)
 im.save(fresh(root/'review'/f'native-word-edge-row{c["row"]}-marked-1200dpi.png'))
E.close()
json.dump(records,open(fresh(root/'review'/'native-word-edge-point-coordinates.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
