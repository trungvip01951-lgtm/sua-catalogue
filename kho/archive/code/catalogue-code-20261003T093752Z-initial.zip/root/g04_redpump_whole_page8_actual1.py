"""Read saved M1: actual paths/local tick inversion/source assets. No PDF writes."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,csv,math
import numpy as np
import pymupdf as fitz
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Ref
from catfix import verify
from PIL import Image,ImageDraw

folder=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
Pfolder=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
b=json.loads((folder/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'))
local=json.loads((Pfolder/'104 NEO QH ANH XA VACH THUC CUC BO V1.json').read_text(encoding='utf8'))
keep=json.loads((Pfolder/'VACH PHU FEET VA KHOI TIEU DE GIU NGUON V1.json').read_text(encoding='utf8'))
atlas=json.loads((Pfolder/'13 NHAN THAT CUNG BO NGUON V4 KHONG CHONG GACH.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert [sha(b['source']),sha(b['input_current']),sha(b['sample'])]==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
E=Editor(b['sample'],backend='fitz');P=E.page(7)
marker=next(i for i,x in enumerate(P.ops) if x.op=='BMC' and list(map(str,x.operands))==['CfxRedpumpWholePage8M1'])
new=[(i,o,P.object_pagepath(i)) for i,o in enumerate(P.objs) if o['i0']>marker and o['op']=='S' and P.color_of(i,'stroke') is not None and max(abs(np.array(P.color_of(i,'stroke'))-np.array([134,149,152])/255))<1e-8]
assert len(new)==27,len(new)

def cubics(path):
    out=[];pos=None
    for op,pts in path:
        if op=='m':pos=np.array(pts[0],float)
        elif op=='c':
            a=np.vstack([pos,np.array(pts,float)]);out.append(a);pos=a[-1]
        else:raise AssertionError(op)
    return out
def bez(a,t):
    return (1-t)**3*a[0]+3*(1-t)**2*t*a[1]+3*(1-t)*t*t*a[2]+t**3*a[3]
def at_x(segments,x):
    eps=1e-8
    hit=[a for a in segments if a[0,0]-eps<=x<=a[-1,0]+eps]
    assert hit,(x,[(a[0,0],a[-1,0]) for a in segments])
    a=hit[0];lo=0.;hi=1.
    if abs(x-a[0,0])<eps:return a[0].copy()
    if abs(x-a[-1,0])<eps:return a[-1].copy()
    for _ in range(65):
        t=(lo+hi)/2
        if bez(a,t)[0]<x:lo=t
        else:hi=t
    return bez(a,(lo+hi)/2)
def inv_H(y):
    ticks=local['H_observed_ticks'];yy=np.array([z['page_y'] for z in ticks]);hh=np.array([z['H'] for z in ticks])
    assert yy[0]-1e-7<=y<=yy[-1]+1e-7
    return float(np.interp(y,yy,hh))
models=[];points=[];paths_export=[];capjoin=[]
for k,row in enumerate(local['records']):
    pair=new[2*k:2*k+2]
    parts=[cubics(z[2]) for z in pair]
    assert [len(z) for z in parts]==[2,5]
    segs=sum(parts,[])
    for _,o,_ in pair:
        assert np.array_equal(o['ctm'],np.eye(3))
        assert abs(o['lw']-.95)<1e-12
        assert o['stroke']==('RG',(134/255,149/255,152/255)) or max(abs(np.array(o['stroke'][1])-np.array([134,149,152])/255))<1e-9
        clip=o['clip'];assert abs(clip[0]-row['anchors'][0]['page_xy'][0])<1e-8 and abs(clip[2]-row['anchors'][-1]['page_xy'][0])<1e-8
    assert max(abs(np.array(pair[0][1]['dash'][0])-np.array([6.95,3.41])))<1e-12 and pair[0][1]['dash'][1]==0.
    assert pair[1][1]['dash'][0]==[] and pair[1][1]['dash'][1]==0.
    for a in segs:
        xy=np.array([bez(a,t) for t in np.linspace(0,1,101)])
        assert np.all(np.diff(xy[:,0])>0) and np.all(np.diff(xy[:,1])<=1e-9)
    join_error=float(np.max(abs(parts[0][-1][-1]-parts[1][0][0])))
    d0=parts[0][-1][-1]-parts[0][-1][-2];d1=parts[1][0][1]-parts[1][0][0]
    angle=abs(float(np.arctan2(d0[1],d0[0])-np.arctan2(d1[1],d1[0])))*180/np.pi
    assert join_error<1e-8 and angle<1e-6
    for a in row['anchors']:
        pt=at_x(segs,a['Q_local']['page_coord']);h=inv_H(pt[1]);error=float(h-a['H_source'])
        assert abs(error)<1e-5,(row['model'],a,error)
        points.append(dict(model=row['model'],Q_m3_h=a['Q'],H_table_m=a['H_source'],
            actual_page_x=float(pt[0]),actual_page_y=float(pt[1]),H_actual_path_m=h,error_m=error,
            technical_limit_m=max(1.,.02*a['H_source']),numeric_limit_m=1e-5,result='ĐẠT VỀ PATH SỐ',
            x_source_local_brackets=a['Q_local']['between_observed_tick_page_coords'],
            H_source_local_brackets=a['H_local']['between_observed_tick_page_coords'],
            dash_gap_does_not_remove_geometric_anchor=a['Q']<6,
            source_tick_uncertainty_pt=.24,source_ink_uncertainty_pt=.48))
    models.append(dict(model=row['model'],actual_objects=[z[0] for z in pair],actual_start=segs[0][0].tolist(),
        actual_end=segs[-1][-1].tolist(),actual_Q6_join=parts[0][-1][-1].tolist(),
        join_error_pt=join_error,tangent_angle_deg=angle,actual_clip=[list(z[1]['clip']) for z in pair],
        actual_width_pt=[z[1]['lw'] for z in pair],actual_RGB=list(pair[0][1]['stroke'][1]),
        actual_dash=[z[1]['dash'] for z in pair],Q_domain=[0,21],endpoints_geometry_exact=True,
        display_endpoint_limitation='Khung trục trái có thể che phần mực tại Q0; không kéo miền để bù khung.'))
    paths_export.append(dict(model=row['model'],parts=[dict(object_index=z[0],path=z[2],ctm=z[1]['ctm'].tolist()) for z in pair]))
assert len(points)==104
eta_actual=new[-1];es=cubics(eta_actual[2]);obs=np.array(b['eta']['source_points']);eta_errors=[]
for p in obs:
    v=at_x(es,p[0]);eta_errors.append(float(v[1]-p[1]))
assert max(abs(np.array(eta_errors)))<=.24
assert np.max(abs(es[0][0]-obs[0]))<1e-8 and np.max(abs(es[-1][-1]-obs[-1]))<1e-8
eta_read=dict(actual_object=eta_actual[0],actual_path=eta_actual[2],actual_width_pt=eta_actual[1]['lw'],
    actual_RGB=eta_actual[1]['stroke'][1],actual_clip=list(eta_actual[1]['clip']),
    source_points=551,max_difference_from_observed_source_centers_pt=max(abs(np.array(eta_errors))),
    RMS_difference_pt=float(np.sqrt(np.mean(np.array(eta_errors)**2))),source_observed_endpoints_exact=True,
    no_visible_extrapolation=True,geometry_candidate_head_under_frame_not_drawn=True,
    numeric_eta_accuracy='CHƯA THỂ: không có bảng hiệu suất.',
    original_corner_head='Không gán endpoint kỹ thuật từ màu bị khung che; chỉ 551 điểm quan sát.',
    errors_at_551_source_points_pt=eta_errors)

# Saved image and alpha bytes/placement must match the approved source atlas exactly.
R=Raster(E);ims=R.images(7);bank={z['model']:z for z in atlas['records']};letterchecks=[]
for lb in b['labels']:
    im=next(z for z in ims if z.name==lb['image_name'])
    assert np.max(abs(im.ctm-np.array(lb['image_CTM'])))<1e-8
    data,left,_=E.doc.stream_decoded(im.ref);assert not left
    assert data==bytes(len(data))
    alpha_ref=im.d['SMask'];alpha,left,d=E.doc.stream_decoded(alpha_ref);assert not left
    wanted=np.clip(np.rint(np.array(bank[lb['model']]['assembled_alpha_source_only'])*255),0,255).astype(np.uint8)
    assert alpha==wanted.tobytes() and hashlib.sha256(alpha).hexdigest()==lb['alpha_SHA256']
    letterchecks.append(dict(model=lb['model'],resource=im.name,source_alpha_exact=True,
        physical_scale=1.,ctm_exact=True,physical_ink_box=lb['physical_ink_box'],
        visual_status='CHỜ SOI ẢNH PDF150/600 VÀ KIỂM ĐỒ HỌA ĐỘC LẬP'))

EA=Editor(b['input_current'],backend='fitz');RA=Raster(EA);oldimages=[]
for pi in range(11):
    targets=R.images(pi)
    for old in RA.images(pi):
        hit=[z for z in targets if z.name==old.name and z.W==old.W and z.H==old.H and np.array_equal(z.ctm,old.ctm)]
        assert len(hit)==1,(pi,old.name);im=hit[0]
        raw=EA.doc.stream_raw(old.ref);assert raw==E.doc.stream_raw(im.ref)
        for key in ['SMask','Mask']:
            om,nm=old.d.get(key),im.d.get(key)
            if isinstance(om,Ref):assert isinstance(nm,Ref) and EA.doc.stream_raw(om)==E.doc.stream_raw(nm)
            else:assert str(om)==str(nm)
        oldimages.append(dict(page=pi+1,name=old.name,size=[old.W,old.H],raw_SHA256=hashlib.sha256(raw).hexdigest(),raw_masks_and_CTM_exact=True))
metadata={};contents=[];fonts=[];drawingstyles=[];gridactual=[]
with fitz.open(b['input_current']) as a,fitz.open(b['sample']) as z:
    links=lambda doc:[[{k:str(v) for k,v in t.items() if k!='xref'} for t in p.get_links()] for p in doc]
    metadata=dict(info=a.metadata==z.metadata,raw_XMP=a.get_xml_metadata()==z.get_xml_metadata(),bookmarks=a.get_toc()==z.get_toc(),
        links=links(a)==links(z),page_count=len(a)==len(z),mediaboxes=[list(p.mediabox) for p in a]==[list(p.mediabox) for p in z],
        cropboxes=[list(p.cropbox) for p in a]==[list(p.cropbox) for p in z],rotations=[p.rotation for p in a]==[p.rotation for p in z])
    assert all(metadata.values()),metadata
    for pi,(p,q) in enumerate(zip(a,z)):
        same=p.read_contents()==q.read_contents();assert same or pi==7
        contents.append(dict(page=pi+1,content_same=same))
        assert p.get_fonts(full=True)==q.get_fonts(full=True)==[]
        fonts.append(dict(page=pi+1,old_font_count=0,new_font_count=0,external_font=False))
    ds=z[7].get_drawings()
    nd=[r for r in ds if r.get('type')=='s' and r.get('color') is not None and max(abs(np.array(r['color'])-np.array([134,149,152])/255))<1e-6]
    assert len(nd)==27
    for r in nd:
        assert abs(r['width']-.95)<1e-6 and r['stroke_opacity']==1. and tuple(r['lineCap'])==(0,0,0) and r['lineJoin']==1
        drawingstyles.append(dict(width_pt=r['width'],RGB=list(r['color']),opacity=r['stroke_opacity'],cap=r['lineCap'],join=r['lineJoin'],dash=r['dashes'],seqno=r['seqno']))
for oi,o in enumerate(P.objs):
    if o['i0']<=marker or o['op']!='S':continue
    color=P.color_of(oi,'stroke')
    if color is not None and max(abs(np.array(color)-np.array([224,224,224])/255))<1e-9:
        gridactual.append(dict(object_index=oi,width=o['lw'],RGB=color,path=P.object_pagepath(oi),ctm=o['ctm'].tolist()))
assert len(gridactual)==2 and all(abs(z['width']-.65)<1e-10 for z in gridactual)

outside=verify.outside_pixels(b['input_current'],b['sample'],{8:b['allowed_bboxes']},dpi=200,thr=0,min_size=0,pad=0)
assert not outside,outside
protected=[]
for dpi in [150,200,600]:
    for label,box in [('Khối tiêu đề nguồn',keep['title_original_page_bbox'])]+[(f'Vạch feet nguồn {i+1}',v['source_original_ink_restore_page_bbox']) for i,v in enumerate(keep['short_feet_ticks'])]:
        # Whole original ink box; checking exact paint, no masking out black/stem ink.
        ar=np.asarray(verify.crop(b['input_current'],7,box,dpi));zr=np.asarray(verify.crop(b['sample'],7,box,dpi));assert ar.shape==zr.shape
        cnt=int(np.any(ar!=zr,axis=2).sum());protected.append(dict(name=label,dpi=dpi,changed_pixels=cnt,pixels_checked=int(ar.shape[0]*ar.shape[1]),rect=box))
        # Edge pixels at a retained clipping rectangle may straddle its boundary.
        # Keep count exact in the report; no success claim unless it is actually zero.

detail=[('DAU VA 13 NHAN',(57.0,340.,124.,509.)),('CUOI Q21 13 DUONG',(312.,329.,323.,400.)),
    ('NOI DUT LIEN Q6',(129.,340.,137.,505.)),('ETA DAU KHUAT NGUON',(57.,269.7,76.,283.)),('ETA DINH VA CUOI',(231.,301.,329.,313.))]
for name,rect in detail:
    verify.compare_sheet(b['input_current'],b['sample'],[(7,rect,name)],fresh(folder/f'{name} TRUOC SAU600.png'),dpi=600,pad=(0,0))
# Actual PDF glyph readback sheet with original-sized and enlarged views.
sheet=Image.new('RGB',(1750,13*170+35),'white');draw=ImageDraw.Draw(sheet)
for k,lb in enumerate(letterchecks):
    box=lb['physical_ink_box'];box=[box[0]-.36,box[1]-.36,box[2]+.36,box[3]+.36]
    a=verify.crop(b['sample'],7,box,600)
    sheet.paste(a,(200,35+170*k));sheet.paste(a.resize((a.width*3,a.height*3),Image.Resampling.NEAREST),(520,35+170*k))
    draw.text((10,40+170*k),lb['model'],fill=(0,0,180))
sheet.save(fresh(folder/'13 NHAN DOC LAI PDF MAU1.png'))

out=dict(sample=b['sample'],sample_SHA256=sha(b['sample']),source_SHA256=sha(b['source']),input_SHA256=sha(b['input_current']),
    numeric_models=13,numeric_anchors=104,points=points,models=models,actual_QH_paths=paths_export,
    max_numeric_H_error_m=max(abs(z['error_m']) for z in points),max_Q6_tangent_error_deg=max(z['tangent_angle_deg'] for z in models),
    styles_actual_fitz=drawingstyles,grid_actual=gridactual,eta_actual=eta_read,labels_source_alpha_CTM=letterchecks,
    metadata=metadata,original_images_masks_CTM=oldimages,fonts=fonts,other_page_contents=contents,
    outside_200dpi_threshold0_pad0=outside,protected_source_pixels=protected,
    source_font_sharpness='CHỜ ROOT/ĐỒ HỌA ĐỌC THỰC. Chữ thật nguồn JPEG150dpi; mãkhớp không tự chứng minh đủ sắc.',
    source_image_style_uncertainty_pt=.48,numeric_eta_status='CHƯA THỂ: nguồn không có bảng sốη.',
    canonical_written=False,shared_progress_written=False,trial_count_for_whole_panel_method=1,
    parent_accepted=False,graphic_accepted=False,status='MẪU1: 104 neo actualPDF đã đọc; còn nghiệm thu đồ họa độc lập, không bản giao.')
Path(fresh(folder/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(folder/'104 NEO ACTUAL PDF MAU1.csv'),'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,list(points[0]));w.writeheader();w.writerows(points)
EA.close();E.close()
assert [sha(b['source']),sha(b['input_current']),sha(b['sample'])]==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
print('ACTUAL M1 104/104 maxH',out['max_numeric_H_error_m'],'outside',outside,'protected',[(z['name'],z['dpi'],z['changed_pixels']) for z in protected],flush=True)
