"""Full-graph design plan only. No sample drawing, no catalogue/shared-ledger mutation."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
from datetime import datetime
from zoneinfo import ZoneInfo
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
folder=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
axes=json.loads((root/'17 TRUC DOC NGUON RIENG KHOA V1.json').read_text(encoding='utf8'))
ids=json.loads((root/'DINH DANH NHAN VA SEED DOC TRUC TIEP V1.json').read_text(encoding='utf8'))
cells=json.loads((root/'1931 O NGUON DINH VI VA DOI CHIEU V2.json').read_text(encoding='utf8'))
inventory=json.loads((folder/'KIEM KE NGUON RIENG VA FONT 17 BIEU DO.json').read_text(encoding='utf8'))
eta=json.loads((folder/'ETA DOC NET NGUON RIENG.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
rows=[p for p in d['rows'] if p['page']==8 and p['family']=='4SL16']
assert len(rows)==13 and all(p['Q']==[0,3,6,9,12,15,18,21] for p in rows)
assert all(p['model_locked'] for p in ids['records'] if p['page']==8)
plans=[]
for row in rows:
 cc=[p for p in cells['cells'] if p['model']==row['model']]
 assert len(cc)==8 and [p['H_source'] for p in cc]==row['H']
 plans.append(dict(model=row['model'],Q=row['Q'],H=row['H'],anchors_QH=list(map(list,zip(row['Q'],row['H']))),source_cell_page_rects=[p['page_rect'] for p in cc],source_cell_native_uv_rects=[p['native_uv_rect'] for p in cc],first_point=[row['Q'][0],row['H'][0]],last_point=[row['Q'][-1],row['H'][-1]],interpolation='PCHIP — nội suy bậc ba giữ dáng từ chính các mốc bảng; đi qua cả8neo, không rung/vượt khoảng giữa hai số.',extrapolation=False,uniform_style_id='REDPUMP_QH_ETA',physical_current_label_locked=True,source_label_rule='Đã đọc trực tiếp nhãn hiện hành cùng nét: đủ cả13mã; chữ ảnh nguồn cùng tệp, không suy theo công suất hoặc thứ hạng H.'))
badshape=[dict(model=p['model'],Q=p['Q'],H=p['H']) for p in d['rows'] if any(b>a for a,b in zip(p['H'],p['H'][1:]))]
style=dict(scope='Cùng một màu/độ dày/cách kết thúc/nối cho toàn13QH và η; áp dụng cùng bộ thông số cho196QH của17biểu đồ sau khi mẫu chung được nghiệm thu.',stroke_kind='Nét PDF toán học thật — không có chỗ ảnh mềm nối với đoạn vector đậm.',RGB_proposed=[134,149,152],color_basis='Lõi mực nguồn Redpump p8 đo PDF600dpi, cùng tệp; có thể điều chỉnh một lần theo chuẩn đồ họa ROOT trước dựng mẫu, không lấy hãng khác.',width_pt_proposed=.95,width_basis='Độ rộng tương đương đo mực nguồn riêng khoảng.96pt; không tuyên bố bút gốc chính xác vì nguồn JPEG150dpi.',line_cap='butt — kết thúc phẳng, không vượt Qđầu/Qcuối có số',line_join='round — nối bo liên tục',solid_Q_interval=[6,21],dashed_Q_interval=[0,6],dash_policy='Giữ quy ước nét đứt đầu/ liền sau của nguồn, nhưng dùng MỘT chu kỳ đứt/khoảng trống đồng nhất cho13đường. Chu kỳ đo từ nguồn riêng và ROOT khóa trước vẽ; chưa lấy thiếu mực JPEG làm khoảng đứt.',eta_dash='liền',constant_opacity=1.,zero_visible_splice=True)
method=dict(name='Dựng toàn vùng đồ thị: nền/lưới riêng +14đường PDF liên tục +nhãn nguồn sạch',trial_count=0,trial_limit=2,different_method=True,
 input_current=d['current'],input_SHA256=d['current_SHA256'],source=d['source'],source_SHA256=d['source_SHA256'],
 page=8,body_QH_bbox_candidate=[59.2,321.6,355.4,507.9],body_eta_bbox_candidate=[59.2,273.,355.4,315.4],
 bbox_status='Hộp dự kiến; trước mẫu phải khóa mép trong khung từ pixel thật/source CTM. Không mở thêm24px mặc định, không phủ trục/chữ/số bên ngoài.',
 layers=['Giữ toàn ảnh gốc/mặt nạ/CTM byte nguyên trong PDF.', 'Sau tất cả lớp cũ, phủ hai miền trong đồ thị bằng nền trắng/lưới dựng lại. Không tẩy từng đường/nối vá.', 'Vẽ13QH từ104neo số và1η từ mực quan sát nguồn, chung thông số nét.', 'Đặt lại nhãn nguồn thật và nguyên khối tiêu đề4SL16, tránh nét/lưới đi qua chữ.'],
 old_curves_policy='Các đường ảnh cũ và2nétPDF/23,/18 nằm dưới nền mới; kiểm ảnh cuối không còn bất kỳ mảnh/quầng nét cũ. Giữ stream cũ nhưng không để lớp nền/che cũ phủ đường mới.',
 grid_policy='Khóa vị trí/tần suất lưới THỰC riêng, không coi vạch m³/h là mọi cột lưới. Dựng lưới cùng màu/độ dày thống nhất, khung/số chia/đơn vị ngoài miền giữ ảnh nguồn. LướiH có thể khác bước sốH ở4SL10, không gán theo thứ hạng.',
 labels_policy='Không có font/chữ vector nhúng ở cả11trang. Mẫu đầu lấy nguyên mực/cụm chữ ảnh đúng Redpump, alpha trong suốt, bỏ nền/lưới/nét bơm quanh cụm. Font vector chỉ dùng nếu chứng minh cùng họ/cỡ/nét; không tự thay Arial. Nếu độ nét nhãn chưa đạt chuẩn mới, ghiCHƯA ĐẠT và thử cách khác trong giới hạn, không lén đổifont.',
 label_placement='Ưu tiên giữ vị trí/tỷ lệ nhãn nguồn; các nhãn gần nhau dướiH40 cần xếp sạch, đặt trong miền đầu nét đứt tương ứng, không đổi danh tính hoặc thả vào đường khác. Kiểm đủ13mã và tránh nét/lưới đè mực chữ.',
 source_only=True,canonical_mutation=False)
eta_plan=dict(source_proof=str(folder/'ETA DOC NET NGUON RIENG.json'),source_observed_points=551,source_Q_interval=eta['source_observed_Q_interval'],source_endpoints=eta['page_observed_endpoint'],numeric_eta_table_available=False,numeric_accuracy='CHƯA THỂ: không có sốηcần đối chiếu. Không thêm giá trị hiệu suất giả.',geometry='Dựng trơn trên tâm mực thật cùng nguồn; so hình dạng/đỉnh/đầu-cuối và đo khoảng lệch nguồn ≤ sai sốmực native. KhoảngQtrước0.188 chưa khóa qua vạchđen nguồn, không suyη=0 vì bảng thiếu.',endpoint_QH_rule_not_applied=True)
acceptance=[
 'Đọc actual PDF cuối:13pathQH/104mốc, mã đúng bảng; sai sốpath số học≤1e-5m, đầuQ0/21 chính xác, không kéo quá miền số; sai số fit trục nguồn ghi riêng.',
 'η đọc lại path/ảnh so551mốc mực nguồn; độ đúng kỹ thuậtη vẫnCHƯA THỂ vì thiếu bảng. Không đổi ý nghĩa/dạng nguồn.',
 'Thông số stroke (RGB,width,dash,opacity,cap,join) đúng cùng chuẩn; không có bất kỳ chỗ vá/nét kép/vệt màu cũ/khoảng gãy. Soi toàntrang và ảnh100%150dpi/300dpi/600dpi ở đầu-giữa-cuối từngđường.',
 'Đọc đủ13nhãn trực tiếp, chống chồng chữ và sai số cuối tên; cùng mựcfont/cỡ nguồn, không có nét bơm/lưới xuyên chữ.',
 '104 ô H nguồn cùng196dòng/1931ô ở các bảng toànfile giữpixel; kW/HP/m³/h và14CAN/84vị trí đã đạt giữ đúng nội dung.',
 'Ngoài đúnghai miền/nhãn đã khai báo: soPDF200dpi ngưỡng0, phải rỗng;10trangkhác/content/fonts/links/rawXMP/info/bookmarks/khổ/ảnhraw+mask+CTM giữ.',
 'ROOT kiểm số/metadata độc lập, tác nhân đồ họa kiểm hình thức độc lập; chỉ sau cảhaiĐẠT mới lưu bản giao qua catfix vớiguardSHA/đường dẫn và giữbản trước.',
 'Chỉ ROOT ghiTIEN DO.md. Mẫu1/2 và toàn hồ sơ cũ giữ nguyên, không dùng tự nghiệm thu nội bộ thay độc lập.'
]
out=dict(time=datetime.now(ZoneInfo('Asia/Ho_Chi_Minh')).isoformat(),status='PHƯƠNG ÁN CHƯA VẼ MẪU',new_user_graphic_standard='Toàn bộ đường phải đồng bộ độ đậm/độ dày/sắc nét, không trông đã vá.',old_tail_sample2='Số đo riêng đạt, CHƯA ĐẠT chuẩn đồng bộ mới. Giữ riêng; canonical b7c1… không thay.',method=method,style_proposal=style,source_axis=next(p for p in axes['records'] if p['family']=='4SL16'),QH_model_count=13,QH_anchor_count=104,eta_curve_count=1,total_graph_curves_page8=14,page8_QH_models=plans,eta_plan=eta_plan,whole_file_framework=inventory['all_17_groups'],source_data=dict(model_rows=196,H_cells=1931,unknown_H_cells=0,cell_pixels_changed=0,current_label_physical_unknown=27,unknown_names_reason='Một số nhãn5/6/8 hoặcchồngnét còn mờ; không ảnh hưởng việc dùng196mãbảng chắc để dựngđường, nhưng chưa gán danh tính đườngcũ bịmờ đểchấmĐẠT.',unexpected_increasing_H_rows=badshape),acceptance=acceptance,catalogue_written=False,sample_drawn=False,shared_progress_written=False)
Path(fresh(folder/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
md=f'''# Phương án Redpump — dựng đồng bộ toàn biểu đồ

**Chưa vẽ mẫu, chưa đổi bản giao.** Mẫu vá đuôi /25 giữ riêng: kiểm số đạt nhưng chưa đạt yêu cầu hình thức mới. Bản giao giữ SHA-256 `{d['current_SHA256']}`.

Trang 8 có **13 đường Q–H + 1 đường η (hiệu suất) = 14 đường thực**. 13 model gồm /4,/5,/6,/8,/9,/11,/12,/14,/16,/18,/20,/23,/25; bảng có **104 số H**, Q=[0,3,6,9,12,15,18,21] m³/h. Cả13nhãn hiện hành đã soi chắc; không có modelthứ14. Ứng viên xám yếu tại H75 là lưới.

| STT | File | Trang | Việc | Trước | Phương án sau | Trạng thái | Bằng chứng / nghiệm thu |
|---|---|---:|---|---|---|---|---|
| 1 | Redpump giếng SL | 8 | Đồng bộ13QH | Ảnh nén + hai đường PDF mới khác độ nét | Dựng toàn13đườngPDF liên tục từ104neo; cùng một màu/độdày/chu kỳnét | CHƯA VẼ MẪU | PHUONG AN…json, bảng sourcecells104ô |
| 2 | Cùng file | 8 | Miền đầu/cuối | Vài đường cũ vượtQ21 | Mỗi đường đúngQ0/Hbảng →Q21/Hbảng, không kéoH=0 | CHƯA VẼ MẪU | Đọc actualPDF13path/104mốc; ≤1e-5m sốhọc |
| 3 | Cùng file | 8 | Nền/lưới | Nền JPEG có màu viền/các lớp vá | Dựng một nền trongkhung + lướiTHỰC; trục/số/đơnvị giữ | CHƯA VẼ MẪU | Khóa mép trongkhung, không mở thêm24px |
| 4 | Cùng file | 8 | 13nhãn và tiêu đề | Chữ ảnh; các nhãn thấp gần nhau | Dùng đúng mựcchữ cùngtệp, alpha trongsuốt; tránhnét xuyênchữ | CHƯA VẼ MẪU | Toàn11trang không có font/textvector nhúng; không tự thayArial |
| 5 | Cùng file | 8 | η hiệu suất | Có nét, không có bảngsốη | Dựng theo551điểmmực nguồn; chungnétQH; giữhìnhdạng/đầucuối | CHƯA THỂ về sốη | ETA DOC NET NGUON RIENG.json; khôngtạo giá trịηgiả |
| 6 | Cùng file | 8 và toànfile | Kiểm sốnguồn | 196model/1931H đãkhóa | Giữđúng từngô, dùng chính sốRedpump | DỮ LIỆU NGUỒN ĐÃ KHÓA | 1931 O…V2.json:0pixel ôbảng thayđổi |
| 7 | Cùng file | 8 | Kiểm đồ họa cuối | Mẫu váđã dừng | Soi150/300/600dpi toàntrang +đầugiữa cuối14đường, đồngbộnét, sạchmọimảnhcũ | CHƯA KIỂM MẪU | Tácnhân đồhọa độc lập vàROOT nghiệmthu |
| 8 | Cùng file | 1–11 | Bảo toàn/lưu | Nguồn vàbản giao cốđịnh | Giữảnhraw/mask/CTM,metadata/link/khổ/chữ/bảng; ngoài vùng200dpi/ngưỡng0rỗng | CHƯA KIỂM MẪU | GuardSHA,catfix,bảncũgiữ; chỉROOT ghitiếnđộ |

**Cách dựng:** phủ toàn miền trong hai khung bằng nền/lưới mới, sau tấtcả lớp cũ; vẽ các đường PDF thật trên nền. Mọiđường dùng một bộthông số, khôngnối một đoạnmới vào nétJPEGcũ. Nội suy PCHIP (bậcba giữdáng) đi qua từngmốcbảng; nétđứtQ0–6 vàliềnQ6–21 dùng một kiểu thốngnhất theoquyước nguồn. MàuđềxuấtRGB=[134,149,152], độdày0,95pt, chờchuẩn đồhọaROOT khóa trướcvẽ. Đây là độrộng tươngđươngsuyra từJPEG150dpi, khôngphảibútgốc chínhxác.

**Chữ:** giữcùngfont/cỡnguồn bằng chữ/nétthật trong chínhRedpump. Ưutiên cụmnhãn đầyđủ alpha (mặt nạ mực trongsuốt), bỏnền/nétbơm quanhchữ. Nếu chấtlượng nétchữ chưa đạt chuẩn mới, ghiCHƯA ĐẠT; không lén đổi phông. Các bảng/sốkẻtrục/logohình thiết kế ngoài miền dựng giữnguyên.

**η:** 551điểmmực đãbám/soi đúng hìnhdạng, miềnQquan sát≈{eta['source_observed_Q_interval'][0]:.6f}…{eta['source_observed_Q_interval'][1]:.6f}. Phần đầugiao khungđen chưa khóa thêm, khôngngoại suyη=0. Không cóbảngηnên chỉ xácminh táidựnghìnhhọc, khônggọiđộđúngηlàĐẠT.

**Khung toànfile:** 17biểuđồ, 196model Q–H, 1931ôH. Mỗi biểuđồ dùngtrục vàsốchia củaCHÍNH Redpump; không trộnnhãn/vạchH khácbước (4SL10), không dùngPerotac. Dựnghết cácmodeltừdòngbảng chắc; 27nhãnđườngcũ đọcchưa chắc giữCHƯA THỂ vềmappingcũ, khôngchọnnhánh theoHbảng hoặc sốtầng. Mẫu trang8 làphươngphápmới, tốiđa2mẫu. Chỉsau mẫu đồngbộnét và kiểmđộc lập đạt mới áp dụng cácbiểuđồ khác rồi kiểmđủ1931neo trongPDFcuối.

Thời điểm: {out['time']}. Hồ sơchi tiết: `PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json`. Khôngghisổtiếnđộchung trongtácnhânnày.
'''
Path(fresh(folder/'PHUONG AN DUNG DONG BO 8 COT.md')).write_text(md,encoding='utf8')
assert before==[sha(d['source']),sha(d['current'])]
print('PLAN ONLY:13QH/104H +eta;17groups/196models/1931H; nonmonotonic source rows',badshape,'canonical untouched',flush=True)
