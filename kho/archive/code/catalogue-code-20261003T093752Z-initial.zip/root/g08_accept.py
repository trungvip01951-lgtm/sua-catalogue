"""Đọc lại bản thử độc lập trước khi xuất bản cuối G08."""
from catwork import start,fresh
from pathlib import Path
import json,re,hashlib
import numpy as np
import pymupdf as fitz
from PIL import Image
S,D,N=start()
from catfix import charts,verify
from catfix.vector import Editor
from catfix.textlayer import TextLayer
checks=json.loads(Path(S.report('G08/THU LAN 1/KIEM TRA.json')).read_text(encoding='utf-8'))
measures=json.loads(Path(S.report('G08/SO DO DUONG CONG.json')).read_text(encoding='utf-8'))
evidence=[]
for chd in checks:
    assert chd['check']['ok']
    name,trial=chd['file'],chd['trial']
    E=Editor(trial); TL=TextLayer(E)
    SE=Editor(S.src(name)); STL=TextLayer(SE)
    doc=fitz.open(trial); src=fitz.open(S.src(name))
    assert doc.metadata==src.metadata
    assert doc.get_toc(simple=False)==src.get_toc(simple=False)
    assert len(doc)==len(src)==8
    for p in range(8):
        assert doc[p].rect==src[p].rect
        assert doc[p].get_links()==src[p].get_links()
        assert not TL.find(p,'irrugation')
        assert len(TL.find(p,'irrigation'))==1
        assert not TL.find(p,'(KW)')
        assert len(TL.find(p,'(kW)'))==len(STL.find(p,'(kW)'))+len(STL.find(p,'(KW)'))
        assert len(TL.find(p,'2 years' if 'Aquaris' in name else '1 year'))==1
        assert not TL.find(p,'1 years')
        if p<5:
            lab=TL.find(p,'Speed');val=TL.find(p,'2900 r.p.m');assert len(lab)==len(val)==1
            head=TL.find(p,'Max head')[0]
            assert abs(lab[0].glyphs[0].o[0]-head.glyphs[0].o[0])<.001
            assert lab[0].glyphs[0].run.font.basefont==head.glyphs[0].run.font.basefont
            assert abs(lab[0].glyphs[0].run.size_page-head.glyphs[0].run.size_page)<.001
        else: assert len(TL.find(p,'1450 r.p.m'))==1
        # Mỗi nguồn và bản thử giữ nguyên byte ảnh logo/bơm/mặt nạ của chính trang đó.
        def ims(dd,pp):
            out=[]
            for im in dd[pp].get_images(full=True):
                data=dd.extract_image(im[0])['image']
                out.append(hashlib.sha256(data).hexdigest())
                if im[1]: out.append(hashlib.sha256(dd.extract_image(im[1])['image']).hexdigest())
            return sorted(out)
        assert ims(doc,p)==ims(src,p)
    assert len(TL.find(0,'50WC15-40-7.5'))==2
    assert not TL.find(0,'50WC15-80-7.5')
    assert len(TL.find(1,'1.5-5.5kW'))==1 and len(TL.find(1,'40 m',rect=(30,420,245,480)))==1
    assert len(TL.find(2,'DN80',rect=(30,450,245,505)))==1
    assert len(TL.find(2,'45',rect=(130,618,175,648)))==1
    assert len(TL.find(3,'240 m³/h',rect=(30,430,245,505)))==1
    assert len(TL.find(7,'DN300',rect=(30,450,245,510)))==1
    model=TL.find(0,'50WC15-25-3',rect=(600,100,740,130))[0]
    nums=TL.find(0,r'\d+',rect=(902,model.bbox[1]-1,1205,model.bbox[3]+1),regex=True)
    assert [int(m.text) for m in nums]==[30,29,28,25,21,16,10,4]
    model=TL.find(4,'150WC200-20-18.5',rect=(600,90,745,115))[0]
    nums=TL.find(4,r'\d+',rect=(893,model.bbox[1]-1,1205,model.bbox[3]+1),regex=True)
    assert len(nums)==13 and int(nums[4].text)==29
    hdr=TL.find(4,'Q (l/min)')[0]
    originals=STL.find(4,r'\d+',rect=(hdr.bbox[2]+3,hdr.bbox[1]-1,1205,hdr.bbox[3]+1),regex=True)
    assert len(originals)==13
    centers=[(m.bbox[0]+m.bbox[2])/2 for m in originals]
    vals=[]
    for i,xc in enumerate(centers):
        left=(centers[i-1]+xc)/2 if i else xc-11
        right=(centers[i+1]+xc)/2 if i+1<len(centers) else xc+11
        cell=TL.find(4,r'\d+',rect=(left,hdr.bbox[1]-1,right,hdr.bbox[3]+1),regex=True)
        assert len(cell)==1,(i,cell)
        vals.append(int(cell[0].text))
    assert vals==list(range(0,6001,500)),vals
    if 'redpump' in name:
        assert len(TL.find(7,'300WC950-20-95'))==len(STL.find(7,'300WC950-20-95'))+len(STL.find(7,'300WC950-20-90')) and not TL.find(7,'300WC950-20-90')
        assert len(TL.find(7,'95',rect=(785,132,800,144)))==1
        assert len(TL.find(7,'130',rect=(808,132,829,144)))==1
    m=next(m for m in measures if m['file']==name and m['page']==1)
    c=charts.Chart.from_ticks(m['x_ticks'],m['y_ticks'])
    # Bộ đọc PyMuPDF đọc đường ra, riêng với bộ ghi catfix.
    found=[d for d in doc[0].get_drawings() if d.get('color') is not None and max(abs(a-b) for a,b in zip(d['color'],m['color']))<.0001 and d['rect'].width>100 and d['rect'].height>100]
    assert len(found)==1,len(found)
    paths=[]
    for item in found[0]['items']:
        if item[0]=='c':
            conv=lambda v:(v.x,doc[0].rect.height-v.y)
            if not paths: paths.append(('m',[conv(item[1])]))
            paths.append(('c',[conv(v) for v in item[2:]]))
        else: raise AssertionError(item[0])
    points=c.to_data(charts.sample_path(paths,n=480))
    dev=[]
    for q,h in zip(m['Q'],[30,29,28,25,21,16,10,4]):
        qq=min(max(q,points[:,0].min()),points[:,0].max())
        v=c.value_at(points,qq);assert v is not None and abs(v-h)<.005
        dev.append(dict(Q=q,H_table=h,H_curve=v,diff=v-h))
    assert np.max(np.abs(points[0]-[0,30]))<.001
    assert np.max(np.abs(points[-1]-[35,4]))<.001
    evidence.append(dict(file=name,metadata_and_links_unchanged=True,embedded_images_unchanged=True,
                         readback_all_pages=True,curve64_independent=dev))
    for p in range(8):
        dest=Path(S.report(f'G08/TOAN TRANG/{Path(name).stem} - {p+1}.png'))
        if not dest.exists(): verify.page_overview(S.src(name),trial,p,fresh(dest),dpi=80)
    # Lưu ảnh riêng các trang nhiều thay đổi để nhìn rõ chữ và biểu đồ.
    for p in [0,2,4,7]:
        dest=Path(S.report(f'G08/TRANG SAU/{Path(name).stem} - {p+1}.png'))
        if not dest.exists(): verify.crop(trial,p,E.mediabox(p),130).save(fresh(dest))
    src.close();doc.close();E.close();SE.close()
Path(fresh(S.report('G08/NGHIEM THU DOC LAP.json'))).write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
print('Ba bản thử: tất cả chữ/số đọc lại đúng; phông Speed cùng mẫu, ảnh/logo/link/thông tin giữ nguyên; đường #64 đo độc lập khớp từng điểm.')
