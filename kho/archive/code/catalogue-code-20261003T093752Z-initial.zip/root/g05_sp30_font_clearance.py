"""Đo nguồn về chữ/đường, không vẽ đường sửa. Phương án vùng tránh chữ."""
from catwork import start, fresh, HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.interpolate import PchipInterpolator
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib

O='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
d=json.loads(Path(S.report(O+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'));source=d['source_path'];E=Editor(source);R=Raster(E);im=R.images(4)[0];cv=R.canvas(im);a=cv.orig.astype(float);assert im.W==1732 and im.H==1240
b=d['axis'];xt=np.array(b['xticks']);yt=np.array(b['yticks']);px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));nx=lambda x:float(cv.to_px(x,b['y0'])[0]);ny=lambda y:float(cv.to_px(b['x0'],y)[1]);py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]));qx=lambda x:float(np.interp(cv.to_page(x,0)[0],xt[:,1],xt[:,0]));rows=[]
for z in d['models']:
 nr=next(p for p in d['all_19_source_rows'] if p['model']==z['model']);qh=nr['source_measured_knots_QH'];spl=PchipInterpolator([nx(px(q)) for q,h in qh],[ny(py(h)) for q,h in qh]);bx=z['native_label_box'];x0=1134;x1=1184;y0=bx[1];y1=bx[3]
 v=a[y0:y1,x0:x1];lum=v@np.array([.299,.587,.114]);chroma=v.max(2)-v.min(2);seed=(lum<175)&(chroma<=6)
 counts=seed.sum(1);potential=np.where(counts>=2)[0]+y0
 # These corebounds need visual confirmation, no acceptance/finalmask from threshold alone.
 typetop=int(potential.min()) if len(potential) else None;typebottom=int(potential.max()) if len(potential) else None
 best=None
 if typebottom is not None:
  for q in np.arange(12.6,16.11,.05):
   x=nx(px(q));cy=float(spl(x))
   if cy-typebottom>=3.0:best=dict(Q=float(q),native_x=float(x),native_y=cy,clearance_from_last_neutral_core_px=cy-typebottom);break
 ii=np.array(Image.fromarray(v.astype(np.uint8)).resize((v.shape[1]*8,v.shape[0]*8),Image.Resampling.NEAREST));pic=Image.fromarray(ii);draw=ImageDraw.Draw(pic)
 if typebottom is not None:draw.line((0,(typebottom-y0+1)*8,pic.width,(typebottom-y0+1)*8),fill=(220,0,230),width=2)
 pic.save(fresh(S.report(O+'GIOI HAN CHU CHI KHAO SAT/'+z['model']+'.png')))
 out=dict(model=z['model'],neutral_dark_ink_row_counts=[dict(native_y=int(y0+i),count=int(c)) for i,c in enumerate(counts)],core_top=typetop,core_bottom=typebottom,potential_safe_join=best,source_rect_native=[x0,y0,x1,y1],font_fringe_must_be_visually_confirmed=True,automatic_mask_not_accepted=True)
 rows.append(out);print(z['model'],'core_y',typetop,typebottom,'earlycandidate',best,flush=True)
Path(fresh(S.report(O+'KHOANG CACH CHU NET - CHI KHAO SAT.json'))).write_text(json.dumps(dict(source_sha256=d['source_sha256'],current_sha256=d['current_sha256'],records=rows,not_final_mask=True,method='Lõi chữ tối trung tính trong dải nhãn đọc thật. Khoảng cách khảo sát với nét nguồn nội suy đơn điệu; chưa dùng làm toạ độ sửa hoặc nghiệm thu.'),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
