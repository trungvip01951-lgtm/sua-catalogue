from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image
from pathlib import Path
from scipy.interpolate import UnivariateSpline
import numpy as np,json
P='G05/KIEM TOAN TOAN BO/'
axes=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
au=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'))
E=Editor(S.dst('Perotac bơm giếng SP_compressed (bản mới).pdf'));R=Raster(E);out=[]
for fam in ['6SP30','6SP60']:
 b=next(z for z in axes if z['family']==fam);a=np.array(Image.open(S.report(P+fam+'-bieu-do-du-truc.png'))).astype(float);im=R.image_at(b['page']-1,(b['x0'],b['y0'],b['x1'],b['y1']));cv=R.canvas(im)
 print(fam,'image dict',im.d,flush=True)
 rec=[]
 for p in au['points']:
  if p['family']!=fam or p.get('H_curve_m') is None or p['Q_m3h'] not in ([18,24,30] if fam=='6SP30' else [36,42,48]):continue
  if p['row']<8:continue
  for z in p['sample_locations'][::2]:
   x=int(round(z['x_px']));y=float(z['y_px']);inds=np.arange(round(y)-12,round(y)+13);prof=a[inds,x]
   bg=np.percentile(prof,90,axis=0);deficit=np.maximum(0,bg-prof);amp=deficit.mean(1)
   baseline=np.percentile(amp,20);amp=np.maximum(0,amp-baseline);sel=amp>np.max(amp)*.5
   peak=prof[int(np.argmax(amp))]
   area=amp.sum()*72/b['dpi'];native=cv.to_px(b['rect'][0]+x*72/b['dpi'],b['rect'][3]-y*72/b['dpi']);nu,nv=map(round,native)
   rec.append(dict(model=p['curve_model'],Q=p['Q_m3h'],page_x=b['rect'][0]+x*72/b['dpi'],page_y=b['rect'][3]-y*72/b['dpi'],render_peak_rgb=peak.tolist(),fwhm_pt=float(sel.sum()*72/b['dpi']),ink_area_pt=float(area),native_rgb=cv.orig[nv,nu].tolist()))
 colors=np.array([v['render_peak_rgb'] for v in rec]);areas=np.array([v['ink_area_pt'] for v in rec]);fwhm=np.array([v['fwhm_pt'] for v in rec]);c=np.round(np.percentile(colors,20,axis=0)).astype(int);w=float(np.median(areas)/(255-c.mean()))
 item=dict(family=fam,source_render_peak_rgb=c.tolist(),width_fit_by_area_pt=w,fwhm_median_pt=float(np.median(fwhm)),samples=rec)
 out.append(item);print(fam,'renderpeak',np.percentile(colors,[10,20,50],axis=0),'areas',np.percentile(areas,[10,50,90]),'fwhm',np.percentile(fwhm,[10,50,90]),'fittedwidth',w,flush=True)
Path(fresh(S.report('G05/MAU SUA DUONG/DO MAU DO DAY ANH RENDER.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
