from catwork import start,fresh
S,D,N=start()
from catfix import verify
from pathlib import Path
import json,hashlib,re
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
src=S.src(NAME);dst=S.dst(NAME)
records=json.loads(Path(S.report('G01/nhung-cho-da-sua.json')).read_text(encoding='utf-8'))
read=json.loads(Path(S.report('G01/doc-lai-doc-lap.json')).read_text(encoding='utf-8'))
check=json.loads(Path(S.report('G01/kiem-cau-truc-va-ngoai-vung.json')).read_text(encoding='utf-8'))
assert read['ok'] and len(read['rows'])==220 and check['ok'] and not check['unexpected'] and not check['missing']
ratios=json.loads(Path(S.report('G01/tinh-ti-le-lan-2.json')).read_text(encoding='utf-8'))
tasks={t['id']:t for t in D['tasks']}
rows=[]
for task in range(1,20):
    rs=[r for r in records if r['task']==task]
    pages=sorted(set(r['page'] for r in rs))
    t=tasks[task]
    olds=list(dict.fromkeys(r['old'] for r in rs));news=list(dict.fromkeys(r['new'] for r in rs))
    if task==19:
        old='69 model có -0x trong cột TYPE';new='69 model đổi thành -x, giữ tâm ô'
    elif task==5:
        old='G2¼ ở dòng cửa xả';new='G1¼; chỉ thay số 2→1 theo lưu ý riêng'
    elif task==16:old='Motor power (Kw)';new='Motor power (kW), đủ 21 sơ đồ thực có'
    elif task==17:old='KW / Hp';new='kW / HP, đủ 42 đầu cột'
    else:old='; '.join(olds);new='; '.join(news) or 'Xoá đúng dòng 104mm'
    proof='Đọc lại '+str(len(rs))+'/'+str(len(rs))+' chỗ ĐẠT; '+', '.join(f'G01/so-sanh-trang-{p}.png' for p in pages)
    if 8<=task<=15:
        q=[q for q in ratios if q['task']==task][0]
        proof+=f"; H/tầng trung vị={q['median']:.6g}; ước tính={q['raw']:.6g}; chốt={q['final']}; G01/tinh-ti-le-lan-2.json"
    rows.append(dict(stt=task,file=NAME,page=', '.join(map(str,pages)),item=rs[0]['method']+'; '+str(len(rs))+' chỗ',old=old,new=new,result='ĐẠT',evidence=proof))
out=fresh(S.report('BAO CAO G01.md'))
verify.write_report(rows,out,title='BÁO CÁO NHÓM G01 – Aquaris SP, chữ/số/model')
with open(out,'a',encoding='utf-8') as f:
    f.write('\n\nTổng: 19 việc · ĐẠT 19 · CHƯA ĐẠT 0 · CHƯA THỂ XÁC MINH 0. Tổng cộng 220 chỗ.\n')
    f.write('\nNghiệm thu: đọc lại độc lập 220/220 đúng; ngoài vùng sửa rỗng; không thiếu vùng thay đổi; số trang 32 và khổ trang giữ nguyên. Thông tin tệp, liên kết và dấu trang đều giữ nguyên.\n')
    f.write('\nPhạm vi thực tế: #16 có 21 sơ đồ, gồm trang 15; #17 có 21 bảng × 2 đầu cột; #18 có 30 chân trang, trang 1–2 không có. Đã xác minh nội dung thực tế và áp đúng yêu cầu thống nhất đơn vị.\n')
    f.write('\n52 chỗ đã sửa trước theo tài liệu hướng dẫn không bị làm lại; mọi điểm ngoài 220 vùng được giao giữ nguyên khi so sánh ảnh. Biểu đồ và nhãn đường cong dành cho G02 chưa thay đổi.\n')
    f.write('\nKý hiệu: kW = kilôoát (đơn vị công suất); HP = mã lực; TYPE = cột tên model; Delivery casing = đầu xả; Motor shaft = trục động cơ; AISI 316ss = inox 316.\n')
    f.write('\nCần anh quyết: Không. Phát hiện thêm: Không có chỉnh sửa ngoài phạm vi; sai khác danh sách trang của #16 đã nêu ở trên.\n')
manifest=dict(source=src,output=dst,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),output_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest(),output_bytes=Path(dst).stat().st_size,tasks=19,edits=220,readback_ok=read['ok'],structure_ok=check['structure']['ok'],outside_pixels=check['unexpected'],missing=check['missing'],meta=read['meta'],report=out,evidence=S.report('So sanh G01.png'))
Path(fresh(S.report('G01/ban-giao.json'))).write_text(json.dumps(manifest,ensure_ascii=False,indent=1),encoding='utf-8')
tables=json.loads(Path(S.report('G01/bang-so-cho-G02-lan-2.json')).read_text(encoding='utf-8'))
for tab in tables.values():
    for row in tab['rows']:row['model']=re.sub(r'-(0)(\d)$',r'-\2',row['model'])
Path(fresh(S.report('G01/bang-so-da-nghiem-thu-cho-G02.json'))).write_text(json.dumps(tables,ensure_ascii=False,indent=1),encoding='utf-8')
S.progress('G01','XONG','19/19 việc ĐẠT; 220/220 chỗ đọc lại đúng, 69 model; ngoài vùng sửa rỗng; cấu trúc và thông tin tệp giữ nguyên. Báo cáo BAO CAO G01.md; dữ liệu G02 ở G01/bang-so-da-nghiem-thu-cho-G02.json.')
print(json.dumps(manifest,ensure_ascii=False,indent=1))
