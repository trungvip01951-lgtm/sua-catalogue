"""Source-only context of three ambiguous cells, native mapping and original samples."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,math
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from PIL import Image
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
outroot=root/'O CHUA DOC CHAC'
catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'))
final=json.loads(Path(S.report('G04/REDPUMP NGHIEM THU BAN CUOI NET PDF.json')).read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
current=S.result(catalog['name']);before=[sha(catalog['source']),sha(current)]
assert before==[catalog['source_SHA256'],final['final_SHA256']]
E=Editor(catalog['source'],backend='fitz');R=Raster(E)
records=[]
for page,model,q,cell,context in [
 (5,'4SL3_15',3.0,(293.8,106.5,316.5,115.3),(27,37,380,124)),
 (8,'4SL16_4',15.0,(306,86,328,97),(27,37,380,107)),
 (8,'4SL16_12',6.0,(232,142,257,154),(27,37,380,169)),
]:
 base=max(R.images(page-1),key=lambda z:z.W*z.H);cv=R.canvas(base)
 uv0=cv.to_px(cell[0],cell[1]);uv1=cv.to_px(cell[2],cell[3]);uv=[min(uv0[0],uv1[0]),min(uv0[1],uv1[1]),max(uv0[0],uv1[0]),max(uv0[1],uv1[1])]
 cuv0=cv.to_px(context[0],context[1]);cuv1=cv.to_px(context[2],context[3]);cuv=[math.floor(min(cuv0[0],cuv1[0])),math.floor(min(cuv0[1],cuv1[1])),math.ceil(max(cuv0[0],cuv1[0])),math.ceil(max(cuv0[1],cuv1[1]))]
 prefix=f'{page:02} {model} Q{q:g}'
 verify.crop(catalog['source'],page-1,context,600).save(fresh(outroot/f'{prefix} TEN DONG VA DAU COT.png'))
 native=Image.fromarray(cv.orig).crop(tuple(cuv));native.save(fresh(outroot/f'{prefix} NATIVE CONTEXT.png'))
 native.resize((native.width*4,native.height*4),Image.Resampling.NEAREST).save(fresh(outroot/f'{prefix} NATIVE CONTEXT 4X.png'))
 records.append(dict(page=page,model=model.replace('_','/'),Q=q,cell_page_rect=list(cell),cell_native_uv_bbox=uv,context_page_rect=list(context),context_native_pixel_rect=cuv,native_image_size=[base.W,base.H],image_bbox=list(base.page_bbox),image_ctm=base.ctm.tolist(),original_image_raw_SHA256=hashlib.sha256(E.doc.stream_raw(base.ref)).hexdigest(),source_only=True,status='CHƯA THỂ: chờ đọc độc lập; các hộp không ghi vào PDF'))
E.close()
assert before==[sha(catalog['source']),sha(current)]
Path(fresh(outroot/'TOA DO O VA NGUON.json')).write_text(json.dumps(dict(source=catalog['source'],source_SHA256=before[0],current_SHA256=before[1],records=records,catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
print('3 uncertain source contexts with native mappings; no PDF writes',flush=True)
