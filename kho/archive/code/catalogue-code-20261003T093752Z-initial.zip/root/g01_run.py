from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.recipes import Job
from catfix.otext import Match,OutlineText
from catfix.vector import Editor
from catfix.charts import Chart
from catfix import verify
from pathlib import Path
from decimal import Decimal,ROUND_HALF_UP
import re,json,numpy as np,hashlib,time,traceback,pickle,copy
from g01_fontbank import make_regular,at_scale

NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
SRC=S.src(NAME); DST=fresh(S.dst(NAME)); REPORT=Path(S.report('G01'))
REPORT.mkdir(parents=True,exist_ok=True)
job=S.job(NAME); T=job.T
source_hash=hashlib.sha256(Path(SRC).read_bytes()).hexdigest()
cache=REPORT/'g01-source-glyphs.pkl'
if cache.exists():
    state=pickle.loads(cache.read_bytes())
    assert state['hash']==source_hash
    T.__dict__.update(state['data'])
    print('G01: phục hồi các nét nguồn đã học, đúng mã băm',flush=True)
else:
    print('G01: học nét chữ 32 trang',flush=True)
    T.learn(list(range(32)),dpi=400)
    cache.write_bytes(pickle.dumps(dict(hash=source_hash,data={k:v for k,v in T.__dict__.items() if k!='E'})))

def union(rs):
    return (min(r[0] for r in rs),min(r[1] for r in rs),max(r[2] for r in rs),max(r[3] for r in rs))

def inside(g,r):
    return r[0] <= (g.bbox[0]+g.bbox[2])/2 <= r[2] and r[1] <= (g.bbox[1]+g.bbox[3])/2 <= r[3]

def custom(p,r,text=None):
    gl=sorted([g for g in T.page_glyphs(p) if inside(g,r)],key=lambda g:g.bbox[0])
    assert gl,(p,r)
    txt=text if text is not None else ''.join(g.char for g in gl)
    return Match(p,gl,txt,gl)

U,F=make_regular(T)
print('Đo kiểu chữ thường', {k:F[k] for k in ['rms_x','max_x','rms_y','max_y']},flush=True)

plans=[]; failures=[]; ratios=[]; tables={}

def placed(sid,c,x,base):
    g,s,_=T._source(sid,c)
    lsb,a,bot=T.char_metrics(sid,c)
    return (x+lsb,base+bot,x+lsb+s*(g.bbox[2]-g.bbox[0]),base+bot+s*(g.bbox[3]-g.bbox[1]))

def add_replace(task,m,new,align='left',method='chép nét chữ cùng kiểu, giữ vị trí'):
    V,M,proof=at_scale(U,m)
    dry=V.replace(M,new,align=align,dry_run=True,verbose=False)
    rs=[m.bbox]
    for c,x in dry['plan']:
        src=U.clusters[U.styles[0]['src'][c]]['members'][0]
        lsb,a,bot=V.char_metrics(0,c);s=proof['scale']
        rs.append((x+lsb,dry['base']+bot,x+lsb+s*(src.bbox[2]-src.bbox[0]),dry['base']+bot+s*(src.bbox[3]-src.bbox[1])))
    plans.append(dict(task=task,mode='fontreplace',m=m,M=M,V=V,new=new,align=align,rect=union(rs),method=method,dry=dry,proof=proof))

def attempt(task,fn):
    try: fn()
    except Exception as e:
        failures.append(dict(task=task,error=str(e),trace=traceback.format_exc()))
        print('CHƯA ĐẠT',task,str(e),flush=True)

def one(p,q,rect=None):
    ms=T.find(p,q,rect=rect)
    assert len(ms)==1,(p+1,q,ms)
    return ms[0]

intro=list(range(14,32,2))
for p in intro:
    def warranty(p=p):
        m=one(p,'Warranty: 1 year');g=[g for g in m.glyphs if g.char=='1'][0]
        digit=Match(p,[g],'1',m.line);dry=T.replace(digit,'2',dry_run=True,verbose=False)
        sid=m.glyphs[-1].style;start,end,base=T.run_extent([m.glyphs[-1]])
        nr=placed(sid,'s',end,base)
        rs=[m.bbox,nr]+[placed(g.style,c,x,dry['base']) for c,x in dry['plan']]
        plans.append(dict(task=1,mode='warranty',m=m,digit=digit,new='Warranty: 2 years',rect=union(rs),x=end,base=base,sid=sid,target=m.glyphs[-1].oi,method='đổi riêng 1→2 và chép thêm s cùng kiểu đậm; giữ nguyên chữ Warranty và year'))
    attempt(1,warranty)
    def comp(p=p):
        ms=T.find(p,'Components'); assert len(ms)==2
        add_replace(2,min(ms,key=lambda m:m.bbox[1]),'Delivery casing')
    attempt(2,comp)
    def shaft(p=p):
        ms=T.find(p,r'^Shaft$',regex=True)
        assert len(ms)==2,ms
        add_replace(3,min(ms,key=lambda m:m.bbox[1]),'Motor shaft')
    attempt(3,shaft)
    def steel(p=p):
        shafts=T.find(p,r'^Shaft$',regex=True);assert len(shafts)==2
        shaft6=max(shafts,key=lambda m:m.bbox[1])
        coupling=one(p,'Shaft coupling')
        casing=one(p,'external casing')
        cyref=(casing.bbox[1]+casing.bbox[3])/2
        ref=one(p,'AISI 304ss',rect=(270,cyref-5,500,cyref+5))
        # Ref is the single material at Motor external casing, between Wear ring and Top cover.
        VR,MR,pr=at_scale(U,ref);refx=VR.origin(MR.glyphs[0])[0]
        for rowm in [shaft6,coupling]:
            cy=(rowm.bbox[1]+rowm.bbox[3])/2
            old=custom(p,(ref.bbox[0]-3,cy-5,ref.bbox[0]+108,cy+5),'①AISI 316 ②AISI 304ss')
            body=[g for g in old.glyphs if g.char=='A'][0]
            VB,MB,pr=at_scale(U,Match(p,[body],'A',[body]));base=VB.origin(MB.glyphs[0])[1]
            x=refx; rs=[old.bbox]
            for c in 'AISI 316ss':
                if c!=' ':
                    src=U.clusters[U.styles[0]['src'][c]]['members'][0];lsb,a,bot=VB.char_metrics(0,c);s=pr['scale']
                    rs.append((x+lsb,base+bot,x+lsb+s*(src.bbox[2]-src.bbox[0]),base+bot+s*(src.bbox[3]-src.bbox[1])))
                x+=VB.char_metrics(0,c)[1]
            # Bao gồm cả vòng tròn của ①② là nét viền, không chỉ chữ số ở giữa.
            field=(ref.bbox[0]-1,cy-6,ref.bbox[0]+108,cy+6)
            groups=[]
            P=job.E.page(p)
            for oi,o in enumerate(P.objs):
                if o['op'] not in ('f','f*','S','s','B','B*','b','b*'):continue
                for gg in P.glyphs(oi):
                    bb=gg['bbox']
                    if field[0]<=bb[0] and bb[2]<=field[2] and field[1]<=bb[1] and bb[3]<=field[3]:groups.append((oi,gg));rs.append(bb)
            plans.append(dict(task=4,mode='material',m=old,V=VB,new='AISI 316ss',rect=union(rs),x=refx,base=base,target=body.oi,groups=groups,proof=pr,method='xoá riêng chữ và nét vòng tròn của ô; chép AISI 316ss, căn trái theo ô AISI 304ss'))
    attempt(4,steel)

for p in [2,3]:
    def outlet(p=p):
        m=one(p,'G2',rect=(400,580,565,635))
        g=m.glyphs[-1]
        add_replace(5,Match(p,[g],'2',m.line),'1',align='left',method='đổi riêng số 2 thành 1; giữ ¼ và dấu ngoặc kép')
    attempt(5,outlet)
def diffuser():
    m=one(15,'56',rect=(75,340,200,360));src4=one(23,'104',rect=(75,355,200,371)).glyphs[-1]
    g5,g6=m.glyphs
    assert abs((src4.bbox[3]-src4.bbox[1])-(g5.bbox[3]-g5.bbox[1]))<.25
    dx=float(g6.bbox[0]-g5.bbox[0])
    copies=[(src4,float(g5.bbox[0]),float(g5.bbox[1])),(g5,float(g5.bbox[0]+dx),float(g5.bbox[1]))]
    plans.append(dict(task=6,mode='copies',m=m,new='45',rect=m.bbox,copies=copies,method='chép số 4, 5 trong cùng kiểu chữ nghiêng của dòng Diffuser; giữ hai vị trí chữ số'))
attempt(6,diffuser)
for p in [23,25]:
    def erase(p=p):
        m=one(p,'104mm',rect=(50,320,230,390))
        old=Match(p,m.line,'Diffuser height: 104mm',m.line)
        plans.append(dict(task=7,mode='delete',m=old,new='',rect=old.bbox,method='xoá đúng nét chữ của dòng 104mm; giữ dòng 128mm'))
    attempt(7,erase)

def modelmatches(p):
    ms=T.find(p,r'\d+SP\d+-\d+',regex=True,ignore_spaces=True,rect=(35,40,300,590))
    if p==27:
        # Dấu nối của đúng dòng này là một nét rời; gom hình gốc, không tạo ký tự khác.
        m=custom(p,(73,188.9,121,196.5),'8SP120-05')
        assert ''.join(g.char for g in m.glyphs)=='8SP120-05', ''.join(g.char for g in m.glyphs)
        ms.append(m)
    return sorted(ms,key=lambda m:-m.bbox[1])

def number(p,r):
    m=custom(p,r)
    assert re.fullmatch(r'\d+(?:\.\d+)?',m.text),(p+1,r,m.text)
    return float(m.text),m

# Đọc độc lập toàn bộ các bảng bằng hình ký tự ở đúng ô, cả các model cuối bảng.
for p in range(2,32):
    hs=T.find(p,'KW');
    if not hs:continue
    assert len(hs)==1
    hm=one(p,'Hp'); lms=T.find(p,'Length');assert lms;lm=min(lms,key=lambda m:m.bbox[0])
    r=(hm.bbox[2]+39,hs[0].bbox[1]-1,lm.bbox[0]-5,hs[0].bbox[3]+1)
    qs=T.find(p,r'\d+(?:\.\d+)?',rect=r,regex=True)
    qs.sort(key=lambda m:m.bbox[0]); q=[float(m.text) for m in qs]
    models=modelmatches(p)
    rows=[]
    for mm in models:
        cy=(mm.bbox[1]+mm.bbox[3])/2
        nums=[]; matches=[]
        for qm in qs:
            cx=(qm.bbox[0]+qm.bbox[2])/2
            h,nm=number(p,(cx-13,cy-5,cx+13,cy+5))
            nums.append(h); matches.append(nm)
        rows.append(dict(model=mm.text,Q=q,H=nums,m=mm,cells=matches,stages=int(mm.text.split('-')[-1])))
    tables[p+1]=dict(Q=q,rows=rows)
    print('Đọc bảng',p+1,'Q=',q,'model=',len(rows),flush=True)

specs=[(8,5,'4SP2-18',2.5,66,(58,62)),(9,16,'6SP20-8',30,29,(25,26)),(10,22,'6SP60-13',40,163,(132,136)),(11,22,'6SP60-12',45,112,(114,118)),(12,26,'8SP95-08',95,93,(94,98)),(13,28,'8SP120-02',150,9,(6,7)),(14,30,'10SP125-05',140,95,(82,86)),(15,32,'10SP160-03',180,52,(52,56))]
def round_half(x):return int(Decimal(str(x)).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
for task,page,model,Q,old,bounds in specs:
    def ratio(task=task,page=page,model=model,Q=Q,old=old,bounds=bounds):
        tab=tables[page]; qi=tab['Q'].index(Q)
        target=[r for r in tab['rows'] if r['model']==model][0]
        assert target['H'][qi]==old
        others=[dict(model=r['model'],H=r['H'][qi],stages=r['stages'],per_stage=r['H'][qi]/r['stages']) for r in tab['rows'] if r is not target]
        med=float(np.median([r['per_stage'] for r in others])); raw=med*target['stages']; estimate=round_half(raw)
        test=target['H'].copy();test[qi]=estimate
        tol=max(1,estimate*.02)
        fit=Chart.fit_poly(tab['Q'],test,tol,degrees=(2,3))
        if fit is None:fit=Chart.fit_poly(tab['Q'],test,float('inf'),degrees=(3,2))
        assert fit is not None,'Không có đa thức đơn điệu bậc 2–3'
        c,degree,res=fit; predicted=float(np.polyval(c,Q))
        near=round_half(predicted)
        final=estimate if abs(estimate-predicted)<=.02*max(1,estimate) else near
        # Với hai khoảng số 25–26 và 6–7, dùng chính số nguyên gần đường khớp nhất trong khoảng.
        if final<bounds[0] or final>bounds[1]:
            final=min(range(bounds[0],bounds[1]+1),key=lambda v:abs(v-predicted))
        rec=dict(task=task,page=page,model=model,Q=Q,old=old,others=others,median=med,raw=raw,estimate=estimate,degree=degree,coefficients=c.tolist(),fit_max_residual=res,fit_at_Q=predicted,estimate_relative_residual=abs(estimate-predicted)/max(1,estimate),final=final,allowed_final=bounds)
        ratios.append(rec)
        add_replace(task,target['cells'][qi],str(final),align='center',method='trung vị H/tầng × số tầng; khớp đa thức bậc 2–3, chốt số nguyên')
        target['H'][qi]=final
        print('CHỐT',task,model,Q,old,'→',final,'trung vị',med,'ước tính',raw,'đường khớp',predicted,flush=True)
    attempt(task,ratio)

for p in range(2,32):
    for m in T.find(p,'(Kw)'):
        attempt(16,lambda m=m:add_replace(16,m,'(kW)'))
    for old,new in [('KW','kW'),('Hp','HP')]:
        for m in T.find(p,old):
            attempt(17,lambda m=m,new=new:add_replace(17,m,new,align='center'))
    def footer(p=p):
        raw=one(p,'Aquaris S.r.y',rect=(0,0,120,60));gl=[copy.copy(g) for g in raw.glyphs]
        assert len(gl)==len('AquarisS.r.l')
        for g,c in zip(gl,'AquarisS.r.l'):g.char=c
        m=Match(p,gl,'Aquaris S.r.l',gl);V,M,pr=at_scale(U,m)
        start,end,base=V.run_extent(M.glyphs)
        src=U.clusters[U.styles[0]['src']['.']]['members'][0];lsb,a,bot=V.char_metrics(0,'.');s=pr['scale']
        nr=(end+lsb,base+bot,end+lsb+s*(src.bbox[2]-src.bbox[0]),base+bot+s*(src.bbox[3]-src.bbox[1]))
        plans.append(dict(task=18,mode='append',m=m,V=V,new='Aquaris S.r.l.',rect=union([m.bbox,nr]),x=end,base=base,target=m.glyphs[0].oi,proof=pr,method='chép thêm một dấu chấm, giữ nguyên mọi nét chữ cũ'))
    attempt(18,footer)
    for m in modelmatches(p):
        if not re.fullmatch(r'\d+SP\d+-0\d',m.text):continue
        def model(m=m):
            zero=m.glyphs[-2];last=m.glyphs[-1]
            assert zero.char=='0'
            V,M,pr=at_scale(U,m);dx=V.char_metrics(0,'0')[1]
            assert 1<dx<10,dx
            new=re.sub(r'-(0)(\d)$',r'-\2',m.text)
            plans.append(dict(task=19,mode='model',m=m,new=new,rect=m.bbox,zero=zero,dx=dx,proof=pr,method='xoá đúng nét số 0; dời các nét gốc để giữ tâm ô TYPE'))
        attempt(19,model)

counts={t:sum(p['task']==t for p in plans) for t in range(1,20)}
expected={1:9,2:9,3:9,4:18,5:2,6:1,7:2,**{i:1 for i in range(8,16)},16:21,17:42,18:30,19:69}
print('SỐ CHỖ',counts,'cần',expected,flush=True)
for t,n in expected.items():
    if counts[t]!=n:failures.append(dict(task=t,error=f'Định vị {counts[t]} / cần {n}'))
def report_path(name):
    path=S.report(name)
    if Path(path).exists():
        base=Path(path);i=2
        while base.with_name(base.stem+f'-lan-{i}'+base.suffix).exists():i+=1
        path=str(base.with_name(base.stem+f'-lan-{i}'+base.suffix))
    return fresh(path)
Path(report_path('G01/tinh-ti-le.json')).write_text(json.dumps(ratios,ensure_ascii=False,indent=1),encoding='utf-8')
clean_tables={str(p):dict(Q=t['Q'],rows=[{k:v for k,v in r.items() if k not in ('m','cells')} for r in t['rows']]) for p,t in tables.items()}
Path(report_path('G01/bang-so-cho-G02.json')).write_text(json.dumps(clean_tables,ensure_ascii=False,indent=1),encoding='utf-8')
Path(report_path('G01/kiem-dinh-vi.json')).write_text(json.dumps(dict(counts=counts,expected=expected,failures=failures),ensure_ascii=False,indent=1),encoding='utf-8')
if failures:
    job.close()
    S.progress('G01','CHƯA XONG','Đã định vị và tính số; lỗi tiền kiểm ở G01/kiem-dinh-vi.json, chưa ghi catalogue')
    raise SystemExit('Tiền kiểm chưa đạt; không ghi catalogue')

records=[]
def font_insert(p,target,V,text,x,base):
    for c in text:
        lsb,a,bot=V.char_metrics(0,c)
        if c!=' ':
            src=U.clusters[U.styles[0]['src'][c]]['members'][0]
            # Tỉ lệ đã xác minh bằng nhiều chữ có sẵn của đúng đoạn đích.
            scale=V.styles[0]['metrics']['adv']['0']/F['adv']['0']
            Mx=np.array([[scale,0,0],[0,scale,0],[x+lsb-scale*src.bbox[0],base+bot-scale*src.bbox[1],1]])
            job.E.insert_path(p,target,job.E.glyph_pagepath(src.key,src.oi,src.g),Mx=Mx)
        x+=a
for plan in plans:
    m=plan['m'];p=m.key;mode=plan['mode']
    if mode=='fontreplace':
        dry=plan['dry'];keep=set(dry['keep'])
        for i,g in enumerate(m.glyphs):
            if i not in keep:job.E.delete_group(p,g.oi,g.g)
        for c,x in dry['plan']:font_insert(p,m.glyphs[0].oi,plan['V'],c,x,dry['base'])
    elif mode=='warranty':
        T.replace(plan['digit'],'2',verbose=False)
        T.insert(p,'s',plan['x'],plan['base'],plan['sid'],plan['target'])
    elif mode=='copies':
        T.delete(m)
        for src,x,y in plan['copies']:
            job.E.insert_path(p,m.glyphs[0].oi,job.E.glyph_pagepath(src.key,src.oi,src.g),dx=x-src.bbox[0],dy=y-src.bbox[1])
    elif mode=='delete':T.delete(m)
    elif mode=='material':
        for oi,gg in plan['groups']:job.E.delete_group(p,oi,gg)
        font_insert(p,plan['target'],plan['V'],plan['new'],plan['x'],plan['base'])
    elif mode=='append':font_insert(p,plan['target'],plan['V'],'.',plan['x'],plan['base'])
    elif mode=='model':
        z=plan['zero'];dx=plan['dx']
        T.delete(Match(p,[z],'0',m.line))
        prefix=Match(p,m.glyphs[:-2],m.text[:-2],m.line)
        tail=Match(p,[m.glyphs[-1]],m.text[-1],m.line)
        T.move(prefix,dx/2,0);T.move(tail,-dx/2,0)
    job._add(p,plan['rect'],f"#{plan['task']} {m.text} -> {plan['new']}",'outline')
    records.append(dict(task=plan['task'],page=p+1,old=m.text,new=plan['new'],rect=[float(v) for v in plan['rect']],mode=mode,method=plan['method']))
job.save();print('ĐÃ LƯU',DST,flush=True)
Path(fresh(S.report('G01/nhung-cho-da-sua.json'))).write_text(json.dumps(records,ensure_ascii=False,indent=1),encoding='utf-8')
check=job.check();Path(fresh(S.report('G01/kiem-cau-truc-va-ngoai-vung.json'))).write_text(json.dumps(check,ensure_ascii=False,indent=1),encoding='utf-8')
print('NGHIỆM THU VÙNG',check['ok'],check['unexpected'],check['missing'],flush=True)
job.evidence(fresh(S.report('So sanh G01.png')),dpi=250)
for page in sorted(set(r['page'] for r in records)):
    subset=[(r['page']-1,r['rect'],f"#{r['task']} {r['old']} → {r['new']}") for r in records if r['page']==page]
    verify.compare_sheet(SRC,DST,subset,fresh(S.report(f'G01/so-sanh-trang-{page}.png')),dpi=300)
job.close()
assert hashlib.sha256(Path(SRC).read_bytes()).hexdigest()==source_hash
print('G01 đã sửa 220 chỗ; chờ đọc lại độc lập và xem ảnh',flush=True)
