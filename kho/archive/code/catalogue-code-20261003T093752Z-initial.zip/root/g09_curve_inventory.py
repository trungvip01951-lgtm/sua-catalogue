from catwork import start,fresh
from pathlib import Path
import json,math,sys
import numpy as np
S,D,N=start()
from catfix.vector import Editor,overlap
from catfix import verify
from PIL import ImageDraw
fi=int(sys.argv[1]) if len(sys.argv)>1 else 0
tag=sys.argv[2] if len(sys.argv)>2 else 'LAN2'
data=json.loads(Path(S.report('G09/NGUON.json')).read_text(encoding='utf-8'))[fi]
input_path=S.report(f'G09/DUONG MAU LAN1/{data["name"]}') if len(sys.argv)>3 and sys.argv[3]=='MAU1' else S.dst(data['name'])
E=Editor(input_path)
charts=[(2,(77,559,524,720),'KTZ 50 TOP'),(2,(77,359,524,520),'KTZ 50 BOT'),(3,(65,563,510,722),'KTZ 60 TOP'),(3,(65,361,510,520),'KTZ 60 BOT'),(6,(77,528,270,720),'LH 50 LEFT'),(6,(330,528,525,720),'LH 50 RIGHT'),(6,(77,309,270,498),'LH 60 LEFT'),(6,(330,309,525,498),'LH 60 RIGHT')]
# PDF uses x/y from bottom left; pull line segments, then connect exact endpoints.
out=[]
for pi,r,label in charts:
    P=E.page(pi);segs=[]
    for oi,o in enumerate(P.objs):
        bb=o['bbox']
        if o['op']!='S' or not (r[0]<=(bb[0]+bb[2])/2<=r[2] and r[1]<=(bb[1]+bb[3])/2<=r[3]):continue
        c=P.color_of(oi,'stroke')
        if not c or not(c[0]>.75 and c[1]<.4 and c[2]<.4):continue
        pp=P.object_pagepath(oi)
        assert pp[0][0]=='m',(label,oi,pp)
        pts=[]
        for op,xx in pp:
            if op in ['m','l']:pts.extend([list(map(float,p)) for p in xx])
            elif op=='c':
                p0=np.array(pts[-1]);p1,p2,p3=map(np.array,xx)
                for t in np.linspace(0,1,61)[1:]:pts.append(((1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3).tolist())
            else:raise AssertionError((label,oi,op))
        a=pts[0];b=pts[-1];segs.append(dict(oi=oi,a=a,b=b,points=pts,path=[(op,[[float(x),float(y)] for x,y in pts]) for op,pts in pp],lw=float(o['lw']),color=c))
    # Shared rounded endpoints of these exported segments differ by at most 0.003 pt.
    groups=[]
    for s in segs:
        if groups:
            t=groups[-1][-1]
            near=min(np.linalg.norm(np.array(s[x])-np.array(t[y])) for x in ['a','b'] for y in ['a','b'])
            direction=(s['b'][0]-s['a'][0])*(t['b'][0]-t['a'][0])
            if near<.007 and direction>0:groups[-1].append(s);continue
        groups.append([s])
    components=[]
    for arr in groups:
        points=sorted([q for s in arr for q in s['points']],key=lambda a:(a[0],a[1]))
        components.append(dict(objects=[s['oi'] for s in arr],segments=arr,points=points,first=points[0],last=points[-1],num=len(arr)))
    # Join separated tails only end-to-start. Equal starts/ends of different models are not joins.
    while True:
        found=None
        for i,a in enumerate(components):
            for k,b in enumerate(components):
                if i==k:continue
                if np.linalg.norm(np.array(a['last'])-np.array(b['first']))<.007:
                    found=(i,k);break
            if found:break
        if not found:break
        i,k=found;a,b=components[i],components[k]
        arr=a['segments']+b['segments'];points=sorted([q for s in arr for q in s['points']],key=lambda a:(a[0],a[1]))
        merged=dict(objects=[s['oi'] for s in arr],segments=arr,points=points,first=points[0],last=points[-1],num=len(arr))
        components=[v for z,v in enumerate(components) if z not in (i,k)]+[merged]
    components.sort(key=lambda c:-c['first'][1])
    im=verify.crop(input_path,pi,r,220)
    draw=ImageDraw.Draw(im);scale=220/72
    for idx,c in enumerate(components):
        if c['num']<3:continue
        idxpt=min(len(c['points'])-1,int(len(c['points'])*.55));p=c['points'][idxpt]
        x=(p[0]-r[0])*scale;y=(r[3]-p[1])*scale
        draw.rectangle((x-2,y-2,x+18,y+12),fill='yellow');draw.text((x,y),str(idx),fill='black')
    path=fresh(S.report(f'G09/DO DUONG/{tag}/{data["short"]}/{label}.png'));im.save(path)
    out.append(dict(page=pi+1,rect=r,label=label,components=components,evidence=path))
    print(data['short'],label,[(i,c['num'],[round(v,3) for v in c['first']],[round(v,3) for v in c['last']]) for i,c in enumerate(components)],flush=True)
E.close()
Path(fresh(S.report(f'G09/DO DUONG/{tag}/{data["short"]}/CAC DUONG.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
