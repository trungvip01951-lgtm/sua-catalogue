from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from PIL import Image
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));im=Image.open(root/'BANG NGUON 05 4SL4.png').convert('RGB');w,h=im.size
im.crop((int(w*.455),int(h*.50),w,h)).save(fresh(root/'SOI 4SL4 CAC HANG CAO.png'))
