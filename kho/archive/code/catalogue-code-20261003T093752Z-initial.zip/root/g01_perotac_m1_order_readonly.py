from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
import fitz
import numpy as np
from PIL import Image
order=sys.argv[1];assert order in ['150-600','600-150']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads(Path(S.report('G08/ROOT PHAT HANH MOT PDF ANH V5 CA8 TRANG/ROOT KHOA MOT PDF ANH M1 V5.json')).read_text(encoding='utf8'))
job=next(j for j in lock['jobs8'] if j['page']==6)
root=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs')
pdf=root/'per_wc_continue_photo_union_v5_PDF_mau1_a1'/'Catalog cắt rác perotac (bản mới).pdf'
assert sha(pdf)=='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee'
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_PDF M1 V5 DOC LAP DU8 TRANG'))
ram=root/'per_wc_continue_photo_union_v5_RAM_a1';renders=[]
with fitz.open(str(pdf)) as doc:
 for i,(kind,dpi) in enumerate([('photo',int(v)) for v in order.split('-')]+[('photo',150),('whole',150)],1):
  pp=doc[5].get_pixmap(dpi=dpi,clip=fitz.Rect(job['allowed_photo_rect_top_fixed_before_RAM']) if kind=='photo' else None,colorspace=fitz.csRGB,alpha=False)
  fp=Path(fresh(O/f'g01_ORDER {order} #{i} p06 {kind} {dpi}dpi.png'));pp.save(str(fp));a=np.frombuffer(pp.samples,np.uint8).reshape(pp.height,pp.width,pp.n)
  def cmp(path):
   b=np.array(Image.open(path).convert('RGB'));assert a.shape==b.shape
   changed=np.any(a!=b,axis=2);n=int(changed.sum())
   if n:
    y,x=np.nonzero(changed);box=[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)]
   else:box=None
   return {'other_file':str(path),'other_SHA':sha(path),'equal':n==0,'changed_pixels_threshold0':n,'changed_bbox':box,'maximum_channel_delta':int(np.abs(a.astype(np.int16)-b.astype(np.int16)).max()),'ROI':'whole image, threshold0, no relaxation'}
  rk='photo' if kind=='photo' else 'whole_page';rp=next(ram.glob(f'*group3_p06_RAM_{rk}_{dpi}dpi.png'))
  iso=O/f'g01_ISOLATED p06 {kind} {dpi}dpi.png'
  renders.append({'sequence':i,'kind':kind,'dpi':dpi,'file':str(fp),'SHA':sha(fp),'raw_samples_SHA':hashlib.sha256(a.tobytes()).hexdigest(),'RAM':cmp(rp),'one_render_per_isolated_process':cmp(iso)})
assert sha(pdf)=='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee'
d={'mode':'new OS process, one PDF doc reused, no other PDF open, no cache reset','order':order,'PDF':str(pdf),'PDF_SHA':sha(pdf),'render_settings':'DeviceRGB, alphaFalse, dpi exact, original locked photo rectangle','actual_images':renders,'PDF_write':False,'TIENDO_write':False,'RGB_retouch':False}
jp=Path(fresh(O/f'g01_ORDER {order} DOC LAI TRANG6.json'));jp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'order':order,'JSON':str(jp),'JSON_SHA':sha(jp),'results':[{'seq':r['sequence'],'kind':r['kind'],'dpi':r['dpi'],'RAM_n':r['RAM']['changed_pixels_threshold0'],'RAM_max':r['RAM']['maximum_channel_delta'],'isolated_n':r['one_render_per_isolated_process']['changed_pixels_threshold0']} for r in renders]},ensure_ascii=False))
