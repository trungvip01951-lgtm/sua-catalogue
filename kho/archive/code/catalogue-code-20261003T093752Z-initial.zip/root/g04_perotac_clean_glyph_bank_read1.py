"""Mẫu từng ký tự nguyên nguồn và biên đẳng mực để ROOT kiểm; không ghi PDF."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from pathlib import Path
from PIL import Image
from scipy import ndimage
import numpy as np,json,hashlib,math

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/MAU KY TU DOC LAN1'))
E=Editor(src,backend='fitz');R=Raster(E)
pages={}
for pi in [5,7]:
    im=max(R.images(pi),key=lambda z:z.W*z.H);pages[pi]=(im,R.canvas(im))
assert cv2 is not None,'Dùng cv2 đã có của catfix, không cài mới'
bg=np.array([255.,255.,255.]);ink=np.array([57.,55.,57.]);zoom=32
# Các hộp tách ký tự đọc từ cột/ảnh nguồn, không ép số thành phần theo tên.
cases=[
 ('4',7,'4SA16/25',[282,204,289,213]),
 ('S',7,'4SA16/25',[289,204,296,213]),
 ('A',7,'4SA16/25',[296,204,304,213]),
 ('1',7,'4SA16/25',[304,204,308,213]),
 ('6',7,'4SA16/25',[308,204,314,213]),
 ('/',7,'4SA16/25',[314,204,318,213]),
 ('2',7,'4SA16/25',[318,204,323,213]),
 ('5',7,'4SA16/25',[323,204,329,213]),
 ('0',7,'4SA16/20',[323,275,329,284]),
 ('8',7,'4SA16/18',[323,304,329,313]),
 ('9',7,'4SA16/9',[318,433,323,442]),
 ('3',5,'4SA8/33',[1196,325,1202,334]),
 ('3A',5,'4SA8/33',[1191,325,1196,334]),
 ('S_BRIDGE',5,'4SA8/33',[1167,325,1174,334]),
 ('A_BRIDGE',5,'4SA8/33',[1174,325,1182,334]),
 ('4_BRIDGE',5,'4SA8/33',[1160,325,1167,334]),
]

def label_topology(m):
    lab,n=ndimage.label(m,np.ones((3,3)));area=np.bincount(lab.ravel())[1:]
    inv,nh=ndimage.label(~np.pad(m,1,constant_values=False),np.ones((3,3)))
    boundary=set(np.r_[inv[0,:],inv[-1,:],inv[:,0],inv[:,-1]])
    holes=[i for i in range(1,nh+1) if i not in boundary]
    ys,xs=np.where(m)
    return dict(components=int(n),component_area_native_px=(area/(zoom*zoom)).tolist(),holes=int(len(holes)),
                ink_bbox_relative_native=[float(xs.min()/zoom-1),float(ys.min()/zoom-1),float((xs.max()+1)/zoom-1),float((ys.max()+1)/zoom-1)] if len(xs) else None)

out=[];imgs=[];alpha_by={}
for ch,pi,word,b in cases:
    im,cv=pages[pi];x0,y0,x1,y1=b;raw=cv.orig[y0:y1,x0:x1];al=R.alpha_of(raw,bg,ink)
    alpha_by[ch]=al
    up=cv2.resize(np.pad(al,1),(al.shape[1]*zoom+2*zoom,al.shape[0]*zoom+2*zoom),interpolation=cv2.INTER_LINEAR)
    basename=ch.replace('/','SLASH')
    rawpath=fresh(root/(basename+' NGUON150dpi.png'));Image.fromarray(raw).save(rawpath)
    Image.fromarray(raw).resize((raw.shape[1]*16,raw.shape[0]*16),Image.Resampling.NEAREST).save(fresh(root/(basename+' NGUON PHONG16LAN.png')))
    separated=(255-al[...,None]*(bg-ink)).clip(0,255).astype(np.uint8)
    Image.fromarray(separated).save(fresh(root/(basename+' MUC THEO ALPHA NGUON150dpi.png')))
    Image.fromarray(separated).resize((raw.shape[1]*16,raw.shape[0]*16),Image.Resampling.NEAREST).save(fresh(root/(basename+' MUC THEO ALPHA PHONG16LAN.png')))
    tests=[];selected=None
    for thr in [.35,.40,.45,.50]:
        mask=up>=thr;t=label_topology(mask);contours,hierarchy=cv2.findContours(mask.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        paths=[]
        for j,c in enumerate(contours):
            xy=(c[:,0,:].astype(float)+.5)/zoom-1
            paths.append(dict(local_native_xy=xy.tolist(),parent=int(hierarchy[0,j,3]),area_native_px=float(cv2.contourArea(c)/(zoom*zoom))))
        t.update(alpha_iso_threshold=thr,ink_area_native_px=float(mask.sum()/(zoom*zoom)),
                 alpha_integral_native_px=float(al.sum()),iso_area_vs_source_alpha_percent=float((mask.sum()/(zoom*zoom)/al.sum()-1)*100),contour_paths=paths)
        tests.append(t)
        if thr==.5:selected=t
    bb=selected['ink_bbox_relative_native'];ptx=np.linalg.norm(im.ctm[:2,0])/im.W;pty=np.linalg.norm(im.ctm[:2,1])/im.H
    corners=[cv.to_page(x0,y0),cv.to_page(x1,y0),cv.to_page(x0,y1),cv.to_page(x1,y1)]
    physical=dict(source_crop_width_pt=float((x1-x0)*ptx),source_crop_height_pt=float((y1-y0)*pty),
                  source_iso50_ink_width_pt=float((bb[2]-bb[0])*ptx),source_iso50_ink_height_pt=float((bb[3]-bb[1])*pty),
                  source_iso50_top_native_y=float(y0+bb[1]),source_iso50_bottom_native_y=float(y0+bb[3]),
                  source_crop_page_bbox=[float(min(p[0] for p in corners)),float(min(p[1] for p in corners)),float(max(p[0] for p in corners)),float(max(p[1] for p in corners))],
                  step_x_pt=float(ptx),step_y_pt=float(pty),source_scale_unchanged=True)
    # Hình biên đẳng mực chỉ để soi, không chép thành phông/PDF trước duyệt.
    m=up>=.5;render=np.full((*m.shape,3),255,np.uint8);render[m]=np.array([57,55,57],np.uint8)
    Image.fromarray(render).save(fresh(root/(basename+' BIEN DANG MUC05 CHI XEM.png')))
    tile=Image.new('RGB',(640,384),'white');rawbig=Image.fromarray(raw).resize((raw.shape[1]*16,raw.shape[0]*16),Image.Resampling.NEAREST)
    sepbig=Image.fromarray(separated).resize((raw.shape[1]*16,raw.shape[0]*16),Image.Resampling.NEAREST)
    contourbig=Image.fromarray(render).resize((render.shape[1]//2,render.shape[0]//2),Image.Resampling.NEAREST)
    tile.paste(rawbig,(20,20));tile.paste(sepbig,(220,20));tile.paste(contourbig,(420,4));imgs.append(tile)
    tile.save(fresh(root/(basename+' NGUON ALPHA BIEN SO SANH.png')))
    row=dict(character=ch,source_page=pi+1,source_image='X'+str(pi),source_literal_word=word,source_native_crop=b,
             original_pixel_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),source_raw_crop=rawpath,
             alpha_from_catfix_Raster_alpha_of=True,alpha_matrix=al.tolist(),physical_dimensions=physical,iso_threshold_tests=tests,
             source_pixel_coordinates_manually_split=True,contour_for_review_only=True,
             font_match_and_shape_finally_accepted=False,PDF_written=False)
    out.append(row);print(ch,'p',pi+1,'W/H pt',round(physical['source_iso50_ink_width_pt'],4),round(physical['source_iso50_ink_height_pt'],4),'topology',[ (t['alpha_iso_threshold'],t['components'],t['holes'],round(t['iso_area_vs_source_alpha_percent'],1)) for t in tests],flush=True)
grid=Image.new('RGB',(640*4,384*4),'white')
for k,t in enumerate(imgs):grid.paste(t,((k%4)*640,(k//4)*384))
grid.save(fresh(root/'16 O KY TU NGUON ALPHA BIEN CHI XEM.png'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(current)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
Path(fresh(root/'KICH THUOC VA BIEN TUNG KY TU NGUON.json')).write_text(json.dumps(dict(source_sha256=sha(src),current_sha256=sha(current),
    source_font_program_present=False,source_is_original_JPEG150dpi=True,read_only=True,source_ink_RGB=ink.tolist(),source_bg_RGB=bg.tolist(),
    required_caption_characters=['A','S','/','0','1','2','3','4','5','6','8','9'],
    glyph_source_candidates=out,new_catalogue_font_or_PDF_written=False,common_progress_written=False,
    limits='Ảnh nguyên chỉ150dpi; biên0,5 là ứng viên soi hình chứ chưa fontPASS. Thành phần/lỗ của từng ngưỡng và trọng lượng mực được giữ để không che giới hạn. Chữ3 p6 phải có cầu nối≥2chữ với p8 trước dùng.'),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
