"""Read clean 3-phase model words from original X7 table, no catalogue write."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/CHU MODEL TU BANG3 PHA CUNG X7'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));a=cv.orig.astype(float);L=a@[.299,.587,.114]
med=np.median(L[839:1163,160:238],axis=1);runs=[]
for j in np.flatnonzero(med<160):
    if runs and j==runs[-1][1]+1:runs[-1][1]=int(j)
    else:runs.append([int(j),int(j)])
print('FULL HORIZONTAL TABLE ROWS',[[lo+839,hi+839] for lo,hi in runs],flush=True)
raw=Image.fromarray(cv.orig[839:1163,147:249]);raw.save(fresh(root/'COT3 PHA NGUON150dpi.png'));raw.resize((raw.width*6,raw.height*6),Image.Resampling.NEAREST).save(fresh(root/'COT3 PHA NGUON PHONG6LAN.png'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'DINH VI COT3 PHA VA KE NGUON CHI DOC.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_only_X7=True,
    source_native_box=[147,839,249,1163],horizontal_rule_rows_native=[[lo+839,hi+839] for lo,hi in runs],source_row_median_L=med.tolist(),
    one_phase_column_not_taken=True,source_style_bridge_pending=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close()
