from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json
root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
models=['3SS3/37','3SS4/20','3SS4/24','3SS4/28','4SA16/20','4SA16/25','4SA4/6','4SA6/6','4SA6/8','4SA8/9','4SA10/9','4SA12/5']
for v in [3,4,5]:
 j=json.loads((root/f'DO NET NGUON LAN{v}.json').read_text(encoding='utf8'))
 for g in j['graphs']:
  for c in g['curves']:
   if c['model'] in models:
    pts=c.get('points',[])
    print('VARIANT',v,c['model'],'SEED',c.get('seed',{}).get('v'),'DOMAIN',(c.get('native_path', [{}])[0].get('u'),c.get('native_path',[{}])[-1].get('u')),'POINTS',[(p['Q_m3_h'],p.get('H_curve_m'),p.get('v_native'),p.get('source_interpolation_gap_native_px'),p.get('uncertainty_H_m'),p['status']) for p in pts if p==pts[-1] or p['status']=='LỆCH CHẮC'],flush=True)
