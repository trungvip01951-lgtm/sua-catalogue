"""Few smooth source-only curves for five noisy caption glyphs, RAM research."""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import cv2
from scipy.interpolate import BSpline
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'CHU NGUON IT DOAN CONG VA NET THANG'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
old=read(base/'CHU NHO BIEN CONG TRONG BAT DINH JPEG/12 GLYPH BIEN CONG NGUON RAM CHUA NGHIEM THU.json');raw=read(base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json');by={r['key']:r for r in raw['candidates']};zoom=64
def periodic_fit(pt,n,lam=.10):
    # Fit a cyclic B-spline to the actual source boundary in arc parameter.
    closed=np.vstack([pt,pt[0]]);d=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(closed,axis=0),axis=1))];t=np.linspace(0,1,800,endpoint=False);target=np.column_stack([np.interp(t*d[-1],d,closed[:,k]) for k in [0,1]])
    knots=np.arange(-3,n+4,dtype=float)/n;BB=BSpline.design_matrix(t,knots,3).toarray();B=BB[:,:n].copy();B[:,:3]+=BB[:,n:]
    DD=np.eye(n)*-2+np.roll(np.eye(n),1,axis=1)+np.roll(np.eye(n),-1,axis=1);c=np.linalg.solve(B.T@B+lam*(DD.T@DD),B.T@target);sp=BSpline(knots,np.vstack([c,c[:3]]),3,extrapolate=False)
    samp=sp(np.linspace(0,1,4096,endpoint=False));bb=np.r_[pt.min(0),pt.max(0)];sb=np.r_[samp.min(0),samp.max(0)];fac=(bb[2:]-bb[:2])/(sb[2:]-sb[:2]);off=bb[:2]-sb[:2]*fac;c=c*fac+off;sp=BSpline(knots,np.vstack([c,c[:3]]),3,extrapolate=False);samp=sp(np.linspace(0,1,4096,endpoint=False));segments=[]
    for j in range(n):
        a=j/n;b=(j+1)/n;ds=(b-a)/3;p=sp(a);q=sp(b);segments.append([p.tolist(),(p+sp.derivative()(a)*ds).tolist(),(q-sp.derivative()(b)*ds).tolist(),q.tolist()])
    haus=max(float(cKDTree(pt).query(samp)[0].max()),float(cKDTree(samp).query(pt)[0].max()));area=abs(float(np.sum(samp[:,0]*np.roll(samp[:,1],-1)-samp[:,1]*np.roll(samp[:,0],-1))/2))
    return dict(local_native_xy=samp.tolist(),cubic_segments_local_native=segments,curve_segments=n,C2_periodic=True,source_boundary_max_symmetric_distance_native_px=haus,area_native_px=area,source_bbox_restored=True),samp
font=[];trial=[];tiles=[]
for src in old['glyphs']:
    ch=src['character']
    if ch not in ['A','S','0','6','9']:font.append(src);continue
    rec=by[src['source_key']];al=np.asarray(rec['alpha']);h,w=al.shape;up=cv2.resize(np.pad(al,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);m=up>=rec['iso_mass_match_threshold'];cc,hh=cv2.findContours(m.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);paths=[]
    for i,c in enumerate(cc):
        pt=(c[:,0,:].astype(float)+.5)/zoom-1;isouter=hh[0,i,3]<0;sourcearea=abs(cv2.contourArea(c)/zoom**2);ns=([4,6,8] if ch=='0' else [10,12,14,16] if ch=='A' else [12,14,16] if ch in ['6','9'] else [16,18,20]) if isouter else [4,6,8]
        chosen=None
        for n in ns:
            candidate,sp=periodic_fit(pt,n);delta=(candidate['area_native_px']/sourcearea-1)*100;candidate['area_vs_source_contour_percent']=delta;candidate['source_original_contour_area_native_px']=sourcearea;candidate['parent']=int(hh[0,i,3]);candidate['source_original_contour_count_vertices']=len(pt);candidate['ROOT_graphic_acceptance_pending']=True
            trial.append(dict(character=ch,parent=candidate['parent'],segments=n,source_max_symmetric_distance_native_px=candidate['source_boundary_max_symmetric_distance_native_px'],area_delta_percent=delta))
            if candidate['source_boundary_max_symmetric_distance_native_px']<=1 and abs(delta)<=10:chosen=candidate;break
        if chosen is None:chosen=candidate;chosen['cannot_accept_source_boundary_or_area']=True
        paths.append(chosen)
    # In-memory only. Keep measured counter boxes/advance/baseline unchanged.
    img=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);d=ImageDraw.Draw(img)
    for p in paths:d.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in p['local_native_xy']],fill=255 if p['parent']<0 else 0)
    mi=np.asarray(img)>0;oc,oh=cv2.findContours(mi.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE);area=float(mi.sum()/zoom**2);value=dict(**src)
    value['cleaned_contour_paths']=paths;value.update(few_curves_from_original_source_iso=True,source_curve_color_RGB=[57,55,57],few_curve_total_segments=sum(p['curve_segments'] for p in paths),
       few_curve_area_native_px=area,few_curve_vs_original_alpha_area_delta_percent=(area/rec['alpha_integral_native_px']-1)*100,
       few_curve_max_source_boundary_distance_native_px=max(p['source_boundary_max_symmetric_distance_native_px'] for p in paths),
       few_curve_outer_components=int(sum(oh[0,j,3]<0 for j in range(len(oc)))),few_curve_holes=int(sum(oh[0,j,3]>=0 for j in range(len(oc)))),
       few_curve_source_one_pixel_uncertainty=True,source_counter_contour_bbox_and_area_recorded=True,source_native_advance_and_baseline_unchanged=True,ROOT_graphic_style_acceptance_pending=True)
    font.append(value);v=Image.new('RGB',((w+2)*24,(h+2)*24),'white');vd=ImageDraw.Draw(v)
    for p in paths:vd.polygon([((x+1)*24,(y+1)*24) for x,y in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
    sourceim=Image.open(base/'DO BIEN GIU LUONG MUC NGUON'/(src['source_key']+' NGUON150dpi.png'));tile=Image.new('RGB',(800,300),'white');tile.paste(sourceim.resize((w*24,h*24),Image.Resampling.NEAREST),(10,20));tile.paste(v,(400,0));tile.save(fresh(root/(ch+' NGUON VA IT DOAN CONG.png')));tiles.append(tile)
    print(ch,'SEGS',value['few_curve_total_segments'],'AREA%',value['few_curve_vs_original_alpha_area_delta_percent'],'HMAX',value['few_curve_max_source_boundary_distance_native_px'],'TOPOLOGY',value['few_curve_outer_components'],value['few_curve_holes'],flush=True)
bank={r['character']:r for r in font};sheet=Image.new('RGB',(1750,2600),'white');dr=ImageDraw.Draw(sheet)
for i,word in enumerate(old['words']):
    x=15.;y=i*200+140.;scale=14
    for ch in word['literal']:
        g=bank[ch]
        for p in g['cleaned_contour_paths']:dr.polygon([(x+xx*scale,y+(yy-9)*scale) for xx,yy in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
        x+=g['native_advance']*scale
sheet.save(fresh(root/'13 TEN CHU NGUON IT DOAN CONG RAM CHUA NGHIEM THU.png'));atlas=Image.new('RGB',(1600,900),'white')
for i,t in enumerate(tiles):atlas.paste(t,((i%2)*800,(i//2)*300))
atlas.save(fresh(root/'5 CHU NGUON VA IT DOAN CONG DE ROOT XEM.png'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==old['source_sha256'] and sha(S.result(name))==old['current_sha256']
Path(fresh(root/'CHU IT DOAN CONG TU NGUON RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_small_caption_only=True,one_source_ink_RGB=[57,55,57],font_program_name_not_claimed=True,
    glyphs=font,words=old['words'],all_component_fit_trials=trial,source_ONE_native_pixel_uncertainty_per_ROOT=True,source_original_counter_advance_bbox_kept=True,
    no_PDF_font_or_progress_written=True,ROOT_and_graphic_acceptance_pending=True),ensure_ascii=False,indent=2),encoding='utf8')
