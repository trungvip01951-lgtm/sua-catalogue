from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.charts import Chart,sample_path
from pathlib import Path
import json,pikepdf,numpy as np
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf';src=S.src(NAME);root=Path(S.report('G07'))
out=dict(font_objects=[],curves=[],axes={})
with pikepdf.open(src) as pdf:
    for i,obj in enumerate(pdf.objects):
        if isinstance(obj,pikepdf.Dictionary) and obj.get('/Type')==pikepdf.Name.Font:
            out['font_objects'].append(dict(object=i+1,basefont=str(obj.get('/BaseFont')),subtype=str(obj.get('/Subtype')),font_descriptor=str(obj.get('/FontDescriptor'))))
E=Editor(src);P=E.page(0)
xt=[(0,976.671),(100,994.627),(200,1012.63),(300,1030.59),(400,1048.54),(500,1066.54),(600,1084.5),(700,1102.5),(800,1120.46)]
yt=[(0,523.086),(3,537.377),(6,551.711),(9,566.003),(12,580.294),(15,594.628),(18,608.919)]
ch=Chart.from_ticks(xt,yt);out['axes']=dict(x_ticks=xt,y_ticks=yt,ax=ch.ax,bx=ch.bx,ay=ch.ay,by=ch.by,residual=ch.residual)
models=[('FS75/40',183,[9.5,7,5,2]),('FS100/40',184,[10,8,6,3.5]),('FS150/40',185,[12.5,10.5,8,5.5,2]),
        ('FS200/50',186,[14,12.5,11,9,7,4]),('FS300/80',187,[15.5,14.5,13.5,12,10.5,8.5,6.5,4.5,2.2])]
for model,oi,hs in models:
    pts=ch.to_data(sample_path(P.object_pagepath(oi),n=1000));checks=[]
    for i,h in enumerate(hs):
        q=i*100;d=pts.copy();covered=d[:,0].min()<=q<=d[:,0].max()
        # Small endpoint shifts (<2 l/min) are measured from nearest endpoint,
        # recorded separately so they are never disguised as exact endpoints.
        hc=ch.value_at(d,q) if covered else float(d[0 if q<d[:,0].min() else -1,1])
        tol=max(1,h*.02);checks.append(dict(Q=q,H_table=h,H_curve=hc,diff=hc-h,tolerance=tol,within_tolerance=abs(hc-h)<=tol,covered=covered))
    out['curves'].append(dict(model=model,index=oi,points=checks,first=pts[0].tolist(),last=pts[-1].tolist(),max_abs_diff=max(abs(a['diff']) for a in checks),
                              stroke=P.objs[oi]['stroke'],lw=P.objs[oi]['lw'],path=P.object_pagepath(oi)))
    print(model,[(a['Q'],round(a['H_curve'],3),round(a['diff'],3),a['covered']) for a in checks],flush=True)
json.dump(out,open(fresh(root/'source-audit.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
