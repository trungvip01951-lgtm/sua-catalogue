"""Read exact crop perimeter and full lower axes; no glyph/PDF edits."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import numpy as np,json,hashlib
import pymupdf as fitz
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_whole_source_island_builder60 import prepare,memory_bytes,NAME
from g04_perotac_whole_pdf_tools46 import read,sha,pixel_at,page_at_pixel
from g04_perotac_whole_actual_read50 import render_document

base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'KIEM MEP9 DAO VA TOAN TRUC DUOI RAMV2 CHI DOC'
expected=read(base/'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF/CATFIX NGUON9 DAO RAM V2 DOC LAI MUC THAT VA NGOAI VUNG.json')
ed,R,cv,content,cliponly,report=prepare(S);assert hashlib.sha256(content).hexdigest()==expected['prepared_content_sha256']
blob=memory_bytes(ed,content);axis=read(report['axis_report_path']);by={w['key']:w for w in axis['words']}
sourceE=Editor(S.src(NAME),backend='fitz');sourceR=Raster(sourceE);sourcecv=sourceR.canvas(max(sourceR.images(7),key=lambda z:z.W*z.H))
records=[];tiles=[]
with fitz.open(S.src(NAME)) as source,fitz.open(S.result(NAME)) as current,fitz.open(stream=blob,filetype='pdf') as actual:
    lower_native=[80,670,790,732];lower_page=list(cv.rect(lower_native))
    for dpi in [150,600]:
        a,_=render_document(source,7,dpi,lower_page);b,_=render_document(current,7,dpi,lower_page);z,_=render_document(actual,7,dpi,lower_page)
        Image.fromarray(z).save(fresh(root/(f'TOAN TRUC DUOI ACTUAL RAM{dpi} DAO NGUON.png')))
        panel=Image.new('RGB',(a.shape[1],a.shape[0]*3+75),'white');dr=ImageDraw.Draw(panel)
        for i,(raw,label) in enumerate([(a,'ORIGINAL SOURCE'),(b,'CURRENT HANDOFF'),(z,'ACTUAL CATFIX RAM SOURCE ISLANDS')]):
            dr.text((8,i*(a.shape[0]+25)+3),label,fill='black');panel.paste(Image.fromarray(raw),(0,i*(a.shape[0]+25)+22))
        panel.save(fresh(root/(f'TOAN TRUC DUOI NGUON CURRENT ACTUAL{dpi}.png')))
    for island in report['source_literal_islands_all']:
        key=island['key'];b=island['source_page_box'];native=island['source_native_box'];a,ma=render_document(source,7,600,b);z,mz=render_document(actual,7,600,b)
        changed=np.any(a!=z,axis=2);yy,xx=np.nonzero(changed);data=[]
        for y,x in zip(yy,xx):
            native_point=np.array(cv.to_px(*page_at_pixel([x+.5,y+.5],ma)))
            rgb=a[y,x];delta=z[y,x].astype(int)-rgb.astype(int)
            data.append(dict(pixel600=[int(x),int(y)],native_center=native_point.tolist(),source_RGB=rgb.tolist(),actual_RGB=z[y,x].tolist(),difference_RGB=delta.tolist(),
                pixel_center_inside_native_island=bool(native[0]<=native_point[0]<=native[2] and native[1]<=native_point[1]<=native[3])))
        # Seed localization from original source contour BOXES only; not its
        # rejected counter shape. Include all original crop foreground edges,
        # with sensitivity levels; uncertain JPEG paper is reported separately.
        paths=by[key]['contour_paths'];glyph_boxes=[np.r_[np.asarray(p['local_native_xy']).min(0),np.asarray(p['local_native_xy']).max(0)]+np.array(native[:2]*2) for p in paths if p['parent']<0]
        support=np.zeros(changed.shape,bool);sourcealpha=np.clip((255-a.mean(2))/200.,0,1)
        for gb in glyph_boxes:
            q0=pixel_at(cv.to_page(gb[0]-.75,gb[1]-.75),ma);q1=pixel_at(cv.to_page(gb[2]+.75,gb[3]+.75),ma);lo=np.minimum(q0,q1);hi=np.maximum(q0,q1)
            YY,XX=np.indices(changed.shape);support|=((XX+.5>=lo[0])&(XX+.5<=hi[0])&(YY+.5>=lo[1])&(YY+.5<=hi[1]))
        sensitivity=[]
        for level in [.05,.10,.20,.30]:
            mask=(sourcealpha>=level)&support
            sensitivity.append(dict(source_alpha_level=level,source_foreground_pixels_in_box_support=int(mask.sum()),changed_source_foreground_pixels=int((changed&mask).sum()),
                support_is_source_boundary_localization_not_original_font_program=True))
        context_native=[native[0]-2,native[1]-2,native[2]+2,native[3]+2];ctx=list(cv.rect(context_native));s,ms=render_document(source,7,600,ctx);n,mn=render_document(actual,7,600,ctx)
        viewS=Image.fromarray(s).resize((s.shape[1]*4,s.shape[0]*4),Image.Resampling.NEAREST);viewN=Image.fromarray(n).resize(viewS.size,Image.Resampling.NEAREST)
        ds=ImageDraw.Draw(viewS);dn=ImageDraw.Draw(viewN)
        for row in data:
            pagepoint=cv.to_page(*row['native_center']);p=pixel_at(pagepoint,ms)*4
            col='red' if min(row['source_RGB'])<235 else 'cyan'
            for dr in [ds,dn]:dr.rectangle([p[0]-1,p[1]-1,p[0]+1,p[1]+1],outline=col,width=1)
        p0=pixel_at(cv.to_page(native[0],native[1]),ms)*4;p1=pixel_at(cv.to_page(native[2],native[3]),ms)*4
        rect=[*np.minimum(p0,p1),*np.maximum(p0,p1)]
        for dr in [ds,dn]:dr.rectangle(rect,outline=(30,200,30),width=2)
        tile=Image.new('RGB',(viewS.width*2+60,viewS.height+70),'white');dt=ImageDraw.Draw(tile)
        dt.text((8,8),key+' SOURCE / ACTUAL. Green=source island. Red=changed dark pixel. Cyan=changed pale pixel.',fill='black')
        tile.paste(viewS,(0,45));tile.paste(viewN,(viewS.width+40,45));tile.save(fresh(root/(key+' MEP NGOAI CUM VA DIEM DOI SOURCE ACTUAL.png')));tiles.append(tile)
        inner=[r for r in data if r['pixel_center_inside_native_island']];dark=[r for r in data if min(r['source_RGB'])<235]
        records.append(dict(key=key,source_native_box=native,changed_pixel_count=len(data),changed_native_pixel_center_inside_count=len(inner),
            changed_source_dark_count=len(dark),source_foreground_sensitivity=sensitivity,source_contour_bbox_only_uncertainty_native=.75,
            changed_native_points_and_RGB=data,all_clip_perimeter_pixels_counted_no2pixel_exclusion=True,
            source_image_raw_and_CTM_unchanged=True,whole_caption_acceptance_NOT_CLAIMED=True))
    # Source horizontal secondary axis measured from the original source at
    # 600 dpi. Include its gray center rather than blue-only colour matching.
    band=list(cv.rect([150,688,690,697]));a,ma=render_document(source,7,600,band);z,mz=render_document(actual,7,600,band)
    profile=(255-np.median(a.mean(2),axis=1))/255.;newprofile=(255-np.median(z.mean(2),axis=1))/255.
    Y=np.array([cv.to_px(*page_at_pixel([a.shape[1]/2,y+.5],ma))[1] for y in range(a.shape[0])])
    choose=profile>=.8*profile.max();source_center=float(np.average(Y[choose],weights=profile[choose]));newchoose=newprofile>=.8*newprofile.max();actualcenter=float(np.average(Y[newchoose],weights=newprofile[newchoose]))
    baseline=next(o for o in report['new_objects'] if o['key']=='M3 base');nativepath=[cv.to_px(*p) for op,ps in baseline['pagepath'] for p in ps]
    source_rule=dict(original_source600_horizontal_gray_core_native_y=source_center,source_grayscale_row_peak=float(profile.max()),
        original_source_row_profile_native_y=Y.tolist(),original_source_row_profile_contrast=profile.tolist(),actual_row_profile_contrast=newprofile.tolist(),
        actual600_horizontal_gray_core_native_y=actualcenter,actual_new_path_native_points=nativepath,
        actual_new_path_width_pt=baseline['width_pt'],actual_new_path_RGB=baseline['RGB'],source_to_actual_center_native_delta=actualcenter-source_center,
        actual_native_path_y=692.,source_JPEG_centroid_uncertainty_native_px=1.,source_exact_original_vector_y_UNKNOWN=True)
    gaps=[]
    for key in ['Q LMIN 150','Q LMIN 250','Q LMIN 350']:
        w=by[key];b=w['source_native_box'];a,ma=render_document(source,7,600,list(cv.rect([b[0]-1,b[1]-1,b[2]+1,697])));z,mz=render_document(actual,7,600,list(cv.rect([b[0]-1,b[1]-1,b[2]+1,697])))
        yy,xx=np.indices(a.shape[:2]);nativepoints=np.array([cv.to_px(*page_at_pixel([x+.5,y+.5],ma)) for y,x in zip(yy.ravel(),xx.ravel())]).reshape(yy.shape+(2,))
        # The source text cluster ends above the separate observed baseline.
        # Report the boundary sensitivity, not a guessed original font size.
        heights=[]
        for threshold in [215,230,245]:
            istext=(a.min(2)<threshold)&(nativepoints[:,:,1]<source_center-1.5)&(nativepoints[:,:,0]>=b[0])&(nativepoints[:,:,0]<=b[2])
            bottom=float(nativepoints[:,:,1][istext].max()) if istext.any() else None
            heights.append(dict(RGB_max_for_foreground=threshold,source_visible_cluster_bottom_native_y=bottom,
                gap_to_actual_new_axis_center_native_px=692.-bottom if bottom is not None else None,
                source_threshold_sensitivity_not_font_program_metric=True))
        gaps.append(dict(key=key,island_bottom_native_y=b[3],actual_new_axis_stroke_top_native_y=692.-baseline['width_pt']/2/np.linalg.norm(np.asarray(cv.to_page(1,0))-np.asarray(cv.to_page(0,0))),
            min_geometric_gap_from_island_to_new_axis_native_px=692.-baseline['width_pt']/2/np.linalg.norm(np.asarray(cv.to_page(1,0))-np.asarray(cv.to_page(0,0)))-b[3],
            source_visible_cluster_bottom_and_axis_gap_sensitivity=heights,
            actual_new_axis_unbroken_full_native_x_span=[124.4937106918239,746.],old_axis_not_preserved_in_source_literal_island=True))
panel=Image.new('RGB',(max(t.width for t in tiles),sum(t.height+15 for t in tiles)),'white');yy=0
for tile in tiles:panel.paste(tile,(0,yy));yy+=tile.height+15
panel.save(fresh(root/'9 CUM DOI CHIEU TOAN MEP KHONG LOAI2PIXEL.png'))
doc=dict(stage='READ-ONLY ALL CLIP-PERIMETER PIXELS AND FULL LOWER AXES; ROOT REVIEW PENDING',
    source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)),locked_actual_RAM_report_sha256=sha(base/'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF/CATFIX NGUON9 DAO RAM V2 DOC LAI MUC THAT VA NGOAI VUNG.json'),
    prepared_native_content_SHA256=hashlib.sha256(content).hexdigest(),source9_crop_edges=records,source_and_actual_secondary_horizontal_rule=source_rule,
    label150_250_350_gaps_and_full_new_axis=gaps,source_font_program_and_true_outline_UNKNOWN=True,all_raw_bytes_and_CTM_kept=True,
    saved_PDF_count=0,no_PDF_graphic_font_bank_or_progress_changed=True,no_caption_font_originality_inferred_from_area=True)
Path(fresh(root/'MEP9 DAO MASK NGUON VA VACH DUOI THUC RAMV2.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
for row in records:print('EDGE',row['key'],'CHANGED',row['changed_pixel_count'],'INSIDE',row['changed_native_pixel_center_inside_count'],'MASKLEVELS',[(s['source_alpha_level'],s['changed_source_foreground_pixels']) for s in row['source_foreground_sensitivity']],flush=True)
print('BASELINE OLD/NEW',source_center,actualcenter,'ACTUALPATH',nativepath,'GAPS',[g['min_geometric_gap_from_island_to_new_axis_native_px'] for g in gaps],flush=True)
sourceE.close();ed.close()
