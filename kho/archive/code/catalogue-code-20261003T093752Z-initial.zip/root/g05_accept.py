from catwork import start,fresh
from pathlib import Path
import json,hashlib,numpy as np
S,D,N=start()
from catfix import verify
from g03_xmp_helper import check_xmp
import pymupdf as fitz
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
trial=S.report('G05/HOAN THIEN/'+name)
ck=json.loads(Path(S.report('G05/HOAN THIEN/KIEM TRA.json')).read_text(encoding='utf-8'))
assert ck['check']['ok'] and not ck['check']['unexpected'] and not ck['check']['missing']
tests=[(4,(631,141.5,641,150),'67'),(7,(712,400,728,408),'1827'),
       (8,(637,89.8,653,97),'175'),(6,(363.8,32.8,376,40),'103'),(6,(377.2,32.8,387,40),'72'),
       (0,(93,87,126,94),'AISI 316 SS'),(0,(93,78,126,85),'AISI 316 SS'),
       (3,(87,87,119,94),'AISI 316 SS'),(3,(87,79,119,86),'AISI 316 SS'),
       (8,(86,87.8,154,95),'AISI 316 SS'),(8,(86,80,154,87),'AISI 316 SS'),
       (10,(81,90.5,148,97.5),'AISI 316 SS'),(10,(81,82.8,148,89.8),'AISI 316 SS'),
       (0,(78,171,116,182),'1 year'),(3,(71,213,109,223),'1 year'),
       (8,(70,211,106,221),'1 year'),(10,(65,214,101,225),'1 year')]
results=[]
for p,r,w in tests:
    ok=verify.ocr_check(trial,p,r,w)
    print(p+1,w,ok,flush=True)
    # Chữ AISI trên ảnh nguồn có thể được OCR đọc là AIS!, AIS1.
    # Không đổi số 8 thành 6; bảng ảnh trước/sau đã được xem riêng từng vùng.
    semantic_ok=ok['ok']
    if w=='AISI 316 SS':
        raw=ok.get('text','')
        import re
        normalized=re.sub(r'[^A-Z0-9]','',raw.upper().replace('!','I'))
        semantic_ok=normalized.replace('AIS1','AISI')=='AISI316SS'
    results.append(dict(page=p+1,rect=r,expected=w,ocr_result=ok,
                        ok=semantic_ok,visual_review=True))
    verify.crop(trial,p,r,350).save(fresh(S.report(f'G05/NGHIEM THU CUOI/O {len(results)}.png')))
a=fitz.open(S.src(name));b=fitz.open(trial)
assert len(a)==len(b)==12 and a.metadata==b.metadata and a.get_toc(simple=False)==b.get_toc(simple=False)
for p in range(12):
    assert a[p].rect==b[p].rect and a[p].get_links()==b[p].get_links()
    old={hashlib.sha256(a.extract_image(i[0])['image']).hexdigest() for i in a[p].get_images(full=True)}
    new={hashlib.sha256(b.extract_image(i[0])['image']).hexdigest() for i in b[p].get_images(full=True)}
    assert old<=new,(p,old-new)
    if p in [0,3,8,10]:
        # Toàn tiêu đề GIỮ NGUYÊN #50 phải trùng điểm ảnh.
        for r in [(20,480,220,535)]:
            assert np.array_equal(np.asarray(verify.crop(S.src(name),p,r,150)),np.asarray(verify.crop(trial,p,r,150)))
    if p==7:
        # #134 Bảng khối lượng 6SP46 giữ nguyên toàn vùng.
        r=(728.5,365,823,492)
        assert np.array_equal(np.asarray(verify.crop(S.src(name),p,r,150)),np.asarray(verify.crop(trial,p,r,150)))
    if p in [0,3,4,6,7,8,10]:
        verify.page_overview(S.src(name),trial,p,fresh(S.report(f'G05/NGHIEM THU CUOI/TOAN TRANG {p+1}.png')),dpi=100)
xmp=check_xmp(S.src(name),trial);assert xmp['values_equal']
a.close();b.close()
out=dict(trial=trial,ocr=results,all_ocr_ok=all(r['ok'] for r in results),
         native_original_images_preserved=True,keep_50_134_pixels_identical=True,xmp=xmp)
Path(fresh(S.report('G05/NGHIEM THU DOC LAP CUOI.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
assert out['all_ocr_ok']
print('G05 đọc lại độc lập đạt:17 vùng, nguồn ảnh/tiêu đề/trọng lượng/metadata/link/khổ giữ nguyên.')
