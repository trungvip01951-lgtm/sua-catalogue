"""Fresh eight-column M1 report. No source/canonical/shared ledger write."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
from datetime import datetime
from zoneinfo import ZoneInfo
root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
b=json.loads((root/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'))
a=json.loads((root/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json').read_text(encoding='utf8'))
ink=json.loads((root/'DO MUC ACTUAL MAU1 VA MEP VACH PHU.json').read_text(encoding='utf8'))
feet=json.loads((root/'5 VACH FEET DOI CHIEU TUNG PIXEL RGB.json').read_text(encoding='utf8'))
ram=json.loads((root/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert [sha(b['source']),sha(b['input_current']),sha(b['sample'])]==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
widths=[v['width_median_pt'] for v in ink['curve_summaries']]
edge=max(v['max_10_90_edge_pixels'] for v in ink['curve_summaries'])
spread=max(v['max_relative_width_dispersion'] for v in ink['curve_summaries'])
rows=[
 dict(stt='1',file=Path(b['sample']).name,page=8,item='Đủ13 đường Q–H qua104mốc riêng Redpump',before='Nét ảnh cũ vàhai nétPDF có độ sắc khác nhau; vàiđuôi không khớpbảng',after='Dựng13đường cùnghìnhhọc trơn, qua104tọađộ vạch thực lâncận; miềnQ0…21',result='ĐẠT PHÉP ĐỌC SỐ MẪU1; CHỜ ROOT',evidence=f'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json:13model/104mốc;maxH={a["max_numeric_H_error_m"]:.3g}m;104 NEO ACTUAL PDF MAU1.csv'),
 dict(stt='2',file=Path(b['sample']).name,page=8,item='Nét QH cùngmàu/độdày/độsắc',before='Có JPEGmềm,vectorđậm và quầngmàu',after='13đường0,95pt,RGB134/149/152,opacity1,đầu0,nối1;dash6,95/3,41ptpha0,chuyểnQ6',result='ĐẠT ĐO65TIẾT DIỆN; CHỜ ĐỒ HỌA',evidence=f'DO MUC ACTUAL MAU1 VA MEP VACH PHU.json:median{min(widths):.6f}…{max(widths):.6f}pt;phântán≤{100*spread:.3f}%;mép10–90%≤{edge:.3f}điểmảnh600dpi;0pixelquầngmàu khác trongruộtmiền'),
 dict(stt='3',file=Path(b['sample']).name,page=8,item='Đủ13nhãn/cùngký tự thật',before='Nhãnảnh cũ có phầnchồngnét/biênJPEGmờ',after='Mộtbộalphamực V4 cùngRedpump,13tên đủ,cỡvậtlý1.0,bốtríV1tránhđường/lưới',result='ĐỌC ĐỦ13TÊN; CHƯA CHỐT ĐỘSẮC',evidence='13 NHAN DOC LAI PDF MAU1.png;mọialpha/CTM đọcPDF khớpbyte;nguồn150dpi vẫngiới hạn biênxám;khôngfont ngoài'),
 dict(stt='4',file=Path(b['sample']).name,page=8,item='Nền/lưới/khung/tiêuđề',before='JPEGvàcácnétcũ trongkhung',after='Hai miền trắng,lưới0,65pt/xám224;khung0,63pt/đen;giữtiêuđề4SL16,cácvạchphụ',result='LƯỚI/TIÊUĐỀ ĐẠT PHÉP KIỂM; VẠCHPHỤ CHƯAĐẠT',evidence='Khối tiêuđề0pixelđổi150/200/600;5+6hànglưới+7cộtmỗiđồthị theo nguồn;hàngnative219khôngđưa vào lưới'),
 dict(stt='5',file=Path(b['sample']).name,page=8,item='5vạchfeet ở mépphải',before='Khung/vạchnguồn đượcgiữ',after='M1holeclip làm8/8/8/8/6điểm mựctối của khungdọc sánghơn;vạchngang bênphải khôngđổi',result='MẪU1 CHƯAĐẠT GIỮ NGUYÊN TOÀNHỘP',evidence='5 VACH FEET DOI CHIEU TUNG PIXEL RGB.json +ảnhphóngraw/đánhdấu;40/44/40/40/29pixelđổi600dpi;khônggiấu thànhĐẠT'),
 dict(stt='6',file=Path(b['sample']).name,page=8,item='Phươngán chỉnhlỗgiữ vạchphụ',before='Lỗ bằnghộpnguồn,biênclip chạmpixel khung',after='Nới riênglỗ0,48pt,bốnmép,giao miền sửa cốđịnh;chỉ thửRAMkhôngPDF2',result='15KIỂM RAM ĐẠT0PIXEL; CHƯA LƯU MẪU2',evidence='PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json:5hộp×150/200/600=0pixelđổi;0pixelmựcQHcũ tronglỗ;ảnhRAM ghi rõkhôngphảiPDFmẫu'),
 dict(stt='7',file=Path(b['sample']).name,page=8,item='Đườngη hiệu suất',before='Cóđườngnguồn551tâm mực,thiếubảngη;đầu bịkhungđen che',after='Cùngnét0,95pt;dựngchỉ551tâm quan sát,khôngnối hiểnthị2,4pt vềgóc chưa rõ',result='CHƯA THỂ VỀ SỐη; HÌNH THỨC CHỜĐỌC',evidence=f'ActualPDFη:maxlệchnguồn{a["eta_actual"]["max_difference_from_observed_source_centers_pt"]:.6f}pt≤0,24pt;đầu/cuốiquan sát giữ;600dpi cònvàigợnnhỏ,cầnđồhọa đọc;khônggánη=0'),
 dict(stt='8',file=Path(b['sample']).name,page='1–11',item='Nguồn/bảng/chữCAN/metadata/link/khổ/lưu',before='Sourcea01b…,canonicalb7c1…',after='Chỉ lưuM1riêng;ảnhraw/mask/CTM/font0/XMP/info/link/khổgiữ;10trangnội dungnguyên',result='ĐẠT BẢO TOÀN NGOÀI MIỀN; CHƯA CHỐT MẪU',evidence='Ngoài200dpi/ngưỡng0/pad0rỗng;source/currentSHAgiữ;14/14CANvàbảngngoàimiền giữnguyên;khôngcanonical/TIEN DO')]
out=dict(time=datetime.now(ZoneInfo('Asia/Ho_Chi_Minh')).isoformat(),scope='G04 Redpump only,p8 whole-panel M1',
    sample=b['sample'],sample_SHA256=b['sample_SHA256'],source_SHA256=b['source_SHA256'],input_SHA256=b['input_SHA256'],
    rows=rows,status='CHƯA CHỐT MẪU1:104neo ĐẠTđọcactual,5mépclipchưađạt,đồhọa/ROOTđangkiểm.',
    proposed_RAM_only_clip_fix=ram['records'],trial_count=1,trial_limit=2,second_sample_not_created=True,
    current_25_label='25trongnguồnvàcanonical,khônglịchsử28→25',
    canonical_written=False,shared_progress_written=False,parent_numeric_acceptance_pending=True,independent_graphic_acceptance_pending=True)
Path(fresh(root/'BAO CAO MAU1 8 COT VA GIOI HAN.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Báo cáo Redpump G04 — mẫu1 toànbiểu đồ trang8

**104/104mốc trong PDFmẫu khớpbảng. Mẫu1 chưađược chốt**: mépclip5vạchphụ làmthay mực khungdọc; độsắcchữ và đườnghiệu suất chờngười kiểm độc lập. Bản gốc vàbản giao giữ nguyên. Đây là phương pháp dựng toàn miền mới, hiện1/2mẫu; chưa cóPDFmẫu2.

| STT | File | Trang | Việc | Trước | Sau / phương án | Kết quả | Bằng chứng |
|---|---|---:|---|---|---|---|---|
'''
for r in rows:
    md+='| '+' | '.join(str(r[k]).replace('|','/') for k in ['stt','file','page','item','before','after','result','evidence'])+' |\n'
md+='''
Đã mở ảnhPDFthực toàntrang150dpi, toànbiểuđồ150/600dpi, đủ13nhãn, vùngchuyển nétđứt–liềnQ6 vàđầucuốiQ21. Số/phông/khổ/bảng ngoài miền sửa giữ nguyên. Các chấm/khungđỏ chỉ ởảnhbáocáo, khôngtrongPDF. `25` trongnguồn vàbảngiao đều là25; khôngdùngkếtluậnlịchsử28→25.

Giới hạn: chữ thật nguồn cóđộphân giải150dpi; giữ ký tự/cỡ khôngtự chứngminh độsắc đủđẹp. Đườngη(hiệusuất) khôngcóbảngsố nên độđúngkỹthuật làCHƯA THỂ. Mẫuηchỉ dùng551tâm mực quan sát, khôngngoại suyđầubịche vàkhôngđặtsốη=0. Màu/độdàynguồn suyra từJPEG, sai sốmépnguồn±0,48pt, khôngtuyên bố bútgốcchínhxác.

Đềxuấtgộp vàoM2 sau ROOT/đồhọa: nới riêng lỗgiữvạch0,48pt rồi giao đúngmiền nềnhiệncó. Thửbộnhớ bằngcatfixđãgiữtoànhộpnguồn0pixelở15phépso,khônggiữmựcQHcũ tronglỗ. PhépRAM làứngviên,kếtquảkhôngthaynghiệmthuPDFM2. KhôngvẽM2 chođếnROOTgộpđủlỗithực.

Giải nghĩa: Q làlưulượngm³/h; H làcộtápm; η làhiệusuất; RGB làhệmàuđỏ/xanhlá/xanhdương; dpi làsốđiểmảnhtrênmộtinch; pt làđơnvịđộdàivật lý1/72inch. Alpha làmặt nạ độtrong suốtcủamựcchữ; CTM làma trậnvịtrí/kíchthướcảnh; RAM làbộnhớmáy. SHA-256 làmãkiểmtratệp.

PDFmẫu: `'''+b['sample']+'''`.

Mãkiểmtra mẫu1: `'''+b['sample_SHA256']+'''`.
Nguồn: `'''+b['source_SHA256']+'''`.
Bảngiao: `'''+b['input_SHA256']+'''`.
Hồsơnguồn/đọcactual/từngpixel vàảnh đều trongcùng thưmụcMẪU1. Chỉ ROOT ghiTIEN DO.md; tácnhânnày khôngđổi sổtiếnđộ.
'''
Path(fresh(root/'BAO CAO MAU1 8 COT VA GIOI HAN.md')).write_text(md,encoding='utf8')
print('8-column M1 report saved; sample/canonical unchanged; noledger. Status:104numbers pass/5frameclip edges notpass/pending independentgraphics.',flush=True)
