"""Read Redpump sample2 saved paths, original resources and visible source glyphs."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,csv,numpy as np
import pymupdf as fitz
from catfix import charts,verify
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.cs import Ref
root=Path(S.report('G04/REDPUMP MAU NET PDF2'));build=json.loads((root/'TAO VA KIEM MAU.json').read_text(encoding='utf8'))
current=build['current'];trial=build['trial'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)==build['current_sha'] and sha(trial)==build['trial_sha']
ax,bx,ay,by=build['axis'];E=Editor(trial,backend='fitz');P=E.page(7);points=[];styles=[];endpoint=[]
for r in build['records']:
 want=np.array(r['RGB'])/255;parts=[]
 for oi,o in enumerate(P.objs):
  col=P.color_of(oi,'stroke')
  if o['op']!='S' or col is None or max(abs(np.array(col)-want))>1e-7:continue
  path=P.object_pagepath(oi);a=charts.sample_path(path,n=400)
  assert np.all(np.diff(a[:,0])>=0) and np.all(np.diff(a[:,1])<=1e-5)
  assert abs(o['lw']-r['width_pt'])<1e-8 and (o['dash'] is None or o['dash'][0]==[])
  parts.append((oi,o,a))
 assert len(parts)==len(r['native_dash_Q_intervals']),(r['model'],len(parts),len(r['native_dash_Q_intervals']))
 a=np.vstack([x[2] for x in parts]);a=a[np.argsort(a[:,0])];qs=(a[:,0]-bx)/ax;hs=(a[:,1]-by)/ay
 assert abs(qs.min())<1e-4 and abs(qs.max()-21)<1e-4,(r['model'],qs.min(),qs.max())
 for q,target in zip(r['Q'],r['H']):
  assert qs.min()-1e-4<=q<=qs.max()+1e-4
  h=float(np.interp(q,qs,hs));delta=h-target;limit=max(1,.02*target);assert abs(delta)<=limit
  in_gap=not any((lo-1e-5<=q<=hi+1e-5) for lo,hi in r['native_dash_Q_intervals'])
  points.append(dict(model=r['model'],Q=q,H_table=target,H_actual=h,error=delta,limit=limit,result='ĐẠT',dash_gap_only_interpolation=in_gap))
 for label,q,h,xy in [('start',r['Q'][0],r['H'][0],a[0]),('end',r['Q'][-1],r['H'][-1],a[-1])]:
  expected=np.array([ax*q+bx,ay*h+by]);d=float(np.max(abs(xy-expected)));assert d<1e-4
  endpoint.append(dict(model=r['model'],which=label,actual=xy.tolist(),expected=expected.tolist(),error_pt=d))
 intervals=[]
 for oi,o,a in parts:intervals.append([(float(a[0,0])-bx)/ax,(float(a[-1,0])-bx)/ax])
 assert np.max(abs(np.array(intervals)-np.array(r['native_dash_Q_intervals'])))<1e-4
 styles.append(dict(model=r['model'],real_path_objects=[x[0] for x in parts],actual_RGB=parts[0][1]['stroke'],source_measured_RGB=want.tolist(),actual_width_pt=parts[0][1]['lw'],source_equivalent_width_pt=r['width_pt'],actual_Q_intervals=intervals,source_is_raster=True))
E.close()
outside=verify.outside_pixels(current,trial,{8:[build['allowed_plot']]},dpi=200,thr=0,min_size=0,pad=.4);assert not outside
fontcheck=[]
for dpi in [150,450,600]:
 old=np.asarray(verify.crop(current,7,(131.5,326.,164.,499.),dpi)).astype(int);new=np.asarray(verify.crop(trial,7,(131.5,326.,164.,499.),dpi)).astype(int)
 font=(old.mean(axis=2)<130)&((old.max(axis=2)-old.min(axis=2))<12);fd=np.max(abs(old-new),axis=2)[font]
 fontcheck.append(dict(dpi=dpi,source_black_pixels_in_label_band=int(font.sum()),changed_pixels=int((fd>0).sum()),max_change=int(fd.max()) if len(fd) else 0))
print('LABEL BAND',fontcheck,flush=True)
metadata={};pagecontents=[];images=[];fonts=[]
with fitz.open(current) as a,fitz.open(trial) as b:
 links=lambda d:[[{k:str(v) for k,v in z.items() if k!='xref'} for z in p.get_links()] for p in d]
 metadata=dict(info=a.metadata==b.metadata,raw_XMP=a.get_xml_metadata()==b.get_xml_metadata(),bookmarks=a.get_toc()==b.get_toc(),links=links(a)==links(b),page_sizes=[tuple(p.rect) for p in a]==[tuple(p.rect) for p in b],page_count=len(a)==len(b))
 for pi,(p,q) in enumerate(zip(a,b)):
  eq=p.read_contents()==q.read_contents();pagecontents.append(dict(page=pi+1,content_same=eq));assert eq or pi==7
  srcfonts=p.get_fonts(full=True);newfonts=q.get_fonts(full=True)
  for f in srcfonts:
   candidates=[z for z in newfonts if z[1:]==f[1:]];assert candidates,(pi,f)
   fs=a.xref_stream(f[0]) or b'';assert any(fs==(b.xref_stream(z[0]) or b'') for z in candidates)
  fonts.append(dict(page=pi+1,source_font_count=len(srcfonts),source_resources_preserved=True))
Ea=Editor(current,backend='fitz');Eb=Editor(trial,backend='fitz');Ra=Raster(Ea);Rb=Raster(Eb)
for pi in range(Ea.doc.n_pages):
 ni=Rb.images(pi)
 for old in Ra.images(pi):
  candidates=[z for z in ni if z.name==old.name and z.W==old.W and z.H==old.H and np.max(abs(z.ctm-old.ctm))<1e-8];assert candidates,(pi,old)
  oldraw=Ea.doc.stream_raw(old.ref);wanted=hashlib.sha256(oldraw).hexdigest();new=next((z for z in candidates if hashlib.sha256(Eb.doc.stream_raw(z.ref)).hexdigest()==wanted),None);assert new is not None,(pi,old.name,'raw image changed')
  for key in ['SMask','Mask']:
   om=old.d.get(key);nm=new.d.get(key)
   if isinstance(om,Ref):assert isinstance(nm,Ref) and Ea.doc.stream_raw(om)==Eb.doc.stream_raw(nm),(pi,old.name,key)
   else:assert str(om)==str(nm),(pi,old.name,key)
  images.append(dict(page=pi+1,name=str(old.name),size=[old.W,old.H],raw_SHA256=wanted,source_raw_bytes_exact=True,source_masks_exact=True,source_CTM_exact=True))
Ea.close();Eb.close();assert all(metadata.values()),metadata
verify.compare_sheet(current,trial,[(7,(57,481,142,498),'Đầu 4SL16/23'),(7,(57,445,142,463),'Đầu 4SL16/18'),(7,(300,366,327,394),'Hai điểm cuối Q21'),(7,(131,440,165,497),'Nhãn nguồn giữ nguyên')],fresh(root/'CHI TIET DAU CUOI VA CHU.png'),dpi=600,pad=(.3,.3))
actual=dict(current=current,current_sha=sha(current),trial=trial,trial_sha=sha(trial),point_count=len(points),points=points,endpoints=endpoint,styles=styles,outside=outside,metadata=metadata,font_foreground=fontcheck,original_images=images,original_fonts=fonts,other_pages_original_contents=pagecontents,visual='Sample2 dash intervals now read from original grey cores; pending ROOT review of actual before/after and source ink width',accepted=False,scope='Only two Redpump curves /23,/18: sixteen tabulated anchors Q0..21; no acceptance asserted for other source curves.')
Path(fresh(root/'DOC LAI ACTUAL PDF.json')).write_text(json.dumps(actual,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(root/'16 MOC ACTUAL PDF.csv'),'w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,list(points[0]));w.writeheader();w.writerows(points)
print('REDPUMP actual16',len(points),'maxH',max(abs(p['error']) for p in points),'maxendpointpt',max(v['error_pt'] for v in endpoint),'all original image bytes/masks/CTM and fonts preserved',flush=True)
