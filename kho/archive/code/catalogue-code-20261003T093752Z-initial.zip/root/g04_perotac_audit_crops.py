from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from g04_perotac_audit_data import DATA
from pathlib import Path
import hashlib,json

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name);root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
E=Editor(src);R=Raster(E);items=[]
for rec in DATA:
 pi=rec['page']-1;im=max(R.images(pi),key=lambda x:x.W*x.H);cv=R.canvas(im);plot=rec['plot_native_box'];table=rec['table_native_box'];family=rec['family'].replace('.','_')
 tr=cv.rect((table[0]-3,table[1]-4,table[2]+3,table[3]+4));pr=cv.rect((plot[0]-27,plot[1]-24,plot[2]+27,plot[3]+156))
 verify.crop(src,pi,tr,400).save(fresh(root/f'BANG P{pi+1:02d} {family}.png'))
 verify.crop(src,pi,pr,400).save(fresh(root/f'DO THI P{pi+1:02d} {family}.png'))
 items.append(dict(**rec,table_page_rect=tr,plot_page_rect=cv.rect(plot),full_plot_axes_page_rect=pr,image_source_name=str(im.name),source_dpi=float(im.dpi),table_point_count=len(rec['rows'])*len(rec['Q_m3_h'])))
out=dict(source=src,source_sha256=sha(src),destination=dst,destination_sha256=sha(dst),read_only=True,pdf_written=False,graphs=items,graph_count=len(items),curves=sum(len(x['rows']) for x in items),table_points=sum(x['table_point_count'] for x in items),excluded_accepted_models=['4SA16/23','4SA16/18'],excluded_accepted_points=16)
Path(fresh(root/'BANG QH DOC TU NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
print('SOURCE TABLES',len(items),'models',out['curves'],'points',out['table_points'],'exclude accepted16. No PDF write.',flush=True)
