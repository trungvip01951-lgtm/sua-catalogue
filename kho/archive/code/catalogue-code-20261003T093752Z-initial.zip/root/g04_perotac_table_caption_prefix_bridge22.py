"""Compare complete 4SA prefixes with one common transform, same original X7."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.ndimage import map_coordinates,gaussian_filter
from scipy.optimize import differential_evolution,minimize
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/CAU NOI NGUYEN CUM4SA BANG VA NHAN'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));bg=np.array([255.,255.,255.]);ink=np.array([57.,55.,57.])
capbox=[281,203,305,214];tabbox=[165,1146,190,1157];capraw=cv.orig[capbox[1]:capbox[3],capbox[0]:capbox[2]];tabraw=cv.orig[tabbox[1]:tabbox[3],tabbox[0]:tabbox[2]]
ca=R.alpha_of(capraw,bg,ink);ta=R.alpha_of(tabraw,bg,ink);sub=16;h,w=ca.shape;yy,xx=np.mgrid[:h*sub,:w*sub];cx=(xx+.5)/sub;cy=(yy+.5)/sub
def predict(z):
    sx,sy,dx,dy,sigma=z;tx=(cx-dx)/sx;ty=(cy-dy)/sy;up=map_coordinates(ta,[ty-.5,tx-.5],order=1,mode='constant',cval=0,prefilter=False);aa=up.reshape(h,sub,w,sub).mean((1,3));return gaussian_filter(aa,sigma,mode='constant'),aa
def objective(z):return float(np.mean((predict(z)[0]-ca)**2))
bounds=[(.78,1.05),(.74,1.03),(-1.5,2),(-1,2),(0,.5)]
opt=differential_evolution(objective,bounds,seed=4022,popsize=9,maxiter=55,tol=1e-7,polish=False);fine=minimize(objective,opt.x,bounds=bounds,method='Powell',options={'maxiter':120,'xtol':1e-6,'ftol':1e-9});z=fine.x;pred,aa=predict(z)
out=[]
for ch,(x0,x1),(t0,t1) in zip('4SA',[(282,289),(289,296),(296,304)],[(166,173),(173,180),(180,189)]):
    source=ca[:,x0-capbox[0]:x1-capbox[0]];pp=pred[:,x0-capbox[0]:x1-capbox[0]];pa=aa[:,x0-capbox[0]:x1-capbox[0]];sel=(source>.2)|(pp>.2);sm=source>.45;pm=pp>.45
    out.append(dict(character=ch,caption_native_x_range=[x0,x1],source_table_native_x_range=[t0,t1],same_fixed_common_transform=z.tolist(),
        no_per_character_x_placement_or_scale=True,source_caption_alpha=source.tolist(),table_predicted_caption_alpha=pp.tolist(),
        alpha_RMSE=float(np.sqrt(np.mean((pp-source)**2))),alpha_MAE=float(np.mean(abs(pp-source))),signal_correlation=float(np.corrcoef(source[sel],pp[sel])[0,1]),IoU45=float((sm&pm).sum()/(sm|pm).sum()),
        source_alpha_mass=float(source.sum()),predicted_table_mass=float(pa.sum()),mass_delta_percent=float((pa.sum()/source.sum()-1)*100)))
mass=float((aa.sum()/ca.sum()-1)*100);selection=(ca>.2)|(pred>.2)
sheet=Image.new('RGB',(1700,430),'white');sheet.paste(Image.fromarray(capraw).resize((capraw.shape[1]*20,capraw.shape[0]*20),Image.Resampling.NEAREST),(10,20));sheet.paste(Image.fromarray((255-pred[:,:,None]*(bg-ink)).clip(0,255).astype(np.uint8)).resize((w*20,h*20),Image.Resampling.NEAREST),(580,20));sheet.paste(Image.fromarray(tabraw).resize((tabraw.shape[1]*20,tabraw.shape[0]*20),Image.Resampling.NEAREST),(1160,20));sheet.save(fresh(root/'NGUYEN CUM4SA NHAN DOC LAI BANG VA NGUON BANG.png'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
doc=dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_only_original_Perotac_X7=True,
        caption_native_box=capbox,table_native_box=tabbox,caption_literal='4SA',table_literal='4SA',table_column='3 pha,380–415V',
        source_caption_alpha=ca.tolist(),source_table_alpha=ta.tolist(),one_common_scale_translate_and_JPEG_comparison_only=z.tolist(),
        no_shear_rotation_or_character_specific_warp=True,source_full_prefix_alpha_MSE=objective(z),source_full_prefix_signal_correlation=float(np.corrcoef(ca[selection],pred[selection])[0,1]),
        source_prefix_mass_delta_percent=mass,results=out,source_edge_uncertainty_native_px=.5,source_kerning_not_changed_for_bridge=True,
        font_family_program_unknown=True,whole_table_word_use_not_accepted_before_ROOT_review=True,PDF_font_or_progress_written=False)
Path(fresh(root/'CAU NOI3 CHU NGUYEN CUM BANG VA NHAN CHI DOC.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8');E.close()
print('COMMON FULL PREFIX TRANSFORM',z.tolist(),'MSE/CORR/MASS',objective(z),doc['source_full_prefix_signal_correlation'],mass,flush=True)
for r in out:print(r['character'],'RMSE/CORR/IOU/MASS',r['alpha_RMSE'],r['signal_correlation'],r['IoU45'],r['mass_delta_percent'],flush=True)
