"""Read completed actual RAM evidence and source references, no PDF save."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from g04_perotac_whole_pdf_tools46 import read,sha
import json
base=Path(S.report('G04/PHUONG AN DONG BOAN BIEU DO P08')).parent/'PHUONG AN DONG BO TOAN BIEU DO P08'
root=base/'RAM CATFIX NGUON9 DAO V2 CHUA LUU PDF'
report=read(root/'CATFIX NGUON9 DAO RAM V2 DOC LAI MUC THAT VA NGOAI VUNG.json')
files=['CATFIX NGUON9 DAO RAM V2 DOC LAI MUC THAT VA NGOAI VUNG.json',
       'PEROTAC P08 CATFIX TOAN TRANG150 NGUON9 DAO CHUA NGHIEM THU.png',
       'PEROTAC P08 CATFIX THAT600 NGUON9 DAO CHUA NGHIEM THU.png',
       '9 CUM CHU NGUYEN NGUON VA ACTUAL CATFIX600.png',
       'LENH CATFIX TRANG08 NGUON9 DAO KHONG CHE TRANG.txt']
manifest=dict(stage='ACTUAL CATFIX IN-MEMORY PDF; NO FILE SAVE; GRAPHIC REVIEW PENDING',files=[dict(path=str(root/f),sha256=sha(root/f)) for f in files],
    source_sha256=report['source_sha256'],canonical_sha256=report['canonical_sha256'],prepared_content_sha256=report['prepared_content_sha256'],
    literal_preservation='Original source X7 bytes and CTM, 9 geometric islands; no font reconstruction at these fields',
    canonical_PDF_and_progress_unchanged=True,M1_PDF_count=0,
    actual_font_shape_claim='UNKNOWN original font program; no four-cubic approximation claimed original font')
Path(fresh(root/'MANIFEST ACTUAL RAM9 DAO V2 SHA256.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
for row in report['actual_serialized_RAM_checks']['source_island_actual600_reads']:
    print(row['key'],'ALL',row['actual600_all_crop_changed_pixels'],'DARKALL',row['actual600_original_dark_pixel_changed'],'INTERIORALL',row['actual600_crop_interior2pixel_changed'],'DARKINTERIOR',row['actual600_dark_interior2pixel_changed'],'MAX',row['actual600_max_channel_difference'],flush=True)
print('MANIFEST',json.dumps(manifest,ensure_ascii=False),flush=True)
for f in ['ETA4 DOAN C2 NGUON VA DAU LAN KHUNG/ETA4 BEZIER C2 VA558 DIEM NGUON CHUA CHOT.json','MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json','DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON/KHOANG THONG SO PHA VA NHIP NGUON V8 DE ROOT KIEM.json']:
    doc=read(base/f);print('SOURCE REFERENCE KEYS',f,list(doc),flush=True)
