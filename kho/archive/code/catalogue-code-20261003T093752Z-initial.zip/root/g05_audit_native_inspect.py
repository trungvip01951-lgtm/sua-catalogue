from catwork import start,fresh,HERE
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
import numpy as np,json
from PIL import Image
from scipy.signal import find_peaks

prefix='G05/MAU SUA DUONG/'
axes=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
E=Editor(S.dst(name));R=Raster(E);out=[]
for f in ['6SP30','6SP60','10SP135']:
 b=next(z for z in axes if z['family']==f)
 im=R.image_at(b['page']-1,(b['x0'],b['y0'],b['x1'],b['y1']))
 cv=R.canvas(im);a=cv.orig
 p0=cv.to_px(b['x0'],b['y1']);p1=cv.to_px(b['x1'],b['y0'])
 x0,y0=np.round(p0).astype(int);x1,y1=np.round(p1).astype(int)
 crop=a[y0:y1+1,x0:x1+1]
 imgpath=Path(S.report(prefix+f+'-native-x4.png'))
 if not imgpath.exists():Image.fromarray(crop).resize((crop.shape[1]*4,crop.shape[0]*4)).save(fresh(imgpath))
 K=np.minimum(crop[:,:,1].astype(float)-crop[:,:,0],crop[:,:,2].astype(float)-crop[:,:,0]);g=crop.mean(2)
 lines=[]
 for q in ([18,24,36,42] if f=='6SP30' else ([36,60,72,78] if f=='6SP60' else [54,144,180])):
  x=float(np.interp(q,np.array(b['xticks'])[:,0],np.array(b['xticks'])[:,1]));xp=cv.to_px(x,b['y0'])[0]
  xi=round(xp)-x0
  val=K[:,xi];pk,_=find_peaks(val,prominence=5,distance=2,height=8)
  xx=[]
  for y in pk:
   xx.append(dict(y=int(y),rgb=crop[y,xi].tolist(),K=float(val[y]),gray=float(g[y,xi]),neighbors=crop[max(0,y-3):y+4,xi].tolist()))
  lines.append(dict(Q=q,xpage=x,xpixel=xp,peaks=xx))
 out.append(dict(family=f,page=b['page'],W=im.W,H=im.H,ctm=im.ctm.tolist(),native_box=list(map(int,[x0,y0,x1,y1])),lines=lines))
 print(f,'W/H',im.W,im.H,'CTM',im.ctm,'native box',[x0,y0,x1,y1], 'K percentile',np.percentile(K,[90,95,99,99.9]),flush=True)
 for l in lines: print(l['Q'],[(v['y'],v['rgb'],v['K']) for v in l['peaks']],flush=True)
Path(fresh(S.report(prefix+'PHAN TICH NET GOC.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close()
