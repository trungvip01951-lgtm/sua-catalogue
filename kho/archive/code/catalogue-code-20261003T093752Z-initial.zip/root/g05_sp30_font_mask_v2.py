"""Only source-glyph mask research; never retype glyph or replace source RGB."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.ndimage import map_coordinates,binary_dilation
from pathlib import Path
from PIL import Image
import json,numpy as np,hashlib

I='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
O='G05/6SP30 HAI MUOI CHIN MOC/MAT NA CHU TU GLYPH SACH V2/'
d=json.loads(Path(S.report(I+'CHUNG CU NGUON 29 MOC 13 MAY.json')).read_text(encoding='utf8'))
E=Editor(d['source_path']);R=Raster(E);a=R.canvas(R.images(4)[0]).orig;f=a.astype(float);gray=f@np.array([.299,.587,.114]);chroma=f.max(2)-f.min(2)
bodies={13:(475,481),15:(458,466),17:(443,450),20:(419,426),24:(388,394),26:(372,378),30:(340,346),32:(325,330),35:(302,307),38:(277,283),42:(246,252)}
# Manual character cells, read against the native source images. Forced OCR
# component splits from the earlier diagnostic are discarded.
slots=[(1135,1142),(1141,1149),(1148,1156),(1155,1162),(1161,1168),(1166,1171),(1170,1177),(1176,1183)]
clean={'6':('6SP30-26',1176,1183,371,380),'S':('6SP30-42',1141,1149,245,254),'P':('6SP30-42',1148,1156,245,254),'3':('6SP30-42',1155,1162,245,254),'0':('6SP30-42',1161,1168,245,254),'-':('6SP30-42',1166,1171,245,254),'4':('6SP30-42',1170,1177,245,254),'2':('6SP30-42',1176,1183,245,254),'1':('6SP30-17',1170,1177,442,452),'7':('6SP30-17',1176,1183,442,452),'5':('6SP30-35',1176,1183,301,309),'8':('6SP30-38',1176,1183,276,285)}
bank={};records=[]
for ch,(text,x0,x1,y0,y1) in clean.items():
 suffix=int(text.rsplit('-',1)[1]);top,bot=bodies[suffix];v=gray[y0:y1,x0:x1];alpha=np.clip((255-v)/255,0,1)
 # This box is a clean source glyph cell. Pixels outside the verified letter
 # height are kept in research, but do not support a foreign curve at target.
 yy=np.arange(y0,y1);alpha[(yy<top)|(yy>bot)]=0
 bank[ch]=dict(alpha=alpha,box=[x0,y0,x1,y1],body=[top-y0,bot-y0],source=text)
 raw=a[y0:y1,x0:x1];Image.fromarray(raw).resize(((x1-x0)*24,(y1-y0)*24),Image.Resampling.NEAREST).save(fresh(S.report(O+'CHU SACH/'+ch.replace('-','dau-noi')+'.png')))
 records.append(dict(char=ch,source_label=text,box=[x0,y0,x1,y1],body=[top,bot],alpha=alpha.tolist(),raw_RGB=raw.tolist(),manual_cell=True))

lock=np.zeros(a.shape[:2],bool);support=np.zeros_like(lock);core=np.zeros_like(lock);rows=[]
# Low labels are the untouched prefix of every edited curve; keep every pixel
# in this field, including all eight actual source labels and their source ink.
lock[494:580,1132:1187]=True
for suffix,(top,bot) in bodies.items():
 text='6SP30-'+str(suffix);word=np.zeros_like(lock);fits=[]
 for i,ch in enumerate(text):
  x0,x1=slots[i];y0=top-1;y1=bot+2;v=gray[y0:y1,x0:x1];cc=chroma[y0:y1,x0:x1];t=bank[ch];al=t['alpha'];best=None
  # Align only to independent neutral black source letter cores, never to a
  # table coordinate or a grey curve. The transform defines a mask only.
  wanted=(v<110)&(cc<8);h=y1-y0;w=x1-x0
  for dy in np.arange(-.8,.81,.2):
   for dx in [-.25,0,.25]:
    yy,xx=np.meshgrid(np.linspace(0,al.shape[0]-1,h)+dy,np.linspace(0,al.shape[1]-1,w)+dx,indexing='ij');tmpl=map_coordinates(al,[yy,xx],order=1,mode='constant',cval=0)
    # Fit neutral source black cores and penalize invented font in white gaps.
    err=float(np.sum((1-tmpl[wanted])**2)+.15*np.sum(tmpl[v>240]**2))
    if best is None or err<best[0]:best=(err,tmpl,dx,dy)
  err,tmpl,dx,dy=best
  # Native source curves have a non-neutral core. A simple two-ink mixture
  # estimate is diagnostic only and must also be inside a real glyph contour.
  rg=np.maximum(0,f[y0:y1,x0:x1,1]-f[y0:y1,x0:x1,0]);font_alpha=np.clip((255-v-149*rg/9)/255,0,1)
  seed=(v<110)&(cc<8);glyph=(tmpl>.10)&((font_alpha>.04)|((cc<=5)&(v<240)))
  glyph|=seed
  # True neutral fringe one pixel from a verified letter core is retained.
  glyph|=binary_dilation(seed,iterations=1)&(tmpl>.04)&(v<250)&(cc<=5)
  word[y0:y1,x0:x1]|=glyph;support[y0:y1,x0:x1]|=tmpl>.10;core[y0:y1,x0:x1]|=seed
  fits.append(dict(char=ch,target_box=[x0,y0,x1,y1],source_label=t['source'],source_box=t['box'],dx=float(dx),dy=float(dy),fit_error=err,neutral_core=int(seed.sum()),neutral_core_covered=int((seed&glyph).sum()),mask_count=int(glyph.sum()),support_count=int((tmpl>.10).sum())))
 lock|=word
 bx=(1132,top-3,1187,bot+4);raw=a[bx[1]:bx[3],bx[0]:bx[2]];m=word[bx[1]:bx[3],bx[0]:bx[2]];overlay=raw.copy();overlay[m]=(np.round(.7*raw[m]+.3*np.array([0,210,60]))).astype(np.uint8)
 Image.fromarray(raw).resize((raw.shape[1]*20,raw.shape[0]*20),Image.Resampling.NEAREST).save(fresh(S.report(O+'NHAN/'+text+'-goc.png')))
 Image.fromarray(overlay).resize((raw.shape[1]*20,raw.shape[0]*20),Image.Resampling.NEAREST).save(fresh(S.report(O+'NHAN/'+text+'-khoa.png')))
 retained_curve_candidates=int((word&(gray>85)&(chroma>7)&~support).sum())
 rows.append(dict(label=text,body=[top,bot],fits=fits,retained_curve_candidates_outside_learned_contour=retained_curve_candidates,pixel_count=int(word.sum()),mask_not_retyped=True))
 print('MASK',text,int(word.sum()),retained_curve_candidates,flush=True)
np.savez_compressed(fresh(S.report(O+'MAT NA NGUON.npz')),fontlock=lock,fontcore=core,support=support)
Path(fresh(S.report(O+'CHUNG CU MAT NA CHU.json'))).write_text(json.dumps(dict(source_sha256=d['source_sha256'],current_sha256=d['current_sha256'],clean_manual_glyphs=records,rows=rows,low_labels_entire_prefix_unchanged=True,source_RGB_never_replaced=True,status='KHAO SAT CAN SOI TUNG NHAN',earlier_forced_component_splits_rejected=True),ensure_ascii=False,indent=2),encoding='utf8')
E.close()
