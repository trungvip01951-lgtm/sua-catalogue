from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
p=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((p/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
source=d['method']['source'];current=d['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest()
assert [sha(source),sha(current)]==[d['method']['source_SHA256'],d['method']['input_SHA256']]
text='''# Phương án Redpump: dựng đồng bộ toàn biểu đồ

**Chưa vẽ mẫu, chưa thay bản giao.** Mẫu vá đuôi /25 giữ riêng: số đo đạt nhưng chưa đạt yêu cầu hình thức mới.

Trang 8 có **13 đường Q–H + 1 đường η = 14 đường thực**. Q là lưu lượng, H là cột áp, η là hiệu suất. 13 model gồm /4, /5, /6, /8, /9, /11, /12, /14, /16, /18, /20, /23, /25. Bảng riêng Redpump có 104 số H tại Q=[0,3,6,9,12,15,18,21] m³/h. Đã soi chắc cả 13 nhãn hiện hành.

| STT | Tệp | Trang | Việc | Trước | Dự kiến sau | Trạng thái | Bằng chứng và kiểm tra |
|---|---|---:|---|---|---|---|---|
| 1 | Redpump giếng SL | 8 | Đồng bộ 13 đường Q–H | Nét ảnh nén khác độ sắc với hai đường PDF đã sửa | Dựng toàn bộ 13 đường PDF liên tục từ 104 neo; cùng một bộ màu, độ dày và nét đứt | CHƯA VẼ MẪU | Đọc lại 13 đường thật trong PDF và đủ 104 neo |
| 2 | Cùng tệp | 8 | Điểm đầu/cuối | Một số nét cũ vượt Q21 | Mỗi đường chạy đúng Q0/H bảng → Q21/H bảng | CHƯA VẼ MẪU | Không kéo H=0 hoặc ngoại suy ngoài số bảng |
| 3 | Cùng tệp | 8 | Nền, lưới | Nền JPEG có viền màu và nhiều lớp sửa | Dựng nền, lưới thống nhất trong hai khung; giữ trục, số, đơn vị bên ngoài | CHƯA VẼ MẪU | Khóa mép trong khung bằng ảnh thật; không nới hộp mặc định |
| 4 | Cùng tệp | 8 | Nhãn, tiêu đề | Nhãn là chữ ảnh; nhãn thấp gần nhau | Dùng mực chữ thật trong chính tệp, nền trong suốt; tránh nét/lưới đè chữ | CHƯA VẼ MẪU | Tệp không có phông chữ vector nhúng; không tự thay phông Arial |
| 5 | Cùng tệp | 8 | Đường η | Có đường, thiếu bảng số hiệu suất | Dựng theo 551 điểm mực nguồn, giữ hình dạng và đầu/cuối, chung kiểu nét | CHƯA THỂ về số η | Kiểm hình học với nguồn; không tạo giá trị hiệu suất giả |
| 6 | Cùng tệp | Toàn tệp | Dữ liệu nguồn | 196 model / 1.931 ô H | Dùng chính các số Redpump, giữ từng ô bảng | DỮ LIỆU ĐÃ KHÓA | Đã so 1.931 vùng ô nguồn với bản giao: 0 điểm ảnh đổi |
| 7 | Cùng tệp | 8 | Hình thức cuối | Cách vá đuôi đã dừng | Soi toàn trang và đầu/giữa/cuối từng đường ở 150/300/600 dpi | CHƯA KIỂM MẪU | Mọi đường đều nét, không nét kép, quầng cũ, gãy hoặc cảm giác vá |
| 8 | Cùng tệp | 1–11 | Bảo toàn và lưu | Nguồn và bản giao có mã kiểm tra cố định | Giữ ảnh, chữ, bảng, liên kết, siêu dữ liệu, khổ trang; ngoài vùng dựng không đổi | CHƯA KIỂM MẪU | Đối chiếu ảnh 200 dpi, ngưỡng 0; kiểm độc lập; chỉ ROOT ghi tiến độ |

**Phương pháp:** sau tất cả lớp cũ, phủ toàn miền trong hai khung bằng nền/lưới mới rồi vẽ đủ 14 đường. Mỗi đường dùng cùng màu, độ dày, độ mờ, cách kết thúc và cách nối. Không nối một đoạn mới vào đường ảnh cũ. Giữ toàn ảnh gốc và mặt nạ gốc trong cấu trúc tệp; nền mới phải che sạch mực đường cũ mà không phủ trục, số, bảng hoặc logo.

**Số và đường:** nội suy PCHIP — bậc ba giữ dáng qua các mốc — đi qua đúng từng số bảng. Nét đứt Q0–6 và nét liền Q6–21 giữ quy ước nguồn; dùng một chu kỳ nét đứt thống nhất, đo riêng từ Redpump trước khi dựng. Màu đề xuất RGB=[134,149,152], dày 0,95 pt; ROOT và tác nhân kiểm đồ họa khóa bộ nét trước mẫu. pt là đơn vị điểm của PDF. Độ dày này suy từ mực ảnh nguồn, không phải thông số bút gốc đã biết.

**Chữ:** tệp Redpump không có phông chữ hoặc chữ vector nhúng ở 11 trang. Ưu tiên lấy đúng toàn cụm nhãn trong chính tệp, dùng alpha — mặt nạ mực trong suốt — để bỏ nền, lưới và nét bơm quanh chữ. Giữ đúng hình chữ, cỡ và màu. Nhãn gần nhau được bố trí sạch trong miền đầu đường tương ứng. Nếu chữ chưa đạt chuẩn nét mới thì ghi CHƯA ĐẠT; không tự thay phông bằng phông khác.

**Hiệu suất:** đã theo 551 điểm mực nguồn và soi đúng hình dạng. Miền Q quan sát khoảng 0,188459…21,587239 m³/h; giao đầu với khung đen còn phải khóa theo mực thật. Không giả định η=0 hoặc thêm số thiếu. Không có bảng hiệu suất nên chỉ nghiệm thu tái dựng hình học; độ đúng thông số η vẫn CHƯA THỂ XÁC MINH.

**Khung toàn tệp:** 17 biểu đồ, 196 model Q–H, 1.931 ô H. Mỗi biểu đồ dùng trục, số chia và dữ liệu của chính Redpump. Đường trong nguồn bị mờ không được chọn theo H bảng hoặc số tầng. 27 nhãn nguồn hiện chưa khóa chắc danh tính đường cũ được giữ CHƯA THỂ; mã model trong bảng đã đọc chắc có thể dùng để dựng nhãn mới bằng chữ cùng kiểu trong tệp. Khi các vạch lưới và số chia khác bước, như 4SL10, phải đo riêng và giữ ý nghĩa trục.

Các dòng 6SL25/12, /14, /16, /18, /20 tăng nhẹ 1 m từ Q0 sang Q3 trong bảng nguồn. Phải giữ số thật; không ép đường giảm đơn điệu ở đoạn này. Không kéo đường về H=0 sau điểm cuối có số.

Đây là phương pháp dựng toàn biểu đồ mới, chưa thử mẫu; tối đa hai mẫu. Sau mẫu trang 8 đạt cả số và hình thức độc lập mới áp dụng các biểu đồ khác, rồi đọc lại đủ 1.931 neo trong PDF cuối. Hai đường /23 và /18 đã đạt số trước đây cũng dựng lại đồng bộ nhưng phải giữ 16 số đã khóa. Mẫu cũ, báo cáo cũ và nguồn đều giữ nguyên. Chỉ ROOT cập nhật TIEN DO.md.

Hồ sơ số, tọa độ và phạm vi chi tiết: PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json.
'''
Path(fresh(p/'PHUONG AN DUNG DONG BO 8 COT DE DOC.md')).write_text(text,encoding='utf8')
assert [sha(source),sha(current)]==[d['method']['source_SHA256'],d['method']['input_SHA256']]
print('Plan readable saved, no sample or catalogue written',flush=True)
