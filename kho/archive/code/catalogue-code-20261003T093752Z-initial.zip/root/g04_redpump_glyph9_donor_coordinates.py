"""Actual source donor context and coordinates; no PDF or substitute font."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cases=[(3,'3SL4/9',(129,377,145,385)),(7,'4SL10/19',(133,410,160,417)),(7,'4SL12/29',(553,461,584,469)),(6,'4SL8/29',(552,421,583,429))];records=[]
pic=Image.new('RGB',(1150,4*330),'white');dr=ImageDraw.Draw(pic)
for i,(page,name,rect) in enumerate(cases):
 cv=R.render_canvas(page-1,rect,dpi=600);a=Image.fromarray(cv.orig);p=a.resize((a.width*3,a.height*3),Image.Resampling.NEAREST);pic.paste(p,(150,i*330+35));dr.text((5,i*330+5),name,fill='blue')
 for u in range(0,a.width,20):dr.text((150+u*3,i*330+13),str(u),fill=(180,0,180))
 for v in range(0,a.height,10):dr.text((120,i*330+35+v*3),str(v),fill=(180,0,180))
 records.append(dict(source_page=page,word=name,rect=list(cv.rect0),dpi=600,width=a.width,height=a.height))
photo=fresh(root/'CHU9 UNG VIEN MO NGUYEN CUM VA TOA DO.png');pic.save(photo)
Path(fresh(root/'CHU9 UNG VIEN MO NGUYEN CUM VA TOA DO.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=records,photo=photo,PDF_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('Source contexts only; noPDF',flush=True)
