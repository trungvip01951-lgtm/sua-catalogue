"""Fresh RAM source-edge smallglyph geometry; no mass-fit, no PDF."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,sys,numpy as np
sys.path.insert(0,str(HERE))
from g04_source_glyph_source_edge_math import source_edge_glyph
from g04_source_glyph_core_math import source_linear_stroke
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
folder=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1/CHU NHO BIEN NGUON KHONG EP MUC RAM V5'))
assert not folder.exists()
B=json.loads((P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
tops={'4':(1,1),'S':(1,0),'L':(1,0),'6':(1,1),'3':(1,0),'/':(1,0),'2':(1,0),'5':(3,0),'0':(1,1),'8':(1,2),'9':(1,1),'1':(1,0)}
out=[]
for r in B['records']:
    ch=r['character'];v=(source_linear_stroke(r['source_alpha'],core_gray=63) if ch=='/' else
        source_edge_glyph(r['source_alpha'],tops[ch],core_gray=63,curvy=ch in 'S6350892'))
    v.update(character=ch,source_page=r['source_page'],source_word=r['source_word'],source_page_box=r['source_page_box'],source_alpha=r['source_alpha'],
        source_common_core_rule='RGB63 chung đã tính từ12donor; ứng viên hình thức, không suy font gốc có nhiều màu.',no_PDF_written=True)
    out.append(v);Path(fresh(folder/f'BIEN KY TU {ord(ch):03d} RAM.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
    print('source_edge',ch,'mass_delta',v['vector_optical_area_px']/v['source_area_px']-1,'geometry',[(p['kind'],round(p['coverage_threshold'],3),len(p['loops']),p.get('max_contour_fit_error_px600')) for p in v['parts']],flush=True)
Path(fresh(folder/'12 GLYPH NHO BIEN MOT MAU RAM V2.json')).write_text(json.dumps(dict(records=out,core_gray=63,no_mass_tightening=True,
    no_external_font=True,no_large_title=True,no_table_bold_font=True,PDF_written=False,M2_written=False,canonical_written=False,
    shared_progress_written=False,status='Chỉ biên nhỏ từ nguồn, không ép tích phân. Cần ROOT/đồhọa đọc bộ13tên.'),ensure_ascii=False,indent=2),encoding='utf8')
print('SOURCE EDGE ONLY RAM',folder,flush=True)
