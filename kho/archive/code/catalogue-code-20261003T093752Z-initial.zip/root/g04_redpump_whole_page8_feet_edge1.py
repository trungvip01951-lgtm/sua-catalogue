"""Locate every changed feet pixel in actual M1. Read-only/source/current guards."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
pr=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
b=json.loads((root/'TAO MAU1 VA BAO VE NGUON.json').read_text(encoding='utf8'));keep=json.loads((pr/'VACH PHU FEET VA KHOI TIEU DE GIU NGUON V1.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(b['source']),sha(b['input_current']),sha(b['sample'])];assert before==[b['source_SHA256'],b['input_SHA256'],b['sample_SHA256']]
Ea=Editor(b['input_current'],backend='fitz');Ra=Raster(Ea);Ez=Editor(b['sample'],backend='fitz');Rz=Raster(Ez)
out=[];sheet=Image.new('RGB',(1600,2100),'white');dr=ImageDraw.Draw(sheet)
for idx,t in enumerate(keep['short_feet_ticks']):
 box=t['source_original_ink_restore_page_bbox'];A=Ra.render_canvas(7,box,dpi=600);Z=Rz.render_canvas(7,box,dpi=600)
 assert A.rect0==Z.rect0 and A.orig.shape==Z.orig.shape
 delta=np.any(A.orig!=Z.orig,axis=2);ys,xs=np.where(delta);pixels=[]
 for u,v in zip(xs,ys):
  x,y=A.to_page(float(u)+.5,float(v)+.5);old=A.orig[v,u].astype(int);new=Z.orig[v,u].astype(int)
  edge=min(x-box[0],box[2]-x,y-box[1],box[3]-y)
  near_vertical_frame=abs(x-355.0665066767002)<.75
  near_horizontal_tick=abs(y-t['source_page_y'])<.55
  oldgray=float(old@np.array([.299,.587,.114]));newgray=float(new@np.array([.299,.587,.114]))
  pixels.append(dict(pixel_uv_in_actual_crop=[int(u),int(v)],page_xy_center=[x,y],RGB_before=old.tolist(),RGB_after=new.tolist(),
   gray_before=oldgray,gray_after=newgray,gray_change=newgray-oldgray,distance_to_restore_box_edge_pt=edge,
   distance_from_source_tick_y_pt=abs(y-t['source_page_y']),near_source_vertical_frame=near_vertical_frame,near_horizontal_tick_core=near_horizontal_tick,
   classification='Nguồn khung dọc ở mép clip' if near_vertical_frame else 'Biên/nền ở mép hộp, nằm ngoài tâm vạch phụ ngang' if not near_horizontal_tick else 'Mực vạch phụ ngang cần đọc riêng'))
 original=(A.orig.astype(float)@np.array([.299,.587,.114]))
 newly=(Z.orig.astype(float)@np.array([.299,.587,.114]))
 corechanged=[z for z in pixels if z['near_horizontal_tick_core'] and not z['near_source_vertical_frame']]
 lostdark=[z for z in pixels if z['gray_before']<200 and z['gray_change']>1]
 boxexpanded=[box[0]-1.,box[1]-1.,box[2]+1.,box[3]+1.]
 a=Ra.render_canvas(7,boxexpanded,dpi=600);z=Rz.render_canvas(7,boxexpanded,dpi=600);pic0=Image.fromarray(a.orig);pic1=Image.fromarray(z.orig)
 ann0=ImageDraw.Draw(pic0);ann1=ImageDraw.Draw(pic1)
 for px in pixels:
  x,y=px['page_xy_center'];u,v=a.to_px(x,y);u=int(np.floor(u));v=int(np.floor(v))
  ann0.rectangle([u-1,v-1,u+1,v+1],outline=(255,0,0));ann1.rectangle([u-1,v-1,u+1,v+1],outline=(255,0,0))
 raw0=Image.fromarray(a.orig).resize((a.orig.shape[1]*6,a.orig.shape[0]*6),Image.Resampling.NEAREST)
 raw1=Image.fromarray(z.orig).resize((z.orig.shape[1]*6,z.orig.shape[0]*6),Image.Resampling.NEAREST)
 y0=idx*410;sheet.paste(raw0,(10,y0+30));sheet.paste(raw1,(780,y0+30))
 dr.text((10,y0+5),f'Feet{idx+1}: actual current600dpi, original pixels',fill='blue');dr.text((780,y0+5),f'M1:changed{len(pixels)};horizontal core outside frame{len(corechanged)}',fill='blue')
 marked0=pic0.resize((pic0.width*6,pic0.height*6),Image.Resampling.NEAREST);marked1=pic1.resize((pic1.width*6,pic1.height*6),Image.Resampling.NEAREST)
 sheet.paste(marked0,(10,y0+235));sheet.paste(marked1,(780,y0+235))
 dr.text((10,y0+220),'Redboxes: changed positions, reportimage only',fill='blue')
 out.append(dict(index=idx+1,restore_bbox=box,render_actual_rect=A.rect0,source_native_row=t['source_native_v'],source_page_y=t['source_page_y'],
  changed_pixel_count=len(pixels),lost_dark_ink_count=len(lostdark),changed_horizontal_tick_core_outside_frame_count=len(corechanged),
  horizontal_stem_observation='Đầu/đuôi vạch ngang bên phải khung không đổi; các điểm đổi nằm ở mép hộp/khung dọc.' if not corechanged else 'Có điểm mực vạch ngang đổi; CHƯA ĐẠT.',
  changed_pixels=pixels,source_black_frame_changed=True if lostdark else False,
  exact_restore_box_preserved=False,proposed_next_trial_clip=[box[0]-.48,box[1]-.48,box[2]+.48,box[3]+.48],
  proposal='Nới riêng lỗ bảo vệ vạch0,48pt mỗi mép rồi giao với miền sửa cố định. Không nới miền sửa và không đụng sốfeet. Giữ khu vực mực gốc khỏi mép khử răng cưa clip. Đây là kế hoạch, chưa tạoM2.' ))
sheet.save(fresh(root/'5 VACH FEET PIXEL RGB VA MEP CLIP TRUOC SAU600.png'))
Path(fresh(root/'5 VACH FEET DOI CHIEU TUNG PIXEL RGB.json')).write_text(json.dumps(dict(sample=b['sample'],sample_SHA256=b['sample_SHA256'],records=out,PDF_written=False,canonical_written=False,proposal_only=True),ensure_ascii=False,indent=2),encoding='utf8')
Ea.close();Ez.close();assert before==[sha(b['source']),sha(b['input_current']),sha(b['sample'])]
print([(r['index'],r['changed_pixel_count'],r['lost_dark_ink_count'],r['changed_horizontal_tick_core_outside_frame_count']) for r in out],flush=True)
