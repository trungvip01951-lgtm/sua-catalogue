from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import json
prefix='G05/KIEM TOAN TOAN BO/'
for fam,r in [('6SP18',(.62,.88,.98,.95)),('10SP135',(.66,.10,.84,.24)),('6SP36',(.01,.79,.99,.94))]:
    im=Image.open(S.report(prefix+'BANG DAY DU/'+fam+'.png'));w,h=im.size
    box=(int(r[0]*w),int(r[1]*h),int(r[2]*w),int(r[3]*h));cro=im.crop(box)
    cro.resize((cro.width*3,cro.height*3),Image.Resampling.NEAREST).save(fresh(S.report(prefix+'CHI TIET/'+fam+'.png')))
    print('CROP',fam,box,flush=True)
