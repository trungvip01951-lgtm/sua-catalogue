from catwork import start,fresh
from pathlib import Path
import json,numpy as np
from scipy.signal import find_peaks
S,D,N=start()
from catfix import charts
j=S.job('Perotac bơm giếng SP_compressed (bản mới).pdf')
out=[]
for p,r,hstep,hmax,xstep,qmax,number,ordinal,qs,hs,tops in [
 (4,(469,310,768,504),65,520,6,48,19,5,list(range(0,43,6)),[68,67,63,58,53,46,34,21],[478,467,441,405,373,321,241,148]),
 (6,(70,310,370,504),50,300,6,84,13,13,[72,78],[103,72],[110,80])]:
    cv=j.R.render_canvas(p,r,dpi=600);g=cv.gray()
    yh,_=find_peaks(255-np.median(g,axis=1),prominence=3,distance=int(0.8*(hstep/hmax)*(g.shape[0]-20)))
    xv,_=find_peaks(255-np.median(g,axis=0),prominence=3,distance=int(0.8*(xstep/qmax)*(g.shape[1]-20)))
    print('trang',p+1,'gridY',[(round(cv.to_page(0,int(y))[1],2),round(float(255-np.median(g,axis=1)[y]),2)) for y in yh],
          'gridX',[(round(cv.to_page(int(x),0)[0],2),round(float(255-np.median(g,axis=0)[x]),2)) for x in xv],flush=True)
    assert len(yh)==hmax/hstep+1 and len(xv)==qmax/xstep+1,(p,len(yh),len(xv))
    ch=charts.Chart.from_ticks([(i*xstep,cv.to_page(int(x),0)[0]) for i,x in enumerate(xv)],
                              [(i*hstep,cv.to_page(0,int(y))[1]) for i,y in enumerate(reversed(yh))])
    a=cv.work.astype(float)
    mask=(a[:,:,1]-a[:,:,0]>7)&(a[:,:,2]-a[:,:,0]>7)&(a[:,:,0]<249)
    values=[]
    for Q,H,top in zip(qs,hs,tops):
        px,py=ch.to_page(Q,H);u=cv.to_px(px,py)[0]
        found=[]
        for dx in [0,3,-3,6,-6,10,-10,16,-16]:
            x=int(round(u+dx));w=4
            vcount=mask[:,max(0,x-w):min(mask.shape[1],x+w+1)].sum(axis=1)
            idx=np.where(vcount>=3)[0];clusters=[]
            for v in idx:
                if not clusters or v-clusters[-1][-1]>3:clusters.append([int(v)])
                else:clusters[-1].append(int(v))
            centers=[]
            for cl in clusters:
                vv=float(np.average(cl,weights=vcount[cl]));yp=cv.to_page(x,vv)[1]
                hh=ch.to_data(np.array([[cv.to_page(x,vv)[0],yp]]))[0,1]
                if 0<=hh<min(hmax-1,top+18):centers.append((float(hh),vv))
            centers.sort()
            if len(centers)==number:
                found.append((centers[ordinal-1][0],dx,len(centers)))
        values.append(dict(Q=Q,H_table=H,H_curve=None if not found else float(np.median([v[0] for v in found])),
                   candidates=found,tolerance=max(1,.02*H)))
    print('số đo',values,flush=True)
    out.append(dict(page=p+1,model='6SP30-6' if p==4 else '6SP60-20',
                    unit_Q='m3/h',unit_H='m',values=values,grid_x=xv.tolist(),grid_y=yh.tolist(),
                    x_ticks=ch.xticks if hasattr(ch,'xticks') else None))
Path(fresh(S.report('G05/DO DUONG CONG.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
j.close()
