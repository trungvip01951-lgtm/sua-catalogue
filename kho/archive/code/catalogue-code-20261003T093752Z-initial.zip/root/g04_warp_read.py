"""Đọc độc lập điểm bảng trên ảnh đã dời nét, trước khi chạm PDF."""
from catwork import start,fresh
from pathlib import Path
import json,numpy as np,csv
from PIL import Image,ImageDraw
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
name='Perotac bơm giếng SA_compressed (bản mới).pdf';E=Editor(S.dst(name));R=Raster(E);cv=R.canvas(R.images(7)[0])
folder=Path(S.report('G04/THU DOI NET GOC LAN2'));old=cv.orig.copy();new=np.asarray(Image.open(folder/'Toan anh nguon da doi net.png'))
assert old.shape==new.shape
ticks=[(100,134.875),(150,172.07),(200,209.15),(250,246.47),(300,283.79)]
c=np.polyfit([q for q,x in ticks],[x for q,x in ticks],1);res=max(abs(np.polyval(c,q)-x) for q,x in ticks);assert res<.2
top,bottom=180.5,571.5;Q=[0,3,6,9,12,15,18,21];series=[('4SA16/23',[136,133,127,115,101,86,69,50]),('4SA16/18',[107,104,99,90,79,67,54,39])]
g=new@np.array([.299,.587,.114]);a=new.astype(int);colour=(a[:,:,1]-a[:,:,0]>8)&(a[:,:,2]-a[:,:,0]>10)&(a[:,:,0]<235)
records=[];seen=[]
for model,hs in series:
 for q,h in zip(Q,hs):
  xpt=float(np.polyval(c,q*1000/60));u=float(cv.to_px(xpt,400)[0]);v=bottom-h/150*(bottom-top)
  xs=[];ys=[]
  for xx in range(max(0,int(round(u))-6),min(new.shape[1],int(round(u))+7)):
   # Chỉ đọc trong miền bảng; ngoài đầu/cuối có đường của model kế bên.
   q_at_x=(cv.to_page(xx,0)[0]-c[1])/c[0]*60/1000
   if q_at_x<0 or q_at_x>21:continue
   vv=np.arange(max(0,int(round(v))-6),min(new.shape[0],int(round(v))+7));ink=vv[colour[vv,xx]]
   if len(ink):
    groups=np.split(ink,np.where(np.diff(ink)>1)[0]+1);centers=[float(np.average(z,weights=255-g[z,xx])) for z in groups];yy=min(centers,key=lambda z:abs(z-v));xs.append(xx);ys.append(yy)
  enough=len(xs)>=3
  if len(xs)>=2:slope,intercept=np.polyfit(xs,ys,1);yread=float(slope*u+intercept)
  elif len(xs)==1:yread=float(ys[0])
  else:yread=float('nan')
  hread=(bottom-yread)/(bottom-top)*150;tol=max(1,.02*h)
  px_per_pt=cv.to_px(xpt+1,400)[0]-cv.to_px(xpt,400)[0]
  r=dict(model=model,Q_m3h=q,H_table=h,H_curve=hread,difference_m=hread-h,tolerance_m=tol,n_source_columns=len(xs),max_Q_distance_used=float(max(abs(np.array(xs)-u))/((c[0]*1000/60)*px_per_pt)) if xs else None,uncertainty_m=150/(bottom-top),result='ĐẠT' if enough and abs(hread-h)<=tol else 'CHƯA ĐẠT')
  records.append(r);seen.append((u,yread));print(model,q,round(hread,3),r['result'],flush=True)
accepted=all(r['result']=='ĐẠT' for r in records)
# Chỉ hai hành lang bị đổi: chữ đen và mọi pixel bên ngoài hộp biểu đồ giữ nguyên.
pu0,pv0,pu1,pv1=cv.box((59.5,324,359,513));changed=np.any(old!=new,axis=2);outside=changed.copy();outside[pv0:pv1,pu0:pu1]=False;assert not outside.any()
im=Image.fromarray(new[pv0:pv1,pu0:pu1]).resize(((pu1-pu0)*3,(pv1-pv0)*3));dr=ImageDraw.Draw(im)
for u,v in seen:
 if not np.isfinite(v):continue
 x=(u-pu0)*3;y=(v-pv0)*3;dr.ellipse((x-5,y-5,x+5,y+5),outline=(220,0,0),width=2)
im.save(fresh(folder/'16 DIEM DOC LAI.png'))
Path(fresh(folder/'16 DIEM DOC LAI.json')).write_text(json.dumps(dict(records=records,accepted=accepted,axis_from_source_ticks=True,axis_residual_pt=float(res),outside_plot_pixels=0,scope='16 điểm bảng của2đường, không phải tất cả đường G04',decision='Không ghi PDF: còn đầu cuối chưa đủ chứng cứ nét. Đã dừng phương pháp dời ảnh sau2mẫu.'),ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(folder/'16 DIEM DOC LAI.csv'),'w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print('ACCEPTED',accepted,'NO PDF WRITE',flush=True);E.close()
