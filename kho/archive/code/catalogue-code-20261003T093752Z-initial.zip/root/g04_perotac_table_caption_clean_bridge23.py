"""Compare complete prefixes at clean source labels; original images only."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
from scipy.ndimage import map_coordinates,gaussian_filter
from scipy.optimize import differential_evolution,minimize
from PIL import Image
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/CAU NOI CUM4SA NHAN KHONG LAN NET BOM'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));bg=np.array([255.,255.,255.]);ink=np.array([57.,55.,57.]);tabbox=[165,1146,190,1157];tabraw=cv.orig[1146:1157,165:190];ta=R.alpha_of(tabraw,bg,ink)
records=[];tiles=[]
for model,y0 in [('4SA16/18',303),('4SA16/12',389),('4SA16/20',274)]:
    box=[281,y0,305,y0+11];raw=cv.orig[y0:y0+11,281:305];ca=R.alpha_of(raw,bg,ink);sub=12;h,w=ca.shape;yy,xx=np.mgrid[:h*sub,:w*sub];cx=(xx+.5)/sub;cy=(yy+.5)/sub
    def predict(z):
        sx,sy,dx,dy,sigma=z;up=map_coordinates(ta,[(cy-dy)/sy-.5,(cx-dx)/sx-.5],order=1,mode='constant',cval=0,prefilter=False);aa=up.reshape(h,sub,w,sub).mean((1,3));return gaussian_filter(aa,sigma,mode='constant'),aa
    def objective(z):return float(np.mean((predict(z)[0]-ca)**2))
    bounds=[(.78,1.05),(.74,1.03),(-1.5,2),(-1,2),(0,.5)];opt=differential_evolution(objective,bounds,seed=4023,popsize=7,maxiter=35,tol=1e-6,polish=False);fine=minimize(objective,opt.x,bounds=bounds,method='Powell',options={'maxiter':80,'xtol':1e-5,'ftol':1e-8});z=fine.x;pred,aa=predict(z);chars=[]
    for ch,(lo,hi) in zip('4SA',[(1,8),(8,15),(15,23)]):
        al=ca[:,lo:hi];pp=pred[:,lo:hi];pa=aa[:,lo:hi];sel=(al>.2)|(pp>.2);sm=al>.45;pm=pp>.45
        chars.append(dict(character=ch,one_common_prefix_transform=z.tolist(),source_caption_alpha=al.tolist(),predicted_table_alpha=pp.tolist(),alpha_RMSE=float(np.sqrt(np.mean((pp-al)**2))),
          signal_correlation=float(np.corrcoef(al[sel],pp[sel])[0,1]),IoU45=float((sm&pm).sum()/(sm|pm).sum()),source_alpha_mass=float(al.sum()),predicted_mass=float(pa.sum()),mass_delta_percent=float((pa.sum()/al.sum()-1)*100)))
    chroma=raw.max(2).astype(float)-raw.min(2).astype(float);blue=(raw[:,:,2].astype(float)-raw[:,:,0].astype(float)>12)&(raw[:,:,1].astype(float)-raw[:,:,0].astype(float)>5)&(ca>.1)
    rr=dict(source_caption_model=model,caption_native_box=box,table_native_box=tabbox,source_table_column='3 pha',source_table_alpha=ta.tolist(),source_caption_alpha=ca.tolist(),
      one_prefix_transform_no_character_specific_shape_change=z.tolist(),source_full_prefix_MSE=objective(z),source_full_prefix_mass_delta_percent=float((aa.sum()/ca.sum()-1)*100),
      original_blue_ink_or_JPEG_fringe_pixels_in_complete_crop=int(blue.sum()),original_blue_positions_native=[[int(x+281),int(y+y0)] for y,x in zip(*np.where(blue))],
      complete_crop_no_blue_pixels_removed_for_fitting=True,full_source_words_kept_for_visual_readback=True,characters=chars,font_style_not_accepted_by_numbers_alone=True)
    records.append(rr);tile=Image.new('RGB',(1700,320),'white');tile.paste(Image.fromarray(raw).resize((w*20,h*20),Image.Resampling.NEAREST),(10,20));tile.paste(Image.fromarray((255-pred[:,:,None]*(bg-ink)).clip(0,255).astype(np.uint8)).resize((w*20,h*20),Image.Resampling.NEAREST),(580,20));tile.paste(Image.fromarray(tabraw).resize((tabraw.shape[1]*20,tabraw.shape[0]*20),Image.Resampling.NEAREST),(1160,20));tiles.append(tile);tile.save(fresh(root/(model.replace('/','-')+' CUM4SA NGUON VA BANG QUA1 BIEN DOI.png')))
    print(model,'COMMON TRANSFORM',z.tolist(),'MSE/MASS',objective(z),rr['source_full_prefix_mass_delta_percent'],'BLUE',rr['original_blue_ink_or_JPEG_fringe_pixels_in_complete_crop'],flush=True)
    for ch in chars:print(ch['character'],'RMSE/CORR/IOU/MASS',ch['alpha_RMSE'],ch['signal_correlation'],ch['IoU45'],ch['mass_delta_percent'],flush=True)
sheet=Image.new('RGB',(1700,960),'white')
for k,t in enumerate(tiles):sheet.paste(t,(0,k*320))
sheet.save(fresh(root/'3 CUM4SA NHAN DOI CHIEU NGUYEN BANG3 PHA.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Path(fresh(root/'3 CUM4SA NGUON NHAN VA BANG KHONG DOI PHONG.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_original_Perotac_X7_only=True,
    first_25_caption_prefix_contains_blue_curve_fringe_and_not_used_as_clean_glyph=True,records=records,no_system_or_other_file_font=True,table_words_not_selected_before_ROOT_style_review=True,PDF_font_or_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8');E.close()
