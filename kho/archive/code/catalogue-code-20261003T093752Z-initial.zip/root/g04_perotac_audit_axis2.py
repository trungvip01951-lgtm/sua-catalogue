from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from g04_perotac_audit_data import DATA
from pathlib import Path
from PIL import Image,ImageDraw
from scipy.signal import find_peaks
import numpy as np,json,hashlib

root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name);E=Editor(src);R=Raster(E);items=[]
maxima=[55,90,210,160,120,480,450,480,400,300,240,210,150,360,320,300,225]
visible_flows=[list(range(0,17,2)),list(range(0,41,5)),list(range(0,46,5)),list(range(0,61,5)),list(range(0,91,10)),list(range(0,56,5)),list(range(0,81,10)),list(range(0,101,10)),list(range(0,141,20)),list(range(0,181,20)),list(range(0,241,30)),list(range(0,271,30)),list(range(0,351,50)),list(range(0,351,50)),list(range(0,551,50)),[0,83,167,250,333,417,500,583,667,750],list(range(0,901,100))]
for rec,hmax,flows in zip(DATA,maxima,visible_flows):
 im=max(R.images(rec['page']-1),key=lambda im:im.W*im.H);cv=R.canvas(im);a=cv.orig;g=a.astype(float)@np.array([.299,.587,.114]);x0,y0,x1,y1=rec['plot_native_box'];dual=x1-x0<400
 # Black frame centroids from the source; printed H=0 and H=hmax are
 # visually verified at these two frame lines. The right frame never sets Q.
 def frame_y(around):
  yy=np.arange(around-5,around+6);score=(g[yy,x0+5:x1-5]<120).sum(axis=1);selected=yy[score>=.8*score.max()];weights=score[score>=.8*score.max()]
  return float(np.average(selected,weights=weights))
 top,bottom=frame_y(y0),frame_y(y1)
 def frame_x(around):
  xx=np.arange(around-5,around+6);score=(g[y0+8:y1-8,xx]<120).sum(axis=0);selected=xx[score>=.8*score.max()];weights=score[score>=.8*score.max()]
  return float(np.average(selected,weights=weights))
 left,right=frame_x(x0),frame_x(x1)
 # Median darkness along actual gray vertical grid lines; captions/curves
 # occupy a small fraction of the height and cannot create these long lines.
 sc=255-np.median(g[int(top)+45:int(bottom)-12,int(left)+4:int(right)-3],axis=0)
 peaks,_=find_peaks(sc,height=9,distance=9,prominence=6)
 candidates=peaks+int(left)+4
 # Actual gray grid stems continue through the efficiency panel. The flow
 # values are the printed l/min labels read from source images, not table Q.
 if len(candidates)<len(flows)-1:
  sc2=255-np.median(g[int(bottom)+20:int(bottom)+(64 if dual else 89),int(left)+4:int(right)-3],axis=0)
  p2,_=find_peaks(sc2,height=8,distance=9,prominence=5);candidates=np.unique(np.r_[candidates,p2+int(left)+4])
 distances=np.diff(np.r_[left,candidates]);period=float(np.median(distances[distances>8])) if len(candidates)>1 else None
 grid=[left]+candidates.tolist()
 # Preserve possible extra grid lines/right extensions as rejected positions.
 ticks=[]
 for value,pos in zip(flows,grid):
  ticks.append(dict(litre_per_minute=value,u_native=float(pos),value_read_directly=True))
 if len(ticks)==len(flows):
  fit=np.polyfit([t['litre_per_minute'] for t in ticks],[t['u_native'] for t in ticks],1);res=np.array([t['u_native'] for t in ticks])-np.polyval(fit,[t['litre_per_minute'] for t in ticks])
  cal=dict(u_per_l_min=float(fit[0]),u_Q0=float(fit[1]),max_residual_native_px=float(abs(res).max()),manually_reviewed=False)
 else:cal=None
 qbox=(int(left)-9,int(bottom)+(72 if dual else 103),int(right)+55,int(bottom)+(99 if dual else 131))
 crop=Image.fromarray(a[qbox[1]:qbox[3],qbox[0]:qbox[2]]).resize(((qbox[2]-qbox[0])*4,(qbox[3]-qbox[1])*4),Image.Resampling.NEAREST);draw=ImageDraw.Draw(crop)
 for t in ticks:
  u=(t['u_native']-qbox[0])*4;draw.line((u,0,u,8),fill='red',width=2);draw.text((u+2,0),str(t['litre_per_minute']),fill='red')
 file='TRUC Q NGUON '+rec['family'].replace('.','_')+'.png';crop.save(fresh(root/file))
 item=dict(page=rec['page'],family=rec['family'],source_image=str(im.name),H_printed_min=0,H_printed_max=hmax,frame_native=dict(left=left,top=top,right=right,bottom=bottom),H_m_per_native_px=hmax/(bottom-top),flow_unit='l/min (lít/phút)',flow_ticks=ticks,unassigned_grid_x=grid[len(flows):],axis_calibration_draft=cal,grid_period_native=period,flow_image=file,flow_native_box=qbox,source_flow_values_read_directly=flows)
 items.append(item);print('AXIS2',rec['family'],'frame',item['frame_native'],'grid',np.round(grid,2),'cal',cal,flush=True)
Path(fresh(root/'TRUC NGUON DO LAN2.json')).write_text(json.dumps(dict(source=src,read_only=True,pdf_written=False,graphs=items),ensure_ascii=False,indent=2),encoding='utf8')
# Existing corrected #36 is identity evidence for the /17 source geometry.
rec=DATA[1];im=max(R.images(0),key=lambda im:im.W*im.H);cv=R.canvas(im);rect=cv.rect((1428,325,1511,350));before=verify.crop(src,0,rect,600);after=verify.crop(dst,0,rect,600);out=Image.new('RGB',(before.width+after.width, max(before.height,after.height)),'white');out.paste(before);out.paste(after,(before.width,0));out.save(fresh(root/'NHAN 17 DA SUA DOI CHIEU.png'));E.close()
