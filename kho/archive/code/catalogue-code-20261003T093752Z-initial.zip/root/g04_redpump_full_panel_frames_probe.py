"""Lock actual full-panel source frames/grid for plan, not a PDF sample."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import dark_line_centroid
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
source=plan['method']['source'];current=plan['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(source),sha(current)]
assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(source,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);spread=a.max(2)-a.min(2)
def groups(ids,gap=1):
 out=[]
 for i in ids:
  if not out or i-out[-1][-1]>gap:out.append([])
  out[-1].append(int(i))
 return out
out=[];pic=Image.fromarray(cv.orig);dr=ImageDraw.Draw(pic)
for name,yrange in [('QH',(175,571)),('eta',(574,680))]:
 ys=np.arange(*yrange);cov=(g[ys,130:732]<130).mean(1);runs=groups(ys[cov>.84]);assert len(runs)==2,(name,runs)
 hframes=[float(np.average(z,weights=cov[np.array(z)-yrange[0]])) for z in runs]
 lo=int(np.ceil(min(hframes)+4));hi=int(np.floor(max(hframes)-4));xx=np.arange(115,749);xc=(g[lo:hi,xx]<130).mean(0);xr=groups(xx[xc>.88]);assert len(xr)==2,(name,xr)
 vframes=[float(np.average(z,weights=xc[np.array(z)-115])) for z in xr]
 x0,y1=cv.to_page(vframes[0],hframes[0]);x1,y0=cv.to_page(vframes[1],hframes[1]);full=[x0,y0,x1,y1]
 # Neutral long-rule medians suppress chart ink, irrespective of numeric H.
 xx0=int(np.ceil(vframes[0]+4));xx1=int(np.floor(vframes[1]-4));sub=a[lo:hi,xx0:xx1];neutral=sub.max(2)-sub.min(2)<14;grays=sub@np.array([.299,.587,.114]);hc=((grays<243)&neutral).mean(1);hr=groups(np.arange(lo,hi)[hc>.67]);hy=[float(np.average(z,weights=hc[np.array(z)-lo])) for z in hr]
 xs0=int(np.ceil(vframes[0]+4));xs1=int(np.floor(vframes[1]-4));sub=a[lo:hi,xs0:xs1];neutral=sub.max(2)-sub.min(2)<14;grays=sub@np.array([.299,.587,.114]);vc=((grays<243)&neutral).mean(0);vr=groups(np.arange(xs0,xs1)[vc>.6]);vx=[float(np.average(z,weights=vc[np.array(z)-xs0])) for z in vr]
 # Native source anti-aliased frame has finite uncertainty, even a two-sided center.
 frame_record=dict(name=name,frame_native_uv=[vframes[0],hframes[0],vframes[1],hframes[1]],frame_native_ink_runs=dict(horizontal=runs,vertical=xr),frame_page_bbox=full,horizontal_inner_grid_native=hy,horizontal_inner_grid_page=[cv.to_page(0,z)[1] for z in hy],vertical_inner_grid_native=vx,vertical_inner_grid_page=[cv.to_page(z,0)[0] for z in vx],source_native_pixel_pt=[abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]),abs(cv.to_page(0,1)[1]-cv.to_page(0,0)[1])],allowed_rebuild_bbox_proposed=[full[0]-1.1,full[1]-1.1,full[2]+1.1,full[3]+1.1],allowed_padding_basis='1,1pt ~2,3nativepixel để phủ quầng JPEG đường/khung; khóa rõ ngoài vùng không đổi, không nới24pixel. Nếu chạmchữ/trục thì phải thu bbox trước mẫu.',grid_classification='Chỉ tọa độ mực lưới thực, chưa gán sốH/η theo thứhạng.' )
 out.append(frame_record)
 dr.rectangle([vframes[0]-2,hframes[0]-2,vframes[1]+2,hframes[1]+2],outline=(180,0,180),width=1)
 for y in hy:dr.line((vframes[0]+4,y,vframes[1]-4,y),fill=(180,0,180),width=1)
 for x in vx:dr.line((x,hframes[0]+4,x,hframes[1]-4),fill=(180,0,180),width=1)
 print(name,'actual frame',full,'grid rows',len(hy),'columns',len(vx),flush=True)
photo=fresh(root/'KHUNG LUOI THAT NGUON TRANG8 KHONG LA MAU.png');pic.crop((78,145,783,710)).resize((1410,1130),Image.Resampling.NEAREST).save(photo)
result=dict(source=source,source_SHA256=before[0],current_SHA256=before[1],source_original_image_shape=[im.W,im.H],source_original_ctm=im.ctm.tolist(),panels=out,source_marked_frame_photo=photo,plan_only=True,PDF_sample_written=False,eta_box_old_candidate_superseded=[59.2,273.,355.4,315.4],correction='Hộp η trong kế hoạch đầu chỉ làdựkiến; đáy thực≈269,8pt. Dùngkhung đo này, khôngcắt mựcđầuđường theo273pt.',font_alpha_probe_not_accepted=True)
Path(fresh(root/'KHUNG LUOI THAT NGUON TRANG8.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(source),sha(current)]
