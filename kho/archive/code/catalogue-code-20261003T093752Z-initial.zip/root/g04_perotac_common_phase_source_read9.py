"""Ước lượng chung pha,chu kỳ,đoạn mực bằng toàn bộ biên nguồn sạch; chưa PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.optimize import least_squares
from scipy.integrate import quad
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=folder/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON'
raw=json.loads((root/'13 NHIP DUT LIEN DOC NGUON CHI KIEM.json').read_text(encoding='utf8'));rby={r['model']:r for r in raw['curves']}
v5=json.loads((root/'13 CHU KY CUNG NGUON VA DE XUAT V5 CHUA KHOA.json').read_text(encoding='utf8'));measure=json.loads((folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'))
audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));g=next(x for x in audit['graphs'] if x['family']=='4SA16')
paths={r['model']:r.get('native_path') for r in g['curves']};paths.update({r['model']:r['observed_source_path'] for r in measure['prior_accepted_models_original_source_style_trace_only']})
geometry=json.loads((folder/'KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json').read_text(encoding='utf8'));origin=geometry['main_observed_vertical_lines'][0]['native_center'];step=measure['source_pixel_to_page_pt'];edges=[];source_geometry=[]
for r in v5['curves']:
    model=r['model'];xy=np.array([[p['u'],p['v']] for p in paths[model]]) if model!='4SA16/18' else np.array(rby[model]['source_actual_trace_xy']);xy=xy[(xy[:,0]>=127)&(xy[:,0]<=278)]
    u=xy[:,0];v=xy[:,1];z=(u-200)/100;c=np.polyfit(z,v,3);c=least_squares(lambda cc:np.polyval(cc,z)-v,c,loss='soft_l1',f_scale=.25).x;d=np.polyder(c)
    arc=lambda a,b:quad(lambda x:float(np.hypot(1,np.polyval(d,(x-200)/100)/100))*step,float(a),float(b),epsabs=1e-9)[0]
    source_geometry.append(dict(model=model,source_head_geometric_fit_coeff=c.tolist(),actual_observed_source_u_min=float(u.min()),phase_origin_axis_native_u=origin,
       axis_covers_unobserved_head_native_width=float(u.min()-origin),origin_arc_uncertainty_pt=step,
       hidden_contact_uses_continuation_of_source_slope_only_for_style_fit=True,no_QH_value_or_new_hydraulic_point_created=True))
    starts=r['source_start_edge_native_u_6full_plus_long']
    for n,x in enumerate(starts,1):edges.append(dict(model=model,kind='start',cycle_index=n,source_edge_u=float(x),source_arc_pt=arc(origin,x),edge_uncertainty_pt=step,original_edge_from_JPEG_first_visible_column=True))
    for n,(lo,hi) in enumerate(r['source_first6_full_dash_intervals_native'],1):edges.append(dict(model=model,kind='end',cycle_index=n,source_edge_u=float(hi+1),source_last_visible_u=hi,source_arc_pt=arc(origin,hi+1),edge_uncertainty_pt=step,original_edge_from_JPEG_last_visible_column_plus_pixel_span=True))
X=np.array([[1.,r['cycle_index'],0. if r['kind']=='start' else 1.] for r in edges]);y=np.array([r['source_arc_pt'] for r in edges]);fit=least_squares(lambda z:(X@z-y)/step,[0.,10.38,7.22],loss='soft_l1',f_scale=.65,bounds=([-1,10,6.5],[1,10.8,8.]));phase,period,length=map(float,fit.x)
pred=X@fit.x;delta=(pred-y)/step
for r,dv,pv in zip(edges,delta,pred):r.update(common_predicted_arc_pt=float(pv),common_predicted_source_edge_error_native_px=float(dv),within_source_one_pixel_uncertainty=bool(abs(dv)<=1))
source_models=[]
for model in paths:
    ee=[r for r in edges if r['model']==model];de=np.array([r['common_predicted_source_edge_error_native_px'] for r in ee]);source_models.append(dict(model=model,edge_count=len(ee),source_edges_within_one_px=sum(r['within_source_one_pixel_uncertainty'] for r in ee),max_source_edge_error_native_px=float(max(abs(de))),edge_error_median_native_px=float(np.median(de)),exact_source_phase_or_endpoint_state='UNKNOWN',only_fit_not_all_edges_accepted=True))
def evaluate(z):
    dd=(X@np.array(z)-y)/step;return dict(phase_pt=z[0],period_pt=z[1],dash_length_pt=z[2],within_source_uncertainty_1px=int((abs(dd)<=1).sum()),edge_count=len(dd),median_absolute_edge_error_native_px=float(np.median(abs(dd))),max_abs_error_native_px=float(max(abs(dd))))
zero=evaluate([0.,v5['replacement_of_V3_dash_proposal_not_locked']['physical_period_pt'],v5['replacement_of_V3_dash_proposal_not_locked']['dash_length_pt']]);common=evaluate([phase,period,length])
# Parameter intervals with all observed edges may have no feasible intersection; retain that fact.
from scipy.optimize import linprog
A=np.vstack([X,-X]);b=np.r_[y+step,-y+step];feas=linprog([0,0,0],A_ub=A,b_ub=b,bounds=[(-1,1),(10,10.8),(6.5,8)],method='highs');bounds={}
if feas.success:
    for k,label0 in enumerate(['phase','period','dash_length']):
        obj=np.zeros(3);obj[k]=1;low=linprog(obj,A_ub=A,b_ub=b,bounds=[(-1,1),(10,10.8),(6.5,8)],method='highs');high=linprog(-obj,A_ub=A,b_ub=b,bounds=[(-1,1),(10,10.8),(6.5,8)],method='highs');bounds[label0]=[float(low.x[k]),float(high.x[k])]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==v5['source_sha256'] and sha(S.result(name))==v5['current_sha256']
out=dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_all13_named_original_ink_only=True,
 common_source_estimate=dict(phase_pt=phase,period_pt=period,dash_length_pt=length,gap_length_pt=period-length,rounded_proposal_pt=[round(phase,2),round(period,2),round(length,2),round(period-length,2)]),
 source_uncertainty_one_native_px_pt=step,phase_origin_contact_uncertainty_native_px=1.,axis_hidden_phase_not_original_fact=True,
 source_common_fit_checked_against_all_edges=common,previous_V5_phase_zero_checked_against_same_source_edges=zero,
 all_source_edges_within_one_pixel_common_parameter_region_exists=bool(feas.success),all_edges_feasible_parameter_intervals=bounds,
 source_phase_exact_state='UNKNOWN',phase_estimate_must_not_be_used_as_exact_original_PDF_state=True,origin_fit_hidden_contact_geometry=source_geometry,models=source_models,all_source_edges=edges,
 numeric_table_nodes_not_read_or_used_to_select_phase=True,PDF_or_font_or_progress_written=False)
Path(fresh(root/'PHA CHU KY VA DOAN MUC CHUNG TU169 BIEN NGUON V6 CHUA KHOA.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
md=f'''# Ước lượng pha chung từ mọi biên nguồn

**Chỉ nguồn 13 nhánh/169 biên, không đọc hay dùng điểm bảng để chọn pha. Chưa khóa hoặc tạo PDF.**

Ước lượng chung: pha **{phase:.6f}pt**, chu kỳ **{period:.6f}pt**, đoạn mực **{length:.6f}pt**, khe **{period-length:.6f}pt**. Đây là ước lượng ảnh JPEG, trạng thái pha/đầu nét PDF nguyên: **UNKNOWN (chưa thể xác minh chính xác)**.

Trục trái che khoảng2,5pixel đầu đường; chiều dài cung đoạn dưới khung chỉ dùng tiếp tuyến nguồn tiếp tục để quy về gốc vật lý, có thêm bất định1pixel. Không tạo hoặc gán Q–H mới cho phần đó. Mỗi biên thấy có bất định1pixel thực; không ép0,5pixel.

Biên trong±1pixel khi giữ pha0V5: **{zero['within_source_uncertainty_1px']}/169**; với pha/chu kỳ/mực ước lượng chung: **{common['within_source_uncertainty_1px']}/169**. Sai số tuyệt đối trung vị: {zero['median_absolute_edge_error_native_px']:.5f}→{common['median_absolute_edge_error_native_px']:.5f}pixel. Cực đại: **{common['max_abs_error_native_px']:.5f}pixel**. Cải thiện xét cùng bộ169biên, không chỉ đẩy ba nhánh cuối cho qua.

Có miền thông số chung thỏa mọi169biên với±1pixel: **{bool(feas.success)}**. Nếu False (không), phải giữ biên chưa xác minh hoặc ảnh mờ thật; không tự tăng dung sai để nhận đủ.

| Model | Số biên trong±1pixel | Lệch lớn nhất(pixel) |
|---|---:|---:|
'''
for r in source_models:md+=f"| {r['model']} | {r['source_edges_within_one_px']}/{r['edge_count']} | {r['max_source_edge_error_native_px']:.5f} |\n"
md+='\nBảng JSON giữ đủ biên đầu/cuối từng dash (đoạn đứt), khớp/thiếu rõ và hệ số hình học nguồn. Chưa nhận nhịp mới ĐẠT; ROOT/đồ họa còn xét biên/ảnh. Bản giao, nguồn, tiến độ giữ nguyên.\n'
for a,b in {'khoảng2':'khoảng 2','bất định1':'bất định 1','ép0':'ép 0','trong±':'trong ±','pha0V5':'pha 0 V5','bộ169':'bộ 169','mọi169':'mọi 169','với±':'với ±'}.items():md=md.replace(a,b)
Path(fresh(root/'PHA CHU KY VA DOAN MUC CHUNG TU169 BIEN NGUON V6 CHUA KHOA.md')).write_text(md,encoding='utf8')
print('COMMON SOURCE PHASE PERIOD DASH GAP',phase,period,length,period-length,'169EDGE SOURCE',common,'ZERO',zero,'FEASIBLE',feas.success,flush=True)
