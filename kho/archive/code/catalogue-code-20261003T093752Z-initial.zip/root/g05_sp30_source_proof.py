"""Chỉ đọc chứng cứ 29 mốc SP30 trước lập phương án. Không vẽ đường mới/ghi PDF."""
from catwork import start, fresh, HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify
from g05_audit_manual_data import TABLES
from scipy.interpolate import UnivariateSpline, PchipInterpolator
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np,json,hashlib,csv

O='G05/6SP30 HAI MUOI CHIN MOC/DOC NGUON V2/'
P='G05/KIEM TOAN TOAN BO/'
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
current=S.dst(name);source=S.src(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)=='7335c3a45042d0517e5bb1d033513dad722145dcda0aecdb1a896c9765e7eee1'
assert sha(source)=='e1b94dc6f23c35d18d61cee71d9d88c844b1070d14ff662bbabe2256cdd690c9'
latest=json.loads(Path(S.report('G05/10SP135 HAI MOC CUOI/GIAO BAN/NGHIEM THU ACTUAL PDF GIAO.json')).read_text(encoding='utf8'))
assert latest['final_sha256']==sha(current)
points=[p for p in latest['full2218_points'] if p['family']=='6SP30']
bad=[p for p in points if p['verification_status']=='CHƯA ĐẠT']
assert len(bad)==29 and all(not p['identity_uncertain'] for p in bad)
models=sorted({p['curve_model'] for p in bad},key=lambda m:int(m.rsplit('-',1)[1]))
assert len(models)==13 and '6SP30-8' not in models
b=next(z for z in json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8')) if z['family']=='6SP30')
xt=np.array(b['xticks']);yt=np.array(b['yticks']);r=b['rect'];s=72/b['dpi']
px=lambda q:float(np.interp(q,xt[:,0],xt[:,1]));py=lambda h:float(np.interp(h,yt[:,0],yt[:,1]))
E=Editor(source);R=Raster(E);im=R.image_at(4,(b['x0'],b['y0'],b['x1'],b['y1']));cv=R.canvas(im);a=cv.orig
assert im.W==1732 and im.H==1240 and 'SMask' not in im.d
assert .479<abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0])<.481
nx=lambda x:float(cv.to_px(x,b['y0'])[0]);ny=lambda y:float(cv.to_px(b['x0'],y)[1]);page_y=lambda y:float(cv.to_page(0,y)[1])
orig_audit=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'))
source_rows=[];splines=[]
for k,row in enumerate(TABLES['6SP30']['rows']):
 bins={}
 for p in orig_audit['points']:
  if p['family']!='6SP30' or p['row']!=k+1 or p.get('H_curve_m') is None or p['Q_m3h']==12:continue
  for z in p['sample_locations']:
   x=nx(r[0]+z['x_px']*s);y=ny(r[3]-z['y_px']*s);bins.setdefault(round(x,4),[]).append(y)
 sx=np.array(sorted(bins));sy=np.array([np.median(bins[x]) for x in sx])
 measured=[p for p in orig_audit['points'] if p['family']=='6SP30' and p['row']==k+1 and p.get('H_curve_m') is not None]
 qh=sorted((p['Q_m3h'],p['H_curve_m']) for p in measured)
 knotx=np.array([nx(px(q)) for q,h in qh]);knoty=np.array([ny(py(h)) for q,h in qh]);spl=PchipInterpolator(knotx,knoty);splines.append(spl)
 resid=float(np.max(abs(spl(sx)-sy)))
 sr=dict(rank=k+1,model=row['curve_model'],source_actual_label='6SP30-9' if row['curve_model']=='6SP30-8' else row['curve_model'],source_samples=len(sx),source_residual_max_native_px=resid,source_samples_native_xy=np.c_[sx,sy].tolist(),selected=row['curve_model'] in models,source_spline_for_read_only_diagnostics=True,source_spline_not_final_accepted_center=True,source_measured_knots_QH=qh,source_spline_method='Nội suy giữ đơn điệu qua H nét nguồn được đọc độc lập; không fit dao động trong vùng thiếu mẫu. Không dùng H bảng.')
 source_rows.append(sr)

tr=next(z['rect'] for z in json.loads(Path(S.report(P+'BANG DAY DU.json')).read_text(encoding='utf8')) if z['family']=='6SP30')
verify.crop(current,4,tr,600).save(fresh(S.report(O+'BANG SO PDF GIAO.png')))
verify.crop(source,4,tr,600).save(fresh(S.report(O+'BANG SO PDF NGUON.png')))
verify.crop(current,4,r,600).save(fresh(S.report(O+'BIEU DO PDF GIAO.png')))
verify.crop(source,4,r,600).save(fresh(S.report(O+'BIEU DO PDF NGUON.png')))
label_r=(px(10.7),py(22),px(16.8),py(465))
verify.crop(current,4,label_r,600).save(fresh(S.report(O+'NHAN 19 NET.png')))
records=[];rawfont=[]
for k,row in enumerate(TABLES['6SP30']['rows']):
 if row['curve_model'] not in models:continue
 sp=splines[k];x0=int(np.floor(nx(px(11.8))));x1=int(np.ceil(nx(px(16.1))));cx=nx(px(13));cy=float(sp(cx));nb=(x0,max(0,int(np.floor(cy-14))),x1,int(np.ceil(cy+5)))
 native=a[nb[1]:nb[3],nb[0]:nb[2]].copy()
 Image.fromarray(native).resize((native.shape[1]*8,native.shape[0]*8),Image.Resampling.NEAREST).save(fresh(S.report(O+'NHAN TUNG MAY/'+row['curve_model']+'-raw8x.png')))
 # Đây là phép đo phân lớp nguồn; chưa sửa/mô phỏng vị trí đường mới.
 xx=np.arange(nb[0],nb[2]);yy=np.arange(nb[1],nb[3]);cent=np.array(sp(xx))
 delta=yy[:,None]-cent[None,:];lum=native.astype(float)@np.array([.299,.587,.114]);chroma=native.max(2).astype(float)-native.min(2).astype(float)
 text_candidates=(delta<-1.8)&(lum<210)
 curve_candidates=(abs(delta)<1.8)&(lum<210)
 rawfont.append(dict(model=row['curve_model'],native_box=nb,candidate_font_pixels=int(text_candidates.sum()),candidate_curve_pixels=int(curve_candidates.sum()),font_chroma_quantiles=np.percentile(chroma[text_candidates],[10,25,50,75,90]).tolist() if text_candidates.any() else [],curve_chroma_quantiles=np.percentile(chroma[curve_candidates],[10,25,50,75,90]).tolist() if curve_candidates.any() else [],font_luma_quantiles=np.percentile(lum[text_candidates],[10,25,50,75,90]).tolist() if text_candidates.any() else [],curve_luma_quantiles=np.percentile(lum[curve_candidates],[10,25,50,75,90]).tolist() if curve_candidates.any() else [],automatic_font_classification_not_accepted=True))
 qp=[]
 for q in [10.8,11.5,12,12.3,13,14,15,16,16.5,18,24,30]:
  x=nx(px(q));y=float(sp(x));yp=page_y(y);hc=float(np.interp(yp,yt[:,1],yt[:,0]));qp.append(dict(Q=q,source_H_from_rank_spline_m=hc,source_tangent_page=-float(sp.derivative()(x)),source_native_xy=[x,y]))
 records.append(dict(model=row['curve_model'],row=k+1,Q=TABLES['6SP30']['Q'],H_table=row['H'],all_8_current_points=[p for p in points if p['curve_model']==row['curve_model']],known_bad_Q=[p['Q_m3h'] for p in bad if p['curve_model']==row['curve_model']],native_label_box=nb,source_geometry_probe=qp,identity_confirmed_from_visible_source_label=True,table_fingerprint_only_support=True))

unknown=[p for p in points if p['curve_model']=='6SP30-8']
assert len(unknown)==8 and all(p['verification_status']=='CHƯA THỂ' and p['identity_uncertain'] for p in unknown)
out=dict(source_path=source,source_sha256=sha(source),current_path=current,current_sha256=sha(current),page=5,family='6SP30',known_bad_point_count=len(bad),known_model_count=len(models),models=records,all_19_source_rows=source_rows,axis=b,native_image_shape=list(a.shape),native_ctm=im.ctm.tolist(),native_pixel_pt=abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]),font_vs_curve_diagnostics=rawfont,excluded_unknown_8points=unknown,read_only=True,pdf_changed=False,source_fit_does_not_use_table_H=True,original_caption_text_retained=True)
Path(fresh(S.report(O+'CHUNG CU NGUON 29 MOC 13 MAY.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(S.report(O+'29 MOC LECH DA RO.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 fields=['page','curve_model','source_label','Q_m3h','H_table_m','H_curve_m','deviation_m','uncertainty_m','limit_m','verification_status'];w=csv.DictWriter(fp,fields,extrasaction='ignore');w.writeheader();w.writerows(bad)
E.close();assert sha(current)==out['current_sha256'] and sha(source)==out['source_sha256']
print('SP30_READ_ONLY_PROOF',S.report(O+'CHUNG CU NGUON 29 MOC 13 MAY.json'),flush=True)
for z in records:print(z['model'],z['known_bad_Q'],'join_probes',[(p['Q'],round(p['source_H_from_rank_spline_m'],3)) for p in z['source_geometry_probe'] if p['Q'] in [11.5,12,16.5,18]],flush=True)
print('FONT_DIAGNOSTICS',rawfont,flush=True)
