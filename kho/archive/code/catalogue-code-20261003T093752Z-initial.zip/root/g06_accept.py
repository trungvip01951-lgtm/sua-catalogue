from catwork import start,fresh
S,D,N=start()
from catfix import verify
from catfix.pdfdoc import render
from catfix.recipes import Job
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from g03_xmp_helper import check_xmp
import json,numpy as np,pikepdf,hashlib,io
from PIL import Image
import pymupdf as fitz

root=Path(S.report('G06'));st=json.loads((root/'final-state-v2.json').read_text(encoding='utf-8'))
src,dst=st['source'],st['final'];rect=(50,657,286,681)
job=Job(src,dst);job.edits=[dict(page=0,rect=rect,label='#51: FS-35-7-2.2 đúng model đầu bảng',kind='raster')]
out=dict(job_check=job.check(raster=True),outside_pixels=verify.outside_pixels(src,dst,{1:[rect]},dpi=200,thr=48,min_size=2),
         source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),destination_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest(),
         xmp=check_xmp(src,dst),checks=[])
for z in st['final_checks']:
    o=verify.ocr_check(dst,0,z['rect'],z['new'])
    out['checks'].append(dict(**z,ocr=o))
    print('Đọc lại',z['new'],o,flush=True)
out['full_model_ocr']=verify.ocr_check(dst,0,rect,'FS-35-7-2.2')
print('Đọc cả model',out['full_model_ocr'],flush=True)
out['unchanged_pages']=[]
for pi in (1,2,3):
    a=render(src,pi,dpi=200);b=render(dst,pi,dpi=200)
    same=a.shape==b.shape and np.array_equal(a,b)
    out['unchanged_pages'].append(dict(page=pi+1,pixels_exactly_equal=same))
with pikepdf.open(src) as a,pikepdf.open(dst) as b:
    out['metadata_equal']={str(k):str(v) for k,v in a.docinfo.items()}=={str(k):str(v) for k,v in b.docinfo.items()}
    image=[]
    for pg,(pa,pb) in enumerate(zip(a.pages,b.pages),1):
        aa=pa.Resources.XObject;bb=pb.Resources.XObject
        for key,obj in aa.items():
            if obj.get('/Subtype')==pikepdf.Name.Image:
                image.append(dict(page=pg,key=str(key),ok=key in bb and obj.read_raw_bytes()==bb[key].read_raw_bytes()))
    out['original_image_streams']=image
with fitz.open(src) as a,fitz.open(dst) as b:
    out['bookmarks_equal']=a.get_toc()==b.get_toc()
    norm=lambda l:{k:str(v) for k,v in l.items() if k!='xref'}
    out['links_equal']=[[norm(l) for l in p.get_links()] for p in a]==[[norm(l) for l in p.get_links()] for p in b]
ea,eb=Editor(src),Editor(dst);ra,rb=Raster(ea),Raster(eb)
ia,ib=ra.images(0)[0],rb.images(0)[0]
da,db=Image.open(io.BytesIO(ea.doc.stream_raw(ia.ref))),Image.open(io.BytesIO(eb.doc.stream_raw(ib.ref)))
out['native_image_preserved']=dict(source_dimensions=(ia.W,ia.H),final_dimensions=(ib.W,ib.H),
                                 source_colorspace=str(ia.d.get('ColorSpace')),final_colorspace=str(ib.d.get('ColorSpace')),
                                 same_jpeg_quantization=da.quantization==db.quantization,source_dpi=float(ia.dpi),final_dpi=float(ib.dpi))
out['kept_page4_content_stream_equal']=ea.doc.page_content(3)==eb.doc.page_content(3)
ea.close();eb.close();job.close()
out['source_preserved']=out['source_sha256']==st['source_sha256']
out['visual_review']=dict(model=True,failed_table_samples_not_applied=True,
                        note='Đã xem 2 mẫu bảng; mẫu không đúng nét chữ được giữ riêng trong review, trang 4 file cuối giữ nguyên.')
items=[(0,(26,632,303,682),'#51: ví dụ đúng model; giữ từng nhóm số và chú thích'),
       (1,(164,227,193,242),'#52: giữ KW do thiếu k chữ đậm cùng kiểu'),
       (2,(172,255,205,272),'#52: giữ KW do thiếu k chữ đậm cùng kiểu'),
       (3,(286,382,559,697),'#53: giữ nguyên bảng sau 2 mẫu chưa đẹp')]
verify.compare_sheet(src,dst,items,S.report('So sanh G06.png'),dpi=300)
for pi in range(4):verify.page_overview(src,dst,pi,fresh(root/f'so-sanh-dat-p{pi+1}.png'),dpi=130)
json.dump(out,open(fresh(root/'acceptance-v2.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
print('Tổng kiểm',out['job_check']['ok'],out['outside_pixels'],out['unchanged_pages'],flush=True)
