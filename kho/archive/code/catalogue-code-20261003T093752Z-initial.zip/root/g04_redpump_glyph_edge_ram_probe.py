"""Own-source small-glyph smoothing metrics only. No PDF/font installation."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np
from scipy.ndimage import gaussian_filter,label,binary_fill_holes
root=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
plan=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((plan/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
records=[]
def metrics(a):
 out=[]
 for level in [.085,.15,.2,.25,.3,.35,.4,.5]:
  m=a>=level;_,components=label(m);_,holes=label(binary_fill_holes(m)&~m);v,u=np.where(m)
  out.append(dict(level=level,components=components,holes=holes,box=[int(u.min()),int(v.min()),int(u.max()+1),int(v.max()+1)] if len(u) else None))
 return out
for rec in d['records']:
 a=np.array(rec['source_alpha']);padded=np.pad(a,8)
 smooth=gaussian_filter(padded,1.,mode='constant')
 z=np.clip(smooth+.75*(smooth-gaussian_filter(smooth,2.,mode='constant')),0,1)[8:-8,8:-8]
 # Preserve optical mass rather than increasing darkness to hide bad shape.
 ratio=a.sum()/z.sum();z=np.clip(z*ratio,0,1)
 records.append(dict(character=rec['character'],source_shape=list(a.shape),source_alpha=a.tolist(),proposed_alpha=z.tolist(),
  source_ink_area_pt2=float(a.sum()*.12**2),proposed_ink_area_pt2=float(z.sum()*.12**2),
  source_core_max=float(a.max()),proposed_core_max=float(z.max()),mass_normalization=float(ratio),
  source_topology=metrics(a),proposed_topology=metrics(z),source_uncertainty_pt=.24,
  smoothing_sigma_pt=.12,unsharp_sigma_pt=.24,unsharp_amount=.75,
  physical_scale=1.,new_font=False,font_donor='Bộglyph nhỏ đãchốt của CHÍNH Redpump'))
out=dict(source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],records=records,status='THĂM DÒ MATH CHỈ RAM, chưa dựng đườngbiên/chữ trongPDF',PDF_written=False)
Path(fresh(root/'CHU MEP NGUON THU MATH RAM V1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
for z in records:
 print(z['character'],'areas',round(z['source_ink_area_pt2'],5),round(z['proposed_ink_area_pt2'],5),'massScale',round(z['mass_normalization'],4),
  'topologies',[(x['level'],x['components'],x['holes']) for x in z['source_topology']],[(x['level'],x['components'],x['holes']) for x in z['proposed_topology']],flush=True)
