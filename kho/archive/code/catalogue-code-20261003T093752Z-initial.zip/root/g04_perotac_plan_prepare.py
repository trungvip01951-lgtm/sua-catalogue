from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json
from g04_perotac_audit_data import DATA
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
src=S.src(name);dst=S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
audit=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'))
out=Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC'))
doc=json.loads((audit/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'))
models={p['model'] for p in doc['confirmed_deviating_points']}
records=[]
for g in doc['graphs']:
 for c in g['curves']:
  if c['model'] not in models:continue
  r={k:v for k,v in c.items() if k!='native_path'}
  r['axis']=g['axis'];r['source_table_geometry']=next(x for x in DATA if x['family']==c['family'])
  records.append(r)
receipt=json.loads(Path(S.report('G04/NGHIEM THU BAN CUOI NET PDF THAT.json')).read_text(encoding='utf8'))
Path(fresh(out/'KHOI DONG VA DU LIEU 5 DIEM.json')).write_text(json.dumps(dict(source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),read_only=True,pdf_written=False,common_progress_written=False,prior_acceptance_receipt=receipt,records=records),ensure_ascii=False,indent=2),encoding='utf8')
for r in records:
 print('MODEL',r['model'],'page',r['page'],'seed',r.get('seed'),'caption',r.get('label_native_box'),'domain',r.get('source_domain'))
 print('AXIS',json.dumps(r['axis'],ensure_ascii=False))
 print('LAST2',json.dumps(r['points'][-2:],ensure_ascii=False))
 print('TABLE',r['source_table_geometry']['table_native_box'])
print('SOURCE',sha(src),'CURRENT',sha(dst),'OUT',out)
