"""ROOT docdoclap2endpointSP135 trenPDFthat; ko ghiPDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image
from catfix import charts,verify
from catfix.vector import Editor
import pymupdf as fitz
root=Path(S.report('G05/10SP135 HAI MOC CUOI/MAU 2'))
spec=json.loads((root/'TOA DO VA BANG NGUON.json').read_text(encoding='utf8'));saved=json.loads((root/'GHI PDF VA NGOAI VUNG.json').read_text(encoding='utf8'))
current,trial=spec['current_path'],saved['trial'];source=S.src('Perotac bơm giếng SP_compressed (bản mới).pdf')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)==spec['current_sha256'] and sha(trial)==saved['trial_sha256'] and sha(source)==spec['source_sha256']
targets={'10SP135-5':66.,'10SP135-7':93.};xt=np.array(spec['axis']['xticks']);yt=np.array(spec['axis']['yticks'])
E=Editor(trial,backend='fitz');P=E.page(10);out=[]
def y_at(path,x):
 prev=None
 for op,pts in path:
  if op=='m':prev=np.array(pts[0],float)
  elif op=='c':
   ctrl=np.vstack([prev,pts]);end=ctrl[-1]
   if prev[0]-1e-5<=x<=end[0]+1e-5:
    xx=min(max(x,float(prev[0])),float(end[0]));lo,hi=0.,1.
    for _ in range(65):
     t=(lo+hi)/2;v=sum(ctrl[k]*[1,3,3,1][k]*(1-t)**(3-k)*t**k for k in range(4))
     if v[0]<xx:lo=t
     else:hi=t
    return float(v[1])
   prev=end
  else:raise ValueError(op)
 raise ValueError(('outside domain',x))
for c in spec['curves']:
 matches=[]
 for oi,o in enumerate(P.objs):
  if o['op']!='S':continue
  path=P.object_pagepath(oi);a=charts.sample_path(path,n=600)
  if np.max(abs(a[0]-c['start_page']))<1e-4 and np.max(abs(a[-1]-c['end_page']))<1e-4:matches.append((oi,o,path,a))
 assert len(matches)==1;oi,o,path,a=matches[0]
 assert np.all(np.diff(a[:,0])>0) and np.all(np.diff(a[:,1])<0)
 assert abs(o['lw']-c['width_pt'])<1e-8 and max(abs(np.array(P.color_of(oi,'stroke'))-np.array(c['color_rgb'])/255))<1e-8
 assert o['dash'] is None or o['dash'][0]==[]
 assert np.max(abs(o['ctm']-np.eye(3)))<5e-8
 x=float(np.interp(180,xt[:,0],xt[:,1]));y=y_at(path,x);h=float(np.interp(y,yt[:,1],yt[:,0]));target=targets[c['model']];assert abs(h-target)<1e-4
 beginq=float(np.interp(a[0,0],xt[:,1],xt[:,0]));endq=float(np.interp(a[-1,0],xt[:,1],xt[:,0]));assert abs(beginq-c['Q_join'])<1e-5 and abs(endq-180)<1e-5
 err=max(float(np.max(abs(a[0]-c['start_page']))),float(np.max(abs(a[-1]-[x,np.interp(target,yt[:,0],yt[:,1])]))));assert err<1e-5
 widths=json.loads(Path(S.report('G05/10SP135 HAI MOC CUOI/DO MUC NGUON/DIEN TICH MUC VUONG GOC.json')).read_text(encoding='utf8'))
 width=next(z for z in widths['curves'] if z['model']==c['model']);fwhm=width['source_fwhm_quantiles_pt'];assert abs(o['lw']-width['new_width_from_source_opacity_area_pt'])<1e-8
 out.append(dict(model=c['model'],object=oi,Q=180,H_source_table=target,H_actual_PDF=h,error_m=h-target,actual_color=P.color_of(oi,'stroke'),lw=o['lw'],source_width_median_pt=float(np.median(fwhm)),source_width_range_pt=[min(fwhm),max(fwhm)],source_native_pixel_uncertainty_pt=.48,actual_domainQ=[beginq,endq],endpoints_error_pt=err,result='ĐẠT'))
allowed={11:[e['rect'] for e in saved['edits']]};outside=verify.outside_pixels(current,trial,allowed,dpi=200,thr=0,min_size=0,pad=.4);assert not outside
left=(spec['rect'][0],spec['rect'][1],min(c['start_page'][0] for c in spec['curves'])-.5,spec['rect'][3]);assert np.array_equal(np.asarray(verify.crop(current,10,left,600)),np.asarray(verify.crop(trial,10,left,600)))
tb=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/BANG DAY DU.json')).read_text(encoding='utf8'));tables=[]
for t in tb:
 same=np.array_equal(np.asarray(verify.crop(current,t['page']-1,t['rect'],450)),np.asarray(verify.crop(trial,t['page']-1,t['rect'],450)));assert same;tables.append(dict(family=t['family'],same450=True))
 if t['family']=='10SP135':verify.crop(source,t['page']-1,t['rect'],450).save(fresh(root/'SP135 BANG NGUON DOC LAP ROOT.png'))
axes=json.loads(Path(S.report('G05/KIEM TOAN TOAN BO/HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'));panels=[]
for ax in axes:
 if ax['family']=='10SP135':continue
 same=np.array_equal(np.asarray(verify.crop(current,ax['page']-1,ax['rect'],450)),np.asarray(verify.crop(trial,ax['page']-1,ax['rect'],450)));assert same;panels.append(dict(family=ax['family'],same450=True))
pres={}
with fitz.open(current) as a,fitz.open(trial) as b:
 links=lambda d:[[{k:str(v) for k,v in z.items() if k!='xref'} for z in p.get_links()] for p in d]
 pres=dict(info=a.metadata==b.metadata,xmp=a.get_xml_metadata()==b.get_xml_metadata(),toc=a.get_toc()==b.get_toc(),links=links(a)==links(b),sizes=[tuple(p.rect) for p in a]==[tuple(p.rect) for p in b])
 for p,q in zip(a,b):
  orig=[hashlib.sha256(a.xref_stream_raw(z[0])).hexdigest() for z in p.get_images(full=True)]
  news=[hashlib.sha256(b.xref_stream_raw(z[0])).hexdigest() for z in q.get_images(full=True)];assert set(orig)<=set(news)
 assert all(pres.values())
E.close()
verify.compare_sheet(current,trial,[(10,(715,341,763,386),'SOURCE | ACTUAL PDF')],fresh(root/'ROOT SO SANH 150dpi.png'),dpi=150,pad=(1,1))
Path(fresh(root/'NGHIEM THU DOC LAP ROOT 2END.json')).write_text(json.dumps(dict(trial=trial,trial_sha=sha(trial),current_sha=sha(current),source_sha=sha(source),actual_points=out,outside200=outside,metadata=pres,left_text_dashes_same600=True,all15tables= tables,other14panels=panels,source_images_preserved=True,visual='ROOT da soi PDF MAU HAI DUOI va toantrang: khong bongchu/netkhac; bangnguonanhmoi canxacnhan66/93truocfinal.',accepted=False),ensure_ascii=False,indent=2),encoding='utf8')
print('ROOT SP135 2 actual endpoints',out,'PASS',flush=True)
