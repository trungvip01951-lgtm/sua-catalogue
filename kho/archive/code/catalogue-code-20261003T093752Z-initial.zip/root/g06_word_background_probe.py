from catwork import start,fresh
S,D,N=start()
from catfix import verify
from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,cv2
root=Path(S.report('G06'));st=json.loads((root/'review'/'word-copy-build-2.json').read_text(encoding='utf-8'))
ac=json.loads((root/'review'/'word-copy-acceptance-stage.json').read_text(encoding='utf-8'))
print('GRID',ac['grid_checks'],'NUMBERS',ac['number_column_checks'],flush=True)
items=[];data=[]
for dpi in (400,500,600):
 for c in st['changes']:
  r=c['rect'];aa=np.array(verify.crop(st['prior'],3,r,dpi));bb=np.array(verify.crop(st['stage'],3,r,dpi))
  old=aa.min(axis=2)<230;grid=np.zeros(old.shape,np.uint8)
  for x in np.where(old.mean(axis=0)>.8)[0]:grid[:,max(0,x-4):min(grid.shape[1],x+5)]=1
  for y in np.where(old.mean(axis=1)>.85)[0]:grid[max(0,y-4):min(grid.shape[0],y+5),:]=1
  old=cv2.dilate(old.astype(np.uint8),np.ones((5,5),np.uint8)).astype(bool)&~grid.astype(bool)
  im=Image.fromarray(bb);dr=ImageDraw.Draw(im);rects=[]
  for p in st['placements']:
   if p['row']!=c['row']:continue
   nr=p['destination_rect'];pad=.6;s=dpi/72
   x0=max(0,int(np.floor((nr[0]-pad-r[0])*s)));x1=min(old.shape[1],int(np.ceil((nr[2]+pad-r[0])*s)))
   y0=max(0,int(np.floor((r[3]-nr[3]-pad)*s)));y1=min(old.shape[0],int(np.ceil((r[3]-nr[1]+pad)*s)))
   old[y0:y1,x0:x1]=False;dr.rectangle((x0,y0,x1,y1),outline='green');rects.append(dict(word=p['word'],box=(x0,y0,x1,y1)))
  yy,xx=np.where(old&(bb.min(axis=2)<254))
  for x,y in zip(xx,yy):dr.ellipse((x-2,y-2,x+2,y+2),outline='red')
  if len(xx):
   t=Image.new('RGB',(im.width,im.height+20),'white');ImageDraw.Draw(t).text((0,0),f'{dpi}dpi row{c["row"]}',fill='black');t.paste(im,(0,20));items.append(t)
  rr=dict(dpi=dpi,row=c['row'],size=bb.shape[:2],badpoints=[dict(x=int(x),y=int(y),gray=int(bb[y,x].min()),source_gray=int(aa[y,x].min()),page=(r[0]+x*72/dpi,r[3]-y*72/dpi)) for x,y in zip(xx,yy)],new_boxes=rects)
  data.append(rr);print('BACKGROUND',dpi,c['row'],rr['badpoints'],flush=True)
out=Image.new('RGB',(max(x.width for x in items),sum(x.height+6 for x in items)),'white');y=0
for im in items:out.paste(im,(0,y));y+=im.height+6
out.save(fresh(root/'review'/'word-copy-background-diagnostic.png'))
json.dump(data,open(fresh(root/'review'/'word-copy-background-diagnostic.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
