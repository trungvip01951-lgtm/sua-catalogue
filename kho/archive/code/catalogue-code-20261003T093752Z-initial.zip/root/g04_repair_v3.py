"""G04: miếng ảnh sát nét, giữ nguyên đường kẻ nguồn."""
from catwork import start, fresh
from pathlib import Path
import sys,json,hashlib,copy
import numpy as np
from PIL import Image
S,D,N=start()
from catfix.verify import crop

fi=int(sys.argv[1]);short=['Perotac','Redpump'][fi]
plan=json.loads(Path(S.report('G04/KE HOACH '+short+(' bo sung' if fi else '')+'.json')).read_text(encoding='utf8'))
d=plan['file'];assert not plan['fails']
prior={'sha256':json.loads(Path(S.report('G04/KIEM TRA LAN2 '+short+'.json')).read_text(encoding='utf8'))['destination_sha256']}
job=S.job(d['name']);R=job.R;cvs={};prepared=[]
def cv_for(page):
    if page not in cvs:
        im=R.images(page-1)[0]
        if im.has_stencil_mask:
            cv=R.render_canvas(page-1,(0,0,d['width'],d['height']),dpi=150)
        else:
            cv=R.canvas(im)
            job._canvases[('img',im.key,im.index)]=cv
        cvs[page]=cv
    return cvs[page]
def mapped(page,r):
    b=R.images(page-1)[0].page_bbox
    return [b[0]+x*(b[2]-b[0])/841.89 if i%2==0 else b[1]+x*(b[3]-b[1])/598.79 for i,x in enumerate(r)]
def sample(cv,hit,text):
    cc=R.components(cv,hit['box'],expect=len(text.replace(' ','')))
    assert len(cc)==len(text.replace(' ','')),(text,len(cc),hit['box'])
    assert ' ' not in text
    hs=[c['box'][3]-c['box'][1] for c in cc]
    bots=[c['box'][3] for c,ch in zip(cc,text) if ch not in R.DESC and ch not in R.LOWMARK]
    return dict(text=text,word=dict(text=text,box=hit['box']),base=float(np.median(bots)),comps=cc,size=float(np.percentile(hs,75)))
def scale_sample(s,target):
    ratio=target/s['size'];out=copy.deepcopy(s)
    out['base']=s['base']*ratio;out['size']=target
    for a,b in zip(s['comps'],out['comps']):
        x0,y0,x1,y1=a['box'];nw=max(1,int(round((x1-x0)*ratio)));nh=max(1,int(round((y1-y0)*ratio)))
        b['alpha']=np.asarray(Image.fromarray(a['alpha'].astype(np.float32),'F').resize((nw,nh),Image.Resampling.LANCZOS)).clip(0,1)
        b['box']=(int(round(x0*ratio)),int(round(y0*ratio)),int(round(x0*ratio))+nw,int(round(y0*ratio))+nh)
    return out
def source(page,rect,text,actual=False):
    cv=cv_for(page);rr=rect if actual else mapped(page,rect)
    hits=R.find(cv,text,box=cv.box(rr),scale=4,psm=7)
    hit=hits[0] if len(hits)==1 else dict(text=text,box=cv.box(rr))
    return sample(cv,hit,text)
sources=[source(2,(576,499,606,513),'3SS2'),source(3,(280,489,335,514),'3SS4')] if fi==0 else [
    source(2,(576,499,606,513),'3SL2'),source(3,(280,489,335,514),'3SL4'),
    source(8,(267,491,332,514),'4SL16'),source(4,(703,491,760,514),'4SL2'),
    source(7,(128,214,156,226),'50Hz')]
kw_extra=source(8,(116,42,134,51),'7.5')
dimension_extra=source(8,(717,319,738,327),'819')
plot_sources=[source(1,(510,466,538,474),'2SS0.7/32'),source(1,(690,414,724,423),'2.5SS1.5/12')] if fi==0 else [source(1,(507.2,463.8,531.0,468.8),'2SL0.7/32',actual=True),source(1,(687,412.2,716,417.5),'2.5SL1.5/12',actual=True)]

# Chỉ dùng các mẫu chữ đã đọc ở ô nguồn và có số nét khớp, bỏ ngân hàng OCR rộng.
for p in plan['plans']:
    cv=cv_for(p['page'])
    if fi==1 and p['page']==1:
        p['hit']['box']=cv.box(p['rect'])
    if p['action']=='replace':
        p['_sample']=sample(cv,p['hit'],p['old'])
dimension_samples=[p['_sample'] for p in plan['plans'] if p['task'] in [37,38,39,40,41,42]]+[dimension_extra]
kw_samples=[p['_sample'] for p in plan['plans'] if p['task']==131]+[kw_extra]
for p in plan['plans']:
    bank=None
    if p['action']=='replace':
        oldsample=p['_sample']
        if p['task'] in [43,44,45]:
            ss=[oldsample]+[scale_sample(s,oldsample['size']) for s in sources]
        elif p['task']==131:ss=[oldsample]+kw_samples
        elif p['task'] in [37,38,39,40,41,42]:ss=[oldsample]+dimension_samples
        elif p['task']==36:ss=[oldsample]+plot_sources
        else:ss=[oldsample]
        bank=R._bank_from_samples(ss)
        assert all(ch in bank['glyphs'] for ch in p['new'] if ch!=' '),(p['task'],p['new'],set(bank['glyphs']))
    prepared.append((p,bank))
    print('PREP',short,p['task'],p['page'],p['old'],'->',p['new'],flush=True)

source_hash=hashlib.sha256(Path(d['src']).read_bytes()).hexdigest()
patches={}
for p,bank in prepared:
    cv=cv_for(p['page']);hit=p['hit'];action=p['action'];prior_pixels=cv.work.copy()
    if action=='replace':R.replace_word(cv,hit,p['new'],bank,align=p['align'],erase_method='ring')
    elif action in ['drop_s','dot']:
        cc=R.components(cv,hit['box'],expect=len(p['old'].replace(' ','')))
        assert len(cc)==len(p['old'].replace(' ',''))
        R.erase_components(cv,[cc[-1]],method='ring')
        job.E.log.append(dict(page=p['page'],kind='raster-delete-last',old=p['old'],new=p['new'],box_px=hit['box']))
    elif action=='close_gap':
        cc=R.components(cv,hit['box'],expect=8);assert len(cc)==8
        gaps=[cc[i+1]['box'][0]-cc[i]['box'][2] for i in [0,1,3,4,5,6]]
        delta=max(1,int(round(cc[3]['box'][0]-cc[2]['box'][2]-np.median(gaps))))
        R.erase_components(cv,cc[3:],method='ring')
        for c in cc[3:]:R.stamp(cv,c,c['box'][0]-delta,c['box'][1])
        job.E.log.append(dict(page=p['page'],kind='raster-close-gap',old=p['old'],new=p['new'],delta_px=delta,box_px=hit['box']))
    else:raise ValueError(action)
    yy,xx=np.where(np.any(cv.work!=prior_pixels,axis=2));assert len(xx),(p['task'],p['page'])
    bb=(int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1))
    patches.setdefault(p['page'],[]).append(bb);p['patch_box']=bb
    job._add(p['page']-1,p['rect'],f'#{p["task"]} {p["label"]}: {p["old"]} -> {p["new"]}','raster')
    print('EDIT',short,p['task'],p['page'],p['old'],'->',p['new'],flush=True)

# Lưu miếng ảnh nhỏ, giữ nguyên toàn bộ ảnh nguồn / lớp logo.
for page,cv in cvs.items():
    for box in patches.get(page,[]):R._write_patch(cv,box,encoding='flate')
    cv.orig=cv.work.copy()

# Chỉ chuyển bản thử do chính phiên tạo, đã kiểm mã băm và đường dẫn tuyệt đối.
out=Path(d['dst']).resolve();root=Path(S.out_dir).resolve();src=Path(d['src']).resolve()
assert out.is_relative_to(root) and out!=src
assert hashlib.sha256(out.read_bytes()).hexdigest()==prior['sha256']
archive=Path(fresh(S.report('G04/BAN THU LAN2/'+out.name))).resolve()
assert archive.is_relative_to(root) and archive!=out
out.rename(archive)
log=Path(job.log_path)
if log.exists():
    Path(fresh(S.report('G04/BAN THU LAN2/'+log.name))).write_bytes(log.read_bytes())
job.save();job.close()
assert hashlib.sha256(Path(d['src']).read_bytes()).hexdigest()==source_hash
result=job.check(raster=True)
for p in plan['plans']:p.pop('_sample',None)
Path(fresh(S.report('G04/KIEM TRA LAN3 '+short+'.json'))).write_text(json.dumps(dict(src=d['src'],dst=d['dst'],source_sha256=source_hash,destination_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),result=result,plans=plan['plans']),ensure_ascii=False,indent=2,default=str),encoding='utf8')
job.evidence(fresh(S.report('G04/So sanh LAN3 '+short+'.png')),dpi=350)
print('FINAL',short,len(job.edits),'CHECK',result['ok'],'unexpected',result['unexpected'],'missing',result['missing'],flush=True)


