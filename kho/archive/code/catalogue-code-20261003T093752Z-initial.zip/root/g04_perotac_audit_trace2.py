from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_trace1.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
code=code.replace("E=Editor(src);R=Raster(E);allcurves=[];graphs=[]", "E=Editor(src);R=Raster(E);allcurves=[];graphs=[];COLUMN_CACHE={}")
code=code.replace(" m=mask[top:bottom+1,x];labels,n=ndimage.label(m);out=[]", " if x in COLUMN_CACHE:return COLUMN_CACHE[x]\n m=mask[top:bottom+1,x];labels,n=ndimage.label(m);out=[]")
code=code.replace(" return out\ndef trace", " out=[z for z in out if z['width']<=6]\n COLUMN_CACHE[x]=out\n return out\ndef trace")
code=code.replace("for rec,a in zip(DATA,axis):\n pi=", "for rec,a in zip(DATA,axis):\n COLUMN_CACHE={}\n pi=")
code=code.replace("mask=(cr>7)&(cb>9)&(lum>75)&(lum<244)","mask=(cr>3)&(cb>3)&(cr+cb>11)&(lum>105)&(lum<225)")
code=code.replace("x=int(labelx)-2", "x=int(labelx)+5")
code=code.replace("'LAN1.png'", "'LAN2.png'")
code=code.replace("' LAN1.png'", "' LAN2.png'")
code=code.replace('BANG QH DOC TU NGUON V2.json','BANG QH DOC TU NGUON V3.json')
code=code.replace('TRUC DA DOI CHIEU.json','TRUC DA DOI CHIEU LAN2.json')
code=code.replace('DO NET NGUON LAN1.json','DO NET NGUON LAN2.json')
code=code.replace("print('TRACE1'", "print('TRACE2'")
exec(compile(code,__file__,'exec'))
