from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix import verify
from catfix.recipes import Job
name='Perotac bơm giếng SP_compressed (bản mới).pdf'
j=Job(S.src(name),fresh(S.report('G05/HOAN THIEN/'+name)),
      log_path=fresh(S.report('G05/HOAN THIEN/'+name+'.log.json')))
proof=[]

def ref(p,r,dpi=300):return j.R.render_canvas(p,r,dpi=dpi)
def bank(cv,items):return j.R.glyph_bank(cv,words=[dict(text=t,box=cv.box(r)) for t,r in items])
def change(cv,p,old,new,r,b):
    parts=j.R.components(cv,cv.box(r),expect=len(old))
    assert len(parts)==len(old),(p,old,len(parts))
    assert all(c in b['glyphs'] for c in new)
    j.R.replace_word(cv,dict(text=old,box=cv.box(r)),new,b,align='center',erase_method='median')
    j._add(p,r,old+' → '+new,'raster-render')
    proof.append(dict(page=p+1,old=old,new=new,rect=r))

cvref=ref(4,(607,135,785,183))
matrix=[[23,22,21,19,18,15,11,7],[34,33,31,29,27,23,17,11],
        [46,44,42,39,36,31,23,14],[57,56,53,48,44,38,29,18],
        [68,57,63,58,53,46,34,21],[80,78,74,68,62,54,40,25]]
its=[]
for ii,nums in enumerate(matrix):
    y=177.91-ii*7.92
    for cc,v in enumerate(nums):
        x=612.73+cc*23.32;its.append((str(v),(x-6,y-3,x+6,y+3)))
b=bank(cvref,its)
change(ref(4,(625,139,647,153)),4,'57','67',(632,143.3,640,149.1),b)

cvref=ref(7,(710,391,746,417))
b=bank(cvref,[('1767',(713.2,401.1,727,406.9)),('2000',(713.2,393.4,727,399.0)),
              ('1649',(713.2,409.0,727,414.8)),('18.6',(730,401.1,742,406.9))])
change(ref(7,(712.5,400.4,727.8,407.3)),7,'1767','1827',(713.2,401.1,727,406.9),b)

cvref=ref(8,(585,89,783,98))
vals=[181,180,1750,162,147,133,119,100]
b=bank(cvref,[(str(v),(594.14+cc*25.45-7.5,90.55,594.14+cc*25.45+7.5,96.65)) for cc,v in enumerate(vals)])
change(ref(8,(636.5,89.7,654.5,97.0)),8,'1750','175',(638,90.55,652,96.65),b)

cvref=ref(6,(204,31,389,42));cv=ref(6,(362,31,389,42))
vals=[280,279,278,273,259,240,224,206,193,176,159,135,110,80]
b=bank(cvref,[(str(v),(211.24+cc*13.30-5.5,33.1,211.24+cc*13.30+5.5,39.3)) for cc,v in enumerate(vals)])
change(cv,6,'110','103',(365,33.4,375,39.4),b)
change(cv,6,'80','72',(378.7,33.4,386.0,39.4),b)

# Mẫu 6 ở cùng bảng vật liệu của trang9; điều chỉnh độ phân giải đọc mẫu
# để nét số có cỡ giống bảng trang1/4, không dùng phông hệ thống.
cv6=ref(8,(133.9,88.6,143.8,94.3),dpi=322)
s=bank(cv6,[('316',(134.1,88.8,143.6,94.1))])['samples'][0]
extra=dict(text='6',comps=[s['comps'][2]],base=s['base'],size=s['size'])
for p,r,items in [(0,(103,76,119,95),[('431',(106,87.5,115.8,93.2)),('304',(106,79,115.8,84.7))]),
                  (3,(97,77,112,95),[('431',(99.5,87.2,108.8,93)),('304',(99.5,79.5,109,85.5))])]:
    cv=ref(p,r)
    # Chép cả cụm316 với đúng khoảng cách/baseline nguồn, không ghép từng số khác cỡ.
    wholecv=ref(8,(133.9,88.6,143.8,94.3),dpi=322 if p==0 else 312)
    b=bank(wholecv,[('316',(134.1,88.8,143.6,94.1))])
    for old,rr in items:change(cv,p,old,'316',rr,b)

for p,left,source_x,rows in [(8,87.0,(124.3,151.4),[(88.3,94.4),(80.6,86.7)]),
                            (10,82.0,(119.4,146.1),[(90.9,97.0),(83.2,89.3)])]:
    cv=ref(p,(left-1,rows[-1][0]-.8,source_x[1]+2,rows[0][1]+.8))
    for y0,y1 in rows:
        source=cv.box((source_x[0],y0,source_x[1],y1))
        dest=cv.box((left,y0,left+source_x[1]-source_x[0],y1))
        j.R.copy_box(cv,source,(dest[0],dest[1]))
        box=(dest[0]+source[2]-source[0]+1,dest[1],cv.box((left,y0,source_x[1]+1,y1))[2],dest[1]+source[3]-source[1])
        bg,ink=j.R.bg_ink(cv.work,box)
        mask=np.zeros(cv.work.shape[:2],bool)
        mask[box[1]:box[3],box[0]:box[2]]=j.R.alpha_of(cv.work[box[1]:box[3],box[0]:box[2]],bg,ink)>.04
        j.R.erase(cv,mask=mask,dilate=0,color=bg)
        rr=(left,y0,source_x[1]+1,y1)
        j._add(p,rr,'#135 AISI316SS duy nhất, chép mẫu gốc cùng dòng','raster-render')
        proof.append(dict(page=p+1,old='①AISI431/304SS ②AISI316SS',new='AISI 316 SS',rect=rr))

onecv=ref(10,(211,120,262,130))
o=bank(onecv,[('10SP135-2',(212.2,120.8,260.4,128.6))])['samples'][0]
one=dict(text='1',comps=[o['comps'][0]],base=o['base'],size=o['size'])
b=j.R._bank_from_samples([one])
for p,rnum,ryear in [(0,(80,172,87,180.5),(88.5,171.5,115.2,180.3)),
        (3,(72.0,213.4,80.6,222),(82.0,213.5,107.3,222)),
        (8,(71.0,211.5,80.0,220),(81,211.3,104.8,220)),
        (10,(66,214.4,74.5,223.8),(75.5,214.0,99.5,223.0))]:
    rr=(rnum[0]-1,ryear[1]-1,ryear[2]+1,max(ryear[3],rnum[3])+1)
    cv=ref(p,rr)
    change(cv,p,'2','1',rnum,b)
    parts=j.R.components(cv,cv.box(ryear),expect=5)
    assert len(parts)==5
    j.R.erase_components(cv,[parts[-1]],method='median',dilate=1)
    j._add(p,ryear,'years → year, giữ nguyên bốn chữ đầu','raster-render')
    proof.append(dict(page=p+1,old='years',new='year',rect=ryear))

j.save();ck=j.check(raster=True)
print('G05 vùng render',ck['ok'],'unexpected',ck['unexpected'],'missing',ck['missing'],flush=True)
Path(fresh(S.report('G05/HOAN THIEN/KIEM TRA.json'))).write_text(json.dumps(dict(check=ck,proof=proof,edits=j.edits),ensure_ascii=False,indent=2,default=lambda x:float(x)),encoding='utf-8')
j.evidence(fresh(S.report('G05/HOAN THIEN/SO SANH.png')),dpi=250)
j.close()
