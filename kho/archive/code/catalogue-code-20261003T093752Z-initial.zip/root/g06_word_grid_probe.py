from catwork import start,fresh
S,D,N=start()
from catfix import verify
from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,cv2
root=Path(S.report('G06'));st=json.loads((root/'review'/'word-copy-build-2.json').read_text(encoding='utf-8'))
geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
out=[];items=[]
for dpi in (300,400,500,600):
 for i,g in enumerate(geo['grids']):
  r=g['rect'];aa=np.array(verify.crop(st['prior'],3,r,dpi));bb=np.array(verify.crop(st['stage'],3,r,dpi))
  gray=aa.min(axis=2);dark=gray<160;mask=np.zeros(dark.shape,bool)
  xs=np.where(dark.mean(axis=0)>.8)[0];ys=np.where(dark.mean(axis=1)>.8)[0]
  for x in xs:mask[:,max(0,x-1):min(mask.shape[1],x+2)]=True
  for y in ys:mask[max(0,y-1):min(mask.shape[0],y+2),:]=True
  delta=np.abs(aa.astype(int)-bb.astype(int)).max(axis=2);changed=(delta>0)&mask
  rec=dict(dpi=dpi,table=i+1,grid_columns=xs.tolist(),grid_rows=ys.tolist(),changed=int(changed.sum()),maxdelta=int(delta[changed].max()) if changed.any() else 0)
  rec['core']=[dict(gray_threshold=t,pixels=int((mask&(gray<t)).sum()),changed=int((changed&(gray<t)).sum()),maximum_delta=int(delta[changed&(gray<t)].max()) if (changed&(gray<t)).any() else 0) for t in (10,40,80,100,160,220,255)]
  rec['changed_columns']=[dict(x=int(x),page_x=r[0]+x*72/dpi,count=int(changed[:,x].sum()),min_source_gray=int(gray[:,x][changed[:,x]].min()),maxdelta=int(delta[:,x][changed[:,x]].max())) for x in np.where(changed.any(axis=0))[0]]
  rec['changed_rows']=[dict(y=int(y),page_y=r[3]-y*72/dpi,count=int(changed[y].sum()),min_source_gray=int(gray[y][changed[y]].min()),maxdelta=int(delta[y][changed[y]].max())) for y in np.where(changed.any(axis=1))[0]]
  out.append(rec);print('GRID',dpi,i+1,'core',rec['core'],'cols',rec['changed_columns'],flush=True)
  if dpi==600:
   m=Image.fromarray(bb.copy());a=np.array(m);a[changed]=(255,0,0);m=Image.fromarray(a)
   t=Image.new('RGB',(aa.shape[1]*2+20,aa.shape[0]+24),'white');ImageDraw.Draw(t).text((0,0),f'table{i+1}: source | changed grid pixels in red',fill='black');t.paste(Image.fromarray(aa),(0,24));t.paste(m,(aa.shape[1]+20,24));items.append(t)
 for i,r in enumerate(((288,382,309.5,695.3),(425.6,478,445.8,695.3))):
  aa=np.array(verify.crop(st['prior'],3,r,dpi));bb=np.array(verify.crop(st['stage'],3,r,dpi))
  same=bool(np.array_equal(aa,bb));out.append(dict(dpi=dpi,number_column=i+1,rect=r,equal=same));print('NUMBERS',dpi,i+1,same,flush=True)
if items:
 im=Image.new('RGB',(max(t.width for t in items),sum(t.height+10 for t in items)),'white');y=0
 for t in items:im.paste(t,(0,y));y+=t.height+10
 im.save(fresh(root/'review'/'word-copy-grid-diagnostic-600dpi.png'))
json.dump(out,open(fresh(root/'review'/'word-copy-grid-diagnostic.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
