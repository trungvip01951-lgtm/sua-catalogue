from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from pathlib import Path
import json,numpy as np
root=Path(S.report('G03'));state=json.loads((root/'build-state.json').read_text(encoding='utf-8'))
A=Editor(state['source']);B=Editor(state['destination'])
fields=('op','fill','stroke','lw','dash','gs','fill_cs','stroke_cs','clip','textclip')
rows=[]
for z in state['curves']:
    ao=A.page(z['page']-1).objs[z['oi']];bo=B.page(z['page']-1).objs[z['oi']]
    before={k:ao.get(k) for k in fields};after={k:bo.get(k) for k in fields}
    checks={k:before[k]==after[k] for k in fields}
    checks['ctm']=bool(np.max(np.abs(ao['ctm']-bo['ctm']))<1e-9)
    rows.append(dict(page=z['page'],model=z['model'],oi=z['oi'],before=before,after=after,checks=checks,ok=all(checks.values())))
json.dump(rows,open(fresh(root/'curve-styles.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
A.close();B.close()
print('Kiểu/màu/độ dày/ma trận/lớp đường cong:',sum(r['ok'] for r in rows),'/',len(rows))
