"""Actual black source glyphs with local background removed, one source bank. No PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'GLYPH HOAN CHINH HOP NGUON THU CONG.json').read_text(encoding='utf8'));plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=d['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cache={};records=[];pic=Image.new('RGB',(1050,12*112),'white');dr=ImageDraw.Draw(pic)
for i,z in enumerate(d['records']):
 key=(z['source_page'],tuple(z['source_canvas_rect']))
 if key not in cache:cache[key]=R.render_canvas(z['source_page']-1,z['source_canvas_rect'],dpi=600)
 cv=cache[key];x0,y0,x1,y1=z['source_render_box'];whole=cv.orig.astype(float);g=whole@np.array([.299,.587,.114]);bg=np.median(g,axis=1);p=g[y0:y1,x0:x1]
 al=np.clip((bg[y0:y1,None]-p)/np.maximum(bg[y0:y1,None],1),0,1);candidate=al>.085;components,n=label(candidate);sizes=[int((components==k).sum()) for k in range(1,n+1)];assert sizes,z['character'];idx=int(np.argmax(sizes))+1;keep=components==idx
 # Only the single genuine character's connected source ink survives; JPEG
 # flecks and the adjacent character's detached fringe are not part of glyph.
 al*=keep
 raw=Image.fromarray(whole[y0:y1,x0:x1].round().astype('uint8'));clean=Image.fromarray((255*(1-al)).round().clip(0,255).astype('uint8')).convert('RGB')
 dr.text((5,i*112+6),z['character']+' from '+z['source_word'],fill='blue');pic.paste(raw.resize((raw.width*2,raw.height*2),Image.Resampling.NEAREST),(260,i*112+10));pic.paste(clean.resize((clean.width*2,clean.height*2),Image.Resampling.NEAREST),(440,i*112+10));dr.text((650,i*112+20),f'source components {sizes}; kept {idx}',fill='blue')
 out=dict(z);out['source_alpha']=al.tolist();out['source_background_gray_by_row']=bg[y0:y1].tolist();out['source_other_components_excluded_area_px']=[n for k,n in enumerate(sizes,1) if k!=idx];out['source_character_component_kept']=idx;out['source_foreground_color_assumption']=[0,0,0];out['method']='Mực đen thực: alpha=(nềnnguồn−luminance)/nềnnguồn; nềnmedian hàng cảdải chữ nguồn. Giữcomponent nguồnliền củaglyph, khôngtạo đườngnétmới.';records.append(out)
photo=fresh(root/'GLYPH NGUON TACH NEN GIU NET DUNG CUNG FILE.png');pic.save(photo)
result=dict(source=src,source_SHA256=before[0],current_SHA256=before[1],records=records,source_proof_photo=photo,physical_scale=1.,one_bank_for_all13=True,prior_manual_no_background_bank_superseded=True,PDF_sample_written=False,new_font=False,status='GLYPH NGUỒN TÁCH NỀN: cầnROOT soi từngchữ; chưa vẽPDF/chấmđồhọa.',assumption='Mựcnhãn nguồn đen, nềnmedian dảichữ; ghi phép tách đểkiểm độc lập, khôngnhậnsốchữOCR hoặc fontArial.',font_source_uncertainty_pt=.24)
Path(fresh(root/'GLYPH NGUON TACH NEN GIU NET DUNG CUNG FILE.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)]
print('True source glyphs background-unmixed; noPDF; candidates',[(p['character'],p['source_other_components_excluded_area_px']) for p in records],flush=True)
