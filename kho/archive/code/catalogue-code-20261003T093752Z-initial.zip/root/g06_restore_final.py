from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
import json,hashlib
NAME='Aquaris FS_300dpi_75% (bản mới).pdf';root=Path(S.report('G06'))
st=json.loads((root/'final-state.json').read_text(encoding='utf-8'))
old=Editor(st['final']);old.save(fresh(root/'review'/'Ban truoc khoi phuc anh4.pdf'));old.close()
proof=Path(S.report('So sanh G06.png'))
Path(fresh(root/'review'/'So sanh chua khoi phuc anh4.png')).write_bytes(proof.read_bytes())
accepted=Editor(st['stage']);ar=Raster(accepted);im=ar.images(0)[0]
raw=accepted.doc.stream_raw(im.ref)
filters=accepted.doc.resolve(im.d.get('Filter'))
filters=[str(f) for f in filters] if isinstance(filters,list) else [str(filters)]
accepted.close()
# Bản nguồn làm nền; chỉ luồng ảnh trang 1 đã đạt được chuyển vào bằng API catfix.
job=S.job(NAME);R=job.R;original=R.images(0)[0]
R._overwrite_stream(original.ref,raw,filters)
job.edits=[dict(page=0,rect=[50,657,286,681],label='#51: FS-35-7-2.2, đúng từng nhóm số',kind='raster')]
job.E.log=[dict(page=1,task=51,kind='raster-native-copy',old='FS 15 15 1.5',new='FS-35-7-2.2',
                source_page=2,source_model='FS-35-7-2.2',font5_iou=st['font5_iou']),
           dict(task=52,result='CHƯA THỂ XÁC MINH',reason=st['missing52']),
           dict(task=53,result='CHƯA ĐẠT',reason=st['kept53']),
           dict(task=136,result='GIỮ NGUYÊN',reason=st['preserve136'])]
job.save()
st.update(final_edits=job.edits,final_sha256=hashlib.sha256(Path(job.dst).read_bytes()).hexdigest(),
          correct_restoration='Dựng từ PDF nguồn; chỉ chuyển luồng ảnh trang 1; trang 2–4 nguyên ảnh và lệnh nguồn.')
json.dump(st,open(fresh(root/'final-state-v2.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
assert hashlib.sha256(Path(job.src).read_bytes()).hexdigest()==st['source_sha256']
job.close()
print('Đã khôi phục ảnh trang 4 đúng từ nguồn',flush=True)
