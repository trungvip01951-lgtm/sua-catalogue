from catwork import start,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
q=Path(S.report('G08/ROOT PHAT HANH MOT PDF ANH V5 CA8 TRANG/ROOT KHOA MOT PDF ANH M1 V5.json'))
d=json.loads(q.read_text(encoding='utf8'))
print('LOCK_KEYS',list(d))
for k in ['source_file','canonical_file','clip_file','background','products']:
 print(k,json.dumps(d.get(k),ensure_ascii=False)[:6000])
print('JOBS',len(d['jobs8']))
print('JOB1',json.dumps(d['jobs8'][0],ensure_ascii=False)[:6000])
ram=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs\per_wc_continue_photo_union_v5_RAM_a1')
print('RAM_FILES',[p.name for p in ram.glob('*.png')])
