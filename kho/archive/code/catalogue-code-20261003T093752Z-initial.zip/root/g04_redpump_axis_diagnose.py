from catwork import start
S,D,N=start()
import json,numpy as np
from pathlib import Path
from catfix.vector import Editor
from catfix.raster import Raster
r=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
d=json.loads((r/'17 TRUC NGUON CANDIDATE.json').read_text(encoding='utf8'))
E=Editor(S.src('Redpump gieng SL_compressed (bản mới).pdf'),backend='fitz');R=Raster(E)
for name in ['4SL3','4SL6','4SL16']:
 z=next(p for p in d['records'] if p['family']==name);cv=R.render_canvas(z['page']-1,(29,240,382,530),dpi=600);g=cv.orig.astype(float)@np.array([.299,.587,.114]);hb=cv.to_px(0,z['H_frame_bottom_page'])[1]
 print(name,'hb',hb,'rect',cv.rect0)
 for y in range(int(hb-10),int(hb+11)):
  print(y,'dark150',int((g[y,400:2700]<150).sum()),'median',round(float(np.median(g[y,400:2700])),2))
E.close()
