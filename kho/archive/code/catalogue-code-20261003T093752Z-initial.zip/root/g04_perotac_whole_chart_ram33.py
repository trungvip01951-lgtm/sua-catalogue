"""Whole Perotac SA page8 RAM graphic plan: no PDF and no progress writes."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.pdfdoc import render
from scipy.interpolate import PchipInterpolator
from scipy.integrate import quad
from scipy.optimize import brentq
from pathlib import Path
import argparse
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
parser=argparse.ArgumentParser();parser.add_argument('--font-report',default='G04/BO KY TU SACH NGUON PEROTAC/CHU NHO BIEN CONG TRONG BAT DINH JPEG/12 GLYPH BIEN CONG NGUON RAM CHUA NGHIEM THU.json');parser.add_argument('--axis-report',default='G04/PHUONG AN DONG BO TOAN BIEU DO P08/CHU TRUC NGUON VA RAM CHI DOC/CHU SO TRUC VA TIEU DE DUONG BAO RAM CHUA NGHIEM THU.json');parser.add_argument('--ram-subfolder',default='RAM TRANG08 DONG BO DE ROOT VA DO HOA XEM');args=parser.parse_args()
assert args.font_report.startswith('G04/') and args.axis_report.startswith('G04/') and '/' not in args.ram_subfolder and '\\' not in args.ram_subfolder
root=base/args.ram_subfolder
load=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
plan=load(base/'PHUONG AN DONG BO P08 DE ROOT KIEM V4.json');geo=load(base/'KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json')
ticks=load(base/'DOI CHIEU VACH PHU NGUON THAT/VACH PHU34 VA TRUC CUC BO NGUON V4 DE ROOT KIEM.json')
dashdoc=load(base/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON/KHOANG THONG SO PHA VA NHIP NGUON V8 DE ROOT KIEM.json')
eta=load(base/'ETA4 DOAN C2 NGUON VA DAU LAN KHUNG/ETA4 BEZIER C2 VA558 DIEM NGUON CHUA CHOT.json')
fontpath=Path(S.report(args.font_report));axispath=Path(S.report(args.axis_report));fontdoc=load(fontpath);axisdoc=load(axispath)
measure=load(base/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json');step=measure['source_pixel_to_page_pt'];font={r['character']:r for r in fontdoc['glyphs']}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==plan['source_sha256'] and sha(S.result(name))==plan['current_sha256']
assert fontdoc['source_sha256']==plan['source_sha256']==axisdoc['source_sha256'] and fontdoc['current_sha256']==plan['current_sha256']==axisdoc['current_sha256']
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));source=cv.orig.copy()
box=[65,117,790,805];sc=16;W=(box[2]-box[0])*sc;H=(box[3]-box[1])*sc;canvas=Image.new('RGB',(W,H),'white');dr=ImageDraw.Draw(canvas)
xy=lambda p:((float(p[0])-box[0])*sc,(float(p[1])-box[1])*sc)
def line(points,color,width_pt):dr.line([xy(p) for p in points],fill=tuple(color),width=max(1,int(round(width_pt/step*sc))),joint='curve')
def rect(b,color,width_pt):line([(b[0],b[1]),(b[2],b[1]),(b[2],b[3]),(b[0],b[3]),(b[0],b[1])],color,width_pt)
def paths(ps,left,top,color):
    for p in ps:dr.polygon([xy((left+x,top+y)) for x,y in p['local_native_xy']],fill=tuple(color) if p['parent']<0 else 'white')
def word(literal,left,baseline):
    x=float(left);positions=[]
    for ch in literal:
        ff=font[ch];paths(ff['cleaned_contour_paths'],x,baseline-9.,[57,55,57]);positions.append(dict(character=ch,native_left=x,source_key=ff['source_key']));x+=ff['native_advance']
    return dict(literal=literal,native_left=left,native_baseline=baseline,native_advance=x-left,glyph_positions=positions)
gridx=[r['native_center'] for r in geo['main_observed_vertical_lines']];gridy=[r['native_center'] for r in geo['main_observed_horizontal_lines']];etax=[r['native_center'] for r in geo['source_eta_vertical_lines']];etay=[r['native_center'] for r in geo['source_eta_horizontal_lines']]
for x in gridx[1:-1]:line([(x,gridy[0]),(x,gridy[-1])],[225,225,225],.75)
for y in gridy[1:-1]:line([(gridx[0],y),(gridx[-1],y)],[225,225,225],.75)
for x in etax[1:-1]:line([(x,etay[0]),(x,etay[-1])],[225,225,225],.75)
for y in etay[1:-1]:line([(etax[0],y),(etax[-1],y)],[225,225,225],.75)
rect([gridx[0],gridy[0],gridx[-1],gridy[-1]],[93,93,93],.55);rect([etax[0],etay[0],etax[-1],etay[-1]],[93,93,93],.55)
titlebox=[geo['source_title_left_native_u'],gridy[0],gridx[-1],geo['source_title_bottom_native_v']]
dr.rectangle([xy(titlebox[:2]),xy(titlebox[2:])],fill='white');rect(titlebox,[93,93,93],.55)
# Actual secondary baselines and 34 printed-number stems; no imagined ticks.
line([(gridx[0],164),(gridx[-1],164)],[93,93,93],.55)
line([(gridx[0],692),(gridx[-1],692)],[93,93,93],.55)
for t in ticks['secondary_units_actual_source_stems']:
    p=t['source_tick_center_native'];axis=t['axis']
    if axis=='Q US':pts=[(p,159),(p,164)]
    elif axis=='Q IMP':pts=[(p,176),(p,180)]
    elif axis=='Q M3':pts=[(p,692),(p,696)]
    else:pts=[(746,p),(752,p)]
    line(pts,[93,93,93],.55)
# Source decorative side and bottom rules, separated from data/frame category.
line([(83,164),(83,gridy[-1])],[174,174,174],.25)
line([(gridx[0],725),(gridx[-1],725)],[174,174,174],.25)
qx=np.array([r['native_u'] for r in ticks['primaryQ_actual_local_grid_ticks']]);qt=np.array([r['Q_m3_h'] for r in ticks['primaryQ_actual_local_grid_ticks']]);ht=np.array([r['H_m'] for r in ticks['primaryH_actual_local_grid_ticks']]);hv=np.array([r['native_v'] for r in ticks['primaryH_actual_local_grid_ticks']]);ord=np.argsort(ht);ht=ht[ord];hv=hv[ord]
style=dashdoc['rounded_physical_style_proposal_pending_ROOT'];phase=style['phase_pt'];P=style['cycle_pt'];Ddash=style['ink_pt'];rows=[];allnodes=[];suffixes=[];legend=[]
for idx,row in enumerate(plan['rows']):
    qq=np.asarray(row['source_Q_m3_h'],float);hh=np.asarray(row['source_H_m'],float);uu=np.interp(qq,qt,qx);vv=np.interp(hh,ht,hv);p=PchipInterpolator(uu,vv,extrapolate=False);dp=p.derivative();ns=[]
    cuts=[float(x) for x in uu[1:-1]]
    def arc(x):return quad(lambda z:float(np.hypot(1,dp(z)))*step,float(uu[0]),float(x),points=[t for t in cuts if t<x],epsabs=1e-9)[0]
    total=arc(uu[-1])
    def inv(s):return float(uu[0]) if s<=0 else float(uu[-1]) if s>=total else brentq(lambda x:arc(x)-s,float(uu[0]),float(uu[-1]),xtol=1e-10)
    def cubics(a,b):
        pts=[a]+[t for t in cuts if a<t<b]+[b];out=[]
        for l,r in zip(pts,pts[1:]):
            delta=(r-l)/3.;out.append(dict(start=[l,float(p(l))],control1=[l+delta,float(p(l)+dp(l)*delta)],control2=[r-delta,float(p(r)-dp(r)*delta)],end=[r,float(p(r))]))
        return out
    subpaths=[]
    for k in range(7):
        s0=max(0.,phase+k*P);s1=phase+k*P+Ddash;a,b=inv(s0),inv(s1);pts=[(x,float(p(x))) for x in np.linspace(a,b,max(3,int((b-a)/.1)+1))];line(pts,[127,145,150],.90)
        subpaths.append(dict(kind='dash',cycle=k,arc_start_pt=s0,arc_end_pt=s1,actual_arc_pt=arc(b)-arc(a),first_start_clipped_at_literal_Q0=k==0,cubics_native=cubics(a,b)))
    solid_s=phase+7*P;solid_u=inv(solid_s);line([(x,float(p(x))) for x in np.linspace(solid_u,uu[-1],max(3,int((uu[-1]-solid_u)/.1)+1))],[127,145,150],.90)
    subpaths.append(dict(kind='solid',arc_start_pt=solid_s,arc_end_pt=total,cubics_native=cubics(solid_u,float(uu[-1]))))
    for q,h,x,y in zip(qq,hh,uu,vv):
        s=arc(x);visible=s>=solid_s or any(z['arc_start_pt']-1e-8<=s<=z['arc_end_pt']+1e-8 for z in subpaths[:-1]);vact=float(p(x));hact=float(np.interp(vact,hv[::-1],ht[::-1]));nd=dict(model=row['model'],Q_m3_h=float(q),H_source_m=float(h),native_u=float(x),native_v=float(y),RAM_geometry_H_m=hact,RAM_geometry_H_delta_m=hact-h,planned_visible_ink_at_node=bool(visible),not_actual_PDF_readback=True);ns.append(nd);allnodes.append(nd)
    center=row['proposed_end_suffix_center_native'];baseline=center[1]+4.5;label=word(row['curve_suffix_label'],center[0],baseline);suffixes.append(dict(model=row['model'],**label))
    line([(float(uu[-1])+2.1,float(vv[-1])),(center[0]-3.,center[1])],[180,180,180],.30)
    col=idx//5;rr=idx%5;left=140+col*(621.5/3);basey=744+rr*14;line([(left-14,basey-4.5),(left-4,basey-4.5)],[127,145,150],.90);legend.append(dict(model=row['model'],**word(row['model'],left,basey)))
    source_transition=next(t for t in dashdoc['local_source_tick_crosscheck_only_after_source_style_fit'] if t['model']==row['model'])['source_solid_half_coverage_u']
    rows.append(dict(model=row['model'],literal_source_Q_m3_h=qq.tolist(),literal_source_H_m=hh.tolist(),native_real_tick_nodes=[[float(x),float(y)] for x,y in zip(uu,vv)],QH_all_7_cubic_segments_native=cubics(float(uu[0]),float(uu[-1])),physical_subpaths=subpaths,source_solid_half_coverage_u=source_transition,RAM_new_local_ticks_solid_u=solid_u,RAM_vs_source_transition_native_px=solid_u-source_transition,numeric_nodes=ns,all_literal_nodes_Ram_geometry_match=True,no_extrapolation_or_QH_empty_cells_filled=True))
# One source-geometry efficiency curve, 4 C2 cubic segments, uncertain head kept.
for seg in eta['source_four_C2_bezier_segments_native']:
    c=np.asarray([seg['start'],seg['control1'],seg['control2'],seg['end']]);tt=np.linspace(0,1,max(16,int((c[-1,0]-c[0,0])/.1)))[:,None];pts=(1-tt)**3*c[0]+3*(1-tt)**2*tt*c[1]+3*(1-tt)*tt**2*c[2]+tt**3*c[3];line(pts,[127,145,150],.90)
# Every original axis literal stays at its source-native position and size.
for r in axisdoc['words']:paths(r['contour_paths'],r['source_native_box'][0],r['source_native_box'][1],r['source_RGB'])
ram600=canvas.resize(((box[2]-box[0])*4,(box[3]-box[1])*4),Image.Resampling.LANCZOS);ram150=canvas.resize((box[2]-box[0],box[3]-box[1]),Image.Resampling.LANCZOS)
ram600.save(fresh(root/'PEROTAC P08 TOAN BIEU DO RAM600 CHUA NGHIEM THU.png'));ram150.save(fresh(root/'PEROTAC P08 TOAN BIEU DO RAM150 CHUA NGHIEM THU.png'));del canvas
currentpix=render(S.result(name),7,dpi=150);currentpil=Image.fromarray(currentpix);current_native_size=(source.shape[1],source.shape[0]);resized_for_report=currentpil.size!=current_native_size
if resized_for_report:currentpil=currentpil.resize(current_native_size,Image.Resampling.LANCZOS)
full=currentpil.copy();full.paste(ram150,(box[0],box[1]));full.save(fresh(root/'PEROTAC P08 TOAN TRANG RAM150 CHUA NGHIEM THU.png'))
compare=Image.new('RGB',(ram150.width*2,ram150.height),'white');compare.paste(Image.fromarray(source[box[1]:box[3],box[0]:box[2]]),(0,0));compare.paste(ram150,(ram150.width,0));compare.save(fresh(root/'PEROTAC P08 NGUON VA RAM150.png'))
assert len(rows)==13 and len(allnodes)==104 and len(suffixes)==13 and len(legend)==13
assert max(abs(r['RAM_geometry_H_delta_m']) for r in allnodes)<1e-8
assert sha(S.src(name))==plan['source_sha256'] and sha(S.result(name))==plan['current_sha256']
doc=dict(stage='RAM GRAPHIC PROPOSAL ONLY; ROOT AND GRAPHIC REVIEW PENDING',source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_Perotac_X7_only=True,
    original_font_program_absent_no_name_invented=True,only_source_small_caption_glyphs_used_for_model_names=True,no_table_or_big_header_font_for_model_names=True,
    source_data_13_models_104_H_cells=True,QH_rows=rows,numeric104_RAM_geometry_only=allnodes,actual_PDF_or_visible_PDF_104_acceptance_not_run=True,
    source_secondary34_stems_retained=ticks['secondary_units_actual_source_stems'],main_Q_actual_local_ticks=ticks['primaryQ_actual_local_grid_ticks'],main_H_actual_local_ticks=ticks['primaryH_actual_local_grid_ticks'],
    grid_RGB=[225,225,225],grid_width_pt=.75,frame_RGB=[93,93,93],frame_width_pt=.55,secondary_rule_tick_width_pt=.55,curve_RGB=[127,145,150],curve_width_pt=.90,opacity=1.,
    dash_source169_caps_estimate=style,exact_original_JPEG_PDF_dash_phase='UNKNOWN',first_dash_clipped_at_literal_Q0_not_extrapolated=True,physical_dash_fits_applied_without_phase_adjustment_from_table=True,
    explicit13_suffixes=suffixes,explicit13_full_name_legend=legend,legend_max_native_baseline=800,model_source_caption_native_scale=1.,
    glyph_source_file=args.font_report,glyph_source_report_SHA256=sha(fontpath),axis_literal_source_file=args.axis_report,axis_source_report_SHA256=sha(axispath),axis_punctuation_source_low_resolution_and_graphic_review_pending=True,
    eta_source558_only=True,eta_clear_body_checks=eta['source_clear_body_checks'],eta_head11_centers_UNKNOWN=eta['head_source_uncertainty'],eta_4C2_segments=eta['source_four_C2_bezier_segments_native'],eta_values_numeric_UNKNOWN_no_table=True,
    edit_source_native_box=box,RAM_supersample_native=16,RAM_report600_output4x_source_not_actual_PDF_render=True,current_actual_render150_size=list(currentpix.shape[:2]),full_preview_outside_current150_render_resized_for_report=resized_for_report,
    curve_width_render_rounding_RAM_native_px=round(.90/step*sc)/sc,grid_width_render_rounding_RAM_native_px=round(.75/step*sc)/sc,
    outside_final_PDF_200dpi_not_run=True,current_and_source_unchanged=True,PDF_sample_count_whole_chart_method=0,no_PDF_font_or_progress_written=True,root_and_graphic_acceptance_pending=True)
Path(fresh(root/'RAM13 QH104 O VA ETA CHUA NGHIEM THU.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8');E.close()
print('RAM13QH104;visible planned',sum(n['planned_visible_ink_at_node'] for n in allnodes),'maxnumericdelta',max(abs(n['RAM_geometry_H_delta_m']) for n in allnodes),'source/current unchanged',flush=True)
print('CURVE TRANSITIONS',[(r['model'],round(r['RAM_vs_source_transition_native_px'],5)) for r in rows],flush=True)
