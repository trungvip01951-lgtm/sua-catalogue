from catwork import start,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.otext import OutlineText,procrustes
from g02_glyphs import chart_refs
from g01_fontbank import make_regular
from pathlib import Path
import pickle,numpy as np
NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf';E=Editor(S.result(NAME));T=OutlineText(E)
T.__dict__.update(pickle.loads(Path(S.report('G02/glyph-doc-chuan.pkl')).read_bytes()));T.E=E
refs=chart_refs(T)
for p,ois in [(9,[405,407,408,416,426,427,429,500]),(2,[358,360,362,364]),(4,[271,297]),(7,[289])]:
    for oi in ois:
        g=[g for g in T.page_glyphs(p) if g.oi==oi][0]
        print('GL',p+1,oi,g.char,g.ops,len(g.pts),g.bbox,flush=True)
        cand=[]
        for r in refs:
            if r['ops']!=g.ops or r['pts'].shape!=g.pts.shape:continue
            s,R,t,res=procrustes(r['pts'],g.pts,allow_rotation=True)
            ang=float(np.degrees(np.arctan2(R[1,0],R[0,0])))
            A=np.c_[r['pts'],np.ones(len(r['pts']))];M=np.linalg.lstsq(A,g.pts,rcond=None)[0]
            af=float(abs(A@M-g.pts).max())
            cand.append((res,r['char'],round(s,4),round(ang,2),af,M.tolist()))
        print(sorted(cand,key=lambda a:a[0])[:2],flush=True)
E.close()
