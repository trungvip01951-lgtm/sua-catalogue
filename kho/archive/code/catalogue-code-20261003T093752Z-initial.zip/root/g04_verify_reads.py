"""Đọc độc lập PDF đã lưu, kiểm cấu trúc / ảnh gốc / 84 chỗ sửa."""
from catwork import start,fresh
from pathlib import Path
import json,hashlib,concurrent.futures,datetime,re
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.verify import crop,structure_check,outside_pixels,_remove_rules,compare_sheet
from catfix.ocr import image_words
import numpy as np
from PIL import Image
import pymupdf as fitz
plans=[json.loads(Path(S.report('G04/KIEM TRA LAN3 Perotac.json')).read_text(encoding='utf8')),
       json.loads(Path(S.report('G04/KIEM TRA LAN5 Redpump.json')).read_text(encoding='utf8'))]
def norm(s):return re.sub(r'\s+','',s).upper()
def readone(pj,p):
    r=p['rect'];rect=(r[0]-1.8,r[1]-.7,r[2]+1.8,r[3]+.7)
    if p['task']==46:rect=(27,494,97,516)
    want='6SL' if p['task']==46 else p['new']
    a=np.asarray(crop(pj['dst'],p['page']-1,rect,dpi=600))
    g=(a.astype(np.float32)@np.array([.299,.587,.114])).clip(0,255).astype(np.uint8)
    config='-c tessedit_char_whitelist=0123456789.' if want.replace('.','').isdigit() else ''
    reads=[]
    for variant,psm in [(g,7),(_remove_rules(g),8),(_remove_rules(g),13)]:
        words=image_words(Image.fromarray(variant),psm=psm,config=config)
        text=' '.join(w['text'] for w in words);reads.append(text)
        if norm(text)==norm(want):break
    ok=any(norm(t)==norm(want) for t in reads)
    return dict(file=Path(pj['dst']).name,task=p['task'],page=p['page'],label=p['label'],old=p['old'],new=want,rect=rect,reads=reads,ocr_exact=ok,visual='CHỜ ĐỌC ẢNH')
tasks=[(pj,p) for pj in plans for p in pj['plans']]
records=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for rec in pool.map(lambda z:readone(*z),tasks):
        records.append(rec);print('READ',rec['file'][:7],rec['task'],rec['page'],rec['new'],rec['reads'],rec['ocr_exact'],flush=True)
checks=[]
for pj in plans:
    src,dst=pj['src'],pj['dst'];assert hashlib.sha256(Path(src).read_bytes()).hexdigest()==pj['source_sha256']
    assert hashlib.sha256(Path(dst).read_bytes()).hexdigest()==pj['destination_sha256']
    A=Editor(src);B=Editor(dst);RA=Raster(A);RB=Raster(B);ims=[]
    for pi in range(A.doc.n_pages):
        outims=RB.images(pi)
        hashes=[hashlib.sha256(B.doc.stream_raw(im.ref)).hexdigest() for im in outims]
        for im in RA.images(pi):
            h=hashlib.sha256(A.doc.stream_raw(im.ref)).hexdigest();assert h in hashes,(pi,im.ref)
            mates=[z for z,hh in zip(outims,hashes) if hh==h];same=[z for z in mates if np.allclose(z.page_bbox,im.page_bbox,atol=1e-8)]
            assert same,(pi,im.ref,'bbox')
            for key in ['SMask','Mask']:
                mask=im.d.get(key);m2=same[0].d.get(key)
                if isinstance(mask,tuple):assert A.doc.stream_raw(mask)==B.doc.stream_raw(m2),(pi,key)
            ims.append(dict(page=pi+1,width=im.W,height=im.H,sha256=h,raw_unchanged=True,bbox_unchanged=True))
    A.close();B.close()
    fA=fitz.open(src);fB=fitz.open(dst)
    assert fA.metadata==fB.metadata
    assert fA.get_xml_metadata()==fB.get_xml_metadata()
    assert fA.get_toc()==fB.get_toc()
    links=lambda doc:[[dict((k,str(v)) for k,v in a.items() if k!='xref') for a in p.get_links()] for p in doc]
    assert links(fA)==links(fB);fA.close();fB.close()
    allowed={}
    for p in pj['plans']:
        r=p['rect'];allowed.setdefault(p['page'],[]).append((r[0]-3,r[1]-3,r[2]+12,r[3]+3))
    outside=outside_pixels(src,dst,allowed,dpi=100,thr=48,min_size=2)
    assert not outside
    checks.append(dict(file=Path(dst).name,source_sha256=pj['source_sha256'],destination_sha256=pj['destination_sha256'],structure=structure_check(src,dst),outside=outside,original_images=ims,metadata_same=True,xml_metadata_same=True,bookmarks_same=True,links_same=True))
    short='Perotac' if 'Perotac' in dst else 'Redpump';rows=[]
    for p in pj['plans']:
        if p['task']==131 and 'kW' in p['label']:
            r=p['rect'];x0=29 if r[0]<400 else 462;y=(r[1]+r[3])/2
            if short=='Redpump':x0=29 if r[0]<400 else 459
            rows.append((p['page']-1,(x0,y-3.9,x0+348,y+3.9),p['label']))
    compare_sheet(src,dst,rows,fresh(S.report('G04/HANG MODEL '+short+'.png')),dpi=260,pad=(0,0))
out=dict(time=datetime.datetime.now().astimezone().isoformat(),checks=checks,records=records,ocr_exact=sum(r['ocr_exact'] for r in records),count=len(records))
Path(fresh(S.report('G04/NGHIEM THU DOC LAI.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8')
print('OCR exact',out['ocr_exact'],'/',out['count'],flush=True)
