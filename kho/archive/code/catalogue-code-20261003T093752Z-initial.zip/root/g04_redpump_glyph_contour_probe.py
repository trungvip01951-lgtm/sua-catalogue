"""Contour topology study from genuine source-alpha glyphs, no PDF sample."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np
from scipy.ndimage import binary_fill_holes,label,gaussian_filter
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'GLYPH NGUON CHON LAI GRAYSCALE CUNG FILE.json').read_text(encoding='utf8'));old=json.loads((root/'GLYPH THAT CUNG TRANG8 NGAN HANG UNG VIEN.json').read_text(encoding='utf8'));bank={p['character']:dict(p) for p in d['records']}
for ch in ['1','/']:
 p=next(p for p in old['records'] if p['character']==ch);q=dict(p);q['source_true_alpha']=q.pop('source_alpha');q['source_glyph_height_pt']=len(q['source_true_alpha'])*72/600;q['source_glyph_width_pt']=len(q['source_true_alpha'][0])*72/600;q['extract_dpi']=600;q['new_font']=False;bank[ch]=q
records=[]
for ch,z in bank.items():
 a=np.array(z['source_true_alpha']);smooth=gaussian_filter(a,.7);series=[]
 for threshold in [.35,.4,.45,.5,.55,.6]:
  b=np.pad(smooth>=threshold,1);_,n=label(binary_fill_holes(b)&~b);_,c=label(b);ys,xs=np.nonzero(b)
  series.append(dict(alpha_threshold=threshold,holes=int(n),components=int(c),area_px=int(b.sum()),bbox=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)] if len(xs) else None))
 print(ch,[(p['alpha_threshold'],p['holes'],p['components']) for p in series],flush=True);records.append(dict(character=ch,source_record=z,topology=series))
Path(fresh(root/'GLYPH BIEN MUC NGUON TOPOLOGY CHUA VE PDF.json')).write_text(json.dumps(dict(source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],records=records,source_mid_alpha_study=True,sigma=.7,physical_sigma_pt=.7*72/600,PDF_sample_written=False,new_font=False,status='Chỉ thăm dò biên mực thật để chọn cáchtái dựng khôngmấtlỗ/nét; không chỉnh glyphbằngnétngoài nguồn.'),ensure_ascii=False,indent=2),encoding='utf8')
