from catwork import start, fresh, row
from pathlib import Path
import json, hashlib
from PIL import Image, ImageDraw, ImageFont

S,D,N=start()
from catfix.vector import Editor
from catfix import verify
import pymupdf as fitz

checks=json.loads(Path(S.report('G08/THU LAN 1/KIEM TRA.json')).read_text(encoding='utf-8'))
accepted=json.loads(Path(S.report('G08/NGHIEM THU DOC LAP.json')).read_text(encoding='utf-8'))
assert len(checks)==len(accepted)==3
baseline=json.loads(Path(S.report('BAO CAO BUOC0.json')).read_text(encoding='utf-8'))
hashes=next(r['hashes_before'] for r in baseline if 'hashes_before' in r)
for path,h in hashes.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h, path

finalcheck=[]
for c in checks:
    assert c['check']['ok'] and not c['check']['unexpected'] and not c['check']['missing']
    assert any(a['file']==c['file'] and a['readback_all_pages'] for a in accepted)
    final=fresh(c['final'])
    E=Editor(c['trial'])
    E.save(final)
    E.close()
    structure=verify.structure_check(S.src(c['file']),final)
    unchanged=verify.outside_pixels(c['trial'],final,{},dpi=100)
    assert structure['ok'] and not unchanged
    source_final=verify.outside_pixels(S.src(c['file']),final,
                        {int(k):v for k,v in c['check']['regions'].items()},dpi=100)
    assert not source_final, source_final
    a=fitz.open(c['trial']); b=fitz.open(final)
    assert a.metadata==b.metadata and a.get_toc(simple=False)==b.get_toc(simple=False)
    assert len(a)==len(b)==8
    for pi in range(8):
        assert a[pi].get_text()==b[pi].get_text()
        assert a[pi].get_links()==b[pi].get_links()
    a.close();b.close()
    log=dict(group='G08',src=S.src(c['file']),dst=final,edits=c['edits'],
             accepted_trial=c['trial'],final_pixel_identical_to_trial=True)
    Path(fresh(S.report(c['file']+'.log.json'))).write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
    finalcheck.append(dict(file=c['file'],final=final,structure=structure,
        final_sha256=hashlib.sha256(Path(final).read_bytes()).hexdigest(),
        trial_pixel_difference=unchanged,source_pixels_outside_allowed=source_final))
Path(fresh(S.report('G08/NGHIEM THU BAN CUOI.json'))).write_text(json.dumps(finalcheck,ensure_ascii=False,indent=2),encoding='utf-8')

# Ảnh báo cáo: các bản chi tiết vẫn được lưu nguyên độ phân giải trong THU LAN 1.
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',22)
strips=[]
for c in checks:
    im=Image.open(S.report('G08/THU LAN 1/'+c['file']+'.png')).convert('RGB')
    if im.width>1800:
        im=im.resize((1800,round(im.height*1800/im.width)),Image.Resampling.LANCZOS)
    strip=Image.new('RGB',(1800,im.height+60),'white')
    ImageDraw.Draw(strip).text((12,15),c['file']+' — trước | sau',font=font,fill='black')
    strip.paste(im,(0,60));strips.append(strip)
sheet=Image.new('RGB',(1800,sum(i.height for i in strips)),'white')
y=0
for im in strips: sheet.paste(im,(0,y));y+=im.height
sheet.save(fresh(S.report('So sanh G08.png')))

methods={64:'Đo đường gốc Aquaris, làm tròn cột áp; thay số và nội suy đơn điệu qua từng điểm, giữ nét/màu gốc.',
         138:'Đo đường gốc tại Q120: H28,747m; chốt29m; thay đúng ô cùng phông.',
         139:'Sao chép kiểu chữ, tọa độ cột và đường kẻ từ dòng liền trên; chuẩn tốc độ các trang6–8.'}
new={64:'Cả ba bản: H30/29/28/25/21/16/10/4m tại Q0/5/10/15/20/25/30/35m³/h; đồng bộ đường.',
     138:'29m tại Q120m³/h, cả ba bản.',139:'Trang1–5:2900vòng/phút; trang6–8:1450vòng/phút.',
     61:'DN80; sơ đồ giải thích model gồm5 phần:80 WC 45 9 2.2.'}
rows=[]
for t in D['tasks']:
    if 'G08' not in t['groups'] or t['status']!='CAN_SUA':continue
    rows.append(row(t['id'],'; '.join(t['files']),t['page'],t['where'],
                    t['current'],new.get(t['id'],t['new']),
                    evidence='So sanh G08.png; G08/NGHIEM THU DOC LAP.json; G08/NGHIEM THU BAN CUOI.json',
                    method=methods.get(t['id'],'Thay đúng chữ/số bằng catfix, giữ phông, cỡ và căn theo chỗ gốc.')))
assert len(rows)==12 and all(r['result']=='ĐẠT' for r in rows)
dest=fresh(S.report('BAO CAO G08.md'))
verify.write_report(rows,dest,title='BÁO CÁO NHÓM G08 – Cắt rác WC (Aquaris, Perotac, Redpump)')
lines=['# BÁO CÁO NHÓM G08 – Cắt rác WC (Aquaris, Perotac, Redpump)','',
       'Đã lưu 3 PDF trong thư mục Nước thải. Nghiệm thu 24 trang; mọi sửa đổi nằm đúng vùng cho phép.','',
       '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
       '|---|---|---|---|---|---|---|---|']
for r in rows:
    lines.append('| '+' | '.join(str(r[k]).replace('|','/').replace('\n',' ') for k in
                   ['stt','file','page','old','new','method','result','evidence'])+' |')
lines+=['','Tổng: 12 việc · ĐẠT 12 · CHƯA ĐẠT 0 · CHƯA THỂ XÁC MINH 0.',
        '','Cần anh quyết: không; thực hiện theo quyền anh đã cấp.',
        '', 'Phát hiện thêm đã sửa: cả ba bản trang 5, hàng lít/phút dùng nhầm hệ số; đã đổi thành 0/500/1000/…/6000, tương ứng 0/30/60/…/360m³/h. Công thức: lít/phút = m³/h ×1000÷60.',
        '', '#64:Hai nguồn có đường khác nhau. Lấy đường Aquaris làm căn cứ; số đo và lựa chọn được lưu đầy đủ trong G08/SO DO DUONG CONG.json. Sai lệch từng điểm đường sau so với bảng dưới0,005m; đầu(0,30),cuối(35,4) đúng bảng.',
        '', '#162 GIỮ NGUYÊN:logo Italy Standard của Redpump; byte ảnh/ảnh mặt nạ các trang giữ nguyên. Ảnh bơm, liên kết, dấu trang, thông tin tài liệu, số trang và khổ trang được đối chiếu nguyên vẹn.',
        '', 'Chữ Speed nghĩa là tốc độ; r.p.m nghĩa là vòng/phút. kW là kilowatt,công suất; HP là mã lực.']
Path(dest).write_text('\n'.join(lines),encoding='utf-8')
S.progress('G08','XONG','12/12 ĐẠT;3 PDF/24 trang, đường #64 khớp bảng; sửa thêm hàng đổi lít/phút trang5; logo #162 giữ nguyên.')
print('G08:12/12 ĐẠT; ba bản cuối lưu đúng thư mục, cấu trúc đạt, điểm ảnh ngoài vùng sửa rỗng, nguồn nguyên vẹn.')
