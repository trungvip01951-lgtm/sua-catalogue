from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import numpy as np,json,hashlib,collections
from PIL import Image
from scipy.signal import find_peaks
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name)
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'))
RDIR=O.parent;d=json.loads((RDIR/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'))
E=Editor(src);R=Raster(E);out=[]
selected=sys.argv[1:] or ['3SS3','3SS4','4SA4','4SA6','6SA25','6SA35','6SA45']
for g in d['graphs']:
 if g['family'] not in selected:continue
 rec=next(z for z in DATA if z['family']==g['family']);im=max(R.images(g['page']-1),key=lambda z:z.W*z.H);rgb=R.canvas(im).orig;gray=rgb.astype(float)@np.array([.299,.587,.114]);item={'page':g['page'],'family':g['family'],'raw_shape':list(rgb.shape),'records':[]}
 family=g['family'];x0,y0,x1,y1=rec['plot_native_box'];targets=[c for c in g['curves'] if any(p['status']!='KHỚP MỐC' for p in c['points'])]
 for c in targets:
  if not c.get('seed'):continue
  sx=int(c['seed']['u']);sy=float(c['seed']['v']);yb=int(sy);rows=np.arange(yb-7,yb+8);sig=255-np.median(gray[rows,sx-1:sx+2],axis=1);peaks,_=find_peaks(sig,height=30,prominence=15)
  item['records'].append({'model':c['model'],'seed_source':[sx,sy],'local_rows':rows.tolist(),'source_darkness_median3cols':sig.tolist(),'peak_v_gray':[int(rows[k]) for k in peaks]})
 # Original source pixels only: no mask, tracing dots, color/contrast change.
 lb=[c.get('label_native_box') for c in targets if c.get('label_native_box')]
 if lb:
  l=min(b[0] for b in lb)-22;r=max(b[2] for b in lb)+38;t=min(b[1] for b in lb)-15;b=max(b[3] for b in lb)+18
  box=[l,t,r,b];fp=Path(fresh(O/f'g01_{family}_NHAN VA NOI NET PIXEL NGUYEN GOC.png'));Image.fromarray(rgb[t:b,l:r]).save(fp);item['label_crop_original_pixel_bbox']=box;item['label_crop_path']=str(fp);item['label_crop_sha256']=sha(fp)
 fp=Path(fresh(O/f'g01_{family}_DAU DUOI PIXEL NGUYEN GOC.png'));lx=int(g['axis']['flow_ticks'][-1]['u_native']);box=[lx-24,y0-10,lx+14,y1+4];Image.fromarray(rgb[box[1]:box[3],box[0]:box[2]]).save(fp);item['end_section_crop_original_pixel_bbox']=box;item['end_section_crop_path']=str(fp)
 out.append(item);print('GRAY SEEDS',family,[(q['model'],q['seed_source'],q['peak_v_gray']) for q in item['records']],flush=True)
fp=Path(fresh(O/'g01_TIEU CHI MUC XAM NGUON VA NHAN THUC.json'));fp.write_text(json.dumps({'source':src,'source_SHA':sha(src),'current':dst,'current_SHA':sha(dst),'no_PDF_written':True,'no_source_pixel_changed':True,'records':out},ensure_ascii=False,indent=2),encoding='utf8');E.close();print('OUTPUT',str(fp),sha(fp))
