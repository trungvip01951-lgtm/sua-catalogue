from catwork import start
S,D,N=start()
from pathlib import Path
import json
p=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 DU LIEU HINH HOC/g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json'))
d=json.loads(p.read_text(encoding='utf8'))
print('TOP_KEYS',list(d))
for g in d['groups']:
 print('GROUP',g['group'],'KEYS',list(g))
 for k,v in g.items():
  if 'witness' in k or 'point' in k or 'exclude' in k:print(k,'N',len(v) if isinstance(v,list) else None,'FIRST',json.dumps(v[0] if isinstance(v,list) and v else v,ensure_ascii=False)[:2500])
print('ADD55FIRST',json.dumps(d['additional_water_and_metal_witnesses'][0],ensure_ascii=False))
print('ORIGINAL27',type(d['original27_witnesses_read_again']).__name__,json.dumps(d['original27_witnesses_read_again'],ensure_ascii=False)[:3500])
print('EXCLUDE5',json.dumps(d['excluded_regions5'],ensure_ascii=False)[:2000])
print('GAP',json.dumps(d['actual_source_gap_proof_V5'],ensure_ascii=False)[:2000])
