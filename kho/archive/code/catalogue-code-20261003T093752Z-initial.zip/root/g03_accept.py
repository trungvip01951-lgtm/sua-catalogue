from catwork import start,fresh
S,D,N=start()
from catfix import verify,charts
from catfix.recipes import Job
from catfix.vector import Editor
from catfix.otext import OutlineText
from pathlib import Path
import json,hashlib,numpy as np,pikepdf
import pymupdf as fitz

root=Path(S.report('G03'));state=json.loads((root/'build-state.json').read_text(encoding='utf-8'))
src=state['source'];dst=state['destination']
job=Job(src,dst);job.edits=state['edits']
accept=dict(job_check=job.check(),source_sha256_before=json.loads((root/'inspection.json').read_text(encoding='utf-8'))['sha256'],source_sha256_after=hashlib.sha256(Path(src).read_bytes()).hexdigest(),destination_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest())
allowed={}
for e in state['edits']:
    r=e['rect'];allowed.setdefault(e['page']+1,[]).append([r[0]-1,r[1]-1,r[2]+1,r[3]+1])
accept['outside_pixels_200dpi']=verify.outside_pixels(src,dst,allowed,dpi=200)
print('Cấu trúc/vùng điểm ảnh',accept['job_check']['ok'],accept['outside_pixels_200dpi'],flush=True)

with pikepdf.open(src) as a,pikepdf.open(dst) as b:
    accept['metadata_equal']={str(k):str(v) for k,v in a.docinfo.items()}=={str(k):str(v) for k,v in b.docinfo.items()}
    ma=a.Root.get('/Metadata');mb=b.Root.get('/Metadata')
    accept['metadata_stream_equal']=(ma.read_bytes() if ma is not None else None)==(mb.read_bytes() if mb is not None else None)
    streams=[]
    for pg,(pa,pb) in enumerate(zip(a.pages,b.pages),1):
        xa=pa.Resources.get('/XObject',{});xb=pb.Resources.get('/XObject',{})
        for key,obj in xa.items():
            if obj.get('/Subtype')==pikepdf.Name.Image:
                streams.append(dict(page=pg,name=str(key),ok=key in xb and obj.read_raw_bytes()==xb[key].read_raw_bytes()))
    accept['image_streams']=streams
with fitz.open(src) as a,fitz.open(dst) as b:
    accept['bookmarks_equal']=a.get_toc()==b.get_toc()
    normalize=lambda link:{k:(list(v) if hasattr(v,'__len__') and not isinstance(v,(str,list,dict)) else v) for k,v in link.items() if k!='xref'}
    accept['links_equal']=[[normalize(v) for v in p.get_links()] for p in a]==[[normalize(v) for v in p.get_links()] for p in b]

numeric=[]
for z in state['checks']:
    o=verify.ocr_check(dst,z['page']-1,z['rect'],z['new'])
    numeric.append(dict(**z,ocr=o))
    print('Đọc lại',z['id'],z['page'],z['new'],o,flush=True)
accept['numeric']=numeric
E=Editor(dst);T=OutlineText(E);T.learn(range(10),dpi=400,verbose=False)
content=[]
for z in state['contents']:
    ms=T.find(1,z['name']);out=dict(**z,found=len(ms))
    if len(ms)==1:
        out['bbox_after']=list(ms[0].bbox);out['ok']=max(abs(ms[0].bbox[i]-z['new'][i]) for i in range(4))<0.02
    else:out['ok']=False
    content.append(out)
accept['contents']=content
special=[]
for z in state['special']:
    if z['new']=='HP':o=verify.ocr_check(dst,z['page']-1,z['rect'],'HP')
    elif z['new']=='S.r.l.':
        # OCR dấu chấm thường gộp vào chữ; xác minh thêm hình chấm có tồn tại độc lập.
        o=verify.ocr_check(dst,z['page']-1,z['rect'],'S.r.l.')
    else:o=verify.ocr_check(dst,z['page']-1,z['rect'],'diameter')
    special.append(dict(**z,ocr=o))
    print('Chữ chung',z['page'],z['new'],o['ok'],flush=True)
accept['special']=special

curvechecks=[]
sourceE=Editor(src)
for z in state['curves']:
    pg=z['page']; pi=pg-1;P=E.page(pi)
    axis=next(a for a in state['axes'] if a['page']==pg);x0,y0,x1,y1=axis['rect']
    ch=charts.Chart.from_ticks([(0,x0),(axis['maxQ'],x1)],[(0,y0),(axis['maxH'],y1)])
    pts=ch.to_data(charts.sample_path(P.object_pagepath(z['oi']),n=700));dev=ch.compare(pts,z['table_points'],tol_rel=0.02)
    for v in dev:v['tolerance']=max(1,0.02*abs(v['H_table']));v['ok']=v['diff'] is not None and abs(v['diff'])<=v['tolerance']
    points=np.array([z['table_points'][0],z['table_points'][-1]])
    eps=float(np.abs(np.array([pts[0],pts[-1]])-points).max())
    beforeP=sourceE.page(pi)
    col_ok=P.color_of(z['oi'],'stroke')==beforeP.color_of(z['oi'],'stroke')
    beforestate=beforeP.objs[z['oi']].get('state',{})
    afterstate=P.objs[z['oi']].get('state',{})
    curvechecks.append(dict(page=pg,model=z['model'],oi=z['oi'],points=dev,endpoint_max_error=eps,color_preserved=col_ok,state_preserved=beforestate==afterstate,ok=all(v['ok'] for v in dev) and eps<0.001 and col_ok and beforestate==afterstate))
accept['curves_saved_readback']=curvechecks
sourceE.close();E.close()

# Ảnh nguồn/sau của từng trang và từng cụm thay đổi để tự soi rõ nét.
for pi in range(10):verify.page_overview(src,dst,pi,fresh(root/f'so-sanh-p{pi+1}.png'),dpi=120)
numericitems=[(z['page']-1,z['rect'],f"#{z['id']}: {z['old']} -> {z['new']}") for z in state['checks']]
specialitems=[(z['page']-1,z['rect'],f"#34: {z['old']} -> {z['new']}") for z in state['special']]
contentitems=[(1,[min(z['old'][0],z['new'][0]),min(z['old'][1],z['new'][1]),max(z['old'][2],z['new'][2]),max(z['old'][3],z['new'][3])],f"#33: {z['name']}") for z in state['contents']]
curveitems=[(a['page']-1,a['rect'],f"Biểu đồ trang {a['page']}") for a in state['axes']]
verify.compare_sheet(src,dst,numericitems,fresh(root/'so-lieu.png'),dpi=350)
verify.compare_sheet(src,dst,specialitems,fresh(root/'chu-chung.png'),dpi=350)
verify.compare_sheet(src,dst,contentitems,fresh(root/'muc-luc.png'),dpi=250)
verify.compare_sheet(src,dst,numericitems+contentitems+specialitems+curveitems,fresh(S.report('So sanh G03.png')),dpi=220)

accept['source_preserved']=accept['source_sha256_before']==accept['source_sha256_after']
accept['numeric_all_ok']=all(v['ocr']['ok'] for v in numeric)
accept['contents_all_ok']=all(v['ok'] for v in content)
accept['curves_all_ok']=all(v['ok'] for v in curvechecks)
json.dump(accept,open(fresh(root/'acceptance.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
job.close()
print('TỔNG KIỂM', {k:v for k,v in accept.items() if k in ('source_preserved','numeric_all_ok','contents_all_ok','curves_all_ok','metadata_equal','bookmarks_equal','links_equal')},flush=True)
