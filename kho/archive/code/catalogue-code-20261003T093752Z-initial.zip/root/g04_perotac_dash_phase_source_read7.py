"""Đo chu kỳ/phần chuyển của13nhánh nguồn; đề xuất sửa kế hoạch, chưa PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.interpolate import PchipInterpolator
from scipy.integrate import quad
from scipy.optimize import brentq,least_squares
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'));root=folder/'DOI CHIEU NHIP DUT LIEN TUNG NHANH NGUON'
first=json.loads((root/'13 NHIP DUT LIEN DOC NGUON CHI KIEM.json').read_text(encoding='utf8'));cols=json.loads((root/'13 NHIP THEO MUC TUNG COT NGUON V2.json').read_text(encoding='utf8'));by={r['model']:r for r in first['curves']}
measure=json.loads((folder/'MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json').read_text(encoding='utf8'));plan=json.loads((folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V4.json').read_text(encoding='utf8'))
audit=json.loads(Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/KIEM TOAN CUOI DE ROOT DOC.json')).read_text(encoding='utf8'));g=next(z for z in audit['graphs'] if z['family']=='4SA16')
paths={r['model']:r.get('native_path') for r in g['curves']};paths.update({r['model']:r['observed_source_path'] for r in measure['prior_accepted_models_original_source_style_trace_only']})
step=measure['source_pixel_to_page_pt'];out=[];periods=[];dashes=[];gaps=[]
for r in cols['curves']:
    model=r['model'];xy=np.array([[p['u'],p['v']] for p in paths[model]]) if model!='4SA16/18' else np.array(by[model]['source_actual_trace_xy'])
    xy=xy[(xy[:,0]>=127)&(xy[:,0]<=278)];x=xy[:,0];y=xy[:,1];z=(x-200)/100
    coeff=np.polyfit(z,y,3);fit=least_squares(lambda c:np.polyval(c,z)-y,coeff,loss='soft_l1',f_scale=.25,max_nfev=1000);coeff=fit.x;der=np.polyder(coeff)
    arc=lambda a,b:quad(lambda u:float(np.hypot(1,np.polyval(der,(u-200)/100)/100))*step,float(a),float(b),epsabs=1e-9)[0]
    # First visible/last visible edges are JPEG readings, not original PDF cap coordinates.
    intervals=r['source_unmerged_ink_intervals'];full=[v for v in intervals if v[0]>=140 and v[1]<=271 and v[1]-v[0]>=8];long=[v for v in intervals if v[0]>=267 and v[0]<=283 and v[1]>=345]
    assert len(full)==6 and len(long)==1,(model,full,long);solid=long[0][0];starts=[v[0] for v in full]+[solid]
    ss=np.array([arc(starts[0],u) for u in starts]);index=np.arange(7);pp=np.polyfit(index,ss,1);period=float(pp[0]);resid=ss-np.polyval(pp,index)
    dl=[arc(lo-.5,hi+.5) for lo,hi in full];gg=[arc(hi+.5,b-.5) for (lo,hi),b in zip(full,starts[1:])]
    periods.append(period);dashes.extend(dl);gaps.extend(gg)
    out.append(dict(model=model,source_first6_full_dash_intervals_native=full,source_long_visible_interval_native=long[0],source_isolated_colour_fringe_runs=[v for v in intervals if 267<=v[0]<=283 and v[1]-v[0]<3],
       source_start_edge_native_u_6full_plus_long=starts,source_relative_arc_length_at_7starts_pt=ss.tolist(),source_6cycle_linear_fit_period_pt=period,source_6cycle_fit_max_residual_pt=float(max(abs(resid))),
       source_complete_dash_arc_lengths_pt=dl,source_gap_arc_lengths_pt=gg,source_center_smoothing_robust_cubic_only_geometry_not_H=True,
       source_observed_center_residual_native_px_median=float(np.median(abs(np.polyval(coeff,z)-y))),source_observed_center_residual_native_px_p90=float(np.percentile(abs(np.polyval(coeff,z)-y),90)),
       source_phase_zero_not_proved_from_JPEG_only=True,source_transition_first_visible_u=solid,source_transition_edge_uncertainty_native_px=1.0,
       actual_original_path_exists_only_inside_observed_points=True,source_table_not_used_for_trace_or_source_cycle_fit=True))
period=float(np.median(periods));length=float(np.median(dashes));gap=period-length
# Planning cross-check uses each printed neighbour tick directly; no whole-axis fit.
xt=np.array([t['u_native'] for t in g['axis']['flow_ticks']]);qt=np.array([t['litre_per_minute']*.06 for t in g['axis']['flow_ticks']]);ht=np.array([t['H_m'] for t in g['axis']['H_grid_calibration']['ticks']]);vt=np.array([t['v_native'] for t in g['axis']['H_grid_calibration']['ticks']])
proposal=dict(physical_period_pt=round(period,2),dash_length_pt=round(length,2),gap_length_pt=round(gap,2),original_exact_PDF_dash_state_unavailable=True,phase_zero_only_proposal_pending_source_frame_contact_review=True)
for r in out:
    row=next(v for v in plan['rows'] if v['model']==r['model']);q=np.array(row['source_Q_m3_h']);h=np.array(row['source_H_m']);uu=np.interp(q,qt,xt);vv=np.interp(h,ht,vt);p=PchipInterpolator(uu,vv,extrapolate=False);dp=p.derivative()
    speed=lambda u:float(np.hypot(1,dp(u)))*step
    ar=lambda u:quad(speed,float(uu[0]),float(u),points=[float(t) for t in uu[1:-1] if t<u],epsabs=1e-9)[0]
    target=7*proposal['physical_period_pt'];solid_u=brentq(lambda u:ar(u)-target,float(uu[0]),float(uu[-1]),xtol=1e-10)
    r['proposed_common_cycle_solid_start_u_on_new_literal_curve']=solid_u;r['new_literal_local_tick_transform_node_xy']=[[float(x),float(y)] for x,y in zip(uu,vv)]
    r['proposed_vs_source_first_visible_ink_delta_native_px']=solid_u-r['source_transition_first_visible_u']
    r['same_cycle_source_edge_within_one_native_px']=abs(r['proposed_vs_source_first_visible_ink_delta_native_px'])<=1
    r['not_actual_PDF_acceptance']=True
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==plan['source_sha256'] and sha(S.result(name))==plan['current_sha256']
obj=dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_from_Perotac_only=True,
         source_13periods_pt=periods,source_median_period_pt=period,source_median_dash_arc_pt=length,source_median_direct_gap_arc_pt=float(np.median(gaps)),
         source_cycle_minus_dash_gap_proposed_pt=gap,source_period_range_pt=[float(min(periods)),float(max(periods))],source_edges_uncertain_native_px=1.,
         replacement_of_V3_dash_proposal_not_locked=proposal,source_transition_not_V3_confirmed=True,curves=out,
         planning_Q_tick_transform_uses_local_actual_printed_ticks=True,planning_H_tick_transform_uses_local_actual_printed_ticks=True,
         original_phase_zero_exactly_unavailable=True,whole_axis_fit_only_crosscheck_not_draw_input=True,PDF_or_font_or_progress_written=False)
Path(fresh(root/'13 CHU KY CUNG NGUON VA DE XUAT V5 CHUA KHOA.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Đối chiếu nhịp đứt–liền nguồn từng nhánh

**V3 chuyển liền sớm hơn mực nguồn; không dùng V3 để vẽ. Hồ sơ này vẫn là nghiên cứu, chưa khóa nhịp, chưa PDF.**

Mỗi nhánh có bảy đoạn đứt nhìn thấy (đoạn đầu bị trục trái cắt), sau đó một đoạn dài qua vùng tên đến x370. Đo từ sáu đoạn đầy đủ và đoạn dài, khóa danh tính theo nhãn/đường thật; không dùng H bảng để chọn nét hay chỉnh pha. /9 và /18 có 1–2 cột màu rời trong khe cuối, giữ RGB/ảnh như nguồn; không nối các cột đó để giả vờ khe biến mất.

Vị trí sau đây là **cột mực màu đầu tiên quan sát** của đoạn dài, có bất định khoảng 1 pixel do JPEG150dpi, không phải tọa độ cap (đầu nét) vector nguồn. Pha0 không thể chứng minh tuyệt đối khi chỉ còn JPEG và đường ở khung trái bị khung đè. Phép fit (khớp) nguồn chỉ dùng làm sạch dao động tâm ảnh để đo chiều dài cung; không lấy hệ số fit trục toàn miền để căn104neo.

| Model | Bắt đầu mực dài x nguồn | Chu kỳ nguồn (pt) | Chuyển đề xuất x trên đường mới | Lệch nguồn (pixel) |
|---|---:|---:|---:|---:|
'''
for r in out:md+=f"| {r['model']} | {r['source_transition_first_visible_u']} | {r['source_6cycle_linear_fit_period_pt']:.5f} | {r['proposed_common_cycle_solid_start_u_on_new_literal_curve']:.5f} | {r['proposed_vs_source_first_visible_ink_delta_native_px']:+.5f} |\n"
md+=f"\nChu kỳ trung vị13nhánh: **{period:.6f}pt**; độ dài đoạn mực trung vị: **{length:.6f}pt**; khe đo trực tiếp trung vị: **{np.median(gaps):.6f}pt**. Tổng hai trung vị riêng không bắt buộc bằng trung vị chu kỳ vì alias (khử răng cưa) và lượng tử pixel ở đầu nét. Đề xuất bộ vật lý chung **{proposal['dash_length_pt']:.2f}/{proposal['gap_length_pt']:.2f}pt**, chu kỳ **{proposal['physical_period_pt']:.2f}pt**, thay7,26/2,94cũ. Đây là đề xuất cần ROOT/đồ họa xét, chưa chốt.\n"
md+='''
Những chênh của đầu chuyển còn phải xét ảnh/source edge uncertainty (bất định biên nguồn), không tự kéo nhịp đến nơi có điểm bảng. Mã thử vẽ sẽ giữ104ô bằng từng vạch thật lân cận; 104tâm nét/chữ/lưới/đầucuối đều cần đọc lại PDF thật. Các vạch phụ cần định vị trước khi dựng.

Các ảnh từng nhánh `*DAU VA NOI NGUON PHONG3LAN.png` giữ nguyên nguồn. `13 NHIP THEO MUC TUNG COT NGUON V2.json` giữ7RGBmỗi cột và mọi cột trống. Phương pháp tích phân màu ở hồ sơ trước đã loại vì nối qua khe thật; không dùng trường ứng viên chuyển của nó để vẽ. Chưa ghi bản giao, phông hay tiến độ.
'''
for old,new in {'trung vị13':'trung vị 13','JPEG150':'JPEG 150','căn104':'căn 104','thay7':'thay 7','giữ104':'giữ 104','104tâm':'104 tâm','104ô':'104 ô','giữ7RGB':'giữ 7 RGB','Pha0':'Pha 0'}.items():md=md.replace(old,new)
Path(fresh(root/'13 CHU KY CUNG NGUON VA DE XUAT V5 CHUA KHOA.md')).write_text(md,encoding='utf8')
print('SOURCE MED PERIOD/DASH/GAPDIRECT',period,length,np.median(gaps),'PROPOSE',proposal,flush=True)
for r in out:print(r['model'],'SOURCE',r['source_transition_first_visible_u'],'NEW',r['proposed_common_cycle_solid_start_u_on_new_literal_curve'],'DELTA',r['proposed_vs_source_first_visible_ink_delta_native_px'],flush=True)
