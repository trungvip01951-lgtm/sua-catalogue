"""Threshold sensitivity of exact local source glyphs; read only."""
from catwork import start
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from pathlib import Path
from g04_perotac_whole_pdf_tools46 import read
import numpy as np
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
doc=read(base/'CHU TRUC NGUON VA RAM CHI DOC/DON VI DAU CHAM DAU GACH CHEO VA i NGUON V2/CHU TRUC DAU NHO DOC RIENG V2 RAM CHUA NGHIEM THU.json')
regions={'Q US 10':[('0',[12,2,19,11])],'Q US 30':[('0',[12,2,19,11])],
 'H FEET 200':[('0-first',[5,2,11,11]),('0-second',[10,2,17,11])],
 'Q LMIN 150':[('5',[11,0,17,10]),('0',[16,0,23,10])],
 'Q LMIN 250':[('0',[16,0,23,10])],'Q LMIN 350':[('0',[16,0,23,10])],
 'M3 UNIT':[('3-raised',[11,0,15,6]),('slash',[12,3,17,10]),('h',[16,1,23,10])],
 'ETA UNIT':[('t',[9,3,12,12]),('a',[12,5,18,12]),('upper-oval',[22,3,26,8]),('lower-oval',[26,7,31,12]),('percent-all',[22,3,31,12]),('left-parenthesis',[18,3,22,14]),('right-parenthesis',[30,3,35,14])]}
E=Editor(S.src(name),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(7),key=lambda im:im.W*im.H))
for key,rs in regions.items():
    word=next(w for w in doc['words'] if w['key']==key);b=word['source_native_box'];al=R.alpha_of(cv.orig[b[1]:b[3],b[0]:b[2]],255,np.array(word['source_RGB']))
    for role,box in rs:
        a=al[box[1]:box[3],box[0]:box[2]];up=cv2.resize(np.pad(a,1),((a.shape[1]+2)*64,(a.shape[0]+2)*64),interpolation=cv2.INTER_LINEAR)
        out=[]
        for t in [.25,.30,.35,.40,.45,.50]:
            m=up>=t;co,hi=cv2.findContours(m.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
            good=[i for i,c in enumerate(co) if cv2.contourArea(c)/64**2>.04]
            out.append((t,round(m.sum()/64**2,3),round((m.sum()/64**2/a.sum()-1)*100,1),sum(hi[0,i,3]<0 for i in good),sum(hi[0,i,3]>=0 for i in good)))
        print(key,role,'alphaMass',round(float(a.sum()),3),'LEVEL AREA DELTA% COMP HOLE',out,flush=True)
E.close()
