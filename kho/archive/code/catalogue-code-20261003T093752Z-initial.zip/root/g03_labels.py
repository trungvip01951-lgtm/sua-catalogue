from catwork import start, fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.otext import OutlineText
from pathlib import Path
import json
E=Editor(S.src('Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf')); T=OutlineText(E);T.learn(range(10),dpi=400,verbose=False)
out={}
for pi in range(2,10):
    groups={}
    for g,ch,sim,sid,res in T.similarity_decode(pi,(205,190,270,420)):
        if g.bbox[2]-g.bbox[0] > 15 or g.bbox[3]-g.bbox[1]>15: continue
        col=E.page(pi).color_of(g.oi,'fill')
        if col is None or col[0]>0.6 or col[1]>0.6 or col[2]<0.4: continue
        groups.setdefault(g.oi,[]).append(dict(char=ch,bbox=g.bbox,res=res,style=sid,oi=g.oi,color=col))
    rows=[]
    for oi,gs in groups.items():
        gs.sort(key=lambda v:v['bbox'][0])
        rows.append(dict(oi=oi,text=''.join(v['char'] for v in gs),bbox=[min(v['bbox'][0] for v in gs),min(v['bbox'][1] for v in gs),max(v['bbox'][2] for v in gs),max(v['bbox'][3] for v in gs)],glyphs=gs))
    rows.sort(key=lambda v:-v['bbox'][3]);out[pi+1]=rows
    print('PAGE',pi+1,[(r['oi'],r['text'],[round(v,1) for v in r['bbox']]) for r in rows],flush=True)
json.dump(out,open(fresh(Path(S.report('G03'))/'labels.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
