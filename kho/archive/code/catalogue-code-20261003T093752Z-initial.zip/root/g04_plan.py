from catwork import start, fresh
from pathlib import Path
import sys, json, numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from catfix.verify import crop

descs=json.loads(Path(S.report('G04/duong-dan.json')).read_text(encoding='utf-8'))
fi=int(sys.argv[1]);d=descs[fi];E=Editor(d['src']);R=Raster(E)
cvs={}; plans=[]; fails=[]
def cv_for(page):
    pi=page-1
    if pi not in cvs:
        im=R.images(pi)[0]
        cvs[pi]=R.render_canvas(pi,(0,0,d['width'],d['height']),dpi=300) if im.has_stencil_mask else R.canvas(im)
    return cvs[pi]
def mapped(page,r):
    b=R.images(page-1)[0].page_bbox
    return [b[0]+x*(b[2]-b[0])/841.89 if i%2==0 else b[1]+x*(b[3]-b[1])/598.79 for i,x in enumerate(r)]
def add(task,page,old,new,rect,learn=None,align='center',action='replace',label='',actual=False):
    cv=cv_for(page); rr=rect if actual else mapped(page,rect)
    lr=(learn if actual else mapped(page,learn)) if learn else rr
    if action=='dot':
        comps=R.components(cv,cv.box(rr),expect=1)
        if len(comps)!=1: raise ValueError(('dot',len(comps),rr))
        hit=dict(text='.',box=comps[0]['box'],line_text='6SL.')
    else:
        hits=R.find(cv,old,box=cv.box(rr),scale=4,psm=7)
        if len(hits)!=1 and old.replace('.','').isdigit():
            words=R.ocr(cv,cv.box(rr),scale=5,psm=10,config='-c tessedit_char_whitelist=0123456789.')
            if len(words)==1 and words[0]['text']==old:
                cc=R.components(cv,words[0]['box'],expect=len(old))
                if len(cc)==len(old):
                    box=(min(c['box'][0] for c in cc)-1,min(c['box'][1] for c in cc)-1,max(c['box'][2] for c in cc)+1,max(c['box'][3] for c in cc)+1)
                    hits=[dict(text=old,box=box,line_text=old,words=words,n_glyphs=len(cc))]
        if len(hits)!=1:
            fail=dict(task=task,page=page,old=old,new=new,rect=rr,hits=hits,ocr=R.ocr(cv,cv.box(rr),scale=4,psm=7))
            fails.append(fail); print('FAIL',task,page,old,fail['ocr'],flush=True); return
        hit=hits[0]
    p=dict(task=task,page=page,old=old,new=new,rect=cv.rect(hit['box']),search=rr,learn=lr,align=align,action=action,label=label,hit=hit)
    plans.append(p); print('OK',task,page,old,'->',new,[round(x,2) for x in p['rect']],flush=True)

if fi==0:
    add(35,1,'2SD','2SS',(27,391,46,401),(27,300,178,425),align='left')
    add(35,1,'2.5SD','2.5SS',(27,382,53,393),(27,300,178,425),align='left')
add(36,1,'24','17',(687,432,725,442),(477,326,804,491),align='right',label='Nhãn thứ hai 2.5SS1.5/24' if fi==0 else 'Nhãn thứ hai 2.5SL1.5/24')
add(37,1,'1546','1566',(621,48.5,638,56.5),(576,40,732,102),label='T = 779 + 787')
add(38,3,'752','732',(717,450,735,459),(653,252,812,505),label='3SS2/11 T(T)' if fi==0 else '3SL2/11 T(T)')
add(38,3,'873','843',(717,440,735,449),(653,252,812,505),label='3SS2/15 T(T)' if fi==0 else '3SL2/15 T(T)')
add(39,3,'6.4','7.5',(765,275,780,285),(653,252,812,505),label='3SS3/26 M(T)' if fi==0 else '3SL3/26 M(T)')
add(39,3,'7.5','8.7',(765,265,780,275),(653,252,812,505),label='3SS3/31 M(T)' if fi==0 else '3SL3/31 M(T)')
add(40,8,'814','819',(702.5,319,716.5,327),(653,245,812,505),label='4SA3/10 T(S)' if fi==0 else '4SL3/10 T(S)')
add(40,8,'1664','1788',(702,247,720,257),(653,245,812,505),label='4SA3/35 T(S)' if fi==0 else '4SL3/35 T(S)')
add(41,9,'475','513',(224,304,236,313),(224,40,380,480),label='4SA8/6 P(mm)' if fi==0 else '4SL8/6 P(mm)')
add(41,9,'3.3','3.9',(300,305,314,315),(224,40,380,480),label='4SA8/6 P(kg)' if fi==0 else '4SL8/6 P(kg)')
add(42,9,'2143','2112',(653,342,670,352),(652,342,812,478),label='4SA12/32 P(mm)' if fi==0 else '4SL12/32 P(mm)')
if fi==0:
    add(43,11,'6SA15','6SA35',(150,499,184,510),(29,495,380,514),label='Tiêu đề trái')
    add(43,11,'6SA25','6SA45',(330,499,365,510),(29,495,380,514),label='Tiêu đề phải')
else:
    add(44,7,'4SL6','4SL10',(268,492,329,512),(237,492,790,519),label='Tiêu đề trái')
    add(44,7,'4SL8','4SL12',(700,492,757,512),(237,492,790,519),label='Tiêu đề phải')
    add(45,11,'6SL15','6SL35',(150,499,184,510),(29,495,380,514),label='Tiêu đề trái')
    add(45,11,'6SL25','6SL45',(330,499,365,510),(29,495,380,514),label='Tiêu đề phải')
    add(45,11,'6SL 35/20','6SL35/20',(72,496,101,505),(69,397,286,504),align='left',action='close_gap')
    add(46,10,'.','',(86,500,95,507),action='dot',label='Xoá dấu chấm tiêu đề')
for page in [1,2,4,10]:
    add(132,page,'years','year',(76,222,109,233),(27,222,173,233),align='left',action='drop_s')

# Lấy đúng từng hàng từ đường kẻ bảng thực tế; không suy đoán tọa độ hàng.
perf=[(4,462,15,[(14,'4SA2/64','5',True)]),
      (5,29,16,[(14,'4SA3/56','5',True)]),
      (5,462,17,[(13,'4SA4/45','5',True),(15,'4SA4/56','7',False)]),
      (6,29,18,[(14,'4SA6/38','5',True),(16,'4SA6/47','7',False)]),
      (6,462,17,[(13,'4SA8/33','5',True),(15,'4SA8/41','7',False)]),
      (7,29,16,[(12,'4SA10/24','5',True),(14,'4SA10/30','7',False)]),
      (7,462,15,[(11,'4SA12/23','5',True),(13,'4SA12/29','7',False)]),
      (8,29,13,[(9,'4SA16/18','5',True),(11,'4SA16/23','7',False)])]
for page,x0,count,targets in perf:
    cv=cv_for(page); rr=mapped(page,(x0,35,x0+350,200 if page==8 else 215))
    u0,v0,u1,v1=cv.box(rr);a=cv.gray((u0,v0,u1,v1));rows=np.where((a<220).sum(1)>(u1-u0)*.65)[0]
    groups=[]
    for k in rows:
        if not groups or k>groups[-1][-1]+1:groups.append([int(k)])
        else:groups[-1].append(int(k))
    ys=[float(cv.to_page(u0,v0+np.mean(g))[1]) for g in groups][-(count+1):]
    assert len(ys)==count+1,(page,x0,ys)
    step=np.median(np.diff(ys));assert np.all(abs(np.diff(ys)-step)<1.3),(page,x0,ys)
    for index,model,old,hp in targets:
        y=(ys[index]+ys[index+1])/2
        kwcol=(556 if x0>400 else 125); hpcol=(580 if x0>400 else 148)
        kwr=mapped(page,(kwcol-7,0,kwcol+7,0));kwr[1]=y-3.5;kwr[3]=y+3.5
        lr=mapped(page,(kwcol-12,42,hpcol+10,(193 if x0>400 else 184)))
        if fi:model=model.replace('SA','SL')
        add(131,page,old,old+'.5',kwr,lr,label=model+' kW',actual=True)
        if hp:
            hpr=mapped(page,(hpcol-7,0,hpcol+7,0));hpr[1]=y-3.5;hpr[3]=y+3.5
            add(131,page,'7','7.5',hpr,lr,label=model+' HP',actual=True)

out={'file':d,'plans':plans,'fails':fails}
Path(fresh(S.report(f'G04/KE HOACH {d["short"]}.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),encoding='utf-8')
E.close()
print('PLAN',d['short'],len(plans),'OK;',len(fails),'FAIL')
