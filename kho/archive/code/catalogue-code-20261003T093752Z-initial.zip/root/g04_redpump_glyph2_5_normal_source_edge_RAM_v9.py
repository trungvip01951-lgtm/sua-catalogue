"""Different method: project existing continuous contours locally onto source ink.
No binary-mask reconstruction/closing, no source-image alteration, no PDF save.
"""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import copy,json,hashlib,sys,numpy as np,cv2
from scipy.ndimage import gaussian_filter,distance_transform_edt
from scipy.interpolate import RectBivariateSpline
from PIL import Image,ImageDraw
sys.path.insert(0,str(HERE))
from g04_source_glyph_source_edge_math import sample_path
from g04_source_glyph_core_math import topology,signed_area
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
F=M/'CHU2 5 CHIEU BIEN VAO MUC NGUON RAM V9B';assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
previous_file=M/'CHU5 9 BIEN QUAN SAT RAM V7/12 GLYPH RAM V7 BIEN5 9 MOT MAU.json'
prev=J(previous_file)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
pad=8;up=8;replacements=[]
def smoothstep(a):
    t=np.clip(a,0,1);return t*t*(3-2*t)
def band(a,left,right,edge=2.):
    return smoothstep((a-left+edge)/edge)*smoothstep((right+edge-a)/edge)
for ch in ['2','5']:
    old=next(z for z in prev['records'] if z['character']==ch)
    alpha=np.asarray(old['source_alpha']);A=np.pad(alpha,pad)
    field=gaussian_filter(A,1.0)
    spline=RectBivariateSpline(np.arange(field.shape[0])-pad,np.arange(field.shape[1])-pad,field,kx=3,ky=3,s=0)
    level=.42;limit_move=2.8
    def weight(p):
        x,y=p
        if ch=='2':return float(band(y,9,19,3.)*smoothstep((x-13)/4))
        middle=band(y,11,20,3.)*band(x,2,21,2.)
        right=band(y,18,31,3.)*smoothstep((x-10)/4)
        return float(max(middle,right))
    def transform(p):
        # Integrate the smooth source-gradient field. A flow transports the
        # whole closed contour without the folds of a one-step normal snap.
        p=np.asarray(p,float).copy()
        for _ in range(24):
            w=weight(p)
            if w<=0:break
            x,y=p;value=float(spline.ev(y,x));g=np.array([spline.ev(y,x,dy=1),spline.ev(y,x,dx=1)],float)
            gn=float(np.linalg.norm(g))
            if gn<1e-6:break
            diff=level-value
            positive=(diff+np.sqrt(diff*diff+.01**2))/2
            length=limit_move*np.tanh(positive/(gn*limit_move))
            p+=w*length*g/gn/24
        return p
    def jacobian(p):
        p=np.asarray(p,float);hh=.001
        return np.column_stack([(transform(p+np.eye(2)[i]*hh)-transform(p-np.eye(2)[i]*hh))/(2*hh) for i in range(2)])
    all_true=[];all_actual=[];outloops=[];maxfit=0;maxmove=0
    for loop in old['parts'][0]['loops']:
        path=[];cur=first=None
        def emit(cur,controls):
            P=np.asarray([cur,*controls],float)
            def eval(t):
                return (1-t)**3*P[0]+3*(1-t)**2*t*P[1]+3*(1-t)*t*t*P[2]+t**3*P[3]
            def deriv(t):
                return 3*((1-t)**2*(P[1]-P[0])+2*(1-t)*t*(P[2]-P[1])+t*t*(P[3]-P[2]))
            def piece(lo,hi,depth=0):
                nonlocal_dummy=None
                p0,p3=eval(lo),eval(hi);q0,q3=transform(p0),transform(p3)
                q1=q0+jacobian(p0)@deriv(lo)*(hi-lo)/3
                q2=q3-jacobian(p3)@deriv(hi)*(hi-lo)/3
                ts=np.linspace(0,1,25);orig=np.array([eval(lo+(hi-lo)*t) for t in ts]);true=np.array([transform(p) for p in orig])
                actual=np.array([(1-t)**3*q0+3*(1-t)**2*t*q1+3*(1-t)*t*t*q2+t**3*q3 for t in ts])
                error=float(np.linalg.norm(actual-true,axis=1).max())
                if error>.075 and depth<7:
                    mid=(lo+hi)/2;piece(lo,mid,depth+1);piece(mid,hi,depth+1);return
                assert error<=.08,(ch,error)
                path.append(('c',[q1.tolist(),q2.tolist(),q3.tolist()]))
                all_true.extend(true.tolist());all_actual.extend(actual.tolist())
            piece(0.,1.)
        for op,ps in loop['path']:
            if op=='m':
                cur=np.asarray(ps[0],float);first=cur.copy();path.append(('m',[transform(cur).tolist()]))
            elif op=='l':
                target=np.asarray(ps[0],float);emit(cur,[cur+(target-cur)/3,cur+2*(target-cur)/3,target]);cur=target
            elif op=='c':
                emit(cur,ps);cur=np.asarray(ps[2],float)
            elif op=='h':
                if np.linalg.norm(cur-first)>1e-7:emit(cur,[cur+(first-cur)/3,cur+2*(first-cur)/3,first])
                path.append(('h',[]));cur=first
        ar=abs(signed_area(path));outloops.append(dict(path=path,foreground=True,tree_depth=0,area_px=ar,
            method='Source-gray-gradient normal projection of existing continuous contour; bounded local move, Hermite cubic chain-rule derivatives.',
            max_contour_fit_error_px600=.08,cubic_segments=sum(op=='c' for op,_ in path)))
    true=np.asarray(all_true);actual=np.asarray(all_actual);maxfit=float(np.linalg.norm(actual-true,axis=1).max())
    original_points=sample_path(old['parts'][0]['loops'][0]['path'],128)
    moved=np.array([transform(p) for p in original_points]);maxmove=float(np.linalg.norm(moved-original_points,axis=1).max())
    assert maxmove+maxfit<4.,(ch,maxmove,maxfit)
    fine=np.zeros((A.shape[0]*up,A.shape[1]*up),'uint8')
    polys=[np.rint((sample_path(z['path'],64)+pad)*up).astype('int32') for z in outloops]
    cv2.fillPoly(fine,polys,1);assert topology(fine)==(1,0),(ch,topology(fine))
    area=sum(z['area_px'] for z in outloops);z=copy.deepcopy(old)
    z.update(vector_optical_area_px=area*(1-63/255),parts=[dict(source_part=1,loops=outloops,
        kind='source_gradient_local_edge_projection',source_projection_target_alpha=level,
        source_field_sigma_px600=1.,max_projected_move_px600=maxmove,
        max_fitted_contour_error_px600=maxfit,max_total_local_boundary_move_pt=(maxmove+maxfit)*.12,
        relative_math_ink_error=float(area*(1-63/255)/alpha.sum()-1),
        loop_area_px=area,source_mass_px=float(alpha.sum()),topology=[1,0],
        no_morphological_closing=True,no_source_image_edit=True,no_RGB_channel_mask=True,
        no_mass_tightening=True,no_geometry_scale=True,
        status='ỨNG VIÊN RAM; cần nguồn và13nhãn được ROOT/đồhọa soi, không tự gọi phôngĐẠT.')])
    replacements.append(z)
    yy,xx=np.where(fine);bbox=[float(xx.min()/up-pad),float(yy.min()/up-pad),float((xx.max()+1)/up-pad),float((yy.max()+1)/up-pad)]
    source_img=Image.fromarray(np.round(255*(1-alpha)).clip(0,255).astype('uint8')).convert('RGB')
    oldfill=np.zeros_like(fine);cv2.fillPoly(oldfill,[np.rint((sample_path(z['path'],64)+pad)*up).astype('int32') for z in old['parts'][0]['loops']],1)
    def glyph_img(fill):
        return Image.fromarray((255-192*fill.astype(float)).clip(0,255).astype('uint8')).crop((pad*up,pad*up,(pad+alpha.shape[1])*up,(pad+alpha.shape[0])*up)).convert('RGB')
    old_img,new_img=glyph_img(oldfill),glyph_img(fine)
    sheet=Image.new('RGB',(1450,700),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(17)
    dr.text((5,5),f'{ch} NGUỒN / V7 / RAM V9 - chiếu biên vào mực nguồn, màu63, chưa PDF2',fill='blue',font=ft)
    for title,img,xp in [('Nguồn nhỏ thật',source_img,30),('V7',old_img,430),('V9 ứng viên',new_img,830)]:
        dr.text((xp,35),title,fill='blue',font=ft)
        sheet.paste(img.resize((alpha.shape[1]*10,alpha.shape[0]*10),Image.Resampling.NEAREST if xp==30 else Image.Resampling.LANCZOS),(xp,65))
    dr.text((5,520),f'Dịch biên local ≤{(maxmove+maxfit)*.12:.4f}pt; không đổi scale/advance/màu. Δmực{z["parts"][0]["relative_math_ink_error"]:+.4f}.\nMép JPEG yếu/source CAD không chắc; không suy phôngĐẠT từ giới hạn dịch.',fill='blue',font=ft)
    sheet.save(fresh(F/f'{ch} NGUON V7 V9 CHIEU BIEN RAM KHONG PDF.png'))
    Path(fresh(F/f'{ch} CHIEU BIEN SOURCE DATA RAM V9.json')).write_text(json.dumps(dict(character=ch,source_page_box=old['source_page_box'],source_alpha=alpha.tolist(),source_field=field.tolist(),target_alpha=level,
        old_loops=old['parts'][0]['loops'],new_loops=outloops,source_input_unchanged=True,actual_bbox600=bbox,
        observed_local_regions=[2,11,18,20,13,18,18,33] if ch=='5' else [10,9,20.3,19],
        max_move_px600=maxmove,max_fit_px600=maxfit,source_native_pixel_pt=.4801362852213916,
        same_9_V7_preserved=True,no_binary_mask_rebuild=True,no_source_image_edit=True,
        no_opacity_layers=True,no_mass_target=True,method='Bounded projection towards gradient of grayscale source ink only in reviewed local edge regions.'),ensure_ascii=False,indent=2),encoding='utf8')
out=copy.deepcopy(prev);rep={z['character']:z for z in replacements};out['records']=[rep.get(z['character'],z) for z in prev['records']]
assert next(z for z in out['records'] if z['character']=='9')==next(z for z in prev['records'] if z['character']=='9')
out.update(RAM_variant='V9_continuous_source_gradient_local_projection2_5_other10and9V7held',
    previous_bank=str(previous_file),previous_bank_SHA256=sha(previous_file),
    common_gray=63,core_gray=63,opacity=1,physical_scale=1,no_mass_tightening=True,
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False,
    status='RAM ứng viên mới, không PDF2, chưa hình thức/phôngĐẠT.')
fp=Path(fresh(F/'12 GLYPH RAM V9 CHIEU BIEN2 5 MOT MAU GIU9V7.json'))
fp.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print('RAM geometry',str(fp),'SHA256',sha(fp),flush=True)
