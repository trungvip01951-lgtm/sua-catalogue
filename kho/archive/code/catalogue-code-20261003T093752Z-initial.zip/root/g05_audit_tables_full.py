from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import json,hashlib,pymupdf as fitz
prefix='G05/KIEM TOAN TOAN BO/'
snap=json.loads(Path(S.report(prefix+'TRANG THAI VA OCR.json')).read_text(encoding='utf8'))
raw=Path(snap['output']).read_bytes();assert hashlib.sha256(raw).hexdigest()==snap['output_sha256']
doc=fitz.open(stream=raw,filetype='pdf');out=[]
for st in snap['charts']:
    r=st['table_rect'];p=doc[st['page']-1];right=827 if r[0]>400 else min(r[2]+10,420)
    rr=(r[0],r[1],right,r[3]);pix=p.get_pixmap(matrix=fitz.Matrix(450/72,450/72),clip=fitz.Rect(rr[0],p.rect.height-rr[3],rr[2],p.rect.height-rr[1]),alpha=False)
    Image.frombytes('RGB',(pix.width,pix.height),pix.samples).save(fresh(S.report(prefix+'BANG DAY DU/'+st['table_family']+'.png')))
    out.append(dict(family=st['table_family'],page=st['page'],rect=rr,dpi=450,width=pix.width,height=pix.height))
    print('BẢNG ĐỦ',st['table_family'],flush=True)
Path(fresh(S.report(prefix+'BANG DAY DU.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
doc.close()
