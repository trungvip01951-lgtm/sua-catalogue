"""Inspect clean source words in same Redpump file, no font assumption or PDF mutation."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
from catfix import verify
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));src=d['method']['source'];cur=d['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['method']['source_SHA256'],d['method']['input_SHA256']]
items=[('TRANG5 GLYPH3 DONOR DANG SOI',4,(123,485,151,499)),('TRANG4 GLYPH5 DONOR DANG SOI',3,(537,456,565,474))]
records=[]
for caption,p,box in items:
 fn=fresh(root/(caption+'.png'));verify.crop(src,p,box,600).save(fn);records.append(dict(page=p+1,rect=box,dpi=600,source_photo=fn,status='Ảnh source thật, cần soi nhãn/đúng glyph/đúngfontstyle trước chọn.'))
Path(fresh(root/'DONOR CHU CUNG FILE TRANG4 VA5 DANG SOI.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=records,PDF_written=False),ensure_ascii=False,indent=2),encoding='utf8')
assert before==[sha(src),sha(cur)]
