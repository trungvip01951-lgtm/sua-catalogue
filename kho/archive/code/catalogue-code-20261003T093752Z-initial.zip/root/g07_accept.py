from catwork import start,fresh
S,D,N=start()
from catfix.recipes import Job
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from catfix import verify
from g03_xmp_helper import check_xmp
from pathlib import Path
import json,hashlib,pikepdf,numpy as np
import pymupdf as fitz
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf';root=Path(S.report('G07'))
st=json.loads((root/'build-state.json').read_text(encoding='utf-8'))
src=S.src(NAME)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def expand(r,d=1):return [r[0]-d,r[1]-d,r[2]+d,r[3]+d]
def font_streams(pdf):
    out={}
    for o in pdf.objects:
        if not isinstance(o,pikepdf.Dictionary) or o.get('/Type')!=pikepdf.Name.Font:continue
        if '/BaseFont' not in o:continue
        fd=o.get('/FontDescriptor')
        if fd is None and '/DescendantFonts' in o:fd=o.DescendantFonts[0].get('/FontDescriptor')
        if fd is None:continue
        for key in ('/FontFile','/FontFile2','/FontFile3'):
            if key in fd:out[str(o.BaseFont)]=(key,hashlib.sha256(fd[key].read_raw_bytes()).hexdigest())
    return out
def inspect_file(dst,label):
    out=dict(source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),source_preserved=sha(src)==st['source_sha256'])
    job=Job(src,dst);job.edits=st['edits'];out['job_check']=job.check()
    allowed={1:[expand(e['rect']) for e in st['edits']]}
    out['outside_pixels_200dpi']=verify.outside_pixels(src,dst,allowed,dpi=200)
    B=Editor(dst);TL=TextLayer(B)
    out['prose']=[]
    for r in st['paragraphs']:
        ms=TL.find(0,r['new'],rect=expand(r['new_rect'],2))
        oks=len(ms)==1 and all(g.run.font.basefont==r['font'] and abs(g.run.size_page-r['size'])<.001 for g in ms[0].glyphs)
        out['prose'].append(dict(new=r['new'],count=len(ms),font=r['font'],size=r['size'],task_ids=r['task_ids'],ok=oks,rect=r['new_rect']))
    out['titles']=[]
    for r in st['titles']:
        ms=TL.find(0,r['new'],rect=expand(r['new_rect'],2))
        out['titles'].append(dict(new=r['new'],count=len(ms),ok=len(ms)==1 and not TL.find(0,r['old']),rect=r['new_rect']))
    out['decimals']=[]
    for r in st['decimal']:
        ms=TL.find(0,r['new'],rect=expand(r['rect'],1))
        out['decimals'].append(dict(old=r['old'],new=r['new'],count=len(ms),rect=r['rect'],ok=len(ms)==1 and not TL.find(0,r['old'],rect=expand(r['rect'],1))))
    out['hz']=dict(new='50 Hz',count=len(TL.find(0,'50 Hz',rect=expand(st['hz']['rect'],2))),old_count=len(TL.find(0,'50HZ')))
    out['sizes']=[]
    for r in st['sizes']:
        ms=TL.find(0,r['text'],rect=expand(r['old_rect'],1));g=ms[0].glyphs if len(ms)==1 else []
        out['sizes'].append(dict(text=r['text'],count=len(ms),sizes=sorted(set(gx.run.size_page for gx in g)),
                                 ok=len(ms)==1 and all(abs(gx.run.size_page-r['new_size'])<.001 and gx.run.font.basefont==r['font'] for gx in g)))
    r=st['insert48'];ms=TL.find(0,'48',rect=expand(r['rect'],1))
    out['insert48']=dict(count=len(ms),center_error=abs((ms[0].bbox[0]+ms[0].bbox[2])/2-r['center']) if len(ms)==1 else None,
                         ok=len(ms)==1 and all(g.run.font.basefont==r['font'] and abs(g.run.size_page-r['size'])<.001 for g in ms[0].glyphs))
    out['outlet_parts']=[]
    for r in st['outlet']:
        ms=TL.find(0,r['new'],rect=expand(r['rect'],1))
        out['outlet_parts'].append(dict(old=r['old'],new=r['new'],rect=r['rect'],ok=len(ms)==1 and not TL.find(0,r['old'],rect=expand(r['rect'],1))))
    out['outlet_unresolved']=[dict(**r,preserved=len(TL.find(0,r['old'],rect=expand(r['rect'],1)))==1) for r in st['unresolved']]
    out['units_count']=len(TL.find(0,'kg/dm³'))
    out['old_units_count']=len(TL.find(0,'Kg³/m'))
    out['retained_solid50']=len(TL.find(0,'50',rect=(939,247,963,260)))==1
    out['preserve136']=all(Path(S.src(n)).is_file() for n in [NAME,'Aquaris FS_300dpi_75% (bản mới).pdf'])
    A=Editor(src);pa,pb=A.page(0),B.page(0)
    fields=('op','fill','stroke','lw','dash','gs','fill_cs','stroke_cs','clip','textclip')
    same=len(pa.objs)==len(pb.objs)
    if same:
        for oi,(a,b) in enumerate(zip(pa.objs,pb.objs)):
            # Include clipping commands W/W* and preserve their exact native
            # packets, which are not accepted by object_pagepath's path reader.
            packet=lambda p,o:[(i.op,i.operands) for i in p.ops[o['i0']:o['i1']+1]]
            if any(a.get(k)!=b.get(k) for k in fields) or not np.array_equal(a['ctm'],b['ctm']) or packet(pa,a)!=packet(pb,b):same=False;break
    out['all_vector_drawings_unchanged']=same
    with pikepdf.open(src) as a,pikepdf.open(dst) as b:
        out['metadata_values_equal']={str(k):str(v) for k,v in a.docinfo.items()}=={str(k):str(v) for k,v in b.docinfo.items()}
        out['embedded_font_streams_equal']=font_streams(a)==font_streams(b)
        out['embedded_font_count']=len(font_streams(a))
        out['images']=[]
        for pg,(aa,bb) in enumerate(zip(a.pages,b.pages),1):
            xa,xb=aa.Resources.get('/XObject',{}),bb.Resources.get('/XObject',{})
            for key,obj in xa.items():
                if obj.get('/Subtype')!=pikepdf.Name.Image:continue
                ok=key in xb and obj.read_raw_bytes()==xb[key].read_raw_bytes()
                ok=ok and all(obj.get(k)==xb[key].get(k) for k in ('/Width','/Height','/BitsPerComponent','/Filter'))
                out['images'].append(dict(page=pg,name=str(key),ok=ok))
    out['xmp']=check_xmp(src,dst)
    with fitz.open(src) as a,fitz.open(dst) as b:
        out['bookmarks_equal']=a.get_toc()==b.get_toc()
        norm=lambda link:{k:(list(v) if hasattr(v,'__len__') and not isinstance(v,(str,list,dict)) else v) for k,v in link.items() if k!='xref'}
        out['links_equal']=[[norm(v) for v in p.get_links()] for p in a]==[[norm(v) for v in p.get_links()] for p in b]
    out['common_checks_ok']=all([out['source_preserved'],out['job_check']['ok'],not out['outside_pixels_200dpi'],
                                out['all_vector_drawings_unchanged'],out['metadata_values_equal'],out['embedded_font_streams_equal'],
                                all(a['ok'] for a in out['images']),out['xmp']['values_equal'],out['bookmarks_equal'],out['links_equal']])
    out['task_results']={
       '54':out['insert48']['ok'] and out['insert48']['center_error']<.001,
       '55':all(r['ok'] for r in out['prose'] if 55 in r['task_ids']),
       '56':all(r['ok'] for r in out['prose'] if 56 in r['task_ids']) and all(r['ok'] for r in out['titles']) and out['units_count']==3 and out['old_units_count']==0,
       '57':all(r['ok'] for r in out['decimals']) and all(r['ok'] for r in out['sizes']) and out['hz']['count']==1 and out['hz']['old_count']==0,
       '137':not out['outlet_unresolved'] and all(r['ok'] for r in out['outlet_parts'])}
    out['accepted_pass_count']=sum(out['common_checks_ok'] and v for v in out['task_results'].values())
    out['visual_review']=dict(descriptions=True,upper_table=True,performance_table=True,bottom_table=True,
                              note='Đã soi từng chữ mới trên các ảnh phóng lớn: đủ khoảng cách, không đè chữ sau; ³ giữ nét gốc, k đúng Arial; các ô số căn giữa và cùng cỡ.')
    json.dump(out,open(fresh(root/(label+'.json')),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
    print(label,'common=',out['common_checks_ok'],'outside=',out['outside_pixels_200dpi'],'tasks=',out['task_results'],flush=True)
    A.close();B.close();job.close()
    return out

pre=inspect_file(st['stage'],'acceptance-stage')
assert pre['common_checks_ok'] and pre['accepted_pass_count']==4,pre
fresh(S.dst(NAME));job=S.job(NAME)
assert sha(job.src)==st['source_sha256']
job.E.close();job.E=Editor(st['stage']);job.edits=st['edits']
stage_log=json.loads((root/'review'/'mau-sua.log.json').read_text(encoding='utf-8'))
job.E.log=stage_log['log']+[dict(task=137,result='CHƯA ĐẠT',reason=st['unresolved']),dict(task=136,result='GIỮ NGUYÊN')]
job.save();final=job.dst;log=job.log_path;job.close()
after=inspect_file(final,'acceptance-final')
assert after['common_checks_ok'] and after['accepted_pass_count']==4,after
verify.page_overview(src,final,0,fresh(root/'trang-truoc-sau.png'),dpi=140)
job=Job(src,final);job.edits=st['edits'];job.evidence(fresh(S.report('So sanh G07.png')),dpi=220);job.close()
print('Final:',final,'Log:',log,'4/5 ĐẠT; #137 thiếu 8 phông MyriadPro-Regular.',flush=True)
