from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np
from scipy.ndimage import label
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image
root=Path(S.report('G06/KIEM DUONG DOC LAP ROOT V2'))
b=json.loads((root/'NGHIEM THU QH ROOT.json').read_text(encoding='utf8'))
E=Editor(S.src('Aquaris FS_300dpi_75% (bản mới).pdf'),backend='fitz');R=Raster(E);cv=R.canvas(max(R.images(1),key=lambda z:z.W*z.H));a=cv.orig.astype(float)
page=b['pages'][0];xs=page['vertical_rules_native'];ys=page['horizontal_rules_native_top_down'];uu=np.arange(int(round(xs[0]))-2,int(round(xs[-1]))+3);vv=np.arange(int(round(ys[0]))-2,int(round(ys[-1]))+3)
ar=a[np.ix_(vv,uu)];con=255-ar;out=[]
for ident in page['identities']:
    if ident['model'] not in ('FS-50-7-3.0','FS-50-10-4.0'):continue
    target=255-np.array(ident['legend_actual_RGB']);n=np.linalg.norm(target)
    cosine=(con@target)/(np.maximum(np.linalg.norm(con,axis=2),1)*n);alpha=(con@target)/(n*n)
    mask=(cosine>.982)&(alpha>.15)&(ar.max(2)-ar.min(2)>30)
    labels,count=label(mask,np.ones((3,3)));sizes=np.bincount(labels.ravel());sizes[0]=0;order=np.argsort(sizes)[-12:][::-1]
    component_rows=[]
    for index in order:
        if sizes[index]==0:continue
        rr,cc=np.where(labels==index);component_rows.append(dict(index=int(index),pixel_count=int(sizes[index]),bbox_native=[int(uu[cc.min()]),int(vv[rr.min()]),int(uu[cc.max()]),int(vv[rr.max()])]))
    leader=int(order[0]);m=labels==leader;show=np.full_like(ar,255,dtype=np.uint8);show[m]=ar[m].astype(np.uint8)
    Image.fromarray(show).save(fresh(root/(ident['model']+' THANH PHAN MUC.png')))
    points=[]
    for q in (0,20):
        x=xs[q//20];cols=np.where(abs(uu-int(round(x)))<=2)[0];p=m[:,cols];rows=np.where(p.any(1))[0]
        points.append(dict(Q=q,native_x=x,native_y_first=int(vv[rows.min()]) if len(rows) else None,native_y_last=int(vv[rows.max()]) if len(rows) else None,pixel_count=int(p.sum()),rows=vv[rows].tolist()))
    out.append(dict(model=ident['model'],components=component_rows,points=points))
E.close();Path(fresh(root/'CAC THANH PHAN MUC NGUON.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(out,ensure_ascii=False,indent=2),flush=True)
