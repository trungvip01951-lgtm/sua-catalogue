"""Đọc ứng viên ký tự khác của chính file, giữ nguyên pixel nguồn."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster,cv2
from g04_perotac_audit_data import DATA
from g04_perotac_audit_labels_manual import MANUAL
from pathlib import Path
from PIL import Image
from scipy import ndimage
import numpy as np,json
name='Perotac bơm giếng SA_compressed (bản mới).pdf';root=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC/UNG VIEN KHAC CHI DOC LAN2'))
E=Editor(S.src(name),backend='fitz');R=Raster(E);ink=np.array([57.,55.,57.]);bg=np.array([255.,255.,255.]);results=[]
for fam,suffix in [('4SA16',8),('4SA16',12),('4SA16',16),('4SA16',23),('4SA10',30),('4SA3',30),('4SA8',37)]:
    page=next(z['page'] for z in DATA if z['family']==fam);lx,ll=MANUAL[fam];_,t,b=next(z for z in ll if z[0]==suffix)
    cv=R.canvas(max(R.images(page-1),key=lambda z:z.W*z.H));bbox=[lx-1,t-1,lx+48,b];raw=cv.orig[bbox[1]:bbox[3],bbox[0]:bbox[2]];al=R.alpha_of(raw,bg,ink)
    label=fam+'-'+str(suffix);Image.fromarray(raw).resize((raw.shape[1]*20,raw.shape[0]*20),Image.Resampling.NEAREST).save(fresh(root/(label+' NGUON20LAN.png')))
    print('\n',fam+'/'+str(suffix),'page',page,'box',bbox,flush=True)
    print('     '+''.join(str((x//10)%10) for x in range(bbox[0],bbox[2])),flush=True)
    print('     '+''.join(str(x%10) for x in range(bbox[0],bbox[2])),flush=True)
    for j,row in enumerate(al):print(f'{bbox[1]+j:4d} '+''.join('#' if v>=.65 else '+' if v>=.4 else ':' if v>=.18 else '.' if v>=.05 else ' ' for v in row),flush=True)
    results.append(dict(source_page=page,source_word=fam+'/'+str(suffix),source_image='X'+str(page-1),source_box=bbox,alpha=al.tolist(),source_pixels_unmodified=True))
Path(fresh(root/'DOC UNG VIEN KY TU KHAC.json')).write_text(json.dumps(dict(PDF_written=False,source_candidates=results),ensure_ascii=False,indent=2),encoding='utf8');E.close()
