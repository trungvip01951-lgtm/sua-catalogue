"""Actual PDF ink read at two source-locked 6SL25 Q27 points, no PDF writes."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from datetime import datetime
import hashlib,json,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import color_runs

root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
out=root/'6SL25 Q27 DOC ACTUAL600 RIENG LAN3'
read=lambda n:json.loads((root/n).read_text(encoding='utf8'))
d=read('DOC MUC LOCAL NGOAI P8 6SL25 LAN1/DO MUC LOCAL DOC NGUON VA BAN GIAO CHUA CHOT.json')
tables=read('DANH MUC BANG NGUON 196 DONG V2.json')
cells=read('1931 O NGUON DINH VI VA DOI CHIEU V2.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(d['source']),sha(d['current'])]
assert before==[d['source_SHA256'],d['current_SHA256']]
for p in ['source','current']:
    E=Editor(d[p],backend='fitz');R=Raster(E)
    for dpi in [150,600]:
        c=R.render_canvas(9,(632,351,800,513),dpi=dpi)
        Image.fromarray(c.orig).save(fresh(out/f'{p.upper()} 6SL25 TOAN BIEU DO NGUYEN {dpi}dpi.png'))
    E.close()
hy=np.array(d['local_H_positions']);hv=np.array(d['local_H_values']);qx=np.array(d['local_Q_positions']);qv=np.array(d['local_Q_values'])
point_x=float(np.interp(27,qv,qx))
nx,ny=d['source_native_pixel_pt'];records=[]
for name in ['6SL25/20','6SL25/16']:
    z=next(r for r in d['records'] if r['model']==name)
    target=next(p for p in z['numeric_points'] if p['Q']==27)
    locked_xy=np.array(z['trace_xy']);centery=target['local_page_point'][1]
    reads=[]
    for kind in ['source','current']:
        E=Editor(d[kind],backend='fitz');R=Raster(E)
        cv=R.render_canvas(9,(point_x-5,centery-4,point_x+5,centery+4),dpi=600)
        ar=cv.orig.astype(float);gray=ar@np.array([.299,.587,.114])
        u,v=cv.to_px(point_x,centery);u=int(round(u));a=[]
        threshold_reads=[];unavailable_thresholds=[]
        for threshold in [160,175,190,210]:
            samples=[]
            mask=(ar[:,:,1]-ar[:,:,0]>4)&(ar[:,:,2]-ar[:,:,0]>6)&(gray<threshold)
            for uu in range(u-4,u+5):
                pagex=float(cv.to_page(uu,0)[0]);pred_y=float(np.interp(pagex,locked_xy[:,0],locked_xy[:,1]));pred_v=cv.to_px(0,pred_y)[1]
                cand=[r for r in color_runs(mask,255-gray,uu,0,len(gray)-1,max_width=30) if abs(r['v']-pred_v)<15 and r['strength']>=100]
                if len(cand)!=1:
                    unavailable_thresholds.append(dict(threshold=threshold,column=uu,candidate_count=len(cand),status='KHÔNG ĐỦ MỰC CHẮC; không ép run hoặc nội suy cột đó'))
                    samples=[];break
                r=cand[0];x,y=cv.to_page(uu,r['v']);samples.append(dict(u=uu,**r,page=[float(x),float(y)]))
            if not samples:continue
            sampled_xy=np.array([r['page'] for r in samples]);poly=np.polyfit(sampled_xy[:,0]-point_x,sampled_xy[:,1],2)
            threshold_reads.append(dict(grayscale_threshold=threshold,samples=samples,fit_poly=poly.tolist(),point_y=float(poly[2]),H=float(np.interp(poly[2],hy,hv))))
        assert len(threshold_reads)>=2,(name,kind,'insufficient stable dark-core cuts')
        # Use the darkest cut with actually observed unambiguous ink in every column.
        # Missing cuts remain UNKNOWN. Retain sensitivity and source-pixel bounds.
        a=threshold_reads[0]['samples']
        xy=np.array([r['page'] for r in a]);fit=np.polyfit(xy[:,0]-point_x,xy[:,1],2)
        point_y=float(fit[2]);H=float(np.interp(point_y,hy,hv));slope=abs(float(fit[1]))
        j=min(max(int(np.searchsorted(hy,point_y)),1),len(hy)-1)
        hscale=abs(float((hv[j]-hv[j-1])/(hy[j]-hy[j-1])))
        width=max(r['width'] for r in a)*72/600
        fit_residual=float(abs(xy[:,1]-np.polyval(fit,xy[:,0]-point_x)).max())
        # Keep source-pixel bound; high-resolution rendering does not add source detail.
        sensitivity=max(abs(r['point_y']-point_y) for r in threshold_reads)
        uncert=hscale*(ny+.5*width+nx*slope+fit_residual+.06*slope+sensitivity)
        error=H-target['H_table'];limit=max(1,.02*target['H_table'])
        status='CHƯA ĐẠT' if abs(error)-uncert>limit else 'CHƯA THỂ'
        img=Image.fromarray(cv.orig);md=ImageDraw.Draw(img)
        px,py=cv.to_px(point_x,point_y);md.line((px,0,px,img.height),fill=(180,0,180),width=1);md.ellipse((px-4,py-4,px+4,py+4),outline=(255,0,0),width=1)
        source_photo=Path(fresh(out/f'{name.replace("/","_")} {kind.upper()} Q27 MUC THAT600.png'))
        Image.fromarray(cv.orig).save(source_photo)
        annotated=Path(fresh(out/f'{name.replace("/","_")} {kind.upper()} Q27 DO600.png'));img.save(annotated)
        reads.append(dict(file=kind,path=d[kind],SHA256=sha(d[kind]),sample_columns=a,threshold_reads=threshold_reads,unavailable_thresholds=unavailable_thresholds,selected_dark_core_threshold=threshold_reads[0]['grayscale_threshold'],threshold_center_sensitivity_pt=sensitivity,
            actual_read_xy=[point_x,point_y],H_curve=H,H_table=target['H_table'],error=error,
            max_error_allowed=limit,conservative_uncertainty_m=uncert,status=status,
            native_pixel_pt=[nx,ny],ink_occupied_width_pt=width,
            local_abs_dy_dx=slope,fit_residual_pt=fit_residual,
            adjacent_H_ticks=dict(values=hv[j-1:j+1].tolist(),positions=hy[j-1:j+1].tolist()),
            source_photo=str(source_photo),measurement_photo=str(annotated)))
        E.close()
    assert abs(reads[0]['H_curve']-reads[1]['H_curve'])<1e-10
    rr=next(r for r in tables['rows'] if r['model']==name)
    cr=next(r for r in cells['cells'] if r['model']==name and r['Q']==27)
    records.append(dict(model=name,page=10,Q=27,H_table=target['H_table'],
        source_table_row=rr,source_cell_position=cr,
        name_identity_basis=z['seed_basis'],name_evidence=z['name_source_current_photo'],
        whole_trace_photo=z['photo'],whole_trace_branch_count=len(z['branch_issues']),
        current_trace_point_unchanged_from_source=target['source_current_tube_changed_pixels']==0,
        actual_reads=reads,status='CHƯA ĐẠT - cần ROOT đọc độc lập trước kế hoạch dựng toàn biểu đồ',
        local_Q_bracket=dict(values=[25,30],positions=qx[-2:].tolist(),fraction=.4),
        source_only_geometry=True,H_table_not_used_for_trace_or_candidate_choice=True))
report=dict(time=datetime.now().isoformat(),source=d['source'],source_SHA256=before[0],
    current=d['current'],current_SHA256=before[1],records=records,
    axis_evidence=str(root/'17 TRUC DOC NGUON RIENG KHOA V1.json'),
    catalogue_written=False,shared_progress_written=False,
    scope='Hai điểm Q27 ngoài p8; chưa nghiệm thu toàn 10 đường/120 ô 6SL25 hay 16 biểu đồ khác.',
    limitation='Mực JPEG nguồn đọc từ PDF thật, bảo thủ giữ pixel nguồn và nửa bề rộng mực. Không coi 600dpi là nguồn có thêm độ chính xác.')
path=Path(fresh(out/'HAI DIEM Q27 DO MUC ACTUAL600 NGUON VA BAN GIAO.json'))
path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
assert before==[sha(d['source']),sha(d['current'])]
print(json.dumps(dict(path=str(path),SHA256=sha(path),reads=[dict(model=r['model'],H_table=r['H_table'],**{k:r['actual_reads'][0][k] for k in ['H_curve','error','conservative_uncertainty_m','max_error_allowed','status']}) for r in records]),ensure_ascii=False),flush=True)
