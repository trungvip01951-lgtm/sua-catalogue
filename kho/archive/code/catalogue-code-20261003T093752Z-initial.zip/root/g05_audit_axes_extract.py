from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.raster import Raster,RenderCanvas
from pathlib import Path
import json,hashlib,numpy as np,pymupdf as fitz

prefix='G05/KIEM TOAN TOAN BO/'
snap=json.loads(Path(S.report(prefix+'TRANG THAI VA OCR.json')).read_text(encoding='utf8'))
raw=Path(snap['output']).read_bytes();assert hashlib.sha256(raw).hexdigest()==snap['output_sha256']
doc=fitz.open(stream=raw,filetype='pdf');E=Editor(snap['source']);R=Raster(E)
def cv(p,rect,dpi):
    page=doc[p];s=72/dpi;h=page.rect.height
    x0=np.floor(rect[0]/s)*s;x1=min(page.rect.width,np.ceil(rect[2]/s)*s)
    y0=h-np.ceil((h-rect[1])/s)*s;y1=h-np.floor((h-rect[3])/s)*s
    box=(x0,y0,x1,y1)
    pix=page.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),clip=fitz.Rect(x0,h-y1,x1,h-y0),alpha=False)
    arr=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,pix.n).copy()
    return RenderCanvas(p,box,dpi,arr,None)
out=[]
for st in snap['charts']:
    fam=st['table_family'];r=st['plot_rect'];p=st['page']-1
    bottom=345 if st['page']==2 else 230
    c=cv(p,(max(0,r[0]-25),bottom,min(831.56,r[2]+25),540),600)
    c.save_png(fresh(S.report(prefix+fam+'-bieu-do-du-truc.png')))
    words=R.ocr(c,scale=1,psm=11)
    ws=[dict(text=w['text'],rect=c.rect(w['box']),conf=w['conf']) for w in words]
    if fam=='6SP10':
        r=st['table_rect'];t=cv(p,(r[0],r[1],827,r[3]),450)
        t.save_png(fresh(S.report(prefix+fam+'-bang-du.png')))
    out.append(dict(family=fam,page=st['page'],rect=c.rect0,dpi=600,shape=list(c.work.shape),words=ws))
    print('ĐỌC TRỤC',fam,len(ws),flush=True)
Path(fresh(S.report(prefix+'TRUC VA NHAN.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();doc.close()
