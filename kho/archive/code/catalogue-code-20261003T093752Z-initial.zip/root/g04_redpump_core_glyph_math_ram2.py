"""Prepare source small-glyph single-core geometry only. No PDF save."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,sys,numpy as np
sys.path.insert(0,str(HERE))
from g04_source_glyph_core_math import glyph_core_contours,source_linear_stroke

P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
folder=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1/CHU NHO MOT MAU RAM V4'))
assert not folder.exists()
B=json.loads((P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
tops={'4':(1,1),'S':(1,0),'L':(1,0),'6':(1,1),'3':(1,0),'/':(1,0),'2':(1,0),'5':(3,0),'0':(1,1),'8':(1,2),'9':(1,1),'1':(1,0)}
cores=[]
for r in B['records']:
    a=np.array(r['source_alpha']);v=a[a>.085]
    cores.append(float(np.median(v[v>=np.quantile(v,.95)])))
gray=int(round(255*(1-np.median(cores))));print('Source common median core gray',gray,'source per-glyph core coverages',cores,flush=True)
out=[]
for r in B['records']:
    v=(source_linear_stroke(r['source_alpha'],core_gray=gray) if r['character']=='/' else
       glyph_core_contours(r['source_alpha'],tops[r['character']],core_gray=gray))
    v.update(character=r['character'],source_page=r['source_page'],source_word=r['source_word'],source_page_box=r['source_page_box'],source_alpha=r['source_alpha'],
        source_common_core_rule='Xám chung từ trung vị các lõi tối 5% của 12 donor nhỏ đã chứng minh, không phông ngoài.',
        topology_source_read_basis='Đọc trực tiếp hình chữ nhỏ nguồn; giữ 3 mảnh chân 5. Không dùng outline phông hệ thống.',
        no_PDF_written=True)
    out.append(v)
    f=fresh(folder/f'BIEN KY TU {ord(r["character"]):03d} RAM.json')
    Path(f).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
    print('contour',r['character'],'parts',len(v['parts']),'core',gray,'areaerror',v['vector_optical_area_px']/v['source_area_px']-1,
          'settings',[(p['kind'],round(p['coverage_threshold'],3),p['close_px600'],round(p['boundary_offset_px600'],3),len(p['loops'])) for p in v['parts']],flush=True)
Path(fresh(folder/'12 GLYPH NHO BIEN MOT MAU RAM V2.json')).write_text(json.dumps(dict(records=out,core_gray=gray,source_measured_core_coverages=cores,
    common_core_rule='Median of top5percent donor small-glyph source coverage, round grayscale 0..255.',
    source_uncertainty_native_pixel_pt=.4801362852213916,no_external_font=True,no_large_title=True,no_table_bold_font=True,
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False,status='RAM candidate only: optical/edge/bounds/direct-read still pending.'),ensure_ascii=False,indent=2),encoding='utf8')
print('MATH RAM ONLY',folder,flush=True)
