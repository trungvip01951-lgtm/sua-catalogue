"""Read actual proposed contour data anew for all12 source glyph metrics."""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import cv2
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'TOAN BO12 DO LAI DUONG CHU V3 LAY MAU CA CANH THANG'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
current=read(base/'CHU2 CHU5 GIU NET THANG NGUON V3/TOAN BO12 CHU NGUON NET THANG V3 RAM CHUA NGHIEM THU.json');source=read(base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json');by={r['key']:r for r in source['candidates']};scale=96;out=[]
def actual_points(path):
    if not path.get('cubic_segments_local_native'):
        vertices=np.asarray(path['local_native_xy'],float);points=[]
        for i,v in enumerate(vertices):points.extend((v+np.linspace(0,1,256,endpoint=False)[:,None]*(vertices[(i+1)%len(vertices)]-v)).tolist())
        return np.asarray(points)
    pts=[]
    for seg in path['cubic_segments_local_native']:
        c=np.asarray(seg,float);t=np.linspace(0,1,256,endpoint=False)[:,None];pts.extend(((1-t)**3*c[0]+3*(1-t)**2*t*c[1]+3*(1-t)*t**2*c[2]+t**3*c[3]).tolist())
    return np.asarray(pts)
for glyph in current['glyphs']:
    r=by[glyph['source_key']];a=np.asarray(r['alpha']);h,w=a.shape;up=cv2.resize(np.pad(a,1),((w+2)*scale,(h+2)*scale),interpolation=cv2.INTER_LINEAR);srcm=up>=r['iso_mass_match_threshold'];co,hh=cv2.findContours(srcm.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
    paths=[];piece=[];newmask=Image.new('L',((w+2)*scale,(h+2)*scale),0);dr=ImageDraw.Draw(newmask)
    for j,p in enumerate(glyph['cleaned_contour_paths']):
        pts=actual_points(p);ref=(co[j][:,0,:].astype(float)+.5)/scale-1;hd=max(float(cKDTree(ref).query(pts)[0].max()),float(cKDTree(pts).query(ref)[0].max()));ar=abs(float(np.sum(pts[:,0]*np.roll(pts[:,1],-1)-pts[:,1]*np.roll(pts[:,0],-1))/2));sr=abs(cv2.contourArea(co[j])/scale**2);bb=np.r_[pts.min(0),pts.max(0)];oldbb=np.r_[ref.min(0),ref.max(0)]
        dr.polygon([((x+1)*scale,(y+1)*scale) for x,y in pts],fill=255 if p['parent']<0 else 0);paths.append(pts)
        piece.append(dict(parent=p['parent'],source_contour_area_native_px=sr,proposed_exact_curve_area_native_px=ar,area_change_percent=(ar/sr-1)*100,
            source_bbox_native=oldbb.tolist(),proposed_bbox_native=bb.tolist(),bbox_width_height_delta_percent=(((bb[2:]-bb[:2])/(oldbb[2:]-oldbb[:2])-1)*100).tolist(),source_max_symmetric_boundary_distance_native_px=hd,
            exact_cubic_count=len(p.get('cubic_segments_local_native',[])),straight_only_polygon=p.get('cubic_segments_local_native',[])==[]))
    nm=np.asarray(newmask)>0;nc,nh=cv2.findContours(nm.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);alld=np.vstack(paths);bb=np.r_[alld.min(0),alld.max(0)];srcbb=np.asarray(r['source_iso_native_bbox']);whratio=((bb[2:]-bb[:2])/(srcbb[2:]-srcbb[:2])-1)*100;area=float(nm.sum()/scale**2);obj=dict(character=glyph['character'],source_key=glyph['source_key'],source_page=r['source_page'],source_image=r['source_image'],source_native_box=r['source_native_box'],source_raw_pixel_sha256=r['raw_pixel_sha256'],
       source_RGBA_projected_alpha_area_native_px=r['alpha_integral_native_px'],current_RAM_mask_area_native_px=area,current_RAM_alpha_area_delta_percent=(area/r['alpha_integral_native_px']-1)*100,
       source_bbox_native=srcbb.tolist(),current_exact_curve_bbox_native=bb.tolist(),current_bbox_WH_delta_percent=whratio.tolist(),source_crop_advance_native=float(w),current_advance_native=glyph['native_advance'],advance_unchanged=glyph['native_advance']==w,
       source_components=r['components'],source_holes=r['holes'],current_components=int(sum(nh[0,k,3]<0 for k in range(len(nc)))),current_holes=int(sum(nh[0,k,3]>=0 for k in range(len(nc)))),
       source_counter_and_body_each=piece,max_source_boundary_distance_native_px=max(p['source_max_symmetric_boundary_distance_native_px'] for p in piece),proposed_single_source_RGB=[57,55,57],opacity=1.,no_FontProgram_available_or_invented=True,
       actual_PDF_readback_not_run=True,visual_font_style_same_source_acceptance_pending_ROOT_graphic=True)
    obj['measured_numeric_bounds_only_within_source_one_px_area10pct_bbox2pct']=bool(obj['max_source_boundary_distance_native_px']<=1 and abs(obj['current_RAM_alpha_area_delta_percent'])<=10 and max(abs(whratio))<=2 and obj['source_holes']==obj['current_holes'] and obj['source_components']==obj['current_components'] and obj['advance_unchanged'])
    out.append(obj);print(obj['character'],'area%',round(obj['current_RAM_alpha_area_delta_percent'],4),'bbox%',np.round(whratio,4),'HD',round(obj['max_source_boundary_distance_native_px'],4),'numeric_bounds_only',obj['measured_numeric_bounds_only_within_source_one_px_area10pct_bbox2pct'],flush=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==current['source_sha256'] and sha(S.result(name))==current['current_sha256']
Path(fresh(root/'DO LAI TU12 DUONG CHU V3 VA MAT NA RAM.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_original_only=True,current_glyph_source_report='CHU2 CHU5 GIU NET THANG NGUON V3/TOAN BO12 CHU NGUON NET THANG V3 RAM CHUA NGHIEM THU.json',
    independently_sampled_actual_current_cubic_data=True,straight_edges_dense_sampled_as_well_as_curves=True,prior_VERTEX_ONLY_straight_edge_distance_report_invalid_not_used=True,glyphs=out,all_numeric_bounds_pass_only=all(r['measured_numeric_bounds_only_within_source_one_px_area10pct_bbox2pct'] for r in out),numeric_bounds_do_not_establish_visual_font_acceptance=True,no_PDF_font_or_progress_written=True),ensure_ascii=False,indent=2),encoding='utf8')
md='''# Đo lại 12 đường chữ nguồn hiện dùng trong ảnh RAM V2

**Chỉ kiểm dữ liệu hình chữ được đề xuất trong bộ nhớ. Chưa phải chữ đã lưu vào PDF; các số đo trong giới hạn không tự thay việc soi hình và nghiệm thu phông/dáng chữ.**

Đọc lại từng đường cong hiện dùng ở bộ chữ V3, lấy mẫu độc lập và so với biên mực nguyên từ Perotac. Cùng một màu nguồn RGB57/55/57, tỷ lệ1:1, khoảng tiến ký tự và đường cơ sở giữ nguyên. Không dùng tên phông hay mô tả phông đã mất, không lấy chữ của tệp khác.

| Ký tự | Diện tích mực đổi | Rộng/cao đổi | Biên lệch lớn nhất | Thành phần/lòng nguồn→mới |
|---|---:|---:|---:|---|
'''
for r in out:md+=f"| {r['character']} | {r['current_RAM_alpha_area_delta_percent']:+.4f}% | {r['current_bbox_WH_delta_percent'][0]:+.4f}% / {r['current_bbox_WH_delta_percent'][1]:+.4f}% | {r['max_source_boundary_distance_native_px']:.4f} điểm ảnh gốc | {r['source_components']}/{r['source_holes']} → {r['current_components']}/{r['current_holes']} |\n"
md+='''
Giới hạn được ROOT cho phép: sai lệch biên trong bất định nguồn1 pixel; hộp/cỡ±2%, mực±10%. Chứng cứ từng lòng chữ và biên ngoài, hộp, diện tích, số đoạn nằm trongJSON. Hộp nguồn lấy từ đường đẳng lượng mực của JPEG150dpi; nguồn không có mô tả phông liên tục, không coi số này là phông gốc chính xác.

A cong ở thử36 và2/5 cong ở thử38 đã loại sau soi hình vì uốn mất nét thẳng; không được dùng chúng khi tạo mẫu. A/1/2/5 hiện dùng các nét thẳng/cung ít đoạn theo chính nguồn. /11 phải giữ đủ cả hai số1. Chữ3/8 có đối chứng từ các ký tự4/S/A chung trong cùng Perotac; nguồn khác trang vẫn cùng tệp, không nhập phông ngoài.

ROOT và tác nhân đồ họa cần soi12 hình chữ nguồn–đề xuất,13 tên và toàn trang RAM150/600. Bản nguồn, bản giao và tiến độ giữ nguyên. Chưa PDF, chưa tự nhậnĐẠT.
'''
for x,y in {'RGB57':'RGB 57','tỷ lệ1':'tỷ lệ 1','nguồn1':'nguồn 1','trongJSON':'trong JSON','JPEG150dpi':'JPEG 150dpi','thử36':'thử 36','và2/5':'và 2/5','thử38':'thử 38','số1':'số 1','Chữ3/8':'Chữ 3/8','ký tự4/S/A':'ký tự 4/S/A','soi12':'soi 12',',13 tên':', 13 tên','RAM150/600':'RAM 150/600','nhậnĐẠT':'nhận ĐẠT'}.items():md=md.replace(x,y)
Path(fresh(root/'DO LAI12 KY TU RAM V3 DE ROOT VA DO HOA DOC.md')).write_text(md,encoding='utf8')
