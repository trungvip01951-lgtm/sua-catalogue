"""Independent read-only actual-PDF photo QA; no PDF save or RGB retouch."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,time
import numpy as np
from PIL import Image
import fitz
from catfix.vector import Editor
from catfix.raster import Raster

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
LOCK=Path(S.report('G08/ROOT PHAT HANH MOT PDF ANH V5 CA8 TRANG/ROOT KHOA MOT PDF ANH M1 V5.json'))
lock=json.loads(LOCK.read_text(encoding='utf8'))
assert sha(LOCK)=='98a449eb4bffbdbc6a125ddc1a3afe0e0d956767e7779b0b26d1fa1fc0060ecc'
OUTROOT=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs')
PDF=OUTROOT/'per_wc_continue_photo_union_v5_PDF_mau1_a1'/'Catalog cắt rác perotac (bản mới).pdf'
PDF_SHA='74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee'
RAM=OUTROOT/'per_wc_continue_photo_union_v5_RAM_a1'
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_PDF M1 V5 DOC LAP DU8 TRANG'))
O.mkdir(parents=True,exist_ok=True)
guards={str(PDF):PDF_SHA,str(LOCK):sha(LOCK),lock['source_file']:lock['source_sha256'],lock['canonical_file']:lock['canonical_sha256'],lock['clip_file']:lock['clip_sha256'],lock['background']['file']:lock['background']['sha256']}
guards.update({p['source_JPEG']:p['source_JPEG_sha256'] for p in lock['products']})
for p,h in guards.items():assert sha(p)==h,(p,sha(p),h)
clip=json.loads(Path(lock['clip_file']).read_text(encoding='utf8'))

native=[]
e=Editor(str(PDF),backend='fitz')
assert e.n_pages==8
for job in lock['jobs8']:
 pi=job['page']-1;group=next(g for g in clip['groups'] if g['group']==job['group'])
 products=[i for i in Raster(e).images(pi) if i.name==job['original_source_JPEG_name']]
 backgrounds=[i for i in Raster(e).images(pi) if i.name.startswith('CfxPerStudioBg')]
 assert len(products)==len(backgrounds)==1
 im=products[0];bg=backgrounds[0];old=job['source_identity'];ops=e.page(pi).ops;di=im.index
 assert digest(e.doc.stream_raw(im.ref))==old['raw_JPEG_sha256']
 assert [im.W,im.H]==group['source_canvas_pixel']
 ctm=np.asarray(im.ctm);ctmdelta=float(np.max(np.abs(ctm-np.asarray(old['source_photo_ctm']))))
 assert ctmdelta<1e-10
 product_dictionary={k:str(v) if isinstance(v,str) else v for k,v in im.d.items() if k not in ['Length','SMask']}
 # Read dictionary values explicitly; backend Ref/Name wrappers are not metadata differences.
 product_dictionary={k:(int(im.d[k]) if k in ['Width','Height','BitsPerComponent'] else str(im.d[k])) for k in ['ColorSpace','Width','Subtype','Height','BitsPerComponent','Filter']}
 assert product_dictionary==old['original_image_dictionary_except_Length_SMaskRef'],product_dictionary
 sm=im.d.get('SMask');smrec=None
 if old['existing_source_SMask']:
  assert sm is not None
  smraw=e.doc.stream_raw(sm);assert digest(smraw)==old['existing_source_SMask']['raw_stream_sha256']
  pp=fitz.Pixmap(smraw);assert pp.n==1 and min(pp.samples)==max(pp.samples)==255
  smrec={'raw_SHA':digest(smraw),'width':pp.width,'height':pp.height,'minimum':255,'maximum':255,'decoded_samples':len(pp.samples)}
 else:assert sm is None
 assert ops[di-2].op=='W' and ops[di-1].op=='n'
 qi=max(i for i in range(di-2) if ops[i].op=='q')
 actual=[(op.op,[float(v) for v in op.operands]) for op in ops[qi+1:di-2]]
 expected=[];ringcount=0
 for sub in group['combined_clip_subpaths']:
  ringcount+=1
  for cmd in sub['commands_pixel']:
   if (isinstance(cmd,str) and cmd=='Z') or (isinstance(cmd,list) and cmd[0]=='Z'):expected.append(('h',[]))
   else:expected.append((cmd[0].lower(),[round(cmd[1]/im.W,10),round(1-cmd[2]/im.H,10)]))
 assert actual==expected,('CLIP_NOT_EXACT',job['page'],len(actual),len(expected))
 # Background XObject keeps exact decoded RGB values of the approved empty scene.
 samples,left,bd=e.doc.stream_decoded(bg.ref)
 assert not left and str(bd['ColorSpace'])=='DeviceRGB' and int(bd['BitsPerComponent'])==8
 original_bg=np.array(Image.open(lock['background']['file']).convert('RGB'))
 assert [int(bd['Width']),int(bd['Height'])]==[original_bg.shape[1],original_bg.shape[0]]
 assert samples==original_bg.tobytes()
 bi=bg.index;assert ops[bi-1].op=='cm'
 bgcm=[float(v) for v in ops[bi-1].operands]
 assert max(abs(a-b) for a,b in zip(bgcm,job['background_cover']['unit_cm']))<5.1e-11
 bq=max(i for i in range(bi) if ops[i].op=='q')
 assert [o.op for o in ops[bq+1:bi]]==['re','W','n','cm']
 assert [float(x) for x in ops[bq+1].operands]==[0.,0.,1.,1.]
 assert not any(op.op=='W*' for op in ops[bq:di+1])
 native.append({'page':job['page'],'group':job['group'],'product_Do_count':1,'background_Do_count':1,'source_JPEG_SHA':digest(e.doc.stream_raw(im.ref)),'source_dimensions':[im.W,im.H],'source_dictionary_match':True,'SMask':smrec,'source_CTM_max_difference':ctmdelta,'nonzero_clip_operator':'W n','clip_rings':ringcount,'clip_M_L_h_exact_round10_match':True,'background_RGB_bytes_equal':True,'background_decoded_RGB_SHA':digest(samples),'background_cover_cm':bgcm,'no_product_reencoding_resizing_or_new_CTM':True})
 assert not e.touched()
e.close()
print('NATIVE_READ_PASS_8',[(r['page'],r['clip_rings'],r['source_CTM_max_difference']) for r in native],flush=True)

def arraypix(p):return np.frombuffer(p.samples,dtype=np.uint8).reshape(p.height,p.width,p.n).copy()
def comparison(a,b):
 if a.shape!=b.shape:return {'same_shape':False,'shape_A':list(a.shape),'shape_B':list(b.shape),'pixel_equal':False,'changed_pixels_threshold0':None}
 changed=np.any(a!=b,axis=2);n=int(changed.sum());delta=np.abs(a.astype(np.int16)-b.astype(np.int16))
 if n:
  ys,xs=np.nonzero(changed);box=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]
 else:box=None
 return {'same_shape':True,'shape':list(a.shape),'pixel_equal':n==0,'changed_pixels_threshold0':n,'changed_bbox_halfopen':box,'maximum_channel_difference':int(delta.max()),'raw_RGB_SHA_A':digest(a.tobytes()),'raw_RGB_SHA_B':digest(b.tobytes()),'threshold':0,'ROI':'entire rendered image, no relaxed region'}
def pix(doc,job,kind,dpi):
 rect=fitz.Rect(job['allowed_photo_rect_top_fixed_before_RAM']) if kind=='photo' else None
 return doc[job['page']-1].get_pixmap(dpi=dpi,clip=rect,colorspace=fitz.csRGB,alpha=False)
def reference(job,kind,dpi):
 rk='RAM_photo' if kind=='photo' else 'RAM_whole_page'
 files=list(RAM.glob(f'*group{job["group"]}_p{job["page"]:02d}_{rk}_{dpi}dpi.png'))
 assert len(files)==1,files
 return files[0]
fresh_images=[];references=[]
# A fresh-open document for every individual render; no shared-document image cache.
for job in lock['jobs8']:
 for kind,dpi in [('whole',150),('photo',150),('photo',600)]:
  with fitz.open(str(PDF)) as doc:
   assert len(doc)==8
   pp=pix(doc,job,kind,dpi);a=arraypix(pp)
   fp=Path(fresh(O/f'g01_PDF THUC p{job["page"]:02d} {kind} {dpi}dpi.png'))
   pp.save(str(fp))
  rec={'page':job['page'],'group':job['group'],'kind':kind,'dpi':dpi,'file':str(fp),'SHA':sha(fp),'width':pp.width,'height':pp.height,'n':pp.n,'raw_RGB_SHA':digest(a.tobytes()),'document_open_mode':'fresh document per one render','colorspace':'DeviceRGB','alpha':False,'photo_rect_top':job['allowed_photo_rect_top_fixed_before_RAM'] if kind=='photo' else None}
  fresh_images.append(rec)
  if job['page'] in [1,4,6]:
   rp=reference(job,kind,dpi);b=np.array(Image.open(rp).convert('RGB'));references.append({'page':job['page'],'kind':kind,'dpi':dpi,'reference':str(rp),'reference_SHA':sha(rp),**comparison(a,b)})
 print('FRESH_PAGE_RENDERED',job['page'],flush=True)

def fresh_array(job,kind,dpi):
 rec=next(r for r in fresh_images if r['page']==job['page'] and r['kind']==kind and r['dpi']==dpi)
 return np.array(Image.open(rec['file']).convert('RGB'))

reuse_simple=[]
with fitz.open(str(PDF)) as doc:
 for job in [j for j in lock['jobs8'] if j['page'] in [1,4,6]]:
  for kind,dpi in [('whole',150),('photo',150),('photo',600)]:
   a=arraypix(pix(doc,job,kind,dpi));reuse_simple.append({'page':job['page'],'kind':kind,'dpi':dpi,'mode':'one reused document in order p1,p4,p6; whole150/photo150/photo600',**comparison(a,fresh_array(job,kind,dpi))})

# Also replay the producer RAM-render history explicitly: all eight native pages,
# full200 before each representative image set and canonical page in a second doc.
# Do not reset MuPDF store or alter antialias/color settings to conceal a delta.
reuse_history=[]
with fitz.open(str(PDF)) as doc, fitz.open(lock['canonical_file']) as base:
 for job in lock['jobs8']:
  base[job['page']-1].get_pixmap(dpi=200,colorspace=fitz.csRGB,alpha=False)
  doc[job['page']-1].get_pixmap(dpi=200,colorspace=fitz.csRGB,alpha=False)
  if job['page'] not in [1,4,6]:continue
  for kind,dpi in [('photo',150),('whole',150),('whole',600),('before_photo',150),('before_photo',600),('photo',600)]:
   if kind=='before_photo':
    base[job['page']-1].get_pixmap(dpi=dpi,clip=fitz.Rect(job['allowed_photo_rect_top_fixed_before_RAM']),colorspace=fitz.csRGB,alpha=False)
    continue
   pp=pix(doc,job,kind,dpi)
   if kind=='whole' and dpi==600:continue
   a=arraypix(pp);comp=comparison(a,fresh_array(job,kind,dpi))
   reuse_history.append({'page':job['page'],'kind':kind,'dpi':dpi,'mode':'producer-like reused document including page200/whole600/canonical photo reads',**comp})
   if not comp['pixel_equal']:
    fp=Path(fresh(O/f'g01_REUSE HISTORY p{job["page"]:02d} {kind} {dpi}dpi.png'));pp.save(str(fp));reuse_history[-1]['file']=str(fp);reuse_history[-1]['SHA']=sha(fp)
 print('HISTORY_PAGE_READ',job['page'],flush=True)

for p,h in guards.items():assert sha(p)==h,(p,'HASH_CHANGED')
data={'scope':'Independent graphics actual saved M1 PDF eight pages; read-only, no publishing, no TIEN DO','PDF':str(PDF),'PDF_SHA':sha(PDF),'PDF_bytes':PDF.stat().st_size,'pages':8,'bootstrap_environment':'BƯỚC0 report43/43 and all verdicts true','native_photo_checks8':native,'fresh_open_actual_PDF_renders24':fresh_images,'fresh_open_vs_accepted_RAM9':references,'reuse_simple_vs_fresh9':reuse_simple,'reuse_producer_history_vs_fresh9':reuse_history,'renderer_versions':{'PyMuPDF':fitz.VersionBind,'MuPDF':fitz.VersionFitz},'guard_SHA_final':guards,'no_PDF_writes':True,'no_RGB_pixel_retouch':True,'no_canonical_or_TIENDO_write':True,'visual_result':'PENDING opening all eight actual page images, all three actual600 photos, source/V4B/V5. Numeric/byte QA alone is not visual acceptance.'}
fp=Path(fresh(O/'g01_DOC TRUC TIEP PDF M1 - CLIP BYTE VA SO HAI CACH MO.json'))
fp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',fp,'SHA',sha(fp),flush=True)
print('EXACT_RAM',sum(r['pixel_equal'] for r in references),len(references),'REUSE_SIMPLE',sum(r['pixel_equal'] for r in reuse_simple),len(reuse_simple),'REUSE_HISTORY',sum(r['pixel_equal'] for r in reuse_history),len(reuse_history),flush=True)
print('DIFFERENCES',[r for r in reuse_simple+reuse_history+references if not r['pixel_equal']],flush=True)
