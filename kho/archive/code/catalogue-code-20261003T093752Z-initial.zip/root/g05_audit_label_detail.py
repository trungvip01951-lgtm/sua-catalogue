from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image
import numpy as np
E=Editor(S.dst('Perotac bơm giếng SP_compressed (bản mới).pdf'));R=Raster(E)
for p,rect,fam in [(4,(542,321,570,352),'6SP30-nhan-nho'),(4,(542,398,570,417),'6SP30-nhan30-32'),(6,(134,324,160,349),'6SP60-nhan-nho')]:
 cv=R.render_canvas(p,rect,dpi=1200)
 cv.save_png(fresh(S.report('G05/MAU SUA DUONG/'+fam+'.png')))
E.close()
