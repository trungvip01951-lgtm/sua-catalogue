from catwork import start,fresh
import json,sys,hashlib,numpy as np
from pathlib import Path
S,D,N=start()
from catfix.recipes import Job
from catfix import verify
from catfix.inspect_pdf import what_is_at
from catfix.otext import robust_fit
from catfix.vector import FILL_OPS
fi=int(sys.argv[1]) if len(sys.argv)>1 else 0
tag=sys.argv[2] if len(sys.argv)>2 else 'MAU LAN1'
d=json.loads(Path(S.report('G09/NGUON.json')).read_text(encoding='utf-8'))[fi]
j=Job(d['src'],fresh(S.report(f'G09/{tag}/{d["name"]}')),log_path=fresh(S.report(f'G09/{tag}/{d["short"]}.log.json')))
details=[]
for pi,r in [(0,None),(2,(60,45,554,311)),(3,(46,48,543,313)),(4,(65,610,546,738))]:
    j.T.learn([pi],rect=r,dpi=450)
def rep(p,old,new,r,task,align='left'):
    loc=what_is_at(j.src,p,r,E=j.E)
    assert loc['text_layer'][0]=='',(old,loc)
    mm=j.T.find(p,old,rect=r);assert len(mm)==1,(old,len(mm))
    m=mm[0];dr=j.T.replace(m,new,align=align,dry_run=True)
    print(task,old,'→',new,'rect',m.bbox,'plan',dr,flush=True)
    j.T.replace(m,new,align=align)
    j._add(p,r,f'#{task} {old} → {new}','outline')
    details.append(dict(task=task,page=p+1,rect=r,old=old,new=new,what=loc,plan=dr))
body=[
(694,704,'The body of motor and pump is made of rigid cast iron for long-lasting durability.'),
(681,690,'Greatly increased maximum submersion depth due to mechanical seal resistant to high pressure.'),
(668,677,'Semi-open impeller made of high chrome alloy match with wear plate(ductile iron) achieves superior'),
(654,664,'durability.'),
(641,651,'Effective motor cooling due to discharge channel cast as part of the motor housing.Space economically'),
(628,638,'by a top outlet.'),
(602,612,'Hermetically sealed motor equipped build-in thermal protection for the power below 15kW.'),
]
import re
seq=[]
for y0,y1,text in body:
    gl=sorted([g for ln in j.T.lines(0,(79,y0,531,y1)) for g in ln],key=lambda g:g.bbox[0])
    assert len(gl)==len(text.replace(' ','')),text
    index=0
    for token in text.split(' '):
        bx=[g.bbox for g in gl[index:index+len(token)]];index+=len(token)
        if re.fullmatch('[a-z]+',token):seq.append(dict(chars=token,boxes=bx))
F=robust_fit(seq)
assert all(0<F['adv'][c]<10 for c in 'eidts') and F['max_x']<.01,(F['max_x'],F['adv'])
def source_letters(r):
    loc=what_is_at(j.src,0,r,E=j.E);assert loc['text_layer'][0]==''
    return sorted([g for ln in j.T.lines(0,r) for g in ln],key=lambda g:g.bbox[0])
def copy_replace(target,proto,old,new,following):
    tx=float(target.bbox[0])-F['lsb'][old]+F['lsb'][new]
    ty=float(target.bbox[1])-F['bot'][old]+F['bot'][new]
    path=j.E.glyph_pagepath(0,proto.oi,proto.g)
    j.E.delete_group(0,target.oi,target.g)
    j.E.insert_path(0,target.oi,path,dx=tx-float(proto.bbox[0]),dy=ty-float(proto.bbox[1]))
    dx=F['adv'][new]-F['adv'][old]
    for g in following:j.E.move_group(0,g.oi,g.g,dx,0)
    return dict(old=old,new=new,source_bbox=proto.bbox,target_bbox=target.bbox,new_ink_origin=[tx,ty],shift_rest=dx,font_fit_rms=F['rms_x'],font_fit_max=F['max_x'])
r=(309.8,197.3,389,207.1);gl=source_letters(r);assert len(gl)==16
plan=copy_replace(gl[3],gl[1],'e','i',gl[4:]);j._add(0,r,'#71 Civel engineering → Civil engineering','outline')
details.append(dict(task=71,page=1,rect=r,old='Civel engineering',new='Civil engineering',plan=plan))
r=(239.8,601.5,473.8,612);gl=source_letters(r)
assert len(gl)==len('build-inthermalprotectionforthepowerbelow15kW.')
plan=copy_replace(gl[4],gl[8],'d','t',gl[5:]);j._add(0,r,'#71 build-in → built-in, giữ khoảng chữ','outline')
details.append(dict(task=71,page=1,rect=r,old='build-in thermal protection for the power below 15kW.',new='built-in thermal protection for the power below 15kW.',plan=plan))
rep(4,'a','s',(474.3,701.3,479.8,707.7),72)
rep(2,'1.60','1.50',(336,112,356,123),73,'center')
rep(3,'1.60','1.50',(322,116,342,126),73,'center')
rep(3,'0.60','0.50',(322,225,342,234),74,'center')
# #75: số 637 đúng đã có sẵn; bỏ hai chữ SH và dời cả ba nét số để căn tâm nhãn.
r=(117,602,138,612)
if fi==1:r=(r[0]+1.19064,r[1]-2.1024,r[2]+1.19064,r[3]-2.1024)
P=j.E.page(6)
gs=sorted([g for g in j.T.page_glyphs(6) if r[0]<=(g.bbox[0]+g.bbox[2])/2<=r[2] and r[1]<=(g.bbox[1]+g.bbox[3])/2<=r[3] and P.color_of(g.oi,'fill')==(0.,0.,0.)],key=lambda g:g.bbox[0])
assert len(gs)==5,[(g.oi,g.bbox) for g in gs]
for g in gs[:2]:j.E.delete_group(6,g.oi,g.g)
for g in gs[2:]:j.E.move_group(6,g.oi,g.g,-3.4,.65)
# Nhãn này còn lớp nét viền S trùng toàn bộ chữ SH637; phải sửa cả lớp đó.
gb=(min(g.bbox[0] for g in gs),min(g.bbox[1] for g in gs),max(g.bbox[2] for g in gs),max(g.bbox[3] for g in gs))
tw=[oi for oi in P.objects_in(r) if P.objs[oi]['op']=='S' and P.color_of(oi,'stroke')==(0.,0.,0.) and max(abs(float(a-b)) for a,b in zip(P.objs[oi]['bbox'],gb))<.01]
assert len(tw)==1,tw
tg=P.merged_glyphs(tw[0]);assert len(tg)==5
for g in tg[:2]:j.E.delete_group(6,tw[0],g)
for g in tg[2:]:j.E.move_group(6,tw[0],g,-3.4,.65)
j._add(6,r,'#75 SH637 → 637, chép nét số có sẵn','outline')
details.append(dict(task=75,page=7,rect=r,old='SH637',new='637',deleted=[dict(oi=g.oi,subs=g.g['subs'],bbox=g.bbox) for g in gs[:2]],stroke_twin=tw[0],move637=[-3.4,.65]))
# #76: xác định đúng 4 đối tượng số 03, nền viền cũ, đường dẫn riêng và chấm đỏ.
p=1;P=j.E.page(p)
def one_obj(box,op,color,kind,min_width=0):
    cand=[oi for oi in P.objects_in(box,full=True) if (P.objs[oi]['op'] in FILL_OPS if op=='FILL' else P.objs[oi]['op']==op) and np.max(abs(np.array(P.color_of(oi,kind))-np.array(color)))<.001 and P.objs[oi]['bbox'][2]-P.objs[oi]['bbox'][0]>=min_width]
    assert len(cand)==1,(box,op,cand)
    return cand[0]
labelbox=(211.9,661.6,220.9,668.1)
white=one_obj(labelbox,'FILL',(.996094,)*3,'fill')
black=one_obj(labelbox,'FILL',(.199951,.173096,.168945),'fill')
leader=one_obj((192.1,664.8,211,669.9),'S',(.199951,.173096,.168945),'stroke',min_width=15)
dot=one_obj((190.9,668.3,193.7,671.1),'FILL',(.902344,.128906,.160889),'fill')
# Số 1 nguồn ở chú thích 01, cùng cỡ/phông/màu với chú thích 03.
sr=(101.8,695.4,104.5,701.9)
srcg=[g for g in j.T.page_glyphs(1) if sr[0]<=(g.bbox[0]+g.bbox[2])/2<=sr[2] and sr[1]<=(g.bbox[1]+g.bbox[3])/2<=sr[3] and P.color_of(g.oi,'fill')==(.199951,.173096,.168945)]
assert len(srcg)==1,[g.bbox for g in srcg]
g=srcg[0];path=j.E.glyph_pagepath(1,g.oi,g.g);dy=594.0-float(g.bbox[1])
j.E.insert_path(1,g.oi,path,dx=-4.6032-9.4,dy=dy)
j.E.insert_path(1,g.oi,path,dx=-9.4,dy=dy)
tip=(135.4,610.0);linepath=[('m',[(96.8,596.8)]),('l',[tip])]
j.E.insert_object_after(1,leader,linepath)
bb=P.objs[dot]['bbox'];cx=(bb[0]+bb[2])/2;cy=(bb[1]+bb[3])/2
dotpath=j.E.transform_path(P.object_pagepath(dot),dx=tip[0]-cx,dy=tip[1]-cy)
j.E.insert_object_after(1,dot,dotpath)
for oi in [white,black,leader,dot]:j.E.delete_object(1,oi)
oldr=(190.8,660.8,222,671.6);newr=(87,592.8,137,611.6)
j._add(1,oldr,'#76 xóa 03 + đường riêng + chấm','outline+leader')
j._add(1,newr,'#76 thêm 11 chỉ vỏ động cơ','outline+leader')
details.append(dict(task=76,page=2,rect=oldr,new_rect=newr,old='03 ở chỗ bắt cáp',new='11 chỉ vỏ động cơ',delete_objects=[white,black,leader,dot],source_digit=dict(oi=g.oi,bbox=g.bbox),line=linepath,tip=tip))
j.save();ck=j.check();print('CHECK',ck['ok'],ck['unexpected'],ck['missing'],flush=True)
j.evidence(fresh(S.report(f'G09/{tag}/TRUOC SAU {d["short"]}.png')),dpi=300)
verify.page_overview(j.src,j.dst,1,fresh(S.report(f'G09/{tag}/HINH CAT {d["short"]}.png')),dpi=160)
Path(fresh(S.report(f'G09/{tag}/KIEM TRA {d["short"]}.json'))).write_text(json.dumps(dict(check=ck,details=details,sha256=hashlib.sha256(Path(j.dst).read_bytes()).hexdigest()),ensure_ascii=False,indent=2,default=str),encoding='utf-8')
Path(fresh(S.report(f'G09/{tag}/KHOANG CHU {d["short"]}.json'))).write_text(json.dumps(F,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
j.close()
