"""Pure independent readback of serialized Perotac content and visible pixels."""
from io import BytesIO
import json, hashlib
import numpy as np
import pymupdf as fitz
import pikepdf
from scipy import ndimage
from scipy.integrate import quad
from catfix.vector import VPage
from catfix.cs import parse
from g04_perotac_whole_pdf_tools46 import xml_values, pixel_at, page_at_pixel

def metadata(doc):
    return dict(page_count=len(doc),Info=doc.metadata,XMP_semantic=xml_values(doc.get_xml_metadata()),
        bookmarks=doc.get_toc(simple=False),
        links=[[{k:str(v) for k,v in row.items() if k!='xref'} for row in p.get_links()] for p in doc],
        annotations=[[dict(type=a.type,rect=list(a.rect),info=a.info,flags=a.flags,colors=a.colors,border=a.border,opacity=a.opacity)
                       for a in (p.annots() or [])] for p in doc],
        rects=[list(p.rect) for p in doc],rotations=[p.rotation for p in doc],
        boxes=[dict(Media=list(p.mediabox),Crop=list(p.cropbox),Bleed=list(p.bleedbox),Trim=list(p.trimbox),Art=list(p.artbox)) for p in doc],
        fonts=[[list(f[1:]) for f in p.get_fonts(full=True)] for p in doc],texts=[p.get_text('text') for p in doc])

def image_resources(pdf):
    def record(image):
        fields=['Width','Height','ColorSpace','BitsPerComponent','Filter','Decode','DecodeParms','Interpolate','Intent']
        out={key:str(image.get('/'+key)) for key in fields}
        out['raw_sha256']=hashlib.sha256(image.read_raw_bytes()).hexdigest()
        mask=image.get('/SMask')
        out['SMask']=record(mask) if isinstance(mask,pikepdf.Stream) else str(mask)
        return out
    result=[]
    def walk(res,prefix,rows):
        for name,obj in res.get('/XObject',pikepdf.Dictionary()).items():
            if obj.get('/Subtype')==pikepdf.Name('/Image'):rows[prefix+str(name)]=record(obj)
            elif obj.get('/Subtype')==pikepdf.Name('/Form'):walk(obj.get('/Resources',pikepdf.Dictionary()),prefix+str(name)+'/',rows)
    for page in pdf.pages:
        rows={};walk(page.Resources,'',rows);result.append(rows)
    return result

def render_document(doc,pi,dpi,clip=None):
    p=doc[pi];T=p.transformation_matrix;s=dpi/72
    if clip is not None:
        a=fitz.Point(clip[0],clip[1])*T;b=fitz.Point(clip[2],clip[3])*T
        clip=fitz.Rect(min(a.x,b.x),min(a.y,b.y),max(a.x,b.x),max(a.y,b.y))
    pix=p.get_pixmap(matrix=fitz.Matrix(s,s),clip=clip,colorspace=fitz.csRGB,alpha=False)
    ar=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[:,:,:3].copy()
    return ar,dict(T=[float(v) for v in T],origin=[pix.x,pix.y],scale=s,dpi=dpi)

def outside_read(before,after,roi,pi=7,dpi=200):
    out=[]
    for page in range(len(before)):
        a,ma=render_document(before,page,dpi);b,mb=render_document(after,page,dpi)
        if a.shape!=b.shape:
            out.append(dict(page=page+1,result='CHƯA ĐẠT',reason='size changed'));continue
        change=np.any(a!=b,axis=2);allowed=np.zeros(change.shape,bool)
        if page==pi:
            p0=pixel_at(roi[:2],ma);p1=pixel_at(roi[2:],ma)
            x0,y0=np.floor(np.minimum(p0,p1)).astype(int);x1,y1=np.ceil(np.maximum(p0,p1)).astype(int)
            allowed[max(0,y0):min(a.shape[0],y1),max(0,x0):min(a.shape[1],x1)]=True
        bad=change&~allowed
        where=np.argwhere(bad);box=[where[:,1].min(),where[:,0].min(),where[:,1].max()+1,where[:,0].max()+1] if len(where) else None
        out.append(dict(page=page+1,changed_pixels=int(change.sum()),outside_changed_pixels=int(bad.sum()),outside_bbox_pixels=box,
                        dpi=dpi,threshold=0,pad=0,min_size=0,result='ĐẠT NGOÀI VÙNG' if not bad.any() else 'CHƯA ĐẠT'))
    return out

def same_path(a,b):
    return len(a)==len(b) and all(x[0]==y[0] and np.asarray(x[1]).shape==np.asarray(y[1]).shape
        and np.allclose(np.asarray(x[1],float),np.asarray(y[1],float),rtol=0,atol=2e-8) for x,y in zip(a,b))

def native_segments(path,cv):
    result=[];last=None
    for op,points in path:
        if op=='m':last=np.asarray(cv.to_px(*points[0]),float)
        elif op=='c':
            control=np.array([last]+[np.asarray(cv.to_px(*p),float) for p in points])
            result.append(control);last=control[-1]
    return result

def at_u(segments,u):
    for c in segments:
        if c[0,0]-1e-7<=u<=c[3,0]+1e-7:
            # Exact polynomial root, not sample/rank interpolation.
            coefficients=[-c[0,0]+3*c[1,0]-3*c[2,0]+c[3,0],3*c[0,0]-6*c[1,0]+3*c[2,0],-3*c[0,0]+3*c[1,0],c[0,0]-u]
            while abs(coefficients[0])<1e-10 and len(coefficients)>1:coefficients.pop(0)
            roots=np.roots(coefficients)
            possible=[float(z.real) for z in roots if abs(z.imag)<1e-7 and -1e-7<=z.real<=1+1e-7]
            if not possible:continue
            t=np.clip(possible[0],0,1);p=(1-t)**3*c[0]+3*(1-t)**2*t*c[1]+3*(1-t)*t*t*c[2]+t**3*c[3]
            d=3*(1-t)**2*(c[1]-c[0])+6*(1-t)*t*(c[2]-c[1])+3*t*t*(c[3]-c[2])
            return p,d
    return None,None

def profile(ar,mapping,cv,point,tangent,endpoint=None):
    center=pixel_at(cv.to_page(*point),mapping)
    direction=pixel_at(cv.to_page(*(point+tangent)),mapping)-center;direction/=np.linalg.norm(direction)
    normal=np.array([-direction[1],direction[0]])
    offsets=np.linspace(-12,12,193)
    along=np.linspace(0.3,1.3,5) if endpoint=='start' else np.linspace(-1.3,-.3,5) if endpoint=='end' else np.linspace(-.4,.4,5)
    values=[];rgb=[]
    for t in along:
        coords=center+t*direction+offsets[:,None]*normal
        colors=np.array([ndimage.map_coordinates(ar[:,:,k].astype(float),[coords[:,1]-.5,coords[:,0]-.5],order=1,mode='constant',cval=255) for k in range(3)]).T
        alpha=np.clip(((colors[:,1]-colors[:,0])*18+(colors[:,2]-colors[:,0])*23)/(18**2+23**2),0,1)
        values.append(alpha);rgb.append(colors)
    alpha=np.mean(values,axis=0);rgb=np.mean(rgb,axis=0)
    if alpha.max()<.1:return dict(result='CHƯA THỂ XÁC MINH',reason='No visible matching-color ink')
    weight=np.maximum(alpha-.02,0);offset=float(np.sum(offsets*weight)/weight.sum())
    visible_page=page_at_pixel(center+normal*offset,mapping);visible_native=np.array(cv.to_px(*visible_page))
    width=float(np.trapezoid(alpha,offsets)*72/mapping['dpi'])
    # Interpolated 10–90% transitions on both sides of the measured center.
    transitions=[];maximum=alpha.max();normalized=alpha/maximum
    for side in ['left','right']:
        inds=np.where(offsets<offset)[0] if side=='left' else np.where(offsets>offset)[0][::-1]
        xx=offsets[inds];aa=normalized[inds]
        def crossing(level):
            ok=np.where((aa[:-1]<=level)&(aa[1:]>=level))[0]
            if not len(ok):return None
            i=ok[0];return float(xx[i]+(level-aa[i])/(aa[i+1]-aa[i])*(xx[i+1]-xx[i]))
        a10,a90=crossing(.1),crossing(.9)
        transitions.append(abs(a90-a10) if a10 is not None and a90 is not None else None)
    core=rgb[alpha>.95]
    return dict(result='CÓ MỰC THẬT',visible_native_center=visible_native.tolist(),normal_center_offset_600px=offset,
        equivalent_chroma_area_width_pt=width,edge10_90_width_600px=transitions,
        core_RGB_median=np.median(core,axis=0).tolist() if len(core) else None,
        matching_color_peak_alpha=float(alpha.max()),cross_section_offset600=offsets.tolist(),cross_section_alpha=alpha.tolist())

def actual_paths_and_ink(content,report,ram,cv,ar600,mapping):
    P=VPage(parse(content));matches=[];indices=set();rows={};eta=[]
    for expected in report['new_objects']:
        hits=[]
        for oi,obj in enumerate(P.objs):
            if oi in indices or obj['op']!=expected['paint'] or obj['gs']!=report['new_normal_opaque_gs']:continue
            actual=P.object_pagepath(oi)
            if same_path(actual,expected['pagepath']):hits.append((oi,obj,actual))
        if len(hits)!=1:
            matches.append(dict(kind=expected['kind'],key=expected['key'],matches=len(hits),result='CHƯA ĐẠT'));continue
        oi,obj,path=hits[0];indices.add(oi)
        col=P.color_of(oi,'stroke' if expected['paint']=='S' else 'fill')
        style=bool(np.allclose(col,np.asarray(expected['RGB'])/255,rtol=0,atol=2e-9))
        if expected['paint']=='S':style=style and abs(obj['lw']-expected['width_pt'])<1e-8 and (obj['dash'] is None or obj['dash'][0]==[])
        rec=dict(kind=expected['kind'],key=expected['key'],actual_object_index=oi,actual_RGB255=[float(v*255) for v in col],
                 actual_width_pt=obj['lw'] if expected['paint']=='S' else None,actual_gs=obj['gs'],actual_clip=obj['clip'],
                 actual_path_sha256=hashlib.sha256(json.dumps(path).encode()).hexdigest(),result='KHỚP PATH/STYLE' if style else 'CHƯA ĐẠT')
        matches.append(rec)
        if expected['kind']=='QH':rows.setdefault(expected['model'],[]).extend(native_segments(path,cv))
        elif expected['kind']=='eta':eta=native_segments(path,cv)
    ht=np.array([t['H_m'] for t in ram['main_H_actual_local_ticks']]);hv=np.array([t['native_v'] for t in ram['main_H_actual_local_ticks']]);order=np.argsort(hv);hv=hv[order];ht=ht[order]
    numeric=[];styles=[];monotone=[];arclengths=[]
    for row in ram['QH_rows']:
        segments=rows.get(row['model'],[])
        for j,node in enumerate(row['numeric_nodes']):
            point,tangent=at_u(segments,node['native_u'])
            if point is None:
                numeric.append(dict(model=row['model'],Q_m3_h=node['Q_m3_h'],result='CHƯA ĐẠT',reason='No actual stroked path through anchor'));continue
            h=float(np.interp(point[1],hv,ht));prof=profile(ar600,mapping,cv,point,tangent,'start' if j==0 else 'end' if j==7 else None)
            visible_h=float(np.interp(prof['visible_native_center'][1],hv,ht)) if 'visible_native_center' in prof else None
            delta=h-node['H_source_m'];visible_delta=visible_h-node['H_source_m'] if visible_h is not None else None
            tolerance=max(1,.02*node['H_source_m'])
            numeric.append(dict(model=row['model'],Q_m3_h=node['Q_m3_h'],H_table_m=node['H_source_m'],actual_path_H_m=h,
                path_delta_m=delta,actual_visible_H_m=visible_h,visible_delta_m=visible_delta,tolerance_m=tolerance,
                actual_profile=prof,result='KHỚP PATH VÀ MỰC' if abs(delta)<=tolerance and visible_delta is not None and abs(visible_delta)<=tolerance else 'CHƯA ĐẠT'))
        min_dx=1e99;min_dy=1e99
        for c in segments:
            t=np.linspace(0,1,257)[:,None];derivative=3*(1-t)**2*(c[1]-c[0])+6*(1-t)*t*(c[2]-c[1])+3*t*t*(c[3]-c[2])
            min_dx=min(min_dx,float(derivative[:,0].min()));min_dy=min(min_dy,float(derivative[:,1].min()))
            pagec=np.array([cv.to_page(*p) for p in c])
            length=quad(lambda v:float(np.linalg.norm(3*(1-v)**2*(pagec[1]-pagec[0])+6*(1-v)*v*(pagec[2]-pagec[1])+3*v*v*(pagec[3]-pagec[2]))),0,1,epsabs=1e-10)[0]
            arclengths.append(dict(model=row['model'],actual_segment_page_pt_length=length,actual_source_native_control_points=c.tolist()))
        monotone.append(dict(model=row['model'],minimum_dU=min_dx,minimum_dV=min_dy,actual_stroked_source_native_domain=[float(segments[0][0,0]),float(segments[-1][-1,0])] if segments else None,
                             result='GIẢM THEO LƯU LƯỢNG' if min_dx>=-1e-7 and min_dy>=-1e-7 else 'CHƯA ĐẠT'))
        q=np.array(row['literal_source_Q_m3_h']);u=np.array(row['native_real_tick_nodes'])[:,0]
        for value in [8.25,10.25,12.75,16.25,19.25]:
            x=float(np.interp(value,q,u));point,tangent=at_u(segments,x)
            if point is None:continue
            p=profile(ar600,mapping,cv,point,tangent)
            styles.append(dict(model=row['model'],Q_measure_m3_h=value,measurement='Visible PDF pixels at600dpi, color-chroma normal integral',**p))
    for x in [200.,300.,400.,520.,630.]:
        point,tangent=at_u(eta,x)
        if point is not None:styles.append(dict(model='ETA own558',source_native_u=x,measurement='Visible PDF pixels at600dpi, color-chroma normal integral',**profile(ar600,mapping,cv,point,tangent)))
    style_summary=[]
    for model in [r['model'] for r in ram['QH_rows']]+['ETA own558']:
        samples=[s for s in styles if s['model']==model and 'equivalent_chroma_area_width_pt' in s]
        widths=[s['equivalent_chroma_area_width_pt'] for s in samples]
        edges=[e for s in samples for e in s['edge10_90_width_600px'] if e is not None]
        cores=[s['core_RGB_median'] for s in samples if s['core_RGB_median'] is not None]
        style_summary.append(dict(model=model,normal_sections=len(samples),equivalent_widths_pt=widths,
             median_equivalent_width_pt=float(np.median(widths)) if widths else None,
             within_model_max_width_delta_from_median_percent=max(abs(np.array(widths)/np.median(widths)-1))*100 if widths else None,
             max_10_90_transition_600px=max(edges) if edges else None,core_RGB_median=np.median(cores,axis=0).tolist() if cores else None,
             graphic_review_still_PENDING=True))
    return dict(new_object_matches=matches,actual_13_QH_models=list(rows),actual_eta_cubic_segments_source_native=[c.tolist() for c in eta],
        actual104_path_and_visible_points=numeric,actual_monotone=monotone,
        actual_page_space_segment_arclengths=arclengths,actual_normal_style_sections=styles,actual_style_summary=style_summary,
        all_named_new_objects_match=all(r['result']=='KHỚP PATH/STYLE' for r in matches),
        all104_path_and_visible_points_match=len(numeric)==104 and all(r['result']=='KHỚP PATH VÀ MỰC' for r in numeric),
        actual_image_render_is_serialized_memory_not_saved_file=True,PDF_file_readback_NOT_RUN=True,
        no_visual_or_full_curve_acceptance_claimed=True)
