from catwork import start,fresh
S,D,N=start()
from catfix.raster import Raster
from catfix.vector import Editor
from pathlib import Path
import json
NAME='Aquaris FS_300dpi_75% (bản mới).pdf'
root=Path(S.report('G06'));E=Editor(S.src(NAME));R=Raster(E)
cvs=[R.canvas(R.image_at(i,E.mediabox(i))) for i in range(4)]
regions=[(1,(21,204,103,220),'FS-35-7-2.2'),(2,(22,200,111,250),None),(3,(311.3,478.06,419.5,499.94),None)]
details=[]
for pi,rect,txt in regions:
    cv=cvs[pi];ws=R.ocr(cv,box=cv.box(rect),scale=3,psm=7 if txt or pi==3 else 6)
    bank=R.glyph_bank(cv,words=ws)
    comps=R.components(cv,cv.box(rect),expect=len(txt)) if txt else []
    print(pi+1,' '.join(w['text'] for w in ws),'glyphs',sorted(bank['glyphs']),'comps',len(comps),flush=True)
    details.append(dict(page=pi+1,rect=rect,words=ws,glyphs=sorted(bank['glyphs']),components=[dict(box=c['box'],keys=list(c)) for c in comps]))
    cv.save_png(fresh(root/f'font-p{pi+1}.png'),box=cv.box(rect),scale=3)
json.dump(details,open(fresh(root/'font-probe.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
