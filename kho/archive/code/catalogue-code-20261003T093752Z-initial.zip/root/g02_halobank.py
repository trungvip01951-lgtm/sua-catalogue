"""Viền mở rộng: chép nguyên mẫu đã ghép chắc chắn, biến đổi cùng hình chữ xanh."""
from catfix.otext import procrustes,Sim
from catfix.vector import union
import numpy as np

def make_halobank(T):
    refs=[];P=T.E.page(8)
    for oi in range(363,411):
        gl=[g for g in T.page_glyphs(8) if g.oi==oi];assert len(gl)==1
        g=gl[0];ho=oi-48;gg=P.merged_glyphs(ho);assert len(gg)==1
        assert min(P.color_of(ho,'fill'))>.995
        a=g.bbox;b=gg[0]['bbox']
        assert max(abs((a[k]+a[k+2]-b[k]-b[k+2])/2) for k in range(2))<.4
        refs.append(dict(char=g.char,g=g,halo_key=8,halo_oi=ho,halo_g=gg[0]))
    for oi,ho,c in [(405,400,'6'),(429,424,'9')]:
        g=next(g for g in T.page_glyphs(9) if g.oi==oi);gg=T.E.page(9).merged_glyphs(ho)
        assert len(gg)==1 and min(T.E.page(9).color_of(ho,'fill'))>.995
        refs.append(dict(char=c,g=g,halo_key=9,halo_oi=ho,halo_g=gg[0]))
    # Có hai cách đóng đường hình chữ nhật mlllh/mlllc trong bản PDF.
    for oi,ho,c,key in [(360,353,'-',2),(362,355,'.',2),(406,401,'-',9),(420,419,'.',9)]:
        g=next(g for g in T.page_glyphs(key) if g.oi==oi);gg=T.E.page(key).merged_glyphs(ho)
        assert len(gg)==1 and min(T.E.page(key).color_of(ho,'fill'))>.995
        refs.append(dict(char=c,g=g,halo_key=key,halo_oi=ho,halo_g=gg[0]))
    assert set('0123456789.-')<=set(r['char'] for r in refs)
    return refs

def plot_halos(E,p,plot):
    """Các hình viền trắng nhỏ trong dải nhãn đầu đường, cùng đối tượng biểu đồ."""
    rect=(plot[0]-25,plot[1]-15,plot[0]+82,plot[3]+20);out=[];P=E.page(p)
    for oi in P.objects_in(rect):
        o=P.objs[oi];col=P.color_of(oi,'fill')
        if o['op'] not in ['f','f*'] or col is None or min(col)<.995:continue
        for gg in P.merged_glyphs(oi):
            b=gg['bbox'];cx=(b[0]+b[2])/2;cy=(b[1]+b[3])/2
            if rect[0]<=cx<=rect[2] and rect[1]<=cy<=rect[3] and b[2]-b[0]<12 and b[3]-b[1]<13:
                out.append((oi,gg))
    assert out,(p+1,'Không có hình viền trắng ở dải nhãn')
    return out

def insert_halo(E,p,target,g,shift,bank):
    cand=[]
    for r in bank:
        if r['char']!=g.char or r['g'].ops!=g.ops or r['g'].pts.shape!=g.pts.shape:continue
        variants=[r['g'].pts]
        if len(g.pts)==4:variants=[np.roll(r['g'].pts,k,axis=0) for k in range(4)]
        for A in variants:
            s,R,t,res=procrustes(A,g.pts,allow_rotation=True)
            if .4<s<2 and res<.03:cand.append((res,r,s,R,t))
    assert cand,(p+1,g.char,g.ops,len(g.pts),'Không khớp viền mẫu cùng chữ')
    res,r,s,R,t=min(cand,key=lambda c:c[0])
    M=Sim(s,R,t+np.asarray(shift)).matrix3()
    E.insert_path(p,target,E.glyph_pagepath(r['halo_key'],r['halo_oi'],r['halo_g']),Mx=M)
    return dict(char=g.char,res=float(res),scale=float(s),source_page=r['halo_key']+1,source_oi=r['halo_oi'])
