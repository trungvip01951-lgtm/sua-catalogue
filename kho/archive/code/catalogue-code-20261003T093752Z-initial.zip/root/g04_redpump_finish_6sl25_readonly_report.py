"""Close readonly evidence checkpoint for ROOT before returning to glyph RAM."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from datetime import datetime
import json,hashlib,numpy as np
from PIL import Image
from catfix.vector import Editor
from catfix.raster import Raster

root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
out=root/'6SL25 Q27 DOC ACTUAL600 RIENG LAN3'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
raw=read(out/'HAI DIEM Q27 DO MUC ACTUAL600 NGUON VA BAN GIAO.json')
manifest=read(root/'DANH MUC BANG NGUON 196 DONG V2.json')
ax=next(z for z in read(root/'17 TRUC DOC NGUON RIENG KHOA V1.json')['records'] if z['family']=='6SL25')
frame=next(z for z in read(root/'17 TRUC NGUON XY CANDIDATE V4.json')['records'] if z['family']=='6SL25')
bands=next(z for z in read(root/'17 TRUC NGUON CANDIDATE.json')['records'] if z['family']=='6SL25')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=[sha(raw['source']),sha(raw['current'])]
assert before==[raw['source_SHA256'],raw['current_SHA256']]
E=Editor(raw['source'],backend='fitz');R=Raster(E)
for dpi in [150,600]:
    Image.fromarray(R.render_canvas(9,(633,310,813,376),dpi=dpi).orig).save(fresh(out/f'NGUON Q L MIN VA M3 H VACH THUC {dpi}dpi.png'))
    Image.fromarray(R.render_canvas(9,(633,327,813,515),dpi=dpi).orig).save(fresh(out/f'NGUON QH ETA TEN VA VACH THUC {dpi}dpi.png'))
E.close()
states=[]
for z in raw['records']:
    source,current=z['actual_reads'];assert source['H_curve']==current['H_curve']
    states.append(dict(model=z['model'],Q=z['Q'],H_table=z['H_table'],H_actual=source['H_curve'],
        error_m=source['error'],source_conservative_uncertainty_m=source['conservative_uncertainty_m'],
        allowed_error_m=source['max_error_allowed'],
        remaining_certain_error_m=max(0,abs(source['error'])-source['conservative_uncertainty_m']),
        status=source['status'],status_scope='Kết quả phép đọc thực này, cần ROOT đọc độc lập trước phương án thay đường.',
        raw_record_outer_status_correction='Trường status cấp record trong JSON thô dùng câu tổng quát. Trạng thái đo đúng lấy actual_reads: /20 CHƯA ĐẠT, /16 CHƯA THỂ.',
        actual_source_current_same=True,
        proof=dict(table=z['source_table_row']['table_photo'],table_position=z['source_cell_position'],
            identity=z['name_evidence'],trace=z['whole_trace_photo'],source_ink=source['source_photo'],current_ink=current['source_photo'])))
groups=[]
for family in ['2.5SL1.5','3SL4','4SL2','4SL3','6SL25']:
    name=family.replace('.','_');p=root/f'DOC MUC LOCAL NGOAI P8 {name} LAN1'/'DO MUC LOCAL DOC NGUON VA BAN GIAO CHUA CHOT.json'
    d=read(p);points=[z for r in d['records'] for z in r.get('numeric_points',[])]
    groups.append(dict(family=family,records=len(d['records']),table_anchor_rows_attempted=len(points),
        file=str(p),SHA256=sha(p),acceptance=False,
        scope='Bám mực và điểm ứng viên; chưa soi/chốt toàn bộ đường, không cộng số ĐẠT.'))
anchors=[]
for row in [z for z in manifest['rows'] if z['family']=='6SL25']:
    aa=[]
    qv=np.array(ax['Q_printed_values']);qx=np.array(ax['Q_printed_tick_page_x'])
    hv=np.array(ax['H_printed_values_used'])[::-1];hy=np.array(ax['H_printed_grid_page_y'])[::-1]
    for Q,H in zip(row['Q'],row['H']):
        inq=qv.min()<=Q<=qv.max();inh=hv.min()<=H<=hv.max()
        aa.append(dict(Q=Q,H_source=H,
            local_x_candidate=float(np.interp(Q,qv,qx)) if inq else None,
            local_y_candidate=float(np.interp(H,hv,hy)) if inh else None,
            status='KẾ HOẠCH LOCAL' if inq and inh else 'CHƯA THỂ ánh xạ đủ: Q33 chưa có vạch số riêng khóa',
            already_numeric_accepted=False))
    anchors.append(dict(model=row['model'],Q=row['Q'],H=row['H'],source_table_photo=row['table_photo'],
        source_H_at_Q0_to_Q3_increase_is_source_data_not_error=row['H'][1]>row['H'][0],anchors=aa))
plan=dict(chart='6SL25',page=10,source=raw['source'],source_SHA256=before[0],input_current=raw['current'],input_SHA256=before[1],
    models=10,H_source_cells=120,models_and_source_anchors=anchors,
    numeric_error_current_read=states,
    actual_axis_file=str(root/'17 TRUC DOC NGUON RIENG KHOA V1.json'),
    local_Q=dict(values=ax['Q_printed_values'],tick_x=ax['Q_printed_tick_page_x']),
    local_H=dict(values=ax['H_printed_values_used'],tick_y=ax['H_printed_grid_page_y']),
    Q33_gap='Chưa khóa vạch phụ Q33. Ảnh nguồn có l/min550 và m³/h0..30 cần đọc từng vạch thật và quy đổi đơn vị đúng trước dựng đầu cuối, không ngoại suy fit.',
    all_curves_method='Nếu ROOT chốt lỗi và cho mẫu: dựng toàn miền 10 QH cùng màu/nét/độ sắc, đủ120 neo LOCAL; η theo nguồn riêng, giữ UNKNOWN số. Không vá đuôi.',
    eta_scope='Không bảng số η; chưa đọc tâm mực η của6SL25. Không dùng551 tâm η trang8.',
    glyph_scope='Tên nguồn riêng6SL25 cùngfile; cần chứng minh kiểu/cỡ/đậm sạch, không chuyển chữ giữacatalogue hoặc dùngfontbảng đậm.',
    graphics_style_scope='Cần đo riêng màu/width/dash/chuyển nét/vạch/khung6SL25. Không tự coi bộ.95pt/6.95-3.41pt của p8 là source6SL25.',
    source_region_geometry=dict(frame_x=frame['H_frame_x_page'],H_bounds=[bands['H_frame_bottom_page'],bands['H_frame_top_page']],eta_bounds=[bands['efficiency_bottom_page'],bands['efficiency_top_page']]),
    catalogue_written=False,PDF_sample_created=False,shared_progress_written=False,
    status='PHƯƠNG ÁN CHƯA ĐỦ ĐIỀU KIỆN VẼ: cần ROOT đọc lỗi/khóaQ33/chữ/nét/η riêng.')
planpath=Path(fresh(out/'PHUONG AN6SL25 TOAN BIEU DO CHUA VE VA TRANG THAI DUNG.json'))
planpath.write_text(json.dumps(dict(time=datetime.now().isoformat(),measured_statuses=states,other_five_groups_readonly=groups,plan=plan,
    invalid_trial_history=['LAN1 ngưỡng235 tạo run nối lưới/halo; không kết luận từ run đó.',
        'LAN2 ngưỡng160 thiếu mực một cột/16. LAN3 giữ ngưỡng không đủ thành UNKNOWN, không ép run.'],
    source_current_SHA_unchanged=True),ensure_ascii=False,indent=2),encoding='utf8')
lines=['# G04 – Hai điểm Q27 của Redpump6SL25, đọc PDF thật', '',
    'Phép đọc hiện tại: **6SL25/20 CHƯA ĐẠT tại Q27**. **6SL25/16 CHƯA THỂ XÁC MINH** khi giữ bất định bảo thủ ảnh nguồn. Cần ROOT đọc độc lập trước khi thay đường.', '',
    '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
    '|---|---|---|---|---|---|---|---|']
for z in states:
    lines.append(f'| Q27 {z["model"]} | Redpump SL | 10 | Bảng {z["H_table"]}m; mực {z["H_actual"]:.6f}m | Không đổi PDF | Đọc nguồn và bản giao riêng600dpi; localQ25–30 và localH120–160; không chọn nét bằng H bảng | {z["status"]}; lệch {z["error_m"]:.6f}m ±{z["source_conservative_uncertainty_m"]:.6f}m, giới hạn {z["allowed_error_m"]}m | [Số đo/ảnh/tọa độ]({planpath.as_posix()}) |')
lines+=['',
    'Mực nguồn và bản giao tại hai điểm trùng nhau. Ngưỡng mực được kiểm độ nhạy; giữ riêng pixel nguồn, nửa bề rộng mực, độ dốc đổi bất định Q sang H và sai số lấy mẫu. 600dpi chỉ phóng hiển thị, không tạo thêm độ chính xác cho JPEG nguồn150dpi.', '',
    'Hai dòng trên không thay cho nghiệm thu10đường/120ô hoặc16biểuđồ ngoài trang8. Năm nhóm có51đường/540mốc ứng viên được bám nguồn mới; các nhánh giao, đầu thiếu mực và vạch ngoài miền còn CHƯA THỂ, chưa cộng ĐẠT.', '',
    'Kế hoạch6SL25: dựng toàn biểu đồ10QH cùng nét nếu ROOTchốt, dùng120ô CHÍNH SL, giữ các đoạn tăng nhẹ nguồn. Q33, nét/chữ/vạch/η riêng chưa khóa đủ nên chưa tạo mẫu. Không lấy trục/số/chữ từ Perotac hoặc hìnhη trang8.', '',
    'Không tạoPDF, không sửa bản giao/nguồn/MẪU1, không ghiTIEN DO. Các lượt đo lỗi vẫn được giữ riêng; bản thô LAN3 có câu status cấp record tổng quát, trạng thái đúng của/16làCHƯA THỂ theo actual_reads và hồ sơ bổ sung này.', '',
    f'SHA nguồn `{before[0]}`; SHA bản giao `{before[1]}`.']
report=Path(fresh(out/'BAO CAO8 COT Q27 VA KE HOACH6SL25 CHUA VE.md'))
report.write_text('\n'.join(lines)+'\n',encoding='utf8')
assert before==[sha(raw['source']),sha(raw['current'])]
print(json.dumps(dict(report=str(report),report_SHA256=sha(report),plan=str(planpath),read_only_candidates=sum(z['records'] for z in groups),candidate_table_anchors=sum(z['table_anchor_rows_attempted'] for z in groups)),ensure_ascii=False),flush=True)
