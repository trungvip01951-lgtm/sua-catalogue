"""Doc actual16moc, mau/net va font foreground cua G04 netPDF mau2."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,csv,numpy as np
import pymupdf as fitz
from catfix import charts,verify
from catfix.vector import Editor
root=Path(S.report('G04/NET PDF THAT MAU2'))
build=json.loads((root/'TAO VA KIEM MAU.json').read_text(encoding='utf8'))
current=S.result('Perotac bơm giếng SA_compressed (bản mới).pdf');trial=build['trial']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(current)==build['current_sha'] and sha(trial)==build['trial_sha']
ax,bx,ay,by=build['axis'];E=Editor(trial,backend='fitz');P=E.page(7)
points=[];styles=[];endpoint=[]
for r in build['records']:
    # This builder explicitly uses Num(), which preserves ten decimal places.
    want=[z/255 for z in r['RGB']];parts=[]
    for oi,o in enumerate(P.objs):
        col=P.color_of(oi,'stroke')
        if o['op']!='S' or col is None or max(abs(np.array(col)-want))>1e-7:continue
        path=P.object_pagepath(oi);a=charts.sample_path(path,n=400)
        assert np.all(np.diff(a[:,0])>=0) and np.all(np.diff(a[:,1])<=1e-5)
        assert abs(o['lw']-r['width_pt'])<1e-8
        assert o['dash'] is None or o['dash'][0]==[]
        parts.append((oi,o,a))
    assert len(parts)==len(r['native_dash_Q_intervals']),(r['model'],len(parts),len(r['native_dash_Q_intervals']))
    a=np.vstack([x[2] for x in parts]);a=a[np.argsort(a[:,0])];qs=(a[:,0]-bx)/ax;hs=(a[:,1]-by)/ay
    assert abs(qs.min())<1e-4 and abs(qs.max()-21)<1e-4
    for q,target in zip(r['Q'],r['H']):
        # Read actual path positions; for a source dash gap only interpolate
        # between its two real ends, inside the known curve domain.
        assert qs.min()-1e-4<=q<=qs.max()+1e-4
        h=float(np.interp(q,qs,hs));delta=h-target;limit=max(1,.02*target);assert abs(delta)<=limit
        points.append(dict(model=r['model'],Q=q,H_table=target,H_actual=h,error=delta,limit=limit,result='ĐẠT',dash_gap_bracket_only=True))
    for label,q,h,xy in [('start',r['Q'][0],r['H'][0],a[0]),('end',r['Q'][-1],r['H'][-1],a[-1])]:
        expected=np.array([ax*q+bx,ay*h+by]);d=float(np.max(abs(xy-expected)));assert d<1e-4
        endpoint.append(dict(model=r['model'],which=label,actual=xy.tolist(),error_pt=d))
    styles.append(dict(model=r['model'],real_path_objects=[x[0] for x in parts],actualRGB=parts[0][1]['stroke'],expectedRGB=want,actualwidth=parts[0][1]['lw'],source_equivalentwidth=r['width_pt'],dash_intervals=r['native_dash_Q_intervals'],source_is_raster=True))
E.close()
outside=verify.outside_pixels(current,trial,{8:[[59.5,324,359,513]]},dpi=200,thr=0,min_size=0,pad=.4);assert not outside
# Check glyph foreground in the label band independently from the editor's mask.
old=np.asarray(verify.crop(current,7,(125,327,162,505),450)).astype(int)
new=np.asarray(verify.crop(trial,7,(125,327,162,505),450)).astype(int)
font=(old.mean(axis=2)<130)&((old.max(axis=2)-old.min(axis=2))<12)
font_delta=np.max(abs(old-new),axis=2)[font]
fontcheck=dict(black_source_font_pixels=int(font.sum()),changed_pixels=int((font_delta>0).sum()),max_change=int(font_delta.max()) if len(font_delta) else 0)
print('FONT FOREGROUND',fontcheck,flush=True)
metadata={}
with fitz.open(current) as a,fitz.open(trial) as b:
    links=lambda d:[[{k:str(v) for k,v in z.items() if k!='xref'} for z in p.get_links()] for p in d]
    metadata=dict(info=a.metadata==b.metadata,rawXMP=a.get_xml_metadata()==b.get_xml_metadata(),bookmarks=a.get_toc()==b.get_toc(),links=links(a)==links(b),page_sizes=[tuple(p.rect) for p in a]==[tuple(p.rect) for p in b])
assert all(metadata.values()),metadata
actual=dict(current=current,current_sha=sha(current),trial=trial,trial_sha=sha(trial),point_count=len(points),points=points,endpoints=endpoint,styles=styles,outside=outside,metadata=metadata,font_foreground=fontcheck,visual='ROOT soi mau2: net sach, khong pale nhu mau1; can soi fontforeground neu co delta.',accepted=False,scope='2duong/16moc bang; cacduong khac G04 chua duocnghiemthu toanbo.')
Path(fresh(root/'DOC LAI ACTUAL PDF.json')).write_text(json.dumps(actual,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(root/'16 MOC ACTUAL PDF.csv'),'w',encoding='utf-8-sig',newline='') as fp:
    w=csv.DictWriter(fp,list(points[0]));w.writeheader();w.writerows(points)
print('G04 REAL PATH',len(points),'PASS maxH',max(abs(p['error']) for p in points),'END max',max(v['error_pt'] for v in endpoint),flush=True)
