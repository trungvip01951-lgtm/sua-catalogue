"""Restore source2 base and5 top/stem straight features; RAM research only."""
from catwork import start,fresh
S,D,N=start()
from catfix.raster import cv2
from scipy.spatial import cKDTree
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'CHU2 CHU5 GIU NET THANG NGUON V3'
read=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
data=read(base/'TOAN BO CHU NGUON IT DOAN CONG V2/TOAN BO12 CHU NGUON IT DOAN CONG V2 RAM CHUA NGHIEM THU.json');raw=read(base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json');by={r['key']:r for r in raw['candidates']};zoom=96
def L(a,b):a=np.asarray(a,float);b=np.asarray(b,float);return [a.tolist(),(a+(b-a)/3).tolist(),(a+2*(b-a)/3).tolist(),b.tolist()]
def C(a,b,c,d):return [list(a),list(b),list(c),list(d)]
models={
 '2':[C((.508,1.133),(1.,.80),(3.42,.72),(4.133,1.492)),C((4.133,1.492),(4.98,2.34),(4.55,3.476),(4.101,3.961)),C((4.101,3.961),(3.6,4.70),(2.72,5.55),(2.086,6.039)),
 C((2.086,6.039),(1.90,6.20),(1.60,6.65),(2.461,6.977)),L((2.461,6.977),(3.539,6.977)),C((3.539,6.977),(4.,7.),(4.257,7.21),(4.257,7.523)),C((4.257,7.523),(4.,7.92),(3.8,8.01),(3.711,7.992)),
 L((3.711,7.992),(.492,8.117)),C((.492,8.117),(.15,8.11),(-.023,7.85),(-.023,7.555)),C((-.023,7.555),(.15,6.73),(.85,5.85),(1.508,5.258)),L((1.508,5.258),(2.977,3.977)),
 C((2.977,3.977),(3.40,3.18),(3.47,2.00),(2.414,1.852)),C((2.414,1.852),(1.74,1.78),(1.,2.),(.477,2.961)),L((.477,2.961),(.133,2.602)),C((.133,2.602),(.04,1.9),(.16,1.5),(.508,1.133))],
 '5':[L((3.555,.758),(1.508,.898)),C((1.508,.898),(1.05,.91),(.96,1.35),(1.023,1.477)),L((1.023,1.477),(.914,3.586)),L((.914,3.586),(1.257,4.602)),
 C((1.257,4.602),(1.36,4.92),(1.65,4.96),(2.492,4.086)),C((2.492,4.086),(3.56,3.71),(4.19,4.45),(4.305,5.492)),C((4.305,5.492),(4.3,6.7),(3.4,7.54),(2.102,6.789)),L((2.102,6.789),(1.508,6.148)),L((1.508,6.148),(.867,6.492)),
 C((.867,6.492),(.94,7.79),(1.89,8.30),(3.477,7.867)),C((3.477,7.867),(4.32,8.1),(5.13,7.83),(5.195,6.539)),L((5.195,6.539),(5.024,5.492)),C((5.024,5.492),(5.65,4.55),(5.,3.36),(3.492,2.977)),L((3.492,2.977),(2.508,3.023)),
 C((2.508,3.023),(2.20,3.1),(1.95,2.72),(1.992,2.508)),L((1.992,2.508),(2.492,1.992)),L((2.492,1.992),(3.539,2.055)),C((3.539,2.055),(4.08,2.09),(4.40,1.79),(4.773,1.508)),C((4.773,1.508),(4.55,.8),(4.11,.66),(3.555,.758))]
}
def sample(ss):
    out=[]
    for seg in ss:
        c=np.asarray(seg);t=np.linspace(0,1,200,endpoint=False)[:,None];out.extend(((1-t)**3*c[0]+3*(1-t)**2*t*c[1]+3*(1-t)*t**2*c[2]+t**3*c[3]).tolist())
    return np.asarray(out)
font=[];tiles=[]
for old in data['glyphs']:
    char=old['character']
    if char not in models:font.append(old);continue
    src=by[old['source_key']];al=np.asarray(src['alpha']);h,w=al.shape;up=cv2.resize(np.pad(al,1),((w+2)*zoom,(h+2)*zoom),interpolation=cv2.INTER_LINEAR);m=up>=src['iso_mass_match_threshold'];co,hi=cv2.findContours(m.astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE);actual=(co[0][:,0,:].astype(float)+.5)/zoom-1;ss=models[char];pts=sample(ss);bb=np.r_[actual.min(0),actual.max(0)];nb=np.r_[pts.min(0),pts.max(0)];f=(bb[2:]-bb[:2])/(nb[2:]-nb[:2]);off=bb[:2]-nb[:2]*f;ss=(np.asarray(ss)*f+off).tolist();pts=sample(ss)
    hd=max(float(cKDTree(actual).query(pts)[0].max()),float(cKDTree(pts).query(actual)[0].max()));area=abs(float(np.sum(pts[:,0]*np.roll(pts[:,1],-1)-pts[:,1]*np.roll(pts[:,0],-1))/2));mi=Image.new('L',((w+2)*zoom,(h+2)*zoom),0);dr=ImageDraw.Draw(mi);dr.polygon([((x+1)*zoom,(y+1)*zoom) for x,y in pts],fill=255);cc,hh=cv2.findContours((np.asarray(mi)>0).astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    p=dict(local_native_xy=pts.tolist(),cubic_segments_local_native=ss,parent=-1,curve_segments=len(ss),source_true_straight_bar_or_base_and_stem_kept=True,source_boundary_max_symmetric_distance_native_px=hd,source_bbox_restored=True,area_native_px=area)
    g=dict(**old);g['cleaned_contour_paths']=[p];g.update(periodic_2_or5_candidate_from38_rejected_visually=True,source_straight_features_restored=True,
       straight_research_area_native_px=area,straight_research_area_vs_source_alpha_percent=(area/src['alpha_integral_native_px']-1)*100,straight_research_max_source_edge_distance_native_px=hd,
       straight_research_source_bbox_original=bb.tolist(),straight_research_outer_components=int(sum(hh[0,j,3]<0 for j in range(len(cc)))),straight_research_holes=int(sum(hh[0,j,3]>=0 for j in range(len(cc)))),source_advance_and_baseline_unchanged=True,ROOT_and_graphic_acceptance_pending=True)
    font.append(g);print(char,'STRAIGHT SEG',len(ss),'AREA%',g['straight_research_area_vs_source_alpha_percent'],'HMAX',hd,'TOPO',g['straight_research_outer_components'],g['straight_research_holes'],flush=True)
    v=Image.new('RGB',((w+2)*24,(h+2)*24),'white');vd=ImageDraw.Draw(v);vd.polygon([((x+1)*24,(y+1)*24) for x,y in pts],fill=(57,55,57));rawim=Image.open(base/'DO BIEN GIU LUONG MUC NGUON'/(old['source_key']+' NGUON150dpi.png'));tile=Image.new('RGB',(800,300),'white');tile.paste(rawim.resize((w*24,h*24),Image.Resampling.NEAREST),(10,10));tile.paste(v,(400,0));tile.save(fresh(root/(char+' NGUON VA NET THANG V3.png')));tiles.append(tile)
bank={r['character']:r for r in font};sheet=Image.new('RGB',(1750,2600),'white');d=ImageDraw.Draw(sheet)
for i,word in enumerate(data['words']):
    x=15.;y=i*200+140.;scale=14
    for c in word['literal']:
        g=bank[c]
        for p in g['cleaned_contour_paths']:d.polygon([(x+xx*scale,y+(yy-9)*scale) for xx,yy in p['local_native_xy']],fill=(57,55,57) if p['parent']<0 else 'white')
        x+=g['native_advance']*scale
sheet.save(fresh(root/'13 TEN CHU NGUON NET THANG V3 RAM CHUA NGHIEM THU.png'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(S.src(name))==data['source_sha256'] and sha(S.result(name))==data['current_sha256']
Path(fresh(root/'TOAN BO12 CHU NGUON NET THANG V3 RAM CHUA NGHIEM THU.json')).write_text(json.dumps(dict(read_only=True,source_sha256=sha(S.src(name)),current_sha256=sha(S.result(name)),source_small_caption_only=True,source_one_color_RGB=[57,55,57],glyphs=font,words=data['words'],periodic_2_and5_previous_candidates_rejected=True,no_PDF_font_or_progress_written=True,ROOT_and_graphic_acceptance_pending=True),ensure_ascii=False,indent=2),encoding='utf8')
