"""Pure geometric helpers: no I/O, imports PDF, raster creation, or side effects."""
import numpy as np
def parse(q):
    cs=q['commands_pixel'];pts=[];ops=[]
    for c in cs:
        op=c if isinstance(c,str) else c[0]
        assert op in ('M','L','Z'),op
        ops.append(op)
        if op!='Z':
            assert len(c)==3
            pts.append([float(c[1]),float(c[2])])
    assert ops[0]=='M' and ops[-1]=='Z' and ops.count('M')==1 and ops.count('Z')==1
    p=np.array(pts,dtype=float)
    if np.array_equal(p[0],p[-1]):p=p[:-1]
    assert len(p)>=3 and np.isfinite(p).all()
    return p
def area(p):return float(.5*np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1]))
def cross(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]
def winding(p,pts):
    z=np.array(pts,dtype=float).reshape(-1,2)
    a=p;b=np.roll(p,-1,axis=0);r=b-a;out=[]
    for i in range(0,len(z),256):
        t=z[i:i+256];v=t[:,None,:]-a[None,:,:];c=cross(r[None,:,:],v)
        up=(a[None,:,1]<=t[:,None,1])&(b[None,:,1]>t[:,None,1])&(c>0)
        dn=(a[None,:,1]>t[:,None,1])&(b[None,:,1]<=t[:,None,1])&(c<0)
        out.extend((up.sum(axis=1)-dn.sum(axis=1)).tolist())
    return np.array(out,dtype=int)
def windall(polys,pts):
    t=np.zeros(len(pts),dtype=int)
    for p in polys:t+=winding(p,pts)
    return t
def dist(p,pt):
    a=p;b=np.roll(p,-1,axis=0);r=b-a
    t=np.sum((np.array(pt)-a)*r,axis=1)/np.maximum(np.sum(r*r,axis=1),1e-30)
    return float(np.linalg.norm(a+np.clip(t,0,1)[:,None]*r-np.array(pt),axis=1).min())
def bbox(p):return [float(p[:,0].min()),float(p[:,1].min()),float(p[:,0].max()),float(p[:,1].max())]
def intersections(p,q,same=False):
    qa=q;qb=np.roll(q,-1,axis=0);s=qb-qa;mn=np.minimum(qa,qb);mx=np.maximum(qa,qb);hits=[]
    for i,a in enumerate(p):
        b=p[(i+1)%len(p)];r=b-a;lo=np.minimum(a,b);hi=np.maximum(a,b)
        ix=np.flatnonzero((mn[:,0]<=hi[0]+1e-10)&(mx[:,0]>=lo[0]-1e-10)&(mn[:,1]<=hi[1]+1e-10)&(mx[:,1]>=lo[1]-1e-10))
        for j in ix.tolist():
            if same and (j<=i or j==i+1 or (i==0 and j==len(p)-1)):continue
            den=float(cross(r,s[j]));v=qa[j]-a
            if abs(den)>1e-10:
                t=float(cross(v,s[j])/den);u=float(cross(v,r)/den)
                if -1e-10<=t<=1+1e-10 and -1e-10<=u<=1+1e-10:
                    typ='strict_cross' if 1e-10<t<1-1e-10 and 1e-10<u<1-1e-10 else 'endpoint_contact'
                    hits.append({'edge1':i,'edge2':j,'kind':typ,'xy':(a+t*r).tolist()})
            elif abs(float(cross(v,r)))<1e-10:
                rr=float(np.dot(r,r))
                if rr<1e-20:continue
                t0=float(np.dot(qa[j]-a,r)/rr);t1=float(np.dot(qb[j]-a,r)/rr)
                left=max(0,min(t0,t1));right=min(1,max(t0,t1))
                if left<=right+1e-10:hits.append({'edge1':i,'edge2':j,'kind':'collinear_overlap' if right-left>1e-10 else 'endpoint_contact','xy':(a+left*r).tolist()})
    return hits
def intervals(polys,y):
    xs=[];vs=[]
    for p in polys:
        a=p;b=np.roll(p,-1,axis=0)
        keep=((a[:,1]<=y)&(b[:,1]>y))|((a[:,1]>y)&(b[:,1]<=y))
        a=a[keep];b=b[keep]
        if len(a):
            xx=a[:,0]+(y-a[:,1])*(b[:,0]-a[:,0])/(b[:,1]-a[:,1])
            xs.extend(xx.tolist());vs.extend(np.where(b[:,1]>a[:,1],1,-1).tolist())
    if not xs:return []
    ix=np.argsort(xs);xs=np.array(xs)[ix];vs=np.array(vs)[ix]
    acc=0;left=None;out=[]
    for x,v in zip(xs,vs):
        old=acc;acc+=v
        if old==0 and acc!=0:left=float(x)
        if old!=0 and acc==0:out.append([left,float(x)])
    assert acc==0
    return out
