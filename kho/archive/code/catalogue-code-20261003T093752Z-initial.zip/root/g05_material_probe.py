from catwork import start,fresh
from pathlib import Path
import json
S,D,N=start()
j=S.job('Perotac bơm giếng SP_compressed (bản mới).pdf')
info=[]
for p in [0,3,8,10]:
    cv=j.canvas(p)
    lr=(30,40,190,130 if p==0 else 150)
    b=j.R.glyph_bank(cv,box=cv.box(lr))
    print('Trang',p+1,'chu',list(b['glyphs']),flush=True)
    for c in ['A','I','S','3','1','6']:
        if c in b['glyphs']:
            g=j.R.best_glyph(b,c)
            print(c,tuple(v for v in g['box']),g['alpha'].shape,flush=True)
    print('316',[(h['text'],tuple(float(v) for v in cv.rect(h['box']))) for h in j.R.find(cv,'316',box=cv.box(lr))],flush=True)
    ws=j.R.ocr(cv,box=cv.box(lr),scale=3,psm=11)
    print([(w['text'],tuple(round(float(v),1) for v in cv.rect(w['box']))) for w in ws],flush=True)
    info.append(dict(page=p+1,words=ws,chars=list(b['glyphs'])))
j.close()
Path(fresh(S.report('G05/DINH VI/MAU CHU VAT LIEU.json'))).write_text(json.dumps(info,ensure_ascii=False,indent=2,default=lambda x:float(x)),encoding='utf-8')
