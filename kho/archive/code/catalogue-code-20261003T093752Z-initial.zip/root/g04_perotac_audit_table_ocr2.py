from catwork import start,fresh
S,D,N=start()
from pathlib import Path
code=Path(__file__).with_name('g04_perotac_audit_table_ocr.py').read_text(encoding='utf8').split('S,D,N=start()\n',1)[1]
code=code.replace('black=g<175','black=g<205')
code=code.replace("len(yb)!=ny+1 or len(xb)!=nx+1", "len(xb)!=nx+1")
code=code.replace('dy=np.diff(yb);dx=np.diff(xb)','''
 dy=np.diff(yb);dx=np.diff(xb); row_geometry_estimated=False
 if len(yb)!=ny+1 or max(abs(dy-np.median(dy)))>2:
  period=float(np.median(np.diff(yy)[np.diff(yy)>8]));last=float(yy[-1]+v0-5)
  yb=(last-np.arange(ny,-1,-1)*period).tolist();dy=np.diff(yb);row_geometry_estimated=True
''')
code=code.replace('max(abs(dx-np.median(dx)))>2','min(dx)<15 or max(dx)>65')
code=code.replace("words=R.ocr(mem,scale=1,psm=6,config='-c tessedit_char_whitelist=0123456789')", "words=R.ocr(mem,scale=1,psm=11)")
code=code.replace('OCR O SO ','OCR O SO LAN2 ')
code=code.replace('DOI CHIEU DOC BANG LAN1.json','DOI CHIEU DOC BANG LAN2.json')
code=code.replace('grid_unknown=False,row_borders_native=yb','grid_unknown=False,row_geometry_estimated=row_geometry_estimated,row_borders_native=yb')
exec(compile(code,__file__,'exec'))
