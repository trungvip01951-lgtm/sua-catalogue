"""Đo hai giao điểm đã nhận diện bằng mắt; không suy từ mặt nạ màu."""
from catwork import start,fresh
from pathlib import Path
import json,numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from PIL import Image,ImageDraw
name='Perotac bơm giếng SA_compressed (bản mới).pdf';E=Editor(S.src(name));R=Raster(E);cv=R.canvas(R.images(7)[0]);g=cv.gray()
top,bottom=180.5,571.5
ticks=[(100,134.875),(150,172.07),(200,209.15),(250,246.47),(300,283.79)]
c=np.polyfit([q for q,x in ticks],[x for q,x in ticks],1);res=max(abs(np.polyval(c,q)-x) for q,x in ticks)
xpt=float(np.polyval(c,350));u=float(cv.to_px(xpt,400)[0]);records=[]
for model,expected,rows in [('4SA16/23',50,[433,434,435,436]),('4SA16/18',39,[463,464,465])]:
    assert all(np.median(g[y,135:735])>245 for y in rows),('Lẫn kẻ lưới',model)
    weight=255-g[rows,int(round(u))-1:int(round(u))+2].min(1)
    v=float(np.average(rows,weights=weight));h=(bottom-v)/(bottom-top)*150
    records.append(dict(model=model,Q_m3h=21,H_table_m=expected,H_curve_m=h,difference_m=h-expected,tolerance_m=max(1,.02*expected),uncertainty_m=150/(bottom-top),v_px=v,rows_px=rows,result='CHƯA ĐẠT',identification='Đọc nhãn, đi theo nét đường đến Q=21; hàng có màu xám nền >245 nên không phải kẻ ngang'))
box=cv.box((59.5,324,359,513));im=Image.fromarray(cv.work[box[1]:box[3],box[0]:box[2]]).resize(((box[2]-box[0])*2,(box[3]-box[1])*2))
dr=ImageDraw.Draw(im);xx=(u-box[0])*2;dr.line([(xx,0),(xx,im.height)],fill=(255,100,0),width=2)
for r in records:
    yy=(r['v_px']-box[1])*2;dr.ellipse((xx-6,yy-6,xx+6,yy+6),outline=(255,0,0),width=2)
im.save(fresh(S.report('G04/DO DIEM 4SA16 Q21.png')))
out=dict(file=name,page=8,chart='4SA16',scope='Chỉ 2 điểm Q=21 trên 4SA16/23 và 4SA16/18; chưa kiểm đủ các điểm/đường còn lại, Redpump chưa đo.',ticks_lmin=ticks,x_fit=[float(v) for v in c],max_axis_residual_pt=float(res),top_v=top,bottom_v=bottom,records=records)
Path(fresh(S.report('G04/DO DIEM 4SA16 Q21.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(out);E.close()
