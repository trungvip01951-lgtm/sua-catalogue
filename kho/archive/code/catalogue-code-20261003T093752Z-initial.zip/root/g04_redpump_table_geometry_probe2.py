"""Actual neutral rules on source table body; threshold candidates not acceptance."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'));d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(d['source']),sha(d['current'])];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(d['source'],backend='fitz');R=Raster(E);records=[]
def runs(a):
 out=[]
 for i in np.flatnonzero(a):
  if not out or i-out[-1][-1]>1:out.append([])
  out[-1].append(int(i))
 return out
for t in catalog['tables']:
 rows=[r for r in d['rows'] if r['page']==t['page'] and r['family']==t['table_model']];cv=R.render_canvas(t['page']-1,t['rect'],dpi=300);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);spread=a.max(2)-a.min(2);H,W=g.shape;xc=int(W*.54);variants=[]
 for thr in [195,210,225]:
  mask=(g[:,xc:W-5]<thr)&(spread[:,xc:W-5]<32);coverage=mask.mean(1);peaks=runs(coverage>.65);centres=[float(np.average(z,weights=coverage[z])) for z in peaks]
  # The last n+1 rules must be an equal-spacing body sequence. If absent, leave unknown.
  tail=np.array(centres[-len(rows)-1:]);diff=np.diff(tail);step=float(np.median(diff)) if len(diff) else None
  residual=float(np.max(abs(diff-step))) if len(diff) else None;qualified=len(tail)==len(rows)+1 and residual<=2.5
  variants.append(dict(threshold=thr,coverage_min=.65,neutral_spread_max=32,all_horizontal_centres=centres,body_candidates=tail.tolist(),body_step=step,body_step_residual=residual,qualified=qualified))
 records.append(dict(page=t['page'],family=t['table_model'],rect=list(cv.rect0),dpi=300,models=[r['model'] for r in rows],Q=rows[0]['Q'],variants=variants,status='Source rules only; body candidate needs image inspection, not curve acceptance'))
 print(t['page'],t['table_model'],[(v['threshold'],len(v['all_horizontal_centres']),v['body_step_residual'],v['qualified']) for v in variants],flush=True)
E.close();assert before==[sha(d['source']),sha(d['current'])];Path(fresh(root/'HOA TIET BANG NGUON CANDIDATE2.json')).write_text(json.dumps(dict(records=records,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
