"""Candidate contours from clearer small own-file donors; no PDF or canonical."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import copy,json,hashlib,sys,numpy as np,cv2
from scipy.ndimage import gaussian_filter,distance_transform_edt
from PIL import Image,ImageDraw
sys.path.insert(0,str(HERE))
from g04_source_observed_mask_contour_math import source_mask_contours
from g04_source_glyph_core_math import topology
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
F=M/'CHU2 5 DONOR RO HON CUNG FILE RAM V10';assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
previous=M/'CHU5 9 BIEN QUAN SAT RAM V7/12 GLYPH RAM V7 BIEN5 9 MOT MAU.json';prev=J(previous)
sourcefile=M/'DONOR2 5 NGUYEN CUNG TU P8 P4 LAN4/NGUON2 5 VA4 KY TU CHUNG P4 P8 NGUYEN CUM KHONG DOI BANK.json';donors=J(sourcefile)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
pad=8;up=8;replacements=[]
for ch,word,level in [('5','4SL2/52',.35),('2','4SL16/20',.40)]:
    old=next(z for z in prev['records'] if z['character']==ch)
    src=next(z for z in donors['records'] if z['character']==ch and z['source_word']==word)
    alpha=np.asarray(src['source_alpha']);A=np.pad(alpha,pad);field=gaussian_filter(A,1.)
    mask=field>=level;assert topology(mask)==(1,0)
    loops,area,actual=source_mask_contours(mask,pad=pad,up=up,curvy=True,epsilon=1.5,radius=.9,expected=(1,0))
    weak=cv2.resize((A>=.085).astype('uint8'),(actual.shape[1],actual.shape[0]),interpolation=cv2.INTER_NEAREST).astype(bool)
    missing=float(distance_transform_edt(actual==0)[weak].max()/up*.12)
    extra=float(distance_transform_edt(~weak)[actual>0].max()/up*.12)
    yy,xx=np.where(actual);bbox=[float(xx.min()/up-pad),float(yy.min()/up-pad),float((xx.max()+1)/up-pad),float((yy.max()+1)/up-pad)]
    z=copy.deepcopy(old)
    # Same physical scale and existing advances/assembled positions; source
    # full box retained independently, never resized to a desired ink amount.
    z.update(source_page=src['source_page'],source_word=src['source_word'],source_page_box=src['source_page_box'],
        source_alpha=src['source_alpha'],actual_source_RGB_cell=src['actual_source_RGB_cell'],
        original_source_donor_record=src,source_pixel_pt=.12,source_area_px=float(alpha.sum()),
        vector_optical_area_px=area*(1-63/255),physical_scale=1,core_gray=63,opacity=1,
        source_full_box_pt=src['source_full_box_pt'],source_previous_full_box=old['source_page_box'],
        source_common_core_rule='Mộtmàu63chung, không tự gán sourcegray thànhnhiều màu chữ; chữmẫu khác trongCHÍNH file, phông/cỡ cầnROOT/đồhọađọc.',
        parts=[dict(source_part=1,loops=loops,kind='clearer_own_source_observed_edge_contour',
            source_smoothing_sigma_px600=1.,source_smoothing_sigma_pt=.12,coverage_threshold=level,
            close_px600=0,source_mass_px=float(alpha.sum()),loop_area_px=area,
            relative_math_ink_error=float(area*(1-63/255)/alpha.sum()-1),actual_vector_bbox600=bbox,
            topology=[1,0],source_weak_alpha_point085_missing_distance_pt=missing,
            source_weak_alpha_point085_extra_distance_pt=extra,max_contour_fit_error_px600=max(q['max_contour_fit_error_px600'] for q in loops),
            no_mass_tightening=True,no_geometry_scale=True,no_morphological_closing=True,
            no_RGB_channel_mask=True,no_source_image_edit=True,
            status='ỨNG VIÊN RAM; dáng/cỡ/đậm donor và13 tên cầnđọc, chưa phôngPASS.')])
    replacements.append(z)
    H,W=alpha.shape
    candidate=Image.fromarray((255-192*actual.astype(float)).clip(0,255).astype('uint8')).crop((pad*up,pad*up,(pad+W)*up,(pad+H)*up)).convert('RGB')
    original=Image.fromarray(src['actual_source_RGB_cell'] and np.asarray(src['actual_source_RGB_cell'],dtype='uint8')).convert('RGB')
    sheet=Image.new('RGB',(1450,650),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(17)
    dr.text((5,5),ch+' – donor '+word+' p'+str(src['source_page'])+' / RAM V10, nguyên cỡ vàmàu63, chưaPDF2',fill='blue',font=ft)
    sheet.paste(original.resize((W*10,H*10),Image.Resampling.NEAREST),(30,65));sheet.paste(candidate.resize((W*10,H*10),Image.Resampling.LANCZOS),(450,65))
    dr.text((850,90),'Mộtkhối, khôngclose\nKhôngscale/ép mực\nΔmực '+str(round(z['vector_optical_area_px']/z['source_area_px']-1,4))+'\nCùng4/S/L/slash:\nCHƯA CHỐT font',fill='blue',font=ft)
    sheet.save(fresh(F/(ch+' NGUON MOI NGUYEN CO VA BIEN RAM V10.png')))
out=copy.deepcopy(prev);rep={z['character']:z for z in replacements};out['records']=[rep.get(z['character'],z) for z in prev['records']]
assert next(z for z in out['records'] if z['character']=='9')==next(z for z in prev['records'] if z['character']=='9')
out.update(RAM_variant='V10_clearer_own_file_donors5p4_52_2p8_20_no_closing_other10_and9V7held',
    previous_bank=str(previous),previous_bank_SHA256=sha(previous),source_candidate_packet=str(sourcefile),source_candidate_packet_SHA256=sha(sourcefile),
    common_gray=63,core_gray=63,opacity=1,physical_scale=1,no_mass_tightening=True,
    source_font_qualification='ỨNG VIÊN: cùngnhãnbơmnhỏCHÍNH Redpump;4/S/L/slash nguyêncụm đãđọc, chưa coi donor/fontPASS từbboxJPEG.',
    source_boundary_scope='Biên đượcchọn trongJPEG riêng, khôngphôngCADgốc. Ngưỡng/diện tích/topology chưa đủ nhận hình.',
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False,
    status='ỨNG VIÊN RAM; cần ROOT/đồhọa đọc phông/cỡ/đậm/dáng2/5 và13 tên, chưaPDF2.')
fp=Path(fresh(F/'12 GLYPH RAM V10 DONOR2 5 CUNG FILE GIU9V7.json'))
fp.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print('RAM',[(z['character'],z['parts'][0]['actual_vector_bbox600'],round(z['parts'][0]['relative_math_ink_error'],4)) for z in replacements],str(fp),sha(fp),flush=True)
