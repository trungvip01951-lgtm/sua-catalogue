"""Supplemental visual source donor note only, no glyph bank or image changes."""
from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,hashlib
O=Path(S.report('G04/g01 KIEM DOC LAP CHU NHO REDPUMP RAM V5'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
C=M/'CHU5 SACH NGUON P8 VA2 KY TU CUNG KIEU LAN1/5 CUNG KIEU2 KY TU NGUON VA CO.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads(C.read_text(encoding='utf8'))
assert sha(d['source'])==d['source_SHA256']=='a01b7f84c0ebb4960a6b9601d98a04420c4c00f8bf1d48a23e1bde4e8b084038'
seen=[M/'CHU5 SACH NGUON P8 VA2 KY TU CUNG KIEU LAN1/5 NGUON SACH VA2 KY TU4 S CUNG KIEU.png',P/'CHU9 UNG VIEN MO NGUYEN CUM VA TOA DO.png',P/'GLYPH9 NGUON TRANG4 NHAN4SL2_9 TOA DO.png',P/'CHU9 SACH NGUON 3SL4_9 V3.png']
lines=['# Đọc bổ sung chữ mẫu 5/9 trong chính Redpump', '',
 'Ưu tiên khảo sát tiếp số 5 trong nhãn 4SL16/25 trang 8. Nét ngang trên, nét trái và phần cong dưới đọc đầy đủ hơn chữ mẫu 4SL3/35 trang 5. Hai chữ 4/S trong cùng nhãn có cùng họ dáng sans (chữ không chân) nhìn thấy; mức xám mờ và pha điểm ảnh khiến chưa thể suy cỡ phông danh nghĩa chính xác.', '',
 '| Chữ nguồn p8 | Vùng PDF gốc dưới trái | Hộp mực ứng viên (điểm PDF) | Chênh so bộ đang dùng | Giới hạn |',
 '|---|---|---|---|---|']
for r in d['records']:lines.append(f"| {r['character']} | {r['source_page_box']} | {r['candidate_ink_size_pt']} | {r['ink_size_difference_pt']} | Hộp mực ở ngưỡng0,085 có nhiễu/JPEG; không gọi là cỡ phông chính xác |")
lines.extend(['',
 'Chỉ đọc và đối chiếu: chưa chọn chữ mẫu, chưa đổi tỷ lệ, chưa nối mảnh, chưa cập nhật bộ ký tự. Nên đọc đối chứng 4/S và số 5 trong nguyên từ trước dùng; nếu đạt cùng kiểu/cỡ thì dựng mẫu riêng bằng một màu chung.',
 '',
 'Số 9: đã mở nguyên cụm 3SL4/9 trang 3, 4SL10/19 và 4SL12/29 trang 7, 4SL8/29 trang 6, cùng 4SL2/9 trang 4. Các ứng viên ngoài trang 3 đều có mép xám dưới hoặc đường gần/chồng vào vùng chân. Chưa tìm được bằng chứng ảnh rằng đổi sang một ứng viên đó sẽ sạch và chính xác hơn chữ 9 hiện dùng. Giữ trạng thái CHƯA THỂ chốt chữ mẫu 9 tốt hơn; không sửa bank (bộ ký tự) của tác nhân ghi.',
 'Nguyên cụm 3SL4/9 trang 3 vẫn đọc được chân móc và khoảng lõm dưới. Công thức V5 có bước đóng hình3điểmảnh ở chữ9; đây là dấu hiệu kỹ thuật có thể làm chân đầy hơn, chỉ là suy luận cần kiểm lại hình học thật, không phải chỉ thị tự co mực hoặc thay số.',
 '',
 'Các ảnh nguồn đã mở, giữ mã kiểm:'])
for p in seen:lines.append(f'- [{p.name}](<{p}>) — SHA256 `{sha(p)}`.')
lines.append('\nKhông có PDF/ảnh tô sửa, không sửa tệp g18/canonical (bản giao)/TIEN DO.md.\n')
t='\n'.join(lines).replace('ngưỡng0,085','ngưỡng 0,085').replace('đóng hình3điểmảnh ở chữ9','đóng hình 3 điểm ảnh ở chữ 9')
fp=Path(fresh(O/'g01_DOC BO SUNG DONOR5 9 NGUON - CHUA DOI BANK.md'));fp.write_text(t,encoding='utf8')
assert sha(d['source'])==d['source_SHA256']
print(fp,'SHA',sha(fp),flush=True)
