"""Chữ biểu đồ: nhận dạng và sao chép nét gốc từ chính tệp G01."""
from catfix.otext import OutlineText,procrustes,Match
from catfix.vector import union
import numpy as np,copy,collections

BLUE=(.133,.365,.635)
def blue_glyphs(T,p,rect):
    out=[];P=T.E.page(p)
    for g in T.page_glyphs(p):
        col=P.color_of(g.oi,'fill');cx=(g.bbox[0]+g.bbox[2])/2;cy=(g.bbox[1]+g.bbox[3])/2
        if col and max(abs(a-b) for a,b in zip(col,BLUE))<.02 and rect[0]<=cx<=rect[2] and rect[1]<=cy<=rect[3]:out.append(g)
    return out

def chart_refs(T):
    # Các nhãn 30/22/15/10 trên trang 3 nằm ngang, được kiểm trực tiếp bằng ảnh.
    upright=[]
    for ois,txt in [(range(358,365),'30-0.75'),(range(372,379),'22-0.55'),(range(386,393),'15-0.37'),(range(400,407),'10-0.25')]:
        gl=sorted([g for g in T.page_glyphs(2) if g.oi in ois],key=lambda g:g.oi)
        assert len(gl)==len(txt),(len(gl),len(txt))
        for g,c in zip(gl,txt):upright.append(dict(ops=g.ops,pts=g.pts,char=c,glyph=g));g.char=c
    # 48 chữ của 8 nhãn trang 9 đã đối chiếu ảnh nguồn + bảng G01.
    gs=sorted([g for g in T.page_glyphs(8) if 363<=g.oi<=410],key=lambda g:g.oi)
    txt='25-7.5'+'21-7.5'+'18-5.5'+'15-5.5'+'13-4.0'+'10-3.0'+'07-2.2'+'05-1.5'
    assert len(gs)==len(txt),(len(gs),len(txt))
    refs=list(upright)
    for j in range(8):
        gl=gs[j*6:j*6+6];line=txt[j*6:j*6+6];angles=[]
        for g,c in zip(gl,line):
            cand=[]
            for r in upright:
                if r['char']!=c or r['ops']!=g.ops or r['pts'].shape!=g.pts.shape:continue
                s,R,t,res=procrustes(r['pts'],g.pts,allow_rotation=True)
                if res<.03:cand.append((res,float(np.degrees(np.arctan2(R[1,0],R[0,0])))))
            if cand:angles.append(min(cand)[1])
        assert len(angles)>=2,(line,angles)
        ang=float(np.median(angles));a=np.radians(ang);R=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
        for g,c in zip(gl,line):
            pts=(g.pts-g.pts.mean(0))@R
            refs.append(dict(ops=g.ops,pts=pts,char=c,glyph=g));g.char=c
    # Hai chữ còn thiếu lấy ở nhãn 26-13 và 18-9.2 trang 10.
    for oi,c in [(405,'6'),(429,'9')]:
        g=[g for g in T.page_glyphs(9) if g.oi==oi]
        assert len(g)==1,(oi,len(g))
        g=g[0];g.char=c;refs.append(dict(ops=g.ops,pts=g.pts,char=c,glyph=g))
    assert set('0123456789.-')<=set(r['char'] for r in refs)
    return refs

def decode(g,refs):
    if len(g.pts)==4:
        # Viền hình chữ nhật của dấu chấm/gạch ngang giữ nguyên nét gốc.
        dims=np.linalg.svd(g.pts-g.pts.mean(0),compute_uv=False)
        char='-' if dims[0]/dims[1]>1.8 else '.'
        g.char=char
        return (0.,char,1.,None)
    cand=[]
    for r in refs:
        if r['ops']!=g.ops or r['pts'].shape!=g.pts.shape:continue
        s,R,t,res=procrustes(r['pts'],g.pts,allow_rotation=True)
        ang=float(np.degrees(np.arctan2(R[1,0],R[0,0])))
        # Các nguyên mẫu chart_refs đều đứng ngang trên trang 9/10.
        if .25<s<3 and res<.03 and -35<ang<12:cand.append((res,r['char'],s,ang,r))
    if not cand:return None
    rr=min(cand,key=lambda c:c[0]);g.char=rr[1]
    return rr[:4]

def group_labels(T,p,plot,refs):
    gs=blue_glyphs(T,p,(plot[0]-18,plot[1]-8,plot[0]+72,plot[3]+15))
    rows=[];unknown=[]
    decoded=[]
    for g in gs:
        d=decode(g,refs)
        if d is None:unknown.append(g);continue
        res,char,s,ang=d
        decoded.append((g,ang,res))
    for g,ang,res in decoded:
        if ang is None:
            others=[(abs((h.bbox[1]+h.bbox[3])/2-(g.bbox[1]+g.bbox[3])/2),a) for h,a,r in decoded if a is not None and abs(h.bbox[0]-g.bbox[0])<30]
            ang=min(others)[1] if others else 0.
        # Horizontal intercept removes rotation-induced vertical drift within a label.
        mid=(np.asarray(g.bbox[:2])+np.asarray(g.bbox[2:]))/2
        y=float(mid[1]-(mid[0]-plot[0])*np.tan(np.radians(ang)))
        rows.append((g,y,ang,res))
    # Glyphs of decimal/hyphen are thinner: their centres differ from the digit centres.
    groups=[]
    for g,y,ang,res in sorted(rows,key=lambda row:-row[1]):
        candidates=[(abs(y-np.median([v[1] for v in gr])),i) for i,gr in enumerate(groups)]
        if candidates and min(candidates)[0]<4.1:groups[min(candidates)[1]].append((g,y,ang,res))
        else:groups.append([(g,y,ang,res)])
    result=[]
    for gr in groups:
        gl=sorted([v[0] for v in gr],key=lambda g:g.bbox[0]);txt=''.join(g.char for g in gl)
        result.append(dict(text=txt,glyphs=gl,bbox=union(g.bbox for g in gl),angle=float(np.median([v[2] for v in gr])),y=float(np.median([v[1] for v in gr])),res=max(v[3] for v in gr)))
    result.sort(key=lambda x:-x['y'])
    return result,unknown
