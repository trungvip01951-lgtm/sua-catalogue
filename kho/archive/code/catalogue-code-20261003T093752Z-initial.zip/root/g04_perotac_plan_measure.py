from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
from scipy.interpolate import CubicHermiteSpline
from graph_image_math import color_runs,follow_observed_ink,fit_observed_ticks
from g04_perotac_audit_data import DATA
import numpy as np,json,math,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf'
src=S.src(name);dst=S.result(name)
audit=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));out=Path(S.report('G04/PHUONG AN 5 MOC LECH CHAC'))
doc=json.loads((audit/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'))
E=Editor(src);R=Raster(E);allitems=[];axes={}
for g in doc['graphs']:
 if g['family'] not in ['3SS3','3SS4','4SA16']:continue
 data=next(d for d in DATA if d['family']==g['family']);cv=R.canvas(max(R.images(g['page']-1),key=lambda z:z.W*z.H));ar=cv.orig.astype(int);lum=cv.orig.astype(float)@np.array([.299,.587,.114]);axis=g['axis'];fr=axis['frame_native'];top=int(fr['top'])+5;bottom=int(fr['bottom'])-5
 med=255-np.median(lum[top:bottom,:],axis=0);ticks=[]
 for t in axis['flow_ticks']:
  tau=t['u_native'];xs=np.arange(round(tau)-3,round(tau)+4);score=med[xs];baseline=float(np.median(np.r_[med[max(0,round(tau)-7):round(tau)-4],med[round(tau)+5:round(tau)+8]]));weight=np.maximum(score-baseline,0)
  keep=weight>.2*weight.max();u=float(np.average(xs[keep],weights=weight[keep]));tick=dict(**t,u_refined_native=u,profile_coordinates=xs.tolist(),median_darkness=score.tolist(),baseline=baseline,center_minus_recorded=u-tau);ticks.append(tick)
 fit=fit_observed_ticks([t['litre_per_minute'] for t in ticks],[t['u_refined_native'] for t in ticks]);axes[g['family']]=dict(ticks=ticks,fit=fit,numeric_labels_read_directly=True,method='Trọng tâm mực vạch dọc thật: trung vị cột trên toàn lòng biểu đồ, loại nền lân cận; không dùng tâm hộp chữ/số in.')
 rgb=ar;cr=rgb[:,:,1]-rgb[:,:,0];cb=rgb[:,:,2]-rgb[:,:,0];core=(cr>3)&(cb>3)&(cr+cb>11)&(lum>105)&(lum<225);weak=(cr>2)&(cb>3);neutral=(lum<140)&((rgb.max(2)-rgb.min(2))<14);protect=ndimage.binary_dilation(neutral,iterations=2)
 for c in g['curves']:
  if not any(p['status']=='LỆCH CHẮC' for p in c.get('points',[])):continue
  path=c['native_path'];us=np.array([p['u'] for p in path]);vs=np.array([p['v'] for p in path]);last=c['points'][-1];prior=c['points'][-2]
  startq=prior['Q_m3_h'] if c['family']!='3SS3' else c['points'][-3]['Q_m3_h']
  join=next(p for p in c['points'] if p['Q_m3_h']==startq)
  endpoint=path[-1];stop=int(fr['right'])-3
  extended,issues=follow_observed_ink(lambda x:color_runs(core,(255-lum)*np.maximum(cr+cb,0),x,top,bottom,max_width=6),endpoint,stop,1,radius=2.3,max_gap=2)
  tail=path[:-1]+extended
  lastcore=extended[-1];uend=lastcore['u'];vdend=lastcore['v'];fit_tail=np.polyfit([p['u'] for p in tail[-12:]],[p['v'] for p in tail[-12:]],1)
  weakpix=[]
  for u in range(int(join['target_u_native'])-2,min(stop,uend+7)+1):
   center=float(np.interp(u,[p['u'] for p in tail],[p['v'] for p in tail])) if u<=uend else float(np.polyval(fit_tail,u))
   ys=np.arange(max(top,int(center)-5),min(bottom,int(center)+6));good=ys[weak[ys,u]&~protect[ys,u]]
   weakpix.extend((int(u),int(v)) for v in good)
  tailpts=np.array([[p['u'],p['v']] for p in tail if join['target_u_native']-18<=p['u']<=uend]);poly=np.polyfit(tailpts[:,0],tailpts[:,1],3)
  tube=np.zeros(core.shape,bool)
  for u,v in tailpts:
   uu=int(u);rows=np.arange(max(top,int(round(v))-4),min(bottom,int(round(v))+5));tube[rows,uu]=True
  elig=tube&core&~protect
  # Source core color and equivalent perpendicular ink area are measured
  # independently for this named curve, away from crossing grid columns/rows.
  samples=[];columns=[];gridxs=[t['u_refined_native'] for t in ticks];gridys=[t['v_native'] for t in axis['H_grid_calibration']['ticks']]
  for u,v in tailpts:
   u=int(u)
   if u<join['target_u_native'] or u>last['target_u_native']-5:continue
   if min(abs(u-x) for x in gridxs)<3 or min(abs(v-y) for y in gridys)<3:continue
   ys=np.arange(max(top,int(v)-4),min(bottom,int(v)+5));good=ys[elig[ys,u]]
   if len(good):samples.extend(ar[good,u].tolist());columns.append(u)
  pix=np.array(samples,float);l=pix@np.array([.299,.587,.114]);color=np.median(pix[l<=np.percentile(l,20)],axis=0)
  alpha=np.clip((255-cv.orig.astype(float))@(255-color)/np.sum((255-color)**2),0,1);widths=[]
  for u in columns:
   v=float(np.interp(u,tailpts[:,0],tailpts[:,1]));ys=np.arange(max(top,int(round(v))-4),min(bottom,int(round(v))+5));local=tailpts[abs(tailpts[:,0]-u)<=5];sl=float(np.polyfit(local[:,0],local[:,1],1)[0]);widths.append(float((alpha[ys,u]*weak[ys,u]).sum()/np.sqrt(1+sl*sl)))
  native_step=float(abs(cv.to_page(1,0)[0]-cv.to_page(0,0)[0]));wpt=float(np.median(widths)*native_step)
  # Source-preserving join tangent from observed ink only; numeric endpoint
  # and optional interior point come only from the literal Q-H table.
  ju=join['target_u_native'];jv=join['v_native'];eu=last['target_u_native'];hc=axis['H_grid_calibration'];ev=hc['v_H0']+hc['v_per_m']*last['H_table_m'];leftpts=np.array([[p['u'],p['v']] for p in tail if ju-14<=p['u']<=ju+2]);s0=float(np.polyfit(leftpts[:,0],leftpts[:,1],1)[0]);end_numeric=last['H_table_m']
  nodes=[dict(u=ju,v=jv,Q_m3_h=startq,H_table_m=join['H_table_m'],H_existing_m=join['H_curve_m'],role='Nối đúng tọa độ mực nguồn ở mốc Q có số; giữ H hiện hữu trong ngưỡng, không tự chốt lại')]
  if c['family']=='3SS3':
   mid=c['points'][-2];nodes.append(dict(u=mid['target_u_native'],v=hc['v_H0']+hc['v_per_m']*mid['H_table_m'],Q_m3_h=mid['Q_m3_h'],H_table_m=mid['H_table_m'],role='Mốc nội suy trung gian có số thật, chưa nghiệm thu từ nét nguồn cũ'))
  nodes.append(dict(u=eu,v=ev,Q_m3_h=last['Q_m3_h'],H_table_m=end_numeric,role='Kết thúc đúng số cuối bảng; không dựng sau mốc này'))
  # This is analytic proposal geometry only. No canvas, PDF or image ink edit.
  xs=np.array([p['u'] for p in nodes]);ys=np.array([p['v'] for p in nodes]);sec=np.diff(ys)/np.diff(xs);slopes=np.r_[s0,[(2/(1/sec[i-1]+1/sec[i])) for i in range(1,len(sec))],sec[-1]]
  prop=CubicHermiteSpline(xs,ys,slopes);probe=np.linspace(xs[0],xs[-1],401);pv=prop(probe);dv=prop.derivative()(probe);assert dv.min()>=0,(c['model'],dv.min())
  target_fit_u=fit['intercept']+fit['slope']*last['Q_l_min'];ref_v=float(np.interp(target_fit_u,us,vs)) if target_fit_u<=us[-1] else float(vs[-1]+(target_fit_u-us[-1])*(vs[-1]-vs[-2])/(us[-1]-us[-2]));ref_h=(ref_v-hc['v_H0'])/hc['v_per_m']
  oldxs=[u for u,v in weakpix];oldys=[v for u,v in weakpix];box=(math.floor(min(oldxs+[ju]))-3,math.floor(min(oldys+[float(pv.min())]))-3,math.ceil(max(oldxs+[eu]))+4,math.ceil(max(oldys+[float(pv.max())]))+4)
  min_other=np.inf;near=[]
  for other in g['curves']:
   if other['model']==c['model'] or not other.get('native_path'):continue
   op=other['native_path'];ou=np.array([p['u'] for p in op]);ov=np.array([p['v'] for p in op]);valid=(probe>=ou[0])&(probe<=ou[-1]);dist=abs(pv[valid]-np.interp(probe[valid],ou,ov));mind=float(dist.min()) if len(dist) else None
   if mind is not None and mind<30:near.append(dict(model=other['model'],min_vertical_center_distance_native_px=mind));min_other=min(min_other,mind)
  item=dict(page=c['page'],family=c['family'],model=c['model'],original_source_image=str(max(R.images(c['page']-1),key=lambda z:z.W*z.H).name),caption_native_box=c['label_native_box'],original_point=last,numeric_join=join,numeric_nodes=nodes,old_core_last_native=lastcore,old_weak_tail_pixel_extent=[min(oldxs),min(oldys),max(oldxs),max(oldys)],source_tail_core_extension_points=extended,source_tail_extension_ambiguities=issues,source_color_RGB=color.tolist(),source_equivalent_width_native_px=float(np.median(widths)),source_equivalent_width_pt=wpt,width_sample_count=len(widths),width_native_p10_p90=np.percentile(widths,[10,90]).tolist(),color_core_sample_count=int((l<=np.percentile(l,20)).sum()),source_step_pt_per_native_px=native_step,source_join_tangent_dv_du=s0,proposed_tangent_dv_du=slopes.tolist(),proposed_min_derivative_dv_du=float(dv.min()),proposed_max_derivative_dv_du=float(dv.max()),proposed_native_edit_bounding_box=box,proposed_page_edit_bounding_box=cv.rect(box),printed_last_flow_refined_u_native=target_fit_u,independent_refined_grid_H_curve_m=float(ref_h),independent_refined_grid_delta_H_m=float(ref_h-end_numeric),independent_refined_grid_still_fail=abs(ref_h-end_numeric)>last['tolerance_H_m']+last['uncertainty_H_m'],nearby_other_source_paths=near,contains_black_text_or_frame_pixels=int(protect[box[1]:box[3],box[0]:box[2]].sum()),plan_only=True,pdf_written=False,source_pixel_count_retained_before_join=int((us<ju).sum()),must_preserve_other_curves=['4SA16/23','4SA16/18'] if c['family']=='4SA16' else [],whole_curve_accepted=False)
  allitems.append(item)
  print('PLAN',c['model'],'joinQ/Hactual',startq,join['H_curve_m'],'table',join['H_table_m'],'nodes',[(p['Q_m3_h'],p['H_table_m']) for p in nodes],'core end',uend,vdend,'weak end',max(oldxs),'RGB',color,'width',wpt,'box',box,'refinedH',ref_h,'stillFAIL',item['independent_refined_grid_still_fail'],'near',near)
  # Evidence annotations mark old extent, proposal envelope and numeric nodes;
  # blue polyline is a plan overlay, not a claim of a repaired PDF.
  pad=8;viewbox=(box[0]-pad,box[1]-pad,box[2]+pad,box[3]+pad);im=Image.fromarray(cv.orig[viewbox[1]:viewbox[3],viewbox[0]:viewbox[2]]).resize(((viewbox[2]-viewbox[0])*6,(viewbox[3]-viewbox[1])*6),Image.Resampling.NEAREST);d=ImageDraw.Draw(im)
  d.rectangle(((box[0]-viewbox[0])*6,(box[1]-viewbox[1])*6,(box[2]-viewbox[0])*6,(box[3]-viewbox[1])*6),outline='orange',width=2)
  d.line([((u-viewbox[0])*6,(v-viewbox[1])*6) for u,v in zip(probe,pv)],fill='blue',width=2)
  for node in nodes:
   xx=(node['u']-viewbox[0])*6;yy=(node['v']-viewbox[1])*6;d.ellipse((xx-6,yy-6,xx+6,yy+6),outline='red',width=2)
  im.save(fresh(out/c['model'].replace('/','-')/'SO DO PHUONG AN CHI DINH VI.png'))
Path(fresh(out/'SO DO VA DO NET 5 PHUONG AN.json')).write_text(json.dumps(dict(read_only=True,pdf_written=False,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),current_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest(),Q_axis_independent_refinement=axes,items=allitems),ensure_ascii=False,indent=2),encoding='utf8');E.close()
