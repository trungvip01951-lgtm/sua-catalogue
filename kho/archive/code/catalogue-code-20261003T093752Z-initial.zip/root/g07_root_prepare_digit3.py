"""ROOT reads G07's actual digit and same-font donor before a narrow repair."""
from catwork import start, fresh
S, _, _ = start()
from pathlib import Path
import hashlib, json
import numpy as np
import pikepdf
from catfix.vector import Editor
from catfix.textlayer import TextLayer
from catfix import verify

NAME = 'Catalog bơm nước thải Aquaris FS (bản mới).pdf'
source = Path(S.src(NAME))
current = Path(S.result(NAME))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source) == '4ae76b0cc2a5d1060763b332093ce952ac964902bd9aaa705f4a36b4ef9ce8fa'
assert sha(current) == '5785252969ffb1f9cc78bda04f57bf573b555b26acf0a2deef68b61e96988c4e'
hashes = {str(p): sha(p) for p in [source, current]}

def plain(v):
    if isinstance(v, dict): return {str(k): plain(x) for k,x in v.items()}
    if isinstance(v, (list,tuple)): return [plain(x) for x in v]
    if hasattr(v, 'tolist'): return plain(v.tolist())
    if isinstance(v, bytes): return v.hex()
    return v

def glyph(g):
    r = g.run
    return plain(dict(char=g.ch, code=g.cb, origin=g.o, end=g.e,
        bbox=g.bbox, font=r.font.basefont, font_resource=r.fontname,
        size=r.size_page, fill=r.fill, tr=r.tr, tc=r.tc, tw=r.tw,
        th=r.th, ts=r.ts, Tm=r.Tm, ctm=r.ctm, index=r.index, k=g.k))

A, B = Editor(str(source)), Editor(str(current))
TA, TB = TextLayer(A), TextLayer(B)
readback = []
for label,E,T in [('source',A,TA),('current',B,TB)]:
    match = T.find(0, 'G 2”', rect=(750,247,783,260))
    assert len(match) == 1
    m = match[0]
    digits = [g for g in m.glyphs if g.ch == '2']
    quotes = [g for g in m.glyphs if g.ch == '”']
    assert len(digits) == len(quotes) == 1
    d,q = digits[0],quotes[0]
    assert abs(d.run.size_page-8) < 1e-9 and d.run.tr == 0
    assert d.run.font.basefont == 'BBDDVM+UTM-Helve'
    assert d.cb == b'2' and q.cb == bytes([0x94])
    assert d.run.font.encode('3') == b'3'
    assert d.run.font.width(b'2') == d.run.font.width(b'3') == 586.0
    same = [g for g in T.glyphs(0,visible_only=True)
        if g.ch == '3' and g.run.font.basefont == d.run.font.basefont
        and abs(g.run.size_page-d.run.size_page) < 1e-9
        and g.run.fill == d.run.fill and g.run.tr == d.run.tr]
    assert same
    outlet = T.find(0,'50',rect=(1100,620,1150,635))
    assert len(outlet) == 1
    readback.append(dict(file=label, thread=m.text,
        thread_glyphs=[glyph(g) for g in m.glyphs],
        digit=glyph(d), quote=glyph(q),
        available_same_font_3=[glyph(g) for g in same],
        untouched_outlet=outlet[0].text,
        digit_equal_advance=True, original_quote_byte_preserved=True))

assert readback[0]['thread_glyphs'] == readback[1]['thread_glyphs']
fields = ['op','fill','stroke','lw','dash','gs','fill_cs','stroke_cs','clip','textclip','ctm']
pa,pb = A.page(0),B.page(0)
assert len(pa.objs) == len(pb.objs) == 273
for aa,bb in zip(pa.objs,pb.objs):
    assert plain({k:aa[k] for k in fields}) == plain({k:bb[k] for k in fields})
    oa = [(i.op,plain(i.operands)) for i in pa.ops[aa['i0']:aa['i1']+1]]
    ob = [(i.op,plain(i.operands)) for i in pb.ops[bb['i0']:bb['i1']+1]]
    assert oa == ob

folder = Path(S.report('G07/ROOT DOC DUNG G2 VA CHU3 CUNG PHONG TRUOC SUA'))
folder.mkdir(parents=True,exist_ok=False)
digit = readback[1]['digit']
plan = dict(status='ĐẠT PHƯƠNG ÁN SỬA RIÊNG REN; CHƯA PDF', task=137,
    name=NAME, source=str(source), current=str(current), hashes=hashes,
    actual_current='G 2”', expected='G 3”',
    current_digit=digit, original_quote=readback[1]['quote'],
    donor_3=readback[0]['available_same_font_3'][0],
    edit=dict(old='2',new='3',rect=digit['bbox'],align='center',keep_rest=True),
    authoring='catfix TextLayer.replace only digit, not full run; preserve original quote code 94',
    drawings273_held=True, outlet_50_to_80='CHƯA THỂ: thiếu 8 MyriadPro-Regular cùng nguồn',
    readback=readback, PDF_written=False, canonical_written=False)
path = Path(fresh(folder/'ROOT PHUONG AN REN G2 SANG G3 DOC PDF THAT.json'))
path.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
for label,p in [('NGUON',source),('HIEN TAI',current)]:
    verify.crop(str(p),0,(750,244,786,263),600).save(fresh(folder/(label+' G2 THUC600.png')))
assert hashes == {str(p):sha(p) for p in [source,current]}
A.close();B.close()
print(json.dumps(dict(plan=str(path),plan_sha256=sha(path),current_actual='G 2”',
    source_same_style_3=True,drawings273_held=True,PDF_written=False),ensure_ascii=False),flush=True)
