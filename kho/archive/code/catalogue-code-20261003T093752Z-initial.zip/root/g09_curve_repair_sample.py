from catwork import start,fresh
from pathlib import Path
import json,hashlib,sys,math
import numpy as np
S,D,N=start()
from catfix.vector import Editor
from catfix.charts import Chart,sample_path
from catfix.recipes import Job
from catfix import verify
import pymupdf as fitz

fi=int(sys.argv[1]) if len(sys.argv)>1 else 0
qa=json.loads(Path(S.report('G09/NGHIEM THU CHOT.json')).read_text(encoding='utf8'))['checks'][fi]
src=S.dst(qa['file']);assert hashlib.sha256(Path(src).read_bytes()).hexdigest()==qa['destination_sha256']
measure=json.loads(Path(S.report('G09/DO DUONG/DOI CHIEU LAN1.json')).read_text(encoding='utf8'))
selected=[c for c in measure['curves'] if c['file']==qa['file'] and not c['ok']]
short='Perotac' if fi==0 else 'Redpump'
E=Editor(src,backend='fitz');plans=[]
def smooth(t):
    t=min(1.,max(0.,float(t)));return t*t*(3-2*t)
for c in selected:
    pi=c['page']-1;ax=c['axes'];ch=Chart(ax['ax'],ax['bx'],ax['ay'],ax['by'])
    qr,hr,qm,hm=c['table'];qs,hs=c['start'];qe,he=c['end']
    hc=Chart.value_at(c['points'],qr);dh0=hm-hs;dhr=hr-hc
    def deform(q,h):
        if q<=qr:
            t=min(1.,max(0.,(q-qs)/(qr-qs)));qn=qr*t
            hn=h+dh0*(1-t)**2+dhr*smooth(t)
        else:
            t=(q-qr)/(qe-qr);qn=q+(qm-qe)*smooth(t)
            hn=h+dhr*smooth(1-t)
        return qn,min(hm,hn)
    P=E.page(pi);done=[];anchors=[]
    for oi in c['objects']:
        pp=P.object_pagepath(oi);assert P.objs[oi]['op']=='S'
        if any(op!='m' and op!='l' for op,_ in pp):xy=sample_path(pp,n=80)
        else:xy=np.array([p for op,pts in pp for p in pts],float)
        old=ch.to_data(xy);expanded=[old[0]]
        for p0,p1 in zip(old,old[1:]):
            if (p0[0]-qr)*(p1[0]-qr)<0:
                h=p0[1]+(p1[1]-p0[1])*(qr-p0[0])/(p1[0]-p0[0]);expanded.append(np.array([qr,h]))
            expanded.append(p1)
        new=[deform(float(q),float(h)) for q,h in expanded]
        npp=[('m',[ch.to_page(*new[0])])]+[('l',[ch.to_page(*p)]) for p in new[1:]]
        E.replace_path(pi,oi,npp)
        for q,h in new:
            if abs(q-qr)<1e-7:anchors.append([float(q),float(h)])
        done.append(dict(oi=oi,op=P.objs[oi]['op'],color=P.color_of(oi,'stroke'),local_width=P.objs[oi]['lw'],source_path=pp,new_path=npp))
    assert anchors and min(abs(h-hr) for q,h in anchors)<.002,(c['model'],anchors)
    plans.append(dict(model=c['model'],frequency=c['frequency'],page=c['page'],rect=c['chart_rect'],table=c['table'],old_start=c['start'],old_end=c['end'],old_rate_H=hc,head_start_delta=dh0,head_rate_delta=dhr,end_flow_delta=qm-qe,source_H_end_retained=he,objects=done,anchors=anchors))
dst=fresh(S.report(f'G09/DUONG MAU LAN1/{qa["file"]}'));E.save(dst);E.close()
j=Job(src,dst,log_path=S.report(f'G09/DUONG MAU LAN1/{short}.log.json'))
seen=set()
for p in plans:
    key=(p['page'],tuple(p['rect']))
    if key not in seen:
        j._add(p['page']-1,p['rect'],'Sửa đường theo điểm định mức/giới hạn bảng, giữ H cuối nguồn','curve');seen.add(key)
ck=j.check();assert ck['ok'],ck
allowed={}
for p,r in seen:allowed.setdefault(p,[]).append((r[0]-1,r[1]-1,r[2]+1,r[3]+1))
outside=verify.outside_pixels(src,dst,allowed,dpi=150,thr=12,min_size=1);assert not outside,outside
A=fitz.open(src);B=fitz.open(dst);assert A.metadata==B.metadata and A.get_xml_metadata()==B.get_xml_metadata() and A.get_toc()==B.get_toc()
links=lambda doc:[[dict((k,str(v)) for k,v in z.items() if k!='xref') for z in p.get_links()] for p in doc]
assert links(A)==links(B);A.close();B.close()
j.evidence(fresh(S.report(f'G09/DUONG MAU LAN1/TRUOC SAU {short}.png')),dpi=180)
Path(fresh(S.report(f'G09/DUONG MAU LAN1/KIEM TRA {short}.json'))).write_text(json.dumps(dict(source=src,source_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),sample=dst,sample_sha256=hashlib.sha256(Path(dst).read_bytes()).hexdigest(),plans=plans,check=ck,outside=outside),ensure_ascii=False,indent=2,default=str),encoding='utf8')
print(short,'SAMPLE',len(plans),'đường; CHECK',ck['ok'],flush=True);j.close()
