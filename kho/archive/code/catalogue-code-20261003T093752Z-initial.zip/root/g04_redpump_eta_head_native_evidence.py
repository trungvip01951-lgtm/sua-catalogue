"""Inspect source colored efficiency head at the actual frame. No numeric eta/PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from graph_image_math import color_runs
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));frame=json.loads((root/'KHUNG LUOI THAT NGUON TRANG8.json').read_text(encoding='utf8'));src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float);g=a@np.array([.299,.587,.114]);rec=[]
for rg,bg,maxgray in [(2,3,248),(4,6,240),(6,8,230)]:
 mask=(a[:,:,1]-a[:,:,0]>rg)&(a[:,:,2]-a[:,:,0]>bg)&(g<maxgray);cols=[]
 for u in range(119,135):
  rr=color_runs(mask,255-g,u,661,676,max_width=12);cols.append(dict(native_u=u,color_ink_runs=[dict(**z,page_xy=list(cv.to_page(u,z['v']))) for z in rr]))
 rec.append(dict(G_minus_R_gt=rg,B_minus_R_gt=bg,gray_lt=maxgray,columns=cols))
pic=Image.new('RGB',(1500,450),'white');dr=ImageDraw.Draw(pic);srcpic=Image.fromarray(cv.orig);box=(116,658,150,680);raw=srcpic.crop(box).resize((680,440),Image.Resampling.NEAREST);pic.paste(raw,(5,5));dr.text((750,20),'Original native pixels: colored head meets black frame',fill='blue');dr.text((750,45),'Color threshold can miss/shift a black-overlapped endpoint.',fill='blue');dr.text((750,70),'No invented numerical eta table or eta=0 assumption.',fill='blue');wide=srcpic.crop((114,654,194,680)).resize((640,208),Image.Resampling.NEAREST);pic.paste(wide,(750,180))
photo=fresh(root/'DAU ETA KHUNG DEN MUC NGUON THAT.png');pic.save(photo);eta=next(z for z in frame['panels'] if z['name']=='eta');first=np.array(eta['frame_native_uv'])[:2];bbox=eta['frame_page_bbox'];proposed=[bbox[0],bbox[1]]
out=dict(source_SHA256=before[0],current_SHA256=before[1],source_image_size=[im.W,im.H],source_native_CTM=im.ctm.tolist(),original_corner_native=[eta['frame_native_uv'][0],eta['frame_native_uv'][3]],original_corner_page=[bbox[0],bbox[1]],threshold_source_profiles=rec,source_photo=photo,source_native_edge_uncertainty_pt=.480136,source_display_observation='Ảnh nguồn cho thấy đường η nối góc khung trái dưới. Mực xanh/xám đầu bị mực đen khung che. Dò màu mạnh bắt đầu u128; không dùng u128 làm bằng chứng đầu đường kỹ thuật.',proposed_geometry_endpoint=proposed,proposed_geometry_status='ỨNG VIÊN THEO GÓC MỰC KHUNG QUAN SÁT; cần ROOT đọc trực tiếp và khóa. Không phải số hiệu suất lấy từ bảng, không khẳng định tâm đầu nét nằm chính xác ở góc do mực chồng.',numeric_eta_data='CHƯA THỂ: không có bảng số η riêng.',no_extrapolated_numeric_eta=True,PDF_written=False)
Path(fresh(root/'DAU ETA MUC NGUON VA GIOI HAN XAC MINH.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('eta actual source corner',proposed,'numeric eta not inferred, noPDF',flush=True)
