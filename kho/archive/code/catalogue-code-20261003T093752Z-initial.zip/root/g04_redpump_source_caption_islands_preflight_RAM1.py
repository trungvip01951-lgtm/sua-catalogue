"""Read all13 whole original source captions. No glyph/image/PDF mutation."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/'13 CAPTION NGUYEN NGUON DAO RAM LAN1B'
assert not F.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json');w=J(P/'CHU NGUON ALPHA THU DO DOC V2.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
es=Editor(b['source'],backend='fitz');ec=Editor(b['input_current'],backend='fitz');rs=Raster(es);rc=Raster(ec)
im=max(rs.images(7),key=lambda z:z.W*z.H);cv=rs.canvas(im)
assert (im.W,im.H)==(1739,1237)
items=[];tiles=[]
for k,r in enumerate(w['records']):
    # Keep source whole-word request INCLUDING all borders, not just its core.
    bb=list(r['source_page_rect']);rect=bb
    canvases={}
    for dpi in [150,600]:
        sc=rs.render_canvas(7,rect,dpi=dpi);cc=rc.render_canvas(7,rect,dpi=dpi)
        assert sc.orig.shape==cc.orig.shape
        stem=r['model'].replace('/','_')
        sp=Path(fresh(F/(stem+f' NGUYEN NGUON {dpi}dpi FULL MEP.png')));cp=Path(fresh(F/(stem+f' BAN GIAO {dpi}dpi FULL MEP.png')))
        Image.fromarray(sc.orig).save(sp);Image.fromarray(cc.orig).save(cp)
        canvases[dpi]=(sc,cc,str(sp),str(cp))
    sc,cc,sp,cp=canvases[600]
    ar=sc.orig.astype(float);g=ar@np.array([.299,.587,.114])
    neutral=(ar.max(2)-ar.min(2))<25
    # Color is diagnostics only; it is NOT a glyph alpha or edit mask.
    colored=(ar[:,:,1]-ar[:,:,0]>8)&(ar[:,:,2]-ar[:,:,0]>10)&(g<230)
    dark=neutral&(g<155)
    def bounds(mask):
        yy,xx=np.where(mask)
        return None if not len(xx) else [int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]
    bs=bounds(dark);bc=bounds(colored)
    word_candidate=[*sc.to_page(bs[0]-8,bs[3]+8),*sc.to_page(bs[2]+8,bs[1]-8)] if bs else None
    # Diagnostic ruler positioned OUTSIDE source pixels.
    photo=Image.new('RGB',(sc.orig.shape[1]*4+80,sc.orig.shape[0]*4+70),'white');dr=ImageDraw.Draw(photo)
    photo.paste(Image.fromarray(sc.orig).resize((sc.orig.shape[1]*4,sc.orig.shape[0]*4),Image.Resampling.NEAREST),(60,50))
    dr.text((2,2),r['model']+' original SOURCE600 FULL crop, NO RETOUCH',fill='blue')
    for x in range(0,sc.orig.shape[1],10):
        dr.text((60+x*4,22),str(x),fill='purple');dr.line((60+x*4,42,60+x*4,49),fill='purple')
    for y in range(0,sc.orig.shape[0],8):
        dr.text((2,47+y*4),str(y),fill='purple');dr.line((48,50+y*4,59,50+y*4),fill='purple')
    ruler=Path(fresh(F/(stem+' NGUYEN NGUON600 FULL MEP THUOC4X.png')));photo.save(ruler)
    tile=Image.new('RGB',(1650,270),'white');td=ImageDraw.Draw(tile);td.text((5,4),r['model']+'  source150 / current150 ; source600 full / current600 full',fill='blue')
    for dpi,x,y in [(150,5,40),(600,5,95)]:
        z,c,_,_=canvases[dpi];scale=3 if dpi==150 else 2
        left=Image.fromarray(z.orig).resize((z.orig.shape[1]*scale,z.orig.shape[0]*scale),Image.Resampling.NEAREST)
        right=Image.fromarray(c.orig).resize(left.size,Image.Resampling.NEAREST)
        tile.paste(left,(x,y));tile.paste(right,(835,y))
    tiles.append(tile)
    native_box=np.r_[cv.to_px(bb[0],bb[3]),cv.to_px(bb[2],bb[1])].tolist()
    changes=np.any(sc.orig!=cc.orig,axis=2)
    items.append(dict(model=r['model'],source_page_whole_request=bb,actual600_rect=list(sc.rect0),source_native_box_float=native_box,
        original_full600_SHA256=hashlib.sha256(sc.orig.tobytes()).hexdigest(),full_crop_width_height600=[sc.orig.shape[1],sc.orig.shape[0]],
        source_vs_current600_changed_pixels=int(changes.sum()),source_neutral_dark_155_bbox600=bs,source_colored_curve_candidate_bbox600=bc,
        source_colored_curve_candidate_pixels600=int(colored.sum()),dark_bbox_plus8px_candidate_page_box=word_candidate,
        candidate_box_NOT_ACCEPTED=True,source_word_raw_and_CTM_NOT_CHANGED=True,
        color_diagnostics_NOT_a_glyph_or_edit_mask=True,source_images={str(d):dict(source=canvases[d][2],current=canvases[d][3]) for d in canvases},ruler=str(ruler),
        original_whole_word_font_size_position_kept=True,font_program_UNKNOWN=True,
        status='CHƯA CHỐT đảo; cần soi toàn mép, nét đường cũ và khoảng hở.'))
atlas=Image.new('RGB',(1650,len(tiles)*280),'white')
for k,t in enumerate(tiles):atlas.paste(t,(0,k*280))
atlas.save(fresh(F/'13 CAPTION NGUYEN NGUON VA BAN GIAO150600 FULL MEP.png'))
data=dict(source=b['source'],source_SHA256=guards[0],current=b['input_current'],current_SHA256=guards[1],M1=b['sample'],M1_SHA256=guards[2],
    source_image_resource=str(im.name),source_image_raw_SHA256=hashlib.sha256(es.doc.stream_raw(im.ref)).hexdigest(),
    source_image_size=[im.W,im.H],source_image_CTM=im.ctm.tolist(),records=items,
    count=13,whole_original_source_only=True,glyph_fit_stopped=True,source_RGB_never_used_as_glyph_mask=True,
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False,
    status='SOURCE13 caption full read-only. Island boundaries still require readback; no fontPASS from hash alone.')
p=Path(fresh(F/'13 CAPTION NGUYEN NGUON FULL MEP VI TRI VA MUC CU.json'))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
es.close();ec.close();assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print(str(p),flush=True)
print([(r['model'],r['source_neutral_dark_155_bbox600'],r['source_colored_curve_candidate_pixels600']) for r in items],flush=True)
