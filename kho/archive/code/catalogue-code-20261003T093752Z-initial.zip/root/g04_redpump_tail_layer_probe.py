from catwork import start
S,D,N=start()
from catfix.vector import Editor
E=Editor(S.result('Redpump gieng SL_compressed (bản mới).pdf'),backend='fitz');P=E.page(7)
print('ops',len(P.ops),'objects',len(P.objs))
print('LAST OPS',[(i,str(op)) for i,op in enumerate(P.ops) if i>len(P.ops)-25])
print('LAST OBJECTS',P.objs[-1:]);print('PAGE ATTRS',[k for k in dir(P) if 'matrix' in k or 'ctm' in k or 'state' in k or 'end' in k]);print('END CTM',P.ctm_at(len(P.ops)))
E.close()
