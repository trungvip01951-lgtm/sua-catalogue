from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np,hashlib
from catfix import verify
r=Path(S.report('G04/REDPUMP 25 PHUONG AN SUA DUOI'));d=json.loads((r/'PHUONG AN RIENG SUA DUOI 25.json').read_text(encoding='utf8'));rect=(130,491,166,500)
checks=[]
for dpi in [150,450,600]:
 a=np.asarray(verify.crop(d['source'],7,rect,dpi));z=np.asarray(verify.crop(d['current'],7,rect,dpi));different=int(np.any(a!=z,axis=2).sum());checks.append(dict(dpi=dpi,rect=rect,source_current_pixels_changed=different))
verify.compare_sheet(d['source'],d['current'],[(7,rect,'Nhãn p8: nguồn | bản giao')],fresh(r/'NHAN25 NGUON VA BAN GIAO GIU NGUYEN.png'),dpi=600,pad=(.3,.3))
report=json.loads(Path(S.report('G04/NGHIEM THU CHOT CHU SO.json')).read_text(encoding='utf8'));records=[p for p in report['records'] if p.get('file','').startswith('Redpump') and p.get('page')==8];rename=[p for p in records if '/28' in str(p.get('old','')) or '/25' in str(p.get('new',''))]
note=dict(source=d['source'],source_SHA256=d['source_SHA256'],current=d['current'],current_SHA256=d['current_SHA256'],source_label_box=rect,source_current_label_pixels=checks,mandatory_records_rename28_to25=rename,source_curve_table_model='4SL16/25',current_model_authority='ROOT đã khóa model hiện hành /25 và đọc đúng hàng bảng; giữ căn cứ này.',correction='Trong phương án/báo cáo mẫu đã viết nhãn nguồn/28 được đổi/25 theoCAN dựa theo tinROOT. Kiểm mới không thấy việc đổi này trong84vị trí CAN; hộp nhãn nguồn/current giữ nguyên điểm ảnh. Vì vậy bỏ khẳng định đã sửa nhãn/28→/25. Hai cách đọc5/8 trênJPEG cần tách khỏi thay đổi tệp thực. Việc sửa đuôi vẫn dựa đúng đường liên kết theo nhãn hiện hành và bảng/25 doROOT đọc độc lập.',catalogue_written=False)
Path(fresh(r/'BO SUNG NGUON GOC NHAN25 KHONG SUA.json')).write_text(json.dumps(note,ensure_ascii=False,indent=2),encoding='utf8');print(checks,'CAN rename',rename)
