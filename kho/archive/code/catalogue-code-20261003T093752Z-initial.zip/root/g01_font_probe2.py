from catwork import start
S,D,N=start()
from catfix.recipes import Job
from catfix.otext import OutlineText,robust_fit,procrustes,norm
from pathlib import Path
import pickle,copy,json
j=S.job('Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf');T=j.T
state=pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes());T.__dict__.update(state['data'])
p=14;U=OutlineText(j.E)
allowed=[copy.copy(g) for g in T.page_glyphs(p) if 80<g.bbox[1]<710 and 150<g.bbox[0]<460 and j.E.page(p).objs[g.oi].get('fill')==('rg',(0.216064,0.204102,0.208008))]
for g in allowed:U._assign_cluster(g)
U.glyphs[p]=allowed;U.learn([p],dpi=400,verbose=False)
samples=[dict(chars=txt,boxes=[g.bbox for g in gl]) for txt,gl in U.text_lines(p) if '?' not in txt]
F=robust_fit(samples)
print('body metrics',{k:F[k] for k in ['rms_x','max_x','rms_y','max_y','n']})
print('metrics needed',{c:{k:F[k].get(c) for k in ['lsb','adv','bot']} for c in 'DeliverycasngMotorhfAISI316s kWP'})
wm=T.find(14,'Warranty: 1 year')[0];tg=[g for g in wm.glyphs if g.char=='1'][0]
print('target Warranty 1',tg.ops,len(tg.pts),tg.bbox)
for p1 in [1,2,14]:
    for g in [g for g in T.page_glyphs(p1) if g.char=='1'][:100]:
        if g.ops==tg.ops and len(g.pts)==len(tg.pts):
            s,R,t,res=procrustes(g.pts,tg.pts,allow_rotation=False)
            if res<.04:print('MATCH1',p1+1,g.oi,g.bbox,'scale',s,'res',res,j.E.page(p1).objs[g.oi].get('fill'))
j.close()
