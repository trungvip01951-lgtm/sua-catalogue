from catwork import start,fresh
from pathlib import Path
import json,math,datetime,sys
import numpy as np
S,D,N=start()
from catfix.charts import Chart

# Read each field directly from the final PDF tables; Q is m3/h, H is metres.
models=['21.5','31.5','22.2','32.2','23.7','33.7','43.7','35.5','45.5','47.5','67.5','411','611','415','615']
f50=[(15,15,27,22),(30,8,40,14.5),(18,20,33,26),(36,11,55,19),(12,30,33,34),(30,20,55,29),(60,11.5,90,18.5),(36,25,75,34),(60,16,105,23),(48,30,84,40),(90,15,124.8,31),(60,35,84,48.5),(102,22,147,32),(60,42,84,56),(102,30,156,40)]
f60=[(15,16.5,27,23),(30,9,45,15),(18,20,31,28),(30,13,47,20.5),(12,30,50,33),(30,22,55,31),(60,11.5,96,18.5),(36,25,69,38),(60,16,102,24.4),(48,30,80,41),(90,15,127,31),(60,35,84,48.5),(102,22,147,32),(60,42,84,57),(102,27,160,39)]
lh={
'422':(66,60,130,68,66,60,138,68),'430':(72,70,170,78,72,75,144,82),
'622':(120,37,200,50,120,40,210,52),'630':(140,45,220,58,140,48,216,64),
'637':(120,65,220,83,100,65,198,80),'645':(120,75,220,90,100,75,198,90),
'837':(216,35,330,48,216,35,306,50),'845':(270,35,372,53,270,35,305,56),
'655':(90,90,180,102,90,90,180,102),'675':(90,120,180,132,90,120,168,132),
'855':(240,50,390,65,240,50,390,65),'875':(270,60,408,70,270,60,348,78),
'690':(120,128,180,140,120,128,180,140),'890':(270,70,360,90,270,70,360,90),
'6110':(120,150,192,200,120,160,171,205),'8110':(270,90,390,107,270,90,390,107)}
table={'KTZ50':dict(zip(models,f50)),'KTZ60':dict(zip(models,f60)),
       'LH50':{m:v[:4] for m,v in lh.items()},'LH60':{m:v[4:] for m,v in lh.items()}}
orders=[['35.5','23.7','33.7','22.2','45.5','21.5','32.2','43.7','31.5'],['415','411','47.5','615','611','67.5'],
        ['35.5','23.7','33.7','22.2','45.5','21.5','32.2','43.7','31.5'],['415','411','47.5','615','611','67.5'],
        ['6110','690','675','655','645','637','430','422','630','622'],['8110','890','875','855','845','837'],
        ['6110','690','675','655','645','430','637','422','630','622'],['8110','890','875','855','845','837']]
qtops=[105,180,105,180,250,450,250,450];htops=[40,60,40,60,200,120,220,120]
keys=['KTZ50','KTZ50','KTZ60','KTZ60','LH50','LH50','LH60','LH60']
rawdata=json.loads(Path(S.report('G09/NGUON.json')).read_text(encoding='utf8'))
rows=[];mapped=[];axes_records=[]
tag=sys.argv[1] if len(sys.argv)>1 else 'LAN3'
for d in rawdata:
    curves=json.loads(Path(S.report(f'G09/DO DUONG/{tag}/{d["short"]}/CAC DUONG.json')).read_text(encoding='utf8'))
    grids=json.loads(Path(S.report(f'G09/DO DUONG/TRUC LAN2 {d["short"]}.json')).read_text(encoding='utf8'))
    for ci,(c,g,order,qtop,htop,key) in enumerate(zip(curves,grids,orders,qtops,htops,keys)):
        gx=np.array(g['gx'],float);gy=np.array(g['gy'],float)
        xt=[];yt=[];dx=10 if key.startswith('KTZ') and ci%2==0 else (20 if key.startswith('KTZ') else 50)
        if ci in (5,7):dx=50
        dy=10 if ci in (0,2,5,7) else (15 if ci in (1,3) else 20)
        for Q in sorted(set(list(np.arange(0,qtop+1e-6,dx))+[qtop])):
            want=gx[0]+Q/qtop*(gx[-1]-gx[0]);x=float(gx[np.argmin(abs(gx-want))]);assert abs(x-want)<.12
            xt.append((float(Q),x))
        for H in np.arange(0,htop+1e-6,dy):
            want=gy[0]+H/htop*(gy[-1]-gy[0]);y=float(gy[np.argmin(abs(gy-want))]);assert abs(y-want)<.12,(ci,H,y,want)
            yt.append((float(H),y))
        ch=Chart.from_ticks(xt,yt,max_res=.12);assert ch.warning is None
        axes_records.append(dict(file=d['name'],chart=c['label'],xticks=xt,yticks=yt,residual=ch.residual,ax=ch.ax,bx=ch.bx,ay=ch.ay,by=ch.by))
        main=c['components'][:len(order)];extras=c['components'][len(order):]
        for model,co in zip(order,main):
            co['terminal']=co['last'];co['extra_tails']=[]
            for tail in extras:
                if tail['num']>4:continue
                # These small LH tails turn back horizontally by 0.25 pt; keep the actual endpoint.
                if np.linalg.norm(np.array(co['last'])-np.array(tail['last']))<.008:
                    co['segments']+=tail['segments'];co['points']+=tail['points'];co['objects']+=tail['objects'];co['terminal']=tail['first'];co['extra_tails'].append(tail)
            pts=ch.to_data(co['points']);start=ch.to_data([co['first']])[0];end=ch.to_data([co['terminal']])[0]
            qr,hr,qm,hm=table[key][model];family='KTZ' if key.startswith('KTZ') else 'LH'
            hc=Chart.value_at(pts,qr);assert hc is not None,(d['short'],key,model,qr)
            points=[dict(kind='H đầu',Q=float(start[0]),H_table=hm,H_curve=float(start[1]),diff=float(start[1]-hm),limit=max(1,.02*abs(hm)),unit='m'),
                    dict(kind='Điểm định mức',Q=qr,H_table=hr,H_curve=hc,diff=float(hc-hr),limit=max(1,.02*abs(hr)),unit='m')]
            for r in points:r['ok']=abs(r['diff'])<=r['limit'];r.update(file=d['name'],page=c['page'],chart=c['label'],model=family+model,frequency=50 if '50' in key else 60)
            points += [dict(file=d['name'],page=c['page'],chart=c['label'],model=family+model,frequency=50 if '50' in key else 60,kind='Q cuối',Q=qm,H_table=None,H_curve=float(end[1]),Q_curve=float(end[0]),diff=float(end[0]-qm),limit=max(1,.02*abs(qm)),unit='m³/h',ok=bool(abs(end[0]-qm)<=max(1,.02*abs(qm))),note='Bảng không ghi H tại Q tối đa; H cuối chỉ đo từ nét nguồn, không dùng làm H bảng.')]
            rows+=points
            mapped.append(dict(file=d['name'],short=d['short'],page=c['page'],chart=c['label'],chart_rect=c['rect'],model=family+model,frequency=50 if '50' in key else 60,table=[qr,hr,qm,hm],start=start.tolist(),end=end.tolist(),max_q=float(pts[:,0].max()),points=pts.tolist(),objects=co['objects'],segments=co['segments'],axes=dict(ax=ch.ax,bx=ch.bx,ay=ch.ay,by=ch.by),checks=points,ok=all(r['ok'] for r in points),evidence=c['evidence']))
            if not all(r['ok'] for r in points):print(d['short'],family+model,key,[(r['kind'],round(r['diff'],3),r['limit']) for r in points if not r['ok']],flush=True)
        assert len(main)==len(order)
    print(d['short'],'đã đối chiếu',sum(m['short']==d['short'] for m in mapped),'đường',flush=True)
out=dict(time=datetime.datetime.now().astimezone().isoformat(),tables=table,curves=mapped,rows=rows,axes=axes_records,count_curves=len(mapped),pass_curves=sum(c['ok'] for c in mapped),count_rows=len(rows),pass_rows=sum(r['ok'] for r in rows),scope='H tối đa tại đầu gần Q=0, H tại Q định mức, Q cuối; H cuối và toàn bộ dãy Q-H không có trong bảng nên chưa xác minh độ đúng.')
output='DOI CHIEU LAN1.json' if tag=='LAN3' else f'DOI CHIEU {tag}.json'
Path(fresh(S.report('G09/DO DUONG/'+output))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('TOTAL',out['pass_curves'],'/',out['count_curves'],'đường;',out['pass_rows'],'/',out['count_rows'],'phép đo',flush=True)
