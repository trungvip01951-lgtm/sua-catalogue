from catwork import start, fresh
S,D,N = start()
from catfix import verify
from catfix.inspect_pdf import summary
from catfix.vector import Editor
from catfix.otext import OutlineText
from pathlib import Path
import json, hashlib

NAME='Aquaris bơm giếng SA 1_300dpi_75% (bản mới).pdf'
src=S.src(NAME)
root=Path(S.report('G03'))
root.mkdir(exist_ok=True)
print(summary(src), flush=True)
E=Editor(src); T=OutlineText(E)
all_lines={}
for pi in range(10):
    T.learn([pi], dpi=400, verbose=False)
    lines=[]
    for txt, gs in T.text_lines(pi):
        bbox=(min(g.bbox[0] for g in gs),min(g.bbox[1] for g in gs),max(g.bbox[2] for g in gs),max(g.bbox[3] for g in gs))
        lines.append(dict(text=txt,bbox=bbox,styles=sorted(set(g.style for g in gs),key=str)))
    all_lines[pi+1]=lines
    verify.crop(src,pi,E.mediabox(pi),150).save(fresh(root/f'nguon-p{pi+1}.png'))
    print(f'PAGE {pi+1}: {len(lines)} lines',flush=True)
json.dump(dict(src=src,sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),pages=all_lines),open(fresh(root/'inspection.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
E.close()
print(root)
