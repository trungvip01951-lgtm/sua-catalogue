"""While RAM is being built: inspect unchanged/ambiguous source regions numerically only."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,math
import numpy as np
from PIL import Image
from g01_wc_clip_math import parse,windall,intervals
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 KIEM ANH RAM DOC LAP'))
V5=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 DU LIEU HINH HOC/g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(V5)=='8fabfa4986246865c6e0931cb4e63881326e58358aa099bfcb6ffb47a108c4fa'
d=json.loads(V5.read_text(encoding='utf8'));base=json.loads(Path(d['base_geometry_file']).read_text(encoding='utf8'))
assert sha(d['base_geometry_file'])==d['base_geometry_sha256']
source_image={g['group']:np.array(Image.open(g['source_JPEG']).convert('RGB')) for g in d['groups']}
old={g['group']:[parse(q) for q in g['combined_clip_subpaths']] for g in base['groups']}
pol={g['group']:[parse(q) for q in g['combined_clip_subpaths']] for g in d['groups']}
specs=[
 (1,'quai trái nhỏ còn mờ',[149,162,160,176],[[149,166],[150,168],[155,166],[157,168]],'01 QUAI COUPLING CHAN NGUON.png','Ít pixel; nguồn ở rìa có pha nước/màu và khoảng sáng bên trong quai. V5 thu mực xa x145–148; không suy hình lỗ mới ở phần x149 trở vào.'),
 (1,'quai phải nhỏ',[182,163,194,175],[[184,165],[188,168],[190,172]],'01 QUAI COUPLING CHAN NGUON.png','Quai và khoảng trong quá ít pixel, giữ nguyên nguồn; không khoét theo màu trắng/xám.'),
 (1,'lỗ/vùng lõm khớp nối',[108,255,128,287],[[117,263],[119,268],[118,272],[121,277]],'01 QUAI COUPLING CHAN NGUON.png','Không phân biệt chắc lỗ xuyên với mặt lõm tối. Giữ nguyên toàn vùng nguồn. Khớp nối là phần nối giữa ống và bơm.'),
 (2,'vùng trắng dưới đỉnh quai',[540,110,595,175],[[553,135],[561,144],[569,151]],'04 QUAI DINH NGUON.png','Nét kim loại sáng, khoảng trắng/pha màu và bóng ở đỉnh quai; ROI khảo sát bao vùng, chưa gán mọi điểm sáng là nền.'),
 (2,'chi tiết rời trắng và khe/tâm xám',[61,611,254,802],[[111,656],[152,684],[170,711],[91,693]],'04 CHI TIET ROI DUOI NGUON.png','Phần trắng rõ nhưng tâm/khe xám có thể là bóng, mặt kim loại hoặc nền xuyên qua. Giữ pixel gốc bên trong, không tạo các lỗ theo ngưỡng màu.'),
 (2,'bóng mềm quanh chi tiết rời phía trên',[50,313,253,544],[[54,383],[111,359],[236,443]],None,'Có bóng đổ mềm; biên chưa phân biệt hết nền với phản quang. Đường V5 ở đây không đổi.'),
 (3,'quai dây sáng bơm trái',[192,365,315,513],[[201,443],[206,375],[287,456],[201,506]],'06 QUAI BOM TRAI NGUON.png','Quai dây mảnh và mờ do JPEG; giữ cùng vòng nguồn. Không suy dây phải liền ở mọi pixel hay dựng bù đoạn sáng.'),
 (3,'quai dây sáng động cơ phải',[633,20,762,188],[[649,48],[698,44],[741,139],[651,167]],'06 QUAI BOM PHAI NGUON.png','Nét sáng/viền chống răng cưa mờ; giữ nguồn và khe đã xác minh, không thu bằng ngưỡng xám.'),
 (3,'đầu trục dưới động cơ phải',[675,640,704,681],[[686,663],[690,674],[694,679]],None,'Biên đầu trục mờ; V5 không thay vùng này. Không đọc chắc cấu tạo cực nhỏ nên giữ nguyên.'),
 (3,'chi tiết rời giữa và phần tâm tối',[607,696,775,797],[[707,699],[672,747],[725,779]],'06 KHE GIUA HAI CHI TIET PHAI NGUON.png','Biên sáng và tâm tối còn nguyên; không phân loại thêm thành lỗ xuyên hoặc nền. Khe y798 vẫn là khoảng thật giữa hai cụm.'),
 (3,'mép xanh quanh khe chân và mép vỏ',[616,974,664,1040],[[619,1000],[647,1039],[630,1030],[640,1000]],None,'Có mực xanh ngay rìa nguyên vật liệu/khung trong ảnh nguồn. Giữ lớp điểm ảnh gốc khi không tách chắc; khác các cục nước ngoài thân đã thu ở V5.')
]
items=[]
for num,title,bb,points,crop,note in specs:
    x0,y0,x1,y1=bb;rowcounts=[];change=0
    for y in range(y0,y1):
        xx=np.arange(x0,x1,dtype=float)+.5;t=np.column_stack([xx,np.full_like(xx,y+.5)])
        a=windall(old[num],t)!=0;b=windall(pol[num],t)!=0;z=int(np.sum(a!=b));change+=z
        if z:rowcounts.append({'y':y,'different_pixel_centers':z})
    pts=[]
    for x,y in points:
        n=source_image[num];neigh=[]
        for yy in range(y-1,y+2):
            for xx in range(x-1,x+2):neigh.append({'x':xx,'y':yy,'RGB':n[yy,xx].tolist()})
        center=[x+.5,y+.5]
        pts.append({'source_pixel':[x,y],'source_RGB':n[y,x].tolist(),'neighbors3x3_read_only':neigh,'V4B_winding_at_center':int(windall(old[num],[center])[0]),'V5_winding_at_center':int(windall(pol[num],[center])[0]),'material_or_background_auto_classification':False})
    cf=HERE/'wc_clip_source_du_lieu_20261003'/crop if crop else None
    items.append({'group':num,'region':title,'ROI_source_pixel_halfopen':bb,'source_JPEG':d['groups'][num-1]['source_JPEG'],'source_JPEG_sha256':d['groups'][num-1]['source_JPEG_sha256'],'original_existing_crop_seen':str(cf) if cf else None,'existing_crop_sha256':sha(cf) if cf else None,'pixel_profiles':pts,'V4B_V5_geometry_differences_in_ROI_at_pixel_centers':change,'different_rows':rowcounts,'source_visual_observation':note,'status_of_complete_boundary_separation':'CHƯA THỂ XÁC MINH','not_a_color_mask':True})
for g in d['groups']:assert sha(g['source_JPEG'])==g['source_JPEG_sha256']
name='Catalog cắt rác perotac (bản mới).pdf'
assert sha(S.src(name))==d['source_PDF_sha256'] and sha(S.dst(name))==d['canonical_untouched_sha256']
fp=Path(fresh(O/'g01_01_MEP MO NGUON DOC TRUOC KHI CO RAM V5.json'))
fp.write_text(json.dumps({'V5_geometry_sha256':sha(V5),'source_regions_read':items,'RAM_V5_status':'Chưa có thư mục ảnh ở lúc đọc; chưa kết luận hình ghép V5','source_RGB_modified':False,'RGB_threshold_mask_created':False,'image_or_PDF_written':False,'TIEN_DO_written':False,'instruction':'Giữ tệp clip8fab…; chỉ ghi hồ sơ đọc nguồn, không đổi hình học.'},ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',fp,'SHA',sha(fp),flush=True)
print('REGIONS',[(q['group'],q['region'],q['V4B_V5_geometry_differences_in_ROI_at_pixel_centers']) for q in items],flush=True)
