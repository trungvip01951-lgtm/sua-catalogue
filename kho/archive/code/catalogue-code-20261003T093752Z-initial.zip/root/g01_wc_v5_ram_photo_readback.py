"""Read the existing V5 RAM PNGs only, no renderer/product raster creation or PDF write."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib,math,csv
import numpy as np
from PIL import Image
import fitz
O=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 KIEM ANH RAM DOC LAP'))
ROOT=Path(r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-wc-perotac-kiem-duong\outputs')
RAM=ROOT/'per_wc_continue_photo_union_v5_RAM_a1'
V4=ROOT/'per_wc_continue_photo_union_v4B_RAM_a1'
V5=Path(S.report('G08/ROOT KIEM DOC LAP DUONG CAT ANH NGUON V4B/g01_V5 DU LIEU HINH HOC/g01_BA NHOM DUONG CAT PDF NGUON V5 CHO RAM.json'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(V5)=='8fabfa4986246865c6e0931cb4e63881326e58358aa099bfcb6ffb47a108c4fa'
d=json.loads(V5.read_text(encoding='utf8'))
files=list(RAM.glob('*manifest.json'));assert len(files)==1,'RAM manifest not ready or ambiguous'
mf=files[0];manifest=json.loads(mf.read_text(encoding='utf8'));checks=[]
for f in manifest['files']:
    p=RAM/f['file'];h=sha(p);b=p.stat().st_size
    checks.append({'path':str(p),'SHA_read':h,'SHA_manifest':f['sha256'],'bytes_read':b,'bytes_manifest':f['bytes'],'match':h==f['sha256'] and b==f['bytes']})
assert all(q['match'] for q in checks) and not list(RAM.glob('*.pdf'))
src=Path(S.src('Catalog cắt rác perotac (bản mới).pdf'));can=Path(S.dst('Catalog cắt rác perotac (bản mới).pdf'))
assert sha(src)==d['source_PDF_sha256'] and sha(can)==d['canonical_untouched_sha256']
pre=json.loads(next(V4.glob('*preflight.json')).read_text(encoding='utf8'))
def findphoto(folder,group,page,kind,dpi):
    ps=list(folder.glob(f'*group{group}_p{page:02d}_{kind}_{dpi}dpi.png'));assert len(ps)==1,ps;return ps[0]
actual=[];probes=[]
doc=fitz.open(src)
for g in d['groups']:
    num=g['group'];page=g['pages'][0];w,h=g['source_canvas_pixel'];job=next(j for j in pre['jobs8'] if j['page']==page)
    rect=job['allowed_photo_rect_top_fixed_before_RAM'];native=doc[page-1]
    match=[]
    for inf in native.get_image_info(xrefs=True):
        if inf['width']==w and inf['height']==h:
            bs=doc.extract_image(inf['xref'])['image']
            if hashlib.sha256(bs).hexdigest()==g['source_JPEG_sha256']:match.append(inf)
    assert len(match)==1
    transform=match[0]['transform'];a,b,c,e,tx,ty=transform
    def mapped(x,y,dpi):
        scale=dpi/72;px=a*x/w+c*y/h+tx;py=b*x/w+e*y/h+ty
        return px*scale-math.floor(rect[0]*scale),py*scale-math.floor(rect[1]*scale)
    rec={'group':num,'representative_page':page,'source_transform_top':transform,'photo_crop_rect_top':rect,'photo_PNGs':[],'V4B_vs_V5_pixels':[]}
    for dpi in (150,600):
        pold=findphoto(V4,num,page,'RAM_photo',dpi);pnew=findphoto(RAM,num,page,'RAM_photo',dpi);before4=findphoto(V4,num,page,'before_photo',dpi);before5=findphoto(RAM,num,page,'before_photo',dpi)
        imgold=Image.open(pold).convert('RGB');imgnew=Image.open(pnew).convert('RGB');assert imgold.size==imgnew.size
        aa=np.array(imgold);bb=np.array(imgnew);ch=np.any(aa!=bb,axis=2);allowed=np.zeros(ch.shape,dtype=bool)
        for edit in g['V5_edits']:
            x0,y0,x1,y1=edit['changed_bbox_source_pixel'];corners=[mapped(x,y,dpi) for x,y in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]]
            lo=np.floor(np.min(corners,axis=0)-2).astype(int);hi=np.ceil(np.max(corners,axis=0)+2).astype(int)
            allowed[max(0,lo[1]):min(ch.shape[0],hi[1]),max(0,lo[0]):min(ch.shape[1],hi[0])]=True
        out=int(np.sum(ch&~allowed))
        if np.any(ch):
            ys,xs=np.nonzero(ch);cb=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]
        else:cb=None
        before_equal=Image.open(before4).size==Image.open(before5).size and bool(np.array_equal(np.array(Image.open(before4)),np.array(Image.open(before5))))
        rec['V4B_vs_V5_pixels'].append({'dpi':dpi,'size':list(imgnew.size),'changed_pixels_threshold0':int(np.sum(ch)),'changed_pixel_bbox_halfopen':cb,'outside8_source_change_envelopes_with2_render_pixel_pad':out,'before_photo_exact_pixels_equal':before_equal})
        rec['photo_PNGs'].extend([{'file':str(pnew),'dpi':dpi,'type':'RAM_photo','SHA':sha(pnew)},{'file':str(before5),'dpi':dpi,'type':'before_photo','SHA':sha(before5)}])
        for q in d['additional_water_and_metal_witnesses']:
            if q['group']!=num:continue
            x,y=q['point_source_pixel'];u,v=mapped(x,y,dpi);ix=int(round(u-.5));iy=int(round(v-.5))
            assert 0<=ix<bb.shape[1] and 0<=iy<bb.shape[0]
            same=bool(np.array_equal(aa[iy,ix],bb[iy,ix]));probes.append({'group':num,'page':page,'dpi':dpi,'label':q['label'],'kind':q['kind'],'source_center':[x,y],'PNG_nearest_pixel':[ix,iy],'V4B_RGB':aa[iy,ix].tolist(),'V5_RGB':bb[iy,ix].tolist(),'equal_V4B_V5':same,'winding_old':q['winding_V4B'],'winding_V5':q['winding_V5'],'geometric_pass':q['result'],'visual_classification':'Inspect actual image; RGB change alone not a background/material classification.'})
    whole=findphoto(RAM,num,page,'RAM_whole_page',150);rec['whole_page150']={'file':str(whole),'SHA':sha(whole),'size':list(Image.open(whole).size)}
    actual.append(rec)
doc.close()
assert sha(src)==d['source_PDF_sha256'] and sha(can)==d['canonical_untouched_sha256']
assert sha(V5)=='8fabfa4986246865c6e0931cb4e63881326e58358aa099bfcb6ffb47a108c4fa'
result={'geometry_file':str(V5),'geometry_SHA':sha(V5),'RAM_manifest':str(mf),'RAM_manifest_SHA':sha(mf),'state_manifest':manifest['state'],'manifest_files':checks,'all_manifest_identities_match':True,'actual_photos':actual,'actual_PNG_point_probes':probes,'source_PDF_SHA_read':sha(src),'canonical_PDF_SHA_read':sha(can),'native_PDF_RAM_independent_read':'Không có PDF RAM trên đĩa; không coi báo cáo metadata từ tác nhân là đọc độc lập byte PDF','visual_result':'Chưa chốt ở mã đọc: phải mở 3 nhóm150/600 + toàn trang và đối chiếu nguồn/V4B/V5','no_image_or_PDF_written':True,'no_geometry_changes':True,'no_TIENDO_written':True}
fp=Path(fresh(O/'g01_02_DOC PNG RAM V5 THAT VA TOA DO8 DOAN.json'));fp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('SAVED',fp,'SHA',sha(fp),flush=True)
print('PHOTOS',[(x['group'],x['V4B_vs_V5_pixels']) for x in actual],flush=True)
print('POINTS',len(probes),'WATER_NEWLY_EXCLUDED600',sum(x['kind']=='added_exclude_water' and x['winding_old']!=0 and x['dpi']==600 and not x['equal_V4B_V5'] for x in probes),'METAL_KEPT_EQUAL600',sum(x['kind']=='added_keep_metal' and x['dpi']==600 and x['equal_V4B_V5'] for x in probes),flush=True)
