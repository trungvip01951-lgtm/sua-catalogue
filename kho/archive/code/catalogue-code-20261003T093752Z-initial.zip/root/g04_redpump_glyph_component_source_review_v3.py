"""Explicitly review all discarded source glyph components; no assumptions from size."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));d=json.loads((root/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'));p=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17 V2.json').read_text(encoding='utf8'));src=d['source'];cur=p['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cache={};records=[];pic=Image.new('RGB',(1250,12*120),'white');dr=ImageDraw.Draw(pic);colors=np.array([[220,40,40],[40,180,40],[40,70,230],[200,40,200],[230,120,20]])
for i,z in enumerate(d['records']):
 key=(z['source_page'],tuple(z['source_canvas_rect']))
 if key not in cache:cache[key]=R.render_canvas(z['source_page']-1,z['source_canvas_rect'],dpi=600)
 cv=cache[key];x0,y0,x1,y1=z['source_render_box'];allrgb=cv.orig.astype(float);allg=allrgb@np.array([.299,.587,.114]);bg=np.array(z['source_background_gray_by_row']);a=np.clip((bg[:,None]-allg[y0:y1,x0:x1])/np.maximum(bg[:,None],1),0,1);comp,n=label(a>.085);cc=[];cimg=np.ones((y1-y0,x1-x0,3),dtype='uint8')*255
 for k in range(1,n+1):
  yy,xx=np.nonzero(comp==k);cc.append(dict(component=k,area_px=len(xx),glyph_box600=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],kept_in_bankV3=k in z['source_components_kept'],alpha_min=float(a[comp==k].min()),alpha_max=float(a[comp==k].max())));cimg[comp==k]=colors[(k-1)%len(colors)]
 raw=Image.fromarray(allrgb[y0:y1,x0:x1].round().astype('uint8'));dr.text((5,i*120+6),z['character']+' '+z['source_word'],fill='blue');pic.paste(raw.resize((raw.width*3,raw.height*3),Image.Resampling.NEAREST),(240,i*120));pic.paste(Image.fromarray(cimg).resize((raw.width*3,raw.height*3),Image.Resampling.NEAREST),(380,i*120));dr.text((540,i*120+12),str([{k:v for k,v in q.items() if k not in ['alpha_min','alpha_max']} for q in cc]),fill='black')
 records.append(dict(character=z['character'],source_page=z['source_page'],source_word=z['source_word'],source_render_box=z['source_render_box'],source_page_box=z['source_page_box'],components=cc,raw_unmixed_alpha=a.tolist()))
photo=fresh(root/'DOI CHIEU MUC BI LOAI MOI GLYPH V3.png');pic.save(photo);Path(fresh(root/'DOI CHIEU MUC BI LOAI MOI GLYPH V3.json')).write_text(json.dumps(dict(source_SHA256=before[0],current_SHA256=before[1],records=records,source_photo=photo,PDF_written=False,status='ĐỌC NGUỒN TỪNG PHẦN MỰC: không coi component lớn nhất tự động là đủ glyph.'),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print([(q['character'],[(r['area_px'],r['glyph_box600'],r['kept_in_bankV3']) for r in q['components']]) for q in records],flush=True)
