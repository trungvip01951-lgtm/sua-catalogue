"""Read full small-model words and native ink; no bank/PDF modification."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
folder=M/'CHU5 9 NGUON THAT NGUYEN CUM VA4 KY TU LAN2'
assert not folder.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
w=J(P/'CHU NGUON ALPHA THU DO DOC V2.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
E=Editor(b['source'],backend='fitz');R=Raster(E)
cv8=R.render_canvas(7,w['source_rect'],dpi=600)
cv5=R.render_canvas(4,(123,412,151,429),dpi=600)
recs=[]
for model,pi,cv,box in [('4SL16/25',7,cv8,next(z['source_render_rect'] for z in w['records'] if z['model']=='4SL16/25')),
    ('4SL16/9',7,cv8,next(z['source_render_rect'] for z in w['records'] if z['model']=='4SL16/9')),
    ('4SL3/35',4,cv5,[30,40,204,83])]:
    x0,y0,x1,y1=box;rgb=cv.orig[y0:y1,x0:x1].copy()
    bb=[*cv.to_page(x0,y1),*cv.to_page(x1,y0)]
    stem=model.replace('/','_')
    rawpng=fresh(folder/(stem+' NGUYEN CUM600 KHONG RETOUCH.png'))
    Image.fromarray(rgb).save(rawpng)
    native=fresh(folder/(stem+' NGUYEN CUM150 KHONG RETOUCH.png'))
    verify.crop(b['source'],pi,bb,150).save(native)
    pic=Image.fromarray(rgb).resize((rgb.shape[1]*5,rgb.shape[0]*5),Image.Resampling.NEAREST)
    canvas=Image.new('RGB',(pic.width+100,pic.height+50),'white');canvas.paste(pic,(60,35))
    dr=ImageDraw.Draw(canvas);ft=verify._font(14)
    for x in range(0,rgb.shape[1],10):
        dr.line((60+x*5,20,60+x*5,35),fill='blue')
        dr.text((60+x*5,2),str(x),fill='blue',font=ft)
    for y in range(0,rgb.shape[0],5):
        dr.line((45,35+y*5,60,35+y*5),fill='blue')
        dr.text((1,30+y*5),str(y),fill='blue',font=ft)
    gridpng=fresh(folder/(stem+' TOA DO600 5X CHI DAN NGOAI ANH.png'));canvas.save(gridpng)
    gray=rgb@np.array([.299,.587,.114])
    whole=cv.orig@np.array([.299,.587,.114]);bg=np.median(whole,axis=1)[y0:y1]
    aa=np.clip((bg[:,None]-gray)/np.maximum(bg[:,None],1),0,1)
    # Preserve every observed alpha sample; no connected-component removal.
    recs.append(dict(model=model,page=pi+1,source_request_rect=list(cv.rect0),source_render_box=box,
        source_page_box=bb,RGB=rgb.tolist(),alpha_all_source_samples=aa.tolist(),background_gray_by_row=bg.tolist(),
        source_RGB_SHA256=hashlib.sha256(rgb.tobytes()).hexdigest(),physical_scale=1,
        weak_gray_component_purge=False,source_images=[rawpng,native,gridpng],
        use_as_donor_status='CHƯA CHỐT; phải định vị từng glyph và so ít nhất4 ký tự chung, không dùng hộp đoán.'))
out=dict(source=b['source'],source_SHA256=guards[0],current_SHA256=guards[1],M1_SHA256=guards[2],
    records=recs,comparison_common_characters=['4','S','L','/'],no_source_pixel_change=True,
    alpha_is_black_ink_background_assumption=True,no_geometry_fit_yet=True,
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False)
fp=fresh(folder/'NGUYEN CUM NGUON VA TOA DO KHONG LOAI MEP XAM.json')
Path(fp).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print(fp,flush=True)
