from catwork import start,fresh
from pathlib import Path
import json,re
S,D,N=start()
from catfix.otext import robust_fit
j=S.job('KTZ - LH Perotac (bản mới).pdf');j.T.learn([0],dpi=450)
gs=j.T.page_glyphs(0);seq=[]
for w in j.T.ocr_words(0,rect=(79,600,531,706),dpi=450):
    text=w['text'];b=w['bbox']
    if not re.fullmatch('[A-Za-z]+',text):continue
    gl=sorted([g for g in gs if b[0]-.55<=(g.bbox[0]+g.bbox[2])/2<=b[2]+.55 and b[1]-.8<=(g.bbox[1]+g.bbox[3])/2<=b[3]+.8],key=lambda g:g.bbox[0])
    if len(gl)!=len(text):continue
    seq.append(dict(chars=text,boxes=[g.bbox for g in gl]))
F=robust_fit(seq);print('n',F['n'],'rms',F['rms_x'],'max',F['max_x'],flush=True)
print('metrics',[(c,F['lsb'].get(c),F['adv'].get(c),F['bot'].get(c)) for c in 'eidts'],flush=True)
Path(fresh(S.report('G09/KHOANG CHU TU NGUON LAN2 Perotac.json'))).write_text(json.dumps(F,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
j.close()
