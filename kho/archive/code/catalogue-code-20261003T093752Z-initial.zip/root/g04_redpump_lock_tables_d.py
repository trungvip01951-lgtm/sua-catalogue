"""Read Redpump p10/p11 source tables, never write catalogue PDFs."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'))
final=json.loads(Path(S.report('G04/REDPUMP NGHIEM THU BAN CUOI NET PDF.json')).read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
current=S.result(catalog['name'])
assert sha(catalog['source'])==catalog['source_SHA256'] and sha(current)==final['final_SHA256']
groups=[
 (10,'6SL15',[0,3,6,9,12,15,18,21],[(5,[72,70,68,63,56,48,36,18]),(7,[101,99,95,88,78,67,51,25]),(9,[129,127,122,113,100,86,66,32]),(12,[173,169,162,150,134,114,88,42]),(15,[216,211,203,188,167,143,109,53]),(18,[259,254,243,225,200,171,131,63]),(21,[302,296,284,263,234,200,153,74]),(24,[345,338,324,300,267,228,175,84])]),
 (10,'6SL25',[0,3,6,9,12,15,18,21,24,27,30,33],[(3,[45,45,45,44,42,40,38,33,28,22,16,9]),(4,[60,60,60,58,56,54,50,45,39,30,21,12]),(6,[90,90,89,88,85,81,76,66,58,45,32,18]),(8,[120,120,119,117,113,108,101,89,78,60,43,24]),(10,[150,150,149,146,141,135,126,111,97,75,55,30]),(12,[179,180,179,175,169,162,151,134,117,90,65,36]),(14,[209,210,209,204,197,189,176,156,136,105,76,42]),(16,[239,240,238,234,226,216,202,178,156,120,87,48]),(18,[269,270,268,263,254,243,227,201,176,135,98,54]),(20,[299,300,298,292,282,270,252,223,195,150,109,60])]),
 (11,'6SL35',[0,5,10,15,20,25,30,35,40,45],[(3,[44,43,41,39,37,34,30,25,18,9]),(4,[59,57,54,52,49,45,40,33,24,12]),(6,[88,86,82,78,73,67,60,50,36,18]),(7,[103,100,95,91,85,78,70,58,42,21]),(8,[118,114,109,104,98,90,80,66,48,24]),(10,[147,143,136,130,122,112,100,83,60,30]),(12,[176,171,163,155,146,134,120,100,72,36]),(14,[206,200,190,181,171,157,140,116,84,42]),(16,[235,228,218,207,195,179,160,133,96,48]),(18,[265,257,245,233,220,202,180,149,108,54]),(20,[294,285,272,259,244,224,200,166,120,60])]),
 (11,'6SL45',[0,6,12,18,24,30,36,42,48,54],[(2,[28,27,25,23,22,20,18,15,12,8]),(3,[42,40,38,35,33,30,27,23,18,11]),(4,[56,53,50,47,43,39,35,31,25,15]),(5,[70,67,63,58,54,49,44,39,31,19]),(6,[84,80,75,70,65,59,53,46,37,23]),(7,[98,93,88,82,76,69,62,54,43,27]),(8,[113,107,100,93,87,79,71,62,49,30]),(9,[127,120,113,105,98,89,80,70,55,34]),(11,[155,147,138,128,120,109,98,85,67,42]),(13,[183,173,163,152,141,128,115,101,80,49]),(15,[211,200,188,175,163,148,133,116,92,57])]),
]
rows=[]
for page,family,q,series in groups:
 photo=root/f'BANG NGUON {page:02} {family}.png'
 assert photo.exists()
 for suffix,h in series:
  assert len(q)==len(h)
  rows.append(dict(page=page,family=family,model=f'{family}/{suffix}',Q=q,H=h,Q_unit='m³/h',H_unit='m',table_photo=str(photo),table_photo_SHA256=sha(photo),source_file=catalog['source'],source_file_SHA256=catalog['source_SHA256'],table_read='Đọc trực tiếp từng ô ảnh riêng Redpump; 6SL25/6 tại Q21=66 được soi lại bảng toàn vùng, không chép bản đọc nháp68',curve_acceptance='CHƯA ĐO',identity_basis='Bảng và nhãn bản giao Redpump; tiêu đề trang11 #45 đã sửa và nghiệm thu riêng, không gán theo tiêu đề sai của nguồn',ambiguous_cells=[]))
out=dict(name=catalog['name'],source_SHA256=catalog['source_SHA256'],current_SHA256=sha(current),batch='D',model_rows=len(rows),H_cells=sum(len(z['H']) for z in rows),H_cells_read=sum(x is not None for z in rows for x in z['H']),rows=rows,catalogue_written=False,curve_numeric_acceptance_for_new_rows=False)
Path(fresh(root/'BANG SO DA DOC TRUC TIEP D.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
assert sha(catalog['source'])==catalog['source_SHA256'] and sha(current)==final['final_SHA256']
print('Redpump D',len(rows),'rows',out['H_cells_read'],'source H cells; new curves not measured',flush=True)
