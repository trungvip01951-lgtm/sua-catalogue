"""CATFIX serialization and actual in-memory rendering. ZERO PDF file saves."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from io import BytesIO
from PIL import Image
import numpy as np
import json, hashlib
import pymupdf as fitz
import pikepdf
from scipy import ndimage
from catfix.cs import parse
from catfix.vector import VPage
from g04_perotac_whole_clip_builder47 import prepare, memory_bytes, NAME, RAM_REL
from g04_perotac_whole_pdf_tools46 import read, sha, pixel_at
from g04_perotac_whole_actual_read50 import render_document, outside_read, metadata, image_resources, actual_paths_and_ink

root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAM CATFIX CLIP V1 CHUA LUU PDF'))
ed,R,cv,content,only_clip,report=prepare(S)
ram=read(S.report(RAM_REL))
clip_blob=memory_bytes(ed,only_clip);final_blob=memory_bytes(ed,content)
report['serialized_memory_sha256']=hashlib.sha256(final_blob).hexdigest()
report['serialized_memory_bytes']=len(final_blob)
assert sha(S.src(NAME))==report['source_sha256'] and sha(S.result(NAME))==report['canonical_sha256']
with fitz.open(S.result(NAME)) as before,fitz.open(stream=clip_blob,filetype='pdf') as clipped,fitz.open(stream=final_blob,filetype='pdf') as actual:
    roi=report['ROI_page_pt'];mb=ed.mediabox(7)
    ar600,mapping=render_document(actual,7,600,roi)
    ar150,_=render_document(actual,7,150)
    ar200,m200=render_document(clipped,7,200)
    Image.fromarray(ar600).save(fresh(root/'PEROTAC P08 RAM CATFIX THAT600 CHU TRUC CHUA DAT.png'))
    Image.fromarray(ar150).save(fresh(root/'PEROTAC P08 TOAN TRANG RAM CATFIX150 CHU TRUC CHUA DAT.png'))
    blank150,_=render_document(clipped,7,150)
    Image.fromarray(blank150).save(fresh(root/'PEROTAC P08 CHI CLIP MUC CU RAM150.png'))
    outside_final=outside_read(before,actual,roi,dpi=200)
    outside_clipped=outside_read(before,clipped,roi,dpi=200)
    meta0=metadata(before);meta1=metadata(actual)
    meta_equal={key:meta0[key]==meta1[key] for key in meta0}
    title_native=[571,192,659,214]
    title_box=list(cv.rect(title_native))
    title0,_=render_document(before,7,600,title_box);title1,_=render_document(actual,7,600,title_box)
    assert title0.shape==title1.shape
    title_changed=int(np.any(title0!=title1,axis=2).sum())
    # Sample centers of every interior source-native pixel after clipping only.
    x0,y0,x1,y1=report['source_native_edit_box'];u,v=np.meshgrid(np.arange(x0+1,x1-1)+.5,np.arange(y0+1,y1-1)+.5)
    image_point=np.stack([u,v],axis=-1);page=np.array([cv.to_page(float(x),float(y)) for x,y in image_point.reshape(-1,2)])
    pixel=np.array([pixel_at(point,m200) for point in page])
    colors=np.array([ndimage.map_coordinates(ar200[:,:,k].astype(float),[pixel[:,1]-.5,pixel[:,0]-.5],order=1,mode='constant',cval=255) for k in range(3)]).T
    island=report['source_title_native_box'];native_flat=image_point.reshape(-1,2)
    safe=~((native_flat[:,0]>=island[0]-1)&(native_flat[:,0]<=island[2]+1)&(native_flat[:,1]>=island[1]-1)&(native_flat[:,1]<=island[3]+1))
    blank_wrong=np.any(abs(colors[safe]-255)>1e-7,axis=1)
    blank_check=dict(native_pixel_centers_checked=int(safe.sum()),nonwhite_native_centers=int(blank_wrong.sum()),
        max_white_difference=float(abs(colors[safe]-255).max()),title_island_and_one_pixel_edge_excluded=True,
        read_from_serialized_CATFIX_clip_only_render=True,source_clear_has_no_white_paint_or_new_image=True)
    actual_read=actual_paths_and_ink(actual[7].read_contents(),report,ram,cv,ar600,mapping)
    serialized_native=actual[7].read_contents()
    assert serialized_native==content
    P=VPage(parse(serialized_native));ctm_rows=[]
    for clip in report['old_Do_complement_clips']:
        before_images=ed.page(7).images
        old=next(i for i in before_images if i['i']==clip['original_Do_index'])
        hits=[i for i in P.images if i['name']==old['name'] and np.max(abs(i['ctm']-old['ctm']))<1e-9]
        ctm_rows.append(dict(name=old['name'],same_CTM_matches=len(hits),original_CTMs_preserved=len(hits)==1))
with pikepdf.open(S.result(NAME)) as before,pikepdf.open(BytesIO(final_blob)) as actual:
    resources_before=image_resources(before);resources_after=image_resources(actual)
    resources_equal=resources_before==resources_after
    gs=actual.pages[7].Resources.ExtGState['/'+report['new_normal_opaque_gs']]
    opaque={k:str(gs.get('/'+k)) for k in ['CA','ca','BM','SMask']}
    page_content_equal=[before.pages[i].Contents.read_bytes()==actual.pages[i].Contents.read_bytes() for i in range(11) if i!=7]
summary=dict(clip_method_no_cover=True,filesystem_PDF_save_count=0,
    outside_200dpi_threshold0_pad0_all11=outside_final,clip_only_outside_200dpi_threshold0_pad0=outside_clipped,
    current_Info_XMP_links_bookmarks_boxes_fonts_native_text_equal=meta_equal,
    all_current_raw_images_and_SMask_resource_values_equal=resources_equal,all_current_Do_CTM_checks=ctm_rows,
    other10_pages_content_bytes_equal=all(page_content_equal),source_title_glyph_pixels600_changed=title_changed,
    clip_only_source_native_clear_check=blank_check,new_explicit_opaque_gs=opaque,
    actual_serialized_memory_content_exact=serialized_native==content,
    actual_path_and_visible104=actual_read['all104_path_and_visible_points_match'],
    actual_named_objects_style_match=actual_read['all_named_new_objects_match'],
    glyph_axis_field_graphic_FAILURES_from_review_still_unrepaired=True,
    saved_PDF_actual_QA_status='CHƯA CHẠY',ROOT_and_graphic_actual_RAM_review_pending=True,
    source_and_canonical_unchanged=True,no_progress_written=True)
report.update(actual_serialized_RAM_checks=summary,actual_path_and_ink_readback=actual_read,
    prior_RAM_V3_axis_zero_M3_percent_FAIL_still_blocks_M1=True,
    old_white_SMask_preparation_rejected_not_run=True)
Path(fresh(root/'CATFIX CLIP RAM V1 DOC LAI MUC THAT VA NGOAI VUNG.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
Path(fresh(root/'LENH CATFIX TRANG08 CLIP KHONG CHE TRANG.txt')).write_bytes(content)
assert sha(S.src(NAME))==report['source_sha256'] and sha(S.result(NAME))==report['canonical_sha256']
ed.close()
compact={k:v for k,v in summary.items() if k not in ['outside_200dpi_threshold0_pad0_all11','clip_only_outside_200dpi_threshold0_pad0','all_current_Do_CTM_checks']}
print(json.dumps(compact,ensure_ascii=False),flush=True)
print('OUTSIDE FINAL',[(r['page'],r.get('outside_changed_pixels')) for r in outside_final],flush=True)
print('13WIDTH+ETA',[(r['model'],r['normal_sections'],r['median_equivalent_width_pt'],r['within_model_max_width_delta_from_median_percent'],r['max_10_90_transition_600px']) for r in actual_read['actual_style_summary']],flush=True)
