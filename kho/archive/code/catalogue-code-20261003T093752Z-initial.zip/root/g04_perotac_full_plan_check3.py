"""Kế hoạch V3: khóa vạch thật và kiểm nội suy/dash/nhãn bằng số, chưa vẽ."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from scipy.interpolate import PchipInterpolator
from scipy.integrate import quad
from scipy.optimize import brentq
import numpy as np,json,hashlib

name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
folder=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
load=lambda f:json.loads((folder/f).read_text(encoding='utf8'))
plan=load('PHUONG AN DONG BO P08 DE ROOT KIEM V2.json')
geo=load('KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)==plan['source_sha256'] and sha(current)==plan['current_sha256']
plan['stage']='CHỈ KẾ HOẠCH V3 — VẠCH THẬT ĐÃ KHÓA; CHỜ ROOT, CHƯA MẪU'
plan['planned_layout']['eta_panel_native_box']=geo['source_eta_frame_native_box']
plan['styles']['grid']['vertical_native_u']=[z['native_center'] for z in geo['main_observed_vertical_lines']]
plan['styles']['grid']['horizontal_native_v']=[z['native_center'] for z in geo['main_observed_horizontal_lines']]
plan['styles']['eta_grid']=dict(RGB=[225,225,225],width_pt=.25,opacity=1.0,
                              horizontal_native_v=[z['native_center'] for z in geo['source_eta_horizontal_lines']],
                              vertical_native_u=[z['native_center'] for z in geo['source_eta_vertical_lines']],
                              every_grid_position_from_own_source_ink=True)
plan['styles']['title_frame']=dict(native_rect=[geo['source_title_left_native_u'],geo['main_observed_horizontal_lines'][0]['native_center'],geo['main_observed_vertical_lines'][-1]['native_center'],geo['source_title_bottom_native_v']],
                                 RGB=[93,93,93],width_pt=.55,opacity=1.0)
step=load('MAU NET CHU ETA VA NOI SUY CHI DO NGUON.json')['source_pixel_to_page_pt']
qu=plan['source_axis']['calibration']['u_per_l_min']*1000/60*step
hv=abs(plan['source_axis']['H_grid_calibration']['v_per_m'])*step
period=plan['styles']['dash']['period_pt'];dash=plan['styles']['dash']['length_pt'];solid_s=plan['styles']['dash']['solid_arc_start_pt']
min_clear=[];values=[]
for row in plan['rows']:
    q=np.array(row['source_Q_m3_h'],float);h=np.array(row['source_H_m'],float);p=PchipInterpolator(q,h,extrapolate=False);dp=p.derivative()
    speed=lambda x:float(np.hypot(qu,hv*dp(x)))
    arc=lambda x:quad(speed,float(q[0]),float(x),points=[z for z in q[1:-1] if z<x],epsabs=1e-9,epsrel=1e-10)[0]
    total=arc(q[-1]);assert solid_s<total
    solid_q=brentq(lambda x:arc(x)-solid_s,float(q[0]),float(q[-1]),xtol=1e-11)
    styles=[]
    for k in range(7):
        s0=k*period;s1=s0+dash
        q0=float(q[0]) if k==0 else brentq(lambda x:arc(x)-s0,float(q[0]),float(q[-1]),xtol=1e-11)
        q1=brentq(lambda x:arc(x)-s1,float(q[0]),float(q[-1]),xtol=1e-11)
        styles.append(dict(Q_start=q0,Q_end=q1,source_pattern_length_pt=dash,actual_planning_arc_length_pt=arc(q1)-arc(q0)))
    nodes=[]
    for x,y in zip(q,h):
        s=arc(x);visible=(s>=solid_s) or (s%period<=dash+1e-8)
        nodes.append(dict(Q_m3_h=float(x),H_m=float(y),planning_arc_length_pt=s,planned_ink_present_at_node=bool(visible)))
    assert all(n['planned_ink_present_at_node'] for n in nodes),(row['model'],nodes)
    row['planned_explicit_dash_subpaths']=styles
    row['planned_solid_Q_start_m3_h']=solid_q
    row['planned_solid_native_u']=plan['source_axis']['calibration']['u_Q0']+solid_q*plan['source_axis']['calibration']['u_per_l_min']*1000/60
    row['planned_8_numeric_nodes_not_in_dash_gaps']=nodes
    # Keys live after numeric Q21; choose positions clear of both H grids.
    y=row['proposed_end_suffix_center_native'][1]
    nearest=min(abs(y-v) for v in plan['styles']['grid']['horizontal_native_v'])
    safe=(nearest-4.1)*step
    assert safe>=.5,(row['model'],safe)
    min_clear.append(dict(model=row['model'],planned_key_to_H_grid_min_margin_pt=safe,
                          geometric_only_actual_glyph_not_created=True))
    dense=np.linspace(0,21,2101);values.append(p(dense))
gaps=[dict(lower_model=plan['rows'][i]['model'],upper_model=plan['rows'][i+1]['model'],
           minimum_planned_H_separation_m=float(np.min(values[i+1]-values[i]))) for i in range(12)]
assert all(z['minimum_planned_H_separation_m']>0 for z in gaps)
plan['planning_checks']=dict(
    numerical_13rows_104nodes=True,all8source_nodes_each_model_not_in_planned_dash_gaps=True,
    all_literal_starts_ends_respected=True,curve_no_crossing_in_numeric_plan=gaps,
    suffix_H_grid_margins=min_clear,eta_and_title_actual_source_coordinates_locked=True,
    PDF_or_new_glyph_not_created=True,not_actual_104_PDF_acceptance=True,
    source_and_current_hashes_unchanged=True)
plan['source_coordinate_addendum']='KHOA VACH ETA VA KHUNG TIEU DE NGUON THAT.json'
plan['eta_origin_limit']='Nguồn thấy nétη sát góc khung nhưng tâm màu rõ sớm nhất làu127,v674; không gán thêm giá trịη0. Trong mẫu phải kiểm góc không bị cảm giác hụt nét, nếu không bám được mực/cỡ gốc thì chưa đạt.'
Path(fresh(folder/'PHUONG AN DONG BO P08 DE ROOT KIEM V3.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Khóa kế hoạch V3 — Perotac trang 8

**V3 thay các tọa độ ước định của V2. Vẫn chỉ kế hoạch, chưa tạo PDF, glyph hay hình mẫu.** Đọc V3 cùng báo cáo V2 về 104 ô và cách lấy chữ; số máy bơm không đổi.

Đo lại trực tiếp mực X7:

| Phần | Tọa độ pixel nguồn thật |
|---|---|
| Khung η | x124,494..746; y584..676 |
| 8 hàng η | 584; 597; 610; 623; 637; 650; 663; 676 |
| 9 cột η | 124,494; 202; 280; 357,564; 435,445; 513; 591; 668; 746 |
| Khung tiêu đề4SA16 | trái479; đáy222; trên/phải cùng khung Q–H |
| Lưới Q–H | Hàng180,555;246;311;376;441;506;571,544. Cột124,494;202;280;357,564;435,457;513;591;668;746. |

Khung η trong V2 là y583..677, chỉ ước định: **không dùng khi vẽ**. Không thêm nhãn70% cho hàng trên584. Nhãn0/20/40/60% đọc từ nguồn riêng, không suy số chỉ từ thứ hạng hàng lưới.

Bộ nét đề nghị vẫn RGB127/145/150,0,90pt, độ đặc1, đầu phẳng/nối bo; lưới RGB225/0,25pt, khung RGB93/0,55pt. Chữ lấy từ chính Perotac, tỷ lệ1:1, không phông ngoài. Dựng biên glyph còn chưa được thử nên chưa nhận sắc nét/phông đạt.

Đã tính bảy đoạn đứt **theo chiều dài cung**7,26pt/khe2,94pt, pha0; đoạn thứ8 nối liền đến Q21 trong cùng đối tượng đường. Mỗi model cóQ chuyển liền riêng theo chiều dài cung, lưu đủ trongJSON. Cách này giữ một chu kỳ vật lý, không lấy các khe hụt JPEG làm nhịp mới và không chồng đường ở điểm chuyển. Cả104ô thật nằm trong phần có mực của kế hoạch, không rơi vào khe đứt. Đây là kiểm toán học, **chưa nghiệm thu104mốc mực PDF**.

Nội suy13hàng không giao nhau; khoảng cách nhỏ nhất giữa hai model kề nhau ghi bên dưới. Chỉ dùng thứ tự bảng để kiểm va chạm, không dùng thứ hạng ghép danh tính nét cũ. Tên/suffix/đường mới lấy cùng bản ghi bảng thật.

| Model dưới / trên | Khoảng cách H nhỏ nhất trong miền0..21(m) |
|---|---:|
'''
for z in gaps:md+='| '+z['lower_model']+' / '+z['upper_model']+' | '+f"{z['minimum_planned_H_separation_m']:.6f}"+' |\n'
md+='''
Các suffix đã bố trí tránh hàng441/506; biên dự kiến của chữ với lưới đều≥0,5pt. Phải đo lại từ glyph thực, không dùng khoảng cách tâm nhãn để thay nghiệm thu. Chú giải13tên nằm ngoài lưới ở khoảng trắng dưới trụcQ.

η chỉ được đọc hình mực, không bảng số. Tâm màu rõ sớm nhấtu127/v674 nằm sát góc khung; phải xem góc thật khi dựng mẫu, không tự gán thêmQ0/η0 để đạt số. Nếu có cảm giác hụt hoặc không bám mực nguồn thì mẫu chưa đạt.

Nguồn và canonical (bản giao hiện hành) giữ SHA. Không ghiTIEN DO.md. Cần ROOT và tác nhân đồ họa khóa phương án trước MẪU1; mẫu phải có đọc lại104ô trên đường và mực PDF thật, đủ13nhãn, nét/chữ/lưới/η đều sắc, kiểm ngoài vùng0pixel trên11trang. Sau2mẫu cùng phương pháp không đạt phải dừng.
'''
spaced={'tiêu đề4SA16':'tiêu đề 4SA16','trái479':'trái 479','đáy222':'đáy 222','nhãn70%':'nhãn 70%','hàng trên584':'hàng trên 584','cung**7':'cung** 7','pha0':'pha 0','thứ8':'thứ 8','cóQ':'có Q','trongJSON':'trong JSON','Cả104ô':'Cả 104 ô','104mốc':'104 mốc','suy13hàng':'suy 13 hàng','miền0':'miền 0','hàng441':'hàng 441','đều≥':'đều ≥','chú giải13tên':'chú giải 13 tên','Chú giải13tên':'Chú giải 13 tên','trụcQ':'trục Q','nhấtu127':'nhất u127','thêmQ0':'thêm Q0','ghiTIEN':'ghi TIEN','lại104ô':'lại 104 ô','đủ13nhãn':'đủ 13 nhãn','vùng0pixel':'vùng 0 pixel','trên11trang':'trên 11 trang','Sau2mẫu':'Sau 2 mẫu','độ đặc1':'độ đặc 1','tỷ lệ1':'tỷ lệ 1'}
for old,new in spaced.items():md=md.replace(old,new)
md+='\nSHA nguồn: '+sha(src)+'\n\nSHA bản giao: '+sha(current)+'\n'
Path(fresh(folder/'KHOA PHUONG AN V3 DE ROOT KIEM.md')).write_text(md,encoding='utf8')
print('PLANV3 VERIFIED 104 nodes ink in planned strokes; no crossings; eta actual',geo['source_eta_frame_native_box'],flush=True)
print('SOLID START',[(r['model'],round(r['planned_solid_Q_start_m3_h'],6)) for r in plan['rows']],flush=True)
print('MIN KEY GRID MARGIN PT',min(z['planned_key_to_H_grid_min_margin_pt'] for z in min_clear),flush=True)
