"""Manual complete source glyph boxes, one bank; no PDF sample or external font."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label,gaussian_filter,binary_fill_holes
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));words=json.loads((root/'CHU NGUON ALPHA THU DO DOC V2.json').read_text(encoding='utf8'));other=json.loads((root/'GLYPH TRANG4 VA5 TOA DO THUC.json').read_text(encoding='utf8'));nine=json.loads((root/'GLYPH9 NGUON TRANG4 NHAN4SL2_9 TOA DO.json').read_text(encoding='utf8'))
src=plan['method']['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[plan['method']['source_SHA256'],plan['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cv8=R.render_canvas(7,words['source_rect'],dpi=600);wmap={p['model']:p for p in words['records']};cv62=R.render_canvas(4,next(p for p in other['records'] if p['name']=='3 TU NHAN 4SL3_62')['rect'],dpi=600);cv35=R.render_canvas(4,next(p for p in other['records'] if p['name']=='5 TU NHAN 4SL3_35')['rect'],dpi=600);cv9=R.render_canvas(3,nine['rect'],dpi=600)
donors=[('4',5,'4SL3/62',cv62,[34,40,62,77]),('S',5,'4SL3/62',cv62,[60,40,90,77]),('L',5,'4SL3/62',cv62,[90,40,115,77]),('6',5,'4SL3/62',cv62,[152,40,176,77]),('3',5,'4SL3/62',cv62,[115,40,143,77]),('/',5,'4SL3/62',cv62,[144,40,153,77]),('2',5,'4SL3/62',cv62,[175,40,201,77]),('5',5,'4SL3/35',cv35,[176,44,199,80]),('0',8,'4SL16/20',cv8,[180,316,205,353]),('8',8,'4SL16/18',cv8,[180,433,205,466]),('9',4,'4SL2/9',cv9,[142,14,168,48])]
records=[];picture=Image.new('RGB',(1000,12*112),'white');dr=ImageDraw.Draw(picture)
for i,(ch,page,word,cv,box) in enumerate(donors):
 x0,y0,x1,y1=box;a=cv.orig[y0:y1,x0:x1].astype(float);g=a@np.array([.299,.587,.114]);mask=g<230;comp,n=label(mask);keep=np.zeros_like(mask)
 for k in range(1,n+1):
  m=comp==k
  if m.sum()>=4:keep|=m
 al=(1-g/255)*keep
 raw=Image.fromarray(a.round().astype('uint8'));clean=Image.fromarray((255*(1-al)).round().clip(0,255).astype('uint8')).convert('RGB')
 dr.text((5,i*112+6),ch+' from '+word,fill='blue');picture.paste(raw.resize((raw.width*2,raw.height*2),Image.Resampling.NEAREST),(240,i*112+10));picture.paste(clean.resize((clean.width*2,clean.height*2),Image.Resampling.NEAREST),(430,i*112+10))
 topology=[]
 for t in [.2,.25,.3,.35,.4]:
  b=np.pad(gaussian_filter(al,.8)>=t,1);_,holes=label(binary_fill_holes(b)&~b);_,parts=label(b);topology.append(dict(alpha_level=t,holes=int(holes),components=int(parts)))
 dr.text((650,i*112+25),str([(p['alpha_level'],p['holes'],p['components']) for p in topology]),fill='blue')
 pg=[*cv.to_page(x0,y1),*cv.to_page(x1,y0)];records.append(dict(character=ch,source_page=page,source_word=word,source_canvas_rect=list(cv.rect0),source_render_box=box,source_page_box=pg,source_alpha=al.tolist(),source_physical_box_size_pt=[(x1-x0)*72/600,(y1-y0)*72/600],scale=1.,font_donor='Nhãn biểuđồ nguyênCHÍNH Redpump',topology=topology))
 # '1' uses genuine full source flag/stem from p8, already manually inspected.
old=json.loads((root/'GLYPH THAT CUNG TRANG8 NGAN HANG UNG VIEN.json').read_text(encoding='utf8'));p=next(p for p in old['records'] if p['character']=='1');al=np.array(p['source_alpha']);bw=Image.fromarray((255*(1-al)).round().astype('uint8')).convert('RGB');dr.text((5,11*112+6),'1 from 4SL16/20',fill='blue');picture.paste(bw.resize((bw.width*2,bw.height*2),Image.Resampling.NEAREST),(430,11*112+10));records.append(dict(character='1',source_page=8,source_word='4SL16/20',source_page_box=p['source_page_glyph_box'],source_render_box=p['source_render_glyph_box'],source_canvas_rect=list(cv8.rect0),source_alpha=al.tolist(),source_physical_box_size_pt=[al.shape[1]*72/600,al.shape[0]*72/600],scale=1.,font_donor='Nhãn biểuđồ nguyênCHÍNH Redpump'))
photo=fresh(root/'GLYPH HOAN CHINH HOP NGUON THU CONG.png');picture.save(photo)
out=dict(source=src,source_SHA256=before[0],current_SHA256=before[1],records=records,source_proof_photo=photo,one_glyph_bank_for_all13_labels=True,source_pages=[4,5,8],physical_scale=1.,old_auto_alpha_banks_not_used=True,PDF_sample_written=False,new_font_used=False,status='GLYPH GỐC HỘP THỦ CÔNG: cầnROOT đọc mực/capheight/từngkýtự. Kếhoạchvectorcontour chưaáp vàoPDF.',uncertainty='Nguồn150dpi nén: sai sốbiênglyph ít nhất±0,24pt; cỡ donor khôngco/giãn. Chỉbiênmựcthật, khôngdùngfontngoài.')
Path(fresh(root/'GLYPH HOAN CHINH HOP NGUON THU CONG.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)]
print('Manual genuine-source whole boxes;12glyphs, onebank, noPDF',flush=True)
