from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g06_word_tools import grid_mask,word_piece,LABELS
from pathlib import Path
import json,numpy as np
root=Path(S.report('G06'));st=json.loads((root/'review'/'native-word-build-2.json').read_text(encoding='utf-8'))
points=json.loads((root/'review'/'native-word-edge-point-coordinates.json').read_text(encoding='utf-8'))
probe=json.loads((root/'review'/'word-copy-source-geometry.json').read_text(encoding='utf-8'));geo=json.loads((root/'geometry.json').read_text(encoding='utf-8'))
E=Editor(st['source']);R=Raster(E);cv=R.canvas(R.image_at(3,E.mediabox(3)));grid,_=grid_mask(cv,geo)
out=[]
for rec in points:
 if rec['row'] not in (5,13):continue
 rr=next(z for z in probe['rows'] if z['row']==rec['row']);ws=[w for w in rr['words'] if any(ch.isalpha() for ch in w['text'])]
 p=word_piece(cv,R,ws[0],rr['box'],grid,LABELS[rr['row']][0]);x0,y0,x1,y1=p['box'];label=p['text']
 records=[]
 for point in rec['points']:
  nx,ny=map(lambda v:int(np.floor(v)),point['native_pixel']);inside=x0<=nx<x1 and y0<=ny<y1
  a=float(p['alpha'][ny-y0,nx-x0]) if inside else 0.0
  records.append(dict(**point,original_grid_mask=bool(grid[ny,nx]),inside_first_word_box=inside,original_first_word_alpha=a,
      native_gray=int(cv.orig[ny,nx].min()),source_word=label))
 out.append(dict(row=rec['row'],dpi=rec['dpi'],first_word=label,first_word_box=list(p['box']),points=records))
 print('EDGE SOURCE',rec['row'],rec['dpi'],'points',len(records),'in word alpha',sum(p['original_first_word_alpha']>.08 for p in records),'original grid mask',sum(p['original_grid_mask'] for p in records),flush=True)
E.close();json.dump(out,open(fresh(root/'review'/'native-word-edge-original-ink.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
