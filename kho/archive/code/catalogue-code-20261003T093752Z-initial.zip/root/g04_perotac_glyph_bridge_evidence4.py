"""Bảng chứng cứ 12 ký tự và cầu nối 3 chữ nguồn; chưa ghi PDF."""
from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from pathlib import Path
from PIL import Image
from scipy.optimize import minimize
from scipy.ndimage import map_coordinates
import numpy as np,json,hashlib
name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);current=S.result(name)
base=Path(S.report('G04/BO KY TU SACH NGUON PEROTAC'));root=base/'BANG CHUNG CU 12 KY TU VA CAU NOI'
d=json.loads((base/'DO BIEN GIU LUONG MUC NGUON/DO BIEN BAO TOAN LUONG MUC TUNG NGUON.json').read_text(encoding='utf8'));by={x['key']:x for x in d['candidates']}
keys={'A':'A_4SA16-25','S':'S_4SA16-25','/':'SLASH25','0':'0_4SA16-20','1':'1_4SA16-25','2':'2_4SA16-25','3':'3_4SA8-37','4':'4_4SA16-25','5':'5_4SA16-25','6':'6_4SA16-25','8':'8_4SA8-37_PREFIX','9':'9_4SA16-9'}
selected=[];grid=Image.new('RGB',(1440,1200),'white')
for i,(ch,key) in enumerate(keys.items()):
    r=dict(by[key]);r['character']=ch;r['expected_components']=1;r['expected_holes']=2 if ch=='8' else 1 if ch in 'A0469' else 0
    r['topology_matches_literal']=r['components']==1 and r['holes']==r['expected_holes'];assert r['topology_matches_literal'],ch
    r['selected_candidate_only_not_font_final_acceptance']=True;selected.append(r)
    img=Image.open(base/'DO BIEN GIU LUONG MUC NGUON'/(key+' NGUON VA BIEN GIU MUC.png'));grid.paste(img,((i%3)*480,(i//3)*300))
grid.save(fresh(root/'12 KY TU NGUON VA BIEN UNG VIEN CHI XEM.png'))
E=Editor(src,backend='fitz');R=Raster(E);cv8=R.canvas(max(R.images(7),key=lambda z:z.W*z.H));cv6=R.canvas(max(R.images(5),key=lambda z:z.W*z.H))
font=np.array([57.,55.,57.]);bg=np.array([255.,255.,255.]);refraw=cv8.orig[204:213,282:304];testraw=cv6.orig[295:304,1160:1182]
ref=R.alpha_of(refraw,bg,font);test=R.alpha_of(testraw,bg,font);y,x=np.mgrid[:ref.shape[0],:ref.shape[1]]
def sampled(z):
    dx,dy,scale=z
    return map_coordinates(test,[(y-4)/scale+4+dy,(x-10.5)/scale+10.5+dx],order=1,mode='constant',cval=0,prefilter=False)
def objective(z):
    aa=sampled(z);w=(ref>=.2)|(aa>=.2);return float(np.mean((ref[w]-aa[w])**2))
res=minimize(objective,[0,0,1],bounds=[(-.65,.65),(-.65,.65),(.98,1.02)],method='Powell',options={'xtol':1e-7,'ftol':1e-9,'maxiter':1000});sample=sampled(res.x);parts=[]
for ch,sl in [('4',slice(0,7)),('S',slice(7,14)),('A',slice(14,22))]:
    rr=ref[:,sl];aa=sample[:,sl];w=(rr>=.2)|(aa>=.2);rm=rr>=.45;am=aa>=.45;r=by[keys[ch]];t=by[ch+'_4SA8-37_BRIDGE']
    parts.append(dict(character=ch,reference_native_box=r['source_native_box'],test_native_box=t['source_native_box'],source_components=[r['components'],t['components']],source_holes=[r['holes'],t['holes']],
        source_widths_pt=[r['source_iso_width_pt'],t['source_iso_width_pt']],source_heights_pt=[r['source_iso_height_pt'],t['source_iso_height_pt']],
        width_delta_percent=(t['source_iso_width_pt']/r['source_iso_width_pt']-1)*100,height_delta_percent=(t['source_iso_height_pt']/r['source_iso_height_pt']-1)*100,
        alpha_correlation_after_one_common_transform=float(np.corrcoef(rr[w],aa[w])[0,1]),IoU_iso45_after_one_common_transform=float((rm&am).sum()/(rm|am).sum()),mean_abs_source_alpha_difference=float(np.mean(abs(rr[w]-aa[w]))),
        source_structure='4 kín tam giác/thanh ngang' if ch=='4' else 'S có hai vòng mở cùng chiều/hai đầu' if ch=='S' else 'A hai chân xiên/một lỗ/thanh ngang'))
tr=dict(global_box_translation_native=[878,91],additional_common_dx_dy_px=res.x[:2].tolist(),common_uniform_scale=float(res.x[2]),no_rotation=True,
        reference_box=[282,204,304,213],test_box=[1160,295,1182,304],all_three_characters_use_one_transform=True,fit_objective=objective(res.x),source_word_for_3_and8='4SA8/37 p6',comparisons=parts,
        only_evidence_for_ROOT_review=True,no_single_glyph_or_IoU_only_font_acceptance=True,source_edge_uncertainty_native_px=.5)
bridge=Image.new('RGB',(900,420),'white')
for raw,pos in [(refraw,(20,20)),(testraw,(460,20)),((255-ref[:,:,None]*(bg-font)).astype(np.uint8),(20,220)),((255-sample[:,:,None]*(bg-font)).clip(0,255).astype(np.uint8),(460,220))]:
    bridge.paste(Image.fromarray(raw).resize((440,180),Image.Resampling.NEAREST),pos)
bridge.save(fresh(root/'CAU NOI 4SA P08 VA P06 NGUON VA MOT BIEN DOI CHUNG.png'))
word11=cv8.orig[406:416,282:331];Image.fromarray(word11).save(fresh(root/'4SA16-11 CHU NGUON150dpi.png'));Image.fromarray(word11).resize((980,200),Image.Resampling.NEAREST).save(fresh(root/'4SA16-11 NGUON PHONG20LAN.png'))
one_raw=cv8.orig[204:213,304:308];Image.fromarray(one_raw).resize((80,180),Image.Resampling.NEAREST).save(fresh(root/'1 SACH DE DOI CHIEU CA HAI SO1 TRONG 11.png'))
al11=R.alpha_of(word11,bg,font);lum=word11.astype(float)@[.299,.587,.114];chroma=word11.max(2).astype(int)-word11.min(2).astype(int)
cols=[dict(native_x=282+i,neutral_dark_count=int(((lum[:,i]<105)&(chroma[:,i]<25)).sum()),alpha_by_y={str(406+j):float(al11[j,i]) for j in range(len(al11))}) for i in range(word11.shape[1]) if 317<=282+i<=329]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(src)==d['source_sha256'] and sha(current)==d['current_sha256']
obj=dict(read_only=True,source_sha256=sha(src),current_sha256=sha(current),source_fonts_present=False,all_glyphs_from_original_Perotac_JPEG=True,candidates_12=selected,common_three_glyph_font_bridge=tr,
         double_one_11=dict(literal='4SA16/11',same_clean_source_1_proposed_twice=True,clean_1_source_box=[304,204,308,213],old_11_curve_contamination_not_copied=True,old_suffix_columns=cols,final_placement_baseline_not_accepted=True),
         glyph_set_finally_accepted=False,new_catalogue_FontProgram_or_PDF_written=False,canonical_source_and_progress_unchanged=True,
         limit='Biên từ ảnh150dpi vẫn có gợn khi phóng20lần. Không nhận nét/kiểu chữ đạt trước ROOT/đồ họa xem. Chênh cao mỗi biên có bất định±0,5pixel; không bỏ qua để ép kết luận.')
Path(fresh(root/'BANG CHUNG CU 12 KY TU VA CAU NOI.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Chứng cứ 12 ký tự từ đúng Perotac

**Đã định vị đủ 12 ký tự gốc. Chưa nghiệm thu phông/đường bao mới và chưa tạo PDF mẫu.**

Ảnh trái giữ pixel JPEG nguyên 150dpi; ảnh phải là ứng viên biên từ alpha (tỷ lệ mực) nguồn. Biên riêng khớp lượng mực từng crop (miếng cắt); không vẽ bù nét. Khớp lượng mực và số lỗ chưa đủ kết luận giữ kiểu chữ.

| Chữ | Trang / cụm nguồn | Hộp pixel nguyên | Rộng × cao nét (pt) | Thành phần / lỗ |
|---|---|---|---|---|
'''
for r in selected:md+=f"| {r['character']} | {r['source_page']} / {r['key']} | {r['source_native_box']} | {r['source_iso_width_pt']:.4f} × {r['source_iso_height_pt']:.4f} | {r['components']} / {r['holes']} |\n"
md+='''
1 pt = 1/72 inch; mỗi pixel nguyên ≈0,4800 pt. Mẫu giữ 1:1, ma trận alpha, băm pixel nguyên, hộp nguồn và phép đổi tọa độ thật. Không dùng phông hệ thống/file khác.

Chữ 3 và 8 chọn trong **4SA8/37 trang 6**, đúng file. Cầu nối dùng cả **4, S, A** so với **4SA16/25 trang 8**, chung một phép biến đổi. Giữ cấu trúc, số lỗ, hình, rộng/cao và lượng mực; không dùng một chữ hay chỉ IoU (tỷ lệ vùng giao nhau) phán quyết phông. Chiều cao biên có chênh ở ảnh nhỏ/nén, bất định nửa pixel mỗi biên; cần ROOT/đồ họa xem trước nhận.

8 ở /18 bị mất lỗ tại biên giữ mực nên loại; 8 ở phần đầu 4SA8/37 có hai lỗ và liền nét. 3 trong phần đầu 4SA3/30 bị ba thành phần nên loại. Giữ mọi kết quả loại trong hồ sơ đo.

/11 nguồn bị đường bơm xuyên qua, chỉ đọc vị trí. Đề xuất mẫu **1 sạch từ 4SA16/25 trang 8 hai lần**. Phải kiểm đủ hai số 1, khoảng chữ và đường cơ sở trên mẫu đầy đủ; chưa dựng/chốt nhãn cuối.

Biên từ ảnh nhỏ còn gợn ở phóng 20 lần, nhất là /. Đây là hồ sơ chọn chữ, chưa mẫu catalogue/phông mới. Không tự đổi kiểu/làm đậm để che hạn chế. Ảnh chính: `12 KY TU NGUON VA BIEN UNG VIEN CHI XEM.png`; cầu nối: `CAU NOI 4SA P08 VA P06 NGUON VA MOT BIEN DOI CHUNG.png`; /11: `4SA16-11 NGUON PHONG20LAN.png`. Bảng số/ma trận nguồn ở JSON cùng tên.
'''
md+='\nNguồn SHA256: '+sha(src)+'\n\nBản giao SHA256: '+sha(current)+'\n\nKhông ghi bản giao, nguồn hay TIEN DO.md.\n'
Path(fresh(root/'BANG CHUNG CU 12 KY TU VA CAU NOI.md')).write_text(md,encoding='utf8')
print('12 SOURCE CANDIDATES; EXPECTED TOPOLOGY; FONT/CONTOUR NOT ACCEPTED',flush=True);print('COMMON TRANSFORM',res.x.tolist(),flush=True)
for v in parts:print(v['character'],'CORR',v['alpha_correlation_after_one_common_transform'],'IOU',v['IoU_iso45_after_one_common_transform'],'HEIGHT DELTA',v['height_delta_percent'],flush=True)
print('11 SOURCE COLUMNS',[(c['native_x'],c['neutral_dark_count']) for c in cols],flush=True);E.close()
