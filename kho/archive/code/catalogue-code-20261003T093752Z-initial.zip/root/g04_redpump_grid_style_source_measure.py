"""Measure source grid/frame optical profiles, no PDF sample or default-grid assumption."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'));grid=json.loads((root/'LUOI MO DOC MEDIAN NGUON TRANG8.json').read_text(encoding='utf8'));frame=json.loads((root/'KHUNG LUOI THAT NGUON TRANG8.json').read_text(encoding='utf8'));src=d['method']['source'];cur=d['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['method']['source_SHA256'],d['method']['input_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);im=max(R.images(7),key=lambda z:z.W*z.H);cv=R.canvas(im);a=cv.orig.astype(float);gray=a@np.array([.299,.587,.114]);step=abs(cv.to_page(0,1)[1]-cv.to_page(0,0)[1]);records=[]
for z in grid['records']:
 for h in z['horizontal_inner_grid']:
  if z['name']=='QH' and h['peak_native_v']==219:continue
  v=h['peak_native_v'];ys=np.arange(v-6,v+7);xx=np.r_[np.arange(365,446),np.arange(522,577)];sub=a[ys][:,xx];neutral=(sub[:,:,1]-sub[:,:,0]<6)&(sub[:,:,2]-sub[:,:,0]<6)&(sub.max(2)-sub.min(2)<20);levels=np.nanmedian(np.where(neutral,sub@np.array([.299,.587,.114]),np.nan),axis=1);background=float(np.median(np.r_[levels[:2],levels[-2:]]));contrast=np.maximum(0,background-levels);area=float(contrast.sum()*step);width224=area/(255-224);row=dict(panel=z['name'],native_v=v,source_page_y=h['source_page_y'],profile_native_v=ys.tolist(),profile_gray=levels.tolist(),background_gray=background,black_contrast_area_pt=area,equivalent_width_pt_at_RGB224=width224,proposed_025_224_optical_ratio=.25*(255-224)/max(area,1e-8),source_core_gray=float(levels.min()))
  records.append(row);print(z['name'],v,'area',round(area,3),'width224',round(width224,4),'025ratio',round(row['proposed_025_224_optical_ratio'],3),flush=True)
frames=[]
for z in frame['panels']:
 for what,v,xrange in [('top',z['frame_native_uv'][1],(145,450)),('bottom',z['frame_native_uv'][3],(145,730))]:
  ys=np.arange(int(round(v))-6,int(round(v))+7);levels=np.median(gray[ys,xrange[0]:xrange[1]],axis=1);contrast=np.maximum(0,255-levels);area=float(contrast.sum()*step);frames.append(dict(panel=z['name'],edge=what,native_v=v,profile_native_v=ys.tolist(),profile_gray=levels.tolist(),equivalent_black_width_pt=area/255,source_core_gray=float(levels.min())))
E.close();assert before==[sha(src),sha(cur)]
out=dict(source_SHA256=before[0],current_SHA256=before[1],grid_profiles=records,median_equivalent_grid_width_at_RGB224=float(np.median([p['equivalent_width_pt_at_RGB224'] for p in records])),frames=frames,median_equivalent_black_frame_width_pt=float(np.median([p['equivalent_black_width_pt'] for p in frames])),source_native_pixel_pt=step,source_JPEG_measurement=True,measurement_uncertainty='Nguồnảnh150dpi nén vàfringe 6px; đây làđộrộngquanghọc tươngđương, khôngphảibútCAD. Phảisoi toànmẫuchọnlưới nhẹ nhưngđủđậm theo nguồn.',default_025_224_accepted=False,PDF_sample_written=False)
Path(fresh(root/'DO DAM LUOI VA KHUNG NGUON REDPUMP.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('source measured median gridwidth224',out['median_equivalent_grid_width_at_RGB224'],'frameblack',out['median_equivalent_black_frame_width_pt'],flush=True)
