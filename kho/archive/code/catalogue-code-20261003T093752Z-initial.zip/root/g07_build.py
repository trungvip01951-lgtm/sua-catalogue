from catwork import start,fresh
S,D,N=start()
from catfix.recipes import Job
from catfix.textlayer import TextLayer,TMatch
from catfix.vector import Editor
from catfix.cs import Instr,Str
from catfix import verify
from pathlib import Path
import json,re,hashlib,copy
NAME='Catalog bơm nước thải Aquaris FS (bản mới).pdf';root=Path(S.report('G07'));stage=root/'review'/'mau-sua.pdf'
job=Job(S.src(NAME),fresh(stage),log_path=fresh(root/'review'/'mau-sua.log.json'))
TL=job.TL;E=job.E
pairs55=[('industrian','industriali'),('movimentazionee','movimentazione e'),('utllizzare','utilizzare'),
('peril sollevamentodl','per il sollevamento di'),('inseritidei','inseriti dei'),('spiacevolidanni','spiacevoli danni'),
('50 FHz','50 Hz'),('dean','clean'),('nothigherthan','not higher than'),('anda Schuko','and a Schuko'),
('threephase','three-phase'),('trlphasé','triphasé'),('IPB8','IP68')]
units=('Kg³/m','kg/dm³')
state=dict(source=job.src,stage=job.dst,source_sha256=hashlib.sha256(Path(job.src).read_bytes()).hexdigest(),unresolved=[],
           paragraphs=[],titles=[],decimal=[],sizes=[],insert48={},outlet=[],edits=[])
lines=TL.text_lines(0)
def union(gs):
    return [float(min(g.bbox[0] for g in gs)),float(min(g.bbox[1] for g in gs)),float(max(g.bbox[2] for g in gs)),float(max(g.bbox[3] for g in gs))]
def find1(text,rect=None):
    ms=TL.find(0,text,rect=rect)
    assert len(ms)==1,(text,rect,len(ms))
    return ms[0]
def add_rect(rect,label,kind='text'):
    job._add(0,rect,label,kind)
def codes_and_width(ref,source_glyphs,text):
    r=ref.run;data=b'';width=0;copied=[]
    for ch in text:
        try:cb=r.font.encode(ch)
        except KeyError:
            # Preserve an existing, visibly rendered glyph's original byte.
            # Its Unicode cmap contour exists; catfix's availability test picks
            # the other MacRoman cmap and rejects certain existing accents / ³.
            g=next(g for g in source_glyphs if g.ch==ch and g.run.font.basefont==r.font.basefont)
            cb=g.cb;prog=r.font._font_program();assert prog[0]=='tt'
            fn=prog[1]['cmap'].getcmap(3,1).cmap[ord(ch)]
            assert prog[1]['glyf'][fn].numberOfContours!=0
            if not any(a['char']==ch for a in copied):copied.append(dict(char=ch,code=cb.hex(),glyph_name=fn,original_at=list(map(float,g.o))))
        data+=cb
        width+=(r.font.width(cb)/1000*r.fs+r.tc+(r.tw if ch==' ' else 0))*r.th*r.scale_x
    return data,width,copied
def native_insert(ref,data,text,origin):
    # Use catfix's same-style insertion and copy validated original glyph codes
    # into its content instruction. The embedded font bytes stay untouched.
    TL.insert_like(ref,'',origin,verbose=False)
    ins=E.ins[ref.run.key][len(E.page(ref.run.key).ops)]
    j=next(i for i in range(len(ins)-1,-1,-1) if ins[i].op=='Tj')
    ins[j]=Instr([Str(data)],'Tj')
    E.log[-1].update(new=text,method='same embedded font; preserved original codes for existing glyphs')

# Preflight all affected prose lines. Reflow only each suffix; preceding text
# stays in its original native PDF commands. Each suffix keeps one exact style.
all_matches=[(old,new,m) for old,new in pairs55+[units] for m in TL.find(0,old)]
for text,gs in lines:
    ids=set(map(id,gs));hits=[(old,new,m) for old,new,m in all_matches if id(m.glyphs[0]) in ids]
    if not hits:continue
    first=min(gs.index(m.glyphs[0]) for _,_,m in hits);suffix=gs[first:]
    old=''.join(g.ch for g in suffix);new=old
    for a,b,_ in hits:
        assert new.count(a)==1,(a,new)
        new=new.replace(a,b)
    ref=suffix[0];r=ref.run
    for g in suffix:
        assert g.run.font.basefont==r.font.basefont and abs(g.run.size_page-r.size_page)<.01 and g.run.fill==r.fill and g.run.tr==r.tr,(old,g.run.font.basefont,r.font.basefont)
    data,width,copied=codes_and_width(ref,suffix,new)
    x,y=map(float,ref.o);maxx=x+width
    assert maxx<571 or x>600,(old,new,x,maxx)
    rec=dict(old=old,new=new,origin=[x,y],old_rect=union(suffix),new_rect=[x,y-.22*r.size_page,maxx,y+.75*r.size_page],
             task_ids=sorted(set(56 if a==units[0] else 55 for a,b,m in hits)),replacements=[dict(old=a,new=b,old_rect=m.bbox) for a,b,m in hits],
             font=r.font.basefont,fontname=str(r.fontname),size=r.size_page,width=width,copied_existing_codes=copied,
             suffix=suffix,ref=ref,data=data)
    state['paragraphs'].append(rec)
for rec in sorted(state['paragraphs'],key=lambda a:-max(g.run.index for g in a['suffix'])):
    # Original glyph objects retained for same-font source references.
    m=TMatch(0,rec['suffix'],rec['old'],rec['old'])
    TL.delete(m,keep_rest=True)
    ref=rec['ref'];x,y=rec['origin']
    native_insert(ref,rec['data'],rec['new'],(x,y))
    rect=[min(rec['old_rect'][0],rec['new_rect'][0]),min(rec['old_rect'][1],rec['new_rect'][1]),
          max(rec['old_rect'][2],rec['new_rect'][2]),max(rec['old_rect'][3],rec['new_rect'][3])]
    add_rect(rect,'#'+','.join(map(str,rec['task_ids']))+': '+rec['old']+' → '+rec['new'])
    del rec['suffix'];del rec['ref'];del rec['data']

for old,new in [('FESI','PESI'),('Imballa','Imballo'),('CLOSEDIMPELLER','CLOSED IMPELLER'),('PotenZa','Potenza')]:
    m=find1(old);rect=m.bbox;ref=m.glyphs[0];ref.run.font.encode(new)
    w=TL.width_ts(ref.run,new)*ref.run.scale_x
    newrect=[(rect[0]+rect[2]-w)/2,rect[1],(rect[0]+rect[2]+w)/2,rect[3]] if old=='CLOSEDIMPELLER' else [rect[0],rect[1],rect[0]+w,rect[3]]
    TL.replace(m,new,align='center' if old=='CLOSEDIMPELLER' else 'left',keep_rest=True,verbose=False)
    add_rect([min(rect[0],newrect[0]),rect[1],max(rect[2],newrect[2]),rect[3]],'#56 '+old+' → '+new)
    state['titles'].append(dict(old=old,new=new,rect=rect,new_rect=newrect,font=ref.run.font.basefont,size=ref.run.size_page))

table_rects=[(645,620,1165,755),(645,484,940,535),(645,245,1165,329)]
decimal=[]
for rect in table_rects:
    decimal.extend(TL.find(0,r'\d+,\d+',rect=rect,regex=True))
for m in sorted(decimal,key=lambda m:(-m.glyphs[0].run.index,-m.glyphs[0].k)):
    rect=m.bbox;new=m.text.replace(',','.')
    TL.replace(m,new,align='center',keep_rest=True,verbose=False)
    add_rect(rect,'#57 '+m.text+' → '+new)
    state['decimal'].append(dict(old=m.text,new=new,rect=rect))
m=find1('50HZ');rect=m.bbox;TL.replace(m,'50 Hz',align='center',keep_rest=True,verbose=False)
add_rect(rect,'#57 50HZ → 50 Hz');state['hz']=dict(old='50HZ',new='50 Hz',rect=rect)

# Performance data have 7 pt standard text. Normalize the three 8 pt cells
# with an adjacent 7 pt numeric source, preserving each original cell center.
for old,box,reftext,refbox in [('10',(708,515,727,527),'8',(735,515,753,527)),
                             ('14',(708,497,727,509),'11',(759,497,781,508)),
                             ('9',(786,497,807,509),'7',(811,497,828,508))]:
    m=find1(old,box);ref=find1(reftext,refbox);g=ref.glyphs[0];oldr=m.glyphs[0].run;rect=m.bbox
    assert abs(oldr.size_page-8)<.01 and abs(g.run.size_page-7)<.01,(old,oldr.size_page,g.run.size_page)
    width=TL.width_ts(g.run,old)*g.run.scale_x
    origin=((rect[0]+rect[2]-width)/2,float(m.glyphs[0].o[1]))
    TL.delete(m);TL.insert_like(g,old,origin,verbose=False)
    add_rect(rect,'#57 cỡ chữ '+old+' 8 → 7 pt')
    state['sizes'].append(dict(text=old,old_rect=rect,origin=origin,old_size=oldr.size_page,new_size=g.run.size_page,font=g.run.font.basefont))

# Empty m3/h header: same baseline, style and cell center as 42 / 800.
ref=find1('42',(880,575,910,586));low=find1('800',(909,548,938,559));g=ref.glyphs[0]
center=(low.bbox[0]+low.bbox[2])/2;width=TL.width_ts(g.run,'48')*g.run.scale_x
origin=(center-width/2,float(g.o[1]));TL.insert_like(g,'48',origin,verbose=False)
rect=[origin[0],ref.bbox[1],origin[0]+width,ref.bbox[3]]
add_rect(rect,'#54 thêm 48 dưới cột 800 l/min')
state['insert48']=dict(text='48',rect=rect,origin=origin,center=center,ref_rect=ref.bbox,font=g.run.font.basefont,size=g.run.size_page)

for old,new,box in [('50','80',(1100,620,1150,635)),('G 2”','G 3”',(750,247,783,260))]:
    m=find1(old,box);rect=m.bbox;ref=m.glyphs[0]
    try:ref.run.font.encode(new)
    except KeyError as ex:
        state['unresolved'].append(dict(task=137,old=old,new=new,rect=rect,font=ref.run.font.basefont,reason=str(ex),action='Giữ nguyên 50; thiếu nét 8 đúng phông MyriadPro-Regular trong chính file'))
        continue
    TL.replace(m,new,align='center',keep_rest=True,verbose=False)
    add_rect(rect,'#137 FS300/80: '+old+' → '+new)
    state['outlet'].append(dict(old=old,new=new,rect=rect,font=ref.run.font.basefont,size=ref.run.size_page))

job.save();state['edits']=job.edits
state['check']=job.check()
json.dump(state,open(fresh(root/'build-state.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1,default=str)
job.evidence(fresh(root/'review'/'truoc-sau-moi-vi-tri.png'),dpi=200)
verify.crop(job.dst,0,(50,60,575,585),220).save(fresh(root/'review'/'mo-ta-sau.png'))
verify.crop(job.dst,0,(630,375,1170,825),200).save(fresh(root/'review'/'bang-tren-sau.png'))
verify.crop(job.dst,0,(630,240,1170,475),250).save(fresh(root/'review'/'bang-duoi-sau.png'))
print('G07 staging:',job.dst,'check=',state['check']['ok'],'unexpected=',state['check']['unexpected'],'missing=',state['check']['missing'],flush=True)
print('Decimal cells:',len(state['decimal']),'prose suffixes:',len(state['paragraphs']),flush=True)
job.close()
