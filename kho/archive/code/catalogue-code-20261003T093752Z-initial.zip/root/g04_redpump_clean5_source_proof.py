"""Whole-source small5/4/S comparison. Fresh evidence, no PDF or approved-bank overwrite."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,numpy as np,hashlib
from scipy.ndimage import label,binary_fill_holes
from PIL import Image,ImageDraw
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
srcd=json.loads((M/'CHU5 NGUON P8 DOI CHIEU LAN1'/'NGUON5 DOI CHIEU TU CHINH FILE.json').read_text(encoding='utf8'))
bank=json.loads((P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
folder=M/'CHU5 SACH NGUON P8 VA2 KY TU CUNG KIEU LAN1';assert not folder.exists()
r=next(r for r in srcd['records'] if r['model']=='4SL16/25');rgb=np.array(r['RGB']);g=rgb@np.array([.299,.587,.114])
bg=np.median(g[:,210:260],axis=1);al=np.clip((bg[:,None]-g)/np.maximum(bg[:,None],1),0,1)
cuts=[('4',[16,3,45,41]),('S',[46,3,75,41]),('5',[178,3,204,41])]
records=[];photo=Image.new('RGB',(1650,850),'white');dr=ImageDraw.Draw(photo);ft=verify._font(18)
for i,(ch,box) in enumerate(cuts):
    x0,y0,x1,y1=box;a=al[y0:y1,x0:x1];raw=rgb[y0:y1,x0:x1]
    yy,xx=np.where(a>.085);ib=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]
    # Fix the glyph cell to the actual source's optical bbox plus one600px,
    # only translation/cropping. No geometric scaling of source strokes.
    lo=[max(0,ib[0]-1),max(0,ib[1]-1),min(a.shape[1],ib[2]+1),min(a.shape[0],ib[3]+1)]
    alpha=a[lo[1]:lo[3],lo[0]:lo[2]];actualbox=[x0+lo[0],y0+lo[1],x0+lo[2],y0+lo[3]]
    off=r['source_render_box'];source_render_box=[actualbox[0]+off[0],actualbox[1]+off[1],actualbox[2]+off[0],actualbox[3]+off[1]]
    rect=r['source_page_box'];px=.12
    pagebox=[rect[0]+actualbox[0]*px,rect[3]-actualbox[3]*px,rect[0]+actualbox[2]*px,rect[3]-actualbox[1]*px]
    topl=[]
    for t in [.085,.15,.2,.25,.35,.5]:
        _,n=label(alpha>=t);_,h=label(binary_fill_holes(alpha>=t)&~(alpha>=t))
        topl.append(dict(level=t,parts=int(n),holes=int(h)))
    vals=alpha[alpha>.085];core=float(np.median(vals[vals>=np.quantile(vals,.95)]))
    old=next(q for q in bank['records'] if q['character']==ch);oa=np.array(old['source_alpha']);oy,ox=np.where(oa>.085)
    ob=[int(ox.min()),int(oy.min()),int(ox.max()+1),int(oy.max()+1)]
    nb=[int(np.where(alpha>.085)[1].min()),int(np.where(alpha>.085)[0].min()),int(np.where(alpha>.085)[1].max()+1),int(np.where(alpha>.085)[0].max()+1)]
    metric=dict(source_page=8,source_word='4SL16/25',character=ch,source_page_box=pagebox,source_render_box=source_render_box,
        source_render_request_rect=r['source_request_rect'],source_canvas_rect=r['actual_render_rect'],source_alpha=alpha.tolist(),
        actual_source_RGB_cell=raw[lo[1]:lo[3],lo[0]:lo[2]].tolist(),source_background_gray_by_row=bg[actualbox[1]:actualbox[3]].tolist(),
        source_physical_box_size_pt=[alpha.shape[1]*.12,alpha.shape[0]*.12],source_ink_bbox600=nb,
        physical_scale=1.,source_foreground_color_assumption=[0,0,0],source_core_coverage_top5median=core,
        source_ink_area_pt2=float(alpha.sum()*.12**2),topology=topl,
        old_bank_source=old['source_word'],old_bank_page=old['source_page'],old_ink_size_pt=[(ob[2]-ob[0])*.12,(ob[3]-ob[1])*.12],
        candidate_ink_size_pt=[(nb[2]-nb[0])*.12,(nb[3]-nb[1])*.12],
        ink_size_difference_pt=[((nb[2]-nb[0])-(ob[2]-ob[0]))*.12,((nb[3]-nb[1])-(ob[3]-ob[1]))*.12],
        status='Nguồn nhỏ thật, ứng viên; cần ROOT đọc đối chứng4/S và cỡ/đậm trước đổi glyph.')
    records.append(metric)
    oldpic=Image.fromarray(np.round(255*(1-oa)).astype('uint8')).convert('RGB');newpic=Image.fromarray(np.round(255*(1-alpha)).astype('uint8')).convert('RGB')
    dr.text((5,i*250+10),ch+'  trước donor V3 / ứng viên nhỏ p8 cùng từ 4SL16/25',fill='blue',font=ft)
    photo.paste(oldpic.resize((oldpic.width*5,oldpic.height*5),Image.Resampling.NEAREST),(550,i*250+45))
    photo.paste(newpic.resize((newpic.width*5,newpic.height*5),Image.Resampling.NEAREST),(900,i*250+45))
    dr.text((1100,i*250+60),'cỡ mực cũ '+str(metric['old_ink_size_pt'])+'pt\ncỡ mực mới '+str(metric['candidate_ink_size_pt'])+'pt\nΔ '+str(metric['ink_size_difference_pt'])+'pt',fill='blue',font=ft)
f=fresh(folder/'5 NGUON SACH VA2 KY TU4 S CUNG KIEU.png');photo.save(f)
Path(fresh(folder/'5 CUNG KIEU2 KY TU NGUON VA CO.json')).write_text(json.dumps(dict(source=srcd['source'],source_SHA256=srcd['source_SHA256'],records=records,
    photo=f,source_source_word='4SL16/25',no_font_replacement=True,no_scale=True,no_PDF=True,no_M2=True,
    old_bank_not_changed=True,status='Nguồn đối chứng ứng viên, chưa gọi cùng style đạt chỉ từ số đo.'),ensure_ascii=False,indent=2),encoding='utf8')
assert hashlib.sha256(Path(srcd['source']).read_bytes()).hexdigest()==srcd['source_SHA256']
print([(r['character'],r['candidate_ink_size_pt'],r['ink_size_difference_pt'],r['source_ink_area_pt2'],r['source_core_coverage_top5median'],r['topology']) for r in records],flush=True)
