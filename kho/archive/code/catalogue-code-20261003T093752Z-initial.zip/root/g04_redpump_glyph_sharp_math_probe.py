"""Read own approved small-glyph alpha; mathematical diagnostics only."""
from catwork import start
S,D,N=start()
from pathlib import Path
import json,numpy as np
from scipy.ndimage import label,gaussian_filter,maximum_filter,binary_fill_holes,binary_closing
from PIL import Image,ImageDraw
from catfix import verify

P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
B=json.loads((P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'))
for r in B['records']:
    a=np.array(r['source_alpha']);c,num=label(a>=.085)
    parts=[]
    for i in range(1,num+1):
        z=a[c==i];y,x=np.where(c==i)
        parts.append(dict(n=len(z),peak=float(z.max()),mass=float(z.sum()),bbox=[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)]))
    vals=a[a>.085];core=float(np.median(vals[vals>=np.quantile(vals,.95)]))
    t=core*.5;m=a>=t;cc,nn=label(m)
    print(r['character'],a.shape,parts,'core',core,'halfcore',t,'halfcoreparts',nn,'halfcorearea',int(m.sum()),'targetarea',float(a.sum()/core),flush=True)
    ap=np.pad(a,8);z=gaussian_filter(ap,.7)
    for win in [9]:
        norm=z/np.maximum(maximum_filter(z,size=win),1e-5)
        mm=(norm>.5)&(z>.04)
        c,n=label(mm);hc,hn=label(binary_fill_holes(mm)&~mm)
        print('local',win,'parts',n,'holes',hn,'area',int(mm.sum()),flush=True)
        for sz in [3,5]:
            mm2=binary_closing(mm,structure=np.ones((sz,sz)))
            c,n=label(mm2);hc,hn=label(binary_fill_holes(mm2)&~mm2)
            hs=[int((hc==i).sum()) for i in range(1,hn+1)]
            print('closed',sz,'parts',n,'holes',hn,hs,'area',int(mm2.sum()),flush=True)
