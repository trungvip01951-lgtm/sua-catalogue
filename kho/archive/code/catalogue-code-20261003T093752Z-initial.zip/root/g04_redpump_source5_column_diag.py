from catwork import start
S,D,N=start()
from pathlib import Path
import json,numpy as np
from scipy.ndimage import label
P=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1/CHU5 NGUON P8 DOI CHIEU LAN1'))
d=json.loads((P/'NGUON5 DOI CHIEU TU CHINH FILE.json').read_text(encoding='utf8'))
for r in d['records']:
    a=np.array(r['RGB']);g=a@np.array([.299,.587,.114]);m=g<190
    sums=m.sum(0);c,n=label(sums>=2);groups=[]
    for i in range(1,n+1):
        x=np.where(c==i)[0];yy,xx=np.where(m[:,x.min():x.max()+1]);groups.append([int(x.min()),int(x.max()+1),int(yy.min()),int(yy.max()+1),int(len(xx))])
    print(r['model'],a.shape,groups,flush=True)
