"""Keep complete genuine source strokes, including disconnected JPEG ink. No PDF."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
d=json.loads((root/'GLYPH HOAN CHINH HOP NGUON THU CONG.json').read_text(encoding='utf8'))
plan=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17.json').read_text(encoding='utf8'))
src=d['source'];cur=plan['method']['input_current'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cache={};records=[];pic=Image.new('RGB',(1150,12*112),'white');dr=ImageDraw.Draw(pic)
for i,old in enumerate(d['records']):
 z=dict(old)
 if z['character']=='9':
  z.update(source_page=8,source_word='4SL16/9',source_canvas_rect=[132.,346.44,164.04,500.52],source_render_box=[155,942,185,979])
 key=(z['source_page'],tuple(z['source_canvas_rect']))
 if key not in cache:cache[key]=R.render_canvas(z['source_page']-1,z['source_canvas_rect'],dpi=600)
 cv=cache[key];x0,y0,x1,y1=z['source_render_box'];whole=cv.orig.astype(float);g=whole@np.array([.299,.587,.114]);bg=np.median(g,axis=1);p=g[y0:y1,x0:x1]
 al=np.clip((bg[y0:y1,None]-p)/np.maximum(bg[y0:y1,None],1),0,1);candidate=al>.085;components,n=label(candidate);sizes=[int((components==k).sum()) for k in range(1,n+1)];assert sizes,z['character'];idx=int(np.argmax(sizes))+1;kept=[idx]
 # Source '5' has three observed parts. The 12 px left bottom and 48 px
 # bottom bar are both genuine strokes, visible in the source context. Never
 # delete them merely because JPEG disconnection splits a connected component.
 if z['character']=='5':kept=list(range(1,n+1))
 keep=np.isin(components,kept);al*=keep
 raw=Image.fromarray(whole[y0:y1,x0:x1].round().astype('uint8'));clean=Image.fromarray((255*(1-al)).round().clip(0,255).astype('uint8')).convert('RGB')
 dr.text((5,i*112+6),z['character']+' from '+z['source_word'],fill='blue');pic.paste(raw.resize((raw.width*2,raw.height*2),Image.Resampling.NEAREST),(270,i*112+10));pic.paste(clean.resize((clean.width*2,clean.height*2),Image.Resampling.NEAREST),(450,i*112+10));dr.text((650,i*112+20),f'kept source components {kept} / areas {sizes}',fill='blue')
 yy,xx=np.nonzero(al>.085);z.update(source_canvas_rect=list(cv.rect0),source_page_box=[*cv.to_page(x0,y1),*cv.to_page(x1,y0)],source_alpha=al.tolist(),source_background_gray_by_row=bg[y0:y1].tolist(),source_components_kept=kept,source_components_areas=sizes,source_ink_bbox600=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],source_physical_box_size_pt=[(x1-x0)*.12,(y1-y0)*.12],source_foreground_color_assumption=[0,0,0],physical_scale=1.,method='Tách mực theo nền median hàng nguồn. Giữ đầy đủ các phần mực thật của từng chữ đã soi; không đồng nhất chữ với thành phần liên thông lớn nhất. Các mảnh ở ký tự kế bên không được ghép vào chữ.')
 records.append(z)
photo=fresh(root/'GLYPH THAT DAY DU GIU CA NET ROI NGUON V2.png');pic.save(photo)
out=dict(source=src,source_SHA256=before[0],current_SHA256=before[1],records=records,source_proof_photo=photo,physical_scale=1.,one_bank_for_all13=True,PDF_sample_written=False,new_font=False,status='BỘ CHỮ NGUỒN V2: cần đọc từng chữ và kiểm hình thức. Chưa ghi PDF.',corrections=['Giữ ba phần mực thật của chữ 5; bản trước đã bỏ mất phần chân vì chỉ giữ thành phần lớn nhất, không dùng bản đó.','Dùng chữ 9 sạch từ nhãn 4SL16/9 trang 8, thay ứng viên trang 4 có vùng xám dưới chữ.'],font_source_uncertainty_pt=.24,contour_strategy='Nếu dùng nét PDF: bám alpha xám thực nhiều mức; không dùng một ngưỡng nhị phân duy nhất làm mất nét chân/đổi lỗ chữ. Giữ nguyên kích thước vật lý của chữ thật; chỉ dịch vị trí đặt chữ.')
Path(fresh(root/'GLYPH THAT DAY DU GIU CA NET ROI NGUON V2.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('12 source glyphs V2, PDF not written; source/current hashes unchanged',flush=True)
