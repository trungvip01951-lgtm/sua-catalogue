from catwork import start,fresh,HERE
S,D,N=start()
import sys;sys.path.insert(0,str(HERE))
from catfix.vector import Editor
from catfix.otext import OutlineText
from catfix.recipes import Job
from catfix import verify
from g01_fontbank import make_regular
from g02_editlib import draw_page
from pathlib import Path
import json,pickle,hashlib,time

NAME='Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf'
src=S.result(NAME);dst=fresh(S.dst(NAME,sub='G02 (gồm cả G01)'))
assert hashlib.sha256(Path(src).read_bytes()).hexdigest()=='d1ba36df84342b3949f445dee82abc557240bf099ef98002319614a080108dae'
plans=json.loads(Path(S.report('G02/ke-hoach-ve.json')).read_text(encoding='utf-8'))
job=S.job(NAME,sub='G02 (gồm cả G01)',src=src);T=job.T
T.__dict__.update(pickle.loads(Path(S.report('G02/nhan-dung-cho-ve.pkl')).read_bytes()));T.E=job.E
Es=Editor(S.src(NAME));Ts=OutlineText(Es)
Ts.__dict__.update(pickle.loads(Path(S.report('G01/g01-source-glyphs.pkl')).read_bytes())['data']);Ts.E=Es
U,F=make_regular(Ts)
edits=[]
for ps in ['9']+[x for x in plans if x!='9']:
    rec=draw_page(job,T,U,ps,plans[ps]);edits.append(rec)
    print('ĐÃ VẼ',ps,rec['curve_count'],'đường; nhãn',len(rec['labels']),'trục',len(rec['axes']),flush=True)
    if ps=='9':
        sample=fresh(S.report('G02/mau-trang-9-nghiem-thu.pdf'));job.E.save(sample)
        r=rec['allowed'];rect=(r[0]-24,r[1]-24,r[2]+5,r[3]+5)
        verify.compare_sheet(src,sample,[(8,rect,'Mẫu trang 9: 8 đường khớp bảng, viền trắng chép cùng hình chữ gốc')],fresh(S.report('G02/mau-truoc-sau-trang-9-nghiem-thu.png')),dpi=180)
        Path(fresh(S.report('G02/mau-sai-lech-trang-9-nghiem-thu.json'))).write_text(json.dumps(plans['9'],ensure_ascii=False,indent=1),encoding='utf-8')
        S.progress('G02','ĐANG LÀM','Mẫu trang 9 nghiệm thu: chép nguyên mẫu viền trắng gốc theo phép biến đổi của chữ xanh, đã kiểm đủ bộ chữ/viền cho 21 trang; 8/8 đường đi qua mọi số bảng. Tiếp tục 20 biểu đồ còn lại.')
        print('MẪU TRANG 9 ĐÃ LƯU',sample,flush=True)
Path(fresh(S.report('G02/cac-vung-da-ve.json'))).write_text(json.dumps(edits,ensure_ascii=False,indent=1),encoding='utf-8')
job.save();print('ĐÃ LƯU FILE',dst,flush=True)
check=job.check()
Path(fresh(S.report('G02/kiem-cau-truc-va-ngoai-vung.json'))).write_text(json.dumps(check,ensure_ascii=False,indent=1,default=str),encoding='utf-8')
print('NGHIỆM THU',check['ok'],'unexpected',check['unexpected'],'missing',check['missing'],'structure',check['structure'],flush=True)
for ps,plan in plans.items():
    p=int(ps)-1;r=next(r['allowed'] for r in edits if r['page']==p+1)
    # Chụp đủ biểu đồ cả vạch/nhãn trục; bảng phía trên/dưới vẫn hiện một phần để kiểm bảo toàn.
    rect=(max(0,r[0]-50),max(0,r[1]-35),min(590,r[2]+10),min(830,r[3]+25))
    verify.compare_sheet(src,dst,[(p,rect,'Trang '+ps+' | '+str(len(plan['curves']))+' đường')],fresh(S.report('G02/so-sanh-trang-'+ps+'.png')),dpi=160)
    print('ẢNH TRƯỚC/SAU',ps,flush=True)
job.close();Es.close()
