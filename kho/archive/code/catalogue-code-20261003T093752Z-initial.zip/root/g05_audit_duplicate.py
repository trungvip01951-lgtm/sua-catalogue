from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,numpy as np,sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from PIL import Image
P='G05/KIEM TOAN TOAN BO/'
data=json.loads(Path(S.report(P+'NGHIEM THU QH.json')).read_text(encoding='utf8'));pnts=data['points'];t=TABLES['6SP36'];qs=t['Q'];cases=[]
for i in [18,19]:
 row=t['rows'][i];pp=[p for p in pnts if p['family']=='6SP36' and p['row']==i+1]
 fits=[]
 for c in data['curves']:
  if c['family']!='6SP36' or any(v is None for v in c['H_curve']):continue
  devs=[abs(a-b) for a,b in zip(c['H_curve'],row['H'])];limits=[max(1,.02*h) for h in row['H']]
  fits.append(dict(curve_row=c['row'],curve_model=c['curve_model'],all_Q_within_nominal_tolerance=all(d<=e for d,e in zip(devs,limits)),max_deviation_m=max(devs),sum_deviation_m=sum(devs),mismatches=[q for q,d,e in zip(qs,devs,limits) if d>e]))
 fits.sort(key=lambda c:c['sum_deviation_m'])
 cases.append(dict(table_row=i+1,printed_model='6SP36-26',kW=37,HP=50,voltage='3 pha 380–415 V',Q_m3h=qs,H_m=row['H'],matched_curve_label=row['curve_model'],points=pp,matching_to_all_21_curves=fits,unique_nominal_match=sum(c['all_Q_within_nominal_tolerance'] for c in fits)==1))
out=dict(source=data['output_sha256'],cases=cases,dimension_page=8,dimension_6SP36_row26=dict(model='6SP36-26',DN='3 1/4 inch',P_mm=2768,Ms_mm=None,Mt_mm=1208,Ts_mm=None,Tt_mm=3976,weight_P_kg=55.7,weight_Ms_kg=None,weight_Mt_kg=117.3,weight_Ts_kg=None,weight_Tt_kg=173.0),dimension_6SP36_row30=dict(model='6SP36-30',DN='3 1/4 inch',P_mm=3152,Ms_mm=None,Mt_mm=1208,Ts_mm=None,Tt_mm=4360,weight_P_kg=68.9,weight_Ms_kg=None,weight_Mt_kg=117.3,weight_Ts_kg=None,weight_Tt_kg=186.2),dimension_row28_present=False,dimension_note='Trang 8 có hàng 6SP36-26 rồi đến 6SP36-30; không có hàng 6SP36-28 và không có hàng 26 lặp lần hai. Không suy ra kích thước hàng H0=378.',conclusion='Đối chiếu Q-H theo nhãn đường cho thấy dấu hiệu mã 26 bị lặp tại hàng H0=378. Kết quả unique_nominal_match cho phép root đánh giá căn cứ nội bộ đổi mã thành 28; chưa sửa PDF. Nghiệm thu sai số và danh tính vẫn ghi riêng.')
Path(fresh(S.report(P+'HAI HANG 6SP36-26 - CAN CU NOI BO.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
im=Image.open(S.report(P+'CHI TIET/trang 8 - kich thuoc.png'));w,h=im.size
# Giữ nguyên pixel crop, phóng hai lần để đọc hai dòng nguồn 26/30.
im.crop((round(.139*w),round(.879*h),round(.471*w),round(.953*h))).resize((round(.664*w),round(.148*h)),Image.Resampling.NEAREST).save(fresh(S.report(P+'CHI TIET/6SP36 - kich thuoc 26 va 30.png')))
print('DUPLICATE',[dict(row=c['table_row'],unique_nominal_match=c['unique_nominal_match'],best=c['matching_to_all_21_curves'][:3],numeric_status={s:sum(p['confidence_status']==s for p in c['points']) for s in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']}) for c in cases],flush=True)
