from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json
from PIL import Image
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));catalog=json.loads((root/'BANG NGUON VA NHAN HIEN HANH.json').read_text(encoding='utf8'))
for rec in catalog['tables']:
 name=f"BANG NGUON {rec['page']:02} {rec['table_model']}.png";im=Image.open(root/name).convert('RGB');w,h=im.size;im.crop((int(w*.45),0,w,h)).save(fresh(root/'SOI BANG SO'/name))
print('17 source-only numeric areas, original600dpi samples without extra resampling',flush=True)
