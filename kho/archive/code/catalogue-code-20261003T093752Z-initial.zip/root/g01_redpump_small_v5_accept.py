"""Independent read-only acceptance of existing RAM glyphs and unedited source crops."""
from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.ndimage import label,binary_fill_holes
import fitz
from catfix import verify
from g04_source_glyph_source_edge_math import sample_path

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
F=M/'CHU NHO BIEN NGUON KHONG EP MUC RAM V5'
O=Path(S.report('G04/g01 KIEM DOC LAP CHU NHO REDPUMP RAM V5'))
J=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Af=F/'RENDER ACTUAL RAM/13 NHAN MOT MAU VA3LOI ACTUAL RAM.json'
Gf=F/'12 GLYPH NHO BIEN MOT MAU RAM V2.json'
Bf=P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json'
Wf=P/'CHU NGUON ALPHA THU DO DOC V2.json'
Cf=M/'CHU5 SACH NGUON P8 VA2 KY TU CUNG KIEU LAN1/5 CUNG KIEU2 KY TU NGUON VA CO.json'
A,G,B,W,C=map(J,[Af,Gf,Bf,Wf,Cf])
vv={r['character']:r for r in G['records']};bb={r['character']:r for r in B['records']}
guards={Path(A['source']):A['source_SHA256'],Path(A['current']):A['current_SHA256'],Path(A['M1']):A['M1_SHA256']}
for p in [Af,Gf,Bf,Wf,Cf]:guards[p]=sha(p)
for p,h in guards.items():assert sha(p)==h
assert A['source_SHA256']=='a01b7f84c0ebb4960a6b9601d98a04420c4c00f8bf1d48a23e1bde4e8b084038'
assert A['uniform_glyph_fill_RGB']==[63,63,63] and A['uniform_glyph_opacity']==1.
assert len(A['placements'])==13 and len(vv)==12
for ch,r in vv.items():
    source=bb[ch]
    assert r['source_page']==source['source_page'] and r['source_word']==source['source_word']
    assert r['source_page_box']==source['source_page_box']
    assert np.array_equal(np.array(r['source_alpha']),np.array(source['source_alpha']))

# Source evidence is a plain read/render of the original PDF at the original
# position. It includes the actual source grid/curve/JPEG; no cleanup or retouch.
source_images=[]
for dpi in (150,600):
    name=f'g01_NGUON THAT 13 NHAN TRANG8 {dpi}dpi KHONG CHINH DIEM ANH.png'
    fp=Path(fresh(O/name));verify.crop(A['source'],7,tuple(W['source_rect']),dpi).save(fp)
    source_images.append({'file':str(fp),'SHA256':sha(fp),'source_PDF_SHA256':A['source_SHA256'],'source_page':8,'source_rect_bottom_left':W['source_rect'],'dpi':dpi,'unaltered_PDF_render':True})

evidence=[]
for p in A['images']:
    p=Path(p);evidence.append({'file':str(p),'SHA256':sha(p),'opened_directly':True})
source5_images=[]
for model in ['4SL16/25','4SL16/5']:
    for dpi in (150,600):
        fp=M/'CHU5 NGUON P8 DOI CHIEU LAN1'/f'{model.replace("/","_")} NGUYEN CUM{dpi}.png'
        source5_images.append({'file':str(fp),'SHA256':sha(fp),'model':model,'page':8,'dpi':dpi,'opened_directly':True})
extra_images=[P/'NHAN NGUON CHINH TEP 600dpi.png',P/'TIEN TO 4SL16 NGUYEN KHOANG CHU NGUON.png',P/'CHU9 SACH NGUON 3SL4_9 V3.png']
extra_evidence=[{'file':str(p),'SHA256':sha(p),'opened_directly':True} for p in extra_images]

doc=fitz.open(A['source']);m1=fitz.open(A['M1'])
source_image_info=[]
for q in doc[7].get_image_info(xrefs=True):
    if q['xref']:
        raw=doc.extract_image(q['xref']);source_image_info.append({'xref':q['xref'],'width':q['width'],'height':q['height'],'transform':q['transform'],'embedded_image_bytes_SHA256':hashlib.sha256(raw['image']).hexdigest()})
source_font_count=len(doc[7].get_fonts(full=True));m1_font_count=len(m1[7].get_fonts(full=True));pageheight=float(doc[7].rect.height)
doc.close();m1.close()

bad={'4SL16/25':'5: dáng đầu tròn hơn; chân gồm các mảnh xám rời rõ, đọc 25 dựa vào ngữ cảnh. Chưa đạt hình thức số5 nguồn p8.',
     '4SL16/9':'9: lỗ trên còn mở, nhưng phần chân dưới phình thành khối xám đậm hơn nguồn p8/donor3SL4/9. Chưa đạt dáng chân9.',
     '4SL16/5':'5: như /25, các mảnh chân lộ rõ ở150 và600; chưa đạt hình thức dù nhận ra mã theo ngữ cảnh.'}
rows=[];issues=[]
for i,r in enumerate(A['placements']):
    metrics=[]
    for z in A['actual_RAM_metrics']:
        if z['model']!=r['model'] or z['dpi']!=600:continue
        old=np.array(z['old_RGB']);new=np.array(z['new_RGB']);record={'dpi':600,'crop_rect_bottom_left':z['rect'],'old_RGB_shape':list(old.shape),'new_RGB_shape':list(new.shape)}
        for tag,a in [('source_assembled_M1',old),('new_RAM',new)]:
            gray=a.mean(2);yy,xx=np.nonzero(gray<224)
            record[tag+'_optical_bbox_gray_lt224']=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]
            record[tag+'_RGB_min']=a.min((0,1)).tolist()
        record['word_ink_integral_relative_error_not_a_font_gate']=z['relative_actual_ink_error'];metrics.append(record)
    directread=r['model']
    rows.append({'index':i+1,'model':r['model'],'literal_read150_and600':directread,'literal_correct':True,
        'physical_box_bottom_left':r['physical_box'],'original_advance_baseline_metadata_kept_in_RAM':r['chars'],
        'curve_grid_clearance_pt_planned_not_actual_path_QA':r['original_nominal_box_clearance_pt'],
        'visual_spacing':'Không thấy chạm/gạch xuyên nhãn trên toàn biểu đồ150/600; /12 dịch sang ô kế để tránh nét theo bố trí.',
        'visual_typeface_acceptance':'CHƯA ĐẠT' if r['model'] in bad else 'CHƯA CHỐT toàn bộ kiểu chữ; đọc mã/giãn cách tốt, không suy từ đọc được thành phông ĐẠT.',
        'observation':bad.get(r['model'],'Mã đọc rõ hơn nguồn mờ; lỗ 0/6/8/4 nhìn mở khi có ký tự đó. Dáng/đậm toàn bộ còn phụ thuộc xử lý bộ5/9 và nghiệm thu cuối.'),
        'actual_metrics_read':metrics,'sheet600_row_top_pixel':70+i*180,'sheet150_row_top_pixel':70+i*90})
    for c in r['chars']:
        ch=c['character']
        if ch not in '59':continue
        p=np.concatenate([sample_path(q['path'],count=128) for part in vv[ch]['parts'] for q in part['loops']]);ox,oy=c['page_origin'];px=np.column_stack([ox+p[:,0]*.12,oy-p[:,1]*.12])
        bbox=[float(px[:,0].min()),float(px[:,1].min()),float(px[:,0].max()),float(px[:,1].max())]
        topbbox=[bbox[0],pageheight-bbox[3],bbox[2],pageheight-bbox[1]]
        src=vv[ch];alpha=np.array(src['source_alpha']);topo=[]
        for t in [.085,.15,.25,.5]:
            mask=alpha>=t;_,n=label(mask);_,h=label(binary_fill_holes(mask)&~mask)
            ys,xs=np.nonzero(mask);topo.append({'alpha_level':t,'components':int(n),'holes':int(h),'bbox600':[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)]})
        srcrect=next(z['source_page_rect'] for z in W['records'] if z['model']==r['model'])
        issues.append({'model':r['model'],'character':ch,'RAM_page':8,'native_bottom_left_bbox_approx':bbox,'top_left_bbox_approx':topbbox,
            'source_original_same_model_page':8,'source_original_same_model_rect_bottom_left':srcrect,
            'glyph_donor_page':src['source_page'],'glyph_donor_word':src['source_word'],'glyph_donor_box_bottom_left':src['source_page_box'],
            'source_alpha_topology_by_threshold_not_literal_font_topology':topo,'new_geometric_components_and_counters':src['expected_topology'],
            'source_native_pixel_uncertainty_pt':src['source_native_pixel_uncertainty_pt'],
            'reported_geometric_mass_error_not_font_gate':src['vector_optical_area_px']/src['source_area_px']-1,
            'failure_observation':bad[r['model']],
            'source_qualification':'Donor5 p5 đã có3mảnh từJPEG: không gọi mọi khe là nét mới tự tạo. V5 tô một màu làm mảnh rời/độ đậm nhìn lộ hơn và hình5 hẹp hơn mẫu sạchp8.' if ch=='5' else 'Donor9 p3 chỉ1cụm/1lỗ tại ngưỡng0,085, nhưng tail trongRAM phình rõ; số mảnh/lỗ giống nhau không chứng minh dáng chân đúng.'})

font_limits={'source_page8_embedded_fonts_count':source_font_count,'M1_page8_embedded_fonts_count':m1_font_count,
 'source_nominal_font_name_and_size':'CHƯA THỂ XÁC MINH: chữ nguồn nằm trong ảnh quét, không có chương trình phông/cỡ danh nghĩa.',
 'copy_scale':1.,'unchanged_advance_and_baseline':'Đọc metadata tọa độ cùng atlas; kiểu chữ ĐẠT không suy từ scale1. Cỡ hộp mực phụ thuộc mức xám/pha điểm ảnh nguồn, không ép bằng một ngưỡng.',
 'baseline_visual':'Không thấy lệch chân chữ lớn/nhảy dòng tại150. Các số0/8/9 có hộp mực khác nhau theo JPEG; cần giữ đặc điểm nguồn thay vì cưỡng bức chiều cao bằng nhau.',
 'uniform_gray':'Giữ một màuRGB63/opacity1 theo hình họcRAM. Điểm đậm ảnh600 đọc minRGB62/63/62 ở13 nhãn; sai1mức do chuyển/render màu không bị coi là nhiều màu font.',
 'known_shape_failures':'5/9 chưađạt vì nhìn hình thật ở150/600 và so vịtrínguồn, không dùng tíchphân làm phépduyệt riêng.'}
clean_candidate=[{k:r[k] for k in ['character','source_page','source_word','source_page_box','candidate_ink_size_pt','old_ink_size_pt','ink_size_difference_pt','topology']} for r in C['records']]

for p,h in guards.items():assert sha(p)==h
result={'scope':'Chỉ kiểm chữ nhỏ RedpumpSL RAMV5; chưa PDF2/canonical/TIEN DO và không sửa tệp g18.',
 'RAM_actual_json':str(Af),'RAM_actual_json_SHA256':sha(Af),'RAM_geometry_json':str(Gf),'RAM_geometry_SHA256':sha(Gf),
 'actual_images_opened':evidence,'unaltered_source_images':source_images,'existing_actual_source5_images_opened':source5_images,'extra_source_images_opened':extra_evidence,
 'source_page8_embedded_images_read':source_image_info,'13_label_visual_read':rows,'specific_5_9_failure_coords':issues,
 'font_scale_advance_baseline_limits':font_limits,'better_source5_candidate_prior_g18_data_read':{'file':str(Cf),'SHA256':sha(Cf),'records':clean_candidate,'status':'CHƯA CHỐT donor: còn cần đối chiếu4/S trực tiếp và chọn nét nguyên nguồn; không tự sửa bank.'},
 'literal_read_count':sum(r['literal_correct'] for r in rows),'model_count':len(rows),'known_shape_failure_models':list(bad),
 'overall_visual_font_status':'CHƯA ĐẠT: 5 ở2model và chân9 ở1model chưa đồng bộ đúng dáng nguồn. 13mã đọc được không phải phôngPASS.',
 'recommendation':'Giữ một màu chung. Ưu tiên tìm/chọn donor5 sạch ngay nhãn4SL16/25p8 đã có hồ sơ, sau khi chứng minh4/S cùng kiểu/cỡ; kiểm chân9 với nguyên nhãn nhỏp8 hoặc donor9 sạch chính Redpump. Không nối mảnh phỏng đoán, không đổi xám theo chữ, không co nét chỉ để ép tíchphân.',
 'no_independent_RAM_PDF_byte_read':'RAM chưa có PDF2: chỉ đọc ảnh thật/hình học đã lưu, không tính đã kiểm byte/font resource PDF mới.',
 'guards_after_read':{str(p):sha(p) for p in guards},'retouched_images_written':False,'unaltered_original_PDF_evidence_crops_written':len(source_images),
 'PDF_written':False,'g18_files_modified':False,'canonical_written':False,'TIEN_DO_written':False}
fp=Path(fresh(O/'g01_NGHIEM THU13 CHU NHO RAM V5 - HINH THAT KHONG SUY TU TICH PHAN.json'));fp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
lines=['# Kiểm chữ nhỏ Redpump SL RAM V5 độc lập','',
 '**CHƯA ĐẠT hình thức chữ:** số5 ở /25 và /5 lộ các mảnh chân gãy; số9 ở /9 phình chân. 13 mã đọc được, khoảng đặt nhãn nhìn tốt; không tính đó là phông đạt. Chưa ghi PDF mới.','',
 'Đã mở13nhãn/biểuđồ150và600 điểmảnh mỗiinch. So nguyên chữ nhỏ của chính Redpump p8 tại đúng vị trí; đối chứng thêm nguồn donor thật. Một màu xám chung RGB63 và độ đục1 được giữ, không đề nghị đổi màu từng chữ.','',
 '| STT | Tệp | Trang | Việc | Trước | Sau RAM V5 | Nghiệm thu | Chứng cứ |','|---|---|---|---|---|---|---|']
for z in rows:lines.append(f"| {z['index']} | Redpump SL | 8 | Nhãn {z['model']} | JPEG nguồn nhỏ/mờ | {z['observation']} | {z['visual_typeface_acceptance']} | Ảnh150/600; hộpPDF {z['physical_box_bottom_left']} |")
lines.extend(['','| Nhãn/ký tự | Vùng RAM (x0,y0,x1,y1; điểm PDF; gốc dưới trái) | Vùng nguyên nhãn nguồn p8 | Kết luận/giới hạn |','|---|---|---|---|'])
for z in issues:lines.append(f"| {z['model']} / {z['character']} | {[round(x,6) for x in z['native_bottom_left_bbox_approx']]} | {z['source_original_same_model_rect_bottom_left']} | {z['failure_observation']} {z['source_qualification']} |")
lines.extend(['','**Phân biệt nguồn mờ và lỗi chuyển hình:** donor5 hiện lấy4SL3/35p5, đã có3mảnh ở mức mực0,085. Vì vậy không khẳng định mọi khe gãy là do V5 tạo mới. Tuy nhiên V5 làm các mảnh đậm/rời thấy rõ hơn ở cỡ150; dáng5 hẹp, đầu tròn so số5 nguyên nhãn sạch4SL16/25p8. Đây là lý do chưa nghiệm thu chữ, không phải vì thiếu nguồn thì tự nối lại phỏng đoán.',
 'Chân9 vẫn thuộc1cụm và có1lỗ nhưng nhìn thành khối đậm/phình hơn nguyên nguồn. Giữ topology (số mảnh/lỗ) chưa đủ chứng minh đúng dáng. Tíchphân5+57,39%/9+36,03% chỉ ghi giới hạn đo mựcJPEG, không làm điều kiện duyệt duy nhất.',
 '**Cỡ/khoảng/chân chữ:** metadata giữtỷlệ1 và tọa độ khoảng tiến/đường chân của bộ chữ. Không thấy nhảy chân hay chạm đường/lưới lớn ở150. Hộp mực600 phụ thuộc ngưỡng xám, nên không gọi đó là cỡ phông chính xác. Nguồn p8 và M1 đều0phông nhúng; danh tính/cỡ phông danh nghĩa chưa thể truyra từJPEG.',
 'Có ứng viên5 sạch ngay4SL16/25p8 cùng hồsơ2ký tự4/S, nhưng chưa tự xácnhận donor hoặc đổi bộ chữ. Tác nhân ghi cần đọc trực tiếp ứng viên và kiểm cùng kiểu/cỡ trước dùng; không thay font ngoài, không chỉnh xám theo từng ký tự, không ép tíchphân.',
 '', 'Ảnh nguyên nguồn do em chỉ đọc/render PDF gốc, giữ nguyên chữ/nét/lưới và điểm ảnh; không retouch (tô sửa ảnh):'])
for e in source_images:lines.append(f"- [{Path(e['file']).name}]({Path(e['file']).name}) — SHA256 `{e['SHA256']}`.")
lines.extend(['','Ảnh RAM đã mở (SHA256 là mã kiểm tệp):'])
for e in evidence:lines.append(f"- [{Path(e['file']).name}](<{e['file']}>) — `{e['SHA256']}`.")
lines.extend(['',f"[Phiếu tọa độ/số đo chi tiết]({fp.name}) — SHA256 `{sha(fp)}`.",
 'Nguồn a01b7f…4038, bản giao b7c1fe…d435, M1 1059e4…4c20 và mọi tệp g18 đã đọc giữ nguyên mã kiểm. Không sửa TIEN DO.md hoặc bất kỳ PDF nào.'])
rp=Path(fresh(O/'g01_BAO CAO8 COT CHU NHO REDPUMP V5 VA TOA DO5 9.md'));rp.write_text('\n'.join(lines)+'\n',encoding='utf8')
print('REPORT',rp,'SHA',sha(rp),flush=True)
print('JSON',fp,'SHA',sha(fp),flush=True)
print('SOURCE_EVIDENCE',[(e['file'],e['SHA256']) for e in source_images],flush=True)
print('RESULT',len(rows),'literal read; known shape failures',list(bad),flush=True)
