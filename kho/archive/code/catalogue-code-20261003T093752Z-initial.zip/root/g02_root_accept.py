from pathlib import Path
# Đọc lại toàn bộ bản đã lưu, chỉ tạo tệp nghiệm thu bổ sung; không sửa PDF.
code = Path(__file__).with_name('g02_accept.py').read_text(encoding='utf-8')
old = "S.report('G02/nghiem-thu-doc-lap.json')"
assert code.count(old) == 1
code = code.replace(old, "S.report('G02/NGHIEM THU BO SUNG ROOT.json')")
exec(compile(code, 'g02_root_accept_readonly', 'exec'), globals())
