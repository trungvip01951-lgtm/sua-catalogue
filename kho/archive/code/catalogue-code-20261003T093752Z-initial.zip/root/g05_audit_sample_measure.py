from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter1d
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,csv
P='G05/KIEM TOAN TOAN BO/';O='G05/MAU SUA DUONG/PHAM VI DA BO NET CHUA RO 2/'
rec=json.loads(Path(S.report(O+'TOA DO VA PHUONG PHAP.json')).read_text(encoding='utf8'));axes=json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'));out=[];summ=[]
for p in rec['panels']:
 f=p['family'];b=next(z for z in axes if z['family']==f);t=TABLES[f];n=len(t['rows']);r=p['rect'];s=72/p['dpi'];xt=np.array(b['xticks']);yt=np.array(b['yticks']);after=Image.open(S.report(O+f+'-sau.png')).convert('RGB');before=Image.open(S.report(O+f+'-truoc.png')).convert('RGB');g=np.array(after.convert('L'),float);old=np.array(before.convert('L'),float);ink=255-g;top=round((r[3]-b['y1'])/s);bot=round((r[3]-b['y0'])/s);draw=ImageDraw.Draw(after)
 cx=lambda q:(float(np.interp(q,xt[:,0],xt[:,1]))-r[0])/s;hfun=lambda y:float(np.interp(r[3]-y*s,yt[:,1],yt[:,0]))
 title_x=round(cx(b['Qmax']*.78));title_y=round((r[3]-float(np.interp(b['Hmax']*.85,yt[:,0],yt[:,1])))/s)
 ink[top:title_y,title_x:]=0
 changed={c['rank']:c for c in p['curves']};kept={c['rank']:c for c in p['kept_curves']}
 qs=[36,42] if f=='6SP30' else [72,78]
 for q in qs:
  x=cx(q);sets=[];counts=[]
  offsets=list(range(-20,21,2)) if q<qs[-1] else list(range(-20,-1,2))
  for dx in offsets:
   xx=round(x+dx);v=np.mean(ink[:,xx-1:xx+2],axis=1);v=gaussian_filter1d(v,.35);pk,_=find_peaks(v,prominence=14,height=52,distance=4);pk=pk[(pk>top+5)&(pk<bot-5)];counts.append([dx,len(pk)])
   if len(pk)!=n:continue
   cy=[]
   for y in pk[::-1]:
    ids=np.arange(y-1,y+2);wt=np.maximum(0,v[ids]-np.min(v[ids]));cy.append(float(np.sum(ids*wt)/max(sum(wt),1e-8)))
   sets.append((xx,cy))
  for k,row in enumerate(t['rows']):
   h=row['H'][t['Q'].index(q)];item=dict(family=f,rank=k+1,source_label=kept.get(k+1,{}).get('actual_source_label',row['curve_model']),table_model=row['curve_model'],Q=q,H_table=h,curve_changed=k+1 in changed,slices=len(sets),profile_counts=counts)
   if len(sets)<3:item.update(status='CHƯA THỂ',H_read=None,reason='Không phân đủ số nét theo rank nguồn');out.append(item);continue
   xx=np.array([z[0] for z in sets]);yy=np.array([z[1][k] for z in sets]);fit=np.polyfit(xx,yy,1);cy=float(np.polyval(fit,x));spread=float(max(abs(yy-np.polyval(fit,xx))));hc=hfun(cy);dev=abs(hc-h);lim=max(1,.02*h);status='ĐẠT' if dev<=lim else 'CHƯA ĐẠT'
   if spread>3.5:status='CHƯA THỂ'
   if item['source_label']!=row['curve_model']:status='CHƯA THỂ'
   item.update(status=status,H_read=hc,deviation_m=dev,limit_m=lim,local_spread_px=spread,reason='Nhãn nguồn-9/bảng-8 chưa được xác định' if item['source_label']!=row['curve_model'] else '',xpx=x,ypx=cy)
   out.append(item);color=(0,130,30) if status=='ĐẠT' else (230,100,0);draw.ellipse((x-4,cy-4,x+4,cy+4),outline=color,width=2)
 after.save(fresh(S.report(O+f+'-DO MOC V2.png')))
 pts=[v for v in out if v['family']==f];ss=dict(family=f,count=len(pts),changed_count=sum(v['curve_changed'] for v in pts),nominal_counts={st:sum(v['status']==st for v in pts) for st in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']},changed_nominal_counts={st:sum(v['curve_changed'] and v['status']==st for v in pts) for st in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']});summ.append(ss);print(ss,flush=True)
res=dict(summary=summ,points=out,measurement='Independent gray profiles and native rank at all64 right-side points. Nominal comparison only, confidence/axis uncertainty awaits final PDF. Source SP30-9 identity retained unknown.')
Path(fresh(S.report(O+'DOC LAI 64 MOC ANH V2.json'))).write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf8')
with open(fresh(S.report(O+'DOC LAI 64 MOC ANH V2.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 fields=list(dict.fromkeys(k for v in out for k in v if k!='profile_counts'));w=csv.DictWriter(fp,fields,extrasaction='ignore');w.writeheader();w.writerows(out)
print('All changed',sum(v['curve_changed'] for v in out),'statuses',{st:sum(v['curve_changed'] and v['status']==st for v in out) for st in ['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']},flush=True)
