"""Read old RAM contour guard diagnostics; no files or catalogue mutations."""
from catwork import start,HERE
S,D,N=start()
from pathlib import Path
import json,sys,numpy as np,cv2
from scipy.ndimage import label,binary_fill_holes,distance_transform_edt
sys.path.insert(0,str(HERE))
from g04_source_glyph_core_math import hole_centres,topology
P=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1/CHU NHO MOT MAU RAM V2'))
V=json.loads((P/'12 GLYPH NHO BIEN MOT MAU RAM V2.json').read_text(encoding='utf8'))
for char in ['0','9']:
    v=next(r for r in V['records'] if r['character']==char);a=np.pad(np.array(v['source_alpha']),8);h,w=a.shape;up=8
    loops=[]
    for p in v['parts']:
        for lp in p['loops']:
            pts=[];cur=first=None
            for op,ps in lp['path']:
                if op=='m':cur=np.array(ps[0]);first=cur.copy();pts.append(cur)
                elif op=='l':cur=np.array(ps[0]);pts.append(cur)
                elif op=='c':
                    z=np.array(ps);t=np.linspace(0,1,21)[1:,None]
                    q=(1-t)**3*cur+3*(1-t)**2*t*z[0]+3*(1-t)*t**2*z[1]+t**3*z[2]
                    pts.extend(q);cur=z[2]
                elif op=='h':pts.append(first)
            loops.append(np.rint((np.array(pts)+8)*up).astype('int32'))
    mask=np.zeros((h*up,w*up),'uint8');cv2.fillPoly(mask,loops,1)
    nh=hole_centres(mask>0)/up;sh=hole_centres(a>=.25)
    support=cv2.resize((a>=.085).astype('uint8'),(w*up,h*up),interpolation=cv2.INTER_NEAREST)
    dist=distance_transform_edt(support==0)/up
    y,x=np.where(support);sb=np.array([x.min()/up,y.min()/up,(x.max()+1)/up,(y.max()+1)/up])
    y,x=np.where(mask);nb=np.array([x.min()/up,y.min()/up,(x.max()+1)/up,(y.max()+1)/up])
    print(char,'holesSource',sh-8,'holesCandidate',nh-8,'distance',np.linalg.norm(nh[:,None,:]-sh[None,:,:],axis=2).tolist(),
          'outSupportMax',dist[mask>0].max(),'bboxsource',sb-8,'bboxnew',nb-8,'bboxerr',abs(sb-nb).max(),'top',topology(mask>0),flush=True)
