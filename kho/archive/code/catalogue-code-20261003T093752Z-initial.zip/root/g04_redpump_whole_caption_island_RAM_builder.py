"""Pure CATFIX RAM builder: whole original Redpump caption islands, no fonts.

No file, top-level task or PDF writer. The original image bytes/CTMs stay intact.
Original source paint outside the rebuild region and complete caption islands is
retained with PDF clipping geometry; no white/color eraser or pixel mask is made.
"""
def build_caption_islands_RAM(b,a,islands,holes,eta):
    import json,hashlib,numpy as np
    from catfix.vector import Editor
    from catfix.cs import Instr,Num
    from catfix.raster import Raster
    def I(op,*xs):return Instr([Num(float(z)) for z in xs],op)
    def re(bb):return I('re',bb[0],bb[1],bb[2]-bb[0],bb[3]-bb[1])
    def corners(bb):return [[bb[0],bb[1]],[bb[2],bb[1]],[bb[2],bb[3]],[bb[0],bb[3]]]
    def transform(pts,T):return (np.c_[np.asarray(pts,float),np.ones(len(pts))]@T)[:,:2].tolist()
    def poly(pts):return [I('m',*pts[0])]+[I('l',*p) for p in pts[1:]]+[Instr([],'h')]
    def intersect(x,y):
        z=[max(x[0],y[0]),max(x[1],y[1]),min(x[2],y[2]),min(x[3],y[3])]
        return z if z[2]>z[0] and z[3]>z[1] else None
    def source_complement(T,keep):
        inv=np.linalg.inv(T)
        paths=poly(transform(corners(outer),inv))
        for bb in roi:paths+=poly(transform(corners(bb),inv))
        if keep:
            for bb in restored:paths+=poly(transform(corners(bb),inv))
        return paths+[Instr([],'W*'),Instr([],'n')]

    E=Editor(b['sample'],backend='fitz');P=E.page(7);R=Raster(E)
    tag=next(i for i,z in enumerate(P.ops) if z.op=='BMC' and str(z.operands[0])=='CfxRedpumpWholePage8M1')
    mb=E.mediabox(7);outer=[mb[0]-2,mb[1]-2,mb[2]+2,mb[3]+2]
    roi=b['allowed_bboxes']
    restore_candidates=[b['protected_title_hole']]+[r['proposed_effective_hole_after'] for r in holes['records']]+[z['island_page_bbox'] for z in islands]
    restored=[]
    for bb in restore_candidates:
        for rr in roi:
            x=intersect(bb,rr)
            if x is not None:restored.append(x)
    for k,x in enumerate(restored):
        for y in restored[:k]:assert intersect(x,y) is None,('Overlapping even-odd islands',x,y)
    sourceE=Editor(b['source'],backend='fitz');sourceR=Raster(sourceE)
    sourceim=max(sourceR.images(7),key=lambda z:z.W*z.H)
    source_raw=sourceE.doc.stream_raw(sourceim.ref);source_SHA=hashlib.sha256(source_raw).hexdigest()
    source_hits=[z for z in R.images(7) if z.index<tag and hashlib.sha256(E.doc.stream_raw(z.ref)).hexdigest()==source_SHA]
    assert len(source_hits)==1
    source_current=source_hits[0]
    assert source_current.W==1739 and source_current.H==1237 and np.max(abs(sourceim.ctm-source_current.ctm))<1e-9
    clips=[]
    for image in P.images:
        if image['i']>=tag:continue
        pts=np.asarray(transform([[0,0],[1,0],[1,1],[0,1]],image['ctm']));bb=np.r_[pts.min(0),pts.max(0)].tolist()
        if not any(intersect(bb,rr) is not None for rr in roi):continue
        keep=image['i']==source_current.index
        E.insert_instrs(7,image['i'],[Instr([],'q')]+source_complement(image['ctm'],keep),before=True)
        E.insert_instrs(7,image['i'],[Instr([],'Q')],before=False)
        clips.append(dict(kind='old_image',name=image['name'],old_Do_index=image['i'],source_image_keeps_all_restored_islands=keep,
            CTM=image['ctm'].tolist(),raw_bytes_kept=True))
    oldpaths=[]
    for oi,o in enumerate(P.objs):
        if o['i1']>=tag or o['op']=='n':continue
        bb=[o['bbox'][0]-o['lw'],o['bbox'][1]-o['lw'],o['bbox'][2]+o['lw'],o['bbox'][3]+o['lw']]
        if not any(intersect(bb,rr) is not None for rr in roi):continue
        assert all(z.op in {'m','l','c','v','y','h','re','S','s','f','F','f*','B','B*','b','b*'} for z in P.ops[o['i0']:o['i1']+1])
        E.insert_instrs(7,o['i0'],[Instr([],'q')]+source_complement(o['ctm'],False),before=True)
        E.insert_instrs(7,o['i1'],[Instr([],'Q')],before=False)
        oldpaths.append(dict(old_object=oi,old_i0=o['i0'],old_i1=o['i1'],path_geometry_and_style_unmodified=True))
    deleted_Do=[]
    for label in b['labels']:
        hits=[z['i'] for z in P.images if z['i']>tag and z['name']==label['image_name']]
        assert len(hits)==1
        E.delete_instrs(7,hits);deleted_Do+=hits
    deleted_background=[]
    for oi,o in enumerate(P.objs):
        if o['i0']<=tag or o['op']!='f':continue
        color=P.color_of(oi,'fill')
        if color is not None and np.max(abs(np.asarray(color)-1))<1e-9 and any(np.max(abs(np.asarray(o['bbox'])-np.asarray(rr)))<1e-7 for rr in roi):
            E.delete_instrs(7,range(o['i0'],o['i1']+1));deleted_background.append(dict(old_object=oi,old_i0=o['i0'],old_i1=o['i1']))
    assert len(deleted_background)==2
    # Exclude the complete source islands from every new grid, curve and frame.
    gclip=[re(outer)]+[re(z['island_page_bbox']) for z in islands]+[Instr([],'W*'),Instr([],'n')]
    assert P.ops[tag+1].op=='q'
    E.insert_instrs(7,tag+1,gclip,before=False)
    for r in holes['records']:
        for idx in r['changed_rect_instruction_indices']:E.modify_instr(7,idx,re(r['proposed_effective_hole_after']))
    ec=next(z for z in eta['RAM_rendered_candidates'] if z['pieces']==2)
    eo=P.objs[a['eta_actual']['actual_object']]
    E.delete_instrs(7,range(eo['i0'],eo['i1']))
    E.insert_instrs(7,eo['i1'],[Instr([Num(float(v)) for xy in ps for v in xy],op) for op,ps in ec['actual_RAM_path']],before=True)
    content=E.build(7);E.doc.set_page_content(7,content);E.pages.clear();PR=E.page(7)
    new_tag=next(i for i,z in enumerate(PR.ops) if z.op=='BMC' and str(z.operands[0])=='CfxRedpumpWholePage8M1')
    actual=[]
    for oi,o in enumerate(PR.objs):
        color=PR.color_of(oi,'stroke')
        if o['i0']>new_tag and o['op']=='S' and color is not None and np.max(abs(np.asarray(color)-np.array([134,149,152])/255))<1e-8:
            actual.append((oi,PR.object_pagepath(oi)))
    assert len(actual)==27
    dumps=lambda z:json.dumps(z,separators=(',',':'))
    qh=[]
    for m in a['actual_QH_paths']:
        for part in m['parts']:
            hits=[(oi,path) for oi,path in actual if dumps(path)==dumps(part['path'])]
            assert len(hits)==1,(m['model'],part['object_index'])
            oi,path=hits[0];qh.append(dict(model=m['model'],M1_object=part['object_index'],RAM_actual_object=oi,
                full_path_fingerprint_SHA256=hashlib.sha256(dumps(path).encode()).hexdigest(),full_path_geometry_unchanged=True))
    assert len(qh)==26
    R._imgs.clear()
    newimages=R.images(7)
    actualsource=next(z for z in newimages if z.name==source_current.name and np.max(abs(z.ctm-source_current.ctm))<1e-9)
    assert E.doc.stream_raw(actualsource.ref)==source_raw
    report=dict(method='CATFIX complement geometric clip +13 full original source-caption islands; RAM ONLY',
        actual_source_image_name=str(source_current.name),original_source_image_name=str(sourceim.name),original_source_raw_SHA256=source_SHA,
        original_source_size=[sourceim.W,sourceim.H],original_source_CTM=sourceim.ctm.tolist(),source_raw_bytes_and_CTM_preserved=True,
        new_outline_fonts=0,new_images=0,new_glyph_alpha_masks=0,new_background_white_or_color_paints=0,
        removed_M1_reconstructed_caption_Do_indices=deleted_Do,removed_M1_background_fills=deleted_background,
        old_native_image_clips=clips,old_native_path_complement_clips=oldpaths,
        outer_clip_page_bbox=outer,rebuild_ROIs=roi,restored_source_island_boxes=restored,
        all13_original_caption_page_boxes=[z['island_page_bbox'] for z in islands],new_strokes_exclude_original_caption_islands=True,
        QH26_geometry_kept=qh,QH104_previously_accepted_not_remeasured=True,
        eta_two_cubics_RAM_actual_path=ec['actual_RAM_path'],eta551_observed_geometry_only=True,eta_numeric='CHƯA THỂ: không có bảng sốη.',
        feet5_holes_RAM_accepted_recipe=holes['records'],content_SHA256=hashlib.sha256(content).hexdigest(),
        filesystem_PDF_save_count=0,M2_written=False,canonical_written=False,shared_progress_written=False,
        graphic_acceptance='CHƯA CHỐT; phải xem toàn đảo và các mực đường cũ bị lẫn, không fontPASS từ hash.')
    sourceE.close()
    return E,report,content
