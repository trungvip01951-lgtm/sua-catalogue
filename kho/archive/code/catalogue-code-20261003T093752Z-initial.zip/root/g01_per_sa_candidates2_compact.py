from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));d=json.loads((O/'g01_DO MOC TU TIET DIEN MUC THUC VA VACH ETA - V2 CHO DOC NHAN.json').read_text(encoding='utf8'))
for g in d['graphs']:
 for p in g['points']:
  if p['status_pending_visual'].startswith('ỨNG VIÊN'):
   print(p['page'],p['model'],'Q',p['Q_m3_h'],'Htable',p['H_table_m'],'Hcurve',p['H_curve_measured_m'],'delta',p['delta_H_m'],'unc',p['uncertainty_bound_m'],'threshold',p['tolerance_H_m'],'SOURCE',p['Q_source_native_u'],p['source_section_candidates'][0]['source_native_v'],'status',p['status_pending_visual'])
