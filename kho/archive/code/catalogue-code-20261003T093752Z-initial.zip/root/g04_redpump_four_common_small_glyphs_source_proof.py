"""Four original small source glyph controls; no contour/PDF/bank edits."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
from scipy.ndimage import label
from catfix.vector import Editor
from catfix.raster import Raster
from catfix import verify

M=Path(S.report('G04/REDPUMP DONG BO TOAN TRANG8 MAU1'))
P=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'))
folder=M/'CHU5 9 NGUON THAT NGUYEN CUM VA4 KY TU LAN2'
outdir=folder/'4 KY TU CHUNG NGUYEN NGUON';assert not outdir.exists()
J=lambda p:json.loads(p.read_text(encoding='utf8'))
b=J(M/'TAO MAU1 VA BAO VE NGUON.json')
bank=J(P/'GLYPH THAT DAY DU CUNG BO NGUON V3.json')
raw=J(folder/'NGUYEN CUM NGUON VA TOA DO KHONG LOAI MEP XAM.json')
p8=next(r for r in raw['records'] if r['model']=='4SL16/25')
srcRGB=np.array(p8['RGB'],np.uint8)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guards=[sha(b[k]) for k in ['source','input_current','sample']]
assert guards==[b[k] for k in ['source_SHA256','input_SHA256','sample_SHA256']]
E=Editor(b['source'],backend='fitz');R=Raster(E)
records=[];sheet=Image.new('RGB',(1900,4*260+80),'white');dr=ImageDraw.Draw(sheet);ft=verify._font(18)
cuts={'4':[16,0,46,43],'S':[46,0,76,43],'L':[76,0,100,43],'/':[140,0,153,43]}
for i,(ch,box) in enumerate(cuts.items()):
    old=next(z for z in bank['records'] if z['character']==ch)
    cv=R.render_canvas(old['source_page']-1,old['source_canvas_rect'],dpi=600)
    x0,y0,x1,y1=old['source_render_box'];a=cv.orig[y0:y1,x0:x1].copy()
    x0,y0,x1,y1=box;c=srcRGB[y0:y1,x0:x1].copy()
    # Both images are the native physical scale of600dpi, with no resize used
    # in measurements. Enlarged panels below are evidence display only.
    measurements=[]
    for tag,rgb in [('p5_bank_control',a),('p8_25_control',c)]:
        gray=rgb@np.array([.299,.587,.114]);levels=[]
        for cut in [230,190,150,110]:
            mask=gray<cut;ys,xs=np.where(mask)
            if len(xs):levels.append(dict(gray_threshold=cut,ink_bbox600=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)],
                ink_size_pt=[(int(xs.max())+1-int(xs.min()))*.12,(int(ys.max())+1-int(ys.min()))*.12],components=label(mask)[1]))
        measurements.append(dict(control=tag,RGB_shape=list(rgb.shape),source_RGB_sha256=hashlib.sha256(rgb.tobytes()).hexdigest(),
            RGB=rgb.tolist(),levels=levels,physical_scale=1))
    p8bb=[p8['source_page_box'][0]+box[0]*.12,p8['source_page_box'][3]-box[3]*.12,
        p8['source_page_box'][0]+box[2]*.12,p8['source_page_box'][3]-box[1]*.12]
    records.append(dict(character=ch,bank_source_page=old['source_page'],bank_source_word=old['source_word'],
        bank_source_page_box=[*cv.to_page(old['source_render_box'][0],old['source_render_box'][3]),*cv.to_page(old['source_render_box'][2],old['source_render_box'][1])],
        bank_source_canvas_rect=list(cv.rect0),bank_source_render_box=old['source_render_box'],
        p8_source_word='4SL16/25',p8_source_page_box=p8bb,p8_source_wholeword_box=p8['source_page_box'],
        p8_source_relative_glyph_box600=box,measurements=measurements,
        visual_control='4 open triangular hole; S paired bends; L straight stem/right foot; / oblique bar.',
        limitation='4 p8 có đường bơm màu gần chân; không coi số pixel tối của vùng đó là toàn mực chữ. L và / cần soi mép JPEG; không suy tên phông danh nghĩa.',
        status='ĐỐI CHỨNG NGUỒN4 KÝ TỰ, chưa tự chốt donor/phông từ ngưỡng.'))
    y=70+i*260;dr.text((5,y),ch+' nguyên nguồn p5 / p8 - cỡ600 thật; ô lớn chỉ phóng xem',fill='blue',font=ft)
    sheet.paste(Image.fromarray(a),(500,y));sheet.paste(Image.fromarray(c),(580,y))
    sheet.paste(Image.fromarray(a).resize((a.shape[1]*5,a.shape[0]*5),Image.Resampling.NEAREST),(710,y))
    sheet.paste(Image.fromarray(c).resize((c.shape[1]*5,c.shape[0]*5),Image.Resampling.NEAREST),(1050,y))
    dr.text((1300,y+15),'Không co/giãn, không tẩy mực.\nChữ4 cạnh đường bơm: có giới hạn.\nTên phông/cỡ danh nghĩa: chưa thể.',fill='blue',font=ft)
photo=fresh(outdir/'4 S L SLASH NGUYEN CHINH NGUON P5 P8 KHONG DOI CO.png');sheet.save(photo)
fp=fresh(outdir/'4 KY TU CHUNG SOURCE POSITION CO VA PHASE.json')
Path(fp).write_text(json.dumps(dict(source=b['source'],source_SHA256=guards[0],current_SHA256=guards[1],M1_SHA256=guards[2],
    records=records,image=photo,source_native_pixel_uncertainty_pt=.4801362852213916,
    source_no_font_resources=True,bank_not_changed=True,no_external_font=True,
    PDF_written=False,M2_written=False,canonical_written=False,shared_progress_written=False),ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert guards==[sha(b[k]) for k in ['source','input_current','sample']]
print(fp,flush=True)
