from catwork import start,fresh
S,D,N=start()
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from g04_perotac_audit_labels_manual import MANUAL
from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np,hashlib,math,collections

root=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO'));name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd';assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
axis=json.loads((root/'TRUC NGUON DO LAN3.json').read_text(encoding='utf8'))['graphs'];aold=json.loads((root/'TRUC NGUON DO LAN2.json').read_text(encoding='utf8'))['graphs']
for a in axis:
 if a['family']=='4SA6':
  a['flow_ticks']=[dict(litre_per_minute=k*20,u_native=float(x),value_read_directly=True) for k,x in enumerate([124,201,279,357,435,512,590,668])]
  a['axis_method']='Vạch dài ở biểu đồ H; loại vùng cột chữ 285..331, giữ các vạch thật 124,201,279,357,435,512,590,668; đọc số 0,20,..140 trực tiếp.'
 if a['family']=='6SA15':
  a['flow_ticks']=[t for t in aold[13]['flow_ticks']]
  a['axis_method']='Vạch thật H và nhãn l/min; bỏ cột 996 không trùng vạch số nguồn.'
 vals=[t['litre_per_minute'] for t in a['flow_ticks']];xs=[t['u_native'] for t in a['flow_ticks']];fit=np.polyfit(vals,xs,1);res=np.array(xs)-np.polyval(fit,vals)
 a['calibration']=dict(u_per_l_min=float(fit[0]),u_Q0=float(fit[1]),max_residual_native_px=float(abs(res).max()),printed_unit='l/min',manually_reviewed=True,identity_not_from_table=True)
 assert abs(res).max()<1.1,(a['family'],res)

E=Editor(src);R=Raster(E);allcurves=[];graphs=[]
def peaks_column(mask,wgt,x,top,bottom):
 m=mask[top:bottom+1,x];labels,n=ndimage.label(m);out=[]
 for lab in range(1,n+1):
  ys=np.flatnonzero(labels==lab)+top;ww=wgt[ys,x];v=float(np.average(ys,weights=np.maximum(ww,1)))
  out.append(dict(v=v,lo=int(ys.min()),hi=int(ys.max()),strength=float(ww.sum()),width=float(ys.max()-ys.min()+1)))
 return out
def trace(mask,wgt,seed,left,right,top,bottom,direction):
 pts=[seed.copy()];hist=[(seed['u'],seed['v'])];issues=[];missing=0
 for x in range(seed['u']+direction,(right+1 if direction>0 else left-1),direction):
  if len(hist)>3:
   hh=np.array(hist[-9:]);fit=np.polyfit(hh[:,0],hh[:,1],1);slope=float(fit[0]);pred=float(np.polyval(fit,x))
  else:slope=0;pred=hist[-1][1]
  cand=peaks_column(mask,wgt,x,top,bottom);radius=2.7+min(missing*.12,1.5)
  cand=[z for z in cand if abs(z['v']-pred)<=radius];cand.sort(key=lambda z:abs(z['v']-pred))
  if not cand:
   missing+=1
   if missing>12:break
   continue
  p=cand[0];amb=len(cand)>1 and abs(cand[1]['v']-pred)-abs(p['v']-pred)<1.4
  item=dict(u=x,**p,gap_before=missing,ambiguous=amb,predicted_v=pred)
  if amb:issues.append(dict(u=x,candidates=cand))
  pts.append(item);hist.append((x,p['v']));missing=0
 return pts,issues

for rec,a in zip(DATA,axis):
 pi=rec['page']-1;im=max(R.images(pi),key=lambda im:im.W*im.H);cv=R.canvas(im);rgb=cv.orig.astype(int);lum=cv.orig.astype(float)@np.array([.299,.587,.114]);cr=rgb[:,:,1]-rgb[:,:,0];cb=rgb[:,:,2]-rgb[:,:,0]
 mask=(cr>7)&(cb>9)&(lum>75)&(lum<244);wgt=np.maximum(cr+cb,0)*(255-lum)/255
 frame=a['frame_native'];left=int(math.ceil(frame['left']))+2;right=int(math.floor(frame['right']))-2;top=int(math.ceil(frame['top']))+2;bottom=int(math.floor(frame['bottom']))-2
 limit=np.zeros_like(mask);limit[top:bottom+1,left:right+1]=True;mask&=limit
 labelx,labels=MANUAL[rec['family']];lookup={k:(t,b) for k,t,b in labels};curves=[]
 for row in rec['rows']:
  model=row['model'];suffix=row['suffix'];base=dict(page=rec['page'],family=rec['family'],model=model,Q_m3_h=rec['Q_m3_h'],H_table_m=row['H'],source_image=str(im.name),identity_not_from_H_or_rank=True)
  if model in ['4SA16/23','4SA16/18']:
   curves.append(dict(**base,excluded_previously_accepted=True,reason='ROOT đã nghiệm thu riêng 16 mốc; không đo lại.'));continue
  if suffix not in lookup:
   curves.append(dict(**base,identity_confirmed=False,reason='Nhãn chồng ở nguồn 150dpi; không khóa được đúng tên, không gán theo thứ hạng.',points=[dict(Q_m3_h=q,H_table_m=h,status='CHƯA THỂ XÁC MINH',reason='Chưa khóa nhãn thật vào đúng nét') for q,h in zip(rec['Q_m3_h'],row['H'])]));continue
  t,b=lookup[suffix];x=int(labelx)-2;cand=peaks_column(mask,wgt,x,max(top,t),min(bottom,b+10));cand=[z for z in cand if z['v']>=b-2 and z['v']<=b+10];cand.sort(key=lambda z:abs(z['v']-(b+2.4)))
  if not cand:
   curves.append(dict(**base,identity_confirmed=False,label_native_box=[labelx,t,labelx+48,b],reason='Đọc nhãn nhưng chưa nối chắc vào nét màu dưới nhãn',points=[dict(Q_m3_h=q,H_table_m=h,status='CHƯA THỂ XÁC MINH',reason='Không có nét màu nối chắc tại nhãn') for q,h in zip(rec['Q_m3_h'],row['H'])]));continue
  seed=dict(u=x,**cand[0],gap_before=0,ambiguous=False);p1,i1=trace(mask,wgt,seed,left,right,top,bottom,-1);p2,i2=trace(mask,wgt,seed,left,right,top,bottom,1);path=sorted(p1[1:]+p2,key=lambda p:p['u']);u=np.array([p['u'] for p in path]);v=np.array([p['v'] for p in path]);points=[];cal=a['calibration'];ay=a['H_m_per_native_px'];ambxs=[z['u'] for z in i1+i2]
  for q,h in zip(rec['Q_m3_h'],row['H']):
   target=float(cal['u_Q0']+cal['u_per_l_min']*q*1000/60);j=int(np.searchsorted(u,target));out=dict(Q_m3_h=q,Q_l_min=q*1000/60,H_table_m=h,target_u_native=target,tolerance_H_m=max(1,.02*h))
   if len(u)<3 or target<u[0]-2.5 or target>u[-1]+1.6:
    out.update(status='CHƯA THỂ XÁC MINH',reason='Nét gốc không quan sát được đến tọa độ Q này, không giả tạo đầu/cuối',observed_u_domain=[float(u[0]),float(u[-1])]);points.append(out);continue
   if target<u[0]:j=1;k=0
   elif target>u[-1]:j=len(u)-1;k=j-1
   elif j==0:j=1;k=0
   else:j=min(j,len(u)-1);k=j-1
   p,q2=path[k],path[j];gap=q2['u']-p['u'];slope=(q2['v']-p['v'])/gap;yy=p['v']+(target-p['u'])*slope;hh=(frame['bottom']-yy)*ay
   flowunc=cal['max_residual_native_px']+.5;vertunc=.5+.5*max(p['width'],q2['width'])+.5+abs(slope)*flowunc;unc=vertunc*ay;delta=hh-h;amb=any(abs(ux-target)<2 for ux in ambxs)
   if gap>12 or amb:
    status='CHƯA THỂ XÁC MINH';reason='Nét nguồn bị mất/chồng hoặc có hơn một nhánh trong sai số đọc'
   elif abs(delta)<=out['tolerance_H_m']:status='KHỚP MỐC';reason='Trong ngưỡng max(1m,2%H); chưa là chứng minh toàn đường'
   elif abs(delta)<=out['tolerance_H_m']+unc:status='CHƯA THỂ XÁC MINH';reason='Lệch nominal nhưng chưa vượt ngưỡng cộng độ không chắc ảnh/trục'
   else:status='LỆCH CHẮC';reason='Vượt ngưỡng max(1m,2%H) cả khi cộng độ không chắc đọc'
   out.update(H_curve_m=float(hh),delta_H_m=float(delta),delta_percent=float(100*delta/h) if h else None,uncertainty_H_m=float(unc),v_native=float(yy),native_source_bracket=[p,q2],source_interpolation_gap_native_px=gap,status=status,reason=reason)
   points.append(out)
  curves.append(dict(**base,identity_confirmed=True,identity_method='Đọc chữ đen thực tại hộp nhãn; nối vào nét màu ngay dưới chữ rồi bám liên tục pixel. Không dùng bảng H/kW/thứ hạng để chọn nét.',label_native_box=[labelx,t,labelx+48,b],corrected_label_task_36=(model=='2.5SS1.5/17'),seed=seed,seed_candidates=cand,trace_source_only=True,native_path=path,trace_ambiguities=i1+i2,points=points,visual_review_pending=True))
 counts=collections.Counter(pt['status'] for c in curves for pt in c.get('points',[]));graphs.append(dict(page=rec['page'],family=rec['family'],axis=a,curves=curves,point_counts=dict(counts),trace_pending_visual_review=True));allcurves.extend(curves)
 # Annotated evidence only; no PDF alteration. Every point is painted as a
 # tiny magenta dot on a copy of the actual original native page image.
 x0,y0,x1,y1=rec['plot_native_box'];box=(x0-4,y0-8,x1+4,y1+8);view=Image.fromarray(cv.orig[box[1]:box[3],box[0]:box[2]]).resize(((box[2]-box[0])*3,(box[3]-box[1])*3),Image.Resampling.NEAREST);draw=ImageDraw.Draw(view)
 for c in curves:
  for p in c.get('native_path',[]):
   if p['u']%3==0:
    xx=(p['u']-box[0])*3;yy=(p['v']-box[1])*3;draw.ellipse((xx-1,yy-1,xx+1,yy+1),fill=(210,0,170))
  for pt in c.get('points',[]):
   if 'v_native' in pt:
    xx=(pt['target_u_native']-box[0])*3;yy=(pt['v_native']-box[1])*3;color='red' if pt['status']=='LỆCH CHẮC' else ('green' if pt['status']=='KHỚP MỐC' else 'orange');draw.ellipse((xx-4,yy-4,xx+4,yy+4),outline=color,width=2)
  if 'seed' in c:
   xx=(c['seed']['u']-box[0])*3;yy=(c['seed']['v']-box[1])*3;draw.rectangle((xx-3,yy-3,xx+3,yy+3),outline='blue',width=2)
 file='NET DOC P'+str(rec['page']).zfill(2)+' '+rec['family'].replace('.','_')+' LAN1.png';view.save(fresh(root/file));graphs[-1]['trace_evidence_image']=file
 print('TRACE1',rec['family'],'curves',len(curves),'identity',sum(c.get('identity_confirmed',False) for c in curves),'points',dict(counts),flush=True)

Path(fresh(root/'BANG QH DOC TU NGUON V2.json')).write_text(json.dumps(dict(source=src,source_sha256=sha(src),all_tables_read_at_400dpi=True,numeric_cell_count=1931,graphs=DATA),ensure_ascii=False,indent=2),encoding='utf8')
Path(fresh(root/'TRUC DA DOI CHIEU.json')).write_text(json.dumps(dict(source=src,source_sha256=sha(src),calibration_pixels_from_native_source=True,flow_units_not_assumed_from_right_border=True,graphs=axis),ensure_ascii=False,indent=2),encoding='utf8')
counts=collections.Counter(pt['status'] for c in allcurves for pt in c.get('points',[]));out=dict(source=src,destination=dst,source_sha256=sha(src),destination_sha256=sha(dst),read_only=True,pdf_written=False,model_count_all=196,already_accepted_models=['4SA16/23','4SA16/18'],audited_model_count=194,audited_point_count=1915,native_resolution_dpi=150.00556,visual_review_pending=True,point_counts=dict(counts),graphs=graphs)
Path(fresh(root/'DO NET NGUON LAN1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');E.close()
print('TOTAL',dict(counts),flush=True)
