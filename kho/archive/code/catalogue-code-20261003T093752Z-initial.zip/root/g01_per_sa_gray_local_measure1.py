from catwork import start,fresh,HERE
S,D,N=start()
import sys
sys.path.insert(0,str(HERE))
from pathlib import Path
from PIL import Image
import numpy as np,json,hashlib,collections,math
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter1d
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
name='Perotac bơm giếng SA_compressed (bản mới).pdf';src=S.src(name);dst=S.result(name)
assert sha(src)=='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd'
assert sha(dst)=='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c'
O=Path(S.report('G04/KIEM TOAN PEROTAC TOAN BO/RA SOAT NGOAI TRANG8 G01 LAN1'));RDIR=O.parent
d=json.loads((RDIR/'KIEM TOAN CUOI DE ROOT DOC.json').read_text(encoding='utf8'))
E=Editor(src);R=Raster(E)

def local_tick(gray,center,span,axis):
 coords=np.arange(int(round(center))-3,int(round(center))+4)
 z=255-np.median(gray[coords,span[0]:span[1]],axis=1) if axis=='v' else 255-np.median(gray[span[0]:span[1],coords],axis=0)
 base=float(np.min(z));w=np.maximum(z-base,0);mx=int(np.argmax(w));keep=(abs(coords-coords[mx])<=1.6)&(w>=.20*w.max())
 if not keep.any() or w.max()<4:return {'position':float(center),'refined':False,'raw_profile':z.tolist(),'coords':coords.tolist(),'reason':'Mực vạch yếu/không đủ tách'}
 return {'position':float(np.average(coords[keep],weights=w[keep])),'refined':True,'raw_profile':z.tolist(),'coords':coords.tolist(),'peak_darkness':float(z[mx]),'support_native_px':[float(coords[keep].min()-.5),float(coords[keep].max()+.5)]}

def interpolate_ticks(value,pairs,by_value=True):
 # Piecewise between the actual adjacent labelled ticks. No polynomial/global fit.
 pairs=sorted(pairs,key=lambda z:z[0] if by_value else z[1])
 x=np.array([p[0] if by_value else p[1] for p in pairs]);y=np.array([p[1] if by_value else p[0] for p in pairs]);j=int(np.searchsorted(x,value));j=min(max(j,1),len(x)-1)
 if value<x[0]-1e-9 or value>x[-1]+1e-9:return None,None
 t=(value-x[j-1])/(x[j]-x[j-1]);result=float(y[j-1]+t*(y[j]-y[j-1]));return result,[pairs[j-1],pairs[j]]

all_graphs=[]
for g in d['graphs']:
 if g['page']==8:continue
 family=g['family'];rec=next(z for z in DATA if z['family']==family);axis=g['axis'];frame=axis['frame_native'];left=int(math.ceil(frame['left']))+2;right=int(math.floor(frame['right']))-2;top=int(math.ceil(frame['top']))+2;bottom=int(math.floor(frame['bottom']))-2
 im=max(R.images(g['page']-1),key=lambda z:z.W*z.H);rgb=R.canvas(im).orig;gray=rgb.astype(float)@np.array([.299,.587,.114]);xt=[];yt=[]
 yspan=(top+35,bottom-35);xspan=(left+18,right-18)
 for t in axis['flow_ticks']:
  z=local_tick(gray,t['u_native'],yspan,'u');xt.append({'value_l_min':t['litre_per_minute'],'prior_native_position':t['u_native'],**z})
 for t in axis['H_grid_calibration']['ticks']:
  z=local_tick(gray,t['v_native'],xspan,'v');yt.append({'value_H_m':t['H_m'],'prior_native_position':t['v_native'],**z})
 xpairs=[(t['value_l_min'],t['position']) for t in xt];ypairs=[(t['value_H_m'],t['position']) for t in yt]
 assert all(xpairs[k][1]<xpairs[k+1][1] for k in range(len(xpairs)-1)),family
 assert all(ypairs[k][1]>ypairs[k+1][1] for k in range(len(ypairs)-1)),family
 curves=[];cache={}
 def profiles(x,slope=0):
  # Source grayscale perpendicular-ish integration, including the gray core.
  # No color classification, and no H-table prediction/choice of curve/rank.
  key=(int(x),round(float(slope),1))
  if key in cache:return cache[key]
  rows=np.arange(top,bottom+1);cols=np.arange(x-1,x+2);z=[]
  for col in cols:
   rr=rows+slope*(col-x);z.append(np.interp(rr,np.arange(gray.shape[0]),gray[:,col]))
  lum=np.median(np.array(z),axis=0);dark=255-lum;sm=gaussian_filter1d(dark,.42);ids,_=find_peaks(sm,height=28,prominence=18,distance=2);out=[]
  for k in ids:
   base=max(0,float(min(sm[max(0,k-4):k+1].min(),sm[k:min(len(sm),k+5)].min())));weight=np.maximum(dark-base,0);half=base+.33*(dark[k]-base);lo=k;hi=k
   while lo>0 and hi-lo<6 and dark[lo-1]>=half:lo-=1
   while hi+1<len(rows) and hi-lo<6 and dark[hi+1]>=half:hi+=1
   if hi-lo+1>6:continue
   ws=weight[lo:hi+1]
   if ws.sum()<12:continue
   v=float(np.average(rows[lo:hi+1],weights=ws));out.append({'v':v,'lo':float(rows[lo]-.5),'hi':float(rows[hi]+.5),'width':hi-lo+1,'strength':float(ws.sum()),'peak_darkness':float(dark[k]),'raw_peak_native':int(rows[k])})
  cache[key]=out;return out
 def trace(seed,stop,direction):
  pts=[seed.copy()];hist=[(seed['u'],seed['v'])];issues=[];missing=0
  for x in range(int(seed['u'])+direction,stop+direction,direction):
   h=np.array(hist[-12:]);fit=np.polyfit(h[:,0],h[:,1],1) if len(h)>3 else np.array([0.,hist[-1][1]]);slope=float(fit[0]);pred=float(np.polyval(fit,x));cand=[p for p in profiles(x,slope) if abs(p['v']-pred)<=2.6+min(missing*.12,.8)];cand.sort(key=lambda p:abs(p['v']-pred))
   if not cand:
    missing+=1
    if missing>12:break
    continue
   p=cand[0];amb=len(cand)>1 and abs(cand[1]['v']-pred)-abs(p['v']-pred)<1.
   if amb:issues.append({'u':x,'candidates':cand})
   pts.append({'u':x,**p,'gap_before':missing,'ambiguous':amb,'slope_pred':slope});hist.append((x,p['v']));missing=0
  return pts,issues
 for c in g['curves']:
  targets=[p for p in c['points'] if p['status']!='KHỚP MỐC'];base={'page':g['page'],'family':family,'model':c['model'],'literal_label_native_box':c.get('label_native_box'),'baseline_identity_confirmed':c.get('identity_confirmed',False),'no_assignment_from_H_power_or_rank':True,'points':[]}
  if not targets:
   base['scope']='Các mốc cũ đã chắc: chỉ kế thừa hồ sơ, không đo lại';curves.append(base);continue
  if not c.get('identity_confirmed') or not c.get('seed'):
   base.update({'new_identity_confirmed':False,'reason':'Tên/nét không khóa chắc từ nhãn thật; không dựng/gán nhánh bằng số bảng'})
   for p in targets:base['points'].append({'Q_m3_h':p['Q_m3_h'],'H_table_m':p['H_table_m'],'prior_status':p['status'],'new_status':'CHƯA THỂ XÁC MINH','reason':base['reason']})
   curves.append(base);continue
  sx=int(c['seed']['u']);sv=float(c['seed']['v']);cand=sorted([p for p in profiles(sx) if abs(p['v']-sv)<1.9],key=lambda p:abs(p['v']-sv))
  if not cand:
   base['new_identity_confirmed']=False
   for p in targets:base['points'].append({'Q_m3_h':p['Q_m3_h'],'H_table_m':p['H_table_m'],'prior_status':p['status'],'new_status':'CHƯA THỂ XÁC MINH','reason':'Không thấy một tiết diện mực xám riêng ở hạt nhãn thật'})
   curves.append(base);continue
  seed={'u':sx,**cand[0]};fwd,fi=trace(seed,min(right,int(math.ceil(xpairs[-1][1]))+3),1);bak,bi=trace(seed,left,-1);path=sorted(bak[1:]+fwd,key=lambda p:p['u']);uu=np.array([p['u'] for p in path]);vv=np.array([p['v'] for p in path]);base.update({'seed_source_pixels':seed,'observed_trace':path,'trace_ambiguities':bi+fi,'new_identity_confirmed':None,'source_visual_confirmation_pending':True,'table_numbers_used_only_after_trace':True})
  for p in targets:
   q=p['Q_m3_h'];h=p['H_table_m'];u,xb=interpolate_ticks(q*1000/60,xpairs);pt={'Q_m3_h':q,'Q_l_min':q*1000/60,'H_table_m':h,'tolerance_H_m':max(1,.02*h),'prior_status':p['status'],'u_from_actual_local_ticks':u,'local_Q_ticks':xb,'prior_H_curve_m':p.get('H_curve_m')}
   if u is None or u<uu[0] or u>uu[-1]:
    pt.update({'new_status':'CHƯA THỂ XÁC MINH','reason':'Không có giao tâm nét được quan sát tại Q này; không ngoại suy đầu/cuối','observed_u_domain':[float(uu[0]),float(uu[-1])]});base['points'].append(pt);continue
   j=min(max(int(np.searchsorted(uu,u)),1),len(path)-1);lo=path[j-1];hi=path[j];gap=hi['u']-lo['u'];slope=(hi['v']-lo['v'])/gap;v=float(lo['v']+(u-lo['u'])*slope);hv,yb=interpolate_ticks(v,ypairs,False);pt.update({'v_gray_source':v,'source_bracket':[lo,hi],'gap_native_px':gap,'local_H_ticks':yb,'H_curve_local_m':hv})
   if hv is None:pt.update({'new_status':'CHƯA THỂ XÁC MINH','reason':'Tâm nét ngoài miền trục có nhãn thật'});base['points'].append(pt);continue
   dy=abs(yb[1][1]-yb[0][1]);dh=abs(yb[1][0]-yb[0][0]);hy=dh/dy
   # Conservative source-resolution bound, not invented higher resolution.
   # Includes half observed ink thickness, 0.5 px quantisation each axis,
   # local-flow reading (incl printed rounding +/-0.5 l/min) times true slope.
   unitround=.5*abs((xb[1][1]-xb[0][1])/(xb[1][0]-xb[0][0]));flow_unc=.5+unitround;vert_unc=.5*max(lo['width'],hi['width'])+.5+.5+abs(slope)*flow_unc+.15*max(0,gap-1);unc=vert_unc*hy;delta=hv-h;pt.update({'delta_H_m':delta,'uncertainty_H_m':unc,'H_interval_source_m':[hv-unc,hv+unc],'uncertainty_components_native_px':{'half_ink_width':.5*max(lo['width'],hi['width']),'source_quantisation':.5,'H_tick_reading':.5,'Q_tick_and_printed_rounding_mapped':abs(slope)*flow_unc,'gap_interpolation':.15*max(0,gap-1)},'line_identity_pending_visual':True})
   nearby=[z for z in bi+fi if abs(z['u']-u)<3];amb=bool(nearby) or gap>3 or lo.get('ambiguous') or hi.get('ambiguous')
   if amb:stat='CHƯA THỂ XÁC MINH';reason='Tiết diện có nhánh gần/chồng hoặc khoảng thiếu mực; cần soi nguồn riêng'
   elif abs(delta)-unc>pt['tolerance_H_m']:stat='ỨNG VIÊN LỆCH CHẮC';reason='Khoảng sai lệch vượt ngưỡng cả khi cộng biên bất định; chờ khóa nhánh bằng ảnh nguồn'
   elif abs(delta)+unc<=pt['tolerance_H_m']:stat='ỨNG VIÊN KHỚP MỐC';reason='Toàn khoảng đo nằm trong ngưỡng; chờ khóa nhánh bằng ảnh nguồn'
   else:stat='CHƯA THỂ XÁC MINH';reason='Biên bất định còn chạm ngưỡng; tâm đo riêng không đủ nghiệm thu toàn mốc'
   pt.update({'new_status':stat,'reason':reason,'nearby_branch_ambiguities':nearby});base['points'].append(pt)
  curves.append(base)
 gg={'page':g['page'],'family':family,'axis_Q_local':xt,'axis_H_local':yt,'H_grid_inconsistent_labels':axis['H_grid_calibration'].get('only_black_frame_endpoints_used',False),'curves':curves,'counts_pending_visual':dict(collections.Counter(p['new_status'] for c in curves for p in c['points']))}
 all_graphs.append(gg);print('MEASURE1',family,gg['counts_pending_visual'],flush=True)
out={'source':src,'source_sha256':sha(src),'current':dst,'current_sha256':sha(dst),'baseline':str(RDIR/'KIEM TOAN CUOI DE ROOT DOC.json'),'baseline_sha256':sha(RDIR/'KIEM TOAN CUOI DE ROOT DOC.json'),'read_only':True,'PDF_written':False,'source_pixels_changed':False,'method':'Tâm mực xám nguồn bám hình học từ hạt nhãn; ánh xạ từng khoảng vạch thực; không chọn nét bằng H bảng. Đây là số đo ứng viên, phải khóa trực quan trước kết luận.','all_statuses_pending_visual':True,'graphs':all_graphs}
fp=Path(fresh(O/'g01_DO TIEU DIEN XAM VA VACH DIA PHUONG - CHO SOI ANH.json'));fp.write_text(json.dumps(out,ensure_ascii=False,indent=2,default=lambda z:z.item() if isinstance(z,np.generic) else z.tolist()),encoding='utf8');E.close();print('TOTAL',dict(collections.Counter(p['new_status'] for g in all_graphs for c in g['curves'] for p in c['points'])),'FILE',str(fp),'SHA',sha(fp))
