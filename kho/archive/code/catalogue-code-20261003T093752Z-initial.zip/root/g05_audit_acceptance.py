from catwork import start,fresh,HERE
S,D,N=start()
from pathlib import Path
import json,csv,hashlib,sys
sys.path.insert(0,str(HERE))
from g05_audit_manual_data import TABLES
from PIL import Image,ImageDraw
import numpy as np
P='G05/KIEM TOAN TOAN BO/'
a=json.loads(Path(S.report(P+'DO NET DOC LAP V2.json')).read_text(encoding='utf8'))
geometry={b['family']:b for b in json.loads(Path(S.report(P+'HIEU CHUAN TRUC V2.json')).read_text(encoding='utf8'))}
snap=json.loads(Path(S.report(P+'TRANG THAI VA OCR.json')).read_text(encoding='utf8'))
points=a['points']
for p in points:
 if p['H_curve_m'] is None:
  p['verification_status']='CHƯA THỂ';continue
 b=geometry[p['family']];yt=np.array(b['yticks']);s=72/b['dpi'];r=b['rect'];cy=p['y_px'];hc=p['H_curve_m'];sl=abs(p['slope'])
 # Sai số worst-case (tổng biên bảo thủ), chưa coi chụp 600dpi tăng độ phân giải nguồn.
 # Trục: nửa pixel nguồn .24pt; nét: max(nửa pixel,.12*residual) + .06pt định vị tâm.
 # Trục X và vị trí nét X: .30pt, đổi qua độ dốc thật đo được tại mốc.
 yerr_pt=.24+max(.24,s*p['local_spread_px'])+.06+sl*.30
 if p['extrap_pt']>0:yerr_pt+=p['extrap_pt']*max(sl,.02)*.15
 hd=lambda y:float(np.interp(r[3]-y*s,yt[:,1],yt[:,0]))
 un=max(abs(hd(cy+yerr_pt/s)-hc),abs(hd(cy-yerr_pt/s)-hc))
 p['uncertainty_previous_m']=p['uncertainty_m'];p['uncertainty_m']=round(un,5);p['uncertainty_position_pt']=round(yerr_pt,5)
 d=p['deviation_m'];lim=p['limit_m'];p['confidence_status']='ĐẠT' if d+un<=lim else ('CHƯA ĐẠT' if d-un>lim else 'CHƯA THỂ')
 p['verification_status']=p['confidence_status'] if not p['identity_uncertain'] else 'CHƯA THỂ'
 p['measurement_method']='Đủ đường theo thứ tự nhãn tại ít nhất 3 lát sắc độ; fit nét quanh Q, không dùng H bảng để tìm nét.'
 if p['confidence_status']=='CHƯA THỂ' and not p['reason']:p['reason']='Biên sai số ảnh 150dpi chạm ngưỡng cho phép.'
 if p['identity_uncertain']:p['identity_reason']=TABLES[p['family']]['rows'][p['row']-1].get('identity_reason','Tên họ trong bảng và đồ thị khác nhau: 4SP14/4SP15.')

statuslist=['ĐẠT','CHƯA ĐẠT','CHƯA THỂ']
summ=[];curves=[]
for f,t in TABLES.items():
 pp=[p for p in points if p['family']==f];cc=[]
 for i,row in enumerate(t['rows']):
  rr=[p for p in pp if p['row']==i+1];cs={v:sum(r['verification_status']==v for r in rr) for v in statuslist};ns={v:sum(r['confidence_status']==v for r in rr) for v in statuslist}
  st='CHƯA ĐẠT' if cs['CHƯA ĐẠT'] else ('CHƯA THỂ' if cs['CHƯA THỂ'] else 'ĐẠT')
  z=dict(family=f,page=geometry[f]['page'],row=i+1,curve_model=row['curve_model'],table_models=row['table_models'],points=len(rr),counts=cs,numeric_counts=ns,status=st,confirmed_failed_Q=[r['Q_m3h'] for r in rr if r['confidence_status']=='CHƯA ĐẠT'],Q=t['Q'],H_table=row['H'],H_curve=[r['H_curve_m'] for r in rr],max_deviation_m=max([r.get('deviation_m',0) for r in rr]))
  cc.append(z);curves.append(z)
 z=dict(family=f,page=geometry[f]['page'],curves=len(cc),points=len(pp),numeric_counts={v:sum(r['confidence_status']==v for r in pp) for v in statuslist},overall_counts={v:sum(r['verification_status']==v for r in pp) for v in statuslist},curve_counts={v:sum(r['status']==v for r in cc) for v in statuslist},unmeasured=sum(r['H_curve_m'] is None for r in pp));summ.append(z)
 print('ACCEPT',f,z,flush=True)
 b=geometry[f];im=Image.open(S.report(P+f+'-bieu-do-du-truc.png')).convert('RGB');dr=ImageDraw.Draw(im);xt=np.array(b['xticks']);yt=np.array(b['yticks']);s=72/b['dpi'];r=b['rect']
 xp=lambda q:(float(np.interp(q,xt[:,0],xt[:,1]))-r[0])/s;yp=lambda h:(r[3]-float(np.interp(h,yt[:,0],yt[:,1])))/s
 for p in pp:
  x=xp(p['Q_m3h']);y=yp(p['H_table_m']);dr.line((x-5,y,x+5,y),fill=(170,0,240),width=2);dr.line((x,y-5,x,y+5),fill=(170,0,240),width=2)
  if p['H_curve_m'] is not None:
   yy=yp(p['H_curve_m']);co=(0,130,20) if p['confidence_status']=='ĐẠT' else ((235,10,10) if p['confidence_status']=='CHƯA ĐẠT' else (230,150,0));dr.ellipse((x-4,yy-4,x+4,yy+4),outline=co,width=2)
 dr.rectangle((0,0,min(1700,im.width),24),fill='white');dr.text((5,6),'Tim: moc bang. Xanh: dat. Do: lech vuot sai so. Cam: chua the. '+f,fill='black')
 im.save(fresh(S.report(P+'NGHIEM THU/'+f+'.png')))

counts={v:sum(p['verification_status']==v for p in points) for v in statuslist};numeric={v:sum(p['confidence_status']==v for p in points) for v in statuslist}
out=dict(source_sha256=snap['source_sha256'],output_sha256=snap['output_sha256'],source_path=snap['source'],output_path=snap['output'],curve_count=len(curves),point_count=len(points),panel_count=len(summ),page_count=len(set(z['page'] for z in summ)),numeric_counts=numeric,overall_counts=counts,unmeasured=sum(p['H_curve_m'] is None for p in points),method='Grayscale profiles; independent rank from visible model labels; native 150dpi uncertainty; threshold max(1m,2%H); no missing point invented.',summary=summ,curves=curves,points=points)
Path(fresh(S.report(P+'NGHIEM THU QH.json'))).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
fields=list(dict.fromkeys(k for p in points for k in p if k!='sample_locations'))
with open(fresh(S.report(P+'NGHIEM THU QH.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(points)
with open(fresh(S.report(P+'NGHIEM THU TUNG DUONG.csv')),'w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=list(curves[0]));w.writeheader();w.writerows(curves)
prio=[]
for f,m in [('6SP30','6SP30-6'),('6SP60','6SP60-20')]:
 b=geometry[f];rr=[p for p in points if p['family']==f and p['curve_model']==m];xt=np.array(b['xticks']);yt=np.array(b['yticks'])
 prio.append(dict(family=f,model=m,page=b['page'],Q=[p['Q_m3h'] for p in rr],H=[p['H_table_m'] for p in rr],target_xy_pt=[[float(np.interp(p['Q_m3h'],xt[:,0],xt[:,1])),float(np.interp(p['H_table_m'],yt[:,0],yt[:,1]))] for p in rr],points=rr,axis=b))
Path(fresh(S.report(P+'HAI DUONG UU TIEN.json'))).write_text(json.dumps(prio,ensure_ascii=False,indent=2),encoding='utf8')
print('TOTAL',len(curves),len(points),'NUMERIC',numeric,'OVERALL',counts,'UNMEASURED',out['unmeasured'],flush=True)
print('FAILED CURVES',[(c['curve_model'],c['confirmed_failed_Q']) for c in curves if c['confirmed_failed_Q']],flush=True)
