"""Actual current corrected catalogue plots, only read source/canonical PDFs."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib
from catfix import verify
root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
d=json.loads((root/'DANH MUC BANG NGUON 196 DONG V1.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert [sha(d['source']),sha(d['current'])]==[d['source_SHA256'],d['current_SHA256']]
plots=[(1,'2SL0.7',(36,352,371,543)),(1,'2.5SL1.5',(464,352,801,543)),(2,'3SL2',(39,344,379,546)),(2,'3SL3',(466,344,809,546)),(3,'3SL4',(39,345,380,547)),(4,'4SL2',(39,319,381,547)),(5,'4SL3',(29,308,382,547)),(5,'4SL4',(455,308,813,547)),(6,'4SL6',(29,308,382,547)),(6,'4SL8',(455,308,813,547)),(7,'4SL10',(29,308,382,547)),(7,'4SL12',(455,308,813,547)),(8,'4SL16',(29,308,382,547)),(10,'6SL15',(36,319,381,547)),(10,'6SL25',(463,319,810,547)),(11,'6SL35',(29,352,382,550)),(11,'6SL45',(456,320,813,550))]
records=[]
for page,family,rect in plots:
 photo=root/'DUONG VA NHAN HIEN HANH'/f'TRANG {page:02} {family}.png'
 verify.crop(d['current'],page-1,rect,450).save(fresh(photo))
 records.append(dict(page=page,family=family,plot_page_rect=list(rect),photo=str(photo),photo_SHA256=sha(photo),current_SHA256=d['current_SHA256'],status='CHƯA KHÓA: ảnh bản giao hiện hành dùng để đọc nhãn, chưa đo đường'))
Path(fresh(root/'DUONG VA NHAN HIEN HANH/DINH VI ANH.json')).write_text(json.dumps(dict(records=records,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],catalogue_written=False),ensure_ascii=False,indent=2),encoding='utf8')
assert [sha(d['source']),sha(d['current'])]==[d['source_SHA256'],d['current_SHA256']]
print('17 actual current plot photos; no PDF writes',flush=True)
