"""Separate Redpump source tables/current labels for a read-only curve audit."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import hashlib,json
from catfix import verify,ocr
from PIL import Image
name='Redpump gieng SL_compressed (bản mới).pdf';source=S.src(name);current=S.result(name);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=[sha(source),sha(current)];root=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
tables=[(1,'2SL0.7',(455,227,750,301)),(1,'2.5SL1.5',(455,135,750,228)),(2,'3SL2',(455,169,815,304)),(2,'3SL3',(455,38,815,173)),(3,'3SL4',(27,37,380,163)),(4,'4SL2',(455,38,815,212)),(5,'4SL3',(27,37,380,214)),(5,'4SL4',(455,37,815,224)),(6,'4SL6',(27,37,380,231)),(6,'4SL8',(455,37,815,222)),(7,'4SL10',(27,37,380,214)),(7,'4SL12',(455,37,815,214)),(8,'4SL16',(27,37,380,215)),(10,'6SL15',(455,174,815,300)),(10,'6SL25',(455,34,815,174)),(11,'6SL35',(27,174,380,326)),(11,'6SL45',(27,37,380,181))]
records=[]
for page,model,rect in tables:
 im=verify.crop(source,page-1,rect,600);im.save(fresh(root/f'BANG NGUON {page:02} {model}.png'))
 # OCR is only a reading aid, never acceptance or a substituted table value.
 words=ocr.image_words(im,psm=6)
 rec=dict(page=page,table_model=model,rect=list(rect),source_words=words,word_reading_is_provisional=True,table_has_H_numbers=True,source_only=True)
 records.append(rec);print('TABLE',page,model,len(words),flush=True)
for page,rect in [(1,(632,411,728,465)),(7,(35,325,801,520)),(11,(26,370,376,518))]:
 verify.crop(current,page-1,rect,400).save(fresh(root/f'NHAN HIEN HANH {page:02}.png'))
old=json.loads(Path(S.report('G04/NGHIEM THU CHOT CHU SO.json')).read_text(encoding='utf8'));corrections=[z for z in old['records'] if z['file']==name and z['task'] in [36,44,45]]
Path(fresh(root/'BANG NGUON VA NHAN HIEN HANH.json')).write_text(json.dumps(dict(name=name,source=source,source_SHA256=before[0],current=current,current_SHA256=before[1],tables=records,current_accepted_name_corrections=corrections,catalogue_written=False,status='CHƯA XONG: chưa khóa từng số OCR/chưa đo mọi đường',identity_rule='Read existing canonical corrected labels; source supplies H table, ink and axes only. No Perotac data imported.'),ensure_ascii=False,indent=2),encoding='utf8');assert before==[sha(source),sha(current)];print('17Redpump table photos plus current corrected labels, readonly',flush=True)
