"""Lock exact source render request/RGB/BG/ink so independent replay does not round twice."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json,hashlib,numpy as np
from scipy.ndimage import label
from PIL import Image,ImageDraw
from catfix.vector import Editor
from catfix.raster import Raster
root=Path(S.report('G04/REDPUMP DUNG DONG BO TOAN BIEU DO/PHUONG AN TRANG8'));d=json.loads((root/'GLYPH THAT DAY DU CUNG BO NGUON V3.json').read_text(encoding='utf8'));p=json.loads((root/'PHUONG AN DUNG DONG BO TRANG8 VA KHUNG17 V2.json').read_text(encoding='utf8'));src=d['source'];cur=p['method']['input_current'];sha=lambda z:hashlib.sha256(Path(z).read_bytes()).hexdigest();before=[sha(src),sha(cur)];assert before==[d['source_SHA256'],d['current_SHA256']]
E=Editor(src,backend='fitz');R=Raster(E);cache={};records=[];picture=Image.new('RGB',(1150,12*115),'white');dr=ImageDraw.Draw(picture)
for i,z in enumerate(d['records']):
 request=tuple(z['source_canvas_rect']);key=(z['source_page'],request)
 if key not in cache:cache[key]=R.render_canvas(z['source_page']-1,request,dpi=600)
 cv=cache[key];x0,y0,x1,y1=z['source_render_box'];rgb=cv.orig[y0:y1,x0:x1].copy();g=cv.orig.astype(float)@np.array([.299,.587,.114]);bg=np.median(g,axis=1)[y0:y1];alpha=np.clip((bg[:,None]-g[y0:y1,x0:x1])/np.maximum(bg[:,None],1),0,1);comp,n=label(alpha>.085)
 keep=np.ones(alpha.shape,bool)
 # Only 6 has a following 2 donor touching the cropped last column. Its exact
 # column175 is outside the real 6 body; the two components there belong to2.
 if z['character']=='6':keep[:,-1]=False
 alpha=np.where((alpha>.085)&keep,alpha,0.);yy,xx=np.nonzero(alpha>.085);original=Image.fromarray(rgb);ink=Image.fromarray((255*(1-alpha)).round().clip(0,255).astype('uint8')).convert('RGB')
 dr.text((5,i*115+6),z['character']+' original '+z['source_word'],fill='blue');picture.paste(original.resize((original.width*2,original.height*2),Image.Resampling.NEAREST),(290,i*115+10));picture.paste(ink.resize((ink.width*2,ink.height*2),Image.Resampling.NEAREST),(470,i*115+10));dr.text((650,i*115+15),('all true parts kept' if z['character']!='6' else 'last column is adjacent2; excluded'),fill='blue')
 q=dict(z);q.update(source_render_request_rect=list(request),source_canvas_rect=list(cv.rect0),source_canvas_pixel_shape=list(cv.orig.shape),source_canvas_RGB_SHA256=hashlib.sha256(cv.orig.tobytes()).hexdigest(),source_crop_RGB=rgb.tolist(),source_crop_RGB_SHA256=hashlib.sha256(rgb.tobytes()).hexdigest(),source_background_gray_by_row=bg.tolist(),source_alpha=alpha.tolist(),source_page_box=[*cv.to_page(x0,y1),*cv.to_page(x1,y0)],source_ink_bbox600=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],source_components_kept='Full manually locked source glyph cell; all genuine disconnected strokes. No largest-component selection.',source_adjacent_pixel_column_excluded=(x1-1 if z['character']=='6' else None),source_replay_rule='Replay source_render_request_rect exactly, dpi600, then source_render_box. Do not pass rounded source_canvas_rect back as request: repeating rectangle rounding can shift a render row.',source_scale=1.)
 records.append(q)
photo=fresh(root/'GLYPH NGUON NGUYEN CAC NET ROI SNAPSHOT V4.png');picture.save(photo)
out=dict(source=src,source_SHA256=before[0],current_SHA256=before[1],records=records,source_photo=photo,source_only=True,source_physical_scale=1.,source_foreground_color_assumption=[0,0,0],glyph_pixel_threshold=.085,source_native_edge_uncertainty_pt=.24,source_render_pixel_pt=.12,exact_replay_snapshot=True,font_embedded=False,PDF_written=False,status='V4 khóa ảnh RGB/mực nguồn có thể đọc lại chính xác. Giữ mọi phần thật của0/1/3/5/9, không quyết định bằng kích thước component. Độ sắc/cỡ/shape vẫn cần ROOT đọc trước PDF.',source_components_correction='Một mã component ghi trong bản trước không ổn định khi render lại rect0: R.render_canvas làm tròn thêm một hàng. Chữ0/1 trong alpha đã lưu vẫn có thân, nhưng metadata lựa chọn không dùng để nghiệm thu. V4 lưu originalrequest và exactRGB/cỡảnh để kiểm độc lập, bỏ lựa chọn component lớn nhất; chỉ bỏ đúng cột mực của số2 nằm kế glyph6.')
Path(fresh(root/'GLYPH NGUON NGUYEN CAC NET ROI SNAPSHOT V4.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
E.close();assert before==[sha(src),sha(cur)];print('12 actual source glyph snapshots; all parts, exact replay requests; noPDF',flush=True)
