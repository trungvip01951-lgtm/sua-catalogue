"""Manual observed label/seed associations after direct current-photo inspection.
No table H, power, stage ratio or cross-file figure is used for selecting a seed.
Unclear suffixes remain UNKNOWN and are not measured under a guessed model.
"""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json
r=Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'));d=json.loads((r/'17 NHOM SEED CANDIDATE.json').read_text(encoding='utf8'));v=json.loads((r/'DANH MUC BANG NGUON 196 DONG V2.json').read_text(encoding='utf8'))
mapping={
 '2SL0.7':{0:38,1:32,2:26},
 '2.5SL1.5':{0:31,1:24,2:17,3:12},
 '3SL2':{0:46,1:38,2:33,3:27,4:21,5:15,6:11,7:8},
 '3SL3':{0:37,1:31,2:26,3:21,4:16,6:11,7:8},
 '3SL4':{0:28,1:24,2:20,3:16,4:12,5:9,6:6},
 '4SL2':{0:64,1:58,2:52,3:47,4:42,5:37,6:32,7:28,8:24,9:21,10:18,11:15,12:12,13:9,14:7},
 '4SL3':{0:62,1:56,2:50,3:45,4:40,5:35,6:30,7:26,8:22,9:20,10:18,11:15,12:13,13:10,14:7,15:5},
 '4SL4':{0:62,1:56,2:50,3:45,4:40,5:40 if False else 36,6:32,7:28,8:24,9:21,10:18,11:16,12:14,13:12,14:10,15:8,16:6},
 '4SL6':{0:52,1:47,2:42,3:38,4:34,5:30,6:26,7:23,8:20,9:17,10:15,11:13,12:11,13:9,14:8,15:7,16:6,17:5},
 '4SL8':{0:45,1:41,2:37,3:33,4:29,5:26,6:23,8:20,9:17,10:14,11:12,12:10,13:9,14:8,15:7,16:6,17:5},
 '4SL10':{0:34,1:30,2:27,3:24,4:21,5:19,6:17,7:15,8:13,9:11,10:10,11:9,12:8,13:7,14:6,15:5},
 '4SL12':{0:32,1:29,2:26,3:23,4:20,5:18,6:16,7:14,8:12,9:10,10:8,11:7,12:6,13:5,14:4},
 '4SL16':{0:25,1:23,2:20,3:18,5:16,6:14,7:12,8:11,9:9,10:8,11:6,12:5,13:4},
 '6SL15':{0:24,1:21,2:18,3:15,4:12,5:9,6:7,7:5},
 '6SL25':{0:20,1:18,2:16,3:14,4:12,5:10,6:8,7:6,8:4,9:3},
 '6SL35':{0:20,1:18,2:16,3:14,4:12,5:10,6:8,7:7,8:6,9:4,10:3},
 '6SL45':{0:15,1:13,2:11,3:9,4:8,5:7,6:6,7:5,8:4,9:3,10:2}}
unknown={'2SL0.7':[38],'3SL2':[15],'3SL4':[6],'4SL6':[9,8,7,6,5],'4SL8':[9,8,7,6,5],'4SL10':[8,7,6,5],'4SL12':[18,8,7,6,5,4],'6SL15':[5],'6SL35':[18],'6SL45':[15,5]}
rows=[];excluded=[]
for z in d['records']:
 known={p['index']:p for p in z['candidates']}
 for idx,suffix in mapping[z['family']].items():
  assert idx in known
  model=f'{z["family"]}/{suffix}';table=next(p for p in v['rows'] if p['model']==model);unclear=suffix in unknown.get(z['family'],[]);prior=model in ['4SL16/23','4SL16/18'];tail=model=='4SL16/25'
  row=dict(page=z['page'],family=z['family'],table_model_candidate=model,model_locked=None if unclear else model,source_seed=dict(u=z['source_seed_column'],**known[idx]),source_rect=z['source_rect'],source_dpi=z['source_dpi'],current_names_photo=z['current_names_photo'],current_names_seed_photo=z['current_names_seed_photo'],source_SHA256=z['source_SHA256'],current_SHA256=z['current_SHA256'],identity_status='CHƯA THỂ' if unclear else 'KHÓA THEO NHÃN VÀ NÉT',identity_basis='Đã soi tên hiện hành và nối nét rõ tới ứng viên ngay trên ảnh, không dùng H bảng hoặc thứ hạng số để chọn.' if not unclear else 'Chữ số nhỏ5/6/8 hoặc nhãn thấp chồng nét chưa đọc chắc; candidate_model chỉ là dòng bảng cần đối chiếu, chưa gán danh tính cho seed.',prior_16_points_accepted_skip=prior,tail25_separate_ROOT_sample_skip=tail)
  rows.append(row)
 for idx in set(known)-set(mapping[z['family']]):excluded.append(dict(page=z['page'],family=z['family'],seed=known[idx],reason='Ứng viên yếu trên chính hàng lưới xám, không nối tới nhãn/nét model. Đã soi ảnh nguồn; không ép đếm số đường.',current_names_seed_photo=z['current_names_seed_photo']))
assert len(rows)==196 and len({p['table_model_candidate'] for p in rows})==196
out=dict(records=rows,source_SHA256=d['source_SHA256'],current_SHA256=d['current_SHA256'],rows=196,identity_locked=sum(p['model_locked'] is not None for p in rows),identity_unknown=sum(p['model_locked'] is None for p in rows),numeric_rows_to_read=sum(p['model_locked'] is not None and not p['prior_16_points_accepted_skip'] and not p['tail25_separate_ROOT_sample_skip'] for p in rows),excluded_candidate_grids=excluded,catalogue_written=False,numeric_curve_acceptance=False)
Path(fresh(r/'DINH DANH NHAN VA SEED DOC TRUC TIEP V1.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print('identities',out['identity_locked'],'locked',out['identity_unknown'],'UNKNOWN;',out['numeric_rows_to_read'],'new source traces; excluded grids',[(p['family'],p['seed']['index']) for p in excluded])
