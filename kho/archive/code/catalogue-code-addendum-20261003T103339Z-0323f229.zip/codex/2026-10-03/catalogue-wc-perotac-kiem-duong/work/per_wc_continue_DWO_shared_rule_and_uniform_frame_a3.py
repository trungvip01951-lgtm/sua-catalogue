"""Read-only DWO rule adoption; standalone empty XML/SVG, never an XLSX writer.

No curve points are evaluated. Qmin/Hmin stay unknown. The source and current
catalogue are read as ZIP/XML only; shared coordination commands are read-only.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import base64
import hashlib
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parents[1]
SHARED = Path(r'D:\ChatGPT\Sửa catalogue')
OUT = BASE / 'outputs/per_wc_continue_DWO_QUY TAC MOI_CHO MIN_a3'
PREVIOUS = BASE / 'outputs/per_wc_continue_DWO_HO SO CHUAN BI 03-10-2026/per_wc_continue_DWO_FINAL_CHUAN BI_CHO MIN_a2.json'
PLAN = BASE / 'outputs/per_wc_continue_DWO_chart_plan_a1/per_wc_continue_DWO_chart_native_plan_minimum_PENDING_a1.json'
OLD_XML = BASE / 'outputs/per_wc_continue_DWO_chart_plan_a1/per_wc_continue_DWO_scatter7_EMPTY_TEMPLATE_NOT_WORKBOOK_a1.xml'
OLD_SVG = BASE / 'outputs/per_wc_continue_DWO_chart_plan_a1/per_wc_continue_DWO_current_proposed_blank_frame_a1.svg'
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}
for prefix, uri in NS.items():
    ET.register_namespace(prefix, uri)
ET.register_namespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')


def digest(path):
    path = Path(path)
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'INPUT_CHANGED during read'
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def binding(path, role):
    path = Path(path)
    return {'file': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size, 'role': role}


def read_workbook(path):
    with zipfile.ZipFile(path) as z:
        payloads = {name: z.read(name) for name in z.namelist()}
    strings_root = ET.fromstring(payloads['xl/sharedStrings.xml'])
    strings = [''.join(si.itertext()) for si in strings_root.findall('s:si', NS)]
    sheet = ET.fromstring(payloads['xl/worksheets/sheet2.xml'])
    cells = {}
    for cell in sheet.findall('.//s:sheetData/s:row/s:c', NS):
        v = cell.find('s:v', NS)
        if v is None or v.text is None:
            continue
        cells[cell.get('r')] = strings[int(v.text)] if cell.get('t') == 's' else v.text
    book = ET.fromstring(payloads['xl/workbook.xml'])
    sheets = [{'name': s.get('name'), 'state': s.get('state', 'visible')}
              for s in book.findall('s:sheets/s:sheet', NS)]
    media = [{'part': name, 'sha256': hashlib.sha256(raw).hexdigest()}
             for name, raw in payloads.items() if name.startswith('xl/media/')]
    models = []
    for row in range(16, 23):
        models.append({'model': cells[f'B{row}'], 'model_ref': f'Sheet1!B{row}',
                       'Qmax_m3h': int(cells[f'H{row}']), 'Qmax_ref': f'Sheet1!H{row}',
                       'Hmax_m': int(cells[f'F{row}']), 'Hmax_ref': f'Sheet1!F{row}',
                       'Qmin': None, 'Hmin': None, 'rated_Q': None, 'rated_H': None,
                       'paired_QH_points_in_source': 0,
                       'monotonicity_status': 'CHUA_THE_XAC_MINH_NO_SOURCE_PAIRS_NO_NEW_CURVE'})
    return {'valued_cell_count': len(cells), 'sheets': sheets, 'media': media,
            'chart_parts': [p for p in payloads if p.startswith('xl/charts/')], 'models7': models}


def main():
    assert not OUT.exists(), 'Preserve existing evidence; do not overwrite'
    assert digest(PREVIOUS) == '4041ae19a540043693813b325b933598bfe992065cc8a340ac7330b4e2a6213b'
    assert digest(PLAN) == 'f8811316bc80498be6c46f3fad1074db35c198e3aa59e1b4a3cfca9e4c2f05da'
    previous, plan = load(PREVIOUS), load(PLAN)
    source, current = Path(previous['source']['file']), Path(previous['current']['file'])
    for role, path in [('source', source), ('current', current)]:
        assert digest(path) == previous[role]['sha256'], f'INPUT_CHANGED {role}'
    manifest = load(SHARED / 'manifest.json')
    ledger = Path(manifest['paths']['progress'])
    shared_files = [
        'START_HERE.md', 'AGENTS.md', 'manifest.json',
        'rules/QUY_TAC_ANH_TRUNG.md', 'rules/PHOI_HOP_CHATGPT_CLAUDE.md',
        'state/CURRENT_CHECKPOINT.md', 'state/active_assignments.json',
        'procedures/QUY_TRINH_SUA_VA_NGHIEM_THU.md', 'procedures/DUONG_DAC_TINH.md',
        'procedures/EXCEL.md', 'knowledge/CACH_DA_NGHIEM_THU.md',
        'knowledge/LOI_VA_CACH_TRANH.md', 'templates/BAO_CAO8_COT.md',
        'templates/BAN_GIAO.md', 'tools/catalogue.py']
    actual_reads = []
    for relative in shared_files:
        path = SHARED / relative
        content = path.read_text(encoding='utf-8-sig')
        assert content.strip()
        actual_reads.append(binding(path, 'self-read shared project text, DWO scope'))
    ledger_before = binding(ledger, 'original progress ledger, read-only')
    ledger_text = ledger.read_text(encoding='utf-8-sig')
    ledger_rows = [line for line in ledger_text.splitlines()
                   if line.startswith('|') and ('DWO' in line or '| G18 |' in line or 'BỔ SUNG EXCEL' in line)]
    # All three commands have been reviewed: no claim/receipt/refresh mutation.
    reads = []
    for args in [('health',), ('status',), ('context', '--file', 'Trục ngang/Catalogue DWO (bản mới).xlsx')]:
        p = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(SHARED / 'tools/catalogue.py'), *args],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8')
        try:
            parsed = json.loads(p.stdout)
        except json.JSONDecodeError:
            parsed = None
        reads.append({'arguments': list(args), 'exit_code': p.returncode,
                      'stdout': p.stdout, 'stderr': p.stderr, 'read_result': parsed})
    source_xml, current_xml = read_workbook(source), read_workbook(current)
    assert source_xml['valued_cell_count'] == current_xml['valued_cell_count'] == 59
    assert len(source_xml['media']) == len(current_xml['media']) == 3
    assert source_xml['models7'] == current_xml['models7']
    assert source_xml['sheets'] == current_xml['sheets']
    assert current_xml['sheets'][0] == {'name': 'SGV', 'state': 'veryHidden'}
    assert not source_xml['chart_parts'] and not current_xml['chart_parts']
    assert [(m['model'], m['Qmax_m3h'], m['Hmax_m']) for m in current_xml['models7']] == [
        ('DWO037', 6, 12), ('DWO100', 18, 12), ('DWO150', 33, 15),
        ('DWO200', 42, 18), ('DWO300', 57, 21), ('DWO400', 62, 23), ('DWO500', 68, 25)]

    # Change only the independent empty template, never workbook or frozen proof.
    before_xml = OLD_XML.read_bytes()
    root = ET.fromstring(before_xml)
    series = root.findall('.//c:scatterChart/c:ser', NS)
    assert len(series) == 7
    before_colors = []
    for s in series:
        line = s.find('c:spPr/a:ln', NS)
        assert line.get('w') == '12700'
        color = line.find('a:solidFill/a:srgbClr', NS)
        before_colors.append(color.get('val'))
        color.set('val', '2F5597')
    chart_title = root.find('c:chart/c:title/c:tx/c:rich/a:p/a:r/a:t', NS)
    assert chart_title.text == 'REFERENCE Q-H CURVES'
    chart_title.text = 'REFERENCE Q-H CURVES - MINIMA PENDING'
    new_xml = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    parsed = ET.fromstring(new_xml)
    assert len(parsed.findall('.//c:valAx', NS)) == 2
    assert not parsed.findall('.//c:catAx', NS)
    assert not parsed.findall('.//c:numCache/c:pt', NS)
    assert all(n.get('val') == '0' for n in parsed.findall('.//c:numCache/c:ptCount', NS))
    assert len(parsed.findall('.//c:scatterChart/c:ser', NS)) == 7
    assert {n.get('val') for n in parsed.findall('.//c:ser/c:spPr/a:ln/a:solidFill/a:srgbClr', NS)} == {'2F5597'}
    assert [n.text for n in parsed.findall('.//c:ser/c:tx/c:strRef/c:strCache/c:pt/c:v', NS)] == [m['model'] for m in current_xml['models7']]

    old_svg = OLD_SVG.read_text(encoding='utf-8')
    legend_pattern = r'(<path d="M[^"\n]+ h22" stroke=")#[A-Fa-f0-9]{6}(" stroke-width="1\.333333"/>)'
    new_svg, replacements = re.subn(legend_pattern, r'\g<1>#2F5597\2', old_svg)
    assert replacements == 7
    assert new_svg.count('REFERENCE Q-H CURVES</text>') == 1
    new_svg = new_svg.replace('REFERENCE Q-H CURVES</text>',
                              'REFERENCE Q-H CURVES - MINIMA PENDING</text>')
    old_images = re.findall(r'<image\b[^>]+/>', old_svg)
    new_images = re.findall(r'<image\b[^>]+/>', new_svg)
    assert len(old_images) == 3 and old_images == new_images
    old_embedded = re.findall(r'data:image/(?:jpeg|jpg);base64,([A-Za-z0-9+/=]+)', old_svg)
    assert len(old_embedded) == 3
    assert sorted(hashlib.sha256(base64.b64decode(i)).hexdigest() for i in old_embedded) == sorted(m['sha256'] for m in current_xml['media'])
    before_bindings = [binding(OLD_XML, 'historical empty template; held'), binding(OLD_SVG, 'historical projection; held')]
    OUT.mkdir(parents=True)
    xml_path = OUT / 'per_wc_continue_DWO_KHUNG RONG_CUNG MAU_CHO MIN_a3.xml'
    svg_path = OUT / 'per_wc_continue_DWO_BO CUC_KHUNG RONG_CHO MIN_a3.svg'
    xml_path.write_bytes(new_xml)
    svg_path.write_text(new_svg, encoding='utf-8')

    report = {
        'schema': 'DWO_SHARED_RULE_ADOPTION_EMPTY_FRAME_ONLY_V3',
        'state': 'LOCAL_RULE_AND_EMPTY_FRAME_PREP_DONE_MINIMUM_PENDING_NO_XLSX_WRITE',
        'checked_at_Vietnam': datetime.now(timezone(timedelta(hours=7))).isoformat(),
        'actor_thread': '01a0ff67-d6aa-7a22-944f-590cc3a456be',
        'source': binding(source, 'immutable source, read again'),
        'current': binding(current, 'canonical DWO, read again, NOT MODIFIED'),
        'previous_checkpoint': binding(PREVIOUS, 'frozen historical handoff; preserved'),
        'shared_root_self_read': str(SHARED), 'self_read_file_bindings': actual_reads,
        'original_ledger_read': ledger_before, 'ledger_relevant_rows': ledger_rows,
        'shared_read_only_command_results': reads,
        'earlier_first_shared_check': {
            'health': 'CHUA_DAT_MISSING_state/control_manifest.json',
            'context': 'CHUA_DAT_MISSING_state/catalogues.json',
            'status': 'PASS_READ_ONLY_LOCKS_EMPTY_LEDGER_84ed3ca2dc38615d24b6b8a62c9631f6fee5964828f6299c1cc3d0a1346ccd74',
            'ROOT_sealing_in_progress': True, 'not_catalogue_acceptance': True},
        'source_zip_xml_read': source_xml, 'current_zip_xml_read': current_xml,
        'native_empty_template': binding(xml_path, 'standalone empty chart XML; NOT an XLSX'),
        'layout_svg': binding(svg_path, 'XML/JPEG projection, NOT Excel render or print'),
        'historical_frame_colors': before_colors, 'new_uniform_color_RGB': '2F5597',
        'line_width_EMU': 12700, 'line_width_pt': 1,
        'empty_template_validation': 'PASS_WELL_FORMED_7_SERIES_2_VALUE_AXES_0_CURVE_POINTS_UNIFORM_COLOR_ONLY',
        'full_schema_RAM_reload_native_graphics_for_NEW_template': 'NOT_RUN',
        'previous_RAM_OPC_proof': 'Historical 7-series empty frame only; not a new-template graphical acceptance',
        'placement_held': 'B39:P62; below all original images',
        'print_area_proposal_held': "'Sheet1'!$A$1:$P$37,'Sheet1'!$A$39:$Q$63",
        'projection_original_media_raw_held': True, 'projection_numeric_curve_points': 0,
        'actual_view_of_new_projection': 'PENDING_PNG_RENDER_AND_VIEW',
        'new_monotone_rule': 'For the same model and condition, increasing Q requires decreasing H',
        'monotone_audit_for_all7': 'CHUA_THE_XAC_MINH_NO_QH_PAIRS_IN_DWO_SOURCE_NO_NEW_NUMERIC_CURVES',
        'future_numeric_gates': [
            'Do not evaluate until the existing human Qmin/Hmin question is answered',
            'Keep all verified min/max/rated locks; missing rated points remain absent',
            'Qmax and Hmax are independent extrema, never a verified (Qmax,Hmax) pair',
            'Inspect all ordered points for H increase, equality after rounding, or backward Q',
            'Rounding intermediate table values to integers is checked separately against the actual curve',
            'Check the whole smoothed path; native smooth=1 does not prove monotonicity',
            'If fixed points conflict, report exact conflicting locks without moving them',
            'Use clearly identified reference curves when only approved min/max are available',
            'After actual CATFIX save, independently check the saved workbook, chart and print'],
        'old_81_point_proposal_status': 'HISTORICAL_NOT_APPROVED_NOT_EVALUATED_RECHECK_ROUNDING_AND_MONOTONICITY_AFTER_MIN',
        'minimum_decision': 'PENDING_OLD_HUMAN_QUESTION_NO_DEFAULT_ZERO',
        'rated_points_created': 0, 'numeric_curve_points_created': 0,
        'CATFIX_Xlsx_save_calls': 0, 'Artifact_workbook_exports': 0, 'physical_XLSX_samples': 0,
        'source_written': False, 'current_S_dst_written': False, 'TIEN_DO_written': False,
        'shared_project_written': False, 'shared_receipt_command_calls': 0, 'claim_command_calls': 0,
        'self_read_receipt': 'LOCAL_EVIDENCE_ONLY_SHARED_TOOL_RECEIPT_NOT_RECORDED',
        'shared_receipt_next_gate': 'ROOT completes seal/index, verify current controls, then own session can record receipt; do not record for other AI',
        'BOOT0_43_tests_in_this_readonly_delta': 'NOT_RUN_NO_CATALOGUE_AUTHORING_OR_SAVE_PERFORMED',
        'Excel_UI_owner': 'ROOT only', 'worker_GUI_COM_calls': 0,
        'actual_Office_print_123': 'CHUA_THE_XAC_MINH',
        'Perotac_WC': 'Previously closed, untouched; no new PDF',
        'unchanged_files_explicit': [str(source), str(current), str(ledger), str(PREVIOUS), str(PLAN), str(OLD_XML), str(OLD_SVG)],
        'script': binding(Path(__file__), 'new independent local preparation code')}
    for role, path in [('source', source), ('current', current)]:
        assert digest(path) == previous[role]['sha256'], f'INPUT_CHANGED {role} at close'
    for item in before_bindings:
        assert digest(item['file']) == item['sha256']
    report['ledger_sha256_at_close'] = digest(ledger)
    report['ledger_changed_by_external_actor_between_reads'] = report['ledger_sha256_at_close'] != ledger_before['sha256']
    report_path = OUT / 'per_wc_continue_DWO_DOC KHO_QUY TAC QH_CHO MIN_a3.json'
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'state': report['state'], 'report': str(report_path), 'report_sha256': digest(report_path),
                      'new_empty_XML': str(xml_path), 'new_layout_SVG': str(svg_path),
                      'shared_command_exit_codes': [r['exit_code'] for r in reads],
                      'native_numeric_points': 0, 'XLSX_save': 0,
                      'current_sha256': report['current']['sha256']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
