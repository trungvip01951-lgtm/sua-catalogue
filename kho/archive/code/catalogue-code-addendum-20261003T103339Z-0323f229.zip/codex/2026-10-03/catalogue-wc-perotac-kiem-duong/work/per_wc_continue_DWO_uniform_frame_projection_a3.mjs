// Rasterize a newly generated layout SVG; original JPEGs remain exact bytes.
// This does not render Excel, evaluate pump points, or save a workbook.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import sharp from 'sharp';

const base = 'C:/Users/H2/Documents/Codex/2026-10-03/catalogue-wc-perotac-kiem-duong';
const dir = path.join(base, 'outputs/per_wc_continue_DWO_QUY TAC MOI_CHO MIN_a3');
const reportPath = path.join(dir, 'per_wc_continue_DWO_DOC KHO_QUY TAC QH_CHO MIN_a3.json');
const report = JSON.parse(await fs.readFile(reportPath, 'utf8'));
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const input = report.layout_svg;
const svg = await fs.readFile(input.file);
if (hash(svg) !== input.sha256) throw new Error('SVG drift; stop.');
const output = path.join(dir, 'per_wc_continue_DWO_BO CUC_KHUNG RONG_CHO MIN_a3.png');
try { await fs.access(output); throw new Error('Output exists; preserve.'); }
catch (e) { if (e.code !== 'ENOENT') throw e; }
const bytes = await sharp(svg, {density: 144}).png().toBuffer();
await fs.writeFile(output, bytes, {flag: 'wx'});
const meta = await sharp(bytes).metadata();
const proof = {
  state: 'UNIFORM_EMPTY_FRAME_LAYOUT_PNG_ONLY_PENDING_ACTUAL_VIEW',
  file: output, sha256: hash(bytes), width: meta.width, height: meta.height,
  SVG_source: input, rule_report: reportPath,
  rule_report_sha256: hash(await fs.readFile(reportPath)),
  original_images_embedded: 3, source_cells_projected: 59,
  uniform_legend_color: '2F5597', legend_items: 7,
  numeric_curve_points: 0, minimum_assumed_zero: false,
  actual_Excel_render: false, actual_Office_print: false,
  XLSX_save_calls: 0, artifact_exports: 0,
  code: import.meta.url, code_sha256: hash(await fs.readFile(new URL(import.meta.url)))
};
await fs.writeFile(path.join(dir, 'per_wc_continue_DWO_PNG_BO CUC_BANG CHUNG_a3.json'), JSON.stringify(proof, null, 2), {flag: 'wx'});
console.log(JSON.stringify(proof));
