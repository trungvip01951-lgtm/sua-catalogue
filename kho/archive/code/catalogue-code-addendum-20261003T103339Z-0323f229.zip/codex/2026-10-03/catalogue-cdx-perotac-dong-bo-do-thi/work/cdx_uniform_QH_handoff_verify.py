from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];O=R/'outputs'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((O/'cdx_uniform_76_QH_readonly_handoff_manifest.json').read_text(encoding='utf-8'))
errors=[]
for row in m['files']:
 p=Path(row['path'])
 if not p.is_file() or sha(p)!=row['sha256'] or p.stat().st_size!=row['bytes']:errors.append(row['relative_path'])
for k,row in m['inputs'].items():
 if sha(row['path'])!=row['sha256']:errors.append(k+'_INPUT_CHANGED')
rows=[s for s in (O/'cdx_uniform_75_G15_QH_rule_readonly_8_columns.md').read_text(encoding='utf-8').splitlines() if s.startswith('| #')]
if len(rows)!=9 or any(len(s.split('|'))-2!=8 for s in rows):errors.append('8column_structure')
if len(list(R.rglob('*.pdf')))!=1:errors.append('PDF_count')
control_drift=[r['path'] for r in m['self_read_shared_control_files'] if sha(r['path'])!=r['sha256']]
result={'manifest_files_verified':len(m['files']),'original_task_rows':8,'columns':8,
 'canonical_SHA_after':sha(m['inputs']['canonical194a']['path']),
 'source_SHA_after':sha(m['inputs']['source']['path']),
 'source_canonical_writer_guard_errors':errors,
 'shared_control_files_changed_since_readback':control_drift,
 'new_PDF_or_RAM_written':False,'PDF_disk_count':len(list(R.rglob('*.pdf'))),
 'status':'READONLY_HANDOFF_INTEGRITY_PASS' if not errors and not control_drift else 'CHECK_DRIFT_BEFORE_USE',
 'does_not_upgrade_job118':'4 current paths +15 RAM parts descend; models/extrema/full source missing data and oldgraphic FAIL unchanged'}
(O/'cdx_uniform_77_QH_readonly_integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False));assert not errors and not control_drift
