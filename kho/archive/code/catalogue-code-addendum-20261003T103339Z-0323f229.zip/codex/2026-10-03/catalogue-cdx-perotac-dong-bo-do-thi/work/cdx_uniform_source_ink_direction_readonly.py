"""Fresh source pixels: nominal center fluctuations vs full ink footprint.
Pixel tracing does not establish model/manufacturer intermediate values.
"""
from pathlib import Path
import json,hashlib,numpy as np,pymupdf as fitz
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
C=json.loads((O/'cdx_uniform_72_shared_readonly_receipt.json').read_text(encoding='utf-8'))['context']
M=json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))
P3=json.loads((W/'cdx_uniform_p3_source_traces.json').read_text(encoding='utf-8'))
P45=json.loads((W/'cdx_uniform_p45_geometry_source.json').read_text(encoding='utf-8'))
assert sha(C['source'])==C['source_sha256'];doc=fitz.open(C['source'])
report={'source_sha256':C['source_sha256'],'scope':'SOURCE_original_red_ink; no PDF writer or source-number corrections',
 'method':'Fresh source150dpi. Red chroma threshold25 defines contiguous visible stroke footprint;55 computes weighted center. Raw per-pixel center rises are reported. A rise is direction-separable only if the entire later footprint lies above the earlier one (nativey), both trace identity samples are unambiguous and x step<=3px. Missing/buried/crossing intervals UNKNOWN; not manufacturer data or permission to edit.',
 'native_footprint_edges':'red pixel index +/-0.5; no enlarged passing tolerance; inability to separate a rise is UNKNOWN, never a source-series PASS',
 'pages':[],'numbers_proposed_to_change':[],'new_PDF_written':False}
for page in (3,4,5):
 mp=next(p for p in M['pages'] if p['page']==page)
 pix=doc[page-1].get_pixmap(dpi=150,alpha=False,colorspace=fitz.csRGB)
 img=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,3).astype(np.int16)
 red=img[:,:,0]-np.maximum(img[:,:,1],img[:,:,2]);y0,y1=mp['plot_native_pixel_box'][1::2]
 qx=np.array([g['native_pixel_center'] for g in mp['vertical_grid']]);qq=np.array([g['l_min']*.06 for g in mp['vertical_grid']])
 hy=np.array([g['native_pixel_center'] for g in mp['horizontal_grid']]);hh=np.array([g['H_m'] for g in mp['horizontal_grid']])
 def mapq(x):return float(np.interp(x,qx,qq)) if qx[0]-1e-7<=x<=qx[-1]+1e-7 else None
 def maph(y):return float(np.interp(y,hy,hh)) if hy[0]-1e-7<=y<=hy[-1]+1e-7 else None
 if page==3:
  curves=[{'id':c['model'],'parts':[np.array([[p['x_native_px'],p['y_native_px']] for p in c['points']])],
           'ambiguous':set(),'model_identity':'previous source label verified'} for c in P3]
 else:
  gg=next(p for p in P45['pages'] if p['page']==page)
  curves=[{'id':f'number{c["number"]}','parts':[np.array(p['source_observed_points']) for p in c['paths']],
     'ambiguous':set(c['shared_ink_x_native']),'model_identity':'UNKNOWN; only source numeric trace association'} for c in gg['curves']]
 pr={'page':page,'curves':[]}
 for curve in curves:
  cr={'source_identity':curve['id'],'model_identity':curve['model_identity'],'parts':[]}
  for j,obs in enumerate(curve['parts'],1):
   samples=[];missing=[]
   for xx,yy in obs:
    x=int(round(xx));band=red[y0:y1,x];ii=np.flatnonzero(band>25)
    groups=np.split(ii,np.flatnonzero(np.diff(ii)>1)+1) if len(ii) else []
    groups=[g for g in groups if len(g) and np.any(band[g]>55)]
    if not groups:missing.append(x);continue
    def cent(g):
     core=g[band[g]>55];return float(np.average(core+y0,weights=band[core]))
    choice=min(groups,key=lambda g:abs(cent(g)-yy));center=cent(choice)
    if abs(center-yy)>4:missing.append(x);continue
    samples.append({'x':x,'y_center':center,'y_ink_lo':float(choice[0]+y0-.5),'y_ink_hi':float(choice[-1]+y0+.5),
      'Q_m3_h_local':mapq(x),'H_m_local':maph(center),'shared_source_ink':x in curve['ambiguous']})
   rises=[];flats=[];unresolved=[];separable=[];gaps=[]
   for a,b in zip(samples[:-1],samples[1:]):
    if b['x']-a['x']>3:gaps.append([a['x'],b['x']]);continue
    rise=a['y_center']-b['y_center']
    if rise>1e-10:
     entry={'x_native':[a['x'],b['x']],'Q_m3_h':[a['Q_m3_h_local'],b['Q_m3_h_local']],
       'H_m_centers':[a['H_m_local'],b['H_m_local']],'rise_native_px':rise,
       'rise_m_nominal':b['H_m_local']-a['H_m_local'] if a['H_m_local'] is not None and b['H_m_local'] is not None else None,
       'early_ink_y_range':[a['y_ink_lo'],a['y_ink_hi']],'later_ink_y_range':[b['y_ink_lo'],b['y_ink_hi']],
       'identity_shared_source_ink':a['shared_source_ink'] or b['shared_source_ink']}
     rises.append(entry)
     if b['y_ink_hi']<a['y_ink_lo'] and not entry['identity_shared_source_ink']:separable.append(entry)
     else:unresolved.append(entry)
    elif abs(rise)<=1e-10:flats.append([a['x'],b['x']])
   cr['parts'].append({'part':j,'samples_read_from_fresh_source':len(samples),'missing_or_unmatched_native_x':missing,
      'nominal_center_H_rise_count':len(rises),'nominal_flat_center_count':len(flats),
      'largest_nominal_rise_native_px':max((r['rise_native_px'] for r in rises),default=0),
      'largest_nominal_rise_m':max((r['rise_m_nominal'] for r in rises if r['rise_m_nominal'] is not None),default=0),
      'direction_separable_rises_count':len(separable),'direction_separable_rises':separable,
      'center_rises_unresolved_count':len(unresolved),'nominal_center_rises':rises,'sampling_gaps_native_x':gaps,
      'status':'SOURCE_INK_DIRECTION_CANDIDATE_FAIL_REQUIRES_ID_AND_POINT_LOCK_REVIEW' if separable else 'NO_DIRECTION_SEPARABLE_RISE_IN_OBSERVED_SAMPLES; FULL_SOURCE_SERIES_UNKNOWN',
      'no_table_number_change':'sampling/JPEG/crossings cannot be turned into an integer replacement by nearest curve'})
  pr['curves'].append(cr)
 report['pages'].append(pr)
report['totals']={'source_numeric_or_named_traces':15,'source_observed_parts':19,
 'nominal_center_rises':sum(p['nominal_center_H_rise_count'] for pg in report['pages'] for c in pg['curves'] for p in c['parts']),
 'direction_separable_source_rises':sum(p['direction_separable_rises_count'] for pg in report['pages'] for c in pg['curves'] for p in c['parts']),
 'full_source_series_or_manufacturer_model_acceptance':'UNKNOWN; missing/crossing intervals and11 unmapped model identities remain'}
report['source_canonical_unchanged']=sha(C['source'])==C['source_sha256'] and sha(C['current'])==C['current_sha256']
assert report['source_canonical_unchanged'];doc.close()
(O/'cdx_uniform_74b_SOURCE_ink_direction_readonly.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'totals':report['totals'],'pages':[{'page':pg['page'],
  'nominal_rises':sum(p['nominal_center_H_rise_count'] for c in pg['curves'] for p in c['parts']),
  'separable_rises':sum(p['direction_separable_rises_count'] for c in pg['curves'] for p in c['parts']),
  'maximum_nominal_rise_m':max(p['largest_nominal_rise_m'] for c in pg['curves'] for p in c['parts'])} for pg in report['pages']]},ensure_ascii=False))
