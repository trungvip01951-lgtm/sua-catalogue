"""Read-only exact sign audit of canonical p3 + actual-audited p4/5 RAM content.
No Editor.save, PdfDoc.save, PDF serialization, or shared-store writes here.
"""
from pathlib import Path
import os,sys,json,hashlib,numpy as np
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
os.environ['CATFIX_CACHE']=str(W/'cdx_uniform_cache')
sys.path.insert(0,r'D:\TempSystem\catfix_work\catfix_pkg\GOI_SUA_CATALOGUE_CHATGPT')
from catfix.vector import VPage
from catfix.pdfdoc import PdfDoc
from catfix import cs
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=lambda b:hashlib.sha256(b).hexdigest()
cp=json.loads((O/'cdx_uniform_72_shared_readonly_receipt.json').read_text(encoding='utf-8'))['context']
measure=json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))
p3plan=json.loads((W/'cdx_uniform_layout_v8b.json').read_text(encoding='utf-8'))
p45plan=json.loads((W/'cdx_uniform_p45_layout_source.json').read_text(encoding='utf-8'))
ramQA=json.loads((O/'cdx_uniform_68_P45_RAM_actual_QA.json').read_text(encoding='utf-8'))
tables=json.loads((O/'cdx_uniform_73_current_QH_tables_readback.json').read_text(encoding='utf-8'))
assert sha(cp['source'])==cp['source_sha256'] and sha(cp['current'])==cp['current_sha256']
assert cp['current_sha256']=='194a943e106e7a71426464823231494a2331c16bd74a0c3654d77a9dc888241a'
actual=PdfDoc(cp['current'])

def actual_controls(v,o):
 out=[];start=None
 for z in v.ops[o['i0']:o['i1']]:
  a=[float(x) for x in z.operands]
  if z.op=='m':start=a
  elif z.op=='c':
   pp=np.array([start,a[:2],a[2:4],a[4:6]],float)
   out.append((np.c_[pp,np.ones(4)]@o['ctm'])[:,:2]);start=a[4:6]
 return out
def quadratic_bounds(a,b,c):
 ts=[0.,1.]
 if abs(a)>1e-14:
  t=-b/(2*a)
  if 0<t<1:ts.append(float(t))
 vals=[a*t*t+b*t+c for t in ts]
 return {'minimum':float(min(vals)),'maximum':float(max(vals)),'critical_t':ts}
def derivative_bounds(p,d):
 z=np.diff(p[:,d]);return quadratic_bounds(float(3*(z[0]-2*z[1]+z[2])),float(6*(z[1]-z[0])),float(3*z[0]))
def bez(p,t):return (1-t)**3*p[0]+3*t*(1-t)**2*p[1]+3*t*t*(1-t)*p[2]+t**3*p[3]
def y_at_x(paths,x):
 seg=next(p for ss in paths for p in ss if p[0,0]-1e-7<=x<=p[3,0]+1e-7)
 lo,hi=0.,1.
 for _ in range(55):
  t=(lo+hi)/2
  if bez(seg,t)[0]<x:lo=t
  else:hi=t
 return float(bez(seg,(lo+hi)/2)[1])
def map_observed(value,locs,values):
 if value<locs[0]-1e-7 or value>locs[-1]+1e-7:return None
 return float(np.interp(value,locs,values))

report={'phase':'READONLY_NEW_RULE_Q_UP_H_DOWN; not PDF authoring',
 'canonical_SHA':cp['current_sha256'],'source_SHA':cp['source_sha256'],'shared_controls_seal':cp['controls']['seal_sha256'],
 'physical_rule_scope':'Q-H each same identified pump/conditions. Not eta, power or noise. No model mapping by row order/nearest source curve.',
 'method':'For every actual Bezier, compute exact quadratic derivative extrema on0..1, endpoints and interior vertex. Positive dx/dt, negative PDF dy/dt plus monotone source-calibrated axes prove Q up/H down across all cubic parameter positions. Gaps only endpoint compatibility, missing ink UNKNOWN.',
 'pages':[],'table_review':tables,'manufacturer_full_series':'UNKNOWN; numeric direction is a separate criterion',
 'numbers_proposed_to_change':[],'PDF_written':False,'p3_writer_rerun':False,'shared_store_canonical_TIEN_DO_written':False}
total_paths=total_cubics=0
for page in (3,4,5):
 mp=next(p for p in measure['pages'] if p['page']==page)
 if page==3:
  raw=actual.page_content(2);assert digest(raw)=='35b308350dab83c83b09caa552592210e49cd8b67b7235bf0cea490810c4fc93'
  group='CdxUniformOpaque';scope='ACTUAL_CANONICAL_P3_M1_194a'
  names=[c['model'] for c in p3plan['curves']];path_parts=[[1]]*4
 else:
  aq=next(p for p in ramQA['pages'] if p['page']==page)
  raw=(W/f'cdx_uniform_prepared_p{page}_RAM_content.txt').read_bytes()
  assert digest(raw)==aq['actual_content_sha256']
  group=f'CdxP45SourceOpaque_{page}';scope='PREVIOUS_CATFIX_RAM_ACTUAL_SERIALIZED_CONTENT; not current raster graph'
  lp=next(p for p in p45plan['pages'] if p['page']==page)
  names=[f'SOURCE_NUMBER_{c["number"]}; MODEL_UNKNOWN' for c in lp['source_curves']]
  path_parts=[[p['source_visible_part'] for p in c['paths']] for c in lp['source_curves']]
 v=VPage(cs.parse(raw))
 red=[o for o in v.objs if o['op']=='S' and o['gs']==group and o['stroke'][0]=='RG' and abs(o['stroke'][1][0]-210/255)<1e-8]
 black=[o for o in v.objs if o['op']=='S' and o['gs']==group and o['stroke'][0]=='RG' and max(o['stroke'][1])<1e-8]
 assert len(red)==sum(map(len,path_parts))
 nx,ny=len(mp['vertical_grid']),len(mp['horizontal_grid'])
 X=np.array([o['bbox'][0] for o in black[:nx]])
 Q=np.array([g['l_min']*.06 for g in mp['vertical_grid']])
 Y=np.array([o['bbox'][1] for o in black[nx:nx+ny]])[::-1]
 H=np.array([g['H_m'] for g in mp['horizontal_grid']])[::-1]
 axes_good=bool(np.all(np.diff(X)>0) and np.all(np.diff(Q)>0) and np.all(np.diff(Y)>0) and np.all(np.diff(H)>0))
 assert axes_good
 ax={'Q_X_pt':X.tolist(),'Q_m3_h':Q.tolist(),'H_Y_pt':Y.tolist(),'H_m':H.tolist(),
     'positive_local_Q_slope':bool(np.all(np.diff(Q)/np.diff(X)>0)),
     'positive_local_H_slope':bool(np.all(np.diff(H)/np.diff(Y)>0)),
     'method':'actual vector grid, local piecewise affine maps; no ideal global ratio or extrapolated min0'}
 result={'page':page,'readback_scope':scope,'actual_content_SHA':digest(raw),'axes':ax,'curves':[]}
 i=0
 for name,parts in zip(names,path_parts):
  cr={'identity':name,'identity_authority':'previous source label confirmed + ROOT M1/54 and current content exact' if page==3 else 'original numeric trace only; model binding CHUA_THE_XAC_MINH',
      'visible_parts':[],'source_extrema':'outer ink endpoints only; confirmed manufacturer max/min UNKNOWN'}
  paths=[]
  for part in parts:
   pts=actual_controls(v,red[i]);i+=1;paths.append(pts)
   segment_checks=[]
   for si,p in enumerate(pts):
    dx=derivative_bounds(p,0);dy=derivative_bounds(p,1)
    segment_checks.append({'segment':si+1,'actual_controls_pt':p.tolist(),'dx_dt_pt':dx,'dy_dt_pt':dy,
        'Q_strictly_increases':dx['minimum']>0,'H_strictly_decreases':dy['maximum']<0,
        'H_rises_on_nonzero_interval':dy['maximum']>1e-9})
   joins=[{'left_segment':s+1,'C0_gap_pt':float(np.linalg.norm(pts[s][-1]-pts[s+1][0])),
      'next_Q_x_increases_after_join':bool(pts[s+1][-1,0]>pts[s][-1,0]),
      'next_H_y_decreases_after_join':bool(pts[s+1][-1,1]<pts[s][-1,1])} for s in range(len(pts)-1)]
   ends=[pts[0][0],pts[-1][-1]]
   cr['visible_parts'].append({'part':part,'actual_red_path':i,'cubics':len(pts),'segments':segment_checks,'joins':joins,
      'observed_endpoint_QH':[{'PDF_point':p.tolist(),'Q_m3_h_local':map_observed(p[0],X,Q),'H_m_local':map_observed(p[1],Y,H),
          'authority':'graphic ink endpoint, not manufacturer extrema or rated min'} for p in ends],
      'status':'PASS_Q_UP_H_DOWN_ON_VISIBLE_PATH' if all(s['Q_strictly_increases'] and s['H_strictly_decreases'] for s in segment_checks) and all(j['C0_gap_pt']<1e-6 for j in joins) else 'FAIL_OR_FLAT_REVIEW',
      'full_manufacturer_series':'UNKNOWN'})
   total_paths+=1;total_cubics+=len(pts)
  if len(paths)>1:
   end,start=paths[0][-1][-1],paths[1][0][0]
   cr['missing_ink_gap']={'left_end_pdf':end.tolist(),'right_start_pdf':start.tolist(),
      'Q_increases_across_gap_endpoints':bool(start[0]>end[0]),'H_decreases_across_gap_endpoints':bool(start[1]<end[1]),
      'actual_missing_interval_direction':'UNKNOWN; two endpoint signs do not verify undrawn source gap; no bridge drawn'}
  if page==3:
   planned=next(c for c in p3plan['curves'] if c['model']==name);q,h=planned['rated_anchor_Q_m3_h'],planned['rated_anchor_H_m']
   x=float(np.interp(q,Q,X));y=y_at_x(paths,x);actual_h=float(np.interp(y,Y,H));err=actual_h-h
   cr['rated_readback']={'Q_table_m3_h':q,'H_table_m':h,'H_on_actual_path_m':actual_h,'error_m':err,
    'ROOT_corrected_exact_lock':planned['corrected_anchor'],
    'status':'LOCKED_RATED_EXACT_RETAINED' if planned['corrected_anchor'] and abs(err)<1e-4 else 'OTHER_RATED_SOURCE_FIT_WITHIN_NOMINAL_TOL; NOT_EXACT' if not planned['corrected_anchor'] and abs(err)<=max(1,.02*h) else 'FAIL',
    'no_table_or_point_change':True}
  result['curves'].append(cr)
 report['pages'].append(result)
actual.close()
report['direction_totals']={'semantic_curves':15,'actual_paths':total_paths,'cubics':total_cubics,
 'Q_H_visible_path_PASS':sum(p['status']=='PASS_Q_UP_H_DOWN_ON_VISIBLE_PATH' for pg in report['pages'] for c in pg['curves'] for p in c['visible_parts']),
 'reverse_H_segments':sum(s['H_rises_on_nonzero_interval'] for pg in report['pages'] for c in pg['curves'] for p in c['visible_parts'] for s in p['segments']),
 'strict_visible_path_FAIL_or_flat':sum(p['status']!='PASS_Q_UP_H_DOWN_ON_VISIBLE_PATH' for pg in report['pages'] for c in pg['curves'] for p in c['visible_parts']),
 'p3_current_model_paths':4,'p45_RAM_only_numeric_models_UNKNOWN':11,
 'p5_actual_missing_source_gaps_UNKNOWN':4,
 'note':'19 visible paths means 4 current + 15 RAM study parts, not19 manufacturer curves accepted and not current pages4/5 accepted'}
report['table_review_scope']={'read_current_model_header_and_QH_images73':True,'rows':16,
 'rows_per_page':[4,7,5],'rated_pairs_per_model':1,
 'multiple_Q_intermediate_series_table':'NOT_PRESENT_IN_TECHNICAL_TABLES; cannot test sequence from one pair',
 'do_not_compare_different_models_as_single_curve':True,
 'intermediate_integer_corrections':'No identified reverse segment in4 current model paths;11 source traces lack model key. No existing intermediate table cells or confirmed extrema to justify new integer replacements.',
 'maximum_minimum_and_rated':'all original numeric fields kept; absent source min not set0; graphic endpoints never relabelled manufacturer max/min',
 'root_rule_not_fully_satisfied_for_per_model_full_series':'UNKNOWN_P4_P5_MODEL_AND_FULL_DATA; no upgrade to job118'}
assert sha(cp['source'])==cp['source_sha256'] and sha(cp['current'])==cp['current_sha256']
report['input_hashes_unchanged']=True;report['disk_PDF_count']=len(list(R.rglob('*.pdf')))
assert report['disk_PDF_count']==1
(O/'cdx_uniform_74_QH_direction_actual_readonly.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'totals':report['direction_totals'],'pages':[{'page':p['page'],
 'largest_actual_dy_dt_pt':max(s['dy_dt_pt']['maximum'] for c in p['curves'] for part in c['visible_parts'] for s in part['segments']),
 'smallest_actual_dx_dt_pt':min(s['dx_dt_pt']['minimum'] for c in p['curves'] for part in c['visible_parts'] for s in part['segments'])} for p in report['pages']],
 'p3_rated':[c['rated_readback']|{'model':c['identity']} for c in report['pages'][0]['curves']],
 'intermediate_numeric_edits_proposed':0,'PDF_written':False},ensure_ascii=False))
