"""Actual CATFIX RAM readback; pikepdf and PyMuPDF only read or render.
No PDF bytes go to disk. PNGs and JSON evidence are the only saved artifacts.
"""
from pathlib import Path
import importlib.util,json,io,hashlib
import numpy as np,pikepdf,pymupdf as fitz
from PIL import Image
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
spec=importlib.util.spec_from_file_location('cdx_p45_ram',O/'cdx_uniform_65_P45_CATFIX_RAM_ONLY_builder.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
from catfix.vector import VPage
from catfix import cs
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(Path(p).read_bytes())
PH=841.9199829101562
def TL(b):return fitz.Rect(b[0],PH-b[3],b[2],PH-b[1])
def arr(p):return np.frombuffer(p.samples,np.uint8).reshape(p.height,p.width,p.n).copy()
def content(p):
 c=p.obj.get('/Contents');cc=list(c) if isinstance(c,pikepdf.Array) else [c]
 return b''.join(x.read_bytes() for x in cc)
def assets(pdf):
 result={}
 def visit(v,k,anc):
  if isinstance(v,pikepdf.Stream):
   result[k]={'raw_sha256':digest(v.read_raw_bytes()),'raw_bytes':len(v.read_raw_bytes()),
              'Filter':str(v.get('/Filter')),'Subtype':str(v.get('/Subtype'))}
  if isinstance(v,(pikepdf.Dictionary,pikepdf.Stream)):
   marker=v.objgen if v.is_indirect else ('direct',id(v))
   if marker in anc:return
   for kk,vv in v.items():
    if str(kk) not in ('/Parent','/P','/Length'):visit(vv,k+'/'+str(kk).lstrip('/'),anc|{marker})
  elif isinstance(v,pikepdf.Array):
   for i,vv in enumerate(v):visit(vv,k+'/'+str(i),anc)
 for i,p in enumerate(pdf.pages):
  for k in ('/XObject','/Font'):
   if k in p.Resources:visit(p.Resources[k],f'page{i+1}/{k[1:]}',set())
 return result
def stroke_styles(v):
 out={};st={'cap':0,'join':0,'width':1.,'stroke':['G',0.],'dash':[[],0.],'gs':None};stack=[]
 for i,o in enumerate(v.ops):
  a=o.operands
  if o.op=='q':stack.append(dict(st))
  elif o.op=='Q':st=stack.pop()
  elif o.op=='J':st['cap']=int(a[0])
  elif o.op=='j':st['join']=int(a[0])
  elif o.op=='w':st['width']=float(a[0])
  elif o.op in ('G','RG','K'):st['stroke']=[o.op]+[float(x) for x in a]
  elif o.op=='d':st['dash']=[[float(x) for x in a[0]],float(a[1])]
  elif o.op=='gs':st['gs']=str(a[0])
  elif o.op in ('S','s'):out[i]=dict(st)
 return out
def controls(v,o):
 out=[];p=None
 for ins in v.ops[o['i0']:o['i1']]:
  a=[float(x) for x in ins.operands]
  if ins.op=='m':p=a
  elif ins.op=='c':
   q=np.array([p,a[:2],a[2:4],a[4:6]],float)
   out.append((np.c_[q,np.ones(4)]@o['ctm'])[:,:2]);p=a[4:6]
 return out
def bez(p,t):return (1-t)**3*p[0]+3*t*(1-t)**2*p[1]+3*t*t*(1-t)*p[2]+t**3*p[3]
def y_at_x(segs,x):
 s=next(s for s in segs if s[0,0]-1e-7<=x<=s[3,0]+1e-7)
 lo,hi=0.,1.
 for _ in range(48):
  t=(lo+hi)/2
  if bez(s,t)[0]<x:lo=t
  else:hi=t
 return float(bez(s,(lo+hi)/2)[1])
def difference(a,b):
 d=np.max(np.abs(a.astype(np.int16)-b.astype(np.int16)),axis=2)
 return d,{'changed_pixels_threshold0':int(np.count_nonzero(d)),'max_RGB_difference':int(d.max())}

def main():
 data,pre,layout,cp=B.build_ram()
 before={k:sha(v['path']) for k,v in cp['files'].items()}
 checks={};report={'phase':'P45_CATFIX_RAM_ACTUAL_READBACK_ON_194a',
  'RAM_pdf_sha256':digest(data),'RAM_bytes':len(data),'PDF_disk_write':False,'canonical_TIEN_DO_write':False,
  'baseline194a':before['current'],'checks':checks,'pages':[],
  'graphic_acceptance':'PENDING_ROOT_AND_INDEPENDENT_GRAPHICS; limits below are not PASS',
  'source_curve_model_binding':'UNKNOWN; preserve original numeric labels and source7/4 traces',
  'job118':'CHUA_DAT; no fifth curve or model relabel authorized',
  'p3_inherited_limits':cp['p3_limits'],'font_policy':'Own-source outlines scale1; numeric/vertical-word source image islands unchanged inside; grid overlaps UNKNOWN'}
 candidate=fitz.open(stream=data,filetype='pdf');baseline=fitz.open(cp['files']['current']['path']);source=fitz.open(cp['files']['source']['path'])
 with pikepdf.open(cp['files']['current']['path']) as old,pikepdf.open(io.BytesIO(data)) as new:
  checks['five_pages']=len(old.pages)==len(new.pages)==5
  checks['all_page_boxes_rotation_preserved']=all(str(a.MediaBox)==str(b.MediaBox) and str(a.get('/CropBox'))==str(b.get('/CropBox')) and str(a.get('/Rotate'))==str(b.get('/Rotate')) for a,b in zip(old.pages,new.pages))
  checks['raw_Info_dictionary_identical']=old.docinfo.unparse()==new.docinfo.unparse()
  x0,x1=old.Root.get('/Metadata'),new.Root.get('/Metadata')
  checks['raw_XMP_identical']=(x0.read_raw_bytes() if x0 is not None else b'')==(x1.read_raw_bytes() if x1 is not None else b'')
  oa,na=assets(old),assets(new)
  missing=sorted(set(oa)-set(na));changed=sorted(k for k in oa if k in na and oa[k]!=na[k]);added=sorted(set(na)-set(oa))
  report['assets']={'baseline':oa,'RAM':na,'missing':missing,'changed_existing':changed,'new_asset_streams':added}
  checks['all_existing_font_image_streams_preserved']=not missing and not changed
  checks['no_new_font_or_image_asset_stream']=not added
  report['untouched_content']={}
  for pi in (0,1,2):
   h0,h1=digest(content(old.pages[pi])),digest(content(new.pages[pi]))
   report['untouched_content'][f'p{pi+1}']={'baseline_content_sha256':h0,'RAM_content_sha256':h1}
   checks[f'untouched_p{pi+1}_content_identical']=h0==h1
  for lp,pr in zip(layout['pages'],pre):
   pi=lp['page']-1;raw=content(new.pages[pi]);v=VPage(cs.parse(raw));ov=VPage(cs.parse(content(old.pages[pi])))
   gsname=f'CdxP45SourceOpaque_{pi+1}';gs=new.pages[pi].Resources.ExtGState['/'+gsname]
   checks[f'p{pi+1}_actual_opaque_GS']=float(gs['/CA'])==float(gs['/ca'])==1 and str(gs['/BM'])=='/Normal' and str(gs['/SMask'])=='/None'
   checks[f'p{pi+1}_actual_content_matches_prepared']=digest(raw)==pr['prepared_content_sha256']
   red=[o for o in v.objs if o['op']=='S' and o['gs']==gsname and o['stroke'][0]=='RG' and abs(o['stroke'][1][0]-210/255)<1e-8]
   black=[o for o in v.objs if o['op']=='S' and o['gs']==gsname and o['stroke'][0]=='RG' and max(o['stroke'][1])<1e-8]
   fills=[o for o in v.objs if o['op']=='f*' and o['gs']==gsname]
   paths=[controls(v,o) for o in red];styles=stroke_styles(v);rs=[styles[o['i1']] for o in red]
   expected_red=7 if pi==3 else 8
   checks[f'p{pi+1}_actual_visible_source_parts']=len(red)==expected_red
   checks[f'p{pi+1}_uniform_new_red_paths']=all(s['width']==1.28 and s['cap']==0 and s['join']==1 and s['dash']==[[],0.] and np.allclose(s['stroke'][1:],np.array([210,5,50])/255,rtol=0,atol=1e-10) for s in rs)
   checks[f'p{pi+1}_actual_black_grid_axis_tick_count']=len(black)==len(lp['grid_axes_ticks']) and all(abs(o['lw']-.7)<1e-10 for o in black)
   checks[f'p{pi+1}_actual_own_source_glyph_groups']=len(fills)==len(lp['glyph_groups']) and all(o['fill'][0]=='rg' and max(o['fill'][1])==0 for o in fills)
   orig_images=[o for o in ov.images if not o['textclip'] and o['name']==lp['source_main_image_name']]
   new_images=[o for o in v.images if not o['textclip'] and o['name']==lp['source_main_image_name']]
   checks[f'p{pi+1}_source_bitmap_Do_CTM_preserved']=len(orig_images)==len(new_images)==1 and np.array_equal(orig_images[0]['ctm'],new_images[0]['ctm'])
   origsig=[(o['name'],o['textclip'],o['ctm'].tolist()) for o in ov.images];newsig=[(o['name'],o['textclip'],o['ctm'].tolist()) for o in v.images]
   checks[f'p{pi+1}_all_original_Do_order_CTM_textclip_preserved']=origsig==newsig
   planned=[p for c in lp['source_curves'] for p in c['paths']]
   controls_error=max(float(np.max(np.abs(a-np.array(b['control_points_pt'])))) for sets,pp in zip(paths,planned) for a,b in zip(sets,pp['segments']))
   checks[f'p{pi+1}_actual_controls_match_source_plan']=controls_error<1e-6
   curve_metrics=[];idx=0
   sx,sy=json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))['pixel_to_pt']
   for c in lp['source_curves']:
    cm={'number':c['number'],'model':'UNKNOWN','parts':[]}
    for pp in c['paths']:
     ss=paths[idx];idx+=1;obs=np.array(pp['source_observed_points'])
     observed_x=(obs[:,0]+.5)*sx;actual_y_native=np.array([(PH-y_at_x(ss,float(x)))/sy-.5 for x in observed_x])
     residual=actual_y_native-obs[:,1]
     yslope=np.concatenate([np.diff(p[:,1]) for p in ss])
     cm['parts'].append({'actual_red_path':idx,'source_visible_part':pp['source_visible_part'],
        'source_x_domain_native':pp['x_domain_native'],'observation_count':len(obs),
        'actual_source_centerline_max_residual_native_px':float(abs(residual).max()),
        'actual_endpoint_residual_native_px':[float(residual[0]),float(residual[-1])],
        'H_nonincreasing_actual_controls':bool(np.all(yslope<=1e-7)),
        'source_fidelity_status':'GRAPHICAL_FIT; no pointwise or manufacturer-data PASS',
        'actual_controls_pt':[p.tolist() for p in ss]})
    curve_metrics.append(cm)
   checks[f'p{pi+1}_source_visible_endpoints_preserved_in_actual_controls']=all(max(abs(x) for x in p['actual_endpoint_residual_native_px'])<1e-5 for c in curve_metrics for p in c['parts'])
   checks[f'p{pi+1}_actual_controls_H_nonincreasing']=all(p['H_nonincreasing_actual_controls'] for c in curve_metrics for p in c['parts'])
   a=arr(baseline[pi].get_pixmap(dpi=200,alpha=False,colorspace=fitz.csRGB));b=arr(candidate[pi].get_pixmap(dpi=200,alpha=False,colorspace=fitz.csRGB))
   d,_=difference(a,b);roi=TL(lp['whole_region_pdf_pt']);scale=200/72
   xlo,ylo=int(np.floor(roi.x0*scale)),int(np.floor(roi.y0*scale));xhi,yhi=int(np.ceil(roi.x1*scale)),int(np.ceil(roi.y1*scale))
   outside=np.ones(d.shape,bool);outside[ylo:yhi,xlo:xhi]=False
   count=int(np.count_nonzero(d[outside]));maxdiff=int(d[outside].max())
   outside_stats={'threshold':0,'padding':0,'changed_pixels':count,'max_RGB_difference':maxdiff,
                  'roi_pixel_coverage_rect':[xlo,ylo,xhi,yhi],'method':'exclude only pixels intersecting physical ROI; no extra margin'}
   checks[f'p{pi+1}_outside_ROI200_threshold0_padding0']=count==0
   page={'page':pi+1,'actual_content_sha256':digest(raw),'actual_red_paths':len(red),
       'semantic_source_curves':7 if pi==3 else 4,'actual_cubic_segments':sum(len(s) for s in paths),
       'new_uniform_black_strokes':len(black),'black_own_source_filled_groups':len(fills),
       'actual_red_styles':rs,'max_control_serialization_error_pt':controls_error,
       'outside_ROI200':outside_stats,'curve_metrics':curve_metrics,'source_island_pixel_equality':[],
       'whole_source_fidelity':'UNKNOWN at crossings, original numeric islands and missing source ink; fit has nonzero residual',
       'fonts':'SOURCE_OUTLINES_PHYSICAL_SCALE1; no full source height +/-2pct acceptance at grid-overlap islands',
       'image_files':[]}
   # Render actual RAM, not a preview made from design JSON. PNGs may be saved.
   for dpi in (150,600):
    for label,doc in [('RAM',candidate),('baseline194a',baseline),('source',source)]:
     pix=doc[pi].get_pixmap(dpi=dpi,clip=roi,alpha=False,colorspace=fitz.csRGB)
     filename=f'cdx_uniform_67_P{pi+1}_{label}_chart_{dpi}dpi.png';pix.save(O/filename);page['image_files'].append(filename)
     if label=='RAM' and dpi==600:
      im=Image.fromarray(arr(pix))
      # Unscaled tiles cover the actual600 crop; no resize is used.
      xs=[(0,im.width//2),(im.width//2,im.width)];ys=[(0,im.height//2),(im.height//2,im.height)]
      for j,box in enumerate([(xa,ya,xb,yb) for ya,yb in ys for xa,xb in xs],1):
       f=f'cdx_uniform_67_P{pi+1}_RAM_600dpi_tile{j}.png';im.crop(box).save(O/f);page['image_files'].append(f)
    for island in lp['source_islands']:
     clip=TL(island['box_pdf_pt']);p0=source[pi].get_pixmap(dpi=dpi,clip=clip,alpha=False,colorspace=fitz.csRGB);p1=candidate[pi].get_pixmap(dpi=dpi,clip=clip,alpha=False,colorspace=fitz.csRGB)
     delta,ds=difference(arr(p0),arr(p1));sc=dpi/72;yy,xx=np.indices(delta.shape)
     inside=((p1.x+xx)/sc>=clip.x0)&((p1.x+xx+1)/sc<=clip.x1)&((p1.y+yy)/sc>=clip.y0)&((p1.y+yy+1)/sc<=clip.y1)
     page['source_island_pixel_equality'].append({'kind':island['kind'],'number':island['number'],'dpi':dpi,
       **ds,'full_crop_absolute_equality':'PASS' if not delta.any() else 'FAIL; explicit clip-edge differences recorded',
       'fully_inside_changed_pixels':int(np.count_nonzero(delta[inside])),
       'fully_inside_max_RGB_difference':int(delta[inside].max()) if inside.any() else None,
       'crop_box_pdf_TL':list(clip),'source_numeric_identity':'preserved original source glyph; model binding UNKNOWN'})
   # Separate200 islands: strict full equality never inferred from fully-inside test.
   for island in lp['source_islands']:
    clip=TL(island['box_pdf_pt']);p0=source[pi].get_pixmap(dpi=200,clip=clip,alpha=False,colorspace=fitz.csRGB);p1=candidate[pi].get_pixmap(dpi=200,clip=clip,alpha=False,colorspace=fitz.csRGB)
    delta,ds=difference(arr(p0),arr(p1));sc=200/72;yy,xx=np.indices(delta.shape)
    inside=((p1.x+xx)/sc>=clip.x0)&((p1.x+xx+1)/sc<=clip.x1)&((p1.y+yy)/sc>=clip.y0)&((p1.y+yy+1)/sc<=clip.y1)
    page['source_island_pixel_equality'].append({'kind':island['kind'],'number':island['number'],'dpi':200,**ds,
      'full_crop_absolute_equality':'PASS' if not delta.any() else 'FAIL; explicit clip-edge differences recorded',
      'fully_inside_changed_pixels':int(np.count_nonzero(delta[inside])),
      'fully_inside_max_RGB_difference':int(delta[inside].max()) if inside.any() else None,
      'crop_box_pdf_TL':list(clip),'source_numeric_identity':'preserved original source glyph; model binding UNKNOWN'})
    for name,pix in [('source',p0),('RAM',p1)]:
     num=str(island['number']);f=f'cdx_uniform_67_P{pi+1}_island_{num}_{name}_200dpi.png';pix.save(O/f);page['image_files'].append(f)
   checks[f'p{pi+1}_source_islands_fully_inside_pixels_identical']=all(s['fully_inside_changed_pixels']==0 for s in page['source_island_pixel_equality'])
   if pi==4:
    # Actual new vector paths never cross the source strip; render confirms no red.
    gap_native=[438,mpy0:=next(p for p in json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))['pages'] if p['page']==5)['plot_native_pixel_box'][1],462,
          next(p for p in json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))['pages'] if p['page']==5)['plot_native_pixel_box'][3]]
    gap=fitz.Rect(gap_native[0]*sx,gap_native[1]*sy,gap_native[2]*sx,gap_native[3]*sy)
    ap=arr(candidate[pi].get_pixmap(dpi=150,clip=gap,alpha=False,colorspace=fitz.csRGB)).astype(np.int16)
    page['source_blank_label_strip']={'native_columns':[438,461],'actual_RAM_red_pixels_threshold55':int(np.count_nonzero(ap[:,:,0]-np.maximum(ap[:,:,1],ap[:,:,2])>55)),
       'status':'UNKNOWN_SOURCE_HAS_NO_INK; no connecting segment or fifth curve created'}
    checks['p5_no_new_path_bridges_source_blank_strip']=all(ss[-1][3,0]<438*sx if j%2==0 else ss[0][0,0]>461*sx for j,ss in enumerate(paths))
   report['pages'].append(page)
 for pi in (0,1,2):
  checks[f'untouched_p{pi+1}_full_pixels_identical200']=candidate[pi].get_pixmap(dpi=200,alpha=False,colorspace=fitz.csRGB).samples==baseline[pi].get_pixmap(dpi=200,alpha=False,colorspace=fitz.csRGB).samples
 checks['source_canonical_hashes_unchanged']=before=={k:sha(v['path']) for k,v in cp['files'].items()}
 checks['one_existing_PDF_only_no_new_disk_PDF']=len(list(R.rglob('*.pdf')))==1 and not (W/'cdx_uniform_P45_RAM_ONLY_NEVER_DISK.pdf').exists()
 report['source_current_sha256_after']={k:sha(v['path']) for k,v in cp['files'].items()}
 checks={k:bool(v) for k,v in checks.items()};report['checks']=checks
 report['technical_checks_pass']=all(checks.values())
 report['fail_checks']=[k for k,v in checks.items() if not v]
 report['overall']='RAM_TECHNICAL_PRESERVATION_PASS_WITH_EXPLICIT_LIMITS; GRAPHIC_PENDING' if all(checks.values()) else 'RAM_TECHNICAL_CHECK_FAIL; DO_NOT_SAVE'
 (O/'cdx_uniform_68_P45_RAM_actual_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 (O/'cdx_uniform_66_P45_CATFIX_RAM_preflight.json').write_text(json.dumps({'RAM_pdf_sha256':digest(data),'RAM_bytes':len(data),
   'PDF_disk_write':False,'canonical_TIEN_DO_write':False,'baseline194a':before['current'],'page_reports':pre,
   'actual_QA_file':'cdx_uniform_68_P45_RAM_actual_QA.json','status':report['overall']},ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'overall':report['overall'],'check_count':len(checks),'fail_checks':report['fail_checks'],
  'pages':[{'page':p['page'],'outside_ROI200':p['outside_ROI200'],
    'max_actual_source_residual_px':max(z['actual_source_centerline_max_residual_native_px'] for c in p['curve_metrics'] for z in c['parts']),
    'island_full_equality_fail_count':sum(z['full_crop_absolute_equality'].startswith('FAIL') for z in p['source_island_pixel_equality']),
    'island_fully_inside_changed_total':sum(z['fully_inside_changed_pixels'] for z in p['source_island_pixel_equality'])} for p in report['pages']],
  'PDF_disk_write':False},ensure_ascii=False))
 candidate.close();baseline.close();source.close()

if __name__=='__main__':main()
