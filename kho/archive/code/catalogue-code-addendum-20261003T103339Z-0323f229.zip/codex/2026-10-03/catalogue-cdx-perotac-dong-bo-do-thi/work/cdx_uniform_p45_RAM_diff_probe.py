from pathlib import Path
import importlib.util,json,numpy as np,cv2,pymupdf as fitz
from PIL import Image
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
sp=importlib.util.spec_from_file_location('ram',O/'cdx_uniform_65_P45_CATFIX_RAM_ONLY_builder.py');b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
data,_,layout,cp=b.build_ram();old=fitz.open(cp['files']['current']['path']);new=fitz.open(stream=data,filetype='pdf')
def a(p):return np.frombuffer(p.samples,np.uint8).reshape(p.height,p.width,p.n)
out=[]
for lp in layout['pages']:
 pi=lp['page']-1;s=200/72;roi=lp['whole_region_pdf_pt'];PH=841.9199829101562
 x0,x1=int(np.floor(roi[0]*s)),int(np.ceil(roi[2]*s));y0,y1=int(np.floor((PH-roi[3])*s)),int(np.ceil((PH-roi[1])*s))
 aa=a(old[pi].get_pixmap(dpi=200,alpha=False));bb=a(new[pi].get_pixmap(dpi=200,alpha=False));d=np.max(np.abs(aa.astype(np.int16)-bb.astype(np.int16)),2);m=d>0;m[y0:y1,x0:x1]=0
 nc,lab,stats,_=cv2.connectedComponentsWithStats(m.astype('uint8'),8)
 components=[]
 for j in range(1,nc):
  x,y,w,h,n=map(int,stats[j]);components.append({'box_pixel200':[x,y,x+w,y+h],'area':n,'maxRGB':int(d[lab==j].max())})
 yy,xx=np.where(m);bound=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)] if len(xx) else None
 out.append({'page':pi+1,'outside_count':int(m.sum()),'extent':bound,'components':components})
 if bound:
  im=bb.copy();im[~m]=255;Image.fromarray(im).save(W/f'cdx_uniform_p{pi+1}_RAM_outside_diff200.png')
(W/'cdx_uniform_p45_RAM_diff_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps([{'page':p['page'],'outside_count':p['outside_count'],'extent':p['extent'],'component_count':len(p['components']),
 'largest_components':sorted(p['components'],key=lambda c:c['area'],reverse=True)[:10]} for p in out]))
old.close();new.close()
