from pathlib import Path
import os,sys,json,hashlib,numpy as np
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
os.environ['CATFIX_CACHE']=str(W/'cdx_uniform_cache')
sys.path.insert(0,r'D:\TempSystem\catfix_work\catfix_pkg\GOI_SUA_CATALOGUE_CHATGPT')
from catfix.vector import Editor
cp=json.loads((W/'cdx_uniform_p45_rebase194.json').read_text(encoding='utf-8'))
ed0=Editor(cp['files']['source']['path']);ed1=Editor(cp['files']['current']['path']);out=[]
for pi,name in ((3,'X13'),(4,'X19')):
 a,b=ed0.page(pi),ed1.page(pi)
 aa=next(i for i in a.images if i['name']==name and not i['textclip']);bb=next(i for i in b.images if i['name']==name and not i['textclip'])
 raw0=ed0.doc._pages[pi].Resources.XObject['/'+name].read_raw_bytes();raw1=ed1.doc._pages[pi].Resources.XObject['/'+name].read_raw_bytes()
 out.append({'page':pi+1,'main_image':name,'source_raw_SHA':hashlib.sha256(raw0).hexdigest(),'canonical_raw_SHA':hashlib.sha256(raw1).hexdigest(),
   'raw_source_stream_identical':raw0==raw1,'source_main_CTM':aa['ctm'].tolist(),'canonical_main_CTM':bb['ctm'].tolist(),
   'CTM_identical':np.array_equal(aa['ctm'],bb['ctm']),
   'pixel_limit':'even exact raw stream+CTM does not prove crop pixel equality after new clip; actual FAILs retained in68'})
(O/'cdx_uniform_68b_P45_source_image_identity.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out));ed0.close();ed1.close()
