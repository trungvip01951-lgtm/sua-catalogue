from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,hashlib
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=json.loads((W/'cdx_uniform_p45_rebase194.json').read_text(encoding='utf-8'))
qa=json.loads((O/'cdx_uniform_68_P45_RAM_actual_QA.json').read_text(encoding='utf-8'))
pf=json.loads((O/'cdx_uniform_66_P45_CATFIX_RAM_preflight.json').read_text(encoding='utf-8'))
layout=json.loads((W/'cdx_uniform_p45_layout_source.json').read_text(encoding='utf-8'))
assert qa['RAM_pdf_sha256']==pf['RAM_pdf_sha256']
assert [x for x,v in qa['checks'].items() if not v]==['p4_source_islands_fully_inside_pixels_identical']
for k,v in cp['files'].items():assert sha(v['path'])==v['sha256_before']
assert len(list(R.rglob('*.pdf')))==1
checks=qa['checks'];passed=sum(checks.values());total=len(checks)
rows=[
 ('114','4','Dòng điện 380V:18','1.8 đã có ở bản chính194a','Bảo toàn sửa CATFIX pha trước; RAM chỉ ở đồ thị','ĐẠT theo ROOT trước; bảo toàn','68: ngoài vùng trang4 tại200dpi khác0pixel; các bảng nguyên'),
 ('115','5','CDX200/185 lặp','Hàng thứ hai CDX200/185-B ở cả hai bảng, đã có194a','Bảo toàn sửa pha trước; không suy ra danh tính đường từ hậu tốB','ĐẠT theo ROOT trước; bảo toàn','68: ngoài vùng trang5 khác0pixel;57/59: hai185 cùng ứng viên số4'),
 ('116','3–5','Techni cal par ameter list; Reted; Kw','Technical parameter list; Rated; kW đã có194a','Giữ bảng/tiêu đề pha trước','ĐẠT theo ROOT trước; bảo toàn','68: content trang3 và toàn trang3 tại200dpi nguyên; bảng4/5 ngoài vùng nguyên'),
 ('117','2','housring; O-Rring; Flanqe; washar','housing; O-Ring; Flange; washer đã có194a','Giữ sửa CATFIX pha trước','ĐẠT theo ROOT trước; bảo toàn','61/68: content và toàn trang2 tại200dpi trùng194a'),
 ('118','3–5','Trang4 có7 đường số; trang5 có4 đường số/5 model; khóa model chưa đủ','Trang3 M1 đã ROOT nghiệm thu; chỉ RAM trang4 giữ7 đường, trang5 giữ4 đường/8 đoạn thấy mực; nhãn số nguồn giữ','CATFIX dựng cả đồ thị từ mực nguồn, trục/lưới địa phương và chữ nguồn; PDF chỉ trong BytesIO','CHƯA ĐẠT. RAM40/41 kiểm kỹ thuật; FAIL10pixel nội bộ nhãn trang4; toàn hình thức/dữ liệu UNKNOWN','62 là báo cáo trướcRAM;63–68b là kế hoạch/ảnh/readback thực; nguồn54/55 và57–59 giữ giới hạn'),
 ('119','1–2','steelhorizontal; CDX 90 / 120 /200','steel horizontal; khoảng cách tiêu đề đều đã có194a','Giữ sửa CATFIX pha trước','ĐẠT theo ROOT trước; bảo toàn','61/68: content và toàn trang1/2 tại200dpi trùng194a'),
 ('159','1','Phần giải thích ký hiệu model','Đã xóa theo duyệt trước, có194a','Giữ sửa pha trước','ĐẠT theo ROOT trước; bảo toàn','61/68: content và toàn trang1 tại200dpi trùng194a'),
 ('160','3–5','Tên /0x như CDX90/05','/5 và các /0x đã chuẩn hóa trong194a; RAM4/5 giữ nhãn số','Giữ sửa pha trước; không thêm model trên đường khi chưa có khóa','ĐẠT theo ROOT trước; bảo toàn','68: bảng/ngoài vùng nguyên;57/59: gắn model vẫn UNKNOWN')]
text=['# G15 CDX — báo cáo 8 cột và bàn giao RAM trang 4–5','',
 'Kết luận: bản chính194a và trang3 M1 đã nghiệm thu được giữ nguyên. Pha này đã lập báo cáo8 cột trước khi dựng RAM (file62), dựng và đọc lại PDF CATFIX thực trong bộ nhớ. Mẫu trang4/5 chưa đạt nghiệm thu: 40/41 kiểm kỹ thuật đạt, còn FAIL10pixel bên trong nhãn số trang4 tại200dpi, maxRGB1. Không xuất PDF mới, không ghi bản chính hoặc TIEN DO. Trạng thái gốc giữ ĐẠT7/8 theo ROOT; việc118 CHƯA ĐẠT.','',
 '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
 '|---|---|---|---|---|---|---|---|']
for n,page,old,new,method,status,evidence in rows:text.append(f'| #{n} | CDX Perotac (bản mới).pdf | {page} | {old} | {new} | {method} | {status} | {evidence} |')
text += ['',
 '## Bảo toàn đã kiểm bằng dữ liệu thực','',
 'File68 đọc các trang/resources/path từ byte PDF do CATFIX Editor.save xuất vào BytesIO và render chính byte đó. Trang1/2/3 giữ nguyên content SHA và ảnh toàn trang200dpi so với194a. Ngoài vùng đồ thị4/5: threshold0, padding0, khác0pixel/maxRGB0. Giữ5 trang, MediaBox/CropBox/rotation, Info/XMP, mọi stream font và XObject cũ; không thêm stream font/ảnh. X13/X19 giữ byte và CTM, đồng thời trùng ảnh nguồn gốc (file68b). Mọi bảng không chạm và ảnh phần đó nguyên.','',
 '| Trang | Đường nguồn ngữ nghĩa | Path đỏ mới | Cubic mới | Nét lưới/trục/tick mới | Nhóm chữ nguồn f* | Kết quả ngoài vùng200 |',
 '|---|---:|---:|---:|---:|---:|---|',
 '| 4 | 7 | 7 | 81 | 66 | 115 | 0pixel/max0 |',
 '| 5 | 4 | 8 (hai đoạn/đường) | 31 | 62 | 123 | 0pixel/max0 |','',
 'Nét vector đỏ mới cùng1.28pt, RGB210/5/50, cap0/join1, dash rỗng, opaque Normal. Lưới/trục mới đen0.70pt. Những con số này chỉ mô tả vector mới; không phải PASS đồng nhất mọi nét/chữ nhìn thấy. Nhãn số1–7/1–4 và từ xoay không đọc chắc được giữ qua các vùng nhỏ của ảnh nguồn, còn lưới/nét đỏ/JPEG nằm cùng vùng. Chiều cao toàn glyph sát lưới ±2% UNKNOWN; không dùng font hệ thống hoặc giả một tên font. Nhóm f*115/123 là nhóm thành phần mực đã nối, không phải số ký tự Unicode đã xác minh.','',
 '## FAIL và UNKNOWN giữ nguyên','',
 'FAIL nội bộ nguồn tại200dpi: nhãn3 trang4 khác2pixel, nhãn4 khác3, nhãn5 khác4, nhãn6 khác1; đều maxRGB1. So sánh toàn crop tuyệt đối cũng FAIL ở8 vùng trang4 và5 vùng trang5 tại200dpi (có sai khác mép lớn hơn); không đổi FAIL toàn crop thành PASS từ phép kiểm vùng trong. Tại150/600dpi toàn crop các vùng đã kiểm trùng nguồn; trang5 vùng trong tại150/200/600 trùng. Bằng chứng byte ảnh/CTM trùng không thay cho điều kiện pixel trùng. Sau một lần sửa cửa sổ nhãn4/5 bị cắt và mépROI trang5, vẫn còn lỗi trên; mẫu đóng băng ở trạng thái FAIL.','',
 'Các đường là fit đồ họa từ tâm mực đã lọc, không phải giữ chính xác mọi điểm. Sai lệch tâm nét tối đa khi đọc path RAM: trang4 2.492088px nguồn150dpi, trang5 2.293156px. Đầu-cuối ngoài của7/4 đường lấy từ cửa sổ nguồn và giữ trong path; các đoạn giao/đè mực có danh tính tâm riêng UNKNOWN. Phần fit giữa các điểm quan sát là suy luận đồ họa; không chốt toàn bộ Q–H nhà sản xuất.','',
 'Trang5 nguồn không có mực đỏ ở cột438–461. RAM cũng0pixel đỏ threshold55 trong dải đó và không có path nối qua. Không thêm đường thứ5. Các mảnh trước/sau dải nhãn dùng miền quan sát đã lọc: số1 [336,437]/[463,607]; số2 [336,437]/[462,939]; số3 [336,433]/[462,650]; số4 [336,436]/[463,676]. Những mép mảnh ở433/436/462/463 còn thiếu khóa điểm kết thúc đầy đủ của mực sát lưới/dải nhãn; giữ UNKNOWN, không coi việc khớp endpoint của bộ điểm lọc là bảo toàn mọi đoạn nguồn.','',
 'Khóa model vẫn chưa đủ: trang4 không có hoán vị7/7 cùng đạt dung sai tâm nét max(1m,2%H), 90/15 và120/15 cùng ứng viên số4. Trang5 150/150-B có hai hoán đổi số2/3 nếu dùng đủ4 đường; hai185 cùng ứng viên số4. Dữ liệu57/58/59 là chẩn đoán phù hợp tâm mực, không phải phê duyệt gắn model. Giữ nhãn số; không sửa rated/bảng theo quyền Excel chốt số trung gian.','',
 'Trang3 giữ mốc ROOT đã chốt: hình thức M1 và hai neo Q3/H11, Q5/H12; toàn series nhà sản xuất UNKNOWN. Giữ giới hạn14 chiều cao glyph UNKNOWN, full crop200 FAIL69pixel cạnh/max8, vùng trong0; hai rated còn lại là source-fit trong dung sai danh nghĩa. Pha4/5 không sửa hoặc nâng trạng thái các giới hạn này.','',
 '## Ảnh và mã kiểm','',
 '[Trang4 RAM150dpi](cdx_uniform_67_P4_RAM_chart_150dpi.png) · [Nguồn trang4](cdx_uniform_67_P4_source_chart_150dpi.png) · [Trang5 RAM150dpi](cdx_uniform_67_P5_RAM_chart_150dpi.png) · [Nguồn trang5](cdx_uniform_67_P5_source_chart_150dpi.png). Bộ67 có ảnh nguồn/bản194a/RAM ở150/600dpi và8 tile600dpi nguyên kích thước, không resize. Worker đã xem hai toàn đồ thị150 và đủ8 tile600 sau sửa cửa sổ nhãn. Nhãn số còn là ảnh raster; lưới cạnh nhãn4/5 không đồng đều tuyệt đối; trang5 còn vài chấm mực nguồn sát mép tick H30/20/10. Chưa nghiệm thu toàn hình thức.','',
 'File65 chỉ có builder CATFIX RAM; file66 là preflight đúng byte RAM được file68 đọc. Các script nghiên cứu/kiểm ởwork, danh mục SHA và bằng chứng ởfile70. Không chạy lại inventory/writer01–60 vốn khóa887f; không chạy writer50 lần nữa. Builder65 không có writer disk, không mở khóa ngân sách và không được dùng để lưu mẫu thứ2. Chỉ sau khi giải quyết FAIL/UNKNOWN và ROOT cùng kiểm đồ họa độc lập chấp nhận mới xem xét bước cấp PDF.','',
 'VùngROI trang5 đã chọn lại mép trái134.5px trong khoảng trắng nguồn (trước135px); file64 ghi rõ lý do ảnh200dpi ở mép clip. Đây là footprint thật dùng cả builder và phép kiểm, không có padding hoặc threshold bù thêm. Cửa sổ nhãn4/5 trang4 được mở theo ảnh nguồn600 để giữ đủ nét trái, không gõ lại hoặc vẽ bù chữ.','',
 f"SHA nguồn `{cp['files']['source']['sha256_before']}`. SHA bản chính194a/M1 `{cp['files']['current']['sha256_before']}`. SHA RAM được kiểm `{qa['RAM_pdf_sha256']}` (byte chỉ trong bộ nhớ). Ngân sách cảCDX đã dùng1/2 từ M1; pha này thêm0 PDF. Tất cả file01–60 giữ lịch sử, gồm dòng nghiệm thu M1 từng PENDING ở60; mốc61/62/69 là trạng thái mới sau ROOT đã lưu194a."]
report=O/'cdx_uniform_69_G15_8_columns_P45_RAM_handoff.md';report.write_text('\n'.join(text)+'\n',encoding='utf-8')
filepaths=[*sorted(O.glob('cdx_uniform_6*')),O/'cdx_uniform_57_P4_P5_source_matching.json',O/'cdx_uniform_58_P4_P5_candidate_matrix.csv',O/'cdx_uniform_59_P4_P5_readonly_report.md',
 W/'cdx_uniform_p45_rebase194.json',W/'cdx_uniform_p45_geometry_source.json',W/'cdx_uniform_p45_layout_source.json',
 W/'cdx_uniform_p45_geometry.py',W/'cdx_uniform_p45_layout.py',W/'cdx_uniform_p45_RAM_actual_audit.py',W/'cdx_uniform_p45_source_image_identity.py',
 W/'cdx_uniform_prepared_p4_RAM_content.txt',W/'cdx_uniform_prepared_p5_RAM_content.txt']
filepaths=list(dict.fromkeys(p for p in filepaths if p.is_file() and p.name!='cdx_uniform_60_P4_P5_handoff_manifest.json'))
manifest={'phase':'P45_PLAN_RAM_READBACK_HANDOFF_ON194a; NOT_ACCEPTED_FOR_DISK_PDF',
 'time_VN':datetime.now(timezone(timedelta(hours=7))).isoformat(),
 'original_jobs':8,'previous_ROOT_accepted_jobs_retained':7,'job118':'CHUA_DAT',
 'RAM_technical_checks':{'pass':passed,'total':total,'FAIL':qa['fail_checks']},
 'full_graphic_acceptance':'NOT_ACCEPTED; source islands pixel FAIL and font/source gap/fidelity UNKNOWN',
 'canonical_TIEN_DO_written':False,'PDF_written_this_phase':0,'whole_CDX_PDF_budget_used_total':'1/2',
 'no_more_PDF_save_authorization':True,'new_builder_scope':'CATFIX Editor.save to BytesIO only; virtual .pdf sentinel must never exist',
 'RAM_pdf_sha256_observed':qa['RAM_pdf_sha256'],'RAM_bytes':qa['RAM_bytes'],
 'prepared_actual_content_sha256':{f"p{p['page']}":p['actual_content_sha256'] for p in qa['pages']},
 'preserved_inputs':cp['files'],
 'preserved_canonical_is_exact_local_M1':sha(cp['files']['current']['path'])==sha(O/'cdx_uniform_P3_WHOLE_M1_v8c_20261003.pdf'),
 'stale_887f_history':'01–60 historical. M1 now ROOT accepted/current194a; never rerun old pinned writer/inventory.',
 'source_mapping_reference_57_59':'sourceef observations still valid; their current887f references are historical only',
 'limitations':{
  'p4_inside_pixel_FAIL200':{'count':10,'maximum_RGB_difference':1,'by_numeric_label':{'3':2,'4':3,'5':4,'6':1}},
  'full_crop_equality':'p4 8 FAIL and p5 5 FAIL at200; no masking or tolerance change',
  'max_centerline_fit_residual_native150_px':{'p4':2.4920882935363124,'p5':2.29315598575738},
  'numeric_font_under_grid':'UNKNOWN; original image+CTM kept but mixed grid/JPEG islands remain',
  'p5_no_red_source_strip':'438..461 UNKNOWN; no bridge or fifth curve',
  'model_manufacturer_identity':'UNKNOWN; p4 no nominal one-to-one solution; p5 2/3 ambiguity'},
 'files':[{'path':str(p),'relative_path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size} for p in filepaths]}
(O/'cdx_uniform_70_P45_RAM_handoff_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'report69':str(report),'manifest70_files':len(filepaths),'RAM_pass_checks':passed,'RAM_total_checks':total,
 'FAIL':qa['fail_checks'],'canonical_SHA_after':sha(cp['files']['current']['path']),'disk_PDF_count':len(list(R.rglob('*.pdf')))},ensure_ascii=False))
