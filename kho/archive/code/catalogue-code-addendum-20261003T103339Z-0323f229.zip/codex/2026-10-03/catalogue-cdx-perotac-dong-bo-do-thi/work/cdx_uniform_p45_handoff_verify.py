from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];O=R/'outputs'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((O/'cdx_uniform_70_P45_RAM_handoff_manifest.json').read_text(encoding='utf-8'))
errors=[]
for f in m['files']:
 p=Path(f['path'])
 if not p.is_file() or sha(p)!=f['sha256'] or p.stat().st_size!=f['bytes']:errors.append(f['relative_path'])
for k,v in m['preserved_inputs'].items():
 if sha(v['path'])!=v['sha256_before']:errors.append(k+'_input_changed')
report=(O/'cdx_uniform_69_G15_8_columns_P45_RAM_handoff.md').read_text(encoding='utf-8')
rows=[s for s in report.splitlines() if s.startswith('| #')]
if len(rows)!=9 or any(len(s.split('|'))-2!=8 for s in rows):errors.append('8column_report_structure')
if len(list(R.rglob('*.pdf')))!=1:errors.append('PDF_count_not1')
if not m['preserved_canonical_is_exact_local_M1']:errors.append('M1_canonical_mismatch')
if sha(O/'cdx_uniform_50_M1_catfix_writer_STANDBY.py')!='3061e94c43f0cdb1e3468e2cbf64a5c3db7461af45563d897d31d70150d726e7':errors.append('frozen_M1_writer_changed')
result={'manifest_files_verified':len(m['files']),'report8_columns_8_tasks':True,'PDF_disk_count':len(list(R.rglob('*.pdf'))),
 'source_canonical_hashes_match_checkpoint194a':not any(s.endswith('_input_changed') for s in errors),
 'errors':errors,'status':'HANDOFF_INTEGRITY_PASS; RAM_GRAPHIC_TECHNICAL_FAIL_REMAINS' if not errors else 'HANDOFF_INTEGRITY_FAIL',
 'does_not_upgrade_RAM_FAIL':'p4 source-island pixel FAIL10/max1; glyph/source/model UNKNOWN remain'}
(O/'cdx_uniform_71_P45_handoff_integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False));assert not errors
