from pathlib import Path
import json,hashlib,csv
from datetime import datetime,timezone,timedelta
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
A=json.loads((O/'cdx_uniform_74_QH_direction_actual_readonly.json').read_text(encoding='utf-8'))
S=json.loads((O/'cdx_uniform_74b_SOURCE_ink_direction_readonly.json').read_text(encoding='utf-8'))
C=json.loads((O/'cdx_uniform_72_shared_readonly_receipt.json').read_text(encoding='utf-8'))
assert A['direction_totals']['Q_H_visible_path_PASS']==19 and A['direction_totals']['reverse_H_segments']==0
assert S['totals']['direction_separable_source_rises']==0
base=(O/'cdx_uniform_69_G15_8_columns_P45_RAM_handoff.md').read_text(encoding='utf-8').splitlines()
rows=[s for s in base if s.startswith('| #') and not s.startswith('| # việc')]
assert len(rows)==8 and all(len(s.split('|'))-2==8 for s in rows)
new118='| #118 | CDX Perotac (bản mới).pdf | 3–5 | Yêu cầu mới: Q tăng/H giảm trong cùng mã; model đường4/5 chưa rõ | Đã đọc quy tắc và rà4path bản chính p3 +15path RAM4/5,117cubic; giữ rated/điểm quan sát và mọi bảng | Kiểm cực trị đạo hàm thực trên toàn cubic + đọc16dòngRated; rà mực nguồn riêng, chỉ đọc | CHƯA ĐẠT toàn118.19path vẽ giảm đúng chiều; danh tính11đường/4khoảng thiếu mực/source toànseries UNKNOWN; RAM cònFAIL10pixel | 72: đọc kho niêm phong;73: ảnh bảng mã/đầu cột;74: actualpaths;74b: source;69/68: FAIL hình thức giữ |'
rows=[new118 if s.startswith('| #118 |') else s for s in rows]
text=['# G15 CDX — bổ sung rà Q tăng/H giảm và báo cáo 8 cột','',
 'Kết luận: bốn đường trang3 trên bản chính194a giảm H khi Q tăng. Mười lăm path nhìn thấy của nghiên cứu RAM trang4/5 (7 đường trang4, 4 đường trang5 chia hai đoạn) cũng giảm đúng chiều; đã kiểm đủ117 đoạn cubic, không chỉ lấy vài mẫu. Đây là ĐẠT riêng chiều vẽ, chưa nghiệm thu toàn số hay hình thức. Việc118 vẫn CHƯA ĐẠT, G15 giữ7/8 gốc theo ROOT. Không đề xuất thay số trung gian, không ghi PDF hoặc bản chính, không chạy lại writerp3.','',
 '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
 '|---|---|---|---|---|---|---|---|',*rows,'',
 '## Phạm vi và bằng chứng thực','',
 'Đã tự đọc START_HERE, AGENTS, manifest, hai quy tắc, sổ TIEN DO gốc, CURRENT_CHECKPOINT, quy trình đường đặc tính và sổ lỗi tại D:\\ChatGPT\\Sửa catalogue. health/status/context đọc thật, luật và đầu vào khớp bản chụp; ROOT đang niêm phong nên receipt chỉ lưu cục bộ file72, không gọi receipt/claim/refresh hoặc ghi kho chung. health ĐẠT là kiểm cấu trúc, không thay kiểm số/phông/đồ họa.','',
 'File74 đọc content trang3 từ canonical194a bằng CATFIX PdfDoc (chỉ đọc); trang4/5 đọc content thực đã được CATFIX xuất RAM và kiểm ở68, đối chiếu SHA từng stream. Không tạo một PDF RAM mới trong pha rà này. Kiểm chính xác cực trị đa thức bậc2 của dx/dt và dy/dt cho từng đoạn Bézier ở hai đầu và đỉnh trong0..1. Trục Q/H dùng vạch thực và ánh xạ từng đoạn; Q(x) và H(yPDF) đều tăng. Tất cả117 đoạn có dx/dt>0, dy/dt<0 nên H giảm khi Q tăng trên mọi phần đã vẽ, kể cả giữa các mẫu. Không có đoạn quay ngược Q hoặc plateau H trong các path này.','',
 '| Trang/bản được đọc | Đường theo danh tính đang có | Path/đoạncubic | Chiều Q–H | Giới hạn |',
 '|---|---|---|---|---|',
 '| 3/bản chính194a | 4 model đã khóa nhãn nguồn | 4path/5cubic | ĐẠT: không có đoạn tăng ngược | Toàn bảngQ–H hãng/extrema chưa có; không nâng từ hai rated sang toànseries |',
 '| 4/RAM đã đọc thực68 | 7 nhãn số nguồn | 7path/81cubic | ĐẠT trên phần vector đã vẽ | Ghép7model chưa đủ; mực giao/đè và sai lệch fit giữ UNKNOWN |',
 '| 5/RAM đã đọc thực68 | 4 nhãn số nguồn | 8path/31cubic | ĐẠT trên hai mảnh/đường; đầu hai mảnh tương thích chiều giảm | 4 khoảng thiếu mực vẫn UNKNOWN; không nối hoặc thêm đường5 |','',
 'Không diễn giải19path là19 đường nhà sản xuất đã đạt; nguồn chỉ4+7+4 đường. Trang4/5 bản chính vẫn là đồ thị raster cũ, nghiên cứu RAM chưa được tiếp nhận. Dấu đạo hàm của RAM không tự chứng nội dung mực nguồn hoặc đúng danh tính từng model.','',
 '## Rà mực nguồn riêng và bảng','',
 'File74b đọc ảnh nguồn mới tại150dpi, rà15trace bằng số/nhãn nguồn trên19mảnh quan sát. Tâm mực có98 bước H tăng danh nghĩa rất nhỏ (41 trang3,44 trang4,13 trang5); mức lớn nhất lần lượt0.020699m,0.257554m,0.183620m theo trục nguồn. Chưa có bước tăng tách biệt chắc bằng toàn bề rộng mực nét ở hai cột liền nhau. Những bước này vẫn ghi UNKNOWN theo mực JPEG, chỗ lưới che và giao nét; không gọi chắc là dữ liệu bơm sai, cũng không nhận toàn nguồn ĐẠT. Các cột/khoảng không đọc chắc được lưu riêng, không nội suy để biến thiếu phủ thành0lỗi.','',
 'Ảnh73 có tên mã, đầu cột Rated head/flow và toàn16dòng số:4 ởtrang3,7 ởtrang4,5 ởtrang5. Mỗi model chỉ có một cặp định mức, không có dãy nhiều Q cùngmodel để kiểm tăng/ngược hoặc các ô H trung gian sẵn có cần thay. Không so H theo thứ tự các dòng model khác nhau.','',
 'Giữ đúng hai rated đã chốt: CDX50/37(T) Q3/H11 và CDX100/55(T) Q5/H12; path194a lần lượt H10.9999999996 và11.9999999995. Hai rated còn lại giữ bảng và giới hạn cũ: CDX90/37(T) Q4.2/H13 có pathH12.0708665398 (lệch−0.9291334602m); CDX50/25(T) Q3/H9 cópathH9.5672430261 (lệch+0.5672430261m). Đó là source-fit trong dung sai danh nghĩa cũ, không phải đúng tuyệt đối điểm định mức; không đổi13 thành12 hoặc9 thành10 để chạy theo đường. Pha mới chưa đổi các điểm này hay chạy lại writerp3.','',
 'Trang4/5 còn thiếu khóa model: 90/15 và120/15 cùng ứng viên số4; trang5 hai150 có hoán đổi2/3 và hai185 cùng ứng viên4. Quyền Q tăng/H giảm không cho chọn số theo đường gần nhất, dùng thứ tự model, tự gắn mãB hay thêm đường thứ5. Các rated bảng đều giữ. Đầu-cuối mực nguồn được bảo toàn trong phương án đồ họa là bằng chứng hình, chưa phải Qmax/Hmax/Qmin/Hmin nhà sản xuất; min thiếu không gán0.','',
 'Đề xuất số nguyên cần sửa trong pha này: **0 giá trị**. Bốn model định danh trang3 không phát hiện đoạn tăng ngược;11 đường nguồn trang4/5 thiếu khóa model và các bảng không có ô trung gian. Không có căn cứ để đề xuất một số thay cụ thể. Nếu đọc thêm chuỗi Q–H đã định danh, mới kiểm cùngmodel và đề xuất nguyên, giữ các cực trị/rated đã xác định; khóa mâu thuẫn sẽ ghi đúng hai cặp mâu thuẫn, không phá khóa.','',
 '## Bảo toàn và bước tiếp','',
 'Bản nguồn SHA ef57… và bản chính194a… giữ nguyên; số PDF trong cwd vẫn1 (M1cũ), ngân sách cảCDX1/2. Writer50 vẫn SHA3061… và không chạy lại. Không ghi TIEN DO/state/bản chính hoặc nhận một phê duyệt mới từ báo cáo AI. File69/70/71 giữ nguyên lịch sử phaRAM:40/41kiểm kỹ thuật, FAIL10pixel nội bộ nhãn trang4/maxRGB1 cùng FAIL toàncrop, giới hạnphông và fit vẫn còn.','',
 '[Đọc kiểm đạo hàm và rated thực](cdx_uniform_74_QH_direction_actual_readonly.json) · [Rà mực nguồn](cdx_uniform_74b_SOURCE_ink_direction_readonly.json) · [Bảng trang3](cdx_uniform_73_P3_current_model_QH_table300.png) · [Bảng trang4](cdx_uniform_73_P4_current_model_QH_table300.png) · [Bảng trang5](cdx_uniform_73_P5_current_model_QH_table300.png). Danh mục SHA/kiểm niêm phong cục bộ ởfile76; kế hoạch/hình thức trang4/5 vẫn cần giải quyết FAIL và danh tính trước bước PDF mới.']
report=O/'cdx_uniform_75_G15_QH_rule_readonly_8_columns.md';report.write_text('\n'.join(text)+'\n',encoding='utf-8')
# Compact comparison ledger: no invented model names on P4/5.
ledger=[]
for pg in A['pages']:
 for cr in pg['curves']:
  ledger.append({'page':pg['page'],'identity':cr['identity'],'readback_scope':pg['readback_scope'],
   'visible_parts':len(cr['visible_parts']),'cubics':sum(p['cubics'] for p in cr['visible_parts']),
   'reverse_segment_count':sum(s['H_rises_on_nonzero_interval'] for p in cr['visible_parts'] for s in p['segments']),
   'visible_direction':'PASS','missing_source_interval':'UNKNOWN' if len(cr['visible_parts'])>1 else '',
   'model_binding':'SOURCE_LABEL_CONFIRMED_P3' if pg['page']==3 else 'UNKNOWN_SOURCE_NUMERIC_ONLY',
   'source_extrema':'UNKNOWN_MANUFACTURER','intermediate_integer_proposal':'NONE; no confirmed reverse segment and intermediate table series',
   'manufacturer_full_series':'UNKNOWN'})
with (O/'cdx_uniform_75_QH_direction_curve_ledger.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(ledger[0]));w.writeheader();w.writerows(ledger)
items=[*sorted(O.glob('cdx_uniform_72*')),*sorted(O.glob('cdx_uniform_73*')),*sorted(O.glob('cdx_uniform_74*')),*sorted(O.glob('cdx_uniform_75*')),
 W/'cdx_uniform_shared_readonly_receipt.py',W/'cdx_uniform_current_QH_table_render.py',W/'cdx_uniform_QH_direction_readonly.py',
 W/'cdx_uniform_source_ink_direction_readonly.py',W/'cdx_uniform_QH_direction_handoff.py']
inputs={'source':{'path':C['context']['source'],'sha256':A['source_SHA']},'canonical194a':{'path':C['context']['current'],'sha256':A['canonical_SHA']},
 'accepted_writer50':{'path':str(O/'cdx_uniform_50_M1_catfix_writer_STANDBY.py'),'sha256':'3061e94c43f0cdb1e3468e2cbf64a5c3db7461af45563d897d31d70150d726e7'}}
for k,v in inputs.items():assert sha(v['path'])==v['sha256'],k
for entry in C['self_read_controls']:assert sha(entry['path'])==entry['sha256'],entry['path']
manifest={'time_VN':datetime.now(timezone(timedelta(hours=7))).isoformat(),'phase':'QH_NEW_RULE_READONLY_HANDOFF; NO_WRITER_RESTART',
 'scope':'CDX G15 only; same 8 original jobs; no new completion count',
 'G15_original_status':'7/8 inherited from ROOT;118CHUA_DAT','visible_direction':A['direction_totals'],
 'source_ink_direction':S['totals'],'integer_changes_proposed':0,
 'p3_2_exact_rated_retained':True,'p3_other_2_rated_source_fit_limits_not_removed':True,
 'source_max_min_manufacturer_truth':'UNKNOWN where not confirmed; original fields kept and missing minimum not0',
 'p45_model_identity_and_missing_ink':'UNKNOWN; no fifth trace or model names created',
 'previous_P45_RAM_preservation_FAIL':'10 source-label interior pixels/max1 plus fullcrop FAIL; no PASS upgrade',
 'source_canonical_shared_controls_unchanged':True,'shared_store_or_ledger_write':False,
 'PDF_disk_write':False,'PDF_RAM_serialization_this_phase':False,'disk_PDF_count':len(list(R.rglob('*.pdf'))),'whole_CDX_budget_used':'1/2',
 'inputs':inputs,'self_read_shared_control_files':C['self_read_controls'],
 'files':[{'path':str(p),'relative_path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size} for p in items]}
assert manifest['disk_PDF_count']==1
(O/'cdx_uniform_76_QH_readonly_handoff_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'eight_column_rows':8,'curve_ledger_rows':len(ledger),'manifest_files':len(items),'Q_H_actual_paths':19,'cubics_checked':117,
 'reverse_segments':0,'source_centroid_rises_UNKNOWN':98,'integer_changes_proposed':0,
 'source_canonical_controls_unchanged':True,'PDF_or_RAM_write_this_phase':False},ensure_ascii=False))
