from pathlib import Path
import json,numpy as np,pymupdf as fitz
from PIL import Image
R=Path(__file__).resolve().parents[1];W=R/'work'
cp=json.loads((W/'cdx_uniform_p45_rebase194.json').read_text(encoding='utf-8'))
doc=fitz.open(cp['files']['source']['path']);sx,sy=json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))['pixel_to_pt']
for pi in (3,4):
 pix=doc[pi].get_pixmap(dpi=150,alpha=False);a=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,pix.n)
 b=np.asarray(Image.open(W/f'cdx_uniform_source_p{pi+1}_150dpi.png').convert('RGB'))
 print(json.dumps({'page':pi+1,'old_work_shape':list(b.shape),'source_actual_shape':list(a.shape),
  'native_arrays_identical':np.array_equal(a,b),'maxRGB':int(abs(a.astype(np.int16)-b.astype(np.int16)).max()) if a.shape==b.shape else None}))
 for number,bb in ([(3,[677,657,715,700]),(4,[633,596,673,635]),(5,[748,596,790,635]),(6,[499,491,537,535])] if pi==3 else [(1,[430,580,470,624]),(2,[430,536,470,578]),(3,[430,483,470,528]),(4,[430,452,470,493])]):
  rec=fitz.Rect(bb[0]*sx,bb[1]*sy,bb[2]*sx,bb[3]*sy)
  doc[pi].get_pixmap(dpi=600,clip=rec,alpha=False).save(W/f'cdx_uniform_source_p{pi+1}_number{number}_context600.png')
doc.close()
