from pathlib import Path
import json,ast,numpy as np,cv2
from scipy.ndimage import distance_transform_edt
from PIL import Image
R=Path(__file__).resolve().parents[1];W=R/'work';O=R/'outputs'
M=json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))
P=json.loads((O/'cdx_uniform_01_ke_hoach.json').read_text(encoding='utf-8'))
G=json.loads((W/'cdx_uniform_p45_geometry_source.json').read_text(encoding='utf-8'))
SX,SY=M['pixel_to_pt'];PH=841.9199829101562
tree=ast.parse((W/'cdx_uniform_outline_v4.py').read_text(encoding='utf-8'))
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='outline')
exec(compile(ast.Module(body=[fn],type_ignores=[]),'source_alpha_outline_function_only','exec'),globals())
pt=lambda q:[q[0]*SX,PH-q[1]*SY]
boxpt=lambda b:[b[0]*SX,PH-b[3]*SY,b[2]*SX,PH-b[1]*SY]
dark=lambda a:1-a.mean(axis=-1)/255
regions={4:{'untranscribed_word':[143,563,165,606],1:[395,629,404,644],2:[478,610,488,624],
3:[688,677,706,699],4:[638,607,659,628],5:[756,607,778,628],6:[509,503,527,525],7:[438,440,451,458]},
5:{'untranscribed_word':[184,547,201,590],1:[445,594,455,610],2:[444,550,456,567],3:[444,499,457,516],4:[442,466,458,483]}}
rois={4:[93,195,1099,884],5:[134.5,207,1090,895]}
speedboxes={4:[826,385,926,413],5:[869,407,972,441]}
result={'stage':'whole P4/P5 plan; source typography, numeric labels kept as source image islands, no model retyping',
        'PDF_written':False,'geometry_limit':'max source centerline residual about2.5 nativepx, not an exact manufacturer series or pointwise PASS',
        'pages':[]}
for pi in (4,5):
    arr=np.asarray(Image.open(W/f'cdx_uniform_source_p{pi}_150dpi.png').convert('RGB')).astype(float)
    mp=next(p for p in M['pages'] if p['page']==pi);roi=rois[pi]
    X=np.array([v['native_pixel_center']+.5 for v in mp['vertical_grid']]);Y=np.array([v['native_pixel_center']+.5 for v in mp['horizontal_grid']])
    lines=[];tips=[];glyphs=[]
    def line(kind,a,b):lines.append({'kind':kind,'native_points':[list(a),list(b)],'points_pdf_pt':[pt(a),pt(b)]})
    for x in X:line('grid_vertical',[x,Y[0]],[x,Y[-1]])
    for y in Y:line('grid_horizontal',[X[0],y],[X[-1],y])
    def hline(kind,box):
        x0,y0,x1,y1=box;prof=dark(arr[y0:y1,x0:x1]).mean(1);ii=np.flatnonzero(prof>max(.25,float(prof.max())*.7))
        assert len(ii);y=float(np.average(ii,weights=prof[ii]))+y0+.5
        rr=np.flatnonzero(dark(arr[int(y),x0:x1])>.25)
        line(kind,[x0+int(rr.min()),y],[x0+int(rr.max())+1,y]);return y
    us=hline('US_GPM_axis',[294,319,947,334] if pi==4 else [333,336,989,352])
    mh=hline('m3_h_axis',[294,796,951,813] if pi==4 else [333,810,989,826])
    psi=[224,364,236,762] if pi==4 else [261,368,274,778]
    x0,y0,x1,y1=psi;prof=dark(arr[y0:y1,x0:x1]).mean(0);ii=np.flatnonzero(prof>max(.25,float(prof.max())*.7))
    assert len(ii);xp=float(np.average(ii,weights=prof[ii]))+x0+.5
    line('P_psi_axis',[xp,y0],[xp,y1])
    for t in P['secondary_axis_ticks']:
        if t['page']!=pi:continue
        u0,v0,u1,v1=t['strip_native_pixel_box']
        for x in t['x_centers_native_px']:
            i=int(round(x));prof=dark(arr[v0:v1,i-1:i+2]).mean(1);ii=np.flatnonzero(prof>.32)
            if t['axis']=='US_GPM':ii=ii[v0+ii<=us]
            if t['axis']=='IMP_GPM':ii=ii[v0+ii<=Y[0]]
            if len(ii):line('tick_'+t['axis'],[x+.5,v0+int(ii.min())],[x+.5,v0+int(ii.max())+1])
    for t in P['vertical_axis_ticks']:
        if t['page']!=pi:continue
        u0,v0,u1,v1=t['strip_native_pixel_box']
        for y in t['y_centers_native_px']:
            i=int(round(y));prof=dark(arr[i-1:i+2,u0:u1]).mean(0);ii=np.flatnonzero(prof>.32)
            if len(ii):line('tick_'+t['axis'],[u0+int(ii.min()),y+.5],[u0+int(ii.max())+1,y+.5])
    arrows=[('Head',[166,504,178,529],[168,528,177,665],'vertical'),('Flow',[650,851,678,866],[478,855,652,863],'horizontal')] if pi==4 else [
        ('Head',[201,476,217,504],[205,503,214,664],'vertical'),('Flow',[687,866,718,882],[510,869,690,879],'horizontal')]
    for name,tb,sb,orient in arrows:
        x0,y0,x1,y1=sb;prof=dark(arr[y0:y1,x0:x1]).mean(0 if orient=='vertical' else 1);ii=np.flatnonzero(prof>.40)
        center=float(np.average(ii,weights=prof[ii]))+(x0 if orient=='vertical' else y0)+.5
        line('arrow_shaft_'+name,[center,y0] if orient=='vertical' else [x0,center],[center,y1] if orient=='vertical' else [x1,center])
        x0,y0,x1,y1=tb;cc,_=cv2.findContours(np.uint8(dark(arr[y0:y1,x0:x1])>.35)*255,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        poly=cv2.approxPolyDP(max(cc,key=cv2.contourArea),.8,True)[:,0,:]+[x0+.5,y0+.5]
        tips.append({'kind':'arrow_tip_'+name,'points_pdf_pt':[pt(q) for q in poly]})
    banner=next(b for b in P['source_style_samples']['banners'] if b['page']==pi)
    alpha=np.clip(1-arr.mean(2)/255,0,1)
    bx0,by0,bx1,by1=banner['native_pixel_box'];bg=np.array(banner['RGB_area_median'])
    alpha[by0:by1,bx0:bx1]=np.clip(((bg-arr[by0:by1,bx0:bx1])*bg).sum(2)/(bg*bg).sum(),0,1)
    alpha[(arr.max(2)-arr.min(2)>45)&(arr[:,:,0]>arr[:,:,1]+30)]=0
    scope=np.zeros(alpha.shape,bool);scope[int(roi[1]):int(roi[3]),int(np.floor(roi[0])):int(np.ceil(roi[2]))]=True
    alpha[~scope]=0
    mask=np.zeros(alpha.shape,'uint8')
    for l in lines:cv2.line(mask,tuple(np.round(l['native_points'][0]).astype(int)),tuple(np.round(l['native_points'][1]).astype(int)),1,4)
    for _,tb,sb,_ in arrows:
        for b in (tb,sb):mask[b[1]:b[3],b[0]:b[2]]=1
    pb=mp['plot_native_pixel_box'];mask[pb[1]-3:pb[3]+3,pb[0]-3:pb[2]+3]=1
    protected=[]
    for number,b in regions[pi].items():
        protected.append({'kind':'original_untranscribed_word' if isinstance(number,str) else 'original_numeric_label',
            'number':number,'box_native':b,'box_pdf_pt':boxpt(b),'typography':'SOURCE_IMAGE_BYTE_AND_CTM_KEPT_NO_RETYPE',
            'full_source_glyph_height':'UNKNOWN at source grid overlaps, not inferred from guessed font name'})
        mask[b[1]:b[3],b[0]:b[2]]=1
    alpha[mask>0]=0
    # Copy the speed's clean ink before plot masking; move it above the upper axes at scale1.
    sb=speedboxes[pi];sa=arr[sb[1]:sb[3],sb[0]:sb[2]]
    speedalpha=np.clip(1-sa.mean(2)/255,0,1);speedalpha[(sa.max(2)-sa.min(2)>45)&(sa[:,:,0]>sa[:,:,1]+30)]=0
    # Narrow to speed's black components; its old rectangular grid border is excluded.
    speedalpha[:3]=0;speedalpha[-3:]=0;speedalpha[:,:3]=0;speedalpha[:,-3:]=0
    # Outside-plot typography is split by observed components. Voronoi assignment retains own
    # antialias fringes at scale1, with no other glyph substitution or system font.
    binary=np.uint8(alpha>.30);nc,labels,stats,_=cv2.connectedComponentsWithStats(binary,8)
    _,inds=distance_transform_edt(binary==0,return_indices=True);nearest=labels[inds[0],inds[1]]
    discarded=[]
    for k in range(1,nc):
        x,y,w,h,area=stats[k]
        if w>60 or h>36 or area<2:
            discarded.append({'bbox':[int(x),int(y),int(w),int(h)],'area':int(area),'status':'UNKNOWN_UNCLASSIFIED_OR_GEOMETRY_REMAINDER'});continue
        x0,y0=max(int(np.floor(roi[0])),int(x)-3),max(int(roi[1]),int(y)-3);x1,y1=min(int(np.ceil(roi[2])),int(x+w)+3),min(int(roi[3]),int(y+h)+3)
        aa=np.where(nearest[y0:y1,x0:x1]==k,alpha[y0:y1,x0:x1],0)
        if aa.sum()<.06:continue
        ol=outline(aa,f'p{pi}_source_component{k}')
        glyphs.append({'id':k,'source_domain_native':[x0,y0,x1,y1],'physical_scale':1,
            'source_alpha_area':float(aa.sum()),'source_contour_area':ol['filled_polygon_area_px'],
            'source_outline_components':ol['components'],'source_outline_holes':ol['holes'],
            'polygons':[{'points_pdf_pt':[pt(q+[x0,y0]) for q in np.array(po['points_px'])],'depth':po['depth']} for po in ol['polygons']],
            'identity':'untranscribed own-source connected glyph/group, no new font'})
    speedout=outline(speedalpha,f'p{pi}_source_speed_group')
    origin=[sb[0],280 if pi==4 else 289]
    glyphs.append({'id':'speed_group','source_domain_native':sb,'target_native_origin':origin,'physical_scale':1,
        'source_alpha_area':float(speedalpha.sum()),'source_contour_area':speedout['filled_polygon_area_px'],
        'polygons':[{'points_pdf_pt':[pt(q+origin) for q in np.array(po['points_px'])],'depth':po['depth']} for po in speedout['polygons']],
        'identity':'source speed group at scale1, visual review required; no retype'})
    page={'page':pi,'whole_region_native':roi,'whole_region_pdf_pt':boxpt(roi),'style':P['style_proposal'],
        'banner':banner,'grid_axes_ticks':lines,'arrow_tips':tips,'glyph_groups':glyphs,'source_islands':protected,
        'source_curves':next(p for p in G['pages'] if p['page']==pi)['curves'],
        'source_main_image_name':'X13' if pi==4 else 'X19','discarded_source_components':discarded,
        'source_fidelity':'original numeric labels preserved through existing source image; underlying source grid in those small regions may differ from uniform vector grid, graphic UNKNOWN there',
        'source_gap':'P5 original red-label gap UNKNOWN; no connecting stroke inferred' if pi==5 else 'initial4/5 shared-ink identity UNKNOWN; contour fit is graphical inference',
        'actual_RAM_repair':'P4 labels4/5 source600 context exposed clipped left glyph strokes; expanded observed source windows, no retype. P5 left ROI now134.5px in original blank margin (previous135px produced outside clip-AA at col179 in200dpi); QA still threshold0 padding0.'}
    result['pages'].append(page)
(W/'cdx_uniform_p45_layout_source.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
(O/'cdx_uniform_64_P45_layout_source_summary.json').write_text(json.dumps({**result,'pages':[{k:v for k,v in p.items() if k not in ('glyph_groups','source_curves')} for p in result['pages']]},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{'page':p['page'],'grid_strokes':len(p['grid_axes_ticks']),'glyph_groups':len(p['glyph_groups']),
     'source_islands':len(p['source_islands']),'unclassified_components':len(p['discarded_source_components'])} for p in result['pages']]))
