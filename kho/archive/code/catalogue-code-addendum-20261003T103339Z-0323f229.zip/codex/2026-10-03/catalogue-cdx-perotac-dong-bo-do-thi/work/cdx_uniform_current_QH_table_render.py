from pathlib import Path
import json,hashlib,pymupdf as fitz
R=Path(__file__).resolve().parents[1];O=R/'outputs';W=R/'work'
P=json.loads((O/'cdx_uniform_01_ke_hoach.json').read_text(encoding='utf-8'))
C=json.loads((O/'cdx_uniform_72_shared_readonly_receipt.json').read_text(encoding='utf-8'))['context']
assert hashlib.sha256(Path(C['current']).read_bytes()).hexdigest()==C['current_sha256']
sx,sy=json.loads((W/'cdx_uniform_measurements.json').read_text(encoding='utf-8'))['pixel_to_pt']
doc=fitz.open(C['current']);data=[]
for page in (3,4,5):
 rows=[r for r in P['table_rows'] if r['page']==page]
 boxes=[v['native_pixel_box'] for row in rows for v in row['source_cells'].values()]
 box=[min(b[0] for b in boxes)-15,min(b[1] for b in boxes)-130,max(b[2] for b in boxes)+20,max(b[3] for b in boxes)+10]
 rect=fitz.Rect(box[0]*sx,box[1]*sy,box[2]*sx,box[3]*sy)
 name=f'cdx_uniform_73_P{page}_current_model_QH_table300.png'
 doc[page-1].get_pixmap(dpi=300,clip=rect,alpha=False,colorspace=fitz.csRGB).save(O/name)
 data.append({'page':page,'image':name,'native_context_box':box,'PDF_TL_pt':list(rect),
  'rows':[{'model':r['current_model'],'rated_Q_m3_h':r['Q_m3_h'],'rated_H_m':r['H_m'],'source_cells':r['source_cells']} for r in rows],
  'scope':'full model/header/rated Q/H columns; actual current194a. No source min set0 and no intermediate numbers invented'})
(O/'cdx_uniform_73_current_QH_tables_readback.json').write_text(json.dumps({'canonical_SHA':C['current_sha256'],'pages':data,'new_PDF_written':False},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{'page':p['page'],'row_count':len(p['rows']),'image':p['image']} for p in data]));doc.close()
