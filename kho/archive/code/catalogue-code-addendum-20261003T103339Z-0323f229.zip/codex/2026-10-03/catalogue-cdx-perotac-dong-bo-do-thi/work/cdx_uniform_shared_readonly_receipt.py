from pathlib import Path
import sys,importlib.util,json,hashlib
from datetime import datetime,timezone,timedelta
R=Path(__file__).resolve().parents[1];O=R/'outputs';P=Path(r'D:\ChatGPT\Sửa catalogue')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('catalogue_readonly',P/'tools/catalogue.py')
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)
# These three functions use readonly file IO and readonly SQLite URI. Never call
# connect(), claim, receipt, refresh, or any mutation while ROOT seals the store.
health=c.health();status=c.status();context=c.context('Trục ngang/CDX Perotac (bản mới).pdf')
assert not context['controls']['changed'] and not context['inputs_changed_since_snapshot']
assert context['source_sha256']=='ef57c37be06a3f954baac6b7549d0dda8788bf089925b6b23e68d62ed23216da'
assert context['current_sha256']=='194a943e106e7a71426464823231494a2331c16bd74a0c3654d77a9dc888241a'
read=['START_HERE.md','AGENTS.md','manifest.json','rules/QUY_TAC_ANH_TRUNG.md','rules/PHOI_HOP_CHATGPT_CLAUDE.md',
      'state/CURRENT_CHECKPOINT.md','procedures/DUONG_DAC_TINH.md','knowledge/LOI_VA_CACH_TRANH.md',
      'knowledge/THAY_DOI_QUY_TAC_20261003.md','tools/catalogue.py']
oldpath=O/'cdx_uniform_72_shared_readonly_receipt.json';delta=[]
if oldpath.exists():
 oldbytes=oldpath.read_bytes();old=json.loads(oldbytes)
 for r in old['self_read_controls']:
  now=sha(r['path'])
  if now!=r['sha256']:delta.append({'path':r['path'],'before_SHA':r['sha256'],'after_SHA':now})
 if delta:
  history=O/'cdx_uniform_72a_before_ROOT_reseal_readonly_receipt.json'
  assert not history.exists(),'Keep previous control-reseal history; investigate any further drift'
  history.write_bytes(oldbytes)
data={'time_VN':datetime.now(timezone(timedelta(hours=7))).isoformat(),'scope':'G15 CDX read-only monotonicity audit; no shared store write',
 'actor_current_chat':'CDX worker01a0ffaa','received_scope':'Q increases/H decreases per identified model; keep locked extrema/rated; do not guess mapping or rerun p3 writer',
 'local_receipt_only':'ROOT store is sealed; no SQLite event/receipt or ledger/state/catalogue writes authorized here',
 'health':health,'status':status,'context':context,'self_read_controls':[{ 'path':str(P/f),'sha256':sha(P/f)} for f in read],
 'ledger_read_path':status['ledger'],'ledger_read_sha256':status['ledger_sha256'],
 'latest_G15_progress_rows':[s for s in Path(status['ledger']).read_text(encoding='utf-8-sig').splitlines() if s.startswith('| 20') and '| G15 |' in s][-3:],
 'preserved_rules':{'one_model_same_conditions':'Q strictly rises, H decreases; table rounding ties need review',
  'extrema_and_rated':'keep confirmed max/min/rated; missing min not0, outer ink endpoint not manufacturer extrema',
  'unknown_identity':'no model relabel, nearest-curve numbers, or intermediate proposal tied to uncertain code',
  'PDF_phase':'no PDF save; use readonly actual canonical and previously audited RAM content'},
 'shared_store_or_canonical_write':False,
 'ROOT_resealed_during_readonly_phase':bool(delta),'changed_controls_reread_before_local_receipt':delta,
 'reseal_delta_scope':'manifest added knowledge change log/test; checkpoint and error guide updated; no CDX source/current or QH lock change'}
(O/'cdx_uniform_72_shared_readonly_receipt.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'health':health['result'],'controls_changed':context['controls']['changed'],'inputs_changed':context['inputs_changed_since_snapshot'],
 'source':context['source_sha256'],'canonical':context['current_sha256'],
 'active_CDX_locks':[r for r in status['locks'] if 'CDX' in r['file']],
 'latest_G15':data['latest_G15_progress_rows'][-1:],'shared_store_write':False},ensure_ascii=False))
