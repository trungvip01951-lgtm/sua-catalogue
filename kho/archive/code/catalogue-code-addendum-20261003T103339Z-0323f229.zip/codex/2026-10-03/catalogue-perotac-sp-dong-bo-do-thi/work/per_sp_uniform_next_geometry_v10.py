from pathlib import Path
import json,csv,hashlib,io,base64
import numpy as np
from PIL import Image
from scipy.interpolate import PchipInterpolator,UnivariateSpline
from scipy.spatial import cKDTree
import cv2
import pymupdf as fitz

B=Path(__file__).resolve().parents[1];O=B/'outputs';W=B/'work'
probe=json.loads((O/'per_sp_uniform_next_source_probe_v4.json').read_text(encoding='utf8'))
axes=json.loads((O/'per_sp_uniform_next_actual_axes_v5.json').read_text(encoding='utf8'))
read=json.loads((O/'per_sp_uniform_next_actual_curve_readback_v10.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(probe['source'])==probe['source_sha256'] and sha(probe['current'])==probe['current_sha256']
charts=[];checks=[];collisionrows=[]

def cubic(p,t):
    p=np.asarray(p,float);t=np.asarray(t,float)[:,None];return (1-t)**3*p[0]+3*(1-t)**2*t*p[1]+3*(1-t)*t*t*p[2]+t**3*p[3]
def cubics_of(fun,knots):
    ds=fun.derivative();out=[]
    for x0,x1 in zip(knots[:-1],knots[1:]):
        dx=x1-x0;y0=float(fun(x0));y1=float(fun(x1));out.append([[float(x0),y0],[float(x0+dx/3),y0+float(ds(x0))*dx/3],[float(x1-dx/3),y1-float(ds(x1))*dx/3],[float(x1),y1]])
    return out
def svgd(segs,box,sx,sy):
    p=np.asarray(segs,float);p[:,:,0]=(p[:,:,0]-box[0])*sx;p[:,:,1]=(p[:,:,1]-box[1])*sy
    return 'M '+' '.join(f'{v:.8f}' for v in p[0,0])+' '+ ' '.join('C '+' '.join(f'{v:.8f}' for v in z[1:].ravel()) for z in p)

for pr in probe['charts']:
    chart=pr['chart'];pno=pr['page_pdf'];ax=next(a for a in axes['charts'] if a['chart']==chart);ctm=pr['source_pixel_to_page_pt'];sx=ctm['sx'];sy=ctm['sy'];
    im=Image.open(pr['source_native_png']).convert('RGB');a=np.asarray(im);g=a@np.array([.299,.587,.114])
    qt=ax['axes']['Q_m3h']['ticks'];ht=ax['axes']['H_m']['ticks'];qv=np.array([t['value'] for t in qt]);qx=np.array([t['measured_center_native_cell_coord'] for t in qt]);hv=np.array([t['value'] for t in ht]);hy=np.array([t['measured_center_native_cell_coord'] for t in ht])
    cells=list(csv.DictReader((O/f'per_sp_uniform_{chart}_source_cells_v5.csv').open(encoding='utf-8-sig')))
    models=list(dict.fromkeys(r['model'] for r in cells));geom=[]
    if pno==7:box=(80,150,808,746);labelbox=(282,215,333,556);etabox=(152,602,724,689)
    else:box=(955,145,1675,741);labelbox=(1125,233,1185,553);etabox=(1017,601,1575,686)
    # Literal source components are used only as collision evidence. No contour,
    # font donor, redrawn glyph, or unrelated product font is generated.
    x0,y0,x1,y1=labelbox;mask=(g[y0:y1,x0:x1]<160).astype(np.uint8);nc,lab,st,cent=cv2.connectedComponentsWithStats(mask,8)
    sourceglyphpixels=[];sourcecomponents=[];rejected=[]
    for k in range(1,nc):
        xx,yy,ww,hh,area=[int(z) for z in st[k]]
        if 4<=hh<=13 and 1<=ww<=17 and area>=4:
            py,px=np.nonzero(lab==k);xy=np.column_stack([px+x0+.5,py+y0+.5]);sourceglyphpixels.append(xy);sourcecomponents.append(dict(native_bbox=[xx+x0,yy+y0,xx+x0+ww,yy+y0+hh],ink_pixels=int(area),source_component_sha256=hashlib.sha256(np.asarray(xy).tobytes()).hexdigest()))
        else:rejected.append(dict(native_bbox=[xx+x0,yy+y0,xx+x0+ww,yy+y0+hh],ink_pixels=int(area),reason='Source thin curve, fragment, or merged text/curve component; not silently treated as a clean glyph.'))
    glyphpts=np.concatenate(sourceglyphpixels) if sourceglyphpixels else np.empty((0,2));tree=cKDTree(glyphpts*np.array([sx,sy])) if len(glyphpts) else None
    source_trace=json.loads((O/'per_sp_uniform_next_raw_source_trace_v10.json').read_text(encoding='utf8'));tr=next(z for z in source_trace['charts'] if z['chart']==chart)
    for model in models:
        rs=[r for r in cells if r['model']==model];q=np.array([float(r['Q_m3h']) for r in rs]);h=np.array([float(r['H_m']) for r in rs]);x=np.interp(q,qv,qx);y=np.interp(h,hv,hy);f=PchipInterpolator(x,y,extrapolate=False);cub=cubics_of(f,x)
        native=np.asarray(cub);page=native*np.array([sx,sy])+np.array([ctm['x0'],ctm['y0']]);
        # These are candidates based on the source TABLE, not accepted replacements
        # for the literal current paths. The latter remain in their own locked bank.
        sampled=np.concatenate([cubic(s,np.linspace(0,1,250)) for s in cub]);mindist=float(tree.query(sampled*np.array([sx,sy]))[0].min()) if tree else None
        stroke_clearance=mindist-.35 if mindist is not None else None
        rt=np.interp(f(x),hy[::-1],hv[::-1]);nodeerr=float(np.max(abs(rt-h)));assert nodeerr<1e-10
        c0=max((float(np.linalg.norm(native[i,-1]-native[i+1,0])) for i in range(len(native)-1)),default=0.)
        c1=max((float(np.linalg.norm(3*(native[i,-1]-native[i,-2])/(native[i,-1,0]-native[i,0,0])-3*(native[i+1,1]-native[i+1,0])/(native[i+1,-1,0]-native[i+1,0,0]))) for i in range(len(native)-1)),default=0.)
        old=next(z for z in read['actual_model_path_identity'] if z['model']==model)
        record=dict(model=model,literal_source_Q_m3h=q.tolist(),literal_source_H_m=h.tolist(),source_table_cells=len(rs),actual_local_tick_native_nodes=np.column_stack([x,y]).tolist(),
            table_only_candidate_open_Beziers_native=cub,table_only_candidate_open_Beziers_page_pt=page.tolist(),
            table_only_RAM_H_roundtrip_max_error_m=nodeerr,C0_max_native_px=c0,C1_dy_dx_max_delta=c1,
            Q_strictly_increasing=True,H_nonincreasing=True,source_equal_H_intervals_preserved=[dict(Q_interval=[float(q[i]),float(q[i+1])],H_m=float(h[i])) for i in range(len(h)-1) if h[i]==h[i+1]],
            existing_current_path_identity=old,existing_current_path_replaced=False,
            current_native_tail_retention='Literal native tail controls stay locked and are supplied separately; this table-only proposal is not permission to replace them.',
            source_text_bitmap_retained=True,no_glyph_contours_rebuilt=True,
            candidate_centerline_to_provisionally_identified_source_glyph_pixels_min_pt=mindist,candidate_pen070_clearance_to_these_source_glyph_pixels_pt=stroke_clearance,
            complete_text_collision_QA='UNKNOWN - merged/rejected source components remain, old ink is still present; this diagnostic cannot be accepted as a clean chart.')
        geom.append(record);checks.append(dict(chart=chart,model=model,source_cells=len(rs),table_only_max_H_error_m=nodeerr,C0=c0,C1=c1,actual_PDF_test='NOT RUN'))
        collisionrows.append(dict(chart=chart,page_pdf=pno,model=model,identified_source_glyph_centerline_distance_pt=mindist,candidate_pen070_clearance_pt=stroke_clearance,
            source_component_count=len(sourcecomponents),source_rejected_or_merged_component_count=len(rejected),old_curve_ink_not_removed=True,
            actual_oldink_text_clearance_status='UNKNOWN',full_source_text_collision_status='UNKNOWN',reason='Own-source bitmap text retained; conservative partial component audit only, no whiteout or glyph regeneration.'))
    # Eta is measured from its own source ink; the lack of an eta numeric table
    # is explicit. Its source bitmap is retained in diagnostic previews.
    ex0,ey0,ex1,ey1=etabox;eta=[]
    for xx in range(ex0,ex1):
        z=np.flatnonzero(g[ey0:ey1,xx]<185)+ey0;groups=np.split(z,np.flatnonzero(np.diff(z)>1)+1);groups=[z for z in groups if len(z) and len(z)<=4]
        if len(groups)==1:
            yy=groups[0];wt=185-g[yy,xx];eta.append([xx+.5,float(np.dot(yy,wt)/wt.sum())+.5])
    ea=np.array(eta);spline=UnivariateSpline(ea[:,0],ea[:,1],s=len(ea)*.06,k=3);fitres=float(np.max(abs(spline(ea[:,0])-ea[:,1])));knots=spline.get_knots();ecub=cubics_of(spline,knots)
    eta_rec=dict(own_source_ink_samples_native=eta,open_Beziers_native=ecub,own_source_fit_max_residual_native_px=fitres,
        max_fit_target_native_px=1,source_following_geometry_status='PASS PREPARATION ONLY' if fitres<=1 else 'UNKNOWN',
        numeric_QA='UNKNOWN - no own-source eta numerical table',bitmap_eta_in_RAM_left_intact=True,not_drawn_over_source_eta=True,not_written_to_PDF=True)
    # Two PNG-only RAM diagnostics. Orange denotes the table-only proposed path;
    # original glyph pixels, original curves and grids remain in the background.
    crop=im.crop(box);bio=io.BytesIO();crop.save(bio,format='PNG');b64=base64.b64encode(bio.getvalue()).decode();pw=crop.width*sx;ph=crop.height*sy
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{pw}pt" height="{ph}pt" viewBox="0 0 {pw} {ph}">',f'<image x="0" y="0" width="{pw}" height="{ph}" preserveAspectRatio="none" xlink:href="data:image/png;base64,{b64}"/>']
    for r in geom:svg.append(f'<path d="{svgd(r["table_only_candidate_open_Beziers_native"],box,sx,sy)}" stroke="#ee8731" stroke-width="0.70" fill="none" stroke-linecap="butt" stroke-linejoin="round"/>')
    svg.append('</svg>');sv=''.join(svg);svfn=W/f'per_sp_uniform_next_{chart}_TABLE_ONLY_DIAGNOSTIC_v10.svg';svfn.write_text(sv,encoding='utf8');renders=[]
    with fitz.open(stream=sv.encode(),filetype='svg') as ram:
        for dpi in [150,600]:
            fn=O/f'per_sp_uniform_next_{chart}_TABLE_ONLY_DIAGNOSTIC_RAM_v10_{dpi}dpi.png';ram[0].get_pixmap(dpi=dpi,alpha=False).save(fn);renders.append(dict(path=str(fn),sha256=sha(fn),dpi=dpi,not_PDF_output=True,source_bitmap_font_intact=True,old_curve_ink_present=True,graphic_acceptance='NOT RUN'))
    charts.append(dict(chart=chart,page_pdf=pno,source_pdf_sha256=probe['source_sha256'],own_source_image_bytes_sha256=pr['source_extracted_image_bytes_sha256'],
        own_source_decoded_RGB_sha256=pr['source_decoded_RGB_pixels_sha256'],own_source_page_contents_sha256=pr['source_page_contents_sha256'],own_source_pixel_to_page_pt=ctm,
        chart_native_crop=list(box),source_text_retained_as_actual_bitmap=True,source_model_text_component_audit=dict(source_native_region=list(labelbox),partial_components=sourcecomponents,rejected_or_merged_components=rejected,coverage_status='UNKNOWN'),
        source_equal_values_and_2A_4A_preserved=True,table_only_proposed_QH_models=geom,eta_source_following_geometry=eta_rec,diagnostic_RAM_renders=renders,
        diagnostics_are_not_font_or_graphic_acceptance=True,old_ink_collision_risk='Original curve ink intentionally retained. Every proposed stroke overlaps/approaches old ink; no erasing or source-text patching was performed.',
        ready_for_PDF_writer=False,blocking_constraints=['ROOT must resolve 6SP60-20 current tail Q72/Q78 FAIL before deciding any replacement; current coordinates are locked.', 'ROOT font/graphic review is still pending; no new font iterations here.', 'Original old ink/text removal and full source-text collision inspection are not executed.']))
out=dict(source_sha256=probe['source_sha256'],current_sha256=probe['current_sha256'],charts=charts,table_only_candidate_cells=314,
    accepted_existing_paths_bank=[z for z in read['actual_model_path_identity'] if z.get('current_drawing_index') is not None],
    all_existing_current_coordinates_preserved=True,source_table_candidate_is_not_an_authorized_tail_replacement=True,PDF_created=0,canonical_write=False,graphic_QA='NOT RUN',independent_acceptance='NOT RUN')
(O/'per_sp_uniform_next_table_geometry_preserve_current_v10.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
(O/'per_sp_uniform_next_geometry_checks_v10.json').write_text(json.dumps(dict(source_sha256=probe['source_sha256'],models=checks,source_cell_total=sum(c['source_cells'] for c in checks),table_only_RAM_max_H_error_m=max(c['table_only_max_H_error_m'] for c in checks),actual_PDF_QA='NOT RUN'),ensure_ascii=False,indent=2),encoding='utf8')
with (O/'per_sp_uniform_next_oldink_text_collision_risks_v10.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(collisionrows[0]));w.writeheader();w.writerows(collisionrows)
print('25 table-only candidates;314 exact planned anchors;12 current paths locked; PDFs0')
for ch in charts:print(ch['chart'],'ETA',len(ch['eta_source_following_geometry']['own_source_ink_samples_native']),'fit max',ch['eta_source_following_geometry']['own_source_fit_max_residual_native_px'],'glyph components',len(ch['source_model_text_component_audit']['partial_components']), 'rejected/merged',len(ch['source_model_text_component_audit']['rejected_or_merged_components']))
print('minimum provisional pen070 text gap',min(c['candidate_pen070_clearance_pt'] for c in collisionrows),'all complete collision results UNKNOWN')
