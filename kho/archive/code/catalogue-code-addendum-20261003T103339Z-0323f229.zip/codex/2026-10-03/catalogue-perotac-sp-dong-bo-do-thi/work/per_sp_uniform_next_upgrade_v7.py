from pathlib import Path
B=Path(__file__).resolve().parents[1];W=B/'work'
s=(W/'per_sp_uniform_next_curve_read_v6.py').read_text(encoding='utf8').replace('_v6','_v7')
s=s.replace("    if not x0+2<=xi<=x1-2:return dict(status='UNKNOWN',reason='Nominal point intersects a spine or endpoint; no inferred extrapolated centre.')\n    if labelstrip[0]-3<=xi<=labelstrip[1]+3:return dict(status='UNKNOWN',reason='Own-source model text touches this reading window; no closest-H assignment or text removal.')", "    if labelstrip[0]-3<=xi<=labelstrip[1]+3:return dict(status='UNKNOWN',reason='Own-source model text touches this reading window; no closest-H assignment or text removal.')\n    if not x0+2<=xi<=x1-2:return dict(status='UNKNOWN',reason='Nominal point intersects a spine or endpoint; no inferred extrapolated centre.')")
s=s.replace('allnodes=[];identity=[];endpoints=[];rawcharts=[];counts={}', 'allnodes=[];identity=[];endpoints=[];sourceboundaries=[];rawcharts=[];counts={}')
s=s.replace("srrec.update(H_m=sh,H_delta_m=sh-target,H_uncertainty_m=su)", "srrec.update(H_m=sh,H_delta_m=sh-target,H_uncertainty_m=su,numeric_read_result='PASS' if abs(sh-target)+su<=limit else 'FAIL' if abs(sh-target)-su>limit else 'UNKNOWN')")
needle="        for model,d in vecs.items():\n"
insert="""        # Every model gets two own-source boundary records. These are the first
        # and last actually observed source-ink columns, not extrapolated Q=0
        # or nominal-Q endpoints inferred from the table.
        for rank,suffix in enumerate(order):
            full=chart+'-'+suffix;modelrows=[v for v in rows if v['model']==full]
            for which,trace,search,targetrow in [('first_observed_ink',ltr,sorted(ltr),modelrows[0]),('last_observed_ink',tr,sorted(tr,reverse=True),modelrows[-1])]:
                candidates=[(x,trace[x][rank]) for x in search if trace[x][rank]['observed']]
                if candidates:
                    x,z=candidates[0];y=z['y']+.5;xh=x+.5;hact=h_of(y);qact=q_of(xh);target=float(targetrow['H_m']);half=(z['span'][1]-z['span'][0]+1)/2
                    neighbors=[(xx,trace[xx][rank]['y']) for xx in range(max(min(trace),x-3),min(max(trace),x+3)+1) if trace[xx][rank]['observed']]
                    slope=float(np.polyfit(np.array(neighbors)[:,0],np.array(neighbors)[:,1],1)[0]) if len(neighbors)>=2 else 0.
                    uncertainty=h_uncertainty(y,slope,half);delta=hact-target;limit=max(1.,.02*target)
                    boundary_result='FAIL' if abs(delta)-uncertainty>limit else 'UNKNOWN'
                    sourceboundaries.append(dict(chart=chart,page_pdf=pno,model=full,boundary=which,source_native_cell_xy=[xh,y],actual_observed_Q_m3h=qact,
                        nominal_table_Q_m3h=float(targetrow['Q_m3h']),H_table_m=target,H_source_observed_m=hact,H_delta_m=delta,H_uncertainty_m=uncertainty,
                        numeric_result=boundary_result,reason='First/last visible ink sampled from source raster; exact hidden spine/cap boundary not proven.',
                        source_pixel_support_native=z['span'],no_boundary_extrapolated=True,source_image_bytes_sha256=pr['source_extracted_image_bytes_sha256']))
                else:sourceboundaries.append(dict(chart=chart,page_pdf=pno,model=full,boundary=which,numeric_result='UNKNOWN',reason='No unambiguous observed boundary ink.'))
"""
assert needle in s;s=s.replace(needle,insert+needle,1)
s=s.replace("actual_current_path_boundaries=endpoints,", "actual_current_path_boundaries=endpoints,all50_own_source_visible_boundaries=sourceboundaries,")
s=s.replace("    scoped_read_only_counts=counts,", "    scoped_read_only_counts=counts,source_curve_scoped_read_only_counts=dict(Counter(p['source_read'].get('numeric_read_result','UNKNOWN') for p in allnodes)),")
s=s.replace("print('FAIL boundaries',[v for v in endpoints if v['result']=='FAIL'])", "print('FAIL boundaries',[v for v in endpoints if v['result']=='FAIL']);print('source boundaries',len(sourceboundaries),'source curve classification',out['source_curve_scoped_read_only_counts']);print('source FAIL',[(p['model'],p['Q_m3h'],p['source_read']) for p in allnodes if p['source_read'].get('numeric_read_result')=='FAIL'])")
(W/'per_sp_uniform_next_curve_read_v7.py').write_text(s,encoding='utf8')
print('v7 independent readback source-boundary extension; v6 retained')
