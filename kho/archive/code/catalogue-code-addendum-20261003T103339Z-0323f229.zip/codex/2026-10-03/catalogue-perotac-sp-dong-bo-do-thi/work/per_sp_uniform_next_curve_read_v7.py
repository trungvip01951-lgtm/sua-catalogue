from pathlib import Path
import json,csv,hashlib
import numpy as np
from PIL import Image
from scipy.optimize import brentq
import pymupdf as fitz

B=Path(__file__).resolve().parents[1];O=B/'outputs';W=B/'work'
probe=json.loads((O/'per_sp_uniform_next_source_probe_v4.json').read_text(encoding='utf8'))
axes=json.loads((O/'per_sp_uniform_next_actual_axes_v5.json').read_text(encoding='utf8'))
survey=json.loads((O/'per_sp_uniform_next_charts_survey_v2.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(probe['source'])==probe['source_sha256'] and sha(probe['current'])==probe['current_sha256']

def clusters(g,x,lo,hi,thr=185):
    idx=np.flatnonzero(g[lo:hi,x]<thr)+lo; groups=np.split(idx,np.flatnonzero(np.diff(idx)>1)+1);out=[]
    for z in groups:
        if not len(z) or len(z)>5:continue
        wt=thr-g[z,x]
        out.append(dict(y=float(np.dot(z,wt)/wt.sum()),span=[int(z[0]),int(z[-1])],contrast=float(wt.max())))
    return out

def track(g,seed,lo,hi,x0,x1,count):
    init=clusters(g,seed,lo,hi);assert len(init)==count,(seed,len(init),init)
    vals=np.array([z['y'] for z in init]);res={seed:[dict(z,observed=True) for z in init]}
    for direction,stop in [(-1,x0),(1,x1)]:
        prev=vals.copy();slope=np.zeros(count);gap=np.zeros(count,int)
        for x in range(seed+direction,stop+direction,direction):
            pred=prev+slope*direction;cs=clusters(g,x,lo,hi);current=[];nxt=[]
            mids=(pred[:-1]+pred[1:])/2
            for k,y in enumerate(pred):
                cand=[z for z in cs if abs(z['y']-y)<3 and (k==0 or z['y']>mids[k-1]) and (k==count-1 or z['y']<mids[k])]
                if len(cand)==1:
                    z=cand[0];slope[k]=np.clip(.7*slope[k]+.3*(z['y']-prev[k])/direction,-1.9,1.9);gap[k]=0
                    current.append(dict(z,observed=True));nxt.append(z['y'])
                else:
                    gap[k]+=1;current.append(dict(y=float(y),observed=False,span=None,contrast=None,ambiguous_candidates=len(cand),prediction_only=True));nxt.append(y)
            prev=np.array(nxt);res[x]=current
    return res

def node_read(g,tr,rank,xcoord,bounds,labelstrip):
    # xcoord uses source cell-edge coordinates; array indices are centre-.5.
    xc=xcoord-.5;xi=int(round(xc));x0,x1=bounds
    if labelstrip[0]-3<=xi<=labelstrip[1]+3:return dict(status='UNKNOWN',reason='Own-source model text touches this reading window; no closest-H assignment or text removal.')
    if not x0+2<=xi<=x1-2:return dict(status='UNKNOWN',reason='Nominal point intersects a spine or endpoint; no inferred extrapolated centre.')
    samples=[];spans=[]
    for x in range(xi-2,xi+3):
        z=tr.get(x,[None])[rank]
        if z and z['observed']:samples.append([x,z['y']]);spans.append(z['span'])
    if len(samples)<3:return dict(status='UNKNOWN',reason='Dash gap, weak endpoint, or ambiguous local source ink.',observed_columns=len(samples))
    s=np.array(samples);A=np.column_stack([np.ones(len(s)),s[:,0]-xc]);coef=np.linalg.lstsq(A,s[:,1],rcond=None)[0]
    residual=float(np.max(abs(A@coef-s[:,1])));y=float(coef[0]);dy=float(coef[1])
    if residual>.7:return dict(status='UNKNOWN',reason='Local source centre does not form one clear line within 0.7 native pixel.',residual_native_px=residual)
    half=max((b-a+1)/2 for a,b in spans)
    return dict(status='MEASURED',native_cell_xy=[float(xcoord),y+.5],local_slope_dy_dx=dy,
        source_ink_halfwidth_native_px=float(half),local_fit_residual_native_px=residual,source_columns=samples,
        no_table_H_used_to_pick_curve=True,identity='Printed own-source model plus fixed noncrossing rank, traced along neighbouring source columns.')

def cubic(ctrl,t):
    p=np.asarray(ctrl,float);return ((1-t)**3*p[0]+3*(1-t)**2*t*p[1]+3*(1-t)*t*t*p[2]+t**3*p[3])

def value_at_x(items,x):
    for item in items:
        assert item[0]=='c';p=np.array(item[1:],float)
        if p[0,0]-1e-8<=x<=p[-1,0]+1e-8:
            t=brentq(lambda t:cubic(p,t)[0]-x,0,1) if p[0,0]+1e-8<x<p[-1,0]-1e-8 else 0 if x<=p[0,0] else 1
            v=cubic(p,t);d=3*((1-t)**2*(p[1]-p[0])+2*t*(1-t)*(p[2]-p[1])+t*t*(p[3]-p[2]))
            return dict(page_xy_pt=v.tolist(),slope_page_y_per_x=float(d[1]/d[0]),cubic_t=float(t))
    return None

allnodes=[];identity=[];endpoints=[];sourceboundaries=[];rawcharts=[];counts={}
with fitz.open(probe['current']) as cur:
    for pr in probe['charts']:
        chart=pr['chart'];pno=pr['page_pdf'];ax=next(a for a in axes['charts'] if a['chart']==chart);ctm=pr['source_pixel_to_page_pt'];sx=ctm['sx'];sy=ctm['sy']
        own=np.asarray(Image.open(pr['source_native_png']).convert('RGB'));sg=own@np.array([.299,.587,.114])
        # A current PDF raster is used only where literal native vectors do not cover
        # a queried point. Current source text and all existing geometry are intact.
        pix=cur[pno-1].get_pixmap(matrix=fitz.Matrix(1/sx,1/sy),alpha=False)
        ci=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);fn=W/f'per_sp_uniform_next_p{pno:02}_current_native_render_v7.png';ci.save(fn);ca=np.asarray(ci);cg=ca@np.array([.299,.587,.114])
        if pno==7:
            order=['20','18','16','14','12','10','8','7','6','5','4','3','2'];ref=350;lo=240;hi=582;x0=334;x1=724;labelstrip=(282,333)
            leftref=238;leftlo=214;lefthi=582;leftx0=153;leftx1=282;tailmodels=['5','6','7','8','10','12','14','16','18','20'];labels=(282,332)
        else:
            order=['10','9','8','7','6','5','4','4A','3','2','2A','1'];ref=1220;lo=230;hi=580;x0=1186;x1=1575;labelstrip=(1125,1185)
            leftref=1020;leftlo=210;lefthi=580;leftx0=1017;leftx1=1124;tailmodels=['5','7'];labels=(1125,1185)
        n=len(order);tr=track(sg,ref,lo,hi,x0,x1,n);ltr=track(sg,leftref,leftlo,lefthi,leftx0,leftx1,n)
        source_survey=next(c for c in survey['charts'] if c['chart']==chart)
        # Model association uses visible labels + continuous noncrossing source rank,
        # the preserved join, the complete true path and endpoint order together.
        # It is not established by whichever table H is nearest at one endpoint.
        vecs={}
        for model,d in zip(tailmodels,source_survey['current_drawings']):
            vecs[chart+'-'+model]=d
            ident=dict(chart=chart,page_pdf=pno,model=chart+'-'+model,current_drawing_index=d['index'],
                current_path_page_pt=d['items'],current_path_sha256=hashlib.sha256(json.dumps(d['items'],separators=(',',':')).encode()).hexdigest(),
                actual_domain_page_x_pt=[d['items'][0][1][0],d['items'][-1][-1][0]],
                source_rank_top_to_bottom=order.index(model)+1,printed_source_model_identity=True,
                evidence_source_chart_native_png=pr['source_native_png'],
                identity_basis='Own-source printed labels, unbroken curve order before/after label region, retained join location, two/one literal Bezier spans and endpoint order; no nearest-H-only assignment.',
                unchanged_from_live_current_PDF=True,independent_identity_acceptance='NOT RUN')
            identity.append(ident)
        qt=ax['axes']['Q_m3h']['ticks'];ht=ax['axes']['H_m']['ticks'];qv=np.array([t['value'] for t in qt]);qx=np.array([t['measured_center_native_cell_coord'] for t in qt]);hv=np.array([t['value'] for t in ht]);hy=np.array([t['measured_center_native_cell_coord'] for t in ht])
        def h_of(y):return float(np.interp(y,hy[::-1],hv[::-1]))
        def q_of(x):return float(np.interp(x,qx,qv))
        def h_per_native(y):
            k=np.clip(np.searchsorted(hy[::-1],y)-1,0,len(hy)-2);return abs((hv[::-1][k+1]-hv[::-1][k])/(hy[::-1][k+1]-hy[::-1][k]))
        def h_uncertainty(y,slope,source_half=.0,residual=.0):
            # Conservatively includes source pixel support, separately observed H
            # grid support, local Q support and discrepancy of printed Q scales.
            hmunc=max(t['local_support_halfwidth_native_px'] for t in ht)+.5
            qinc=max(t['local_support_halfwidth_native_px'] for t in qt)+.5+max(abs(t['delta_native_px']) for t in ax['Q_printed_scales_crosscheck'])
            return h_per_native(y)*(hmunc+source_half+residual+abs(slope)*qinc)
        rows=list(csv.DictReader((O/f'per_sp_uniform_{chart}_source_cells_v4.csv').open(encoding='utf-8-sig')))
        points=[]
        for row in rows:
            model=row['model'];q=float(row['Q_m3h']);target=float(row['H_m']);x=float(np.interp(q,qv,qx));rank=order.index(model[len(chart)+1:]);limit=max(1.,.02*target)
            if x-.5<labelstrip[0]:sr=node_read(sg,ltr,rank,x,(leftx0,leftx1),labelstrip)
            else:sr=node_read(sg,tr,rank,x,(x0,x1),labelstrip)
            srrec=dict(sr)
            if sr['status']=='MEASURED':
                y=sr['native_cell_xy'][1];sh=h_of(y);su=h_uncertainty(y,sr['local_slope_dy_dx'],sr['source_ink_halfwidth_native_px'],sr['local_fit_residual_native_px']);srrec.update(H_m=sh,H_delta_m=sh-target,H_uncertainty_m=su,numeric_read_result='PASS' if abs(sh-target)+su<=limit else 'FAIL' if abs(sh-target)-su>limit else 'UNKNOWN')
            xp=ctm['x0']+sx*x;vr=value_at_x(vecs[model]['items'],xp) if model in vecs else None
            cr=None
            if vr is not None:
                y=(vr['page_xy_pt'][1]-ctm['y0'])/sy;slope=vr['slope_page_y_per_x']*sx/sy;hh=h_of(y);u=h_uncertainty(y,slope)
                cr=dict(method='Literal live-current native Bezier at requested actual local tick',H_m=hh,H_delta_m=hh-target,H_uncertainty_m=u,native_cell_xy=[x,y],page_xy_pt=vr['page_xy_pt'],current_drawing_index=vecs[model]['index'])
            elif sr['status']=='MEASURED':
                # Fixed own-source identity window; no reselection of another curve
                # after current ink moves. An ambiguous/empty current window stays UNKNOWN.
                pred=sr['native_cell_xy'][1]-.5;xi=int(round(x-.5));sam=[]
                for col in range(xi-2,xi+3):
                    candidates=[z for z in clusters(cg,col,int(pred-7),int(pred+8)) if abs(z['y']-pred)<3]
                    if len(candidates)==1:sam.append([col,candidates[0]['y'],candidates[0]['span']])
                if len(sam)>=3:
                    s=np.array([z[:2] for z in sam]);A=np.column_stack([np.ones(len(s)),s[:,0]-(x-.5)]);coef=np.linalg.lstsq(A,s[:,1],rcond=None)[0];res=float(np.max(abs(A@coef-s[:,1])))
                    if res<=.7:
                        y=float(coef[0]+.5);hh=h_of(y);half=max((z[2][1]-z[2][0]+1)/2 for z in sam);u=h_uncertainty(y,float(coef[1]),half,res)
                        cr=dict(method='Visible live-current PDF own-rank raster window',H_m=hh,H_delta_m=hh-target,H_uncertainty_m=u,native_cell_xy=[x,y],observed_columns=len(sam),local_fit_residual_native_px=res)
            if cr:
                delta=cr['H_delta_m'];u=cr['H_uncertainty_m'];result='PASS' if abs(delta)+u<=limit else 'FAIL' if abs(delta)-u>limit else 'UNKNOWN'
                reason='Full measured interval inside technical tolerance' if result=='PASS' else 'Full measured interval outside technical tolerance' if result=='FAIL' else 'Measured uncertainty interval crosses technical tolerance'
            else:result='UNKNOWN';reason=sr.get('reason','Literal vector does not cover nominal point and visible current ink is ambiguous')
            rec=dict(chart=chart,page_pdf=pno,model=model,Q_m3h=q,H_table_m=target,technical_tolerance_m=limit,
                actual_Q_local_native_cell_coord=x,source_read=srrec,current_read=cr,result=result,reason=reason,
                source_cell_native_bbox=json.loads(row['evidence_native_bbox']),source_cell_RGB_sha256=row['source_cell_RGB_sha256'],
                source_table_evidence=row['evidence_image'],source_sha256=probe['source_sha256'],current_sha256=probe['current_sha256'],independent_acceptance='NOT RUN')
            points.append(rec);allnodes.append(rec)
        # Every model gets two own-source boundary records. These are the first
        # and last actually observed source-ink columns, not extrapolated Q=0
        # or nominal-Q endpoints inferred from the table.
        for rank,suffix in enumerate(order):
            full=chart+'-'+suffix;modelrows=[v for v in rows if v['model']==full]
            for which,trace,search,targetrow in [('first_observed_ink',ltr,sorted(ltr),modelrows[0]),('last_observed_ink',tr,sorted(tr,reverse=True),modelrows[-1])]:
                candidates=[(x,trace[x][rank]) for x in search if trace[x][rank]['observed']]
                if candidates:
                    x,z=candidates[0];y=z['y']+.5;xh=x+.5;hact=h_of(y);qact=q_of(xh);target=float(targetrow['H_m']);half=(z['span'][1]-z['span'][0]+1)/2
                    neighbors=[(xx,trace[xx][rank]['y']) for xx in range(max(min(trace),x-3),min(max(trace),x+3)+1) if trace[xx][rank]['observed']]
                    slope=float(np.polyfit(np.array(neighbors)[:,0],np.array(neighbors)[:,1],1)[0]) if len(neighbors)>=2 else 0.
                    uncertainty=h_uncertainty(y,slope,half);delta=hact-target;limit=max(1.,.02*target)
                    boundary_result='FAIL' if abs(delta)-uncertainty>limit else 'UNKNOWN'
                    sourceboundaries.append(dict(chart=chart,page_pdf=pno,model=full,boundary=which,source_native_cell_xy=[xh,y],actual_observed_Q_m3h=qact,
                        nominal_table_Q_m3h=float(targetrow['Q_m3h']),H_table_m=target,H_source_observed_m=hact,H_delta_m=delta,H_uncertainty_m=uncertainty,
                        numeric_result=boundary_result,reason='First/last visible ink sampled from source raster; exact hidden spine/cap boundary not proven.',
                        source_pixel_support_native=z['span'],no_boundary_extrapolated=True,source_image_bytes_sha256=pr['source_extracted_image_bytes_sha256']))
                else:sourceboundaries.append(dict(chart=chart,page_pdf=pno,model=full,boundary=which,numeric_result='UNKNOWN',reason='No unambiguous observed boundary ink.'))
        for model,d in vecs.items():
            r=[v for v in rows if v['model']==model];target_end=float(r[-1]['H_m']);q_nominal=float(r[-1]['Q_m3h'])
            for which,pnt in [('join',d['items'][0][1]),('end',d['items'][-1][-1])]:
                x=(pnt[0]-ctm['x0'])/sx;y=(pnt[1]-ctm['y0'])/sy;qact=q_of(x);hact=h_of(y);qtarget=(66. if pno==7 else 162.) if which=='join' else q_nominal
                target=float(next(v['H_m'] for v in r if float(v['Q_m3h'])==qtarget));limit=max(1.,.02*target);eval_=value_at_x(d['items'],pnt[0]);slope=eval_['slope_page_y_per_x']*sx/sy;unc=h_uncertainty(y,slope);delta=hact-target
                res='PASS' if abs(delta)+unc<=limit else 'FAIL' if abs(delta)-unc>limit else 'UNKNOWN'
                endpoints.append(dict(chart=chart,page_pdf=pno,model=model,current_drawing_index=d['index'],which=which,actual_page_xy_pt=pnt,
                    actual_native_cell_xy=[x,y],nominal_table_Q_m3h=qtarget,actual_endpoint_Q_local_m3h=qact,Q_delta_m3h=qact-qtarget,
                    H_table_m=target,H_actual_endpoint_m=hact,H_delta_m=delta,H_uncertainty_m=unc,tolerance_m=limit,result=res,
                    evaluation='Actual mathematical path boundary; nominal Q association recorded separately, not a clamped exact-Q read.',unchanged=True))
        for suffix in order:
            full=chart+'-'+suffix
            if full not in vecs:identity.append(dict(chart=chart,page_pdf=pno,model=full,current_drawing_index=None,
                current_path_type='Own-source raster curve, no separate native vector object on this page',source_rank_top_to_bottom=order.index(suffix)+1,
                printed_source_model_identity=True,identity_basis='Own-source legible printed label and fixed noncrossing trace order.',independent_identity_acceptance='NOT RUN'))
        rawcharts.append(dict(chart=chart,page_pdf=pno,source_trace_reference_native_column=ref,source_trace_reference_components=tr[ref],
            own_source_rank_top_to_bottom=order,source_tracking_before_labels_reference_native_column=leftref,
            source_model_label_strip_native_x=list(labelstrip),source_current_reference_images=dict(source=pr['source_native_png'],current=str(fn),current_sha256=sha(fn)),
            source_trace_columns={str(x):z for x,z in tr.items()},source_trace_before_labels={str(x):z for x,z in ltr.items()},
            known_blank_eta_table=True,eta_numeric_QA='UNKNOWN - no own-source eta numeric table',independent_graphic_acceptance='NOT RUN'))
from collections import Counter
counts=dict(Counter(p['result'] for p in allnodes))
out=dict(source=probe['source'],source_sha256=probe['source_sha256'],current=probe['current'],current_sha256=probe['current_sha256'],
    scope='314 literal own-source table cells, 25 Q-H model identities, all12 literal native current paths, separate24 join/end boundaries.',
    all314_current_node_results=allnodes,actual_model_path_identity=identity,actual_current_path_boundaries=endpoints,all50_own_source_visible_boundaries=sourceboundaries,
    scoped_read_only_counts=counts,source_curve_scoped_read_only_counts=dict(Counter(p['source_read'].get('numeric_read_result','UNKNOWN') for p in allnodes)),independent_acceptance='NOT RUN',counts_not_added_to_catalogue_totals=True,
    structural_QA='NOT RUN - no PDF edited',graphic_QA='NOT RUN',PDF_created=0,canonical_write=False)
(O/'per_sp_uniform_next_actual_curve_readback_v7.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
(O/'per_sp_uniform_next_raw_source_trace_v7.json').write_text(json.dumps(dict(charts=rawcharts,source_sha256=probe['source_sha256'],no_table_H_used_to_pick_source_ink=True),ensure_ascii=False,indent=2),encoding='utf8')
csvrows=[]
for r in allnodes:
    c=r['current_read'] or {};s=r['source_read'];csvrows.append(dict(chart=r['chart'],page_pdf=r['page_pdf'],model=r['model'],Q_m3h=r['Q_m3h'],H_table_m=r['H_table_m'],
        H_source_curve_m=s.get('H_m'),H_source_uncertainty_m=s.get('H_uncertainty_m'),H_current_m=c.get('H_m'),H_current_delta_m=c.get('H_delta_m'),
        H_current_uncertainty_m=c.get('H_uncertainty_m'),tolerance_m=r['technical_tolerance_m'],result=r['result'],reason=r['reason'],method=c.get('method'),
        source_cell_bbox=json.dumps(r['source_cell_native_bbox']),source_table_evidence=r['source_table_evidence'],source_sha256=probe['source_sha256'],current_sha256=probe['current_sha256'],independent_acceptance='NOT RUN'))
with (O/'per_sp_uniform_next_314_points_current_source_v7.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(csvrows[0]));w.writeheader();w.writerows(csvrows)
print('314 counts',counts,'identity',len(identity),'boundaries',len(endpoints))
print('FAIL points',[(p['model'],p['Q_m3h'],p['current_read']) for p in allnodes if p['result']=='FAIL'])
print('FAIL boundaries',[v for v in endpoints if v['result']=='FAIL']);print('source boundaries',len(sourceboundaries),'source curve classification',out['source_curve_scoped_read_only_counts']);print('source FAIL',[(p['model'],p['Q_m3h'],p['source_read']) for p in allnodes if p['source_read'].get('numeric_read_result')=='FAIL'])
