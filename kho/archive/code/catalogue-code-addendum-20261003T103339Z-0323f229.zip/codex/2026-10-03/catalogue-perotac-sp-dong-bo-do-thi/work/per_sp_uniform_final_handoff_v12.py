from pathlib import Path
import csv,json,hashlib,datetime,runpy

B=Path(__file__).resolve().parents[1];O=B/'outputs';W=B/'work';SH=Path(r'D:\ChatGPT\Sửa catalogue')
load=lambda n:json.loads((O/n).read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pr=load('per_sp_uniform_next_source_probe_v4.json');d=load('per_sp_uniform_next_actual_curve_readback_v12.json');mon=load('per_sp_uniform_STRICT_QH_MONOTONIC_AUDIT_v12.json');geo=load('per_sp_uniform_next_table_geometry_preserve_current_v12.json');old=load('per_sp_uniform_REVIEW_MANIFEST_v24.json');receipt=load('per_sp_uniform_SHARED_READ_RECEIPT_v12.json')
assert sha(pr['source'])==pr['source_sha256'] and sha(pr['current'])==pr['current_sha256']
frozen=[dict(file=r['file'],expected_SHA256=r['SHA256'],actual_SHA256=sha(r['absolute_path']),unchanged=sha(r['absolute_path'])==r['SHA256']) for r in old['files']];assert all(r['unchanged'] for r in frozen)
# Check supplied closed-form derivative proofs and preserved live-current bank.
assert mon['native_tail_direction_all_PASS'] and mon['native_tail_spans']==22 and len(mon['intervals'])==289 and len(mon['equal_intervals'])==15
table_candidates=[r for c in geo['charts'] for r in c['table_only_proposed_QH_models']]
flatmodels=[r['model'] for r in table_candidates if r['strict_QH_candidate_result'].startswith('UNKNOWN')]
assert len(flatmodels)==11
new20=next(r for r in table_candidates if r['model']=='6SP60-20');assert new20['literal_current_approved_H_m'][-2:]==[103.,72.]
headers=['# việc','File','Trang','Cũ','Mới','Cách sửa','Kết quả','Bằng chứng'];rows=[]
for i,r in enumerate(d['all314_current_node_results'],1):
    c=r['current_read'];n=f"H bản hiện hành={c['H_m']:.6f} ±{c['H_uncertainty_m']:.6f} m; Δ so số đã chốt={c['H_delta_m']:+.6f}" if c else 'CHƯA THỂ ĐỌC TÂM NÉT TẠI MỐC NÀY'
    if r.get('authorized_override'):n+='; dùng103/72 theo#133; giữ PASS ROOT trước đó riêng'
    rows.append(dict(zip(headers,[f'RS{i:03}',Path(pr['current']).name,r['page_pdf'],f"{r['model']}; Q{r['Q_m3h']:g}; nguồn gốcH{r['H_original_source_m']:g}; số hiện hành đúngH{r['H_table_m']:g}",n,
        'Chỉ đọc; không ghi PDF hoặc đổi path đã chấp nhận. Số hiện hành dùng quyết định có thẩm quyền trước nguồn cũ.',
        'KHỚP MỐC ĐỌC; CHỜ QA ĐỘC LẬP' if r['result']=='PASS' else 'CHƯA ĐẠT PHÉP ĐỌC; CHỜ QA' if r['result']=='FAIL' else 'CHƯA THỂ XÁC MINH MỚI; GIỮ KẾT QUẢ CŨ RIÊNG',
        f"per_sp_uniform_next_actual_curve_readback_v12.json all314_current_node_results[{i-1}]; source bbox{r['source_cell_native_bbox']}; sourceSHA{pr['source_sha256']}; currentSHA{pr['current_sha256']}"])))
with (O/'per_sp_uniform_REPORT_8_COLUMNS_314_AUTHORIZED_POINTS_v12.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(rows)
brief=[]
for i,r in enumerate(mon['equal_intervals'],1):brief.append(dict(zip(headers,[f'EQ{i:02}',Path(pr['current']).name,r['page_pdf'],f"{r['model']}; Q{r['Q0_m3h']:g},H{r['H0_current_table_m']:g}",f"Q{r['Q1_m3h']:g},H{r['H1_current_table_m']:g}",
    'H bằng sau làm tròn: cần đọc toàn đường thật; chưa chọn số nguyên thay. Giữ extrema và điểm đã khóa.','CHƯA THỂ XÁC MINH ĐƯỜNG GIẢM',
    f"per_sp_uniform_STRICT_QH_MONOTONIC_AUDIT_v12.json; {r['model']}; hai bbox{r['original_source_QH_evidence']}"])))
with (O/'per_sp_uniform_REPORT_8_COLUMNS_15_EQUAL_INTERVALS_v12.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(brief)
notice='''# Chọn bộ v12 có thẩm quyền hiện hành

Các bàn giao v9/v10 và đọc path v6/v7/v10 không được dùng làm nghiệm thu hiện hành: chúng so hai điểm6SP60-20 Q72/Q78 với số nguồn cũ110/80, thiếu quyết định#133 đã chốt103/72. Hai FAIL trước đây được RÚT, không sửa hay lùi path hiện hành. Bảng PDF thật đã nhìn xác nhận103/72; ROOT52mốc ghi103/72 ĐẠT.

Chọn actual_curve_readback_v12, SOURCE_AND_APPROVED_CELLS_v12, STRICT_QH_MONOTONIC_AUDIT_v12, geometry_v12 và HANDOFF_v12. Source_cells_v5 vẫn đúng cho314 ô gốc bất biến, là bằng chứng lịch sử chứ không thay hai số đã chốt.

Lần đọc2A Q108 thành36 cũng bị bác bỏ: nguồn in35, v3 của ô đó đúng. Gói v4/v8 không được chọn. Còn5 sửa sai bản chép6SP60, không có sửa mới trên catalogue.

FontSP30v24 FAIL theoROOT; không PDFM1. Tất cả12 path và25 file SP30v24 giữ đúng hash. Các phiên cũ giữ nguyên để truy vết lỗi, không sửa thành PASS.
'''
(O/'per_sp_uniform_PREVIOUS_PACKET_NOT_SELECTED_v12.md').write_text(notice,encoding='utf8')
guard=dict(created_local=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(),source_SHA256_before=pr['source_sha256'],source_SHA256_after=sha(pr['source']),current_SHA256_before=pr['current_sha256'],current_SHA256_after=sha(pr['current']),
    frozen_SP30_v24_files=frozen,all25_old_files_unchanged=True,font_SP30_v24_status='FAIL per ROOT',all12_current_paths_kept=True,
    original_source_cells=314,authorized_overrides=2,source_literal_transcription_fixes=5,false_current_FAIL_retracted=2,
    current_scoped_read_only_counts=d['scoped_read_only_counts'],monotonic_table_intervals=dict(total=289,drop=274,equal=15,increase=0),
    native_tail_math_direction=dict(paths=12,cubics=22,PASS=True,scope='Tails only, not whole25 curves'),
    whole25_curves_numeric_graphic_monotonic_acceptance='UNKNOWN/NOT RUN',source_ETA_numeric='UNKNOWN',candidate11_models_have_flat_literals=flatmodels,
    prior_total_catalogue_counts_inherited_only=dict(PASS=1115,FAIL=29,UNKNOWN=1074,total=2218),total_counts_updated=False,
    PDF_created=0,sample_budget=2,Catfix_sole_future_writer=True,writer_M1_allowed=False,canonical_written=False,ledger_written=False,shared_root_written=False,installation=False,elevation=False,
    local_PDF_files=[str(p) for f in [W,O] for p in f.rglob('*.pdf')])
assert not guard['local_PDF_files']
(O/'per_sp_uniform_FINAL_READONLY_AND_LOCK_CHECK_v12.json').write_text(json.dumps(guard,ensure_ascii=False,indent=2),encoding='utf8')
L=lambda name,label:f'[{label}](<{(O/name).as_posix()}>)'
md=[
'# Bàn giao SP trang7/trang11 — nguồn, số đã chốt và quan hệ Q–H',
'**Đủ314 ô,25 model,123 vạch có nhãn riêng,289 khoảng Q–H. Bảng hiện hành không có cặp H tăng; có15 khoảng H bằng nhau chưa được coi là đường giảm đã đạt. 12 đuôi vector/22 cubic hiện có giảm đúng về toán học, nhưng chưa chứng toàn25 đường. Chưa PDF.**',
'Đính chính quan trọng: **6SP60-20 Q72/Q78 phải dùng103/72 m theo việc#133**, đã nhìn bảng PDF hiện hành và đọc hồ sơROOT52mốc. Hai FAIL từng báo so với nguồn cũ110/80 đã rút; giữ kết quảROOT đã nghiệm thu và toàn bộ tọa độ hiện hành. 10SP135-2A Q108 in35 m; không dùng lần đọc nhầm36.',
'## Bảng và quyền áp dụng số',
'Nguồn gốc314 ô được giữ riêng. 312 số dùng đúng nguồn;2 số cuối6SP60-20 dùng quyết định#133 đã thực hiện. Năm lỗi chép v3 được sửa trong dữ liệu nháp6SP60: -14 Q42 145→144; -20 Q42 207→206, Q48 192→193, Q60 156→159, Q66 132→135. Không có sửa catalogue mới trong phiên này.',
'Đã xem lại đủ4 nửa bảng hiện hành bằng pixelx5, có tên model và đầu cộtQ. Background ảnh hiện hành giữ314/314 cellRGB nguồn; lớp#133 trên trang7 thay đúng hai số103/72 khi tổng hợp. Không lấy background cũ110/80 thay cho chữ đang thấy. Mỗi ô gốc/hiện hành có bbox vàSHA riêng; nguồn2A/4A và công suất/điện áp giữ.',
L('per_sp_uniform_6SP60_SOURCE_AND_APPROVED_CELLS_v12.csv','182 ô6SP60: nguồn và số hiện hành')+' · '+L('per_sp_uniform_10SP135_SOURCE_AND_APPROVED_CELLS_v12.csv','132 ô10SP135')+' · '+L('per_sp_uniform_314_SOURCE_CURRENT_CELL_READBACK_v12.json','Đọc ô thật và hai override có quyền'),
'## Q tăng/H giảm và các khóa',
'- 289 cặp kề cùngmodel:274 H giảm trong số bảng,15 H bằng,0 H tăng. Không dùng “nguồn có tăng nhẹ” để nhận đạt. H bằng sau làm tròn phải kiểm đường thật; chưa tự sửa sang số nguyên khác khi mực/trục/dash chưa đủ chắc.',
'- 15 khoảng bằng:6SP60-2 Q0→6/6→12/48→54; -3 và-4 Q0→6/6→12; -5/-6/-7/-8 Q0→6; -10/-12 Q6→12; 10SP135-1/-2A Q0→18. Bảng8cột ghi riêng từng khoảng.',
'- 12 path tail giữ nguyên22 cubic. Tính cực trị đạo hàm trên toàn từngcubic cho dX/dt>0 vàdY/dt>0 theo hệtọađộ y đi xuống, nên Q tăng/H giảm trên chính các đoạn thật. Đây chỉ chứng chiều giảm tail, không chứng số/đồhọa hay toànđường có phần raster.',
'- Khóa Qmin/Hmax/Qmax/Hmin theo cột đầu/cuối đã xác minh; Hmin6SP60-20=72 m theo#133. Hmin khác đều có số dương riêng, không đặt0. Giữ các path/điểm đã nghiệm thu. Chưa xác minh điểm làm việc riêng trong phạmvi này, không suy từ tênseries60/135 để tự tạo điểm định mức.',
'- Toàn25 đường vẫn UNKNOWN cho kiểm giảm đầy đủ: vùng ảnh, nétđứt, nhãn vàbiên chưa được chứng toàn khoảng. Chưa đề xuất số nguyên trung gian mới vì không phát hiện tăng trong bảng và15 khoảng bằng còn thiếu chứng đường thật. η không áp điều kiệnHgiảm; thiếu bảngη nên sốη UNKNOWN.',
L('per_sp_uniform_STRICT_QH_MONOTONIC_AUDIT_v12.json','289 khoảng, đạo hàm22cubic và25 khóa')+' · '+L('per_sp_uniform_REPORT_8_COLUMNS_289_QH_INTERVALS_v12.csv','Báo cáo8cột đủ289 khoảng')+' · '+L('per_sp_uniform_REPORT_8_COLUMNS_15_EQUAL_INTERVALS_v12.csv','15 khoảngH bằng chưa nghiệmthu'),
'## Các phép đọc số và geometry đã chuẩn bị',
'314 phép đọc hiện hành dùng đúng nguồn+quyết định:21 khớp trong toànbiênđo,0 FAILmới,293 UNKNOWN. Hai điểm#133 giữ PASSROOT kếthừa riêng; đọc lại với trụcđịa phương có biênbảo thủ chưa đủ để cấp PASSmới, cũng không thu hồi PASSđã chốt. Không cộng vào1115/29/1074 của2218mốc toàncatalogue.',
L('per_sp_uniform_REPORT_8_COLUMNS_314_AUTHORIZED_POINTS_v12.csv','Báo cáo8cột đủ314 mốc theo số đã chốt')+' · '+L('per_sp_uniform_next_actual_curve_readback_v12.json','Literal path, sốđo, nguồn vàquyết định#133'),
'25 candidateRAM đi314 neo của bộ số hiện hành103/72, bank12 path cũ vẫn riêng vàkhóa. 11 model candidate có15 đoạn phẳng do số bảng bằng nhau nên **không nhận candidate này là đường giảm toàn bộ**; phải giải quyết bằng nguồn/khóa chắc trước chọn đường. Candidate không là đầu vào cho writerM1. Không đưa110/80 nguồn cũ trở lại.',
'RAM150/600 giữ glyph nguồn bằng bitmap riêng, chồng nétcam chỉ để xem vịtrí; mực cũ chưa xóa. Rủiro va chữ/mực cũ UNKNOWN; có khoảng cách tạmâm ở6SP60-2/-8/-12/-14 và10SP135-4. ηfit570/553 cột mực có residual1,040833/1,065011px vượt1px: giữ UNKNOWN, không vẽđèη.',
'**FontSP30v24 FAIL theoROOT, khôngPDFM1; dừng nghiêncứu contour cùngcách.** Đã kiểm đủ25 SHA filev24 vẫn nguyên. Không lấy topology/diện tích98hình làmgraphicPASS.',
L('per_sp_uniform_next_table_geometry_preserve_current_v12.json','Candidate103/72 vàbank path khóa')+' · '+L('per_sp_uniform_next_oldink_text_collision_risks_v12.csv','Rủiro glyph/mực cũ')+' · '+L('per_sp_uniform_next_6SP60_TABLE_ONLY_DIAGNOSTIC_RAM_v12_150dpi.png','RAM6SP60 diagnostic')+' · '+L('per_sp_uniform_next_10SP135_TABLE_ONLY_DIAGNOSTIC_RAM_v12_150dpi.png','RAM10SP135 diagnostic'),
'## Nguồn riêng và kho dùng chung',
f'PDF nguồn SHA256 `{pr["source_sha256"]}`; PDF hiện hành SHA256 `{pr["current_sha256"]}`. Cảhai đọc trước/sau vẫn nguyên.',
]
for c in pr['charts']:md +=[f'{c["chart"]} trang{c["page_pdf"]}: own-imagebytesSHA `{c["source_extracted_image_bytes_sha256"]}`; decodedRGBSHA `{c["source_decoded_RGB_pixels_sha256"]}`; own-pagecontentsSHA `{c["source_page_contents_sha256"]}`. Từngvạch/CTM lấy từ chínhtrang, không mượntrục/glyph từSP30.']
md +=[L('per_sp_uniform_next_actual_axes_v5.json','Từngvạch vàcửa sổ nguồn riêng')+' · '+L('per_sp_uniform_SHARED_READ_RECEIPT_v12.json','Biênnhận tôiđã đọc khoD vàstatus/context'),
'Đã đọc START_HERE/AGENTS/manifest/hai rules/điểm tiếp tục/sổTIẾNĐỘ/procedure/LOI. Context xác nhậnSHA nguồn/bảnhiệnhành chưađổi. Health tại lượtđọc báo3 controlfilechưa khớpseal doROOT đangniêmphong; lưu nguyênkếtquả, không ghiD haynhận health làQAcatfix. Không giữkhóa ghi vì chỉđọc; lockstore chưakhởi tạo không được diễn giải làquyền ghi.',
'**0PDF tạo, ngân sáchmẫu2 chưa dùng. Nguồn/canonical/TIẾNĐỘ/khoD không ghi; khôngcài/nângquyền. Catfix là writerduynhất nếuROOT cho sauQA.** Phầnchưađạt/thiếu được ghi, không nói cataloguexong.',
L('per_sp_uniform_FINAL_READONLY_AND_LOCK_CHECK_v12.json','Hash trước/sau vàcác khóa')+' · '+L('per_sp_uniform_PREVIOUS_PACKET_NOT_SELECTED_v12.md','Rút haiFAIL dùng sai đích vàloạiv4–v10')]
(O/'per_sp_uniform_AUTHORIZED_QH_HANDOFF_v12.md').write_text('\n\n'.join(md)+'\n',encoding='utf8')
names=['per_sp_uniform_AUTHORIZED_QH_HANDOFF_v12.md','per_sp_uniform_FINAL_READONLY_AND_LOCK_CHECK_v12.json','per_sp_uniform_PREVIOUS_PACKET_NOT_SELECTED_v12.md','per_sp_uniform_SHARED_READ_RECEIPT_v12.json','per_sp_uniform_314_SOURCE_CURRENT_CELL_READBACK_v12.json','per_sp_uniform_6SP60_SOURCE_AND_APPROVED_CELLS_v12.csv','per_sp_uniform_10SP135_SOURCE_AND_APPROVED_CELLS_v12.csv','per_sp_uniform_STRICT_QH_MONOTONIC_AUDIT_v12.json','per_sp_uniform_REPORT_8_COLUMNS_289_QH_INTERVALS_v12.csv','per_sp_uniform_REPORT_8_COLUMNS_15_EQUAL_INTERVALS_v12.csv','per_sp_uniform_REPORT_8_COLUMNS_314_AUTHORIZED_POINTS_v12.csv','per_sp_uniform_next_actual_curve_readback_v12.json','per_sp_uniform_next_table_geometry_preserve_current_v12.json','per_sp_uniform_next_geometry_checks_v12.json','per_sp_uniform_next_oldink_text_collision_risks_v12.csv','per_sp_uniform_next_source_probe_v4.json','per_sp_uniform_next_actual_axes_v5.json','per_sp_uniform_next_actual_ticks_v5.csv','per_sp_uniform_6SP60_source_cells_v5.csv','per_sp_uniform_10SP135_source_cells_v5.csv','per_sp_uniform_next_source_cell_deltas_v5.json','per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.png','per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.json','per_sp_uniform_6SP60_CURRENT_TABLE_TASK133_ACTUAL_PDF600_v12.png','per_sp_uniform_next_p07_CURRENT_TABLE_half2_v12_x5.png','per_sp_uniform_next_p07_CURRENT_TABLE_x422_v12_x5.png','per_sp_uniform_next_p11_CURRENT_TABLE_x1200_v12_x5.png','per_sp_uniform_next_p11_CURRENT_TABLE_x1460_v12_x5.png']
names += [Path(z['path']).name for c in geo['charts'] for z in c['diagnostic_RAM_renders']]
names += [Path(z['file']).name for c in pr['charts'] for z in c['table_source_atlases']]
m=dict(created_local=guard['created_local'],selected_packet=12,authority='Original source + approved task133 + actual current table + new same-model Qup/Hdown rule',source_SHA256=pr['source_sha256'],current_SHA256=pr['current_sha256'],
    files=[dict(file=n,absolute_path=str(O/n),bytes=(O/n).stat().st_size,SHA256=sha(O/n)) for n in names],
    font_v24_status='FAIL per ROOT',PDF_created=0,writer_M1_allowed=False,canonical_written=False,ledger_written=False,full_graphic_numeric_acceptance='NOT RUN/UNKNOWN',false_FAIL2_retracted=True)
(O/'per_sp_uniform_AUTHORIZED_QH_MANIFEST_v12.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf8')
print('Finalv12',len(m['files']),'files; sourcecurrentexact;314authorizedpoints8columns;289monotonicintervals8columns;15equalUNKN; fontv24FAIL; PDFs0')
print('ManifestSHA256',sha(O/'per_sp_uniform_AUTHORIZED_QH_MANIFEST_v12.json'))
