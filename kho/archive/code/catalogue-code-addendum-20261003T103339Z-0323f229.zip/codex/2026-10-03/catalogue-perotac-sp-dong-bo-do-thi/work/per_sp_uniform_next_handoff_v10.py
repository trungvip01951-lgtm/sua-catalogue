from pathlib import Path
import json,csv,hashlib,datetime
import pymupdf as fitz

B=Path(__file__).resolve().parents[1];O=B/'outputs';W=B/'work'
load=lambda n:json.loads((O/n).read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pr=load('per_sp_uniform_next_source_probe_v4.json');d=load('per_sp_uniform_next_actual_curve_readback_v10.json');ax=load('per_sp_uniform_next_actual_axes_v5.json');geo=load('per_sp_uniform_next_table_geometry_preserve_current_v10.json');delta=load('per_sp_uniform_next_source_cell_deltas_v5.json');old=load('per_sp_uniform_REVIEW_MANIFEST_v24.json')
assert sha(pr['source'])==pr['source_sha256'] and sha(pr['current'])==pr['current_sha256']
frozen=[]
for r in old['files']:
    actual=sha(r['absolute_path']);frozen.append(dict(file=r['file'],SHA256_before=r['SHA256'],SHA256_after=actual,unchanged=actual==r['SHA256']));assert frozen[-1]['unchanged'],r['file']
images=[]
with fitz.open(pr['source']) as src,fitz.open(pr['current']) as cur:
    for c in pr['charts']:
        pn=c['page_pdf'];m=c['source_pixel_to_page_pt'];bb=next(z['chart_native_crop'] for z in geo['charts'] if z['chart']==c['chart']);rect=fitz.Rect(m['x0']+bb[0]*m['sx'],m['y0']+bb[1]*m['sy'],m['x0']+bb[2]*m['sx'],m['y0']+bb[3]*m['sy'])
        for tag,doc in [('source',src),('current',cur)]:
            for dpi in [150,600]:
                fn=O/f'per_sp_uniform_next_p{pn:02d}_{tag}_ACTUAL_PDF_chart_v10_{dpi}dpi.png';doc[pn-1].get_pixmap(dpi=dpi,clip=rect,alpha=False).save(fn);images.append(dict(chart=c['chart'],page_pdf=pn,kind=tag,dpi=dpi,path=str(fn),sha256=sha(fn),actual_read_only_PDF_render=True,clip_page_rect_pt=list(rect)))
        own=next(z for z in d['actual_model_path_identity'] if z['chart']==c['chart'] and z.get('current_drawing_index') is not None)
        fresh=cur[pn-1].get_drawings()
        for ident in [z for z in d['actual_model_path_identity'] if z['chart']==c['chart'] and z.get('current_drawing_index') is not None]:
            path=[[v[0],*[list(pt) for pt in v[1:]]] for v in fresh[ident['current_drawing_index']]['items']]
            assert path==ident['current_path_page_pt'],ident['model']

headers=['# việc','File','Trang','Cũ','Mới','Cách sửa','Kết quả','Bằng chứng']
filename=Path(pr['current']).name
points8=[]
reason_vi={
    'Measured uncertainty interval crosses technical tolerance':'Biên đo giao dung sai.',
    'Nominal point intersects a spine or endpoint; no inferred extrapolated centre.':'Vướng trục/biên nét; không suy ra tâm bằng ngoại suy.',
    'Own-source model text touches this reading window; no closest-H assignment or text removal.':'Cửa sổ đo vướng chữ model nguồn; không chọn theo H gần nhất.',
    'Dash gap, weak endpoint, or ambiguous local source ink.':'Khe nét đứt, đầu/cuối mực yếu hoặc nét nguồn mơ hồ.',
    'Full measured interval inside technical tolerance':'Toàn biên đo nằm trong dung sai.',
    'Full measured interval outside technical tolerance':'Toàn biên đo nằm ngoài dung sai.'}
for i,r in enumerate(d['all314_current_node_results'],1):
    c=r['current_read'];n=(f"H đọc PDF hiện hành = {c['H_m']:.6f} ± {c['H_uncertainty_m']:.6f} m; lệch {c['H_delta_m']:+.6f} m" if c else 'CHƯA THỂ ĐỌC TÂM NÉT TẠI MỐC NÀY')
    evidence=f"per_sp_uniform_next_actual_curve_readback_v10.json: all314_current_node_results[{i-1}]; {r['source_table_evidence']}; ô nguồn {r['source_cell_native_bbox']}; SHA ô RGB {r['source_cell_RGB_sha256']}"
    points8.append(dict(zip(headers,[f'RS{i:03}',filename,r['page_pdf'],f"{r['model']}; Q={r['Q_m3h']:g} m³/h; H bảng nguồn={r['H_table_m']:g} m",n,
        'Chỉ đo trên PDF thật đang có; giữ tọa độ, chưa sửa. '+reason_vi.get(r['reason'],r['reason']),
        {'PASS':'KHỚP MỐC ĐỌC; CHỜ ROOT','FAIL':'CHƯA ĐẠT PHÉP ĐỌC; CHỜ ROOT','UNKNOWN':'CHƯA THỂ XÁC MINH'}[r['result']],evidence])))
def write8(name,rows):
    with (O/name).open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(rows)
write8('per_sp_uniform_next_REPORT_8_COLUMNS_314_POINTS_v10.csv',points8)
source8=[]
for i,r in enumerate(delta['deltas'],1):source8.append(dict(zip(headers,[f'D{i:02}',filename,r['page_pdf'],f"Dữ liệu chép v3: {r['model']}; Q{r['Q_m3h']}; H={r['H_v3_wrong']}",
    f"Ảnh nguồn: H={r['H_source_readback']} m",'Sửa dữ liệu nháp sang v5; bảng trong PDF giữ nguyên.','ĐÃ ĐỌC NGUỒN; CHỜ ROOT',f"{r['evidence_image']}; ô {r['source_native_bbox']}; SHA RGB {r['source_cell_RGB_sha256']}"])))
write8('per_sp_uniform_next_REPORT_8_COLUMNS_5_READBACK_FIXES_v10.csv',source8)
bound8=[]
for i,r in enumerate(d['actual_current_path_boundaries'],1):bound8.append(dict(zip(headers,[f'BC{i:02}',filename,r['page_pdf'],f"{r['model']} {r['which']}; bảng Q={r['nominal_table_Q_m3h']:g}, H={r['H_table_m']:g}",
    f"Biên path thật Q={r['actual_endpoint_Q_local_m3h']:.6f}; H={r['H_actual_endpoint_m']:.6f} ± {r['H_uncertainty_m']:.6f}; ΔH={r['H_delta_m']:+.6f}",
    'Đọc đúng biên toán học của path; ghi riêng Q danh định, không kẹp t vào mốc ngoài path. Tọa độ giữ nguyên.',{'PASS':'KHỚP PHÉP ĐỌC; CHỜ ROOT','FAIL':'CHƯA ĐẠT; CHỜ ROOT','UNKNOWN':'CHƯA THỂ XÁC MINH'}[r['result']],f"per_sp_uniform_next_actual_curve_readback_v10.json: actual_current_path_boundaries[{i-1}]; drawing={r['current_drawing_index']}; trang={r['page_pdf']}; điểm={r['actual_page_xy_pt']}"])))
write8('per_sp_uniform_next_REPORT_8_COLUMNS_24_PATH_BOUNDARIES_v10.csv',bound8)
sourcebound8=[]
for i,r in enumerate(d['all50_own_source_visible_boundaries'],1):sourcebound8.append(dict(zip(headers,[f'NS{i:02}',filename,r['page_pdf'],f"{r['model']} {r['boundary']}; bảng Q={r.get('nominal_table_Q_m3h')}, H={r.get('H_table_m')}",
    f"Mực nguồn thấy được Q={r.get('actual_observed_Q_m3h')}; H={r.get('H_source_observed_m')} ± {r.get('H_uncertainty_m')}",
    'Chỉ ghi pixel mực nguồn thực đầu/cuối; không ngoại suy vào mép khung. Nguồn không đổi.', 'NGUỒN CHƯA KHỚP BẢNG; CHỜ ROOT' if r['numeric_result']=='FAIL' else 'CHƯA THỂ XÁC MINH BIÊN CHÍNH XÁC',
    f"per_sp_uniform_next_actual_curve_readback_v10.json: all50_own_source_visible_boundaries[{i-1}]; own-source SHA={r.get('source_image_bytes_sha256')}"])))
write8('per_sp_uniform_next_REPORT_8_COLUMNS_50_SOURCE_BOUNDARIES_v10.csv',sourcebound8)

stamp=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat()
guard=dict(created_local=stamp,source=pr['source'],source_SHA256_before=pr['source_sha256'],source_SHA256_after=sha(pr['source']),current=pr['current'],current_SHA256_before=pr['current_sha256'],current_SHA256_after=sha(pr['current']),
    all12_literal_current_paths_match_fresh_PDF_read=True,frozen_SP30_v24_manifest_files=frozen,all25_frozen_files_unchanged=all(r['unchanged'] for r in frozen),
    scoped_table_cells=314,scope_cells_compared_to_v3=314,v3_equal_cells=309,v3_corrected_cells=5,
    current_point_read_counts=d['scoped_read_only_counts'],source_curve_point_read_counts=d['source_curve_scoped_read_only_counts'],
    total_catalogue_counts_updated=False,total_catalogue_prior_counts_inherited_only=dict(PASS=1115,FAIL=29,UNKNOWN=1074,total=2218),
    PDF_files_in_local_work_outputs=[str(p) for folder in [W,O] for p in folder.rglob('*.pdf')],PDF_created=0,sample_budget=2,Catfix_sole_future_PDF_writer=True,
    installation=False,elevation=False,ledger_or_TIEN_DO_written=False,canonical_written=False,
    actual_read_only_PDF_renders=images,source_fonts_redrawn=False,SP30_contour_iterations_after_ROOT_stop=0,
    full_catalogue_graphic_and_structural_QA='NOT RUN',ROOT_independent_numeric_acceptance='NOT RUN')
assert not guard['PDF_files_in_local_work_outputs']
(O/'per_sp_uniform_next_READONLY_AND_FREEZE_CHECK_v10.json').write_text(json.dumps(guard,ensure_ascii=False,indent=2),encoding='utf8')
L=lambda name,label=None:f'[{label or name}](<{(O/name).as_posix()}>)'
md=['# Bàn giao Perotac SP — 6SP60 trang 7 và 10SP135 trang 11',
    f'Đọc lại lúc {stamp}. **Đủ 314 ô bảng, 25 model Q–H, 123 vạch có nhãn đo riêng, 8 hàng lưới η phụ không gán thêm số in, 50 biên mực nguồn và 24 biên path hiện có. Chưa sẵn sàng ghi PDF.**',
    'Hai mốc hiện hành 6SP60-20 Q72/Q78 vẫn CHƯA ĐẠT sau khi tính biên nguồn. Giữ nguyên cả 12 path và toàn bộ bộ chữ SP30 v24. Không cộng kết quả khảo sát này vào nghiệm thu toàn catalogue.',
    '## Dữ liệu nguồn đã đối chiếu',
    '- 6SP60: 13 model, 14 cột Q=0,6…78, 182 ô H. Trục m³/h thực in 0,10…80; trục l/min thực 0,100…1300. Hai hệ chia được đo riêng, lệch vị trí tối đa 0,600 pixel nguồn. Bản chép v5 giữ riêng công suất, điện áp và các ô H bằng nhau theo nguồn.',
    '- 10SP135: 12 model, 11 cột Q=0,18…180, 132 ô H; giữ riêng 2A/4A và công suất 110 kW ở cả -9/-10. Hai hệ m³/h và l/min lệch tối đa 0,809 pixel nguồn.',
    '- 309 ô v3 khớp; sửa 5 ô dữ liệu nháp, không sửa bảng trong PDF: 6SP60-14 Q42 145→144; -20 Q42 207→206, Q48 192→193, Q60 156→159, Q66 132→135. 10SP135-2A Q108 giữ35; đã bác bỏ lần đọc v4=36 sau so5/6 cùng nguồn. Mỗi ô có bbox và SHA RGB riêng. Đã nhìn toàn bộ ảnh x5 bằng pixel nguồn; QA từng ô của người kiểm độc lập NOT RUN.',
    L('per_sp_uniform_next_REPORT_8_COLUMNS_5_READBACK_FIXES_v10.csv','Báo cáo 8 cột: 5 ô sửa dữ liệu nháp')+' · '+L('per_sp_uniform_6SP60_source_cells_v5.csv','182 ô 6SP60 v5')+' · '+L('per_sp_uniform_10SP135_source_cells_v5.csv','132 ô 10SP135 v5'),
    '## Sai lệch đang có và cách giữ các phần đã làm',
    '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
    '|---|---|---|---|---|---|---|---|',
    '| RS181 | Perotac SP | 7 | 6SP60-20 Q72; bảng H110 m | Path thật H103,344786 ±3,047291 m; Δ−6,655214 m; dung sai2,2 m | Chỉ đọc; giữ drawing9 và tất cả tọa độ; ROOT quyết định trước thay | CHƯA ĐẠT PHÉP ĐỌC | actual_curve_readback_v10, RS181; ảnh PDF thật trang7 |',
    '| RS182 | Perotac SP | 7 | 6SP60-20 Q78; bảng H80 m | Path thật H72,279956 ±3,009038 m; Δ−7,720044 m; dung sai1,6 m | Chỉ đọc; giữ drawing9; chưa áp dụng bảng-only candidate | CHƯA ĐẠT PHÉP ĐỌC | actual_curve_readback_v10, RS182; biên thật H72,141273 m |',
    'Tổng riêng 314 phép đọc trên bản hiện hành: **21 khớp trong toàn biên đo, 2 chưa đạt, 291 chưa thể**. Đây là kết quả đọc chỉ tại mốc trong phạm vi này, vẫn chờ ROOT kiểm độc lập; không đồng nghĩa 21 đường hay toàn trang được nghiệm thu. Dung sai max(1 m, 2% H bảng), không tăng ngưỡng để ép PASS. Các mốc vướng chữ, khe dash, trục/biên hoặc biên đo giao dung sai vẫn UNKNOWN.',
    'Nguồn nguyên bản có 32 mốc khớp/1 chưa khớp/281 chưa thể trong cùng314 mốc. Mốc chưa khớp nguyên bản là 6SP60-18 Q72: 99,009124 ±3,988464 m so với bảng93. Năm điểm mực cuối nguồn không khớp bảng thuộc -18/-16/-14/-10/-8; đây là quan sát nguồn trước sửa, không dùng để lùi các đuôi hiện hành đã chỉnh. 50 bản ghi biên nguồn là pixel đầu/cuối nhìn thấy; mép chính xác dưới trục/cap chưa được giả định.',
    'Gán model theo nhãn nguồn và thứ tự đường liên tục trước/sau vùng chữ, điểm nối, toàn bộ span Bezier và thứ tự đầu/cuối. Không gán bằng H gần nhất. Trang7 drawing0…9 lần lượt là -5/-6/-7/-8/-10/-12/-14/-16/-18/-20; trang11 drawing0/-5 và drawing1/-7. Các model còn lại hiện là ảnh nguồn, không có path vector tách riêng. Tất cả model đều có bản ghi nhận dạng, còn chờ người kiểm độc lập.',
    L('per_sp_uniform_next_REPORT_8_COLUMNS_314_POINTS_v10.csv','Đủ báo cáo 8 cột của 314 mốc')+' · '+L('per_sp_uniform_next_REPORT_8_COLUMNS_24_PATH_BOUNDARIES_v10.csv','24 biên path thật')+' · '+L('per_sp_uniform_next_REPORT_8_COLUMNS_50_SOURCE_BOUNDARIES_v10.csv','50 biên mực nguồn')+' · '+L('per_sp_uniform_next_actual_curve_readback_v10.json','Số đo, biên sai số và literal path'),
    '## Geometry RAM và các phần chưa nghiệm thu',
    '25 candidate chỉ theo bảng nguồn đi đúng314 neo đã đo bằng từng vạch địa phương; sai số roundtrip và nối được lưu trong geometry_checks_v10. Chúng được cung cấp riêng với bank12 path hiện có, **không phải lệnh thay các đuôi đã làm**. Chưa chuyển cho Catfix ghi PDF; phải giải quyết current -20 và sự khác biệt của bộ neo mới với các path khóa trước.',
    'RAM150/600 là chồng đường cam để xem vị trí candidate; nền, chữ/glyph, đường cũ, bảng chia và η đều là pixel của chính trang nguồn. Mực cũ vẫn còn nên có hai nét, không dùng ảnh diagnostic để tuyên bố graphicPASS. Không làm thêm contour hay font sau lệnh dừng ROOT.',
    'Kiểm tra chữ chỉ nhận tạm77 thành phần ở6SP60 và95 ở10SP135;89/74 thành phần vỡ hoặc dính nét được giữ riêng, không giả thành glyph sạch. Candidate pen0,70pt có các khoảng cách tạm âm ở -2/-8/-12/-14 của6SP60 và -4 của10SP135; rủi ro chữ/mực cũ vẫn UNKNOWN, cần soi nguyên ảnh trước chọn cách xóa/vẽ. Bộ chữ SP30 v24 giữ nguyên25 hash; quan ngại ROOT về4, feet/Eta/140/160 vẫn chờ kết luận QA, không nhận đạt từ topology.',
    'η có570/553 cột mực nguồn đọc được; fit tối đa1,040833/1,065011 pixel vượt mục tiêu1 pixel nên geometryη giữ UNKNOWN, chưa vẽ đèη nguồn. Không có bảng số η, numericη UNKNOWN.',
    L('per_sp_uniform_next_table_geometry_preserve_current_v10.json','Candidate geometry + bank path giữ nguyên')+' · '+L('per_sp_uniform_next_oldink_text_collision_risks_v10.csv','Rủi ro chữ/mực cũ riêng')+' · '+L('per_sp_uniform_next_geometry_checks_v10.json','Kiểm tra geometry RAM'),
    L('per_sp_uniform_next_6SP60_TABLE_ONLY_DIAGNOSTIC_RAM_v10_150dpi.png','RAM6SP60 diagnostic150')+' · '+L('per_sp_uniform_next_10SP135_TABLE_ONLY_DIAGNOSTIC_RAM_v10_150dpi.png','RAM10SP135 diagnostic150'),
    '## Nguồn riêng, mã kiểm và giới hạn ghi',
    f'- PDF nguồn SHA256 `{pr["source_sha256"]}`.',
    f'- PDF hiện hành SHA256 `{pr["current_sha256"]}`.',
]
for c in pr['charts']:
    md+= [f'- {c["chart"]} trang{c["page_pdf"]}: imagebytesSHA `{c["source_extracted_image_bytes_sha256"]}`; decodedRGBSHA `{c["source_decoded_RGB_pixels_sha256"]}`; pagecontentsSHA `{c["source_page_contents_sha256"]}`. CTM riêng, không mượn trục hoặc chữ trang5.']
md+= [L('per_sp_uniform_next_actual_axes_v5.json','Từng vạch nguồn và cửa sổ đo')+' · '+L('per_sp_uniform_next_actual_ticks_v5.csv','123 vạch có nhãn')+' · '+L('per_sp_uniform_next_source_probe_v4.json','SHA nguồn và bbox314 ô'),
    '**0 PDF đã tạo; ngân sách mẫu2 chưa sử dụng. Không sửa nguồn, canonical, TIẾN ĐỘ/ledger; không cài đặt/nâng quyền.** Catfix vẫn là người duy nhất ghi PDF nếu ROOT cho phép. FullPDF graphic/structural/outside QA NOT RUN vì chỉ chuẩn bị đọc nguồn và RAM; không đánh đồng với file đã nghiệm thu.',
    L('per_sp_uniform_next_READONLY_AND_FREEZE_CHECK_v10.json','Đọc lại hash trước/sau và khóa25 file SP30')]
mdtext='\n\n'.join(md)+'\n'
mdtext=mdtext.replace(' |\n\n|',' |\n|').replace('|\n\n|','|\n|')
(O/'per_sp_uniform_next_HANDOFF_8_COLUMNS_v10.md').write_text(mdtext,encoding='utf8')
names=['per_sp_uniform_next_HANDOFF_8_COLUMNS_v10.md','per_sp_uniform_next_READONLY_AND_FREEZE_CHECK_v10.json','per_sp_uniform_next_source_probe_v4.json','per_sp_uniform_next_source_cell_deltas_v5.json','per_sp_uniform_6SP60_source_cells_v5.csv','per_sp_uniform_10SP135_source_cells_v5.csv','per_sp_uniform_next_actual_axes_v5.json','per_sp_uniform_next_actual_ticks_v5.csv','per_sp_uniform_next_actual_curve_readback_v10.json','per_sp_uniform_next_314_points_current_source_v10.csv','per_sp_uniform_next_raw_source_trace_v10.json','per_sp_uniform_next_table_geometry_preserve_current_v10.json','per_sp_uniform_next_geometry_checks_v10.json','per_sp_uniform_next_oldink_text_collision_risks_v10.csv']
names+=['per_sp_uniform_next_REPORT_8_COLUMNS_314_POINTS_v10.csv','per_sp_uniform_next_REPORT_8_COLUMNS_5_READBACK_FIXES_v10.csv','per_sp_uniform_next_REPORT_8_COLUMNS_24_PATH_BOUNDARIES_v10.csv','per_sp_uniform_next_REPORT_8_COLUMNS_50_SOURCE_BOUNDARIES_v10.csv']
names+=[Path(z['path']).name for z in images]
names += [Path(z['path']).name for c in geo['charts'] for z in c['diagnostic_RAM_renders']]
names += [Path(z['file']).name for c in pr['charts'] for z in c['table_source_atlases']]
names += ['per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.png','per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.json','per_sp_uniform_next_V4_TO_V9_READBACK_NOT_SELECTED.md']
manifest=dict(created_local=stamp,selected_versions=dict(table_readback=5,axes=5,actual_curve_readback=10,RAM_table_only_geometry=10,handoff=10,frozen_SP30_packet=24),
    source_SHA256=pr['source_sha256'],current_SHA256=pr['current_sha256'],files=[dict(file=n,absolute_path=str(O/n),bytes=(O/n).stat().st_size,SHA256=sha(O/n)) for n in names],PDF_created=0,
    independent_acceptance='NOT RUN',ready_for_PDF_writer=False,Catfix_sole_future_PDF_writer=True,old_final_failures_preserved=True)
(O/'per_sp_uniform_next_MANIFEST_v10.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print('Handoff8 columns complete:',len(points8),'point rows,',len(source8),'readback deltas,',len(bound8),'current boundaries,',len(sourcebound8),'source boundaries')
print('Manifest',len(manifest['files']),'SHA256',sha(O/'per_sp_uniform_next_MANIFEST_v10.json'))
print('Freeze25 files unchanged=',guard['all25_frozen_files_unchanged'],'PDFs0; source/current SHA unchanged')
