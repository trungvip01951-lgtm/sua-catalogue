from pathlib import Path
import csv,json,hashlib
from PIL import Image

B=Path(__file__).resolve().parents[1];O=B/'outputs';W=B/'work'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for chart in ['6SP60','10SP135']:
    rs=list(csv.DictReader((O/f'per_sp_uniform_{chart}_source_cells_v4.csv').open(encoding='utf-8-sig')))
    for r in rs:
        if r['model']=='10SP135-2A' and float(r['Q_m3h'])==108:
            r['H_m']='35';r['H_v3']='35';r['v3_matches_source']='True'
            r['readback']='Own-source 35 verified against printed 5 in same model row and printed 6 in same source table. Previous v4 36 is rejected; v3 35 was correct.'
    with (O/f'per_sp_uniform_{chart}_source_cells_v5.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
d=json.loads((O/'per_sp_uniform_next_source_cell_deltas_v4.json').read_text(encoding='utf8'));d['deltas']=[r for r in d['deltas'] if r['chart']=='6SP60'];d.update(same=309,corrected=5,
    rejected_v4_readback=dict(model='10SP135-2A',Q_m3h=108,v4_wrong=36,source_verified=35,v3_was_correct=True,independent_acceptance='NOT RUN'))
assert len(d['deltas'])==5
(O/'per_sp_uniform_next_source_cell_deltas_v5.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
im=Image.open(W/'per_sp_uniform_next_p11_source_native.png');crops=[('10SP135-2A Q108 source35',(1462,967,1503,982)),('same row Q162 source25',(1592,967,1631,982)),('same table -5 Q180 source66',(1634,1059,1673,1074))]
imgs=[im.crop(b) for _,b in crops];canvas=Image.new('RGB',(max(z.width for z in imgs),sum(z.height for z in imgs)+8),'white');y=0;regions=[]
for (name,b),z in zip(crops,imgs):canvas.paste(z,(0,y));regions.append(dict(description=name,source_native_bbox=list(b),montage_native_bbox=[0,y,z.width,y+z.height],source_RGB_sha256=hashlib.sha256(z.tobytes()).hexdigest()));y+=z.height+4
fn=O/'per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.png';canvas.resize((canvas.width*20,canvas.height*20),Image.Resampling.NEAREST).save(fn)
(O/'per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.json').write_text(json.dumps(dict(correct_source_value=35,rejected_read=36,source_pixels_never_changed=True,
    comparison='Own-source 5 has a solid flat upper bar and upper-left stem; own-source 6 has a curved upper arch. The ambiguous target matches the printed5. This supports the visual read, not a new font or independent acceptance.',
    regions=regions,proof_image=str(fn),proof_image_SHA256=sha(fn),independent_acceptance='NOT RUN'),ensure_ascii=False,indent=2),encoding='utf8')
# Corrected versions are fresh files. All old versions stay available as evidence.
s=(W/'per_sp_uniform_next_curve_read_v7.py').read_text(encoding='utf8').replace('_v7','_v10').replace('source_cells_v4','source_cells_v5')
(W/'per_sp_uniform_next_curve_read_v10.py').write_text(s,encoding='utf8')
s=(W/'per_sp_uniform_next_geometry_v8.py').read_text(encoding='utf8').replace('_v8','_v10').replace('curve_readback_v7','curve_readback_v10').replace('source_trace_v7','source_trace_v10').replace('source_cells_v4','source_cells_v5')
(W/'per_sp_uniform_next_geometry_v10.py').write_text(s,encoding='utf8')
s=(W/'per_sp_uniform_next_handoff_v9.py').read_text(encoding='utf8').replace('_v9','_v10').replace('curve_readback_v7','curve_readback_v10').replace('current_source_v7','current_source_v10').replace('source_trace_v7','source_trace_v10').replace('_v8','_v10').replace('source_cells_v4','source_cells_v5').replace('source_cell_deltas_v4','source_cell_deltas_v5')
s=s.replace('8_COLUMNS_6_READBACK_FIXES','8_COLUMNS_5_READBACK_FIXES').replace('v3_equal_cells=308,v3_corrected_cells=6','v3_equal_cells=309,v3_corrected_cells=5')
s=s.replace('308 ô v3 khớp; sửa 6 ô','309 ô v3 khớp; sửa 5 ô').replace('; 10SP135-2A Q108 35→36.','. 10SP135-2A Q108 giữ35; đã bác bỏ lần đọc v4=36 sau so5/6 cùng nguồn.').replace('6 ô sửa dữ liệu nháp','5 ô sửa dữ liệu nháp')
s=s.replace('chép sang v4','chép sang v5').replace('nháp sang v4','nháp sang v5').replace('182 ô 6SP60 v4','182 ô 6SP60 v5').replace('132 ô 10SP135 v4','132 ô 10SP135 v5').replace('Bản chép v4','Bản chép v5')
s=s.replace('geometry_checks_v8','geometry_checks_v10').replace('actual_curve_readback_v7','actual_curve_readback_v10')
s=s.replace("(O/'per_sp_uniform_next_HANDOFF_8_COLUMNS_v10.md').write_text('\\n\\n'.join(md)+'\\n',encoding='utf8')", "mdtext='\\n\\n'.join(md)+'\\n'\n+mdtext=mdtext.replace(' |\\n\\n|',' |\\n|')\n+(O/'per_sp_uniform_next_HANDOFF_8_COLUMNS_v10.md').write_text(mdtext,encoding='utf8')".replace('\n+','\n'))
s=s.replace("selected_versions=dict(table_readback=4,axes=5,actual_curve_readback=7,RAM_table_only_geometry=8,handoff=9,frozen_SP30_packet=24)","selected_versions=dict(table_readback=5,axes=5,actual_curve_readback=10,RAM_table_only_geometry=10,handoff=10,frozen_SP30_packet=24)")
s=s.replace("names += [Path(z['file']).name for c in pr['charts'] for z in c['table_source_atlases']]", "names += [Path(z['file']).name for c in pr['charts'] for z in c['table_source_atlases']]\n+names += ['per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.png','per_sp_uniform_10SP135_2A_Q108_SOURCE35_VERIFIED_v10.json','per_sp_uniform_next_V4_TO_V9_READBACK_NOT_SELECTED.md']".replace('\n+','\n'))
(W/'per_sp_uniform_next_handoff_v10.py').write_text(s,encoding='utf8')
(O/'per_sp_uniform_next_V4_TO_V9_READBACK_NOT_SELECTED.md').write_text('''# Các gói v4 đến v9 không được chọn

Lần đọc 10SP135-2A Q108 thành36 m là sai; nguồn in35 m. So sánh nét số5 và6 từ chính bảng nguồn đã làm rõ. V3 của ô này đúng; nguồn PDF và bảng PDF luôn nguyên trạng.

Không dùng bảng10SP135_v4, geometry_v8 hay handoff/manifest_v9 làm đầu vào. Chọn source_cells_v5 và actual_readback/geometry/handoff/manifest_v10. Bảng6SP60 v5 vẫn có5 ô dữ liệu nháp được sửa đúng theo nguồn. Dữ liệu cũ được giữ để truy vết; không xóa hay đổi nguồn.

Hai FAIL hiện hành của6SP60-20 Q72/Q78 không bị tác động bởi ô đọc nhầm này. Tất cả12 path hiện hành và25 file bộ SP30 v24 được giữ nguyên.
''',encoding='utf8')
print('Source35 correction selected:314 cells;309 v3 equal;5 Perotac6SP60 draft fixes. Versions4-9 retained but not selected.')
