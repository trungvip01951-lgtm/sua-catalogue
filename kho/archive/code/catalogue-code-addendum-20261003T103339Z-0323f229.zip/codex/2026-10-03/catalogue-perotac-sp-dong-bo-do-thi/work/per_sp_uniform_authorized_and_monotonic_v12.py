from pathlib import Path
import json,csv,hashlib,datetime,io,runpy
import numpy as np
from PIL import Image
import pymupdf as fitz
from collections import Counter,defaultdict

B=Path(__file__).resolve().parents[1];O=B/'outputs';W=B/'work';SH=Path(r'D:\ChatGPT\Sửa catalogue')
load=lambda n:json.loads((O/n).read_text(encoding='utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pr=load('per_sp_uniform_next_source_probe_v4.json');orig=load('per_sp_uniform_next_actual_curve_readback_v10.json');axes=load('per_sp_uniform_next_actual_axes_v5.json')
assert sha(pr['source'])==pr['source_sha256'] and sha(pr['current'])==pr['current_sha256']
taskfile=SH/'vendor/catfix_original/GOI_SUA_CATALOGUE_CHATGPT/tasks/tasks.json';tasks=json.loads(taskfile.read_text(encoding='utf-8-sig'));task=next(r for r in tasks['tasks'] if r['id']==133)
assert task['new'].startswith('103 / 72')
ledger=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 03-10-2026 (ChatGPT)\_BAO CAO\TIEN DO.md')
rootcsv=ledger.parent/'G05/52 MOC DOC LAP ROOT.csv';prior=list(csv.DictReader(rootcsv.open(encoding='utf-8-sig')))
tool=runpy.run_path(str(SH/'tools/catalogue.py'),run_name='sp_read_only_shared_tools')
shared=dict(health=tool['health'](),context=tool['context']('Giếng/Perotac bơm giếng SP_compressed (bản mới).pdf'),status=tool['status']())
receipt=dict(created_local=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(),thread_id='01a0ffa9-e245-7b82-87b9-3871ab5ad89d',scope='SP p7/p11 source314 cells and strict Q-H read-only audit; no PDF writer.',
    files_read=[dict(path=str(SH/x),sha256=sha(SH/x)) for x in ['START_HERE.md','AGENTS.md','manifest.json','rules/QUY_TAC_ANH_TRUNG.md','rules/PHOI_HOP_CHATGPT_CLAUDE.md','state/CURRENT_CHECKPOINT.md','procedures/DUONG_DAC_TINH.md']],
    ledger_path=str(ledger),ledger_sha256=sha(ledger),original_task133=task,original_task_file=str(taskfile),original_task_file_sha256=sha(taskfile),
    prior_ROOT_52_csv=str(rootcsv),prior_ROOT_52_csv_sha256=sha(rootcsv),shared_read_only_tools=shared,
    source_sha256=pr['source_sha256'],current_sha256=pr['current_sha256'],write_lock_needed=False,shared_receipt_written=False,
    ROOT_shared_seal_in_progress='Health reports changed controls; only read-only preparation continues. No claim or shared write, no acceptance inferred from project health.',
    new_rule_applied='Each same-model Q-H checked for increasing/equal H; extrema and approved points kept; eta excluded; no source increase accepted.',font_SP30_v24='FAIL per ROOT, unchanged',writer_M1_allowed=False)
(O/'per_sp_uniform_SHARED_READ_RECEIPT_v12.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
allrows=[];cellpixel=[]
with fitz.open(pr['current']) as cur:
    for chart in ['6SP60','10SP135']:
        rows=list(csv.DictReader((O/f'per_sp_uniform_{chart}_source_cells_v5.csv').open(encoding='utf-8-sig')));c=next(z for z in pr['charts'] if z['chart']==chart);pno=c['page_pdf'];a=np.asarray(Image.open(W/f'per_sp_uniform_next_p{pno:02d}_current_native_render_v10.png').convert('RGB'))
        source=np.asarray(Image.open(c['source_native_png']));backxref=55 if pno==7 else 72;raw=np.asarray(Image.open(io.BytesIO(cur.extract_image(backxref)['image'])).convert('RGB'))
        for r in rows:
            originalH=int(r['H_m']);q=int(r['Q_m3h']);approvedH=103 if r['model']=='6SP60-20' and q==72 else 72 if r['model']=='6SP60-20' and q==78 else originalH
            bbox=json.loads(r['evidence_native_bbox']);x0,y0,x1,y1=bbox;override=approvedH!=originalH
            r.update(H_original_immutable_source_m=originalH,H_m=approvedH,H_expected_current_m=approvedH,
                current_expected_basis='Authorized task133, actual current table independently viewed' if override else 'Literal source table and actual current table independently viewed',
                authorized_task_id=133 if override else '',authorized_task_sha256=sha(taskfile) if override else '',
                current_table_cell_RGB_sha256=hashlib.sha256(a[y0:y1,x0:x1].tobytes()).hexdigest(),
                current_background_cell_exact_source_RGB=bool(np.array_equal(raw[y0:y1,x0:x1],source[y0:y1,x0:x1])),
                original_background_is_not_final_composite='The page7 task133 overlay changes2 final displayed cells; original background pixels alone do not define current expected values.',
                effective_extrema_locks='First and last actual current table values locked; model20 Hmin72 comes from authorized133, not immutable source80.')
            allrows.append(r);cellpixel.append(dict(chart=chart,model=r['model'],Q_m3h=q,source_H=originalH,current_H=approvedH,source_cell_bbox=bbox,current_cell_RGB_sha256=r['current_table_cell_RGB_sha256'],background_source_pixels_exact=r['current_background_cell_exact_source_RGB'],approved_override=override))
        with (O/f'per_sp_uniform_{chart}_SOURCE_AND_APPROVED_CELLS_v12.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    # Save a raw current table region with real row model and realQ headers.
    page=cur[6];m=next(c['source_pixel_to_page_pt'] for c in pr['charts'] if c['chart']=='6SP60');rect=fitz.Rect(m['sx']*172,m['y0']+m['sy']*925,m['sx']*811,m['y0']+m['sy']*1172)
    page.get_pixmap(dpi=600,clip=rect,alpha=False).save(O/'per_sp_uniform_6SP60_CURRENT_TABLE_TASK133_ACTUAL_PDF600_v12.png')
(O/'per_sp_uniform_314_SOURCE_CURRENT_CELL_READBACK_v12.json').write_text(json.dumps(dict(source_sha256=pr['source_sha256'],current_sha256=pr['current_sha256'],cells=cellpixel,
    literal_source_cells=314,current_table_cells_read=314,exact_source_background_cell_count=sum(r['background_source_pixels_exact'] for r in cellpixel),
    authorized_current_composite_overrides=2,source_transcription_v3_fixes=5,source2A_Q108_correct=35,independent_acceptance='NOT RUN'),ensure_ascii=False,indent=2),encoding='utf8')
# Reclassify comparisons using the authorized current expected values. Keep the
# raw-source baseline result explicitly, so retractions are visible and auditable.
d=json.loads(json.dumps(orig));d['scope']='314 original source cells, 2 authorized task133 overrides,25 identities,12 current path banks, strict Q-H audit.'
for r in d['all314_current_node_results']:
    rs=next(z for z in allrows if z['model']==r['model'] and float(z['Q_m3h'])==r['Q_m3h']);approved=float(rs['H_m']);old=r['H_table_m']
    r['H_original_source_m']=old;r['original_source_comparison_historical_result']=r['result'];r['H_table_m']=approved;r['expected_authority']='task133' if approved!=old else 'source table/current table';r['technical_tolerance_m']=max(1.,.02*approved)
    if r['current_read']:
        c=r['current_read'];delta=c['H_m']-approved;u=c['H_uncertainty_m'];c['H_delta_m']=delta;r['result']='PASS' if abs(delta)+u<=r['technical_tolerance_m'] else 'FAIL' if abs(delta)-u>r['technical_tolerance_m'] else 'UNKNOWN'
    if approved!=old:
        rr=next(z for z in prior if z.get('model')==r['model'] and float(z.get('Q','-1'))==r['Q_m3h'])
        r['authorized_override']={'task_id':133,'original_H':old,'approved_H':approved,'current_table_read':True,'original_task_sha256':sha(taskfile)}
        r['prior_ROOT_acceptance_inherited']=rr;r['prior_ROOT_acceptance_reopened']=False;r['reason']='Previous FAIL was a comparison against superseded original110/80. Current approved103/72 is the target; fresh conservative read UNKNOWN does not revoke inherited ROOT PASS.'
for r in d['actual_current_path_boundaries']:
    if r['model']=='6SP60-20' and r['which']=='end':
        r.update(H_original_source_m=80,H_table_m=72,H_delta_m=r['H_actual_endpoint_m']-72,tolerance_m=1.44,expected_authority='task133 approved72',previous_FAIL_retracted=True)
        delta=r['H_delta_m'];u=r['H_uncertainty_m'];r['result']='PASS' if abs(delta)+u<=1.44 else 'FAIL' if abs(delta)-u>1.44 else 'UNKNOWN'
d['scoped_read_only_counts']=dict(Counter(r['result'] for r in d['all314_current_node_results']));d['retracted_false_current_FAIL_count']=2
d['current_expected_authority']='Original source plus user task133; not immutable original alone';d['font_v24_status']='FAIL per ROOT, coordinates unchanged';d['ready_for_PDF_writer']=False
(O/'per_sp_uniform_next_actual_curve_readback_v12.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
# Robust polynomial derivative proof on every literal native existing cubic.
def deriv_extrema(p,coord):
    z=np.array(p,float)[:,coord];a=3*(-z[0]+3*z[1]-3*z[2]+z[3]);b=6*(z[0]-2*z[1]+z[2]);c=3*(z[1]-z[0]);ts=[0.,1.]
    if abs(a)>1e-14 and 0<-b/(2*a)<1:ts.append(float(-b/(2*a)))
    v=[a*t*t+b*t+c for t in ts];return dict(min=min(v),max=max(v),evaluated_t=ts,quadratic_coefficients=[float(a),float(b),float(c)])
nativeproof=[]
for ident in d['actual_model_path_identity']:
    if ident.get('current_drawing_index') is None:continue
    spans=[]
    for i,seg in enumerate(ident['current_path_page_pt']):
        p=seg[1:];dx=deriv_extrema(p,0);dy=deriv_extrema(p,1);spans.append(dict(index=i,dx_dt_pt=dx,dy_dt_topdown_pt=dy,Q_increases_and_H_decreases=bool(dx['min']>0 and dy['min']>0)))
    nativeproof.append(dict(model=ident['model'],page_pdf=ident['page_pdf'],current_drawing_index=ident['current_drawing_index'],current_path_sha256=ident['current_path_sha256'],
        all_spans_strict_Q_up_H_down=all(z['Q_increases_and_H_decreases'] for z in spans),spans=spans,
        domain='Actual existing tail only; does not prove whole source raster curve.',unchanged_current_controls=True))
groups=defaultdict(list)
for r in allrows:groups[r['model']].append(r)
intervals=[];locks=[];eq=[]
for model,rows in groups.items():
    rows=sorted(rows,key=lambda r:float(r['Q_m3h']));chart=rows[0]['chart'];first=rows[0];last=rows[-1]
    locks.append(dict(chart=chart,model=model,Qmin=float(first['Q_m3h']),Hmax=float(first['H_m']),Qmax=float(last['Q_m3h']),Hmin=float(last['H_m']),
        extrema_evidence='Own-source first/last explicit table columns with authorized133 override applied; no fabricated zeroHmin.',
        rated_or_working_point='UNKNOWN: no separate duty mark or user-defined duty coordinates established in this p7/p11 read; series-name60/135 is not assumed a locked duty point.',
        existing_native_tail_controls_locked=model in [n['model'] for n in nativeproof],first_last_and_current_paths_not_changed=True))
    for a,b in zip(rows[:-1],rows[1:]):
        q0,q1=float(a['Q_m3h']),float(b['Q_m3h']);h0,h1=float(a['H_m']),float(b['H_m']);typ='DECREASE' if h1<h0 else 'EQUAL' if h1==h0 else 'INCREASE_ERROR'
        ra=next(z for z in d['all314_current_node_results'] if z['model']==model and z['Q_m3h']==q0);rb=next(z for z in d['all314_current_node_results'] if z['model']==model and z['Q_m3h']==q1);ca,cb=ra['current_read'],rb['current_read']
        if ca and cb:
            dh=cb['H_m']-ca['H_m'];u=ca['H_uncertainty_m']+cb['H_uncertainty_m'];curve='DECREASE_AT_TWO_ENDPOINT_BOUNDS_ONLY' if dh+u<0 else 'INCREASE_ERROR_AT_ENDPOINT_BOUNDS' if dh-u>0 else 'UNKNOWN'
            readpair=dict(delta_H_m=dh,delta_H_uncertainty_sum_m=u,endpoint_bound_classification=curve,not_whole_interval_tangent_proof=True)
        else:curve='UNKNOWN';readpair=dict(reason='One/both actual point reads missing, dash/text/boundary ambiguous.',endpoint_bound_classification=curve)
        rec=dict(chart=chart,page_pdf=int(a['page_pdf']),model=model,Q0_m3h=q0,Q1_m3h=q1,H0_current_table_m=h0,H1_current_table_m=h1,
            literal_delta_H_m=h1-h0,literal_relation=typ,current_curve_pair_read=readpair,
            full_interval_in_current_native_tail=None,
            equal_is_not_accepted_as_a_decreasing_curve=typ=='EQUAL',eta_rule_not_applied=True,
            intermediate_integer_proposal=None,intermediate_proposal_status='UNKNOWN - no unambiguous own-source numeric evidence to replace an equal rounded value.' if typ=='EQUAL' else 'NO CHANGE PROPOSED; no literal rise found',
            original_source_QH_evidence=[a['evidence_native_bbox'],b['evidence_native_bbox']],source_sha256=pr['source_sha256'],current_sha256=pr['current_sha256'])
        ident=next((z for z in d['actual_model_path_identity'] if z['model']==model and z.get('current_drawing_index') is not None),None)
        if ident:
            ax=next(z for z in axes['charts'] if z['chart']==chart);tick=ax['axes']['Q_m3h']['ticks'];xp=np.interp([q0,q1],[t['value'] for t in tick],[t['page_coord_pt'] for t in tick]);dom=ident['actual_domain_page_x_pt']
            if dom[0]<=xp[0]<=xp[1]<=dom[1]:rec['full_interval_in_current_native_tail']=dict(current_drawing_index=ident['current_drawing_index'],whole_native_tail_derivative_proof=True,strict_decrease='PASS MATHEMATICAL DIRECTION ONLY')
        intervals.append(rec)
        if typ=='EQUAL':eq.append(rec)
assert len(intervals)==289 and len(eq)==15 and not [r for r in intervals if r['literal_relation']=='INCREASE_ERROR']
mon=dict(source_sha256=pr['source_sha256'],current_sha256=pr['current_sha256'],all314_source_and_authorized_current_cells_read=True,
    adjacent_same_model_intervals=289,literal_relation_counts=dict(Counter(r['literal_relation'] for r in intervals)),equal15_need_actual_curve_check=True,
    intervals=intervals,equal_intervals=eq,all25_extrema_and_missing_working_point_locks=locks,all12_existing_native_tail_direction_proofs=nativeproof,
    native_tail_spans=sum(len(n['spans']) for n in nativeproof),native_tail_direction_all_PASS=all(n['all_spans_strict_Q_up_H_down'] for n in nativeproof),
    physical_whole_curve_acceptance='UNKNOWN for all25: only native tails proved, original raster/dash/text regions incomplete; source slight rises are not accepted.',
    eta_included_in_H_decrease_test=False,eta_numeric='UNKNOWN, no own-source eta table',integer_information_changes_proposed=0,
    why_no_integer_change='No increasing literal pair in scope; equal integer cells need actual curve reading. Current source resolution/dash/text gaps do not justify choosing replacement integers. Extrema/current accepted paths stay locked.',
    font_v24='FAIL per ROOT',writer_M1_allowed=False,PDF_created=0,canonical_write=False,ledger_write=False)
(O/'per_sp_uniform_STRICT_QH_MONOTONIC_AUDIT_v12.json').write_text(json.dumps(mon,ensure_ascii=False,indent=2),encoding='utf8')
headers=['# việc','File','Trang','Cũ','Mới','Cách sửa','Kết quả','Bằng chứng'];out=[]
for i,r in enumerate(intervals,1):out.append(dict(zip(headers,[f'M{i:03}',Path(pr['current']).name,r['page_pdf'],f"{r['model']}; Q{r['Q0_m3h']:g} H{r['H0_current_table_m']:g}",f"Q{r['Q1_m3h']:g} H{r['H1_current_table_m']:g}; ΔH{r['literal_delta_H_m']:g}",
    'Chỉ đọc; giữ extrema và path khóa. '+('Chờ đọc đường thật; chưa đề xuất số nguyên.' if r['literal_relation']=='EQUAL' else 'Không phát hiện tăng trong cặp số bảng này.'),
    'H BẰNG — ĐƯỜNG THẬT CHƯA THỂ' if r['literal_relation']=='EQUAL' else 'H GIẢM TRONG CẶP SỐ; CHƯA NGHIỆM THU TOÀN ĐƯỜNG',
    f"per_sp_uniform_STRICT_QH_MONOTONIC_AUDIT_v12.json intervals[{i-1}]; Q/H source+approved cells_v12; sourceSHA{pr['source_sha256']}"])))
with (O/'per_sp_uniform_REPORT_8_COLUMNS_289_QH_INTERVALS_v12.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(out)
print('314 corrected expected cells:312source +2authorized133; source/canonical SHAunchanged')
print('Fresh point counts',d['scoped_read_only_counts'],'false2FAIL retracted; inheritedROOT PASS not reopened')
print('289same-model intervals',mon['literal_relation_counts'],'12native tails/22cubics strict direction PASS only; all25whole curves UNKNOWN')
