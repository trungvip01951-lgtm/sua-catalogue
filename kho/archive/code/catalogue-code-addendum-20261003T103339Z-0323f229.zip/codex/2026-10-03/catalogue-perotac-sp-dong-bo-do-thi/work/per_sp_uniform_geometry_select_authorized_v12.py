from pathlib import Path
import json
B=Path(__file__).resolve().parents[1];W=B/'work'
s=(W/'per_sp_uniform_next_geometry_v10.py').read_text(encoding='utf8').replace('_v10','_v12')
s=s.replace('per_sp_uniform_next_raw_source_trace_v12.json','per_sp_uniform_next_raw_source_trace_v10.json')
s=s.replace("f'per_sp_uniform_{chart}_source_cells_v5.csv'","f'per_sp_uniform_{chart}_SOURCE_AND_APPROVED_CELLS_v12.csv'")
s=s.replace("literal_source_H_m=h.tolist()","literal_current_approved_H_m=h.tolist(),immutable_original_H_m=[float(r['H_original_immutable_source_m']) for r in rs]")
s=s.replace("existing_current_path_replaced=False,","existing_current_path_replaced=False,strict_QH_candidate_result='UNKNOWN - flat rounded literal interval(s) require actual source-curve review' if any(h[i]==h[i+1] for i in range(len(h)-1)) else 'PASS mathematical direction only',")
s=s.replace("ROOT must resolve 6SP60-20 current tail Q72/Q78 FAIL before deciding any replacement; current coordinates are locked.","Current task133 approved103/72 and all12 previously accepted tails remain locked. Fifteen equal integer intervals need real-curve review; no invented integer changes.")
s=s.replace("ROOT font/graphic review is still pending; no new font iterations here.","ROOT fontv24 FAIL, no writerM1 or new font iterations here.")
s=s.replace("source_equal_values_and_2A_4A_preserved=True,","source_equal_values_and_2A_4A_preserved=True,task133_authorized103_72_used=True,equal_literals_do_not_prove_strict_physical_decrease=True,")
s=s.replace("graphic_QA='NOT RUN',independent_acceptance='NOT RUN')","graphic_QA='NOT RUN',font_v24='FAIL per ROOT',independent_acceptance='NOT RUN',effective_H_authority='Original source plus approved task133103/72; no reversion to110/80')")
(W/'per_sp_uniform_next_geometry_v12.py').write_text(s,encoding='utf8')
print('v12 candidate uses actual authorized103/72, keeps12path bank; rounded15equal intervals not accepted as strict decrease.')
