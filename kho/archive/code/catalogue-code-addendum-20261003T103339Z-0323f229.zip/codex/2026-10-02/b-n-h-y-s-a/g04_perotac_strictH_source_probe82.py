"""Read own SA source/locks/table grid only; do not alter PDF/table/fonts."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
import hashlib, json, runpy, sys
import numpy as np
from PIL import Image
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from g04_perotac_whole_pdf_tools46 import read, sha

NAME = 'Perotac bơm giếng SA_compressed (bản mới).pdf'
PROJECT = Path(r'D:\ChatGPT\Sửa catalogue')
WORK = PROJECT / 'work/g03_sa_p2p3_qh_giam_nguyen_v1'
ACTOR = '/root/g03_aquaris_sa'
SESSION = 'g03_sa_p2p3_strictH20261003_v1'
BEFORE = dict(source=sha(S.src(NAME)), current=sha(S.result(NAME)))
assert BEFORE == dict(source='3925ae2a4beaf22a6514837949e631b2777e83dcd87e4990d7fbd01f3c5d2bcd', current='389a670c2871d450b8c0e9544d8550c0afa810e646921877752ccf2dd031e32c')
controls = [
    'AGENTS.md', 'START_HERE.md', 'README.md', 'manifest.json',
    'rules/QUY_TAC_ANH_TRUNG.md', 'rules/PHOI_HOP_CHATGPT_CLAUDE.md',
    'procedures/QUY_TRINH_SUA_VA_NGHIEM_THU.md', 'procedures/DUONG_DAC_TINH.md',
    'knowledge/THAY_DOI_QUY_TAC_20261003.md', 'knowledge/LOI_VA_CACH_TRANH.md',
    'knowledge/CACH_DA_NGHIEM_THU.md', 'knowledge/BAN_DO_MA_NGUON_VA_BANG_CHUNG.md',
    'templates/BAO_CAO8_COT.md', 'state/CURRENT_CHECKPOINT.md', 'state/active_assignments.json']
coordination = runpy.run_path(str(PROJECT / 'tools/catalogue.py'))
context = coordination['context']('Giếng/' + NAME)
assert not context['inputs_changed_since_snapshot'] and not context['controls']['changed']
receipt = coordination['receipt'](ACTOR, SESSION,
    'Chính phiên G03 đã đọc hướng dẫn/rules/procedures/knowledge liên quan và sổ gốc; health/status/context SA khớp mã. BƯỚC0 và43/43 vừa chạy thật. Phạm vi mới chỉ lập phương án nguyên giảm 3SS3/3SS4 p2/p3; giữ extrema và điểm làm việc đã xác minh. Không ghi PDF/bảng/phông/TIEN DO; RAMp8V4 font chưa đạt,0PDF. Không suy Q/H định mức từ tên. Bước sau: báo cáo8cột có điều kiện chưa xác minh điểm làm việc bổ sung cho ROOT kiểm.')
group_tasks = [t for t in D['tasks'] if 'G04' in t.get('groups', [])]
assert len(group_tasks) == 15
old_plan = Path(S.report('G04/PHUONG AN TOAN BIEU DO TRANG02 VA03 CHI DOC/TOAN MIEN161 O VA KHOANG CHU GIAI V3 CHI DOC/PHUONG AN161 O VA CHU GIAI KHONG CHAM BANG V3 CHI DOC.json'))
old = read(old_plan)
assert old['source_sha256'] == BEFORE['source'] and old['canonical_sha256'] == BEFORE['current']

def line_groups(profile, offset, threshold):
    indices = np.flatnonzero(profile >= threshold)
    groups = []
    for group in np.split(indices, np.where(np.diff(indices) > 1)[0] + 1):
        if not len(group):
            continue
        weight = profile[group]
        groups.append(dict(start=int(group[0] + offset), end_exclusive=int(group[-1] + 1 + offset),
            center_native=float(np.average(group + offset + .5, weights=weight)),
            support_fraction=weight.tolist(), boundary_uncertainty_native_px=1))
    return groups

E = Editor(S.src(NAME), backend='fitz')
R = Raster(E)
evidence = []
for family, box in [('3SS3',[962,936,1695,1165]), ('3SS4',[60,936,793,1165]), ('4SA16',[60,836,793,1165])]:
    data = next(d for d in DATA if d['family'] == family)
    im = max(R.images(data['page']-1), key=lambda z:z.W*z.H)
    cv = R.canvas(im)
    raw = cv.orig
    gray = raw.mean(2)
    x0,y0,x1,y1 = box
    # Native table boundaries are read from long actual gray/black strokes;
    # no ideal equal-spacing grid is substituted for the source.
    vb = (gray[y0+65:y1-5, x0:x1] < 190).mean(axis=0)
    hb = (gray[y0:y1, x0+342:x1-5] < 190).mean(axis=1)
    vgroups = line_groups(vb,x0,.7)
    hgroups = line_groups(hb,y0,.7)
    p = Path(fresh(WORK / (family+' BANG NGUON NGUYEN PIXEL.png')))
    Image.fromarray(raw[y0:y1,x0:x1]).save(p)
    p2 = Path(fresh(WORK / (family+' BANG NGUON PHONG3 CHI DOC.png')))
    Image.fromarray(raw[y0:y1,x0:x1]).resize(((x1-x0)*3,(y1-y0)*3),Image.Resampling.NEAREST).save(p2)
    forigin = Path(fresh(WORK/(family+' TOAN TRANG NGUON KHONG SUA.png')))
    Image.fromarray(raw).save(forigin)
    evidence.append(dict(page=data['page'],family=family,Q_m3_h=data['Q_m3_h'],rows=data['rows'],
        table_crop_native=box,source_image=str(im.name),source_image_key=im.key,source_ctm=im.ctm.tolist(),
        source_image_raw_sha256=hashlib.sha256(E.doc.stream_raw(im.ref)).hexdigest(),
        source_original_dimensions=[im.W,im.H],table_source_pixel_sha256=hashlib.sha256(raw[y0:y1,x0:x1].tobytes()).hexdigest(),
        vertical_grid_long_stroke_measurements=vgroups,horizontal_grid_long_stroke_measurements=hgroups,
        grid_threshold_RGB_mean190=True,grid_minimum_dark_support_fraction=.7,
        files=[dict(path=str(z),sha256=sha(z)) for z in [p,p2,forigin]]))
    print(family,'VERTICAL',[(g['start'],g['end_exclusive'],round(g['center_native'],5)) for g in vgroups],flush=True)
    print(family,'HORIZONTAL',[(g['start'],g['end_exclusive'],round(g['center_native'],5)) for g in hgroups],flush=True)
E.close()
AFTER = dict(source=sha(S.src(NAME)),current=sha(S.result(NAME)))
assert AFTER == BEFORE
out = dict(stage='READ-ONLY OWN-SA SOURCE AND LOCK EXTRACTION; NO PROPOSAL ACCEPTANCE',
    source_current_before=BEFORE,source_current_after=AFTER,source_current_unchanged=True,
    project_context=context,self_read_receipt=receipt,read_controls=[dict(path=str(PROJECT/p),sha256=sha(PROJECT/p)) for p in controls],
    original_G04_tasks_read_fully=group_tasks,original_G04_tasks_count=15,
    original_G04_prompt_path=r'C:\Users\H2\Desktop\Catalog Sua\GOI CHATGPT 02-10-2026\02_PROMPT_TUNG_NHOM\G04 - Perotac SA + Redpump SL.txt',
    original_tasks_json_path=str(Path(N['PKG'])/'tasks/tasks.json'),
    original_tasks_json_sha256=sha(Path(N['PKG'])/'tasks/tasks.json'),
    G04_prompt_or_task_explicit_3SS3_3SS4_rated_QH_locks_found=[],
    ROOT_message='ROOT has not confirmed any directly stated additional working point for 3SS3/3SS4; do not infer rated Q/H from code.',
    locked_source_extrema_for_each_row=True,all_source_Q_columns_locked=True,
    additional_working_points_status='CHUA THE XAC MINH - no independently confirmed additional rated/working QH lock in G04 prompt/tasks',
    explicit_ROOT_table_endpoint_locks=[dict(model='3SS3/37',Q_m3_h=3.6,H_m=54),dict(model='3SS4/20',Q_m3_h=5.4,H_m=25),dict(model='3SS4/28',Q_m3_h=5.4,H_m=36)],
    older_readonly161_node_plan=dict(path=str(old_plan),sha256=sha(old_plan)),
    source_tables=evidence,PDF_saved_count=0,table_changed=False,font_work_started=False,shared_ledger_changed=False,
    no_source_from_Redpump_CDX_or_system_font=True)
path = Path(fresh(WORK/'01 NGUON THAT KHOA VA LUOI BANG CHI DOC.json'))
path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('SOURCE PROBE',path,'SHA256',sha(path),flush=True)
