"""Hoàn thiện tài liệu do ROOT mới tạo; không đọc/ghi catalogue."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import uuid

ROOT = Path(r'D:\ChatGPT\Sửa catalogue').resolve()
TAG = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
DOCS = {
'knowledge/CACH_DA_NGHIEM_THU.md': '''# Những cách đã nghiệm thu — đúng phạm vi

Đọc biên nhận và mở bản thật trước tái sử dụng. Các ca dưới đây là kết quả trước hoặc tại mốc tạo kho ngày 03/10/2026. Kết quả một vùng không chứng toàn catalogue đã xong. Lệnh mới yêu cầu Q tăng/H giảm phải được kiểm thêm trên toàn đường; không đổi báo cáo lịch sử thành đã qua kiểm mới.

| Ca | Cách được chọn | Phạm vi có bằng chứng | Giới hạn phải giữ |
|---|---|---|---|
| WC, 3 thương hiệu | Dựng trơn toàn bộ 38 đường mỗi hãng; giữ khóa, số trung gian nguyên, trục riêng | 372 mốc/114 khóa/174 ô H thay, 43 hàng/108 ô trống; xem 8 trang và đọc PDF thật | Không chép tọa độ/màu/bảng sang hãng khác; 372 mốc không phải 372 mã |
| Perotac WC, ảnh 8 trang | Ảnh sản phẩm gốc + đường cắt 20 vòng/12 khe + nền sáng; CATFIX M1 | ROOT/G01 đọc 8 trang; hai công cụ kiểm ngoài vùng 200 dpi/ngưỡng 0/đệm 0 đều 0; giữ 38 đường, 11.070 chữ, ảnh/mặt nạ/ma trận/thông tin | 82 mốc không chứng mọi cấu tạo; quầng màu nguồn chưa phân biệt chắc; chẩn đoán ảnh RAM so bản thật còn lỗi được giữ |
| CDX trang 3 | Toàn bộ 4 đường/5 đoạn Bézier, 89 vạch lưới, 184 chữ + 4 cụm nguồn; CATFIX M1 | ROOT/đồ họa mở PDF thật; ngoài vùng 200 dpi/ngưỡng 0 = 0; 4 trang khác giữ | #118 trang 4/5 chưa xong; 2 điểm định mức đúng, 2 đường khác chỉ khớp ảnh nguồn; 14 chữ chưa chứng đủ cỡ ±2%; mép ảnh cụm chữ còn 69 điểm khác, tối đa 8 |
| GB | Chép nét chữ/đơn vị nguồn; tăng nét Tr2 đúng 0,2500008 pt; CATFIX M2 | 28 vùng ở 150/600 dpi, 329 kiểm, 214 đơn vị, 120 mốc có bảng/15 dòng; ngoài vùng ngưỡng 0 = 0 | M1 quá nhạt bị loại; 48 đường hai cấp thiếu bảng số; không tạo PDF thứ 3 cùng cách |
| Aquaris FS, ren G3 | Dùng UTMHelve nguồn cỡ 8 pt, thay đúng 2→3 | 8.750 chữ, giữ 8.749; 273 nét/5 đường/9 phông/7 ảnh và thông tin/vùng ngoài; ROOT xem 600 dpi | #137 đổi cửa xả 50→80 còn thiếu ký tự 8 đúng MyriadPro-Regular; không sửa solids Ø50 |
| Aquaris SP, G01+G02 | Chép chữ/viền nguồn, vẽ 21 biểu đồ theo bảng | G01 đã chốt; G02 có 21 biểu đồ/207 đường/1.219 mốc; đọc lại tệp hợp nhất | Dùng Giếng/G02 (gồm cả G01), không ghi lùi bằng bản G01 cũ; kiểm thêm quy tắc giảm theo lệnh mới |

Biên nhận bản chính:

- Perotac WC: `_BAO CAO/G08/PEROTAC WC ANH DU8 TRANG DA NGHIEM THU VA LUU BAN TRUOC/BIEN NHAN LUU BAN ANH DU8 TRANG.json`; mã `74044ef1f3a62804eaf2d41974365ee4af2c071f45218bc604e205f0e6c579ee`. Bản trước 5418… đã sao lưu.
- CDX trang 3: `_BAO CAO/G15/CDX TRANG3 M1 DA NGHIEM THU VA LUU BAN TRUOC/BIEN NHAN LUU CDX TRANG3 M1.json`; mã `194a943e106e7a71426464823231494a2331c16bd74a0c3654d77a9dc888241a`. Bản trước 887f… giữ.
- GB M2: `_BAO CAO/G10/GB M2 DA NGHIEM THU PDF THAT VA LUU BAN TRUOC/ROOT BIEN NHAN BAN GIAO GB M2.json`; mã `f8b8b6ec86876628a1ec5cc8e71224229c88abfcf8095e946cb1f2d62a330cc2`. Bản trước e592… giữ.
- FS G3: `_BAO CAO/G07/ROOT REN G3 DOC PDF THAT VA LUU BAN TRUOC`; mã `928bbda4fdd4aab698bfa49f2af6eb0b1c794f31e1b6b4d6348b956108e49a02`.

SA/SL/SP mới còn đang nghiên cứu trong bộ nhớ hoặc chưa đạt hình thức, không có trong bảng cách đã nghiệm thu. SL giữ 104 neo/26 dấu vết từ M1 không phải mới nghiệm thu toàn mực sau cắt. 13 cụm chữ SL có 5 cụm lẫn nét cũ; đã dừng, chưa PDF mẫu 2.
''',
'knowledge/LOI_VA_CACH_TRANH.md': '''# Lỗi thật và cách tránh

Đây là kiến thức, không phải danh sách chương trình được chạy lại. Tra chứng cứ trong archive/EVIDENCE_INDEX.json và sổ gốc. Giữ mẫu lỗi và phạm vi chưa kiểm; không sửa báo cáo cũ thành đạt.

| Lỗi/ngộ nhận | Cách xử lý cho phiên sau |
|---|---|
| S.src nhận chuỗi có thư mục nên không thấy tệp | Truyền basename, tức chỉ tên tệp; danh mục giữ thư mục và danh tính riêng |
| catwork.start đổi thư mục/sys.path khiến không nhập được helper | Giữ HERE là thư mục chương trình; phục hồi đường dẫn nhập hàm phụ, không sửa catfix |
| Khởi động môi trường được gọi là 43 kiểm | Chạy tests/run_tests.py thật. Nếu chỉ 41/43 thì chưa đạt; 4/4 môi trường không thay 43/43. Chưa tìm được báo cáo lịch sử 41/43 thì không dựng lại hai lỗi |
| Bản G01 cũ ghi lùi G02 | Dùng G02 (gồm cả G01) trong manifest và khóa mã bản hợp nhất |
| Chạy lại chương trình tiếp nhận đã xong | fresh/mã trước từ chối là đúng; không bỏ điều kiện chặn hoặc ghi lại chỉ để có báo cáo mới |
| Thiếu k/W/8/Ó đúng phông | Tìm cùng kiểu trong chính tệp. Không thu nhỏ K, đổi phông hoặc ghép chữ để đoán; ghi chưa thể |
| Chữ OCR ẩn bị coi là chữ đang thấy | Kiểm lớp/chương trình phông/nhiều chữ chung/độ rộng. Tr7 nghĩa là chữ không được vẽ ra |
| Hình chữ từ JPEG khớp diện tích nhưng trông viết tay | Xem toàn ký tự/cụm 600 dpi. Số 4 cong như 3, 5 u cục, 9 sai lòng/đáy đều không đạt; SP v24 chưa được xuất PDF |
| Lặp dựng chữ SL 5/2/9 nhiều phiên | V7 có 9 tốt hơn, 5/2 chưa đạt; V8–V10 bị loại. Không đổi tên để thử cùng cách vô hạn |
| Giữ cụm nguồn được coi mặc định sạch | SL /23,/11,/8,/5,/4 giữ cả nét đường chạm chữ; 13 đảo đã dừng, 8 cụm khác chưa chốt, chưa PDF 2 |
| Bỏ 2 điểm ảnh mép rồi gọi toàn chữ không đổi | Báo toàn mép và nội vùng riêng. SA còn quầng Hfeet200/US10/US30; phải xem đủ cụm |
| Chỉ kiểm nét S, bỏ hình tô f* | S vẽ viền, f* tô theo quy tắc chẵn/lẻ; kiểm cả hai. Hộp Eta/60 giao nhau không tự chứng biên chữ giao; dáng 60 vẫn có lỗi riêng |
| Hai hộp W* chồng nhau tạo lỗ | W* cắt theo chẵn/lẻ; hợp nhất hình học hoặc gộp thành một đảo đúng miền. Giữ byte ảnh/ma trận, kiểm ảnh thật |
| Nhầm PageImage.key và PageImage.index | key định danh trang, index là chỉ số lệnh Do. SL LAN2 có tài nguyên mà chữ không hiện; LAN2B sửa index mới thấy đủ 13 cụm |
| Nới hộp riêng thành quy tắc chung | Phân biệt hộp nguồn/hộp cắt. 0,48 pt của 4 vạch feet + đáy 0 SL không áp cho chữ hoặc catalogue khác |
| Tên ảnh KHONG DOI được dùng thay phép đo | Hộp tiêu đề SL nguồn có 0 điểm đổi, hộp đã nới có thay đổi ở lề. Ghi đúng hộp/đơn vị/mã và phép đo |
| Chỉ dùng độ dày/màu kế hoạch | Đọc lệnh thật và tiết diện mực; kiểm trong suốt, đầu/nối/nét đứt. GB M1 quá nhạt, M2 mới đạt |
| Đường η có quá nhiều đoạn/điểm uốn | Kiểm đạo hàm và hình. SL M1 có 117 đoạn/99 điểm uốn, chưa nhận bản chính |
| Khớp ảnh nguồn được nhận là dữ liệu hãng | Đầu nét quan sát và 6 đường SP thiếu bảng chỉ là chứng hình, không tự xác nhận Qmax/Hmax hãng |
| Gán mã theo thứ tự dòng hoặc cột áp gần nhất | CDX trang 4/5 chưa định danh đủ; 5 dòng/4 đường không tự thành 5 đường hoặc mã 185-B |
| Một hệ số cho cả trục ảnh quét | Đọc tâm vạch và đơn vị từng đoạn của chính biểu đồ; không chép từ hãng khác |
| Khớp bảng tăng ngược rồi gọi kỹ thuật đúng | Lệnh mới 03/10 yêu cầu Q tăng/H giảm từng mã. Sửa số trung gian nguyên + đường, giữ extrema/điểm làm việc. Hướng cũ giữ tăng nhẹ 6SL25 đã bị thay thế |
| H bằng nhau được tự động coi giảm | Kiểm đường thật và làm tròn. Không tự cho đạt hoặc phá giá trị max/min đã khóa |
| Đọc ô lẻ sai dòng/đảo y | Ảnh chứng phải có tên mã, đầu cột và tọa độ. ROOT đọc 4SL3/15 tại Q3 là 76, không phải 78; giữ ảnh sai làm cảnh báo |
| Biên sai số chạm ngưỡng bị gọi lỗi chắc | Ghi danh nghĩa và bất định; SL /16 chưa thể, /20 là phép đọc tác nhân còn chờ ROOT độc lập |
| Cộng mốc đo lại thành tiến độ mới | SA 231 là tập con 1.827; 82 mốc ảnh khác 230 lượt đặt; #132 G04/G05 chỉ đếm một việc |
| RAM và tệp thật khác vài điểm bị che đi | Giữ chẩn đoán lỗi Perotac WC trang 6–8; kiểm tệp thật/bảo toàn/hình thức riêng |
| PDFium làm tròn bitmap nhưng gắn vùng bằng dpi/72 | Dùng kích thước bitmap và khổ trang thực. Sửa phép đo, không nới vùng hoặc sửa PDF để cho qua |
| Parser trả record rỗng cuối | So toàn byte và lệnh có nghĩa; CDX trang 3 có 237 lệnh/238 record, không tự kết luận mất lệnh |
| Chứng cỡ ±2% khi chữ nguồn bị lưới che | 14 chữ CDX trang 3 chưa đủ nguồn để chứng toàn cỡ; 170 chữ sạch không thay giới hạn |
| AI tạo sai cấu tạo bơm | Dùng ảnh sản phẩm gốc + nền AI rỗng + đường cắt hình học; không tạo thêm bộ phận hoặc tẩy màu vật liệu chưa rõ |
| Dựng XLSX ngoài làm mất 3 ảnh | Đọc drawing/media/anchor. Ảnh bố cục từ XML không thay bản Excel/bản in thật |
| chart.xml có 9 series được coi hiển thị 9 đường | Đọc dữ liệu/bộ nhớ đệm/ô trống/quan hệ rồi xem thật; SS180 có x12/y2 chưa tự gọi lỗi |
| Min thiếu được ngầm đặt 0 | DWO còn chờ anh chốt min 0 tham khảo hoặc min thực. Phê duyệt cũ không trả lời câu hỏi mới |
| Office chặn, lặp Close/Raise/Enter không hiệu quả | Quyền anh đã đủ; công cụ/cửa sổ là giới hạn thật. Ngừng lặp, một AI điều khiển; bản in chưa thể |
| Hai AI cùng điều khiển desktop | Active request là công cụ đang bận, không chứng nút đã bấm. Điều phối tuần tự |
| With sqlite3.connect không đóng kết nối | Kiểm phối hợp đầu có 7 lỗi dọn kho tạm trên Windows. ClosingConnection đóng ở __exit__; chạy lại 8/8 đạt. Đây không phải kiểm catfix |
| FINAL hoặc báo cáo AI được coi đã nghiệm thu | Đúng mã tệp thật + người kiểm độc lập + số/đồ họa/bảo toàn/phạm vi. Tên tệp không có quyền ưu tiên |

Thông báo thật: FileExistsError là tệp đã tồn tại; INPUT_CHANGED là đầu vào đổi; Computer Use helper already has an active request là công cụ đang bận; failed to activate captured window là chưa đưa được cửa sổ lên. Không diễn giải thành thao tác thành công.

Thuật ngữ: RAM là bộ nhớ; glyph là hình ký tự; ROI là vùng kiểm/sửa; CTM là ma trận đặt ảnh; dpi là điểm ảnh mỗi inch; SHA-256 là mã kiểm nội dung; helper là hàm phụ; sourcefit là khớp ảnh nguồn; renderer là công cụ dựng ảnh từ tài liệu; series là một dãy dữ liệu biểu đồ; extrema là giá trị lớn/nhỏ nhất.

Không dùng ngưỡng lỏng/hộp lớn/bỏ mép để làm kết quả xanh. Hai mẫu PDF cùng cách không đạt thì dừng; giữ chứng cứ và lý do. Mã trong archive phải đọc trước nhập, vì có chương trình ghi ngay khi nhập mô-đun.
''',
'state/CURRENT_CHECKPOINT.md': '''# Mốc tiếp tục — 03/10/2026

Đây là bản bàn giao lúc tạo kho, **không phải sổ tiến độ thay thế**. Đọc sổ `C:\\Users\\H2\\Desktop\\Catalog Sua\\BẢN MỚI 03-10-2026 (ChatGPT)\\_BAO CAO\\TIEN DO.md`, khóa/phân công và tệp thật mới nhất. Mã hiện hành trong state/catalogues.json. Không dùng snapshot để ghi lùi bản mới.

## Yêu cầu mới nhất

Anh yêu cầu một mã bơm Q tăng/H giảm; thông tin sai phải sửa. Đã cập nhật rules/AGENTS/procedures. Rà các đoạn tăng hoặc bằng trong bảng và đường; giữ extrema và điểm làm việc đã khóa, số trung gian nguyên. Hồ sơ trước đây giữ nguồn tăng nhẹ chỉ chứng dữ liệu gốc, không là nghiệm thu theo lệnh mới. **Chưa sửa bảng/PDF các ca mới chỉ bằng việc cập nhật tài liệu.**

G18 đang kiểm 6SL25: 5 hàng /12,/14,/16,/18,/20 tăng 1 m ở Q0→3; 5 hàng đầu khác có đoạn bằng. Phương án số chưa phát hành; extrema bảng khác extrema vật lý chưa có nhãn riêng. G03 đang kiểm các đoạn bằng của SA p2/p3; 13 hàng/104 số p8 giảm là kiểm bảng, không thay kiểm toàn nét liên tục.

## Phần mở rộng đang làm

| Phạm vi | Trạng thái tại lúc bàn giao | Bước tiếp theo |
|---|---|---|
| Perotac WC ảnh cả 8 trang | M1 đã lưu 74044…; 38 đường trước đó đã đạt vẫn giữ | Đọc biên nhận G08, không chạy lại writer cũ 5418…; giữ chẩn đoán RAM khác tệp thật |
| CDX trang 3 | M1 đã lưu 194a…; hình thức đạt theo ảnh nguồn | Trang 4/5 của #118 còn thiếu; RAM 7/4 đường đang chuẩn bị, không thêm đường hoặc gán mã B |
| GB | M2 đã lưu f8b8…; 28 vùng chữ/nét đạt | 48 đường hai cấp thiếu bảng số; không PDF 3 cùng cách |
| FS | Ren G3 đã lưu 928b… | #137 cửa xả 50→80 còn thiếu 8 đúng phông; không sửa solids Ø50 |
| SA Perotac trang 8 | RAM V4 giữ Eta+60 trong một cụm nguồn nhưng nhiều chữ trục méo/dính; toàn phông CHƯA ĐẠT, 0 PDF | Đã dừng thử font; ba atlas đủ 62 cụm và bàn giao V4 khóa nguồn. Writer65 V2 không được dùng cho V4; quầng H200/US10/30 chưa chốt |
| SA ngoài trang 8 | 183 mã/1.827 mốc: 1.596 khớp kế thừa + 1 mới đạt + 4 chưa đạt + 226 chưa thể | 231 là tập con. Đọc báo cáo G01 V3; phương án trang 2/3 có 14 mã/161 ô mới chỉ đọc, chưa RAM/PDF; rà lại đoạn bằng theo lệnh mới |
| SL Redpump trang 8 | 13 cụm nguồn RAM LAN2B, 5 cụm /23,/11,/8,/5,/4 lẫn đường; đã dừng | 104 mốc/26 dấu vết giữ không thay hình thức; M1 cũ chưa nhận, PDF 2 chưa chạy |
| SL ngoài trang 8 | Bộ riêng 17 biểu đồ/196 mã/1.931 ô; ngoài p8 là 183 mã/1.827 ô | /20 Q27 sai theo tác nhân, ROOT chưa đọc độc lập; /16 chưa thể. Rà 6SL25 theo lệnh mới, không lấy giữ nguồn tăng làm chấp nhận |
| SP Perotac trang 5 | RAM v22/kiểm v23/chữ v24: 98 hình tô khớp nhưng ROOT/QA thấy số 4 và chữ trục sai dáng | Không PDF M1; giữ giới hạn hình thức và 6 đuôi đã chốt; đọc trang 7/11 với 314 ô nguồn, kiểm quy tắc giảm |
| DWO Excel | 7 mã có Qmax/Hmax, thiếu min/điểm định mức; khung/7 dãy chưa điểm đang chuẩn bị | Chờ anh chốt Qmin=Hmin=0 tham khảo hoặc cung cấp min thật; không tự đặt 0 |
| Excel Perotac | Có 9 dãy/57 giá trị H nguồn | Không thêm trùng; kiểm dữ liệu/ô trống/công thức/ảnh/quan hệ và đường thật. SS180 x12/y2 chưa chốt lỗi |
| Bản in Excel | #123 chưa thể, Office Activation Wizard vẫn chặn | Quyền đóng hộp đã có; Close/Raise/Enter thất bại, titlebar22 báo công cụ đang bận. Chỉ ROOT điều khiển; không cài/kích hoạt |

## Việc gốc — mốc đã báo trước tạo kho

162 mã: 149 CAN_SUA (cần sửa), 12 GIU_NGUYEN (giữ nguyên), 1 DA_XONG (#77 đã xong trong nguồn). #132 thuộc G04/G05 vẫn một mã. Mốc 135/149 là phạm vi ban đầu; **không phải 91% yêu cầu mở rộng đồ họa/Excel hoặc quy tắc kỹ thuật mới**. Đối chiếu sổ sau mốc này trước báo tỷ lệ.

| Nhóm | Mốc đã báo đạt | Phần gốc còn thiếu/giới hạn |
|---|---:|---|
| G01 | 19/19 | Tiếp tục trên bản hợp nhất G02 |
| G02 | 1/1 | 21 biểu đồ/207 đường/1.219 mốc; hợp nhất G01 |
| G03 | 14/15 | #34 thiếu k đúng kiểu; 414 mốc/69 đường không thay thiếu phông |
| G04 | 14/14 | Đồ họa SA/SL mở rộng chưa xong |
| G05 | 6/6 | SP mở rộng chưa đạt/chưa thể; #132 không cộng lại |
| G06 | 1/3 | #52 thiếu k đậm; #53 giữ nguồn sau kết luận cách lỗi |
| G07 | 4/5 | #137 thiếu 8 đúng phông |
| G08 | 12/12 | 3 WC, mỗi bộ 38 đường; ảnh Perotac 8 trang đã lưu; giữ giới hạn chẩn đoán |
| G09 | 6/6 | 124 đường/372 mốc có bảng; H tại Qmax/toàn dãy thiếu còn chưa thể |
| G10 | 6/6 | GB M2 đã lưu; 48 đường hai cấp thiếu số |
| G11 | 11/11 | 3 ô nguồn mâu thuẫn giữ theo quyết định cũ; rà lại nếu thuộc Q–H. 50 đường độ ồn thiếu bảng dB |
| G12 | 0/3 | 24 phần chữ/10 đường đạt; thiếu Ó/nháy đậm nghiêng/W đứng |
| G13 | 5/8 | #110/#155/#154 thiếu phông nguồn |
| G14 | 7/8 | #128 thiếu 4W nghiêng; 4kW đứng bổ sung đạt; #129 chỉ đổi tên bản ra |
| G15 | 7/8 | #118 trang 4/5 thiếu định danh/toàn Q–H; không tính trang 3 thành toàn việc xong |
| G16 | 9/10 | #101 thiếu 8 rotatedF; 262 đường/2.106 mốc có giới hạn nguồn |
| G17 | 3/3 | 8W bổ sung thiếu phông không tính đạt |
| G18 | 11/12 | #123 bản in thật chưa thể; biểu đồ Excel mới tách phạm vi |

## Phối hợp

Người điều phối: ChatGPT ROOT, duy nhất ghi sổ và nhận bản chính. state/active_assignments.json là ảnh chụp vai trò, không chứng tác nhân đang chạy hoặc đã đọc kho. Khóa sống xem bằng status; nếu chưa nhập khóa mới phải kiểm tác nhân cũ trước nhận tệp.

Claude chưa được xác minh đã đọc/áp dụng kho. Hai AI dùng chung START_HERE/AGENTS/CLAUDE và công cụ nhưng tự đọc, tự xác nhận; không chép báo cáo AI khác thành nghiệm thu độc lập.
''',
'knowledge/THAY_DOI_QUY_TAC_20261003.md': '''# Quyết định mới và phần bị thay thế

Ngày 03/10/2026, anh Trung trực tiếp yêu cầu: một mã bơm, lưu lượng tăng thì cột áp phải giảm, thông tin sai cần sửa.

- Áp dụng quy tắc Q–H trong rules/QUY_TAC_ANH_TRUNG.md, AGENTS.md và procedures/DUONG_DAC_TINH.md.
- Không còn dùng “giữ tăng nhẹ theo nguồn” làm điều kiện phát hành. Giữ bằng chứng gốc; đánh dấu tăng/bằng cần rà và sửa số trung gian nguyên cùng đường.
- Giữ extrema và điểm làm việc anh đã khóa; dữ liệu thiếu vẫn chưa thể, đặc biệt min DWO. Các khóa mâu thuẫn phải chỉ rõ, không tự thay.
- Không áp H giảm cho η, công suất hoặc độ ồn.
- Các kết quả lịch sử khớp số nguồn chỉ có phạm vi lịch sử đó. Chưa qua kiểm bổ sung thì không nhận đã đạt quy tắc mới.
- Số 6SL25 tăng/bằng và SA trang 2/3 bằng đang được rà bằng dữ liệu thật; chưa sửa catalogue bằng việc viết tài liệu này.

Phiên mới đọc mục này trước tái dùng báo cáo cũ. Khi có quyết định mới của anh, cập nhật nguồn chung, lưu lịch sử và khóa phiên bản mới; không xóa lời chứng cũ hoặc ghi thay Claude đã đọc.
'''
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    history = ROOT / 'history' / ('docs-before-polish-' + TAG)
    history.mkdir(exist_ok=False)
    records = []
    for relative, body in DOCS.items():
        target = (ROOT / relative).resolve()
        assert target.is_relative_to(ROOT) and target.suffix == '.md'
        old = target.read_bytes() if target.exists() else None
        if old is not None:
            backup = history / relative
            backup.parent.mkdir(parents=True, exist_ok=True)
            with backup.open('xb') as output:
                output.write(old)
            assert backup.read_bytes() == old
        data = body.encode('utf8')
        temporary = target.with_name(target.name + '.' + uuid.uuid4().hex + '.new')
        with temporary.open('xb') as output:
            output.write(data)
        os.replace(temporary, target)
        assert target.read_bytes() == data
        records.append({'file': relative, 'before_sha256': sha(old) if old else None, 'after_sha256': sha(data)})
    receipt = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'files': records,
               'catalogues_not_read_or_modified': True, 'source_originals_not_touched': True}
    with (history / 'receipt.json').open('x', encoding='utf8') as output:
        json.dump(receipt, output, ensure_ascii=False, indent=2)
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
