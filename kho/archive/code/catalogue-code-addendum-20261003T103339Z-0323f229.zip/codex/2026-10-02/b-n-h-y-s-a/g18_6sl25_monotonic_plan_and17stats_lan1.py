"""Plan only: 10 integer-decreasing SL6SL25 rows + source-data scan, no catalogue writes."""
from pathlib import Path
from datetime import datetime
from collections import Counter
import hashlib, json

sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p: json.loads(Path(p).read_text(encoding='utf8'))
out=Path(r'D:\ChatGPT\Sửa catalogue\work\g18_project_qa\6SL25_DON_DIEU_DOC_NGUON_LAN1')
readp=out/'DOC NGUON VA TOA DO CHUA CHOT.json'
read=load(readp)
audit=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 03-10-2026 (ChatGPT)\_BAO CAO\G04\KIEM TOAN REDPUMP TOAN BO')
mp=audit/'DANH MUC BANG NGUON 196 DONG V2.json'
cp=audit/'1931 O NGUON DINH VI VA DOI CHIEU V2.json'
m,c=load(mp),load(cp)
before=[sha(read['source']),sha(read['current'])]
assert before==[read['source_SHA256'],read['current_SHA256']]
assert before==[m['source_SHA256'],m['current_SHA256']]==[c['source_SHA256'],c['current_SHA256']]
assert sha(readp)=='a11e3a15a3adcf6a593790cd6645cd2e6e47a4dc0996d880c96c95f0da82b820'
for z in read['evidence']: assert sha(z['path'])==z['SHA256']

# Fresh manual transcript from the actual full source table rendered above;
# no stage ratios, OCR, Perotac tables or curve target values entered it.
Q=[0,3,6,9,12,15,18,21,24,27,30,33]
manual={
 '6SL25/3':[45,45,45,44,42,40,38,33,28,22,16,9],
 '6SL25/4':[60,60,60,58,56,54,50,45,39,30,21,12],
 '6SL25/6':[90,90,89,88,85,81,76,66,58,45,32,18],
 '6SL25/8':[120,120,119,117,113,108,101,89,78,60,43,24],
 '6SL25/10':[150,150,149,146,141,135,126,111,97,75,55,30],
 '6SL25/12':[179,180,179,175,169,162,151,134,117,90,65,36],
 '6SL25/14':[209,210,209,204,197,189,176,156,136,105,76,42],
 '6SL25/16':[239,240,238,234,226,216,202,178,156,120,87,48],
 '6SL25/18':[269,270,268,263,254,243,227,201,176,135,98,54],
 '6SL25/20':[299,300,298,292,282,270,252,223,195,150,109,60]
}
cellmap={(z['model'],z['Q']):z for z in c['cells']}
assert len(cellmap)==1931
proposals=[]
for model,H in manual.items():
    row=next(z for z in m['rows'] if z['model']==model)
    assert row['Q']==Q and row['H']==H
    cells=[cellmap[(model,q)] for q in Q]
    assert [z['H_source'] for z in cells]==H
    M,minimum=max(H),min(H)
    # For these ten source rows only, with no extra fixed rated point on this page:
    # preserve max/min values, put max at first Q, and keep/lower later integers
    # only when necessary for strict adjacent decrease.
    candidate=[M]
    for value in H[1:]: candidate.append(min(value,candidate[-1]-1))
    assert all(type(z) is int for z in candidate)
    assert all(a>b for a,b in zip(candidate,candidate[1:]))
    assert max(candidate)==M and min(candidate)==minimum and candidate[-1]==H[-1]
    assert M-minimum>=len(Q)-1
    changes=[]
    for q,h,hnew,cell in zip(Q,H,candidate,cells):
        if h!=hnew:
            changes.append(dict(Q=q,H_source=h,H_proposed=hnew,delta_m=hnew-h,
                source_page=10,page_rect=cell['page_rect'],
                native_box_TOP_LEFT=next((z['native_box_TOP_LEFT'] for r in read['rows_pending_direct_visual_read'] if r['model']==model for z in r['selected_source_cells'] if z['Q']==q),None),
                cell_provenance=str(cp),cell_source_SHA256=before[0]))
    proof=next(z for z in read['rows_pending_direct_visual_read'] if z['model']==model)
    proposals.append(dict(model=model,single_phase_alias=f'6SLM25/{model.split("/")[1]}' if model in ['6SL25/3','6SL25/4','6SL25/6'] else None,
        Q_m3h=Q,H_source_read_direct=H,H_integer_proposed=candidate,
        source_table_max_value=M,source_table_max_Q=[q for q,h in zip(Q,H) if h==M],
        source_table_min_value=minimum,source_table_min_Q=[q for q,h in zip(Q,H) if h==minimum],
        physical_Hmax_status='CHƯA THỂ: trang10 không có nhãn Hmax riêng; Hmax bảng không tự chứng cực đại vật lý.',
        proposed_max_Q=0,proposed_min_Q=33,
        changed_cells=changes,changed_count=len(changes),preserved_source_cells=12-len(changes),
        preserved_extrema_values=True,preserved_Q_columns=True,preserved_Q33_and_H_at_Q33=True,
        known_prior_points_Q27_preserved=(candidate[9]==H[9]),
        explicit_rated_point_on_original_page_found=False,
        nominal_model_capacity_is_not_a_locked_QH_working_point='25 là ký hiệu lưu lượng trong tên; nguồn không có cặp Q25/H riêng được đánh dấu điểm làm việc.',
        external_locks_status='Không có điểm rated6SL25 riêng trong hồ sơ được giao. ROOT phải ghép khóa ngoài nếu có; xung đột thì dừng, không tự phá khóa.',
        source_row_photo=proof['row_photo'], all_source_cells=cells,
        proposal_status='ỨNG VIÊN SỐ NGUYÊN THEO QUY TẮC MỚI; chưa sửa tệp, chưa mẫu trước/sau, chưa nghiệm thu đường.'))
assert sum(z['changed_count'] for z in proposals)==26

groups={}; badpairs=[]
for row in m['rows']:
    key=(row['page'],row['family'])
    g=groups.setdefault(key,dict(page=row['page'],family=row['family'],model_rows=0,H_cells=0,adjacent_pairs=0,increasing_pairs=0,equal_pairs=0,decreasing_pairs=0,affected_models=set()))
    g['model_rows']+=1;g['H_cells']+=len(row['H']);g['adjacent_pairs']+=len(row['H'])-1
    for idx,(h0,h1) in enumerate(zip(row['H'],row['H'][1:])):
        q0,q1=row['Q'][idx:idx+2]
        assert cellmap[(row['model'],q0)]['H_source']==h0 and cellmap[(row['model'],q1)]['H_source']==h1
        kind='TĂNG' if h1>h0 else 'BẰNG' if h1==h0 else 'GIẢM'
        g['increasing_pairs']+=kind=='TĂNG';g['equal_pairs']+=kind=='BẰNG';g['decreasing_pairs']+=kind=='GIẢM'
        if kind!='GIẢM':
            g['affected_models'].add(row['model'])
            badpairs.append(dict(pair_id=f'{row["model"]}|{q0}|{q1}',page=row['page'],family=row['family'],model=row['model'],
                Q0=q0,H0=h0,Q1=q1,H1=h1,delta_H=h1-h0,type=kind,
                cell0=cellmap[(row['model'],q0)],cell1=cellmap[(row['model'],q1)],
                table_photo=row['table_photo'],table_photo_SHA256=sha(row['table_photo']),
                source_SHA256=before[0],scope='Đếm cặp trên bảng nguồn đã khóa có tọa độ. Ngoài6SL25 chưa đọc lại từng ảnh trong lượt này; không phải nghiệm thu vật lý/đường mới.'))
for g in groups.values():g['affected_models']=sorted(g['affected_models']);g['affected_model_count']=len(g['affected_models'])
assert len(groups)==17 and len(m['rows'])==196 and sum(len(r['H']) for r in m['rows'])==1931
assert len(badpairs)==33 and len({z['pair_id'] for z in badpairs})==33
totals={k:sum(g[k] for g in groups.values()) for k in ['model_rows','H_cells','adjacent_pairs','increasing_pairs','equal_pairs','decreasing_pairs']}
totals['affected_model_count']=len({z['model'] for z in badpairs})
totals['distinct_cells_in_non_decreasing_pairs']=len({(z['model'],z[k]) for z in badpairs for k in ['Q0','Q1']})
assert totals['increasing_pairs']==5 and totals['equal_pairs']==28 and totals['adjacent_pairs']==1735
assert totals['decreasing_pairs']==1702

record=dict(time=datetime.now().astimezone().isoformat(),source=read['source'],source_SHA256=before[0],current=read['current'],current_SHA256=before[1],
    authority='ROOT chuyển yêu cầu mới của anh: Q tăng thì H giảm; giữ giá trị max/min, chưa khóa vị trí ô trung gian sai; lập phương án toàn10hàng, không ghi catalogue.',
    interpretation='Giảm nghiêm ngặt ở các cột Q tăng với H số nguyên, không chấp nhận bằng trong phương án mới.',
    source_read_scope='Đã soi nguyên trang10, bảng đủ10hàng/120ô với đầu cột và tên hàng, đường6SL25 nguồn150/600. Transcript mới khớp120ô nguồn trước; số được đọc đúng không tự chứng thông tin đúng vật lý.',
    source_table_value_acceptance_vs_physical='Cực trị số IN TRONG BẢNG đã đọc. Hmax/Hmin vật lý và dữ liệu hãng sửa chưa có chứng riêng; đây là ứng viên thiết kế theo quyết định.',
    individual_source_coordinates=read['rows_pending_direct_visual_read'],
    proposals=proposals,proposed_changed_H_cells=26,unchanged_H_source_cells=94,proposed_adjacent_strict_decrease_checks=110,
    numerical_plan_checked_only=True,source_curve_new_acceptance=False,
    physical_ink_resolution_note=dict(native_pixel_pt=read['source_axis_record']['native_pixel_pt'],
        native_H_resolution_m=read['source_axis_record']['H_native_resolution_m'],
        observation='Một pixel nguồn xấp xỉ1,12m theo trục nguồn; mực/bề rộng/nét đứt làm bất định lớn hơn. 600dpi không phân biệt chắc179/180. Q0 sát khung và Q3 nhiều nét đứt thiếu mực; không ngoại suy để khẳng định Hmax.'),
    fixed_point_feasibility_rule='Với H nguyên giảm nghiêm ngặt: mọi hai khóa ở chỉ số i<j cần Hi-Hj>=j-i; max-min>=n-1. Nguồn5cặp tăng mâu thuẫn nếu khóa nguyên cảvịtrí cũ. ROOT đã cho giữ giá trị extrema và dời max vềQ0. /12,/14 giữ thêmQ6=179/209 sẽ mâu thuẫn với max180/210 vì chỉ có1m cho2bước; ứng viên hạQ6 thành178/208.',
    endpoint_limits='Giữ Q33 và H bảng tạiQ33. Q33 là cột cuối bảng, chưa tự coi là lưu lượng vật lý cực đại hoặc H=0. Trục vạch phụQ33 chưa khóa; không dùng fit toàn trục ngoại suy. Chưa vẽcurve.',
    remaining_gates=['ROOT kiểm độc lập120 số nguồn/26 ô đề xuất và ghép mọi khóa điểm làm việc có nguồn.',
        'Khóa đúng vạch địa phương đếnQ33, nhãn/chữ/nét/nhịp vàη riêng6SL25; không dùng dữ liệu trang8 hoặcPerotac.',
        'Chuẩn bị mẫu số/đường trước-sau trong hồ sơ mới bằngcatfix theo quyền tiếp theo; kiểm đường thật và hình thức riêng.',
        'Không gọi110 cặp ứng viên là110 mốc đường mới đạt hoặc cộng vào tiến độ149 việc.'],
    source_scan_17_tables=dict(scope='Tái dùng1931dữliệu có chứngtọađộ cùngSHA; thống kê từngcặp liền kề một lần, không renderlặp/không cộng nghiệmthu.',
        totals=totals,groups=list(groups.values()),non_decreasing_pairs=badpairs,
        source_model_table_manifest=dict(path=str(mp),SHA256=sha(mp)),source_cell_map=dict(path=str(cp),SHA256=sha(cp)),
        outside6SL25_increasing_pairs=0,outside6SL25_equal_pairs=21),
    source_read_evidence=dict(path=str(readp),SHA256=sha(readp),pictures=read['evidence']),
    catalogue_PDF_created=False,table_artifact_created=False,canonical_written=False,source_written=False,ledger_written=False,principal_rules_written=False,
    status='PHƯƠNG ÁN SỐ NGUYÊN ĐÃ KIỂM TOÁN 110 CẶP; chưa duyệt số/hình thức hoặc lưu bảng/đường.')
def write_fresh(p,text):
    with Path(p).open('x',encoding='utf8',newline='\n') as stream:stream.write(text)
    assert Path(p).read_text(encoding='utf8')==text
data=out/'PHUONG AN NGUYEN10 HANG VA QUET17 BANG THEO QUY TAC MOI.json'
write_fresh(data,json.dumps(record,ensure_ascii=False,indent=2)+'\n')
lines=['# 6SL25 – nguồn thật và phương án giảm số nguyên theo quy tắc mới','',
 '**Mười hàng có ứng viên số nguyên giảm nghiêm ngặt, giữ giá trị cực đại/cực tiểu đọc trong bảng. Tệp chưa sửa; chưa có PDF hoặc bảng mẫu.** Năm giá trị cực đại in là 180/210/240/270/300 m tại Q=3. Các giá trị 179/209/239/269/299 m là H tại Q=0. Trang không ghi Hmax vật lý riêng.', '',
 'Q là lưu lượng (m³/h), H là cột áp (m). Đã đọc trực tiếp đủ 120 ô ở trang 10 với tên hàng và đầu cột. Không dùng tỉ lệ tầng, chữ nhận dạng tự động hoặc số hãng khác. Quy tắc mới do anh giao thay cho câu “giữ tăng nhẹ đúng nguồn” trong phiếu cũ. Một ô đọc đúng và giữ nguyên nguồn chưa chứng thông tin vật lý đúng.', '',
 '## 1. Cực trị nguồn và các thay đổi đề xuất','',
 '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
 '|---|---|---|---|---|---|---|---|']
for z in proposals:
    short=z['model'].split('/')[1];chg='; '.join(f'Q{r["Q"]}: {r["H_source"]}→{r["H_proposed"]}' for r in z['changed_cells'])
    old=f'Q0={z["H_source_read_direct"][0]}, Q3={z["H_source_read_direct"][1]}; max={z["source_table_max_value"]} ở Q'+','.join(str(q) for q in z['source_table_max_Q'])+f'; min={z["source_table_min_value"]} ở Q33'
    lines.append(f'| Đơn điệu/{short} | Redpump SL | 10 | {old} | {chg} | Chỉ lập phương án; max về Q0, số nguyên giảm | {z["changed_count"]} ô ứng viên; kiểm toán 12 cột/11 cặp, chưa tệp/mẫu | [Hàng nguồn](<{z["source_row_photo"]["path"].replace(chr(92),"/")}>); tọa độ trong JSON |')
lines+=['', 'Q của cả 10 hàng: `0,3,6,9,12,15,18,21,24,27,30,33`.', '',
 'Dãy H ứng viên theo đúng 12 cột, chỉ là phương án chưa áp dụng:', '']
for z in proposals:lines.append(f'- {z["model"]}: `{", ".join(str(h) for h in z["H_integer_proposed"])}`.')
lines+=['', 'Tổng 26 ô đề xuất thay, 94 ô giữ. Đã kiểm cả 110 cặp giảm và 120 số nguyên; mỗi hàng giữ nguyên giá trị max/min, Q33 và H tại Q33. Các số Q27 của /16=120 và /20=150 vẫn giữ; phép đo mực Q27 cũ chưa là chứng toàn đường hoặc giá trị Hmax.', '',
 '## 2. Vì sao không chọn 179 hoặc tự suy điểm làm việc','',
 '179 là H in tại Q0 của /12; 180 là số lớn nhất in ở Q3. Tương tự 209/210, 239/240, 269/270, 299/300. Trang 10 không có nhãn Hmax riêng, không có chấm/ghi rõ cặp điểm làm việc của 6SL25. Ký hiệu 25 trong model (mã bơm) biểu thị lưu lượng danh nghĩa, không tự tạo cặp Q25/H đã khóa. Các hàng /3,/4,/6 có tên một pha 6SLM25/... trong cùng hàng; dùng chung ô H nên không đếm thành model mới.', '',
 'Đã xem nét đầu biểu đồ nguồn thật ở 150/600 dpi (số điểm ảnh trên một inch). Một pixel nguồn tương đương khoảng 1,12 m theo trục; mực và nét đứt thêm bất định. Đầu Q0 sát khung, nhiều Q3 thiếu mực. Vì vậy ảnh chưa chốt chắc 179 hay 180 là Hmax vật lý. Phương án giữ 180 vì đây là GIÁ TRỊ CỰC ĐẠI BẢNG đã đọc và ROOT cho đưa về Q0; chưa nhận là số thử nghiệm hãng.', '',
 '## 3. Các khóa và điều kiện dừng','',
 'Với số nguyên giảm nghiêm ngặt, hai khóa ở chỉ số i<j phải thỏa `Hi-Hj >= j-i`; đồng thời `max-min >= n-1`. Giữ mọi ô nguồn trong năm cặp tăng là vô nghiệm. ROOT đã xác nhận chỉ khóa GIÁ TRỊ max/min, chưa khóa vị trí các ô trung gian sai, nên max có thể chuyển về Q0.', '',
 '/12: giữ max=180 ở Q0 và giữ Q6=179 thì không còn số nguyên cho Q3 giữa 180 và 179. /14 tương tự 210/209. Ứng viên hạ Q6 thành 178/208. Các /16,/18,/20 chỉ cần đổi hai ô đầu. Phải ghép mọi điểm làm việc ngoài hồ sơ này nếu ROOT có; khóa mâu thuẫn thì dừng, không tự bỏ khóa.', '',
 'Q33 chỉ là cột cuối bảng. Giữ H ở Q33 và không gán H=0 hoặc lưu lượng tối đa vật lý. Vạch địa phương Q33 chưa đủ khóa trong hồ sơ trục trước; chưa dùng hệ số khớp toàn trục để ngoại suy khi vẽ. Đường η (hiệu suất) của 6SL25 không có bảng; không dùng 551 tâm mực nguồn của trang 8.', '',
 '## 4. Quét 17 bảng nguồn, không cộng trùng','',
 f'Tái dùng hồ sơ nguồn có tọa độ cùng mã kiểm: 17 bảng/196 hàng/1.931 ô, 1.735 cặp liền kề. Có 5 cặp TĂNG và 28 cặp BẰNG; 1.702 cặp GIẢM. {totals["affected_model_count"]} hàng có ít nhất một cặp không giảm; {totals["distinct_cells_in_non_decreasing_pairs"]} ô riêng nằm trong 33 cặp đó. Đây là thống kê nội dung bảng, chưa là nghiệm thu đường hoặc phần trăm mới.', '',
 '| Trang | Họ model | Hàng/ô | Cặp tăng | Cặp bằng | Hàng bị ảnh hưởng |',
 '|---|---|---|---|---|---|']
for g in groups.values():lines.append(f'|{g["page"]}|{g["family"]}|{g["model_rows"]}/{g["H_cells"]}|{g["increasing_pairs"]}|{g["equal_pairs"]}|{g["affected_model_count"]}|')
lines+=['', 'Cả 5 cặp TĂNG nằm ở 6SL25. Bảy cặp BẰNG cũng nằm ở 6SL25; 21 cặp BẰNG ngoài 6SL25 thuộc 3SL2,3SL3,3SL4,4SL2,4SL10. Tệp JSON (dữ liệu có cấu trúc) ghi từng model/Q/H và tọa độ hai ô, không suy qua Perotac. Ngoài 6SL25 chỉ quét lại dữ liệu đã đọc có bằng chứng cũ, chưa soi lại toàn ảnh trong lượt này và chưa đề xuất số sửa.', '',
 '## 5. Phương án có thể tái dùng, chưa phải chương trình sửa tự động','',
 '1. Khóa mã kiểm/tên model/tên cùng hàng/đơn vị và vị trí từng ô nguồn. Phân biệt max/min bảng, cực đại vật lý, điểm đã khóa và ô sai được đổi.',
 '2. Đọc toàn hàng, xét mọi cặp liền kề. Quy tắc mới loại cả TĂNG/BẰNG ở dãy số nguyên ứng viên; số bất thường nguồn là dữ liệu cần xử lý, không là quyền bỏ qua.',
 '3. Ghép khóa và kiểm tính khả thi số nguyên trước. Với 10 hàng này, đặt H0=max nguồn; ô sau giữ nếu nhỏ hơn ô trước, nếu không thì giảm xuống ô trước-1. Kiểm lại cực trị, cột cuối và khóa; khóa nào sai thì dừng thay vì tự đổi.',
 '4. Gửi ROOT số/tọa độ và chuẩn bị mẫu trước/sau theo quyền tiếp theo. Đường mượt phải qua bộ điểm mới đã chốt; số nguồn đọc đúng chưa tự thành tiêu chuẩn vật lý.',
 '5. Kiểm PDF thật: bảng đọc đúng/số nguyên; đường giảm cả đoạn giữa các mốc; đầu-cuối/vạch địa phương; cùng chữ/nét/màu/độ rõ; ngoài vùng/ảnh/phông/thông tin tài liệu. Kiểm từng phần riêng. 0 điểm ảnh ngoài không thay cho kiểm phông/đồ họa; 110 cặp của phương án chưa là 110 mốc đường mới ĐẠT.', '',
 '## 6. Tệp và mã kiểm','',
 f'- Nguồn PDF: `{read["source"]}`; SHA-256 `{before[0]}`.',
 f'- Bản giao chỉ đọc: `{read["current"]}`; SHA-256 `{before[1]}`.',
 f'- Ảnh nguồn/tọa độ mới: `{readp}`; SHA-256 `{sha(readp)}`.',
 f'- Phương án/từng cặp/tọa độ: `{data}`; SHA-256 `{sha(data)}`.',
 f'- Danh mục 196 dòng: `{mp}`; SHA-256 `{sha(mp)}`.',
 f'- Tọa độ 1.931 ô: `{cp}`; SHA-256 `{sha(cp)}`.',
 '', 'SHA-256 là mã kiểm nguyên vẹn của tệp. Các ảnh nguồn có mã trong JSON; tọa độ PDF dùng điểm với gốc dưới-trái, hộp pixel nguồn tính lại với gốc trên-trái, không lặp hộp đảo y. Giữ toàn mép và đầu cột/tên hàng khi soi.', '',
 'Không ghi nguồn/bản giao/PDF M1/PDF2, không tạo bảng mẫu, không sửa TIEN DO hoặc quy tắc chính. Không chạy health (kiểm kho) lúc ROOT chưa niêm phong; không tự tạo manifest (danh mục cấu hình). Phiếu QA trước giữ làm lịch sử; câu giữ tăng nhẹ nguồn trong phiếu đó đã bị quy tắc mới thay.', '']
report=out/'BAO CAO8 COT6SL25 QUY TAC MOI VA BAI HOC BO SUNG.md'
write_fresh(report,'\n'.join(lines))
assert before==[sha(read['source']),sha(read['current'])]
print(json.dumps(dict(report=str(report),report_SHA256=sha(report),data=str(data),data_SHA256=sha(data),
    source_SHA256=before[0],current_SHA256=before[1],proposed_changed_H_cells=26,strict_adjacent_checks=110,
    scan17_totals=totals,per_group_non_decreasing=[dict(page=g['page'],family=g['family'],increasing=g['increasing_pairs'],equal=g['equal_pairs'],models=g['affected_models']) for g in groups.values() if g['increasing_pairs'] or g['equal_pairs']]),ensure_ascii=False),flush=True)
