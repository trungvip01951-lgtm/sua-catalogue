"""Pure math only. No catalogue numbers, imports with effects, or PDF writes."""

def locked_interval_feasibility(n, locks):
    ordered = sorted((int(i), int(h)) for i, h in locks.items())
    result = []
    for (a, ha), (b, hb) in zip(ordered, ordered[1:]):
        needed = b-a
        available = ha-hb
        result.append(dict(left_index=a,right_index=b,left_H=ha,right_H=hb,
            minimum_integer_drop_required=needed,locked_H_drop_available=available,
            integer_values_available_inclusive=available+1,
            positions_needed_inclusive=needed+1,
            sufficient_strictly_descending_integer_space=available>=needed))
    return result


def solve_integer_descending(source, locks):
    """Minimize maximum absolute edit, then L1, edits, square error, path.

    Iterate maximum-deviation bounds instead of pruning on a prefix maximum:
    future deviations can otherwise incorrectly reverse that comparison.
    All numbers are integers; locks are exact, never softened or inferred.
    """
    h = [int(v) for v in source]
    n = len(h)
    fixed = {int(i):int(v) for i,v in locks.items()}
    intervals = locked_interval_feasibility(n,fixed)
    conflicts = [r for r in intervals if not r['sufficient_strictly_descending_integer_space']]
    if conflicts:
        return dict(feasible=False,conflicting_locks=conflicts,locked_interval_checks=intervals)
    lo, hi = min(h), max(h)
    attempts = []
    for bound in range(hi-lo+1):
        states = {}
        for i, old in enumerate(h):
            candidates = [fixed[i]] if i in fixed else range(max(lo,old-bound),min(hi,old+bound)+1)
            new = {}
            for v in candidates:
                if not lo<=v<=hi or abs(v-old)>bound:
                    continue
                delta = abs(v-old)
                if i == 0:
                    new[v]=(delta,int(delta>0),delta*delta,(v,))
                    continue
                for previous, cost in states.items():
                    if previous <= v:
                        continue
                    option=(cost[0]+delta,cost[1]+int(delta>0),cost[2]+delta*delta,cost[3]+(v,))
                    if v not in new or option<new[v]:
                        new[v]=option
            states=new
            if not states:
                break
        attempts.append(dict(maximum_absolute_change_m=bound,feasible=bool(states),
            reached_positions=i+1,final_state_count=len(states)))
        if states:
            best=min(states.values())
            path=list(best[3])
            assert all(path[j-1]>path[j] for j in range(1,n))
            assert all(path[j]==v for j,v in fixed.items())
            assert min(path)==lo and max(path)==hi
            return dict(feasible=True,H_proposed=path,
                minimal_maximum_absolute_change_m=bound,total_absolute_change_m=best[0],
                changed_cell_count=best[1],sum_squared_change_m2=best[2],
                lower_deviation_bound_attempts=attempts,
                objective=['maximum absolute change','total absolute change','number of changed cells','squared change','integer path'],
                locked_interval_checks=intervals,conflicting_locks=[])
    return dict(feasible=False,conflicting_locks=conflicts,locked_interval_checks=intervals,
        lower_deviation_bound_attempts=attempts)
