"""Hợp đường ngoài rồi bỏ nền lỗ chân; dữ liệu V2, không RGB/PDF sản phẩm."""
from pathlib import Path
import json,hashlib
import cv2,numpy as np
from PIL import Image

HERE=Path(__file__).parent
OLD=HERE/'DU LIEU DUONG CAT NGUON V1'/'BA NHOM DUONG CAT PDF TU PIXEL NGUON V1.json'
OUT=HERE/'DU LIEU DUONG CAT NGUON V2 CHOT PHEP HOP'
assert not OUT.exists();OUT.mkdir()
data=json.loads(OLD.read_text(encoding='utf-8'))
def area(p):
    p=np.asarray(p,float);return float(np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])/2)
def make_contour(points,role):
    p=np.asarray(points,float)
    if (area(p)>0)!=(role=='outer'):p=p[::-1]
    p=np.round(p,3)
    return {'role':role,'points_source_pixel':p.tolist(),'commands_pixel':[['M',*p[0].tolist()]]+[['L',*v.tolist()] for v in p[1:]]+[['Z']],'signed_area_source_pixel2':area(p),'bbox_source_pixel':[float(p[:,0].min()),float(p[:,1].min()),float(p[:,0].max()),float(p[:,1].max())]}
reports=[]
for g in data['groups']:
    w,h=g['source_canvas_pixel'];outside=np.zeros((h,w),np.uint8);holes=np.zeros_like(outside)
    for p in g['subpaths']:
        z=np.zeros_like(outside)
        # Giữ nguyên các mốc nguồn thủ công; đây chỉ là hợp miền hình học ở lưới nguồn.
        pts=np.rint(np.asarray(p['points_source_pixel'])).astype(np.int32)
        cv2.fillPoly(z,[pts],1)
        if p['role']=='outer':outside|=z
        else:holes|=z
    final=outside & (1-holes)
    # Khi một cửa đã nằm ngoài biên thân, không thêm vòng âm riêng ở nền: W nonzero sẽ giữ nhầm nền.
    cs,hierarchy=cv2.findContours(final,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    assert hierarchy is not None
    combined=[]
    for c,hinfo in zip(cs,hierarchy[0]):
        if cv2.contourArea(c)<1:continue
        role='outer' if hinfo[3]==-1 else 'hole'
        combined.append(make_contour(cv2.approxPolyDP(c,.40,True).reshape(-1,2),role))
    assert combined
    g['construction_subpaths_source_only']=g.pop('subpaths')
    g['combined_clip_subpaths']=combined
    g['fill_rule']='nonzero'
    g['pdf_clip_operator']='W n với combined_clip_subpaths; không dùng các construction_subpaths riêng làm W n.'
    g['coordinate_quantization']='Phép hợp/subtract tại lưới pixel nguồn; mốc đường bao tâm pixel, sai số đơn giản hóa tối đa 0.4 pixel. Các viền nguồn mờ 1–3 pixel đã có UNKNOWN. Không co giãn/dịch sản phẩm.'
    g['construction_diagnostic']='V1 là trung gian: các miền ngoài giao nhau và vòng lỗ không luôn nằm trong miền ngoài. V2 lấy hợp miền ngoài rồi trừ lỗ, sau đó xuất topology cuối. Không dùng SVG V1 sản xuất.'
    g['status']='ĐỀ XUẤT ĐƯỜNG CẮT PDF NGUỒN V2; CHỜ MẪU PDF, chưa nghiệm thu mọi biên mờ'
    ds=[]
    for p in combined:ds.append(' '.join(' '.join(map(str,q)) for q in p['commands_pixel']))
    sv=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><metadata>Source-only clipping geometry; JPEG RGB bytes untouched. V2 union-minus-holes, nonzero winding.</metadata><path fill="white" fill-rule="nonzero" d="{" ".join(ds)}"/></svg>'
    name=f'NHOM{g["group"]} DUONG CAT NGUON V2'
    (OUT/(name+'.svg')).write_text(sv,encoding='utf-8')
    Image.fromarray(final*255).save(OUT/(name+' SO DO HINH HOC.png'))
    g['geometry_svg']=str(OUT/(name+'.svg'))
    pts_check=[r for r in data['source_landmarks'] if r['group']==g['group']]
    for r in pts_check:
        x,y=r['source_xy'];r['inside_geometry']=bool(final[y,x]);r['status']='ĐẠT' if r['inside_geometry']==(r['meaning']=='product') else 'CẦN SỬA';assert r['status']=='ĐẠT',r
    holecenters={1:[(85,322),(170,318)],2:[(433,1325),(592,1320)],3:[(209,1020),(300,1017),(640,1000),(740,990)]}[g['group']]
    g['clear_foot_background_tests']=[{'source_xy':[x,y],'inside_final_geometry':bool(final[y,x]),'status':'ĐẠT' if not final[y,x] else 'CẦN SỬA'} for x,y in holecenters]
    assert all(z['status']=='ĐẠT' for z in g['clear_foot_background_tests'])
    report={'group':g['group'],'final_contours':len(combined),'outer':sum(p['role']=='outer' for p in combined),'holes':sum(p['role']=='hole' for p in combined),'visible_area_fraction':float(final.mean()),'clear_foot_hole_centers':g['clear_foot_background_tests']}
    reports.append(report)
data['topology_V2_checks']=reports
data['note_for_writer']='Chỉ dùng combined_clip_subpaths hoặc SVG V2; mỗi group dùng cùng canvas JPEG nguyên. Trục y dữ liệu từ trên xuống, phải đổi sang hệ PDF đúng theo hình ảnh đặt. Dùng W n (nonzero). Đừng nén/lấy RGB khác của ảnh JPEG. Các PNG sơ đồ chỉ bằng chứng hình học, không làm ảnh sản phẩm hoặc SMask production.'
(OUT/'BA NHOM DUONG CAT PDF NGUON V2 CHO MAU.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
assert all(hashlib.sha256(Path(g['source_JPEG']).read_bytes()).hexdigest()==g['source_JPEG_sha256'] for g in data['groups'])
print(json.dumps({'report':str(OUT/'BA NHOM DUONG CAT PDF NGUON V2 CHO MAU.json'),'checks':reports},ensure_ascii=False))
