"""Chốt khe nhìn trực tiếp JPEG giữa hai chi tiết phải: hàng nền y=798."""
from pathlib import Path
import json,hashlib,cv2,numpy as np
from PIL import Image

HERE=Path(__file__).parent
OLD=HERE/'DU LIEU DUONG CAT NGUON V2 CHOT PHEP HOP'/'BA NHOM DUONG CAT PDF NGUON V2 CHO MAU.json'
OUT=HERE/'DU LIEU DUONG CAT NGUON V3 KHE THAT'
assert not OUT.exists();OUT.mkdir()
d=json.loads(OLD.read_text(encoding='utf-8'))
def area(p):
    p=np.asarray(p,float);return float(np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])/2)
def contour(points,role):
    p=np.asarray(points,float)
    if (area(p)>0)!=(role=='outer'):p=p[::-1]
    return {'role':role,'points_source_pixel':p.tolist(),'commands_pixel':[['M',*p[0].tolist()]]+[['L',*v.tolist()] for v in p[1:]]+[['Z']],'signed_area_source_pixel2':area(p),'bbox_source_pixel':[float(p[:,0].min()),float(p[:,1].min()),float(p[:,0].max()),float(p[:,1].max())]}
counts=[]
for g in d['groups']:
    w,h=g['source_canvas_pixel'];outside=np.zeros((h,w),np.uint8);holes=np.zeros_like(outside)
    for p in g['construction_subpaths_source_only']:
        z=np.zeros_like(outside);cv2.fillPoly(z,[np.rint(np.asarray(p['points_source_pixel'])).astype(np.int32)],1)
        if g['group']==3 and p['name']=='Chi tiết rời giữa phía phải - đường bao nguồn':
            z[798:,:]=0
            p['source_confirmed_gap_y']=798
            p['clip_keep_limit']='Hình nguồn chi tiết giữa kết thúc tại y<=797; hàng 798 là nền trắng thật; phần nhỏ y799 trở đi thuộc gờ trên cụm dưới, không nối hai chi tiết.'
            p['gap_evidence']=str(HERE/'06 KHE GIUA HAI CHI TIET PHAI NGUON.png')
        if p['role']=='outer':outside|=z
        else:holes|=z
    final=outside&(1-holes)
    cs,hh=cv2.findContours(final,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    combined=[]
    for c,hi in zip(cs,hh[0]):
        if cv2.contourArea(c)<1:continue
        combined.append(contour(cv2.approxPolyDP(c,.40,True).reshape(-1,2),'outer' if hi[3]==-1 else 'hole'))
    g['combined_clip_subpaths']=combined
    g['status']='DỮ LIỆU V3 CHO MẪU PDF; toàn bộ biên mờ/chi tiết trắng còn các UNKNOWN đã nêu'
    g['construction_diagnostic']='V1/V2 trung gian; V3 giữ phép hợp-minus-holes và khe nền thật y798 ở cụm phải nhóm3. Chỉ dùng combined_clip_subpaths hoặc SVG V3.'
    name=f'NHOM{g["group"]} DUONG CAT NGUON V3'
    ds=[' '.join(' '.join(map(str,q)) for q in p['commands_pixel']) for p in combined]
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><metadata>Source-only clip V3. JPEG RGB is immutable. Nonzero winding, actual source gap between components.</metadata><path fill="white" fill-rule="nonzero" d="{" ".join(ds)}"/></svg>'
    (OUT/(name+'.svg')).write_text(svg,encoding='utf-8');Image.fromarray(final*255).save(OUT/(name+' SO DO HINH HOC.png'))
    g['geometry_svg']=str(OUT/(name+'.svg'))
    for r in d['source_landmarks']:
        if r['group']==g['group']:
            x,y=r['source_xy'];r['inside_geometry']=bool(final[y,x]);assert r['inside_geometry']==(r['meaning']=='product')
    for r in g['clear_foot_background_tests']:
        x,y=r['source_xy'];assert not final[y,x]
    nouter=sum(p['role']=='outer' for p in combined)
    assert nouter=={1:1,2:3,3:4}[g['group']],(g['group'],nouter)
    counts.append({'group':g['group'],'final_outer_components':nouter,'hole_contours':sum(p['role']=='hole' for p in combined),'source_canvas':[w,h]})
d['topology_V3_checks']=counts
d['note_for_writer']='CHỈ dùng combined_clip_subpaths hoặc SVG V3. V1/V2 trung gian không ghép PDF. JPEG giữ nguyên byte, cùng canvas; y dữ liệu từ trên xuống. W n nonzero. PNG sơ đồ hình học chỉ kiểm đường, không dùng làm ảnh sản phẩm/SMask. Không lấy bất kỳ RGB hay biên từ AI.'
d['actual_source_gap_proof']={'group':3,'source_pixel_y':798,'source_RGB_at_684_798':[251,250,255],'meaning':'Nền trắng thật giữa chi tiết rời và gờ cụm vỏ dưới; không nối hai miền.'}
path=OUT/'BA NHOM DUONG CAT PDF NGUON V3 CHO MAU.json';path.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
assert all(hashlib.sha256(Path(g['source_JPEG']).read_bytes()).hexdigest()==g['source_JPEG_sha256'] for g in d['groups'])
print(json.dumps({'report':str(path),'components':counts,'all19_known_product_background_landmarks':'ĐẠT','all8_clear_foot_window_centers':'ĐẠT','status':'DỮ LIỆU ĐỀ XUẤT; CÓ UNKNOWN BIÊN, CHƯA PDF'},ensure_ascii=False))
