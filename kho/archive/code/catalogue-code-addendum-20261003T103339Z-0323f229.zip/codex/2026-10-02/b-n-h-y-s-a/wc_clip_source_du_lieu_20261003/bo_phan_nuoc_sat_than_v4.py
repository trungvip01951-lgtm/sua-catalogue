"""Chốt biên thẳng thân từ scan nguồn; không lấy nước màu xám sát thân thành sản phẩm."""
from pathlib import Path
import json,hashlib,cv2,numpy as np
from PIL import Image
import pymupdf as fitz
HERE=Path(__file__).parent
OLD=HERE/'DU LIEU DUONG CAT NGUON V3 KHE THAT'/'BA NHOM DUONG CAT PDF NGUON V3 CHO MAU.json'
OUT=HERE/'DU LIEU DUONG CAT NGUON V4B BIEN THAN DUNG'
assert not OUT.exists();OUT.mkdir()
d=json.loads(OLD.read_text(encoding='utf-8'))
def signed(p):
    p=np.asarray(p,float);return float(np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])/2)
def contour(c,role):
    p=cv2.approxPolyDP(c,.40,True).reshape(-1,2).astype(float)
    if (signed(p)>0)!=(role=='outer'):p=p[::-1]
    return {'role':role,'points_source_pixel':p.tolist(),'commands_pixel':[['M',*p[0].tolist()]]+[['L',*q.tolist()] for q in p[1:]]+[['Z']],'signed_area_source_pixel2':signed(p),'bbox_source_pixel':[float(p[:,0].min()),float(p[:,1].min()),float(p[:,0].max()),float(p[:,1].max())]}
def source_wall_limits(rgb,y0,y1,seedx):
    aa=rgb.astype(int);sure=(aa.max(2)-aa.min(2)<30)&(aa.mean(2)<212)
    values=[]
    for y in range(y0,y1):
        row=sure[y];assert row[seedx],(y,seedx)
        left=seedx;right=seedx
        while left>0 and row[left-1]:left-=1
        while right+1<len(row) and row[right+1]:right+=1
        values.append([y,left,right])
    values=np.asarray(values,float);ys=values[:,0];proof={'source_band':[y0,y1],'source_seed_x':seedx,'observed_rows':len(values)}
    limits=[]
    for column,label in [(1,'left'),(2,'right')]:
        z=values[:,column];good=np.ones(len(ys),bool)
        for _ in range(5):
            a,b=np.polyfit(ys[good],z[good],1);err=z-(a*ys+b);med=np.median(err[good]);good=np.abs(err-med)<2
        a,b=np.polyfit(ys[good],z[good],1)
        proof[label]={'a':float(a),'b':float(b),'fitted_gray_source_rows':int(good.sum()),'rejected_water_or_alias_outlier_rows':int((~good).sum()),'max_kept_source_residual_pixel':float(np.max(np.abs(z[good]-(a*ys[good]+b))))}
        limits.append(a*ys+b)
    proof['keep_margin_pixel']=1.5
    return np.floor(limits[0]-1.5).astype(int),np.ceil(limits[1]+1.5).astype(int),proof

rows=[]
for g in d['groups']:
    rgb=np.asarray(Image.open(g['source_JPEG']).convert('RGB'));w,h=g['source_canvas_pixel'];outer=np.zeros((h,w),np.uint8);holes=np.zeros_like(outer);wallproof=[]
    bands={1:[],2:[('Thân/miệng/chân bơm chính nguồn',545,830,520)],3:[('Bơm hoàn chỉnh bên trái - thân/miệng/chân nguồn',625,780,240),('Cụm động cơ tách phải - thân nguồn',300,476,680)]}[g['group']]
    for p in g['construction_subpaths_source_only']:
        z=np.zeros_like(outer);cv2.fillPoly(z,[np.rint(np.asarray(p['points_source_pixel'])).astype(np.int32)],1)
        if g['group']==3 and p['name']=='Chi tiết rời giữa phía phải - đường bao nguồn':z[798:,:]=0
        for title,y0,y1,seedx in bands:
            if p['name']==title:
                left,right,proof=source_wall_limits(rgb,y0,y1,seedx);proof['construction_name']=title;wallproof.append(proof)
                for k,y in enumerate(range(y0,y1)):
                    z[y,:max(0,left[k])]=0;z[y,min(w,right[k]+1):]=0
                # Miền thân xám vốn nối một khối. Sau khi bỏ vệt nước bám, chỉ giữ khối nối với
                # thân chắc chắn, không giữ các mảnh nước vừa mất liên kết tại hai đầu dải.
                n,lab,stats,centers=cv2.connectedComponentsWithStats(z,8)
                chosen=int(lab[(y0+y1)//2,seedx]);assert chosen>0
                discarded=[{'bbox':[int(q[0]),int(q[1]),int(q[0]+q[2]),int(q[1]+q[3])],'pixel_area':int(q[4])} for j,q in enumerate(stats) if j not in [0,chosen]]
                z=(lab==chosen).astype(np.uint8)
                proof['discarded_disconnected_water_fragments_after_wall_trim']=discarded
        if p['role']=='outer':outer|=z
        else:holes|=z
    final=outer&(1-holes)
    cs,hh=cv2.findContours(final,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    combined=[]
    for c,hi in zip(cs,hh[0]):
        if cv2.contourArea(c)<1:continue
        combined.append(contour(c,'outer' if hi[3]==-1 else 'hole'))
    assert sum(p['role']=='outer' for p in combined)=={1:1,2:3,3:4}[g['group']]
    g['combined_clip_subpaths']=combined;g['source_straight_wall_readback']=wallproof
    g['construction_diagnostic']='V1–V3 trung gian. V4 đọc riêng các vách thẳng nguồn từ dải RGB thân thật, loại dòng nước/alias ngoại lai bằng fit robust; giữ biên 1.5 pixel. Không đổi RGB/khung nguồn.'
    g['status']='DỮ LIỆU ĐỀ XUẤT V4 CHO MẪU PDF; các UNKNOWN biên mờ/chi tiết trắng vẫn còn'
    name=f'NHOM{g["group"]} DUONG CAT NGUON V4';ds=[' '.join(' '.join(map(str,q)) for q in p['commands_pixel']) for p in combined]
    sv=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><metadata>Source-only V4 geometry, no source RGB changes. Nonzero winding.</metadata><path fill="white" fill-rule="nonzero" d="{" ".join(ds)}"/></svg>'
    sp=OUT/(name+'.svg');sp.write_text(sv,encoding='utf-8');Image.fromarray(final*255).save(OUT/(name+' SO DO HINH HOC.png'));g['geometry_svg']=str(sp)
    svgpoints=[]
    with fitz.open(stream=sp.read_bytes(),filetype='svg') as sd:
        scale=w/sd[0].rect.width;pm=sd[0].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=True);aa=np.frombuffer(pm.samples,np.uint8).reshape(pm.height,pm.width,pm.n)[:,:,-1]
        for r in d['source_landmarks']:
            if r['group']==g['group']:
                x,y=r['source_xy'];v=int(aa[y,x]);expected=r['meaning'];assert v>=128 if expected=='product' else v==0,(g['group'],r,v)
                svgpoints.append({'source_xy':[x,y],'meaning':expected,'actual_SVG_alpha':v,'status':'ĐẠT'})
        for r in g['clear_foot_background_tests']:
            x,y=r['source_xy'];v=int(aa[y,x]);assert v==0,(g['group'],x,y,v);svgpoints.append({'source_xy':[x,y],'meaning':'clear_foot_background','actual_SVG_alpha':v,'status':'ĐẠT'})
    rows.append({'group':g['group'],'SVG_sha256':hashlib.sha256(sp.read_bytes()).hexdigest(),'actual_SVG_points':svgpoints,'wall_source_checks':wallproof,'visible_area_fraction':float(final.mean())})
d['source_wall_cleanup_V4']='Các gai giả dọc thân xám trong V3 là nước/JPEG sát biên; V4 chỉ khóa dải vách thẳng đã quan sát nguồn. Không áp ngưỡng đen vào quai/chi tiết trắng.'
d['note_for_writer']='CHỈ dùng combined_clip_subpaths hoặc SVG V4, W n nonzero, cùng canvas JPEG nguồn và giữ JPEG nguyên byte. Y dữ liệu từ trên xuống. V1–V3 không ghép PDF. PNG sơ đồ là kiểm hình học, không làm ảnh sản phẩm/SMask. Còn UNKNOWN, cần mẫu PDF.'
(OUT/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'DOC LAI SVG THAT VA27 DIEM V4.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
assert all(hashlib.sha256(Path(g['source_JPEG']).read_bytes()).hexdigest()==g['source_JPEG_sha256'] for g in d['groups'])
print(json.dumps({'report':str(OUT/'BA NHOM DUONG CAT PDF NGUON V4 CHO MAU.json'),'source_hashes_held':True,'SVG_points_PASS':sum(len(r['actual_SVG_points']) for r in rows),'wall_bands':[r['wall_source_checks'] for r in rows]},ensure_ascii=False))
