"""Dữ liệu đường cắt PDF từ JPEG nguồn; không sửa RGB và không ghi PDF/ảnh ghép sản phẩm."""
from pathlib import Path
import json,hashlib,math
import cv2
import numpy as np
from PIL import Image
import pymupdf as fitz

HERE=Path(__file__).parent
OUT=HERE/'DU LIEU DUONG CAT NGUON V1'
assert not OUT.exists()
OUT.mkdir()
ROOT=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 03-10-2026 (ChatGPT)\_BAO CAO\G08\ANH DAI DIEN PEROTAC KHAC REDPUMP')
PHOTO=ROOT/'NGUON ANH DOC RIENG'
PDF=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 01-10-2026\Nước thải\Catalog cắt rác perotac (bản mới).pdf')
PHOTOS=json.loads((PHOTO/'ANH NGUON TAM TRANG VA VI TRI.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(PDF)==PHOTOS['hashes']['source']

def area(points):
    p=np.asarray(points,float)
    return float(np.sum(p[:,0]*np.roll(p[:,1],-1)-np.roll(p[:,0],-1)*p[:,1])/2)

def subpath(name,points,role='outer',method='',uncertainty=''):
    p=np.asarray(points,float)
    if (area(p)>0)!=(role=='outer'):p=p[::-1]
    p=np.round(p,3)
    return {'name':name,'role':role,'source_method':method,'uncertainty':uncertainty,'points_source_pixel':p.tolist(),
            'commands_pixel':[['M',*p[0].tolist()]]+[['L',*q.tolist()] for q in p[1:]]+[['Z']],
            'signed_area_source_pixel2':area(p),'bbox_source_pixel':[float(p[:,0].min()),float(p[:,1].min()),float(p[:,0].max()),float(p[:,1].max())]}

def observed_gray_body(rgb,allowed,seed,name):
    # Chỉ tìm biên ngoài phần thân xám trong ROI đã đọc ảnh. Không dùng cho thanh/quai kim loại sáng.
    a=rgb.astype(float);neutral=(a.max(2)-a.min(2)<70)&(a.mean(2)<212)
    select=np.zeros(a.shape[:2],np.uint8)
    for box in allowed:
        x0,y0,x1,y1=box;select[y0:y1,x0:x1]=1
    candidate=(neutral & (select>0)).astype(np.uint8)
    n,lab,stat,cent=cv2.connectedComponentsWithStats(candidate,8)
    x,y=seed;chosen=int(lab[y,x]);assert chosen>0,(name,seed)
    # Lấy đường bao thành phần nguồn thật, rồi giữ biên JPEG thêm tối đa 1 pixel nguồn.
    filled=np.zeros_like(candidate)
    cs,_=cv2.findContours((lab==chosen).astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    assert len(cs)==1
    cv2.drawContours(filled,cs,-1,1,cv2.FILLED)
    filled=cv2.dilate(filled,np.ones((3,3),np.uint8))
    cs,_=cv2.findContours(filled,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    assert len(cs)==1
    pts=cv2.approxPolyDP(cs[0],.40,True).reshape(-1,2)
    return subpath(name,pts,method='Biên RGB xám/trung tính của chính JPEG, thành phần nối với điểm thân chắc chắn; lấy biên ngoài, giữ cả vùng sáng bên trong; đệm biên 1 pixel; không dùng đường này cho quai/ống sáng.',uncertainty='Biên JPEG và vùng sát nước có thể giữ thêm khoảng 1 pixel nền nguồn; phải xem mẫu PDF. Ngưỡng chỉ là trợ giúp thân xám, không nghiệm thu toàn sản phẩm.')

def clear_hole(rgb,box,seed,name):
    a=rgb.astype(float); bg=(a.mean(2)>211)|((a.max(2)-a.min(2)>55)&(a.mean(2)>150))
    keep=np.zeros(a.shape[:2],np.uint8);x0,y0,x1,y1=box;keep[y0:y1,x0:x1]=1
    cand=(bg&(keep>0)).astype(np.uint8)
    n,lab,stat,cent=cv2.connectedComponentsWithStats(cand,8)
    x,y=seed;chosen=int(lab[y,x]);assert chosen>0,(name,seed,rgb[y,x].tolist())
    hole=(lab==chosen).astype(np.uint8)
    # Chỉ bỏ vùng nền chắc bên trong, giữ mép nguồn thận trọng.
    hole=cv2.erode(hole,np.ones((3,3),np.uint8))
    cs,_=cv2.findContours(hole,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    assert cs
    c=max(cs,key=cv2.contourArea);assert cv2.contourArea(c)>2
    pts=cv2.approxPolyDP(c,.35,True).reshape(-1,2)
    return subpath(name,pts,role='hole',method='Chỉ khoảng nền sáng/nước trong cửa chân đã nhìn rõ từ JPEG nguồn; giữ mép thêm 1 pixel, không suy lỗ bằng ảnh AI.',uncertainty='Phần sát mép cửa giữ pixel nguồn. Đây là phần rỗng nền thật nhìn rõ, không cắt lỗ đen/cavity hoặc vật liệu sáng chưa chắc.')

def rect(name,box,note=''):
    x0,y0,x1,y1=box
    return subpath(name,[[x0,y0],[x1,y0],[x1,y1],[x0,y1]],method='Đường thẳng/giới hạn nhìn trực tiếp trong JPEG gốc; giữ cả vệt kim loại sáng.',uncertainty=note)

def svg(paths,w,h):
    ds=[]
    for p in paths:
        ds.append(' '.join(' '.join(map(str,c)) for c in p['commands_pixel']))
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><metadata>Source coordinates. Nonzero winding. No source RGB copied or edited in this geometry SVG.</metadata><path fill="white" fill-rule="nonzero" d="{" ".join(ds)}"/></svg>'

def geometry_raster(paths,w,h):
    # Chỉ sơ đồ hình học để đọc, không phải alpha tài sản sản phẩm hoặc ảnh ghép cuối.
    acc=np.zeros((h,w),np.int16)
    for p in paths:
        z=np.zeros((h,w),np.uint8)
        pts=np.rint(np.asarray(p['points_source_pixel'])).astype(np.int32)
        cv2.fillPoly(z,[pts],1)
        acc+=z if p['role']=='outer' else -z
    return (acc!=0).astype(np.uint8)*255

docs=fitz.open(PDF)
native=[]
for pi in range(8):
    xref=202 if pi<3 else (206 if pi<5 else 209)
    rec=next(x for x in docs[pi].get_images(full=True) if x[0]==xref)
    clips=[x for x in docs[pi].get_drawings(extended=True) if x.get('type')=='clip']
    native.append({'page':pi+1,'source_photo_xref':xref,'source_photo_SMask_xref':rec[1],'image_rects_top_left':[list(x) for x in docs[pi].get_image_rects(xref)],'native_clips':[{'scissor_top_left':list(x['scissor']),'items':[str(q) for q in x.get('items',[])]} for x in clips]})
assert docs.extract_image(202)['image']==(PHOTO/'TRANG 01 ANH NHUNG GOC.jpeg').read_bytes()
assert docs.extract_image(206)['image']==(PHOTO/'TRANG 04 ANH NHUNG GOC.jpeg').read_bytes()
assert docs.extract_image(209)['image']==(PHOTO/'TRANG 06 ANH NHUNG GOC.jpeg').read_bytes()
maskraw=docs.extract_image(201)['image'];import io
mask=np.asarray(Image.open(io.BytesIO(maskraw)).convert('L'));assert mask.min()==mask.max()==255
native_receipt={'source_PDF':str(PDF),'source_PDF_sha256':sha(PDF),'native_pages':native,'group1_source_SMask':{'xref':201,'size':[246,357],'sha256':hashlib.sha256(maskraw).hexdigest(),'all_87822_pixels_255':True,'not_product_cutout':True},'groups2_3_SMask_absent':True,'native_photo_clips_are_layout_rectangles_not_product_silhouette':True}
(OUT/'MASK VA KHUNG BO CUC PDF NGUON.json').write_text(json.dumps(native_receipt,ensure_ascii=False,indent=2),encoding='utf-8')
docs.close()

groups=[]
for index,page in enumerate([1,4,6]):
    path=PHOTO/f'TRANG {page:02} ANH NHUNG GOC.jpeg';rgb=np.asarray(Image.open(path).convert('RGB'));h,w=rgb.shape[:2]
    curves=[];unknown=[]
    if index==0:
        curves.append(observed_gray_body(rgb,[[38,159,212,344]],(170,220),'Cụm thân bơm/coupling/chân nguồn'))
        curves.append(rect('Ống lớn thẳng nguồn',[53.5,19.5,77.5,266.0],'JPEG 246×357: biên kim loại sáng không tách sạch dưới 1 pixel; giữ thêm tối đa khoảng 1 pixel sát biên.'))
        curves.append(rect('Thanh dẫn hướng thẳng nguồn',[98.5,19.5,108.0,341.0],'Không suy số thanh từ ảnh AI; chỉ giữ đúng vùng kim loại thấy trong JPEG nguồn.'))
        curves.append(rect('Quai nhỏ trái nguồn - vùng giữ thận trọng',[145,162,160,180],'UNKNOWN: quai nguồn rất ít pixel, giữ cả vùng nhỏ nguồn; không vẽ lại vòng hoặc cắt lỗ nhỏ.'))
        curves.append(rect('Quai nhỏ phải nguồn - vùng giữ thận trọng',[182,163,194,180],'UNKNOWN: vòng nhỏ mờ; giữ vùng nhỏ nguồn để không mất chi tiết.'))
        curves.append(rect('Đầu nối giữa nguồn - vùng giữ thận trọng',[168,157,178,181],'UNKNOWN: giữ biên đầu nối gốc, không lấy kiểu đầu nối AI.'))
        for box,seed,name in [([70,310,101,335],(85,322),'Khoảng nền cửa chân coupling'),([153,308,188,329],(170,318),'Khoảng nền cửa chân bơm')]:curves.append(clear_hole(rgb,box,seed,name))
        unknown=['Hai quai nhỏ, đầu nối giữa và các lỗ chốt nhỏ nguồn quá ít pixel; giữ vùng nguồn bao nhỏ, không tự tạo topology mới.','Biên bạc hai thanh/ống mờ chống răng cưa; dư nền sát biên tối đa khoảng 1 pixel cần xem ở PDF.','Lỗ/vùng lõm nhỏ của bộ coupling không đọc chắc: giữ pixel nguồn bên trong, chưa tách nền ở đó.']
    elif index==1:
        curves.append(observed_gray_body(rgb,[[350,239,805,1450],[165,999,805,1450]],(520,700),'Thân/miệng/chân bơm chính nguồn'))
        handle=[[509,112],[522,104],[541,101],[560,103],[578,111],[587,130],[596,165],[607,207],[619,255],[631,306],[623,312],[599,312],[588,277],[580,249],[573.5,220],[571.5,200],[564,168],[557,154],[551,151],[540,158],[534.5,178],[523.5,206],[514,234],[500,269],[489,309],[480,352],[471,400],[465,415],[447,419],[438,410],[442,371],[443,335],[449,298],[460,258],[473,214],[482,181],[491,153],[500,130]]
        curves.append(subpath('Quai kim loại sáng nguồn',handle,method='Hai biên/quỹ đạo quai đọc trực tiếp ảnh nguồn phóng; dải kim loại riêng, không áp ngưỡng đen.',uncertainty='Nếp phản quang/đỉnh quai rất sáng: giữ khoảng 1–2 pixel nguồn gần biên, mẫu PDF cần kiểm. Tam giác trắng cực nhỏ dưới đỉnh chưa cắt vì không đọc chắc.'))
        top_part=[[148,316],[163,321],[179,324],[197,332],[217,346],[232,363],[244,384],[252,408],[253,434],[249,460],[239,483],[225,504],[207,521],[187,535],[168,544],[151,544],[132,536],[113,528],[96,518],[80,503],[65,486],[55,466],[50,442],[50,418],[54,395],[62,370],[74,346],[88,328],[105,315],[120,313],[132,317]]
        curves.append(subpath('Chi tiết rời trên - biên nguồn',top_part,method='Các mốc biên ngoài/nhô lên đọc ảnh nguồn; giữ JPEG và khoảng tối bên trong nguyên.',uncertainty='Biên kim loại trắng và bóng đổ: một số đoạn cần giữ viền nguồn nhỏ 1–3 pixel; không bỏ vùng đen ở tâm vì chưa chắc là nền xuyên qua.'))
        bottom_part=[[97,625],[112,617],[132,611],[155,611],[185,617],[210,625],[222,632],[237,633],[244,642],[245,653],[251,679],[254,710],[253,736],[242,760],[236,767],[236,783],[226,793],[212,793],[191,800],[165,802],[136,799],[113,791],[100,784],[84,784],[76,778],[71,768],[66,746],[61,719],[62,691],[67,666],[82,642],[86,630]]
        curves.append(subpath('Chi tiết rời trắng phía dưới - biên nguồn',bottom_part,method='Giữ cả vật liệu trắng bằng đường bao đọc ảnh nguồn; không dùng phân đoạn đen. Giữ nguyên các vùng xám bên trong từ nguồn.',uncertainty='UNKNOWN: biên trắng/bóng đổ và khoảng xám bên trong khó tách nền khỏi phản quang. Giữ pixel nguồn, không cắt các khe xám hoặc tâm tròn theo ảnh AI. Cần xem mẫu PDF.'))
        for box,seed,name in [([401,1260,454,1358],(433,1325),'Khoảng nền cửa chân trái bơm chính'),([548,1267,641,1366],(592,1320),'Khoảng nền cửa chân phải bơm chính')]:curves.append(clear_hole(rgb,box,seed,name))
        unknown=['Chi tiết rời trắng: giữ khe/tâm xám nguyên trong JPEG vì không phân biệt chắc nền xuyên qua với bóng/phản quang.','Hai biên chi tiết rời có bóng đổ mềm, proposal giữ viền nguồn khoảng 1–3 pixel; phải kiểm PDF trước chốt.','Tam giác trắng nhỏ ở đỉnh quai giữ nguyên nguồn, không tách khi chưa rõ.']
    else:
        curves.append(observed_gray_body(rgb,[[85,469,385,1098]],(240,700),'Bơm hoàn chỉnh bên trái - thân/miệng/chân nguồn'))
        left_handle=[[194,505],[197,471],[210,435],[224,398],[235,375],[247,365],[259,365],[268,375],[280,402],[292,433],[307,470],[310,481],[301,481],[299,469],[284,433],[273,405],[262,379],[258,375],[248,375],[242,379],[229,407],[215,442],[206,473],[204,505]]
        curves.append(subpath('Quai dây kim loại bơm trái nguồn',left_handle,method='Dải quai trắng đọc/phóng trực tiếp JPEG gốc, tách riêng khỏi ngưỡng thân xám.',uncertainty='UNKNOWN tại viền quai trắng mờ/JPEG: giữ khoảng 1–2 pixel nền nguồn sát biên để bảo toàn quai.'))
        curves.append(observed_gray_body(rgb,[[587,137,800,681]],(680,400),'Cụm động cơ tách phải - thân nguồn'))
        right_handle=[[633,175],[635,143],[644,117],[655,88],[665,59],[675,34],[685,21],[694,20],[705,22],[711,31],[720,51],[730,77],[741,106],[751,134],[752,157],[744,159],[741,133],[732,109],[720,82],[710,57],[704,41],[698,32],[692,30],[686,33],[676,58],[666,86],[655,117],[646,145],[644,176]]
        curves.append(subpath('Quai dây kim loại cụm phải nguồn',right_handle,method='Dải quai theo ảnh nguồn, giữ phần kim loại sáng, không mượn quai AI.',uncertainty='Biên dây sáng/mờ giữ viền nguồn khoảng 1–2 pixel; không tăng nét hoặc dựng lại dây.'))
        curves.append(subpath('Trục sáng nối cụm trên phải nguồn',[[678,618],[701,618],[701,662],[699,669],[697,679],[691,680],[691,674],[682,674],[678,666]],method='Giới hạn trục/thanh sáng nguồn đọc trực tiếp, giữ điểm sáng mà ngưỡng thân xám bỏ qua.',uncertainty='Đầu trục dưới nhỏ/mờ: giữ vùng nguồn nhỏ; chưa xác minh phụ kiện ở đầu trục.'))
        middle=[[658,697],[681,696],[710,697],[733,703],[753,713],[769,726],[775,740],[770,752],[759,760],[755,781],[747,790],[729,797],[707,802],[677,804],[655,802],[636,797],[624,789],[620,779],[617,762],[610,755],[607,743],[609,728],[618,716],[635,704]]
        curves.append(subpath('Chi tiết rời giữa phía phải - đường bao nguồn',middle,method='Điểm ngoài đọc từ JPEG, giữ vùng sáng và vùng tối lõm của chính chi tiết.',uncertainty='Biên kim loại sáng/mờ: giữ viền nguồn nhỏ khoảng 1–2 pixel. Vùng đen ở tâm giữ nguyên vì không chắc là nền xuyên qua.'))
        curves.append(observed_gray_body(rgb,[[506,800,835,1085]],(690,900),'Cụm vỏ/miệng/chân tách phải - nguồn'))
        for box,seed,name in [([175,980,236,1056],(209,1020),'Khoảng nền chân trái bơm hoàn chỉnh'),([277,980,331,1058],(300,1017),'Khoảng nền chân phải bơm hoàn chỉnh'),([612,955,667,1051],(640,1000),'Khoảng nền chân trái vỏ tách'),([718,943,768,1048],(740,990),'Khoảng nền chân phải vỏ tách')]:curves.append(clear_hole(rgb,box,seed,name))
        unknown=['Quai dây sáng và đầu trục có biên JPEG mờ: giữ pixel nguồn sát biên, chưa chốt dưới 1–2 pixel.','Biên sáng chi tiết rời giữa và vùng tối tâm giữ nguyên nguồn, chưa phân loại thành lỗ xuyên/nền.','Không suy số răng/lỗ/ốc từ hình AI; các chi tiết trong ảnh gốc đều giữ RGB nguyên.']
    # Một đường cắt nonzero: các miền ngoài cùng chiều tạo phép hợp; lỗ ngược chiều.
    name=f'NHOM{index+1} DUONG CAT TU NGUON'
    sv=svg(curves,w,h);(OUT/(name+'.svg')).write_text(sv,encoding='utf-8')
    geom=geometry_raster(curves,w,h)
    Image.fromarray(geom).save(OUT/(name+' SO DO HINH HOC.png'))
    groups.append({'group':index+1,'pages':[1,2,3] if index==0 else ([4,5] if index==1 else [6,7,8]),'source_JPEG':str(path),'source_JPEG_sha256':sha(path),'source_canvas_pixel':[w,h],'fill_rule':'nonzero','pdf_clip_operator':'W n; không dùng W* vì các miền ngoài có giao nhau','subpaths':curves,'unknown_regions':unknown,'status':'DỮ LIỆU ĐỀ XUẤT TỪ NGUỒN; CHỜ ROOT ĐỌC/MẪU PDF, chưa nghiệm thu sạch mọi biên','geometry_svg':str(OUT/(name+'.svg'))})

tests=[[(185,170,'product'),(194,265,'product'),(97,272,'product'),(65,15,'background'),(103,15,'background')],[(581,188,'product'),(594,245,'product'),(397,689,'product'),(111,656,'product'),(91,693,'product'),(544,80,'background'),(500,1475,'background')],[(304,475,'product'),(699,147,'product'),(770,300,'product'),(707,699,'product'),(621,980,'product'),(814,991,'product'),(347,690,'background')]]
landmarks=[]
for g,pts in zip(groups,tests):
    w,h=g['source_canvas_pixel'];m=geometry_raster(g['subpaths'],w,h)
    for x,y,meaning in pts:
        visible=int(m[y,x]);landmarks.append({'group':g['group'],'source_xy':[x,y],'meaning':meaning,'inside_geometry':visible>0,'status':'ĐẠT' if ((visible>0)==(meaning=='product')) else 'CẦN SỬA DỮ LIỆU TRƯỚC MẪU'})
result={'source_only':True,'source_RGB_modified':False,'AI_source_shape_used':False,'PDF_written':False,'final_composite_written':False,'geometry_png_not_production_asset':True,'method':'Bố cục PDF: giữ nguyên byte JPEG, áp đường cắt cùng khung pixel nguồn. Phần thân xám đọc biên từ nguồn với ROI + điểm thân chắc; quai/ống/kim loại trắng có đường giữ riêng. Khoảng rỗng rõ từ nguồn được bỏ thận trọng. Vùng mờ có UNKNOWN và giữ viền nguồn nhỏ.','groups':groups,'source_landmarks':landmarks,'limitations':'Chưa chốt sạch mọi biên, chưa mẫu PDF. Landmark không thay nghiệm thu toàn silhouette/holes. Chi tiết rời trắng và quai mờ còn UNKNOWN; không dựng lại RGB/phụ tùng.'}
(OUT/'BA NHOM DUONG CAT PDF TU PIXEL NGUON V1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
assert sha(PDF)==PHOTOS['hashes']['source']
assert all(sha(g['source_JPEG'])==g['source_JPEG_sha256'] for g in groups)
print(json.dumps({'output':str(OUT),'subpaths_per_group':[len(g['subpaths']) for g in groups],'landmarks_fail':[p for p in landmarks if p['status']!='ĐẠT']},ensure_ascii=False))
