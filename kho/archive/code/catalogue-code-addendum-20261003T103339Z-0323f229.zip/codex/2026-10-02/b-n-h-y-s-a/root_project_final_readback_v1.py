"""Đọc lại kho dùng chung/nguồn bất biến; chỉ ghi báo cáo QA mới."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import uuid

ROOT = Path(r'D:\ChatGPT\Sửa catalogue').resolve()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def main():
    m = read(ROOT/'manifest.json')
    baseline_path = Path(m['paths']['reports'])/'BAO CAO BUOC0.json'
    baseline = next(r['hashes_before'] for r in read(baseline_path) if 'hashes_before' in r)
    source_checks = [{'path': p, 'expected': h, 'actual': digest(p)} for p, h in baseline.items()]
    assert all(x['expected'] == x['actual'] for x in source_checks), 'Nguồn thay đổi so BƯỚC0 đầu'
    inventory = read(ROOT/'state/catalogues.json')
    assert len(inventory['catalogues']) == 25
    source_names = {str(Path(m['paths']['source']) / r['source_relative']) for r in inventory['catalogues']}
    assert source_names <= set(baseline), 'Nguồn chưa có đối chiếu ban đầu'
    assert len({r['current_relative'] for r in inventory['catalogues']}) == 25
    commands = [['health'], ['status']]
    selected = ['Trục ngang/Catalogue DWO (bản mới).xlsx',
                'Nước thải/Catalogue perotac (bản mới).xlsx',
                'Giếng/Aquaris bơm giếng SP 1_300dpi_75% (bản mới).pdf',
                'Trục ngang/bơm trục ngnag redpump model CM_300dpi_75% (bản mới).pdf',
                'Giếng/Perotac bơm giếng SA_compressed (bản mới).pdf']
    commands += [['context', '--file', name] for name in selected]
    results = []
    for args in commands:
        completed = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(ROOT/'tools/catalogue.py'), *args],
                                   capture_output=True, text=True, encoding='utf8')
        assert completed.returncode == 0, (args, completed.stdout, completed.stderr)
        data = json.loads(completed.stdout)
        if args[0] == 'health':
            assert data['result'] == 'ĐẠT CẤU TRÚC DỰ ÁN'
        if args[0] == 'context':
            assert not data['inputs_changed_since_snapshot']
            assert not data['controls']['changed']
        results.append({'args': args, 'result': data})
    newest_bootstrap = sorted((ROOT/'history').glob('bootstrap-*.txt'))[-1]
    log = newest_bootstrap.read_text(encoding='utf8')
    assert 'TỔNG KẾT: 43/43 ĐẠT' in log
    assert 'MÁY ANH TRUNG' in log
    package = read(ROOT/'vendor/ORIGINAL_PACKAGE_MANIFEST.json')
    assert digest(package['original']) == package['zip_sha256'] == digest(ROOT/'vendor/GOI_SUA_CATALOGUE_CHATGPT.zip')
    template = read(ROOT/'templates/NGHIEM_THU.json')
    assert template['result'] == 'CHƯA THỂ XÁC MINH'
    assert all(r['result'] == 'CHUA_CHAY' for r in template['checks'])
    assert not m['claude_runtime_read_verified']
    report = {'recorded_utc': datetime.now(timezone.utc).isoformat(),
              'source_baseline': str(baseline_path), 'source_checks': source_checks,
              'original_sources_unchanged': len(source_checks), 'catalogues': 25,
              'commands': results,
              'bootstrap_evidence': str(newest_bootstrap), 'bootstrap_sha256': digest(newest_bootstrap),
              'catfix_tests_actual': '43/43 ĐẠT',
              'coordination_tests': {'result': '8/8 ĐẠT', 'observed_previous_actual_tool_run': True,
                  'first_failed_run_retained': str(ROOT/'history/COORDINATION_TEST_FAILURE_01.md'),
                  'code_sha256': digest(ROOT/'tools/catalogue.py'), 'test_sha256': digest(ROOT/'tools/test_coordination.py')},
              'task_scope_tests': {'result': '4/4 ĐẠT', 'observed_actual_tool_run_before_this_readback': True,
                  'code_sha256': digest(ROOT/'tools/refresh_index.py'), 'test_sha256': digest(ROOT/'tools/test_project_index.py')},
              'project_structure_not_catalogue_acceptance': True,
              'no_catalogue_written_by_this_QA': True,
              'no_other_AI_read_receipt_claimed': True}
    target = ROOT/'history'/('ROOT-PROJECT-READBACK-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]+'.json')
    with target.open('x', encoding='utf8') as output:
        json.dump(report, output, ensure_ascii=False, indent=2)
    print(json.dumps({'result':'ĐẠT ĐỌC LẠI CẤU TRÚC VÀ NGUỒN', 'report':str(target),
          'report_sha256':digest(target), 'sources_unchanged':len(source_checks),
          'catalogues':25, 'catfix_actual_tests':'43/43 ĐẠT',
          'coordination_actual_tests':'8/8 ĐẠT', 'task_scope_actual_tests':'4/4 ĐẠT',
          'catalogue_numeric_graphic_acceptance_not_claimed':True},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
