"""Kiểm phương án số đã đọc từ ảnh nguồn; không ghi bảng/catalogue."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(r'D:\ChatGPT\Sửa catalogue').resolve()
PLAN = ROOT/'work/g18_project_qa/6SL25_DON_DIEU_DOC_NGUON_LAN1/PHUONG AN NGUYEN10 HANG VA QUET17 BANG THEO QUY TAC MOI.json'
EXPECTED = 'a12f601d5dedddb65c9bb09788015b8196c5f4364043327c96b366fe4839f326'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert sha(PLAN) == EXPECTED
    data = json.loads(PLAN.read_text(encoding='utf8'))
    assert sha(data['source']) == data['source_SHA256']
    assert sha(data['current']) == data['current_SHA256']
    rows = data['proposals']
    assert len(rows) == 10
    changed = 0
    checks = 0
    observed_rows = []
    for row in rows:
        q = row['Q_m3h']; old = row['H_source_read_direct']; new = row['H_integer_proposed']
        assert len(q) == len(old) == len(new) == 12
        assert all(type(h) is int for h in new)
        assert all(q[i+1] > q[i] and new[i+1] < new[i] for i in range(11))
        assert max(new) == max(old) == row['source_table_max_value']
        assert min(new) == min(old) == row['source_table_min_value']
        assert new[-1] == old[-1] and q[-1] == 33
        assert new[9] == old[9] and q[9] == 27
        edits = [(q[i], old[i], new[i]) for i in range(12) if old[i] != new[i]]
        assert len(edits) == len(row['changed_cells'])
        changed += len(edits); checks += 11
        observed_rows.append({'model':row['model'],'Q':q,'source_H':old,'proposed_H':new,
                              'edited_cells':edits,'integer_pairs_checked':11,
                              'actual_PDF_numeric_acceptance':'CHUA_CHAY'})
    assert changed == 26 and checks == 110
    scan = data['source_scan_17_tables']
    pairs = scan['non_decreasing_pairs']
    assert len(pairs) == 33
    report = {'checked_utc':datetime.now(timezone.utc).isoformat(),
        'actor':'ROOT', 'plan_path':str(PLAN),'plan_sha256':EXPECTED,
        'source_path':data['source'],'source_sha256':data['source_SHA256'],
        'source_image_independently_viewed':str(PLAN.parent/'BANG6SL25 TEN HANG DAU COT VA120 O NGUON600.png'),
        'visual_read_scope':'ROOT mở ảnh có tên10 hàng/đầu12 cột, đối chiếu120 số với phương án; không đọc mới toàn1931 ô.',
        'numeric_plan_result':'ĐẠT KIỂM PHƯƠNG ÁN SỐ',
        'models':10,'source_cells':120,'candidate_changed_cells':changed,
        'unchanged_cells':94,'strict_decreasing_pairs':checks,'rows':observed_rows,
        'source_scan_scope':'Tái dùng17 bảng có tọa độ và mã nguồn; 5 cặp tăng/28 bằng, chưa là kiểm mới toàn nét.',
        'source_non_decreasing_pairs':len(pairs),
        'physical_extrema_not_independently_verified':True,
        'other_working_point_locks_not_inferred_from_model_name':True,
        'no_PDF_or_table_written':True,'catalogue_graphic_acceptance':'CHUA_CHAY'}
    output = ROOT/'work/root_qh_check/ROOT KIEM120 SO VA26 O DE XUAT6SL25 - CHUA SUA CATALOGUE.json'
    output.parent.mkdir(exist_ok=True)
    with output.open('x',encoding='utf8') as stream:
        json.dump(report,stream,ensure_ascii=False,indent=2)
    print(json.dumps({'report':str(output),'sha256':sha(output),'plan_numeric_checks':'120 số/110 cặp/26 ô thay/94 giữ',
         'physical_extrema':'CHƯA THỂ','catalogue_written':False},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
