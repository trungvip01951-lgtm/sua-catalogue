"""Render all 62 original axis words against true RAM, without mutation."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from PIL import Image, ImageDraw
from g04_perotac_source9_eta_union_builder77 import prepare, memory_bytes, NAME
from g04_perotac_whole_pdf_tools46 import read, sha
from g04_perotac_whole_actual_read50 import render_document
import pymupdf as fitz, json, hashlib

base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'RAMV4 DOC LAI CA62 CUM CHU TRUC SOURCE ACTUAL CHI DOC'
ed,R,cv,content,cliponly,report=prepare(S);blob=memory_bytes(ed,content)
axis=read(report['axis_report_path']);records=[];groups={1:[],2:[],3:[],4:[]}
kept={m for i in report['source_literal_islands_all'] for m in i['preserved_source_bank_keys']}
with fitz.open(S.src(NAME)) as source,fitz.open(stream=blob,filetype='pdf') as actual:
    for w in axis['words']:
        key=w['key'];b=w['source_native_box'];context=[b[0]-1,b[1]-1,b[2]+1,b[3]+1]
        a,m=render_document(source,7,600,list(cv.rect(context)));z,n=render_document(actual,7,600,list(cv.rect(context)))
        assert a.shape==z.shape and m==n
        factor=2 if a.shape[0]<150 and a.shape[1]<250 else 1
        left=Image.fromarray(a).resize((a.shape[1]*factor,a.shape[0]*factor),Image.Resampling.NEAREST)
        right=Image.fromarray(z).resize(left.size,Image.Resampling.NEAREST)
        tile=Image.new('RGB',(left.width*2+35,left.height+52),'white');dr=ImageDraw.Draw(tile)
        dr.text((5,5),key+' SOURCE / ACTUAL RAM V4',fill='black')
        dr.text((5,20),'ORIGINAL SOURCE ISLAND' if key in kept else 'OWN SOURCE CONTOUR: GRAPHIC ACCEPTANCE PENDING',fill='black')
        tile.paste(left,(0,40));tile.paste(right,(left.width+30,40))
        path=Path(fresh(root/(key+' NGUON VA ACTUAL600 CUM DAY DU.png')));tile.save(path)
        row=dict(key=key,literal=w['literal_source_read'],original_word_native_box=b,context_native_box=context,
            true_render_dpi=600,nearest_pixel_display_scale=factor,original_source_island=key in kept,
            source_actual_image_path=str(path),source_actual_image_sha256=sha(path),
            true_glyph_shape_content_counter_stroke_graphic_result='CHUA NGHIEM THU - require actual visual source comparison',
            JPEG_original_font_program_UNKNOWN=True,no_alpha_area_or_ideal_font_acceptance_inferred=True)
        records.append(row)
        group=1 if key.startswith(('Q US','Q IMP')) else 2 if key.startswith(('Q M3','Q LMIN')) else 3 if key.startswith(('H FEET','H M','ETA ')) and key!='ETA UNIT' else 4
        groups[group].append((tile,row))
for group,tiles in groups.items():
    if group==4:continue
    width=max(t.width for t,_ in tiles);height=max(t.height for t,_ in tiles)
    columns=3;rows=(len(tiles)+columns-1)//columns
    sheet=Image.new('RGB',(columns*(width+10),rows*(height+10)),'white')
    for i,(tile,row) in enumerate(tiles):sheet.paste(tile,((i%columns)*(width+10),(i//columns)*(height+10)))
    path=Path(fresh(root/(f'{group:02} ATLAS CUM TRUC NGUON ACTUAL600 DAY DU.png')));sheet.save(path)
doc=dict(stage='READ-ONLY ALL62 WORDS SOURCE vs ACTUAL CATFIX RAM V4; NO ALL-PASS CLAIM',
    source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)),prepared_content_sha256=hashlib.sha256(content).hexdigest(),
    original_axis_bank_path=report['axis_report_path'],original_axis_bank_sha256=report['axis_report_sha256'],
    source_word_count=len(records),source_literal_word_count=len(kept),single_island_count=len(report['source_literal_islands_all']),
    new_axis_literal_count=sum(o['kind']=='axis_literal' for o in report['new_objects']),
    only_new_contour_removed='ETA 60',words=records,all_words_visual_acceptance_PENDING=True,
    saved_PDF_count=0,source_current_bank_writer_and_progress_unchanged=True)
p=Path(fresh(root/'DOC LAI62 CUM CHU TRUC SOURCE ACTUAL RAMV4 CHI DOC.json'));p.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf8')
print('WORDS',len(records),'ORIGINAL LITERALS',len(kept),'NEW AXIS',doc['new_axis_literal_count'],'REPORT',p,'SHA256',sha(p),flush=True)
ed.close()
