"""Prepare ROOT-authorized single Eta(%)+60 island in fresh RAM code."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
import ast, json, hashlib

work=Path(__file__).resolve().parent
def replace_once(text,old,new):
    assert text.count(old)==1,(old[:100],text.count(old))
    return text.replace(old,new)

builder=(work/'g04_perotac_source9_left_halo_builder70.py').read_text(encoding='utf8')
builder=replace_once(builder,"        original_box=list(literal['source_native_box'])\n        clip_box=list(original_box)",
    "        original_box=list(literal['source_native_box'])\n        source_members=[key]\n        combined_literal=literal['literal_source_read']\n        if key=='ETA UNIT':\n            assert original_box==[85,577,123,593]\n            eta60=next(word for word in axisdoc['words'] if word['key']=='ETA 60')\n            assert eta60['source_native_box']==[108,591,123,604] and eta60['literal_source_read']=='60'\n            original_box=[85,577,123,604]\n            source_members=['ETA UNIT','ETA 60']\n            combined_literal=literal['literal_source_read']+'\\n'+eta60['literal_source_read']\n        clip_box=list(original_box)")
builder=replace_once(builder,"        source_islands.append(dict(key=key,literal_source_read=literal['literal_source_read'],",
    "        source_islands.append(dict(key=key,literal_source_read=combined_literal,\n            preserved_source_bank_keys=source_members,\n            original_source_member_boxes=[dict(key=k,literal_source_read=next(w for w in axisdoc['words'] if w['key']==k)['literal_source_read'],source_native_box=next(w for w in axisdoc['words'] if w['key']==k)['source_native_box']) for k in source_members],\n            union_source_island_no_overlapping_Wstar_rectangles=True,")
builder=replace_once(builder,"        if axis['key'] in KEEP_SOURCE_LITERAL_KEYS:continue",
    "        if axis['key'] in KEEP_SOURCE_LITERAL_KEYS or axis['key']=='ETA 60':continue")
builder_path=Path(fresh(work/'g04_perotac_source9_eta_union_builder77.py'));ast.parse(builder);builder_path.write_text(builder,encoding='utf8')

reader=(work/'g04_perotac_source9_left_halo_actual71.py').read_text(encoding='utf8')
reader=replace_once(reader,'from g04_perotac_source9_left_halo_builder70 import','from g04_perotac_source9_eta_union_builder77 import')
reader=replace_once(reader,'RAM CATFIX NGUON9 DAO V3 GIU QUANG200 CHUA LUU PDF','RAM CATFIX NGUON9 DAO V4 ETA60 NGUYEN CUM CHUA LUU PDF')
reader=replace_once(reader,'CATFIX NGUON9 DAO RAM V3 DOC LAI MUC THAT VA NGOAI VUNG.json','CATFIX NGUON9 DAO RAM V4 DOC LAI MUC THAT VA NGOAI VUNG.json')
reader_path=Path(fresh(work/'g04_perotac_source9_eta_union_actual78.py'));ast.parse(reader);reader_path.write_text(reader,encoding='utf8')

edge=(work/'g04_perotac_source9_full_halo72.py').read_text(encoding='utf8')
edge=replace_once(edge,'from g04_perotac_source9_left_halo_builder70 import','from g04_perotac_source9_eta_union_builder77 import')
edge=replace_once(edge,"root=base/'RAMV3 KIEM TOAN9 MEP VA HALO NGOAI2PIXEL CHI DOC'","root=base/'RAMV4 KIEM TOAN9 DAO10 CUM VA HALO NGOAI2PIXEL CHI DOC'")
edge=replace_once(edge,'RAM CATFIX NGUON9 DAO V3 GIU QUANG200 CHUA LUU PDF/CATFIX NGUON9 DAO RAM V3 DOC LAI MUC THAT VA NGOAI VUNG.json','RAM CATFIX NGUON9 DAO V4 ETA60 NGUYEN CUM CHUA LUU PDF/CATFIX NGUON9 DAO RAM V4 DOC LAI MUC THAT VA NGOAI VUNG.json')
edge=replace_once(edge,"assert report['new_objects']==old['new_objects'], 'New glyph/QH/grid/eta path or style changed'",
    "def without_indexes(row):\n    return {k:v for k,v in row.items() if k not in {'group_instruction_start','group_instruction_end'}}\nexpected_new_objects=[r for r in old['new_objects'] if not (r['kind']=='axis_literal' and r['key']=='ETA 60')]\nassert [without_indexes(r) for r in report['new_objects']]==[without_indexes(r) for r in expected_new_objects], 'Unexpected glyph/QH/grid/eta path or style change'")
old="""        for p in words[key]['contour_paths']:
            if p['parent']>=0: continue
            path=np.asarray(p['local_native_xy'])+np.array(ob[:2])
            gb=np.r_[path.min(0),path.max(0)].tolist();glyph_boxes.append(gb)
            seed|=((points>=np.array(gb[:2])-1)&(points<=np.array(gb[2:])+1)).all(2)"""
new="""        for member_key in island['preserved_source_bank_keys']:
            member_word=words[member_key];member_box=member_word['source_native_box']
            for p in member_word['contour_paths']:
                if p['parent']>=0: continue
                path=np.asarray(p['local_native_xy'])+np.array(member_box[:2])
                gb=np.r_[path.min(0),path.max(0)].tolist();glyph_boxes.append(gb)
                seed|=((points>=np.array(gb[:2])-1)&(points<=np.array(gb[2:])+1)).all(2)"""
edge=replace_once(edge,old,new)
edge=replace_once(edge,'all383_new_paths_styles_glyphs_QH104_eta_and_grid_unchanged=report[\'new_objects\']==old[\'new_objects\'],',
    "all382_retained_paths_styles_glyphs_QH104_eta_and_grid_unchanged=[without_indexes(r) for r in report['new_objects']]==[without_indexes(r) for r in expected_new_objects],\n    only_removed_new_object='axis_literal ETA 60',single_merged_Eta_percent_and60_source_island=True,")
edge=edge.replace('RAM V3','RAM V4').replace('RAMV3','RAMV4')
edge_path=Path(fresh(work/'g04_perotac_source9_eta_union_halo79.py'));ast.parse(edge);edge_path.write_text(edge,encoding='utf8')

manifest=dict(stage='ROOT AUTHORIZED RAM ONLY; NO PDF',
    source_sha256=hashlib.sha256(Path(S.src('Perotac bơm giếng SA_compressed (bản mới).pdf')).read_bytes()).hexdigest(),
    canonical_sha256=hashlib.sha256(Path(S.result('Perotac bơm giếng SA_compressed (bản mới).pdf')).read_bytes()).hexdigest(),
    unchanged_H200_half_pixel_left_extension=True,unchanged_total_ROI=True,
    source_Eta_percent_and60_single_union_native_box=[85,577,123,604],no_overlapping_Wstar_islands=True,
    omitted_new_contour_key='ETA 60',original_axis_bank_unchanged=True,
    historical_writer65_and_manifest_not_changed_or_run=True,
    fresh_scripts=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [builder_path,reader_path,edge_path]],
    all_prepared_code_syntax_checked=True,saved_PDF_count=0,progress_written=False)
out=Path(fresh(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAMV4 CHUAN BI DAO ETA60 NGUYEN CUM/CHUAN BI BUILDER77 READER78 HALO79 CHUA LUU PDF.json')))
out.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(manifest,ensure_ascii=False),flush=True)
