"""Independent closed-form lower bound + inverse local-axis readback."""
from catwork import start, fresh
S,D,N=start()
from pathlib import Path
from PIL import Image
from bisect import bisect_right
import csv,json,math
import numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_audit_data import DATA
from g04_perotac_whole_pdf_tools46 import read,sha

NAME='Perotac bơm giếng SA_compressed (bản mới).pdf'
WORK=Path(r'D:\ChatGPT\Sửa catalogue\work\g03_sa_p2p3_qh_giam_nguyen_v1')
planpath=WORK/'02 PHUONG AN NGUYEN GIAM14 HANG161 O VA TOA DO TRUOC SAU.json'
plan=read(planpath)
assert plan['source_current_after']==dict(source=sha(S.src(NAME)),current=sha(S.result(NAME)))
probe=read(WORK/'01 NGUON THAT KHOA VA LUOI BANG CHI DOC.json')
old=read(probe['older_readonly161_node_plan']['path'])
certificates=[]
for r in plan['source14_rows161_H_cells']+plan['p8_table13_rows104_H_cells']:
    oldH=r['H_source_m'];newH=r['H_proposed_m'];Hmax=oldH[0]
    upper=[Hmax-i for i in range(len(oldH))]
    forced=[max(0,h-u) for h,u in zip(oldH,upper)]
    nearest=[h-d for h,d in zip(oldH,forced)]
    # Every strictly descending integer sequence with fixed initial Hmax
    # has H[i] <= Hmax-i. This gives a per-cell lower bound even if another
    # method permits upward edits. The proposed sequence attains all bounds.
    assert newH==nearest and all(newH[i-1]>newH[i] for i in range(1,len(newH)))
    assert sum(forced)==r['solver']['total_absolute_change_m']
    assert max(forced)==r['solver']['minimal_maximum_absolute_change_m']
    assert sum(d>0 for d in forced)==r['solver']['changed_cell_count']
    assert newH[0]==max(oldH) and newH[-1]==min(oldH)
    assert newH[0]-newH[-1]>=len(newH)-1
    source=next(d for d in DATA if d['family']==r['family'])
    srcrow=next(z for z in source['rows'] if z['model']==r['model'])
    assert oldH==srcrow['H'] and r['Q_m3_h']==source['Q_m3_h']
    certificates.append(dict(model=r['model'],source_H=oldH,proposed_H=newH,
        independent_integer_upper_bound=upper,mandatory_minimum_downward_edit_m=forced,
        optimal_maximum_edit_proven=max(forced),optimal_total_edit_proven=sum(forced),
        optimal_changed_cells_proven=sum(d>0 for d in forced),
        proof='H[i]<=Hmax-i for any strictly decreasing integer sequence with locked H[0]. Proposed source-nearest values attain every per-cell bound and all constraints.',
        additional_working_point_condition_UNRESOLVED=True,
        catalogue_edited_or_accepted=False))

def inverse_at_native(v,ticks):
    # Ordered by decreasing native y; choose actual bracketing source ticks.
    for a,b in zip(ticks,ticks[1:]):
        va=a['source_gray_core_center_native'];vb=b['source_gray_core_center_native']
        if vb-1e-9<=v<=va+1e-9:
            return a['printed_H_m']+(v-va)/(vb-va)*(b['printed_H_m']-a['printed_H_m'])
    raise AssertionError('Native coordinate outside independently read source H axis')

nodechecks=[]
for c in plan['all265_table_cell_records']:
    if c['page']==8:continue
    axis=next(r for r in old['records'] if r['page']==c['page'])
    for label,hkey,ckey in [('source','H_source_m','before_source_table_target_coordinate'),('proposed','H_proposed_m','after_proposal_table_target_coordinate')]:
        readH=inverse_at_native(c[ckey]['native_v'],axis['local_head_tick_measurements'])
        assert abs(readH-c[hkey])<1e-9
    nodechecks.append(dict(model=c['model'],Q_m3_h=c['Q_m3_h'],
        H_source=c['H_source_m'],H_proposed=c['H_proposed_m'],
        local_axis_inverse_source_and_proposal_exact=True,
        source_uncertainty_native_px=1,current_visible_curve_ink_not_remeasured=True))
csvpath=WORK/'03 TOA DO161 MOC BANG TRUOC SAU CHUA VE.csv'
with csvpath.open(encoding='utf-8-sig',newline='') as f:csvrows=list(csv.DictReader(f))
assert len(csvrows)==161
assert len({(r['model'],r['Q_m3_h']) for r in csvrows})==161
assert sum(float(r['delta_H_m'])!=0 for r in csvrows)==34
assert len(plan['source_12_equal_pairs'])==12
assert len(plan['source_10_problem_models'])==10
assert all(r['changed_pixels_threshold0']==0 for r in plan['actual_PDF_source_current_H_table_readback200'])
mdpath=WORK/'04 BAO CAO8 COT SA10 MA12 CAP BANG PHUONG AN34 O.md'
eight=[line for line in mdpath.read_text(encoding='utf8').splitlines() if line.startswith('|')]
assert len(eight)==12 and all(len(line.split('|'))==10 for line in eight)

# Separate neighboring source readback; no new proposal or state update.
# This does not alter or expand the ten-model proposal.
neighbor=next(d for d in DATA if d['family']=='3SS2')
neighbor_pairs=[]
for row in neighbor['rows']:
    for i in range(1,len(row['H'])):
        if row['H'][i]>=row['H'][i-1]:
            neighbor_pairs.append(dict(model=row['model'],Q_left_m3_h=neighbor['Q_m3_h'][i-1],Q_right_m3_h=neighbor['Q_m3_h'][i],
                H_left=row['H'][i-1],H_right=row['H'][i],
                status='SOURCE READBACK ONLY - out of ten-model proposal; actual continuous curve needs checking',
                numeric_change_proposed=False))
assert len(neighbor_pairs)==4 and len({r['model'] for r in neighbor_pairs})==3
E=Editor(S.src(NAME),backend='fitz');R=Raster(E)
im=max(R.images(1),key=lambda z:z.W*z.H);raw=R.canvas(im).orig
neighbor_png=Path(fresh(WORK/'3SS2 BANG NGUON4 CAP BANG NGOAI10 MA CHI PHAT HIEN.png'))
Image.fromarray(raw[638:890,962:1695]).resize((733*3,252*3),Image.Resampling.NEAREST).save(neighbor_png)
E.close()
after=dict(source=sha(S.src(NAME)),current=sha(S.result(NAME)))
assert after==plan['source_current_before']
report=dict(stage='INDEPENDENT NUMBER-PROPOSAL QA ONLY; NOT CATALOGUE ACCEPTANCE',
    plan_path=str(planpath),plan_sha256=sha(planpath),report8_path=str(mdpath),report8_sha256=sha(mdpath),
    csv161_path=str(csvpath),csv161_sha256=sha(csvpath),
    independent_closed_form_optimality_certificates=certificates,
    p2p3_inverse_actual_local_source_tick_readback_161_nodes=nodechecks,
    ten_problem_models_and12_equal_pairs_preserved=True,all14_rows161_source_values_readback=True,
    optimal_34_source_cell_edits_max2_proven=True,
    p2p3_extrema_and_3_ROOT_named_final_points_unchanged=True,
    ROOT_connecting_anchor_3SS3_37_Q3_3_H75_kept=True,
    original_groups_tasks_do_not_supply_additional_rated_point=True,
    source8_column_report_shape_verified=True,
    p8_table_only13_rows104_cells_strict_decrease_PASS=True,
    p8_all_continuous_current_or_saved_uniform_plot_new_rule_NOT_RUN=True,
    p8_RAM_font_still_FAIL_and_whole_chart_PDF0=True,
    adjacent_3SS2_source_plateau_pairs_NOT_in_current_proposal=neighbor_pairs,
    adjacent_3SS2_source_evidence=dict(path=str(neighbor_png),sha256=sha(neighbor_png),native_box=[962,638,1695,890]),
    source_current_after=after,shared_progress_changed=False,PDF_table_font_written=False)
out=Path(fresh(WORK/'05 KIEM DOC LAP CAN DUOI SO NGUYEN VA161 TOA DO.json'))
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('INDEPENDENT QA',out,'SHA256',sha(out),'CERTIFICATES',len(certificates),'NODES',len(nodechecks),'OPTIMAL34','SOURCE_UNCHANGED','PDF0',flush=True)
print('ADJACENT3SS2 OUTSIDE PROPOSAL',neighbor_pairs,flush=True)
