"""Write only the separately assigned project QA note; no CATFIX/ledger/manifest."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json

root=Path(r'D:\ChatGPT\Sửa catalogue').resolve()
target=root/'work'/'g18_project_qa'/'BAI_HOC_SL_VA_KIEM_NGHIEP_VU.md'
assert target.resolve().is_relative_to(root/'work'/'g18_project_qa') and not target.exists()
workspace=Path(__file__).resolve().parent
G=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 03-10-2026 (ChatGPT)\_BAO CAO\G04')
M=G/'REDPUMP DONG BO TOAN TRANG8 MAU1';I=M/'13 CAPTION NGUYEN NGUON DAO RAM LAN2B'
A=G/'KIEM TOAN REDPUMP TOAN BO';Q=A/'6SL25 Q27 DOC ACTUAL600 RIENG LAN3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
evidence={
    'E01':I/'BAN GIAO13 DAO NGUON VA5 GIOI HAN KHONG PDF2.json',
    'E02':I/'CATFIX13 CAPTION DAO NGUYEN NGUON DOC RAM FULL MEP.json',
    'E03':I/'SOI NET CHAM VA TAT CA MEP LAN1'/'SOI13 CAPTION TAT CA MEP VA5 MUC CHAM NGUYEN NGUON.json',
    'E04':I/'BAO CAO8 COT13 DAO NGUON VA5 CHUA THE KHONG PDF2.md',
    'E05':M/'PHUONG AN LO VACH PHU TRUOC SAU VA THU RAM.json',
    'E06':M/'DOC ACTUAL PDF MAU1 104 NEO VA BAO TOAN.json',
    'E07':A/'1931 O NGUON DINH VI VA DOI CHIEU V2.json',
    'E08':G/'ROOT DOC BA O MO'/'DOC NGUON LAN1'/'ROOT XAC NHAN BA O BANG V2.json',
    'E09':Q/'PHUONG AN6SL25 TOAN BIEU DO CHUA VE VA TRANG THAI DUNG.json',
    'E10':A/'RA SOAT HO SO17 NGOAI TRANG8 LAN1'/'MA TRAN17 BIEU DO VA PHAM VI NGOAI TRANG8.json',
    'E11':workspace/'g04_redpump_whole_caption_island_RAM_builder.py',
    'E12':Path(r'D:\TempSystem\catfix_work\catfix_pkg\GOI_SUA_CATALOGUE_CHATGPT\catfix\raster.py'),
    'E13':I/'TOAN QH ETA RAM150 KHONG PDF2.png',
    'E14':I/'SOI NET CHAM VA TAT CA MEP LAN1'/'5 CUM MUC CHAM GLYPH NGUYEN SOURCE CURRENT RAM600.png',
}
hashes={k:sha(p) for k,p in evidence.items()}
assert hashes['E01']=='71d5d432114c5d8246831dfbdca57ea73cd9b97fbdef500adc75d31fba2ea158'
assert hashes['E04']=='c27ad98b3e2e36394c63518201bb126e363779af8fb3d4deebef18e0ceaae2ec'
docs=['AGENTS.md','START_HERE.md','README.md','CLAUDE.md','rules/QUY_TAC_ANH_TRUNG.md','rules/PHOI_HOP_CHATGPT_CLAUDE.md',
    'procedures/QUY_TRINH_SUA_VA_NGHIEM_THU.md','procedures/DUONG_DAC_TINH.md','procedures/EXCEL.md','procedures/ANH_SAN_PHAM.md',
    'templates/BAO_CAO8_COT.md','templates/BAN_GIAO.md','tools/catalogue.py','tools/bootstrap_legacy.py']
doc_hashes={x:sha(root/x) for x in docs}
doc_text={x:(root/x).read_text(encoding='utf8') for x in docs}
assert 'giữ xu hướng từng đoạn' in doc_text['procedures/DUONG_DAC_TINH.md']
assert doc_hashes['procedures/DUONG_DAC_TINH.md']=='d0f598e0b8491f1f727f397a1eaf41342c318674287ddb3c364e91622f0685c7'
iso=J(evidence['E01']);ram=J(evidence['E02']);foot=J(evidence['E05']);table=J(evidence['E07']);local=J(evidence['E09']);coverage=J(evidence['E10'])
source=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 01-10-2026\Giếng\Redpump gieng SL_compressed (bản mới).pdf')
current=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 03-10-2026 (ChatGPT)\Giếng\Redpump gieng SL_compressed (bản mới).pdf')
sample=M/current.name
catalogue_hashes={str(p):sha(p) for p in [source,current,sample]}
assert list(catalogue_hashes.values())==[iso['source_SHA256'],iso['current_SHA256'],iso['M1_SHA256']]
assert len(iso['graphic5_not_completed'])==5 and iso['M2_written'] is False and len(iso['QH104_clip_coverage_check'])==104
assert ram['outside200_threshold0_pad0']['outside_changed_pixels']==0
assert len(foot['records'])==5 and all(x['padding_pt']==.48 for x in foot['records'])
inc={}
for cell in table['cells']:
    if cell['model'] in ['6SL25/12','6SL25/14','6SL25/16','6SL25/18','6SL25/20'] and cell['Q'] in [0,3]:inc.setdefault(cell['model'],{})[cell['Q']]=cell['H_source']
assert len(inc)==5 and all(x[3]==x[0]+1 for x in inc.values())
when=datetime.now(timezone(timedelta(hours=7))).isoformat(timespec='seconds')
def link(p,label=None,line=None):return f"[{label or Path(p).name}](<{str(p).replace(chr(92),'/')}{':'+str(line) if line else ''}>)"
def L(rel,line):return link(root/rel,rel,line)

lines=[
'# Bài học SL và kiểm nghiệp vụ — phiếu riêng trước khi chốt kho dự án',
'',
f'Người viết: tác nhân `g18_nghiem_thu` của ChatGPT. Thời điểm đọc: {when}.',
'',
'**Không đưa cách 13 đảo chữ SL vào danh sách cách đã nghiệm thu.** Bản xem trong bộ nhớ vẫn có 5 cụm chưa thể đồng bộ mực; PDF mẫu 2 chưa được tạo. Phiếu này góp ý cho tài liệu nháp v1, không sửa tài liệu chính, sổ tiến độ hoặc danh mục niêm phong dự án.',
'',
'Đã đọc toàn bộ 12 tài liệu hướng dẫn/quy tắc/quy trình/mẫu và hai chương trình khởi động–phối hợp hiện có; đối chiếu hồ sơ SL, dữ liệu từng ô và các ảnh đã soi trong lượt xử lý SL vừa bàn giao. Tài liệu G01 trong work được xem để tránh lặp ý, không lấy đó làm nghiệm thu SL. Không chạy chương trình ghi PDF hoặc import chương trình tác vụ có lệnh ghi ở cấp mô-đun.',
'',
'## 1. Những câu thiếu hoặc có nguy cơ bị dùng sai',
'',
'| Mã | Ưu tiên | Tài liệu/dòng | Hiện trạng | Rủi ro nghiệp vụ | Đề nghị bổ sung hoặc thay | Chứng cứ | Trạng thái |',
'|---|---|---|---|---|---|---|---|',
f'| SL01 | Cao | {L("procedures/DUONG_DAC_TINH.md",15)} | Bản đầu ghi “H giảm theo Q”; ROOT đã sửa trong lúc rà | Ép giảm làm sai các số tăng nhẹ đúng bảng | Giữ câu mới “giữ xu hướng từng đoạn”; thêm 5 ví dụ nguồn ở phần2 dưới | E07, E09 | ĐÃ SỬA VÀ ĐỌC LẠI câu mới; chưa phải nghiệm thu toàn kho |',
f'| SL02 | Cao | {L("procedures/DUONG_DAC_TINH.md",31)} | Có cảnh báo cắt trọn chữ sẽ giữ mẩu đường cũ, nhưng chưa khóa kết quả SL cụ thể | Phiên sau chọn 13 đảo làm cách đạt chỉ vì ảnh gốc nguyên byte | Ghi rõ SL p8: 13 đảo thử trong bộ nhớ, 5 cụm /23,/11,/8,/5,/4 CHƯA THỂ đồng bộ tại chỗ; 8 cụm khác CHƯA CHỐT; DỪNG cách hiện tại | E01–E04, E13–E14 | CẦN GẮN VÀO KIẾN THỨC/TRẠNG THÁI |',
f'| SL03 | Cao | {L("procedures/QUY_TRINH_SUA_VA_NGHIEM_THU.md",31)} và dòng34 | Đã tách bảo toàn với số/hình thức, nhưng chưa có ví dụ phản chứng mạnh | Ngoài vùng0 hoặc ảnh/CTM nguyên bị nâng thành phông/hình thức ĐẠT | Thêm: “0 điểm ngoài vùng, byte ảnh nguyên, lõi chữ không đổi chỉ chứng đúng phần bảo toàn đã đo; phải kiểm chữ/biên/giao nét độc lập” | E01–E04 | CẦN BỔ SUNG VÍ DỤ SL |',
f'| SL04 | Cao | {L("procedures/QUY_TRINH_SUA_VA_NGHIEM_THU.md",34)}; mẫu bàn giao | Chưa có dòng bắt buộc phân biệt “giữ nguyên dấu vết” với “mới nghiệm thu” | 104 mốc hoặc 26 nét được cộng lần nữa; giữ hình học bị coi là giữ toàn mực nhìn thấy | Ghi riêng kết quả M1 kế thừa theo SHA; 26 nét giữ, 104 neo không bị lỗ che là kiểm bảo toàn. Hình thức mới vẫn chưa đạt/chưa thể | E01, E02, E06 | CẦN TÁCH PHẠM VI VÀ GIAI ĐOẠN |',
f'| SL05 | Cao | {L("procedures/QUY_TRINH_SUA_VA_NGHIEM_THU.md",36)} | Đã cấm bỏ2 điểm mép; còn thiếu cách gọi tên hộp nguồn và hộp bảo vệ đã nới | Mượn nới0,48pt của vạch feet để nới đảo chữ, che lỗi hoặc tuyên bố mọi hộp0 | Khóa riêng từng hộp nguồn/hộp clip và phép giao. Nới0,48pt chỉ đã thử cho 4 vạch feet + đáy0 của SL; không là luật cho glyph/ảnh/nhãn | E01, E03, E05 | CẦN BỔ SUNG PHẠM VI ROI |',
f'| SL06 | Cao | {L("procedures/DUONG_DAC_TINH.md",38)} | “/20 có sai lệch chắc theo phép đo” thiếu cấp nghiệm thu và số đo | Phiên sau hiểu là ROOT đã kiểm độc lập hoặc đã được phép dựng toàn6SL25 | Thêm: phép đọc LAN3 của tác nhân: /20 CHƯA ĐẠT theo biên đã đo; /16 CHƯA THỂ. ROOT đọc độc lập, Q33, chữ/nét/η còn thiếu; chưa tạo mẫu, chưa sửa bảng | E09 | CẦN GHI RÕ CẤP NGHIỆM THU |',
f'| SL07 | Vừa | {L("procedures/QUY_TRINH_SUA_VA_NGHIEM_THU.md",7)} | Định vị và tự nhìn ảnh đã có; thiếu bắt buộc cả tên hàng/đầu cột trong ảnh chứng ô | Lặp lỗi crop sai dòng/đảo y, đọc76 thành78 từ ô lẻ | Số nghi ngờ phải có ảnh cùng tên model, tên cột Q và ô, kèm tọa độ gốc và nguồn SHA. Ô chắc không đồng nghĩa cả đường đạt | E07, E08 | CẦN THÊM MẪU CHỨNG Ô |',
'| SL08 | Vừa | knowledge/LOI_VA_CACH_TRANH.md và danh mục mã sắp tạo | Chưa có bài học về key/index của PageImage | Ảnh nguyên byte có tài nguyên nhưng không được vẽ trong đảo | PageImage.key là định danh trang; PageImage.index là chỉ số lệnh Do. Chọn và kiểm ảnh bằng byte/name/CTM cùng lệnh thực; luôn render kiểm thấy13 tên | E02, E11, E12 | CẦN LƯU LỖI KỸ THUẬT THẬT |',
f'| SL09 | Vừa | {L("START_HERE.md",47)}; bảng phương pháp | Đã cấm chạy mã chỉ vì có FINAL; cần phân loại rõ đoạn nghiên cứu và ghi thật | Hàng loạt RAM V5–V10 làm người tiếp quản tưởng có PDF2 hoặc cách mới không còn giới hạn | Ghi số PDF theo phương pháp, SHA tệp thật; giữ RAM lịch sử đã loại. Chỉ import helper thuần không tác vụ cấp mô-đun; không đổi tên để tiếp tục contour vô hạn | E01, E04, E11 | CẦN GẮN TRẠNG THÁI/MÃ ĐƯỢC CHỌN |',
'| SL10 | Vừa | knowledge/state sắp tạo và giới hạn DUONG_DAC_TINH | SA và SL trùng số183/1827 nhưng là hai bộ nguồn riêng | Chép số/nhãn/trục Perotac vào Redpump; cộng các phép đọc ứng viên thành số đạt | SL riêng:17 biểu đồ196 model1931 ô; ngoài p8 là16/183/1827. 156 danh tính khóa/27 chưa chắc trong hồ sơ rà. 51 đường/540 mốc bám thử không phải nghiệm thu số | E07, E09, E10 | CẦN THÊM DÒNG SL RIÊNG |',
'',
'Các đề nghị là bổ sung bằng chứng và cách chống hiểu sai; không sửa quyền anh đã giao và không mở rộng quyền tác nhân. Những câu đã đúng cần giữ: chỉ catfix ghi catalogue, một tác nhân/tệp, người điều phối giữ sổ, chặn đầu vào đổi, thiếu nguồn/phông ghi chưa thể, hai mẫu PDF thất bại thì dừng, không tự cài.',
'',
'## 2. Trạng thái SL phải được mang sang kho chung',
'',
'**Tệp hiện hành và mẫu thực:**',
'',
*[f'- {link(p)} — SHA-256 `{h}`.' for p,h in catalogue_hashes.items()],
'',
'M1 là PDF mẫu toàn p8 duy nhất của phương pháp dựng toàn miền; ROOT đã đọc 13 đường/104 mốc. Các bản trong bộ nhớ sau đó sửa η, vạch feet và thử chữ không phải PDF mẫu2. Bản giao vẫn giữ mã `b7c1…d435`; chưa nhận toàn13 đường M1 vào bản giao. 26 dấu vết nét hình học giữ nguyên là hai phần liền/đứt của13 đường, không phải26 model.',
'',
'13 đảo nguyên cụm giữ dữ liệu ảnh/cỡ/vị trí nguồn. Nét cũ trong cùng JPEG chạm chữ ở /23,/11,/8,/5,/4; không loại được bằng giữ trọn cụm. Dây dẫn nhãn chỉ giúp gán tên, không tách mực cũ khỏi điểm ảnh chữ. Không dùng9V7 từng đạt riêng để suy cả bộ nguồn đạt; không dùng contour5/2 đã bị bác. Phương pháp hiện tại dừng với5 cụm CHƯA THỂ và8 cụm CHƯA CHỐT hình thức.',
'',
'Kiểm ngoài vùng RAM:200 điểm ảnh mỗi inch, ngưỡng0, đệm0, **0 điểm đổi ngoài miền**. 66 lần đặt ảnh nguồn/mặt nạ/ma trận, luồng XMP, liên kết, khổ và10 trang khác giữ. Kết quả đó vẫn cùng tồn tại với hình thức chữ chưa đạt. Lõi xám dưới100 không đổi ở13 tên; toàn mép150 có0–94 điểm đổi/hộp và600 có0–103. Không loại2 điểm mép, không gọi lõi giống là toàn glyph/phông giống.',
'',
'104 neo được ROOT đọc tại M1 nằm ngoài lỗ caption ít nhất0,792pt theo kiểm phủ, lớn hơn bán kính nét0,475pt; đó là bảo toàn phủ mực tại neo, không kiểm mới toàn đường nhìn thấy sau lỗ clip. Trình đọc phải kiểm cả giao nét/nhịp/độ đậm và tên trên ứng viên thật sau lưu nếu có phương pháp mới được chốt.',
'',
'**Vạch feet và hộp nguồn:** 4 vạch có số400/300/200/100 feet (đơn vị foot) cùng vạch0 ghép đáy tạo5 vùng bảo vệ trong SL. Nới0,48pt chỉ sau đọc nguồn riêng và kiểm không giữ mực đường cũ. 15 ảnh150/200/600 của chính hộp nguồn có0 điểm đổi. Không chuyển padding này sang13 đảo chữ. Đảo chữ thử có cách chọn hộp riêng nhưng chưa đạt; không biến nó thành luật nới chung.',
'',
'Title (khối tiêu đề) ở đúng hộp nguồn `[228.06463548016097,488.2981212611156,355.0665066767002,507.983689571544]`pt có0 điểm đổi ở150/200/600. Hộp clip đã nới quanh title lại có282/405/1238 điểm đổi tại phần lề cho phép dựng. Vì vậy báo cáo phải nêu rõ đang kiểm hộp nào. PNG lịch sử tên “KHOI TIEU DE…KHONG DOI” là hộp nới và đã được cảnh báo trong E01/E04; không dùng tên đó làm chứng0 điểm.',
'',
'**Số tăng nhẹ đúng nguồn6SL25:**',
'',
'| Model | H tại Q0 m³/h | H tại Q3 m³/h | Cách xử lý đúng |',
'|---|---:|---:|---|',
*[f'| {model} | {v[0]}m | {v[3]}m | Giữ tăng1m theo chính bảng Redpump; không ép giảm |' for model,v in inc.items()],
'',
'Câu cũ “H giảm theo Q” ở bản có SHA `98f8db2ac8fbdc7ad5e362b09af64a9061b36dcd17c20d0882a29de20703b8e6` đã được ROOT đổi. Đã đọc câu mới tại dòng15, SHA `d0f598e0b8491f1f727f397a1eaf41342c318674287ddb3c364e91622f0685c7`. Không tiếp tục đánh dấu câu mới là lỗi còn mở.',
'',
'Ở Q27:6SL25/20 có H bảng150m, H mực158,561393m, sai+8,561393m, bất định bảo thủ±5,021414m, giới hạn3m; còn sai chắc3,539979m nên phép đọc này ghi CHƯA ĐẠT. /16 có H bảng120m, mực126,904620m, sai+6,904620m, bất định±4,807388m, giới hạn2,4m; phần còn2,097232m chưa vượt2,4 nên CHƯA THỂ. E09 ghi rõ còn cần ROOT đọc độc lập. Không nâng cả10 đường thành lỗi hay được phép vẽ. Q33 nằm ngoài vạch m³/h0…30 đã khóa; phải đọc vạch phụ/đơn vị thật, không ngoại suy hệ số fit toàn trục.',
'',
'1931 ô giữ nguyên điểm ảnh chỉ chứng bảng giữ; hồ sơ ngoài p8 chưa đủ phép đo để gọi183 đường đạt. η (hiệu suất) không có bảng số vẫn CHƯA THỂ. 551 tâm η của p8 không chuyển sang6SL25 hoặc16 biểu đồ khác.',
'',
'## 3. Bài học kỹ thuật phải ghi cùng phạm vi, không thành mẹo dùng chung',
'',
'- Tọa độ ảnh/chỉ số trang/lệnh vẽ phải phân biệt. Trong catfix.raster.PageImage, key giữ định danh trang, index giữ chỉ số lệnh Do. RAM LAN2 nhầm hai trường làm không giữ ảnh trong đảo; tài nguyên/raw/CTM vẫn có và ngoài vùng vẫn0. LAN2B sửa đúng index rồi mới thật sự thấy13 cụm. Không nghiệm thu từ tồn tại tài nguyên hoặc cấu trúc.',
'- Toàn ảnh nguyên nguồn có thể mang mực cũ/các lớp chồng. Dò bằng màu chỉ là chẩn đoán; không dùng kênh RGB thành mặt nạ chữ, không tẩy toàn hộp, không khẳng định mọi vệt xám là nét bơm. Cần soi source/current/RAM ở150/600 đủ cả mép.',
'- Chọn mẫu chữ trong cùng tệp vẫn phải chứng kiểu/cỡ/đậm/khoảng tiến và nhìn5/2/9. Bộ V7 từng giữ số9 tốt nhưng5/2 bị bác; V10 có hộp cắt và dáng chưa đạt. Giữ một màu chung không tự làm dáng đạt. Không tiếp tục fit contour chỉ đổi tên V11,V12 để né giới hạn.',
'- Trước import mã trong archive, đọc xem có start/Job/save ở cấp mô-đun hay không. Helper thuần mới an toàn để gọi trong một tác vụ có bootstrap/quyền/guard riêng. `g04_redpump_whole_caption_island_RAM_builder.py` là helper thuần; chưa phải chương trình phát hành catalogue.',
'- Khi ô số nghi ngờ, đủ hàng tên/đầu cột quan trọng hơn ảnh ô phóng lẻ. ROOT đọc chắc4SL3/15 tạiQ3=76,4SL16/4 tạiQ15=15 và4SL16/12 tạiQ6=66 bằng contextV2. ContextV1 đảo y và ô lẻ76 dễ nhìn thành78 phải giữ lịch sử chưa dùng; không sửa theo tỷ lệ tầng hoặc Perotac.',
'',
'## 4. Kiểm kho dự án ở lượt này',
'',
'Không chạy health/status/context/claim/receipt hoặc bootstrap43 trong lượt viết phiếu. ROOT đang soạn và chưa niêm phong manifest/control_manifest; các con trỏ knowledge/state chưa hoàn tất tại thời điểm đọc. Đây là trạng thái lắp kho, không phải bằng chứng health đã đạt hoặc lỗi catalogue. Không tự tạo manifest để làm lệnh chạy được. Phiếu này không phải xác nhận Claude đã đọc kho.',
'',
'Các kiểm nội dung đã làm: đọc lại 14 tệp dự án, đối chiếu SHA nguồn/current/M1 và các hồ sơ E01–E14, kiểm trường status/PDF_written/giới hạn, xác nhận5 hàng nguồn tăng nhẹ và phân biệt5 vùng feet với13 đảo chữ. Không chạy lại43 kiểm thử chỉ để viết Markdown; trước sửa catalogue tiếp theo vẫn phải tuân BƯỚC0/43 theo quy trình hiện hành.',
'',
'Sau khi ROOT bổ sung kiến thức và niêm phong: kiểm lại những câu mới, chạy health theo phân công, rồi người tiếp quản đọc chính tệp/sổ mới nhất. Không tính phiếu này là đã nghiệm thu bản v1 hoàn chỉnh.',
'',
'## 5. Con trỏ bằng chứng và mã kiểm nội dung',
'',
'SHA-256 là mã kiểm nội dung; RAM là bộ nhớ; glyph là hình ký tự; ROI là vùng kiểm/sửa; CTM là ma trận đặt ảnh; PDF là định dạng giữ bố cục; JPEG là ảnh nén; dpi là số điểm ảnh mỗi inch; QA là kiểm chất lượng. Mã kiểm gắn đúng tệp đã đọc, không tự chứng nghiệm thu.',
'',
'| Mã | Tệp thật | SHA-256 đọc lại |',
'|---|---|---|',
*[f'| {key} | {link(path)} | `{hashes[key]}` |' for key,path in evidence.items()],
'',
'**Tài liệu dự án đã đọc trong lượt này:**',
'',
'| Tệp | SHA-256 phiên đọc |',
'|---|---|',
*[f'| {link(root/rel,rel)} | `{h}` |' for rel,h in doc_hashes.items()],
'',
'Đầu ra của tác nhân chỉ là phiếu này trong work/g18_project_qa. Người điều phối tự tiếp nhận các đề nghị phù hợp; không sửa rules/procedures/state/ledger hoặc bản catalogue từ đây.',
]
# Improve spacing in prose only; never alter hashes/paths/links with a regex.
replacements={'5 cụm':'5 cụm','13 đảo':'13 đảo','5cụm':'5 cụm','8cụm':'8 cụm','13đường':'13 đường','10đường':'10 đường',
    '13 tên':'13 tên','0 điểm':'0 điểm','0 điểm đổi':'0 điểm đổi','0 điểm ngoài':'0 điểm ngoài','0 điểm mép':'0 điểm mép',
    'ngưỡng0':'ngưỡng 0','đệm0':'đệm 0','bỏ2':'bỏ 2','chữ/phông':'chữ/phông'}
body='\n'.join(lines)+'\n'
for old,new in replacements.items():body=body.replace(old,new)
# Verify the immutable evidence and documents once more before creating the note.
assert all(sha(p)==hashes[k] for k,p in evidence.items())
assert all(sha(root/rel)==h for rel,h in doc_hashes.items()),'Tài liệu nháp đổi trong lúc rà; đọc lại trước lưu phiếu.'
assert all(sha(p)==h for p,h in catalogue_hashes.items())
target.parent.mkdir(parents=True,exist_ok=True)
with target.open('x',encoding='utf8',newline='\n') as f:f.write(body)
assert target.read_text(encoding='utf8')==body
assert all(sha(p)==h for p,h in catalogue_hashes.items())
print(str(target),flush=True)
print('SHA256',sha(target),'bytes',target.stat().st_size,'docs14',len(doc_hashes),'evidence14',len(evidence),flush=True)
print('NO health, manifest, receipt, ledger or catalogue write; fixed monotonic sentence readback only.',flush=True)
