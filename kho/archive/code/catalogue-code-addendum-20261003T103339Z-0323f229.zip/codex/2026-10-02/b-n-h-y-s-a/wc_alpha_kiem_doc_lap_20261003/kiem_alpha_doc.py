"""Đọc/đo mặt nạ; chỉ tạo ảnh chẩn đoán nguồn và alpha ở hai cột, không ghép ảnh cuối."""
from pathlib import Path
import hashlib, json
import numpy as np
from PIL import Image, ImageDraw

root=Path(r'C:\Users\H2\Desktop\Catalog Sua\BẢN MỚI 03-10-2026 (ChatGPT)\_BAO CAO\G08\ANH DAI DIEN PEROTAC KHAC REDPUMP')
receipt=root/'PHUONG AN GIU PIXEL SAN PHAM NGUON V2'/'BON ASSET ALPHA VA NEN - CHUA PDF.json'
data=json.loads(receipt.read_text(encoding='utf-8'))
out=Path(__file__).parent
entries=[]
regions=[
    [('THANH VA QUAI',[38,12,198,185]),('ONG VA CHAN',[40,250,212,347])],
    [('QUAI VA DINH',[390,70,690,420]),('HAI CHI TIET ROI',[25,295,280,830]),('MIENG VA CHAN',[155,1030,803,1450])],
    [('QUAI BOM TRAI',[170,350,350,610]),('QUAI BOM PHAI',[580,0,810,300]),('CHI TIET ROI',[592,680,790,805]),('CHAN VO PHAI',[507,790,836,1095])],
]
rois=[[[139,158,207,335],[45,19,78,262],[97,20,107,340]],[[178,99,790,1445],[40,310,268,552],[40,603,276,813]],[[90,356,385,1096],[588,18,803,680],[605,697,779,803],[510,805,835,1084]]]
for index,asset in enumerate(data['assets'][:3]):
    src=Path(asset['source_product']); mask=Path(asset['file'])
    h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    assert h(src)==asset['source_product_raw_jpeg_sha256'] and h(mask)==asset['sha256']
    orig=Image.open(src).convert('RGB'); rgba=Image.open(mask).convert('RGBA')
    rgb=np.asarray(orig); a=np.asarray(rgba.getchannel('A'))
    sh,sw=rgb.shape[:2]; mh,mw=a.shape
    # Ánh xạ tâm từng pixel nguồn sang toàn canvas alpha, không dịch/crop để cứu mặt nạ.
    ys=np.minimum(mh-1,np.floor((np.arange(sh)+.5)*mh/sh).astype(int))
    xs=np.minimum(mw-1,np.floor((np.arange(sw)+.5)*mw/sw).astype(int))
    mapped=a[ys[:,None],xs[None,:]]
    mappedim=Image.fromarray(mapped)
    mappedim.save(out/f'NHOM{index+1} ALPHA MAP TOAN CANVAS NGUON.png')
    diagnostics=[]
    for title,box in regions[index]:
        left=orig.crop(box); right=mappedim.crop(box).convert('RGB')
        scale=4 if index==0 else (2 if max(left.size)<400 else 1)
        left=left.resize((left.width*scale,left.height*scale),Image.Resampling.NEAREST)
        right=right.resize(left.size,Image.Resampling.NEAREST)
        pair=Image.new('RGB',(left.width*2+18,left.height+35),'white')
        pair.paste(left,(0,35));pair.paste(right,(left.width+18,35))
        d=ImageDraw.Draw(pair);d.text((5,8),'SOURCE JPEG - ORIGINAL PIXELS',fill='black');d.text((left.width+23,8),'ALPHA (WHITE=VISIBLE)',fill='black')
        path=out/f'NHOM{index+1} {title} NGUON VA ALPHA.png';pair.save(path)
        diagnostics.append({'region_source_pixels':box,'image':str(path)})
    # Chỉ sàng lọc vùng tối trung tính để tìm chỗ cần nhìn; không tự tuyên bố foreground hoàn chỉnh.
    gray=rgb.mean(axis=2); chroma=rgb.max(axis=2).astype(int)-rgb.min(axis=2).astype(int)
    dark=(gray<170)&(chroma<35)
    hints=[]
    for box in rois[index]:
        x0,y0,x1,y1=box
        possible=dark[y0:y1,x0:x1]
        missing=possible&(mapped[y0:y1,x0:x1]<16)
        yy,xx=np.nonzero(missing)
        selected=[]
        if len(xx):
            for k in np.linspace(0,len(xx)-1,min(12,len(xx))).astype(int):
                x,y=int(xx[k]+x0),int(yy[k]+y0)
                selected.append({'source_xy':[x,y],'alpha_xy':[int(xs[x]),int(ys[y])],'source_RGB':rgb[y,x].tolist(),'alpha':int(mapped[y,x])})
        hints.append({'source_ROI':box,'dark_neutral_candidate_pixels':int(possible.sum()),'candidate_alpha_below16':int(missing.sum()),'samples_for_visual_check':selected,'candidate_only':True})
    entries.append({'group':index+1,'source':str(src),'mask':str(mask),'source_sha256':h(src),'mask_sha256':h(mask),'source_size':[sw,sh],'mask_size':[mw,mh],'map':'x_mask=(x_source+0.5)*mask_width/source_width; y tương tự. Floor lấy pixel gần tâm; không dịch căn.','diagnostics':diagnostics,'screening_hints_not_acceptance':hints})
    assert h(src)==asset['source_product_raw_jpeg_sha256'] and h(mask)==asset['sha256']
path=out/'DOC MAT NA VA DIEM CAN NHIN.json'
assert not path.exists()
path.write_text(json.dumps({'read_only_assets':True,'final_product_composite_written':False,'PDF_written':False,'entries':entries},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'report':str(path),'hints':[{ 'group':r['group'],'candidate_alpha_below16':[h['candidate_alpha_below16'] for h in r['screening_hints_not_acceptance']]} for r in entries]},ensure_ascii=False))
