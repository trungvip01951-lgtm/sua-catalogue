"""Chốt kho dữ liệu dự án theo yêu cầu anh; không sửa catalogue."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import uuid
import zipfile

ROOT = Path(r'D:\ChatGPT\Sửa catalogue').resolve()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write_new(path, data):
    target = Path(path).resolve()
    assert target.is_relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x',encoding='utf8') as stream:
        json.dump(data,stream,ensure_ascii=False,indent=2)
    assert read(target) == data


def archive_code_delta(manifest, tag):
    """Giữ thêm mã mới/đổi sau lần chụp đầu, không thay kho lịch sử."""
    base_index = ROOT/'archive/CODE_INDEX.json'
    initial = read(base_index)
    known = {str(Path(row['source_path']).resolve()):row['sha256'] for row in initial['scripts']}
    codex = Path(manifest['paths']['legacy_workspace']).resolve().parents[1]
    workspaces = set()
    for source in known:
        p = Path(source)
        if p.is_relative_to(codex):
            relative = p.relative_to(codex)
            if len(relative.parts)>=3:
                workspaces.add(codex/relative.parts[0]/relative.parts[1])
    additions = []
    unstable = []
    excluded = {'.catfix-venv','.venv','venv','node_modules','__pycache__','.git','.cache'}
    for workspace in sorted(workspaces):
        for directory, subdirs, names in os.walk(workspace):
            subdirs[:] = [name for name in subdirs if name not in excluded]
            for name in sorted(names):
                p = Path(directory)/name
                if p.suffix.lower() not in ('.py','.ps1','.js','.mjs'): continue
                before = p.stat(); data = p.read_bytes(); after = p.stat()
                if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
                    unstable.append(str(p)); continue
                current_sha = hashlib.sha256(data).hexdigest()
                if known.get(str(p.resolve())) == current_sha: continue
                additions.append((p,data,current_sha,'codex/'+p.relative_to(codex).as_posix()))
    target = ROOT/'archive/code'/('catalogue-code-addendum-'+tag+'.zip')
    rows = []
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as output:
        for p,data,current_sha,entry in additions:
            output.writestr(entry,data)
            rows.append({'source_path':str(p),'zip_entry':entry,'sha256':current_sha,'bytes':len(data),
                         'previous_archived_sha256':known.get(str(p.resolve())),'execution_not_authorized_by_archival':True})
    with zipfile.ZipFile(target) as check:
        assert all(hashlib.sha256(check.read(r['zip_entry'])).hexdigest()==r['sha256'] for r in rows)
    index = ROOT/'archive'/('CODE_ADDENDUM_INDEX-'+tag+'.json')
    write_new(index,{'captured_utc':datetime.now(timezone.utc).isoformat(),'initial_index':str(base_index),
             'zip':str(target),'zip_sha256':digest(target),'scripts':rows,'unstable_files_not_archived':unstable,
             'scope':'Mã mới/đổi sau lần chụp đầu; giữ cả phiên trước, không chạy tác vụ sửa'})
    return {'index':str(index),'index_sha256':digest(index),'script_versions':len(rows),'unstable_files':unstable}


def main():
    now = datetime.now(timezone.utc)
    tag = now.strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    m = read(ROOT/'manifest.json')
    controls = read(ROOT/'state/control_manifest.json')
    assert all(digest(ROOT/f['relative_path']) == f['sha256'] for f in controls['files'])
    inventory = read(ROOT/'state/catalogues.json')
    archived = read(ROOT/'history/INITIAL_CAPTURE_RECEIPT.json')
    independent = sorted((ROOT/'work/g01_project_qa').glob('*QA04*.json'))
    assert independent, 'Cần phiếu QA04 độc lập trước chốt kho'
    independent_path = independent[-1]
    independent_data = read(independent_path)
    assert independent_data['check_count'] == 28
    assert independent_data['check_results'] == {'ĐẠT':28}
    assert independent_data['seal']['sha256'] == digest(ROOT/'state/control_manifest.json')
    assert independent_data['no_PDF_or_XLSX_write']
    assert not independent_data.get('catalogue_written',False)
    sl = ROOT/'work/g18_project_qa/6SL25_DON_DIEU_DOC_NGUON_LAN1/PHUONG AN NGUYEN10 HANG VA QUET17 BANG THEO QUY TAC MOI.json'
    sa = ROOT/'work/g03_sa_p2p3_qh_giam_nguyen_v1/02 PHUONG AN NGUYEN GIAM14 HANG161 O VA TOA DO TRUOC SAU.json'
    assert digest(sl) == 'a12f601d5dedddb65c9bb09788015b8196c5f4364043327c96b366fe4839f326'
    assert digest(sa) == '2ae4a448857b614a19e9d708b2da8d05b3240e75451fc26ea4cfe227f53cb90a'
    rows = []
    for item in inventory['catalogues']:
        row = {'source_relative':item['source_relative'],'current_relative':item['current_relative'],
               'source_sha256':item['source_sha256'],'current_sha256':item['current_sha256'],
               'status_new_rule':'CHUA_RA_TOAN_BO','changed_in_catalogue_for_new_rule':False,
               'scope':'Theo dõi việc rà sau lệnh mới; không phải nghiệm thu từ tên/hàm băm.'}
        if 'Redpump gieng SL_compressed' in item['source_relative']:
            row.update(status_new_rule='DA_RA_BANG_NGUON_CHUA_SUA',
                table_scan={'tables':17,'models':196,'cells':1931,'adjacent_pairs':1735,'increasing':5,'equal':28,
                    'affected_models':28,'full_curve_check':'CHUA_CHAY','new_direct_visual_read_cells':120},
                proposed={'models':10,'edited_cells':26,'unchanged_cells':94,
                    'source_extrema_preserved':'Gia tri trong bang; khong tu xac nhan extrema vat ly',
                    'plan_path':str(sl),'sha256':digest(sl),
                    'root_numeric_readback':str(ROOT/'work/root_qh_check/ROOT KIEM120 SO VA26 O DE XUAT6SL25 - CHUA SUA CATALOGUE.json')})
        elif 'Perotac bơm giếng SA_compressed' in item['source_relative']:
            row.update(status_new_rule='PHUONG_AN_CO_DIEU_KIEN_CHUA_SUA',
                proposed={'models':10,'equal_pairs_addressed':12,'edited_cells':34,
                    'plan_path':str(sa),'sha256':digest(sa),'root_read_scope':'Doc bao cao so va dieu kien; chua nghiem thu moi toan anh/bang/net'},
                remaining={'additional_3SS2_equal_pairs':4,'p8_table_cells':104,
                    'p8_table_rows':13,'full_p8_continuous_curve_check':'CHUA_CHAY','p8_font':'CHUA_DAT'})
        elif item['source_relative'].endswith('Catalogue DWO (bản mới).xlsx'):
            row.update(status_new_rule='CHO_SO_MIN',pending='Qmin/Hmin chua co; cau hoi min0 tham khao hay min thuc con cho; khung co the lam doc lap')
        rows.append(row)
    new_audit = ROOT/'state/QH_NEW_RULE_AUDIT_20261003.json'
    write_new(new_audit,{'captured_utc':now.isoformat(),'instruction':'Moi ma bom Q tang thi H giam; sua thong tin sai, giu extrema va diem lam viec da khoa',
                         'not_an_alternative_progress_ledger':True,'catalogues':rows,'new_catalogue_edits_accepted':0})
    code_addendum = archive_code_delta(m,tag)
    capsule = ROOT/'archive/project'/('SUA-CATALOGUE-V1-'+tag+'.zip')
    capsule.parent.mkdir(parents=True,exist_ok=True)
    selected = []
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel = p.relative_to(ROOT).as_posix()
        if rel.startswith(('archive/project/',)) or rel.endswith(('.sqlite','.sqlite-wal','.sqlite-shm')): continue
        if rel.startswith('work/') and not rel.startswith(('work/g01_project_qa/','work/g18_project_qa/','work/g03_sa_p2p3_qh_giam_nguyen_v1/','work/root_qh_check/')): continue
        selected.append(p)
    entries = []
    with zipfile.ZipFile(capsule,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
        for p in sorted(selected):
            before = p.stat(); data = p.read_bytes(); after = p.stat()
            assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),p
            rel = p.relative_to(ROOT).as_posix()
            output.writestr(rel,data)
            entries.append({'relative_path':rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        output.writestr('CAPSULE_CONTENT_HASHES.json',json.dumps(entries,ensure_ascii=False,indent=2).encode('utf8'))
    with zipfile.ZipFile(capsule) as check:
        assert len(check.namelist()) == len(entries)+1
        for entry in entries:
            assert hashlib.sha256(check.read(entry['relative_path'])).hexdigest()==entry['sha256']
    receipt = {'recorded_utc':now.isoformat(),'project_root':str(ROOT),'version':'1.0',
        'result':'DA_TAO_VA_KIEM_KHO_DU_LIEU_DU_AN',
        'independent_QA':str(independent_path),'independent_QA_sha256':digest(independent_path),
        'controls_sha256':digest(ROOT/'state/control_manifest.json'),
        'captured_archive_counts':archived['counts'],
        'current_code_addendum':code_addendum,
        'current_catalogues':25,'original_source_check_reference':'history/ROOT-PROJECT-READBACK-20261003T101435Z-30a6c480.json',
        'capsule':str(capsule),'capsule_sha256':digest(capsule),'capsule_files':len(entries)+1,
        'instruction_and_current_data_shared':True,'claude_runtime_application_verified':False,
        'desktop_app_project_registration':'NOT_RUN','catalogue_authored_by_this_handoff':False,
        'new_qh_rule_catalogue_changes_accepted':0,'canonical_progress_ledger':m['paths']['progress']}
    target = ROOT/'history'/('PROJECT-V1-HANDOFF-'+tag+'.json')
    write_new(target,receipt)
    pointer = Path(m['paths']['reports'])/'DU AN SUA CATALOGUE - KHO DU LIEU CHUNG.md'
    assert pointer.resolve().is_relative_to(Path(m['paths']['reports']).resolve())
    body = '''# Kho dữ liệu dự án Sửa catalogue

Anh Trung yêu cầu tạo ngày 03/10/2026 để ChatGPT và Claude dùng chung và tiếp tục không cần kể lại lịch sử.

Thư mục chính: D:\\ChatGPT\\Sửa catalogue. Mở README.md rồi START_HERE.md, AGENTS.md/CLAUDE.md. Quy tắc, quy trình, lỗi, mã và bằng chứng nằm trong kho; sổ TIEN DO.md hiện hành vẫn ở đây, không có sổ tiến độ cạnh tranh.

Lệnh mới Q tăng/H giảm đã ghi; các phương án số mới còn chưa sửa catalogue. Xem state/QH_NEW_RULE_AUDIT_20261003.json và checkpoint. Đã xác minh 27 tệp nguồn vẫn đúng BƯỚC0 ban đầu, danh mục 25 catalogue; công cụ catfix 43/43, phối hợp 8/8 và tách mã việc 4/4 đạt thật, không thay nghiệm thu số/hình thức catalogue.

Biên nhận kho: '''+str(target)+'''. Gói sao lưu: '''+str(capsule)+'''. Không xác nhận thay Claude đã đọc/áp dụng; mỗi phiên tự đọc và ghi xác nhận thật.
'''
    with pointer.open('x',encoding='utf8') as output:
        output.write(body)
    session = 'root-du-an-catalogue-'+tag
    result = subprocess.run([sys.executable,'-B','-X','utf8',str(ROOT/'tools/catalogue.py'),'receipt','--actor','ChatGPT ROOT',
        '--session',session,'--note','ROOT đã đọc kho quy tắc/quy trình/giới hạn, kiểm27 nguồn ban đầu và danh mục25 bản, đọc QA độc lập; tiếp theo sửa bảng và đường theo lệnh mới sau mẫu/đủ dữ liệu, không nhận Claude đã đọc.'],
        capture_output=True,text=True,encoding='utf8')
    assert result.returncode==0,result.stdout+result.stderr
    write_new(ROOT/'history'/('ROOT-READ-RECEIPT-'+tag+'.json'),json.loads(result.stdout))
    print(json.dumps({'project':str(ROOT),'receipt':str(target),'receipt_sha256':digest(target),
        'capsule':str(capsule),'capsule_sha256':digest(capsule),'capsule_files':len(entries)+1,
        'reports_pointer':str(pointer),'sources_not_modified':True,
        'catalogue_edits_by_this_handoff':0},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
