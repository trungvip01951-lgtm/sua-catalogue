"""Freeze read-only proposal pointers; leave shared ledger and catalogue alone."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
import json
from g04_perotac_whole_pdf_tools46 import read,sha
NAME='Perotac bơm giếng SA_compressed (bản mới).pdf'
WORK=Path(r'D:\ChatGPT\Sửa catalogue\work\g03_sa_p2p3_qh_giam_nguyen_v1')
planpath=WORK/'02 PHUONG AN NGUYEN GIAM14 HANG161 O VA TOA DO TRUOC SAU.json'
qapath=WORK/'05 KIEM DOC LAP CAN DUOI SO NGUYEN VA161 TOA DO.json'
plan=read(planpath);qa=read(qapath)
assert sha(planpath)==qa['plan_sha256']
assert dict(source=sha(S.src(NAME)),current=sha(S.result(NAME)))==plan['source_current_before']
paragraphs=[
    '# Bàn giao chỉ đọc SA — số nguyên giảm trang 2–3',
    '', 'Phương án riêng đúng 10 mã/12 cặp bằng, 34 ô giảm 1–2 m. Hai cách kiểm độc lập: tối ưu số nguyên và cận H[i] ≤ Hmax−i. Cận này bắt buộc từng ô đã chỉnh, nên 34 ô và mức lớn nhất 2 m đều là tối thiểu; không chỉ lấy kết quả của một thuật toán làm lời chứng.',
    '', 'Giữ min/max và hai đầu của 14 hàng/161 ô. Giữ /37 Q3,3/H75, /37 Q3,6/H54, /20 Q5,4/H25, /28 Q5,4/H36. Không tìm thấy khóa điểm làm việc bổ sung trong G04/15 mục việc; phương án có điều kiện này rõ ràng và phải kiểm lại nếu ROOT tìm được khóa khác.',
    '', 'JSON 02 có cả 265 ô thuộc 14 hàng trang 2–3 và 13 hàng trang 8; riêng CSV 03 là 161 neo trang 2–3. Tọa độ trước/sau chỉ là đích theo bảng, không gọi tâm mực đường hiện hành. Dùng từng vạch thật cục bộ và hộp ô từ mực lưới; ảnh hàng giữ tên và đầu cột nguồn.',
    '', 'Trang 8: 13 hàng/104 ô giảm nghiêm ngặt = ĐẠT BẢNG. Toàn nét liên tục PDF theo yêu cầu mới CHƯA CHẠY; font RAM V4 chưa đạt, 0 PDF toàn biểu đồ. Không thử chữ thêm, không chạy writer65.',
    '', 'PDF thật nguồn–bản giao 200 dpi: cột Q/H ba bảng không đổi điểm ảnh nào, ngưỡng 0. Nguồn/current giữ SHA. Không ghi PDF/bảng/phông/tiến độ/khóa ghi catalogue.',
    '', 'Phát hiện thêm khi nhìn lại bảng 3SS2 cạnh biểu đồ 3SS3 trang 2: 4 cặp bằng, 3 mã. Các cặp này không nhập vào phương án 10 mã, chưa chốt số mới hoặc dựng đường. ROOT có thể thêm con trỏ riêng vào danh sách cần rà.',
    '', '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
    '|---|---|---|---|---|---|---|---|',
    f'| SA-PHÁT-HIỆN-3SS2-8 | {NAME} | 2 | Q0→0,3: H34=34; Q0,6→0,9: H33=33 | Chưa đề xuất | Chỉ đọc đúng hàng/đầu cột | Cần rà theo quy tắc mới; toàn đường chưa kiểm | JSON 05 và ảnh bảng 3SS2 |',
    f'| SA-PHÁT-HIỆN-3SS2-11 | {NAME} | 2 | Q0,6→0,9: H45=45 | Chưa đề xuất | Chỉ đọc đúng hàng/đầu cột | Cần rà theo quy tắc mới; toàn đường chưa kiểm | JSON 05 và ảnh bảng 3SS2 |',
    f'| SA-PHÁT-HIỆN-3SS2-21 | {NAME} | 2 | Q0→0,3: H89=89 | Chưa đề xuất | Chỉ đọc đúng hàng/đầu cột | Cần rà theo quy tắc mới; toàn đường chưa kiểm | JSON 05 và ảnh bảng 3SS2 |',
    '', 'Không cộng 3 phát hiện này vào 10 phương án đã tính hoặc 149 việc gốc. Số mới chưa phải dữ liệu thử nghiệm nhà sản xuất. ROOT kiểm/chốt nguồn chung và giao bước sau; tác nhân không tự phát hành hoặc dựng mẫu PDF.']
md=Path(fresh(WORK/'06 BAN GIAO NGAN VA4 CAP3SS2 NGOAI PHUONG AN.md'))
md.write_text('\n'.join(paragraphs)+'\n',encoding='utf8')
files=[p for p in WORK.iterdir() if p.is_file()]
manifest=dict(stage='READ-ONLY HANDOFF; CONDITIONAL NUMBER PROPOSAL ONLY; PDF0',
    source_sha256=sha(S.src(NAME)),canonical_sha256=sha(S.result(NAME)),
    proposal_10_models_12_pairs_34_cells_max2_H_change=True,actual_catalogue_new_rule_not_accepted=True,
    number_proposal_math_QA='PASS conditional on no additional working-point lock',
    p8_table_only='PASS13rows104H',p8_whole_continuous_curve_new_rule='NOT_RUN',p8_font='FAIL',
    own_source_only=True,no_PDF_table_font_progress_write=True,
    final_handoff_text=dict(path=str(md),sha256=sha(md)),
    locked_artifacts=[dict(path=str(p),sha256=sha(p)) for p in files],
    code=[dict(path=str(Path(__file__).parent/p),sha256=sha(Path(__file__).parent/p)) for p in [
        'g04_perotac_strictH_source_probe82.py','g04_integer_descending_tools83.py',
        'g04_perotac_strictH_integer_plan84.py','g04_perotac_strictH_plan_QA85.py','g04_perotac_strictH_handoff86.py']])
out=Path(fresh(WORK/'07 MANIFEST BAN GIAO CHI DOC SA NGUYEN GIAM.json'))
out.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print('HANDOFF',md,'SHA256',sha(md),'MANIFEST',out,'SHA256',sha(out),'PDF0',flush=True)
