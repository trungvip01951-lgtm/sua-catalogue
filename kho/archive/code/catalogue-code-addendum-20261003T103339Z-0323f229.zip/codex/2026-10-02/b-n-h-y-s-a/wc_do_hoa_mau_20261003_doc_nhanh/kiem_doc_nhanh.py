"""Phiếu kiểm đọc nhanh; không sửa PDF, nguồn hoặc tiến độ chung."""
from pathlib import Path
import hashlib, json
import pymupdf as fitz

base = Path(r'C:\Users\H2\Desktop\Catalog Sua')
name = 'Catalog cắt rác Aquaris WC (bản mới).pdf'
paths = {
    'source': base / 'BẢN MỚI 01-10-2026' / 'Nước thải' / name,
    'current': base / 'BẢN MỚI 03-10-2026 (ChatGPT)' / 'Nước thải' / name,
    'sample': base / 'BẢN MỚI 03-10-2026 (ChatGPT)' / '_BAO CAO' / 'G08' / 'MAU AQUARIS WC SUA BO SUNG' / '14 MAU 1 TRON TOAN TRANG4' / name,
}
expected = {
    'source': 'b44ed64480e649bbcb2e50ddff8f591d85177c8fe88b07e93ebb154a0a5a3d40',
    'current': 'f850238b7dac6163276aa3e3318e57f7b3b945ec9ce0c67229c01f7b46983aca',
    'sample': 'a6a16e85f42eb332aeb35cfd41d347f421b323be24c1eac968f7ddace2fe1f20',
}
def hashes():
    return {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in paths.items()}
before = hashes()
assert before == expected
docs = {key: fitz.open(path) for key, path in paths.items()}
def curves(page):
    result = []
    for d in page.get_drawings():
        c, r = d.get('color'), d['rect']
        if c is not None and max(c) - min(c) >= .10 and r.width >= 30 and r.height >= 2 and r.x0 >= 650 and r.y0 <= 540 and r.y1 >= 200:
            result.append(d)
    assert len(result) == 6
    return {tuple(d['color']): d for d in result}
styles = ['color', 'width', 'dashes', 'lineCap', 'lineJoin', 'stroke_opacity']
all_curves = {key: curves(d[3]) for key, d in docs.items()}
checks = []
for color, sample in all_curves['sample'].items():
    assert set(all_curves['source']) == set(all_curves['current']) == set(all_curves['sample'])
    assert all(sample[key] == all_curves['source'][color][key] == all_curves['current'][color][key] for key in styles)
    assert len(sample['items']) == 1 and sample['items'][0][0] == 'c'
    checks.append({'native_style': {key: sample[key] for key in styles}, 'one_whole_cubic': True, 'status': 'ĐẠT'})
for d in docs.values():
    d.close()
assert before == hashes()
result = {
    'reviewer': '/root/wc_do_hoa_mau',
    'scope': 'Xác minh nhanh mẫu trang 4 theo chỉ đạo ROOT; kiểm đúng SHA, đọc báo cáo đồ họa đã hoàn tất, tự kết xuất và mở 3 ảnh PDF thực.',
    'hashes': before,
    'native_6_curves_checked': checks,
    'direct_visual_review': {
        'whole_page_150dpi': 'ĐẠT: bố cục rõ, đường và bảng cân đối.',
        'chart_600dpi': 'ĐẠT: sáu nét trơn, đều trong từng màu nguồn; không thấy gãy, mảng che, vết vá đuôi hay đường đôi.',
        'table_600dpi': 'ĐẠT: chữ số sạch, cùng kiểu chữ với bảng, căn giữa và không chạm viền.',
    },
    'existing_independent_report': r'C:\Users\H2\Documents\Codex\2026-10-03\catalogue-kiem-do-hoa-dong-bo\outputs\11-NGHIEM-THU-HINH-THUC-AQUARIS-WC-MAU1-TRANG4.md',
    'existing_report_matches_sample_sha': True,
    'result': 'ĐẠT KIỂM ĐỌC NHANH HÌNH THỨC TRANG 4, ĐÚNG MẪU.',
    'limitations': 'Không đo lại 30 mặt cắt và 42 mốc/18 khóa; đó là phép kiểm của tác nhân đồ họa chính và ROOT, được ghi nhận đúng người kiểm. Không suy rộng trang 4 sang 7 trang chưa sửa hoặc PDF khác.',
    'PDF_written': False,
    'shared_progress_written': False,
    'source_current_sample_hashes_held': True,
}
out = Path(__file__).parent / 'PHIEU DOC NHANH HINH THUC TRANG4.json'
assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status': result['result'], 'native_curves': len(checks), 'receipt': str(out)}, ensure_ascii=False))
