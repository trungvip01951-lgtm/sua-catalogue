"""Serialize/render CATFIX source-island chart in RAM only. Zero PDF saves."""
from catwork import start,fresh
S,D,N=start()
from pathlib import Path
from io import BytesIO
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
import pymupdf as fitz,pikepdf
from scipy import ndimage
from catfix.cs import parse
from catfix.vector import VPage,Editor
from catfix.raster import Raster
from g04_perotac_source9_eta_union_builder77 import prepare,memory_bytes,NAME,RAM_REL
from g04_perotac_whole_pdf_tools46 import read,sha,pixel_at
from g04_perotac_whole_actual_read50 import render_document,outside_read,metadata,image_resources,actual_paths_and_ink

root=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08/RAM CATFIX NGUON9 DAO V4 ETA60 NGUYEN CUM CHUA LUU PDF'))
ed,R,cv,content,only_clip,report=prepare(S);ram=read(S.report(RAM_REL))
clip_blob=memory_bytes(ed,only_clip);final_blob=memory_bytes(ed,content)
report['serialized_memory_sha256']=hashlib.sha256(final_blob).hexdigest();report['serialized_memory_bytes']=len(final_blob)
sourceE=Editor(S.src(NAME),backend='fitz');sourceR=Raster(sourceE);sourceim=max(sourceR.images(7),key=lambda z:z.W*z.H);sourcecv=sourceR.canvas(sourceim)
source_raw_sha=hashlib.sha256(sourceE.doc.stream_raw(sourceim.ref)).hexdigest()
assert source_raw_sha==report['source_X7_raw_sha256']
assert np.allclose(sourceim.ctm,cv.im.ctm,rtol=0,atol=1e-10) if hasattr(cv,'im') else True
island_reads=[];tiles=[]
with fitz.open(S.result(NAME)) as before,fitz.open(S.src(NAME)) as source,fitz.open(stream=clip_blob,filetype='pdf') as clipped,fitz.open(stream=final_blob,filetype='pdf') as actual:
    roi=report['ROI_page_pt'];ar600,mapping=render_document(actual,7,600,roi);ar150,_=render_document(actual,7,150)
    Image.fromarray(ar600).save(fresh(root/'PEROTAC P08 CATFIX THAT600 NGUON9 DAO CHUA NGHIEM THU.png'))
    Image.fromarray(ar150).save(fresh(root/'PEROTAC P08 CATFIX TOAN TRANG150 NGUON9 DAO CHUA NGHIEM THU.png'))
    clip150,_=render_document(clipped,7,150);Image.fromarray(clip150).save(fresh(root/'PEROTAC P08 CHI9 DAO NGUON CLIP150.png'))
    outside_final=outside_read(before,actual,roi,dpi=200);outside_clip=outside_read(before,clipped,roi,dpi=200)
    meta0=metadata(before);meta1=metadata(actual);meta_equal={k:meta0[k]==meta1[k] for k in meta0}
    actual_read=actual_paths_and_ink(actual[7].read_contents(),report,ram,cv,ar600,mapping)
    assert actual[7].read_contents()==content
    for island in report['source_literal_islands_all']:
        key=island['key'];native=island['source_native_box'];b=island['source_page_box']
        original,original_map=render_document(source,7,600,b);new,new_map=render_document(actual,7,600,b)
        assert original.shape==new.shape and original_map==new_map
        change=np.any(original!=new,axis=2);dark=(original.min(2)<235);yy,xx=np.indices(change.shape)
        # Pixel-center geometric test; do not add a tolerance to accepted text.
        p0=pixel_at(b[:2],new_map);p1=pixel_at(b[2:],new_map);lo=np.minimum(p0,p1);hi=np.maximum(p0,p1)
        center=np.stack([xx+.5,yy+.5],axis=-1);inside=((center>=lo+2)&(center<=hi-2)).all(2)
        original_box=island['source_literal_original_native_box']
        raw=sourcecv.orig[original_box[1]:original_box[3],original_box[0]:original_box[2]]
        cover=island['source_halo_raw_cover_box']
        assert hashlib.sha256(sourcecv.orig[cover[1]:cover[3],cover[0]:cover[2]].tobytes()).hexdigest()==island['source_halo_raw_cover_RGB_SHA256']
        assert hashlib.sha256(raw.tobytes()).hexdigest()==island['source_cropped_RGB_SHA256']
        row=dict(key=key,literal_source_read=island['literal_source_read'],source_native_box=native,
            source_literal_original_native_box=original_box,source_halo_raw_cover_box=cover,
            all_perimeter_and_halo_checks_pending_not_inferred_from_interior2=True,
            source_crop_RGB_SHA256=island['source_cropped_RGB_SHA256'],actual_source_X7_raw_SHA256=source_raw_sha,
            original_source_CTM_and_current_CTM=np.allclose(sourceim.ctm,max(R.images(7),key=lambda z:z.W*z.H).ctm,rtol=0,atol=1e-10),
            source_native_pixels_not_rescaled=True,no_new_image_SMask_or_font=True,
            actual600_all_crop_changed_pixels=int(change.sum()),actual600_original_dark_pixel_changed=int((change&dark).sum()),
            actual600_crop_interior2pixel_changed=int((change&inside).sum()),actual600_dark_interior2pixel_changed=int((change&inside&dark).sum()),
            actual600_max_channel_difference=int(abs(original.astype(int)-new.astype(int)).max()),
            original_font_program_unknown=True,literal_and_graphic_ROOT_readback_pending=True)
        island_reads.append(row)
        tile=Image.new('RGB',(max(1500,original.shape[1]*4+100),max(250,original.shape[0]*2+70)),'white');dr=ImageDraw.Draw(tile)
        dr.text((10,10),key+' ORIGINAL SOURCE600 / CATFIX ACTUAL RAM600',fill='black')
        left=Image.fromarray(original).resize((original.shape[1]*2,original.shape[0]*2),Image.Resampling.NEAREST)
        right=Image.fromarray(new).resize(left.size,Image.Resampling.NEAREST);tile.paste(left,(0,45));tile.paste(right,(left.width+50,45))
        tile.save(fresh(root/(key+' SOURCE600 VA ACTUAL RAM600.png')));tiles.append(tile)
    # All unpainted interior source-native centers outside the nine islands.
    blank200,map200=render_document(clipped,7,200)
    x0,y0,x1,y1=report['source_native_edit_box'];u,v=np.meshgrid(np.arange(x0+1,x1-1)+.5,np.arange(y0+1,y1-1)+.5)
    native_points=np.stack([u,v],axis=-1).reshape(-1,2);page=np.array([cv.to_page(float(x),float(y)) for x,y in native_points]);px=np.array([pixel_at(pt,map200) for pt in page])
    colors=np.array([ndimage.map_coordinates(blank200[:,:,k].astype(float),[px[:,1]-.5,px[:,0]-.5],order=1,mode='constant',cval=255) for k in range(3)]).T
    safe=np.ones(len(native_points),bool)
    for island in report['source_literal_islands_all']:
        b=island['source_native_box'];safe&=~((native_points[:,0]>=b[0]-1)&(native_points[:,0]<=b[2]+1)&(native_points[:,1]>=b[1]-1)&(native_points[:,1]<=b[3]+1))
    wrong=np.any(abs(colors[safe]-255)>1e-7,axis=1)
    blank_check=dict(checked_native_centers=int(safe.sum()),nonwhite_native_centers=int(wrong.sum()),max_white_difference=float(abs(colors[safe]-255).max()),all9islands_and_source1px_margin_excluded=True,no_white_paint=True)
    P=VPage(parse(actual[7].read_contents()));ctm_rows=[]
    for clipped_Do in report['old_Do_complement_clips']:
        old=next(i for i in ed.page(7).images if i['i']==clipped_Do['original_Do_index'])
        hits=[i for i in P.images if i['name']==old['name'] and np.max(abs(i['ctm']-old['ctm']))<1e-9]
        ctm_rows.append(dict(name=old['name'],same_CTM_matches=len(hits),old_CTM_kept=len(hits)==1))
with pikepdf.open(S.result(NAME)) as before,pikepdf.open(BytesIO(final_blob)) as actual:
    resources_equal=image_resources(before)==image_resources(actual)
    gs=actual.pages[7].Resources.ExtGState['/'+report['new_normal_opaque_gs']]
    opaque={k:str(gs.get('/'+k)) for k in ['CA','ca','BM','SMask']}
    unchanged_pages=[before.pages[i].Contents.read_bytes()==actual.pages[i].Contents.read_bytes() for i in range(11) if i!=7]
    def raw_info(pdf):
        out={}
        for k,v in pdf.docinfo.items():
            try:out[str(k)]=bytes(v).hex()
            except (TypeError,ValueError):out[str(k)]=str(v)
        return out
    def raw_xmp(pdf):
        m=pdf.Root.get('/Metadata');return hashlib.sha256(m.read_raw_bytes()).hexdigest() if isinstance(m,pikepdf.Stream) else str(m)
    info_raw_equal=raw_info(before)==raw_info(actual);xmp_raw_equal=raw_xmp(before)==raw_xmp(actual)
atlas=Image.new('RGB',(max(t.width for t in tiles),sum(t.height+15 for t in tiles)),'white');y=0
for tile in tiles:atlas.paste(tile,(0,y));y+=tile.height+15
atlas.save(fresh(root/'9 CUM CHU NGUYEN NGUON VA ACTUAL CATFIX600.png'))

# Do not rely on the clipping mask to hide a missing new tick/grid segment.
# Test actual uncropped new stroked geometry against all source text islands.
intrusions=[]
for obj in report['new_objects']:
    if obj['paint']!='S':continue
    segments=[];last=None
    for op,points in obj['pagepath']:
        if op=='m':last=np.array(cv.to_px(*points[0]),float)
        elif op=='l':
            end=np.array(cv.to_px(*points[0]),float);steps=max(3,int(np.linalg.norm(end-last)/.08));tt=np.linspace(0,1,steps)[:,None]
            pp=last+tt*(end-last);dd=np.tile(end-last,(len(pp),1));segments.append((pp,dd));last=end
        elif op=='c':
            c=np.array([last]+[cv.to_px(*p) for p in points]);steps=max(20,int(np.linalg.norm(c[-1]-c[0])/.08));tt=np.linspace(0,1,steps)[:,None]
            pp=(1-tt)**3*c[0]+3*(1-tt)**2*tt*c[1]+3*(1-tt)*tt**2*c[2]+tt**3*c[3]
            dd=3*(1-tt)**2*(c[1]-c[0])+6*(1-tt)*tt*(c[2]-c[1])+3*tt**2*(c[3]-c[2]);segments.append((pp,dd));last=c[-1]
    halfwidth=obj['width_pt']/2/np.linalg.norm(cv.to_page(1,0)-cv.to_page(0,0)) if isinstance(cv.to_page(1,0),np.ndarray) else obj['width_pt']/2/np.linalg.norm(np.array(cv.to_page(1,0))-np.array(cv.to_page(0,0)))
    for pp,dd in segments:
        norm=np.stack([-dd[:,1],dd[:,0]],axis=1)/np.maximum(np.linalg.norm(dd,axis=1)[:,None],1e-12)
        footprint=np.concatenate([pp+norm*d for d in np.linspace(-halfwidth,halfwidth,5)])
        for island in report['source_literal_islands_all']:
            b=island['source_native_box'];hit=((footprint[:,0]>b[0]+1e-7)&(footprint[:,0]<b[2]-1e-7)&(footprint[:,1]>b[1]+1e-7)&(footprint[:,1]<b[3]-1e-7))
            if hit.any():intrusions.append(dict(object_key=obj['key'],object_kind=obj['kind'],island_key=island['key'],hits=int(hit.sum()),native_sample_points=footprint[hit][:10].tolist()))
summary=dict(filesystem_PDF_save_count=0,source9literal_islands_not_retyped=True,source_original_font_program_UNKNOWN=True,
    original_X7_raw_bytes_equal_to_source=source_raw_sha==report['source_X7_raw_sha256'],source_island_actual600_reads=island_reads,
    outside200_threshold0_pad0_all11=outside_final,clip_only_outside200_threshold0_pad0=outside_clip,
    current_Info_XMP_links_bookmarks_boxes_fonts_native_text_equal=meta_equal,current_Info_value_bytes_equal=info_raw_equal,current_XMP_raw_stream_SHA256_equal=xmp_raw_equal,
    all_current_raw_images_SMask_resources_equal=resources_equal,all_current_Do_CTMs_preserved=ctm_rows,
    other10_pages_content_bytes_equal=all(unchanged_pages),clip_only_clear_native_check=blank_check,new_explicit_opaque_gs=opaque,
    actual104_path_and_visible_points_match=actual_read['all104_path_and_visible_points_match'],actual_named_new_objects_match=actual_read['all_named_new_objects_match'],
    new_stroke_footprints_intruding_source_text_islands=intrusions,stroke_footprint_sample_step_native_px=.08,
    source_axis_island_content_and_sharpness_ROOT_GRAPHIC_REVIEW_PENDING=True,saved_PDF_QA='CHƯA CHẠY',no_progress_written=True)
report.update(actual_serialized_RAM_checks=summary,actual_path_and_ink_readback=actual_read,
    former_axis_contour_FAIL_fields_replaced_by_original_source_islands=True,local_ring_research_not_used=True,
    source_native_paint_and_byte_constraints_not_proof_of_full_graphic_acceptance=True)
Path(fresh(root/'CATFIX NGUON9 DAO RAM V4 DOC LAI MUC THAT VA NGOAI VUNG.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
Path(fresh(root/'LENH CATFIX TRANG08 NGUON9 DAO KHONG CHE TRANG.txt')).write_bytes(content)
assert sha(S.src(NAME))==report['source_sha256'] and sha(S.result(NAME))==report['canonical_sha256']
sourceE.close();ed.close()
print('ACTUAL104',summary['actual104_path_and_visible_points_match'],'NAMED',summary['actual_named_new_objects_match'],'RAW INFO/XMP',info_raw_equal,xmp_raw_equal,flush=True)
print('OUTSIDE200',[(r['page'],r.get('outside_changed_pixels')) for r in outside_final],flush=True)
print('SOURCE9 FIELD PIXELS',[(r['key'],r['actual600_all_crop_changed_pixels'],r['actual600_dark_interior2pixel_changed']) for r in island_reads],flush=True)
print('CLEAR',blank_check,'NEWSTROKE INTRUSIONS',intrusions,flush=True)
