"""Read original SL6SL25 tables/ink for new monotonic rule. No PDF writes."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from datetime import datetime
import hashlib, json
from PIL import Image
from catfix.vector import Editor
from catfix.raster import Raster

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
out = Path(r'D:\ChatGPT\Sửa catalogue\work\g18_project_qa\6SL25_DON_DIEU_DOC_NGUON_LAN1')
assert not out.exists(), 'New evidence folder only'
audit = Path(S.report('G04/KIEM TOAN REDPUMP TOAN BO'))
mp = audit/'DANH MUC BANG NGUON 196 DONG V2.json'
cp = audit/'1931 O NGUON DINH VI VA DOI CHIEU V2.json'
ap = audit/'17 TRUC DOC NGUON RIENG KHOA V1.json'
tp = audit/'DOC MUC LOCAL NGOAI P8 6SL25 LAN1/DO MUC LOCAL DOC NGUON VA BAN GIAO CHUA CHOT.json'
load = lambda p: json.loads(Path(p).read_text(encoding='utf8'))
m, c, a, tr = load(mp), load(cp), load(ap), load(tp)
source, current = Path(m['source']), Path(m['current'])
before = [sha(source), sha(current)]
assert before == ['a01b7f84c0ebb4960a6b9601d98a04420c4c00f8bf1d48a23e1bde4e8b084038',
                  'b7c1febb60e0ebfcb88d233f87d8e10d0c0e5886214acc98e6f5cc2b2d32d435']
rows = [r for r in m['rows'] if r['family'] == '6SL25']
assert len(rows) == 10 and all(len(r['Q']) == 12 for r in rows)
table = next(t for t in c['tables'] if t['family'] == '6SL25')
ax = next(z for z in a['records'] if z['family'] == '6SL25')
E = Editor(source, backend='fitz')
R = Raster(E)
page = 9
base = max(R.images(page), key=lambda z: z.W*z.H)
native = R.canvas(base)
raw_image_sha = hashlib.sha256(E.doc.stream_raw(base.ref)).hexdigest()
saved = []
def save(ar, name, **extra):
    p = Path(fresh(out/name))
    im = Image.fromarray(ar, 'CMYK').convert('RGB') if ar.shape[2] == 4 else Image.fromarray(ar)
    im.save(p)
    z = dict(path=str(p), SHA256=sha(p), pixels=[im.width, im.height], **extra)
    saved.append(z)
    return z

full = R.render_canvas(page, base.page_bbox, dpi=150)
save(full.orig, 'NGUON THUC TRANG10 150dpi.png', page=10, rect=list(full.rect0), dpi=150)
tc = R.render_canvas(page, table['rect'], dpi=600)
save(tc.orig, 'BANG6SL25 TEN HANG DAU COT VA120 O NGUON600.png', page=10, rect=list(tc.rect0), dpi=600)
ntbox = native.box(table['rect'])
save(native.orig[ntbox[1]:ntbox[3], ntbox[0]:ntbox[2]], 'BANG6SL25 PIXEL NGUON NATIVE.png', native_box=ntbox,
     native_size=[base.W, base.H], native_mode=native.mode, native_bbox=list(base.page_bbox), raw_image_SHA256=raw_image_sha)
for dpi in [150, 600]:
    gr = R.render_canvas(page, (632, 327, 813, 521), dpi=dpi)
    save(gr.orig, f'DUONG6SL25 NHAN VA VACH NGUON{dpi}.png', page=10, rect=list(gr.rect0), dpi=dpi)

proofs=[]
for row in rows:
    rcells = [z for z in c['cells'] if z['model'] == row['model']]
    assert len(rcells)==12 and [z['H_source'] for z in rcells] == row['H']
    lo=min(z['page_rect'][1] for z in rcells)
    hi=max(z['page_rect'][3] for z in rcells)
    slug=row['model'].replace('/','_')
    rr=(458, lo-.6, 808, hi+.6)
    cv=R.render_canvas(page, rr, dpi=600)
    row_image=save(cv.orig, f'{slug} TOAN HANG NGUON600.png', page=10, rect=list(cv.rect0), dpi=600)
    selected=[]
    for cell in rcells:
        if cell['Q'] not in [0,3,33] and cell['H_source'] not in [max(row['H']), min(row['H'])]:
            continue
        native_box=native.box(cell['page_rect'])
        selected.append(dict(Q=cell['Q'], H_source_candidate=cell['H_source'],
            page_rect=cell['page_rect'], native_box_TOP_LEFT=native_box,
            native_coordinates_recomputed=True))
    old=next(z for z in tr['records'] if z['model']==row['model'])
    oldpoints=[z for z in old['numeric_points'] if z['Q'] in [0,3]]
    proofs.append(dict(model=row['model'], Q=row['Q'], H_source_candidate=row['H'],
        table_max_candidate=max(row['H']), Q_of_table_max_candidate=[q for q,h in zip(row['Q'], row['H']) if h==max(row['H'])],
        table_min_candidate=min(row['H']), Q_of_table_min_candidate=[q for q,h in zip(row['Q'], row['H']) if h==min(row['H'])],
        H_at_Q0_candidate=row['H'][0], H_at_Q3_candidate=row['H'][1],
        row_photo=row_image, selected_source_cells=selected,
        actual_source_ink_at_Q0_Q3_PRIOR_UNACCEPTED=oldpoints,
        ink_status='Prior trace candidates only; do not accept as actual Hmax or use table H to choose ink.' ))
E.close()
assert before == [sha(source),sha(current)]
record=dict(time=datetime.now().astimezone().isoformat(), task='Nguồn thật6SL25 theo quy tắc mới H giảm khi Q tăng',
    source=str(source), source_SHA256=before[0], current=str(current),current_SHA256=before[1],
    source_raw_image=dict(name=base.name,index=base.index,CTM=base.ctm.tolist(),native_size=[base.W,base.H],
        raw_stream_SHA256=raw_image_sha),
    source_PDF_coordinate_system='PDF points, origin bottom-left; native PNG coordinates TOP-LEFT; boxes sorted by Canvas.box()',
    rows_pending_direct_visual_read=proofs, source_axis_record=ax,
    evidence= saved,
    prior_reference_files=[dict(path=str(p),SHA256=sha(p)) for p in [mp,cp,ap,tp]],
    PDF_written=False, table_written=False, canonical_written=False, ledger_written=False,
    status='Chỉ tạo ảnh nguồn và tọa độ. Từng số cần đọc trực tiếp ảnh; chưa khóa phương án số mới.')
p=Path(fresh(out/'DOC NGUON VA TOA DO CHUA CHOT.json'))
p.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(dict(folder=str(out),data=str(p),SHA256=sha(p),source_SHA256=before[0],
    rows=[dict(model=z['model'],Q0=z['H_at_Q0_candidate'],Q3=z['H_at_Q3_candidate'],max=z['table_max_candidate'],min=z['table_min_candidate'],
               priorQ0Q3=[dict(Q=x['Q'],H=x.get('H_curve'),uncertainty=x.get('uncertainty_H'),status=x['status'],reason=x.get('reason')) for x in z['actual_source_ink_at_Q0_Q3_PRIOR_UNACCEPTED']]) for z in proofs]),ensure_ascii=False),flush=True)
