"""SA own-source conditional number proposal only. Zero PDF/table/font writes."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from datetime import datetime, timezone
from PIL import Image
import csv, json, math
import numpy as np
from catfix.vector import Editor
from catfix.raster import Raster
from g04_perotac_whole_pdf_tools46 import read, sha
from g04_integer_descending_tools83 import solve_integer_descending

NAME='Perotac bơm giếng SA_compressed (bản mới).pdf'
WORK=Path(r'D:\ChatGPT\Sửa catalogue\work\g03_sa_p2p3_qh_giam_nguyen_v1')
probe_path=WORK/'01 NGUON THAT KHOA VA LUOI BANG CHI DOC.json'
probe=read(probe_path)
old_path=Path(probe['older_readonly161_node_plan']['path'])
old=read(old_path)
BEFORE=probe['source_current_before']
assert sha(S.src(NAME))==BEFORE['source'] and sha(S.result(NAME))==BEFORE['current']
assert sha(old_path)==probe['older_readonly161_node_plan']['sha256']
E=Editor(S.src(NAME),backend='fitz');R=Raster(E)
C=Editor(S.result(NAME),backend='fitz');RC=Raster(C)
rows=[];node_rows=[];cell_rows=[];comparisons=[];p8=[];pairs=[];proofs=[]

def node_coordinates(record,Q,H):
    heads=record['local_head_tick_measurements']
    flows=record['local_flow_tick_measurements']
    h=np.array([t['printed_H_m'] for t in heads]);v=np.array([t['source_gray_core_center_native'] for t in heads])
    q=np.array([t['printed_l_min'] for t in flows]);u=np.array([t['source_gray_core_center_native'] for t in flows])
    j=int(np.clip(np.searchsorted(h,H,side='right')-1,0,len(h)-2))
    qvalue=Q*1000/60
    k=int(np.clip(np.searchsorted(q,qvalue,side='right')-1,0,len(q)-2))
    assert h[0]<=H<=h[-1] and q[0]<=qvalue<=q[-1]
    return dict(native_u=float(np.interp(qvalue,q,u)),native_v=float(np.interp(H,h,v)),
        Q_local_ticks=[dict(Q_l_min=float(q[z]),native_u=float(u[z])) for z in [k,k+1]],
        H_local_ticks=[dict(H_m=float(h[z]),native_v=float(v[z])) for z in [j,j+1]],
        H_mapping_uncertainty_m_per1_native_px=float(abs((h[j+1]-h[j])/(v[j+1]-v[j]))))

for table in probe['source_tables']:
    family=table['family'];page=table['page'];pi=page-1
    im=max(R.images(pi),key=lambda z:z.W*z.H);cv=R.canvas(im);raw=cv.orig
    q=table['Q_m3_h'];n=len(q);source_rows=table['rows']
    # Select measured source boundary strokes from the rightmost H columns.
    # Actual source widths differ on p3; never replace them with equal spacing.
    vs=table['vertical_grid_long_stroke_measurements'][-(n+1):]
    hs=table['horizontal_grid_long_stroke_measurements'][-(len(source_rows)+1):]
    assert len(vs)==n+1 and len(hs)==len(source_rows)+1
    assert vs[0]['center_native']>table['table_crop_native'][0]+330
    x0,y0,x1,y1=table['table_crop_native']
    hx0,hx1=math.floor(vs[0]['start']),math.ceil(vs[-1]['end_exclusive'])
    hy0,hy1=math.floor(table['horizontal_grid_long_stroke_measurements'][1]['start']),math.ceil(hs[-1]['end_exclusive'])
    p0=cv.to_page(hx0,hy0);p1=cv.to_page(hx1,hy1)
    rect=(min(p0[0],p1[0]),min(p0[1],p1[1]),max(p0[0],p1[0]),max(p0[1],p1[1]))
    a=R.render_canvas(pi,rect,dpi=200,engine='fitz').orig
    b=RC.render_canvas(pi,rect,dpi=200,engine='fitz').orig
    assert a.shape==b.shape
    changes=int(np.any(a!=b,axis=2).sum())
    assert changes==0,(family,changes)
    for label,img in [('NGUON',a),('BAN GIAO',b)]:
        path=Path(fresh(WORK/(family+' Q H '+label+' DOC PDF THAT200.png')))
        Image.fromarray(img).save(path)
        proofs.append(dict(path=str(path),sha256=sha(path)))
    comparisons.append(dict(family=family,page=page,H_columns_source_native_rect=[hx0,hy0,hx1,hy1],
        PDF_clip_rect_pt=list(rect),render_dpi=200,changed_pixels_threshold0=changes,pad_native=0,
        source_current_QH_table_unchanged=True,source_current_matching_does_not_accept_source_plateaus=True))
    planrec=next((r for r in old['records'] if r['family']==family),None)
    for row_index,row in enumerate(source_rows):
        H=row['H'];model=row['model'];maximum=max(H);minimum=min(H)
        assert H[0]==maximum and H[-1]==minimum and len(H)==n
        equal=[]
        for j in range(1,n):
            if H[j]>=H[j-1]:
                rec=dict(model=model,page=page,Q_left_m3_h=q[j-1],Q_right_m3_h=q[j],
                    H_left_source_m=H[j-1],H_right_source_m=H[j],
                    kind='BANG' if H[j]==H[j-1] else 'TANG',left_column_index=j-1,right_column_index=j)
                pairs.append(rec);equal.append(rec)
        locks={0:maximum,n-1:minimum}
        solved=solve_integer_descending(H,locks)
        assert solved['feasible']
        new=solved['H_proposed']
        assert maximum-minimum>=n-1
        delta=[v-h for h,v in zip(H,new)]
        assert all(v<=0 for v in delta),model
        assert all(new[j]<new[j-1] for j in range(1,n))
        assert all(new[j]==H[j] for j in [0,n-1])
        rbox=[x0,hs[row_index]['start'],x1,hs[row_index+1]['end_exclusive']]
        header=raw[y0:hs[0]['end_exclusive'],x0:x1]
        rowimg=raw[rbox[1]:rbox[3],x0:x1]
        joined=np.full((header.shape[0]+8+rowimg.shape[0],header.shape[1],3),255,dtype=np.uint8)
        joined[:header.shape[0]]=header;joined[-rowimg.shape[0]:]=rowimg
        ep=Path(fresh(WORK/(model.replace('/','_')+' TEN DAU COT VA HANG NGUON KHONG SUA.png')))
        Image.fromarray(joined).resize((joined.shape[1]*3,joined.shape[0]*3),Image.Resampling.NEAREST).save(ep)
        proof=dict(path=str(ep),sha256=sha(ep),header_source_box=[x0,y0,x1,hs[0]['end_exclusive']],row_source_box=rbox,
            evidence_is_collage_of_unmodified_source_header_and_row=True,new_numbers_not_painted_in_source_image=True)
        record=dict(model=model,page=page,family=family,Q_m3_h=q,H_source_m=H,H_proposed_m=new,
            delta_H_m=delta,source_equal_or_rise_pairs=equal,source_technical_rule='CHUA DAT' if equal else 'DAT BANG',
            integer_plan_status='DAT TOAN HOC CO DIEU KIEN - CHUA AP DUNG',
            locks=[dict(index=0,Q_m3_h=q[0],H_m=maximum,basis='Nguon Hmax/Qmin giu nguyen'),
                dict(index=n-1,Q_m3_h=q[-1],H_m=minimum,basis='Nguon Hmin/Qmax giu nguyen')],
            confirmed_additional_working_point_locks=[],additional_working_point_status=probe['additional_working_points_status'],
            conditional_on_no_extra_working_point_lock=True,source_extrema_values_and_endpoint_Q_positions_preserved=True,
            source_H_range=maximum-minimum,required_strict_integer_drop=n-1,
            range_slack_m=maximum-minimum-(n-1),solver=solved,source_row_evidence=proof,
            old_source_numbers_are_readback_not_manufacturer_acceptance=True,
            proposed_numbers_not_independently_verified_manufacturer_test_data=True,
            table_or_actual_curve_edited=False,whole_continuous_actual_curve_new_rule_check='CHUA CHAY',
            plot_graphic_acceptance='CHUA DAT CHU; NO RAM/PDF FOR P2P3')
        (p8 if family=='4SA16' else rows).append(record)
        for j,(Q,oldH,newH) in enumerate(zip(q,H,new)):
            cellbox=[vs[j]['start'],hs[row_index]['start'],vs[j+1]['end_exclusive'],hs[row_index+1]['end_exclusive']]
            cell=dict(model=model,page=page,Q_m3_h=Q,H_source_m=oldH,H_proposed_m=newH,
                delta_H_m=newH-oldH,source_table_cell_native_box=cellbox,source_table_column_index=j,
                source_table_row_index=row_index,source_cell_and_replacement_cell_location_same=True,
                source_table_cell_bbox_pixel_boundary_uncertainty=1,table_changed=False,
                source_row_with_column_header_evidence=proof['path'])
            if planrec is not None:
                bef=node_coordinates(planrec,Q,oldH);aft=node_coordinates(planrec,Q,newH)
                oldnode=next(z for z in planrec['proposed_table_nodes_with_local_H_mapping'] if z['model']==model and z['Q_m3_h']==Q)
                assert abs(bef['native_u']-oldnode['proposed_native_u'])<1e-9
                assert abs(bef['native_v']-oldnode['proposed_native_v'])<1e-9
                bp=cv.to_page(bef['native_u'],bef['native_v']);ap=cv.to_page(aft['native_u'],aft['native_v'])
                cell.update(before_source_table_target_coordinate=bef,after_proposal_table_target_coordinate=aft,
                    before_source_table_target_pdf_pt=list(map(float,bp)),after_proposal_target_pdf_pt=list(map(float,ap)),
                    changed_graph_native_v=aft['native_v']-bef['native_v'],
                    original_visible_curve_ink_coordinate_NOT_claimed=True,
                    coordinate_meaning='BEFORE/AFTER are target anchors of source/proposed TABLE, not remeasured current curve ink',
                    source_axis_position_uncertainty_native_px=1,PDF_coordinate_origin='bottom-left; native origin top-left')
            cell_rows.append(cell)

E.close();C.close()
changed=[c for c in cell_rows if c['delta_H_m']]
fixrows=[r for r in rows if r['source_equal_or_rise_pairs']]
assert len(rows)==14 and len(p8)==13 and len(pairs)==12 and len(fixrows)==10
assert sum(len(r['H_source_m']) for r in rows)==161 and sum(len(r['H_source_m']) for r in p8)==104
assert len(changed)==34 and max(abs(c['delta_H_m']) for c in changed)==2
assert not any(r['source_equal_or_rise_pairs'] or any(r['delta_H_m']) for r in p8)
AFTER=dict(source=sha(S.src(NAME)),current=sha(S.result(NAME)))
assert AFTER==BEFORE
record=dict(stage='READ-ONLY CONDITIONAL SA INTEGER DESCENDING PROPOSAL; ROOT REVIEW REQUIRED; NO PDF/TABLE/FONT CHANGE',
    timestamp_UTC=datetime.now(timezone.utc).isoformat(),source_current_before=BEFORE,source_current_after=AFTER,
    own_source_probe=dict(path=str(probe_path),sha256=sha(probe_path)),
    original_tasks_and_prompt_confirmed_extra_working_QH_locks_found=[],
    no_rated_point_inferred_from_model_code=True,
    conditional_on_no_other_working_point_to_be_confirmed=True,
    source_10_problem_models=[r['model'] for r in fixrows],source_12_equal_pairs=pairs,
    source14_rows161_H_cells=rows,proposed_total_changed_H_cells=34,max_absolute_change_H_m=2,
    minmax_extrema_conflict_count=0,integer_space_conflict_count=0,
    p8_table13_rows104_H_cells=p8,p8_table_strict_Q_up_H_down_result='DAT BANG ONLY',
    p8_saved_actual_whole_continuous_curve_new_rule_acceptance='CHUA CHAY - zero uniform whole-chart PDF; source canonical not comprehensively remeasured for monotonicity',
    p8_historical_RAM104_anchor_checks_do_not_replace_continuous_curve_acceptance=True,
    p8_RAM_graphics_result='CHUA DAT FONT - preserve V4 evidence, no further font trial',
    all265_table_cell_records=cell_rows,changed_34_cell_records=changed,
    actual_PDF_source_current_H_table_readback200=comparisons,
    source_evidence_files=proofs,
    numeric_proposal_NOT_source_test_fact=True,interpolation_not_yet_drawn=True,
    method='Constrained exact integer dynamic programming: fixed extrema/endpoints; minimum maximum edit, minimum total edit, then least edited cells/squared edit. No ratio applied to unassigned cells.',
    lower_absolute_change_bounds_exhaustively_tested=True,
    source_Q_columns_names_units_empty_cells_unchanged=True,
    PDF_saved_count=0,shared_progress_written=False,font_work_started=False,extra_source_numbers_added=False)
out=Path(fresh(WORK/'02 PHUONG AN NGUYEN GIAM14 HANG161 O VA TOA DO TRUOC SAU.json'))
out.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
csvp=Path(fresh(WORK/'03 TOA DO161 MOC BANG TRUOC SAU CHUA VE.csv'))
with csvp.open('w',encoding='utf-8-sig',newline='') as f:
    fields=['model','page','Q_m3_h','H_source_m','H_proposed_m','delta_H_m','table_cell_native_box','u_before','v_before','u_after','v_after','x_pt_before','y_pt_before','x_pt_after','y_pt_after','note']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for c in cell_rows:
        if c['page']==8:continue
        bef=c['before_source_table_target_coordinate'];aft=c['after_proposal_table_target_coordinate']
        w.writerow(dict(model=c['model'],page=c['page'],Q_m3_h=c['Q_m3_h'],H_source_m=c['H_source_m'],H_proposed_m=c['H_proposed_m'],delta_H_m=c['delta_H_m'],
            table_cell_native_box=json.dumps(c['source_table_cell_native_box']),u_before=bef['native_u'],v_before=bef['native_v'],u_after=aft['native_u'],v_after=aft['native_v'],
            x_pt_before=c['before_source_table_target_pdf_pt'][0],y_pt_before=c['before_source_table_target_pdf_pt'][1],x_pt_after=c['after_proposal_target_pdf_pt'][0],y_pt_after=c['after_proposal_target_pdf_pt'][1],
            note='De xuat co dieu kien; chua sua bang/duong; truoc la neo bang nguon, khong la muc net hien hanh'))
md=[
    '# Phương án số Perotac SA trang 2–3 — chỉ đọc, chưa áp dụng',
    '',f'Thời điểm UTC: {record["timestamp_UTC"]}. Tác nhân: /root/g03_aquaris_sa.',
    '',f'Nguồn SHA-256: {BEFORE["source"]}. Bản giao đã đọc: {BEFORE["current"]}.',
    '', '10 mã có 12 cặp H bằng nhau. Phương án sửa 34 ô, giảm 1 hoặc 2 m; giữ đúng Qmin/Qmax, Hmax/Hmin và tên/đơn vị. Không có mâu thuẫn khoảng số nguyên trong 14 hàng. 4 hàng còn lại trang 2 giữ toàn bộ số.',
    '', 'Điều kiện: chưa xác minh được điểm làm việc bổ sung cho 3SS3/3SS4 trong G04 hoặc 15 task (mục việc) nguyên gói; ROOT cũng chưa nêu khóa bổ sung. Không suy Q/H định mức từ mã máy. Nếu có khóa mới phải kiểm lại các đoạn khóa và tối ưu số, không tự phá khóa. Các cực trị và 3 điểm cuối ROOT nêu đều giữ nguyên.',
    '', 'Cách chọn: tối ưu số nguyên giảm nghiêm ngặt, ưu tiên mức sửa lớn nhất nhỏ nhất, sau đó tổng sửa nhỏ nhất, số ô sửa ít nhất. Mỗi hàng đã kiểm mọi giới hạn mức sửa thấp hơn trước khi chọn. Mức 2 m là kết quả toán, không suy là dữ liệu thử nghiệm hãng và không áp quy tắc tỷ lệ tầng cho ô chưa được giao.',
    '', 'Thứ tự Q trang 2: '+', '.join(map(str,rows[0]['Q_m3_h']))+' m³/h. Trang 3: '+', '.join(map(str,next(r for r in rows if r['page']==3)['Q_m3_h']))+' m³/h.',
    '', '| # việc | File | Trang | Cũ | Mới | Cách sửa | Kết quả | Bằng chứng |',
    '|---|---|---|---|---|---|---|---|']
for i,r in enumerate(fixrows,1):
    oldstr=', '.join(map(str,r['H_source_m']));newstr=', '.join(map(str,r['H_proposed_m']))
    md.append(f'| SA-SỐ-{i:02} {r["model"]} | {NAME} | {r["page"]} | {oldstr} | Đề xuất: {newstr} | Số nguyên giảm, giữ hai đầu; {r["solver"]["changed_cell_count"]} ô, lớn nhất {r["solver"]["minimal_maximum_absolute_change_m"]} m | CHƯA ĐẠT trên catalogue; toán có điều kiện đạt | JSON 02, CSV 03 và {Path(r["source_row_evidence"]["path"]).name} |')
md += ['', 'Tổng phạm vi cần chỉnh: 10 mã duy nhất · ĐẠT trên catalogue 0 · CHƯA ĐẠT 10. Đây là phần mở rộng, không cộng vào 149 việc gốc. 12 cặp bằng và 34 ô sửa không cộng thành mã việc.',
    '', 'Tọa độ trước/sau trong JSON/CSV là neo đích theo bảng nguồn và bảng đề xuất, dùng hai vạch thật bao quanh từng giá trị. Tọa độ trước không được gọi là tâm đường hiện hành. Có cả hộp từng ô từ mực lưới nguồn; ảnh hàng kèm tên và đầu cột. Bất định ảnh nguồn ±1 điểm ảnh; pt là đơn vị điểm PDF, gốc dưới trái.',
    '', 'Đọc PDF thật nguồn và bản giao ở 200 dpi (điểm ảnh mỗi inch): các cột Q/H cả ba bảng 3SS3/3SS4/4SA16 có 0 điểm ảnh khác với ngưỡng 0. Đó là bằng chứng chưa sửa bảng, không là nghiệm thu kỹ thuật các ô bằng.',
    '', 'Trang 8 tách riêng: 13 hàng/104 ô nguồn đều giảm nghiêm ngặt và giữ nguyên — ĐẠT BẢNG. Toàn nét liên tục của bản PDF theo quy tắc mới CHƯA CHẠY; 104 neo RAM lịch sử không thay phần này. RAM V4 (bộ nhớ) toàn chữ vẫn CHƯA ĐẠT; 0 PDF toàn biểu đồ, không thử phông tiếp.',
    '', 'Giới hạn: số mới là đề xuất kỹ thuật có điều kiện theo lệnh anh, chưa được hãng kiểm thử; chưa dựng đường mới, chưa sửa bảng/PDF và chưa nghiệm thu đồ họa. Không tạo giá trị cho ô trống, không kéo đường qua miền thiếu số. Phải sửa bảng và đường đồng thời sau ROOT khóa phương án.',
    '', 'Mã trước và sau nguồn/bản giao giống nhau. Không ghi TIEN DO.md; không nhận thêm khóa ghi PDF cho công việc chỉ đọc. Bước tiếp: ROOT đọc 34 ô đề xuất/khóa, đưa con trỏ vào danh sách cần sửa và quyết định phương án đường đồng bộ.']
mdp=Path(fresh(WORK/'04 BAO CAO8 COT SA10 MA12 CAP BANG PHUONG AN34 O.md'))
mdp.write_text('\n'.join(md)+'\n',encoding='utf8')
print('INTEGER PLAN',out,'SHA256',sha(out),'ROWS',len(rows),'PAIRS',len(pairs),'FIX MODELS',len(fixrows),'CHANGED',len(changed),'MAX',2,'PDF0',flush=True)
for r in fixrows:
    print(r['model'],'SOURCE',r['H_source_m'],'PROPOSED',r['H_proposed_m'],'DELTA',r['delta_H_m'],'RANGE',r['source_H_range'],'REQUIRED',r['required_strict_integer_drop'],flush=True)
print('REPORT',mdp,'SHA256',sha(mdp),'CSV',csvp,'SHA256',sha(csvp),flush=True)
