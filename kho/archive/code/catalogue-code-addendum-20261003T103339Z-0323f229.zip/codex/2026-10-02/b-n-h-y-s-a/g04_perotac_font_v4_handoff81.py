"""Freeze font failures and own-source strict-H status; no more methods run."""
from catwork import start, fresh
S, D, N = start()
from pathlib import Path
from g04_perotac_whole_pdf_tools46 import read, sha
from g04_perotac_source9_eta_union_builder77 import NAME, RAM_REL
from g04_perotac_audit_data import DATA
import json, ast, numpy as np

base=Path(S.report('G04/PHUONG AN DONG BO TOAN BIEU DO P08'))
root=base/'BAN GIAO RAMV4 FONT CHUA DAT KHOA NGUON DUNG THU'
actual_path=base/'RAM CATFIX NGUON9 DAO V4 ETA60 NGUYEN CUM CHUA LUU PDF/CATFIX NGUON9 DAO RAM V4 DOC LAI MUC THAT VA NGOAI VUNG.json'
halo_path=base/'RAMV4 KIEM TOAN9 DAO10 CUM VA HALO NGOAI2PIXEL CHI DOC/DAY DU9 MEP HALO2 VA PIXEL NGUON THAT RAMV4.json'
allwords_path=base/'RAMV4 DOC LAI CA62 CUM CHU TRUC SOURCE ACTUAL CHI DOC/DOC LAI62 CUM CHU TRUC SOURCE ACTUAL RAMV4 CHI DOC.json'
actual=read(actual_path);halo=read(halo_path);words=read(allwords_path);ram=read(S.report(RAM_REL))
assert sha(S.src(NAME))==actual['source_sha256'] and sha(S.result(NAME))==actual['canonical_sha256']
source_rows=next(d for d in DATA if d['page']==8 and d['family']=='4SA16')
strict_p8=[]
for row in source_rows['rows']:
    diff=np.diff(row['H']);assert np.all(diff<0)
    strict_p8.append(dict(model=row['model'],all8_source_H_values=row['H'],every_increasing_Q_has_strictly_lower_H=True,
        source_min_H=min(row['H']),source_max_H=max(row['H']),no_source_table_anchor_changed=True))
outside_proposal=[]
for family in ['3SS3','3SS4']:
    data=next(d for d in DATA if d['family']==family)
    failures=[]
    for row in data['rows']:
        for i in range(1,len(row['H'])):
            if row['H'][i]>=row['H'][i-1]:
                failures.append(dict(model=row['model'],previous_Q_m3_h=data['Q_m3_h'][i-1],Q_m3_h=data['Q_m3_h'][i],
                    previous_H_source_m=row['H'][i-1],H_source_m=row['H'][i],
                    fail_new_user_strict_H_rule=True,no_corrected_integer_H_invented_or_written=True))
    outside_proposal.append(dict(family=family,page=data['page'],source_plateau_or_rise_pairs=failures,
        pair_count=len(failures),source_readback_is_not_technical_acceptance=True,
        prior161_node_plan_needs_review_under_new_strict_H_instruction=True,
        preserve_source_extrema_and_all_ROOT_locked_rated_anchors_before_any_correction=True,
        numeric_table_and_graph_correction_NOT_STARTED=True))

font_fails=[('Q US 60','Nét 6 và 0 nối nhau, đậm/thô so với cụm nguồn.'),
    ('Q US 80','Nét 8 và 0 nối nhau, dáng vòng và khoảng chữ lệch nguồn.'),
    ('Q IMP 80','Nét 8 và 0 nối nhau; nguồn vẫn đọc rõ hai số.'),
    ('H M 100','Hai số 0 nối giữa thân; hình mới thô/đậm.'),
    ('H FEET 100','Hai số 0 nối; số 1 bị phồng so với nguồn.'),
    ('Q US 40','Số 4 thành khối/như hình thoi, không giữ dáng nhìn nguồn.'),
    ('H FEET 400','Số 4 thành khối, các vòng 0 méo/đậm.'),
    ('ETA 40','Số 4 thành khối, lòng chữ và nét không đạt hình thức.')]
wordmap={r['key']:r for r in words['words']}
font_records=[]
for key,note in font_fails:
    r=wordmap[key]
    font_records.append(dict(key=key,literal_source_read=r['literal'],source_box=r['original_word_native_box'],
        visual_source_actual600_result='CHUA DAT',reason=note,
        actual_source_image=r['source_actual_image_path'],actual_source_image_sha256=r['source_actual_image_sha256'],
        numeric_literal_may_still_be_readable_but_font_graphic_not_accepted=True,
        original_font_program_identity_UNKNOWN=True))

atlas_dir=allwords_path.parent
atlases=[atlas_dir/(f'{i:02} ATLAS CUM TRUC NGUON ACTUAL600 DAY DU.png') for i in [1,2,3]]
here=Path(__file__).resolve().parent
paths=[Path(S.src(NAME)),Path(S.result(NAME)),actual_path,halo_path,allwords_path,Path(S.report(RAM_REL)),
    Path(actual['font_report_path']),Path(actual['axis_report_path']),
    actual_path.parent/'PEROTAC P08 CATFIX TOAN TRANG150 NGUON9 DAO CHUA NGHIEM THU.png',
    actual_path.parent/'PEROTAC P08 CATFIX THAT600 NGUON9 DAO CHUA NGHIEM THU.png',
    actual_path.parent/'9 CUM CHU NGUYEN NGUON VA ACTUAL CATFIX600.png',
    actual_path.parent/'LENH CATFIX TRANG08 NGUON9 DAO KHONG CHE TRANG.txt',
    here/'g04_perotac_source9_eta_union_builder77.py',here/'g04_perotac_source9_eta_union_actual78.py',
    here/'g04_perotac_source9_eta_union_halo79.py',here/'g04_perotac_axis_all_fields80.py',
    here/'g04_perotac_whole_actual_read50.py',here/'g04_perotac_whole_pdf_tools46.py']+atlases
for p in paths:
    if p.suffix=='.py':ast.parse(p.read_text(encoding='utf8'))
checks=actual['actual_serialized_RAM_checks']
assert all(r['outside_changed_pixels']==0 for r in checks['outside200_threshold0_pad0_all11'])
assert checks['actual104_path_and_visible_points_match'] and checks['actual_named_new_objects_match']
assert not checks['new_stroke_footprints_intruding_source_text_islands']
assert actual['source_native_edit_box']==[65,117,790,805]
assert len(actual['new_objects'])==382
record=dict(stage='SA RAMV4 FONT CHUA DAT; STOP FONT METHODS PENDING ROOT; ZERO WHOLE-CHART PDF RELEASE',
    source_sha256=actual['source_sha256'],canonical_sha256=actual['canonical_sha256'],
    actual_RAM_report_path=str(actual_path),actual_RAM_report_sha256=sha(actual_path),
    prepared_content_sha256=actual['prepared_content_sha256'],
    own_source_X7_CTM_bytes_preserved=True,all_previous_QH104_glyph4_13names_34ticks_eta_retained=True,
    all382_retained_new_geometry_and_style_matched_actual_stream=True,
    graphics_entire_chart_result='CHUA DAT - font contours and full exterior halo not accepted',
    current_source_literal_islands=actual['source_literal_islands_all'],source_literal_island_count=9,
    source_literal_word_count=10,axis_bank_word_count=62,remaining_axis_contour_count=52,
    ETA60_original_cluster_only_no_new_contour=True,one_merged_Eta_percent_and60_island=[85,577,123,604],
    H200_extension_only_authorized_half_pixel=True,H200_remaining_exterior_gray_halo_UNRESOLVED=True,
    US10_and30_exterior_source_halo_and_tick_classification_PENDING=True,
    all_crop_or_font_bytes_equal_NOT_CLAIMED=True,interior2pixel_check_NOT_full_caption_acceptance=True,
    observed_font_failures=font_records,other_axis_fields_graphic_acceptance='PENDING - do not assume PASS from path/metadata',
    all_axis_word_source_actual_contact_report=str(allwords_path),three_atlas_paths=[str(p) for p in atlases],
    source_strict_H_status_p8=strict_p8,source_H_rule_review_p2p3=outside_proposal,
    p8_source_QH104_and_actual_path_checks_passed_but_no_PDF_font_acceptance=True,
    source_eta_clear_body_547_of558_coordinate_constraint_kept=True,
    source_eta11_initial_centers_AND_numeric_eta_values_UNKNOWN=True,
    saved_PDF_count=0,historical_writer65_NOT_authorized_or_run=True,
    M1_QA_saved_file='CHUA CHAY - no saved M1 exists',
    new62island_method_NOT_authorized_or_started=True,no_further_font_sample_method_started=True,
    source_current_banks_and_shared_progress_unchanged=True,
    locked_files=[dict(path=str(p),sha256=sha(p)) for p in paths])
out=Path(fresh(root/'BAN GIAO FONT RAMV4 CHUA DAT VA NGUON KHOA.json'));out.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
md='''# Bàn giao Perotac SA p8 RAM V4 — chữ CHƯA ĐẠT

0 lần lưu PDF toàn biểu đồ. Bản nguồn và bản giao giữ nguyên mã kiểm tra tệp. Không chạy writer65, không mở phương pháp 62 đảo, không sửa bank hoặc TIEN DO.md.

Giữ nguyên 104 số của 13 hàng 4SA16: cả 13 hàng đều Q tăng, H giảm nghiêm ngặt; giữ min/max và mọi neo bảng. Đọc lại thực trong RAM đạt 104 neo, 382 đường/vùng tô khớp tọa độ/kiểu; ngoài vùng 200 dpi, ngưỡng 0, không nới trên cả 11 trang = 0 pixel đổi. Ảnh/SMask (mặt nạ ảnh)/CTM (ma trận vị trí)/Info/XMP (thông tin PDF) nguyên. Đó là nghiệm thu kỹ thuật riêng, không là đạt toàn đồ họa.

V4 dùng một đảo cắt nguồn gộp Eta(%)+60 [85,577,123,604], bỏ contour ETA60 mới; không đặt hai hộp chồng nhau trong cắt W*. Chữ 60 đã về đúng nguồn. H200 chỉ mở trái 0,5 pixel như ROOT cho phép; quầng xám còn ngoài ranh này chưa được xác minh. US10/30 có hàng quầng dưới y159 sát vạch, chưa gán hết là nền.

Khi đọc cả 62 cụm, thấy rõ các contour còn lỗi: US60/80, IMP80 nối hai số; HM100/HFEET100 nối hai số0; US40/HFEET400/ETA40 méo số4. Có 3 atlas nguồn–actual600 và ảnh riêng từng cụm trong hồ sơ khóa. Không nhận nguyên phông vì nguồn JPEG không có chương trình phông hoặc biên vector gốc; không dùng diện tích alpha, ±2% phông lý tưởng hoặc crop bỏ2pixel để nhận đạt cả chữ.

Chữ số4 trong bộ tên máy và 13 tên đã được ROOT/đồ họa chấp nhận riêng; phần này giữ nguyên. η dùng đúng nguồn Perotac: 547/558 tâm rõ giữ ràng buộc, 11 điểm đầu lẫn khung chưa chắc; không có bảng số η nên số hiệu suất CHƯA THỂ XÁC MINH.

Quy tắc mới của anh về H giảm nghiêm ngặt làm phương án đọc 161 ô trang2–3 trước đây chưa đủ chấp nhận kỹ thuật: 3SS3 và 3SS4 có các ô nguồn bằng nhau. JSON liệt kê đúng từng cặp; chưa tự điều chỉnh số, chưa dựng RAM/PDF hai trang này. Mọi sửa trung gian phải giữ cực trị min/max và các điểm định mức ROOT đã khóa, không suy định mức chỉ từ tên model.

Chờ ROOT chọn hướng xử lý chữ với bộ nguồn khóa, dừng thử thêm để tránh lặp phương pháp. Mã writer/QA cho bản được duyệt phải khóa mới đúng RAM sau khi chữ đạt; writer65 cũ dùng V2 nên không chạy cho V4.
'''
Path(fresh(root/'BAN GIAO RAMV4 FONT CHUA DAT KHONG PHAT HANH.md')).write_text(md,encoding='utf8')
print('HANDOFF',out,'SHA256',sha(out),'SOURCE H P8 STRICT',len(strict_p8),'OTHER PAIRS',[(r['family'],r['pair_count']) for r in outside_proposal],'PDF0',flush=True)
